import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}
function combineRgb(r, g, b, a) {
  let colorNumber = (r & 255) << 16 | (g & 255) << 8 | b & 255;
  if (a && a >= 0 && a < 1) {
    colorNumber += 16777216 * Math.round(255 * (1 - a));
  }
  return colorNumber;
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path3, args) {
    this.#context.oscSend(host, port, path3, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/config.js
import fs from "fs";
import path from "path";
var logger = createModuleLogger("Config");
function resolveDevicesFolder() {
  const primaryPath = path.join(import.meta.dirname, "../devices");
  const fallbackPath = path.join(import.meta.dirname, "./devices");
  if (fs.existsSync(primaryPath)) {
    logger.debug(`Using devices folder: ${primaryPath}`);
    return primaryPath;
  }
  if (fs.existsSync(fallbackPath)) {
    logger.warn(`Primary devices folder not found, using fallback: ${fallbackPath}`);
    return fallbackPath;
  }
  const errorMsg = `Devices folder not found!
Tried:
  - ${primaryPath}
  - ${fallbackPath}
Module cannot continue without device schemas.`;
  logger.error(errorMsg);
  throw new Error(errorMsg);
}
var devicesFolder = resolveDevicesFolder();
var deviceSchemasCache = null;
function getDevicesFolder() {
  return devicesFolder;
}
function loadDeviceSchemas() {
  const schemas = {};
  try {
    const files = fs.readdirSync(devicesFolder).filter((f) => f.endsWith(".json"));
    for (const f of files) {
      const fullPath = path.join(devicesFolder, f);
      const json = JSON.parse(fs.readFileSync(fullPath, "utf8"));
      if (json?.model) {
        schemas[String(json.model)] = json;
      }
    }
    logger.debug(`Loaded ${Object.keys(schemas).length} device schemas into cache`);
  } catch (e) {
    logger.error(`Failed to load device schemas: ${e}`);
  }
  return schemas;
}
function getDeviceSchemas() {
  if (!deviceSchemasCache) {
    deviceSchemasCache = loadDeviceSchemas();
  }
  return deviceSchemasCache;
}
function getDeviceSchema(model) {
  const schemas = getDeviceSchemas();
  return schemas[model];
}
function reloadDeviceSchemas() {
  logger.info("Reloading device schemas from disk...");
  deviceSchemasCache = loadDeviceSchemas();
}
function loadAvailableModels() {
  const schemas = getDeviceSchemas();
  return Object.keys(schemas).sort();
}
function GetConfigFields(discoveredDevices = []) {
  const models = loadAvailableModels();
  const deviceChoices = [
    { id: "", label: "Manual (enter IP + model below)" },
    ...discoveredDevices.map((d) => ({
      id: d.mac ?? "",
      label: `Model ${d.model} [${d.mac}] @ ${d.ip}`
    }))
  ];
  return [
    // ── Device selection dropdown ────────────────────────────────────────
    // Stores the MAC so re-discovery with a changed IP still matches.
    {
      type: "dropdown",
      id: "deviceMac",
      label: "Device",
      width: 8,
      default: "",
      choices: deviceChoices,
      tooltip: "Select an auto-discovered Studio Technologies device, or choose Manual to enter an IP address."
    },
    // ── Manual IP entry — only visible in manual mode ────────────────────
    {
      type: "textinput",
      id: "host",
      label: "Target IP",
      width: 8,
      default: "",
      regex: Regex.IP,
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Enter the IP address of the device manually."
    },
    // ── Manual model selector — only visible in manual mode ──────────────
    {
      type: "dropdown",
      id: "activeModel",
      label: "Active Device Model",
      width: 8,
      default: models[0] ?? "",
      choices: models.map((model) => ({
        id: model,
        label: `Model ${model}`
      })),
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Select which Studio Technologies model is active for actions and feedbacks."
    },
    // ── Dev Mode ─────────────────────────────────────────────────────────
    {
      type: "checkbox",
      id: "devMode",
      label: "Dev Mode",
      width: 12,
      default: false,
      tooltip: "Enable to allow parsing of ST Devices not currently supported"
    }
  ];
}
function resolveHost(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    return device?.ip ?? "";
  }
  return String(config.host ?? "");
}
function resolveModel(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    logger.debug(`resolveModel: deviceMac="${config.deviceMac}", found device: ${device?.model ?? "none"}`);
    return device?.model ?? "";
  }
  logger.debug(`resolveModel: manual mode, activeModel="${config.activeModel}"`);
  return String(config.activeModel ?? "");
}

// dist/variables.js
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions({
    model: { name: "Device Model Number" },
    modelName: { name: "Device Model Name (Full Description)" },
    manufacturer: { name: "Device Manufacturer" },
    firmware: { name: "Device Firmware Version" },
    danteFW: { name: "Dante Module Firmware Version" },
    mac: { name: "Device MAC Address" },
    ip: { name: "Device IP Address" }
  });
}
var CLEARED_VARIABLES = {
  model: "",
  modelName: "",
  manufacturer: "",
  firmware: "",
  danteFW: "",
  mac: "",
  ip: ""
};
function UpdateVariableValues(self) {
  const currentHost = self.host;
  if (!currentHost || !self.stController.isDeviceAuthorized(currentHost)) {
    self.setVariableValues(CLEARED_VARIABLES);
    return;
  }
  const device = self.devices.find((d) => d.ip === currentHost);
  if (device) {
    self.setVariableValues({
      model: device.model || "",
      modelName: device.modelName || "",
      manufacturer: device.manufacturer || "",
      firmware: device.firmwareMain || "",
      danteFW: device.danteFirmware || "",
      mac: device.mac || "",
      ip: device.ip
    });
  } else {
    self.setVariableValues({
      ...CLEARED_VARIABLES,
      ip: currentHost
    });
  }
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  // function (context, props) {
  // 	return {
  // 		updatedConfig: null,
  // 		updatedActions: [],
  // 		updatedFeedbacks: [],
  // 	}
  // },
];

// dist/types.js
var CMD_GET_FIRMWARE = 0;
var CMD_MIC_PRE = 2;
var CMD_BUS_GET = 3;
var CMD_BUS_SET = 4;
var CMD_HEADPHONE = 5;
var CMD_BUTTON_MODE = 7;
var CMD_SYSTEM = 9;
var CMD_GET_ALL_SETTINGS = 10;
var CMD_SETTINGS_PUSH = 11;
var CMD_DEV_SPEC = 13;
var CMD_RESET_DEVICE = 14;
var CMD_GLOBAL_MIC_KILL = 16;
var CMD_MIC_PRE_BUS = 18;
var CMD_CHANNEL = 20;
function getCommandName(cmdId) {
  switch (cmdId) {
    case CMD_GET_FIRMWARE:
      return "Get Firmware Version";
    case CMD_MIC_PRE:
      return "Mic Preamp";
    case CMD_BUS_GET:
      return "Heartbeat";
    case CMD_BUS_SET:
      return "Set Bus Setting";
    case CMD_HEADPHONE:
      return "Headphone Control";
    case CMD_BUTTON_MODE:
      return "Button Mode";
    case CMD_SYSTEM:
      return "System Command";
    case CMD_GET_ALL_SETTINGS:
      return "Request All Settings";
    case CMD_SETTINGS_PUSH:
      return "Settings Push";
    case CMD_MIC_PRE_BUS:
      return "Mic/Pre Bus";
    case CMD_DEV_SPEC:
      return "Device Setting";
    case CMD_CHANNEL:
      return "Channel Setting";
    case CMD_RESET_DEVICE:
      return "Reset Device";
    case CMD_GLOBAL_MIC_KILL:
      return "Global Mic Kill";
    default:
      return `cmd_0x${cmdId.toString(16).padStart(2, "0")}`;
  }
}
function makeSettingId(model, cmdId, settingId, busCh) {
  const cmd = typeof cmdId === "number" ? cmdId.toString(16) : cmdId;
  const id = typeof settingId === "number" ? settingId.toString(16) : settingId;
  if (busCh !== void 0) {
    const ch = typeof busCh === "number" ? busCh.toString(16) : busCh;
    return `${model}_${cmd}_${ch}_${id}`;
  }
  return `${model}_${cmd}_${id}`;
}
function toHex(value, padLength = 2) {
  return `0x${value.toString(16).padStart(padLength, "0")}`;
}
function bytesToHex(bytes) {
  return `0x${Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}
function formatRgbColor(r, g, b) {
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}
function parseSettingId(id) {
  const [model, cmdIdStr, idStr] = id.split("_");
  return {
    model,
    cmdId: parseInt(cmdIdStr, 16),
    baseId: parseInt(idStr, 16)
  };
}
function modelDistance(modelA, modelB) {
  const na = parseInt(modelA.replace(/\D/g, ""), 10);
  const nb = parseInt(modelB.replace(/\D/g, ""), 10);
  if (Number.isNaN(na) || Number.isNaN(nb))
    return Infinity;
  return Math.abs(na - nb);
}
function getNormalizedSchemas(schemasRaw) {
  const normalized = {};
  for (const [model, json] of Object.entries(schemasRaw)) {
    normalized[model] = {
      model: json.model,
      cmdSchema: Array.isArray(json.cmdSchema) ? json.cmdSchema : []
    };
  }
  return normalized;
}
function findActionForSetting(schemas, model, cmdId, settingId) {
  const schema = schemas[model];
  if (!schema || !Array.isArray(schema.cmdSchema))
    return void 0;
  let action = schema.cmdSchema.find((s) => s.cmd_id === cmdId && s.id === settingId);
  if (!action) {
    action = schema.cmdSchema.find((s) => {
      if (s.cmd_id !== cmdId)
        return false;
      const idAddOption = s.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const offset = settingId - s.id;
      return idAddOption.choices.some((c) => c.id === offset);
    });
  }
  return action;
}

// dist/build-commands.js
function buildOption(o) {
  const base = {
    type: o.type,
    id: o.id,
    label: o.label,
    default: o.default,
    tooltip: o.tooltip
  };
  switch (o.type) {
    case "dropdown":
      return { ...base, choices: o.choices ?? [] };
    case "number":
      return {
        ...base,
        min: o.min,
        max: o.max,
        step: o.step ?? 1,
        range: true
      };
    case "checkbox":
      return { ...base, default: o.default ?? false };
    case "static-text":
      return { ...base, value: o.value ?? "" };
    case "textinput":
    case "colorpicker":
    default:
      return base;
  }
}
function buildActions() {
  const schemas = getDeviceSchemas();
  const actions = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const a of cmdSchema) {
      if (a.readonly === true)
        continue;
      const actionId = makeSettingId(model, a.cmd_id, a.id);
      const options = (a.options ?? []).map(buildOption);
      const action = {
        name: `[Model${model}] ${a.name}`,
        options,
        callback: async () => {
        }
      };
      actions[actionId] = action;
    }
  }
  return actions;
}
function isOnOffDropdown(setting) {
  const valueOpt = setting.options?.find((o) => o.id === "value");
  if (!valueOpt || valueOpt.type !== "dropdown" || !Array.isArray(valueOpt.choices))
    return false;
  if (valueOpt.choices.length !== 2)
    return false;
  const labels = valueOpt.choices.map((c) => String(c.label).toLowerCase());
  return labels.includes("off") && labels.includes("on");
}
function buildFeedbacks() {
  const schemas = getDeviceSchemas();
  const feedbacks = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const setting of cmdSchema) {
      if (setting.writeonly === true)
        continue;
      const baseFeedbackId = makeSettingId(model, setting.cmd_id, setting.id);
      const allOptions = (setting.options ?? []).map(buildOption);
      const valueOptions = allOptions.filter((opt) => opt.id !== "value");
      valueOptions.push({
        type: "checkbox",
        id: "showLabel",
        label: "Show Label",
        default: false,
        tooltip: "Return the label text instead of the numeric value"
      });
      const valueFeedback = {
        type: "value",
        name: `[Model${model}] ${setting.name}`,
        options: valueOptions,
        callback: () => {
          return 0;
        }
      };
      if (isOnOffDropdown(setting)) {
        const boolFeedbackId = `${baseFeedbackId}_bool`;
        const boolOptions = allOptions.filter((opt) => opt.id !== "value");
        const boolFeedback = {
          type: "boolean",
          name: `[Model${model}] ${setting.name} \u2014 Is On`,
          defaultStyle: {
            bgcolor: combineRgb(0, 200, 0),
            color: combineRgb(0, 0, 0)
          },
          options: boolOptions,
          callback: () => {
            return false;
          }
        };
        feedbacks[boolFeedbackId] = boolFeedback;
      } else {
        feedbacks[baseFeedbackId] = valueFeedback;
      }
    }
  }
  return feedbacks;
}

// dist/actions.js
import path2 from "path";

// dist/settingsParser.js
import fs2 from "fs";
var logger2 = createModuleLogger("SettingsParser");
function getModelConfig(model) {
  const rgbIds = /* @__PURE__ */ new Set();
  let sectioned = false;
  try {
    const json = getDeviceSchema(model);
    if (!json) {
      return { sectioned, rgbIds };
    }
    sectioned = json.sectioned ?? false;
    for (const action of json.cmdSchema || []) {
      const hasColorpicker = action.options?.some((opt) => opt.type === "colorpicker");
      if (hasColorpicker) {
        rgbIds.add(action.id);
        const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
        if (idAddOption?.choices) {
          for (const choice of idAddOption.choices) {
            if (typeof choice.id === "number") {
              rgbIds.add(action.id + choice.id);
            }
          }
        }
      }
    }
  } catch (_err) {
  }
  return { sectioned, rgbIds };
}
function extractStPayloadIndex(buf) {
  const sigIndex = buf.indexOf(Buffer.from("Studio-T"));
  if (sigIndex < 0)
    throw new Error("No Studio-T signature in packet");
  const payloadIndex = sigIndex + 8;
  if (buf[payloadIndex] !== 90) {
    throw new Error(`Expected 0x5A after Studio-T, found ${buf[payloadIndex].toString(16)}`);
  }
  return payloadIndex;
}
function parseFlatIdValSequence(block, rgbIds = /* @__PURE__ */ new Set()) {
  let p = 0;
  const out = [];
  while (p < block.length) {
    const id = block[p];
    if (p + 1 >= block.length)
      break;
    if (rgbIds.has(id) && p + 3 < block.length) {
      out.push({
        cmd_id: CMD_DEV_SPEC,
        id,
        valueBytes: [block[p + 1], block[p + 2], block[p + 3]]
      });
      p += 4;
      continue;
    }
    out.push({ cmd_id: CMD_DEV_SPEC, id, valueBytes: [block[p + 1]] });
    p += 2;
  }
  return out;
}
function parseGetAllSettings_flat(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  const blockLen = buf[idx + 2];
  const start = idx + 3;
  const end = start + blockLen;
  if (end > buf.length)
    throw new Error("Invalid block length");
  const { rgbIds } = getModelConfig(model);
  return parseFlatIdValSequence(buf.subarray(start, end), rgbIds);
}
function parseGetAllSettings_sectioned(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  let p = cmdId === CMD_GET_ALL_SETTINGS ? idx + 3 : idx + 2;
  const end = buf.length - 1;
  const out = [];
  const { rgbIds } = getModelConfig(model);
  const commandsWithBusCh = [CMD_BUS_SET, CMD_MIC_PRE_BUS, CMD_CHANNEL];
  const commandsRawValue = [CMD_MIC_PRE];
  while (p + 2 < end) {
    const cmdLen = buf[p];
    const sectionCmdId = buf[p + 1];
    const sectionEnd = p + 1 + cmdLen;
    if (sectionEnd > end)
      break;
    const hasBusCh = commandsWithBusCh.includes(sectionCmdId);
    const isRawValue = commandsRawValue.includes(sectionCmdId);
    let busCh;
    let dataLen;
    let q;
    if (isRawValue) {
      busCh = buf[p + 2];
      const rawBytes = buf.subarray(p + 3, sectionEnd);
      const schema = getDeviceSchema(model);
      const micPreEntries = (schema?.cmdSchema ?? []).filter((a) => (a.cmd_id === CMD_MIC_PRE || a.cmd_id === CMD_MIC_PRE_BUS) && a.busCh !== void 0).sort((a, b) => a.id - b.id);
      for (let i = 0; i < rawBytes.length; i++) {
        const entry = micPreEntries[i];
        if (entry) {
          out.push({ cmd_id: entry.cmd_id, id: entry.id, busCh, valueBytes: [rawBytes[i]] });
        }
      }
      p = sectionEnd;
      continue;
    } else if (hasBusCh) {
      busCh = buf[p + 2];
      dataLen = buf[p + 3];
      q = p + 4;
    } else {
      dataLen = buf[p + 2];
      q = p + 3;
    }
    const qEnd = q + dataLen;
    const qStart = q;
    while (q + 1 < qEnd) {
      const id = buf[q];
      let valueBytes;
      if (rgbIds.has(id) && q + 3 < qEnd) {
        valueBytes = [buf[q + 1], buf[q + 2], buf[q + 3]];
        q += 4;
      } else {
        valueBytes = [buf[q + 1]];
        q += 2;
      }
      const setting = {
        cmd_id: sectionCmdId,
        id,
        valueBytes
      };
      if (busCh !== void 0) {
        setting.busCh = busCh;
      }
      out.push(setting);
    }
    if (q === qStart && sectionEnd > p + 3) {
      let pos = hasBusCh ? p + 3 : p + 2;
      let posId = 0;
      while (pos < sectionEnd) {
        const setting = { cmd_id: sectionCmdId, id: posId++, valueBytes: [buf[pos++]] };
        if (busCh !== void 0)
          setting.busCh = busCh;
        out.push(setting);
      }
    }
    p = sectionEnd;
  }
  return out;
}
function parseSettingsResponse(model, buf) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error(`Not a settings block (cmdId=0x${cmdId.toString(16)})`);
  }
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function formatParsedSetting(setting, actions) {
  let action = actions.find((a) => a.cmd_id === setting.cmd_id && a.id === setting.id);
  if (!action) {
    const baseAction = actions.find((a) => {
      if (a.cmd_id !== setting.cmd_id)
        return false;
      const idAddOption = a.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const channelOffset = setting.id - a.id;
      return idAddOption.choices.some((c) => c.id === channelOffset);
    });
    if (baseAction) {
      action = baseAction;
    }
  }
  const cmdHex = toHex(setting.cmd_id);
  const idHex = toHex(setting.id);
  const valHex = bytesToHex(setting.valueBytes);
  const valDec = setting.valueBytes.length === 3 ? formatRgbColor(setting.valueBytes[0], setting.valueBytes[1], setting.valueBytes[2]) : setting.valueBytes.length === 1 ? setting.valueBytes[0] : setting.valueBytes.join(",");
  const busChStr = setting.busCh !== void 0 ? ` ch:${setting.busCh}` : "";
  const prefix = `cmd:${cmdHex}${busChStr} id:${idHex} val:${valHex}`;
  if (action) {
    let name = action.name;
    if (setting.busCh !== void 0) {
      name = `${name} Ch${setting.busCh + 1}`;
    } else {
      const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
      if (idAddOption?.choices) {
        const channelOffset = setting.id - action.id;
        const idAddChoice = idAddOption.choices.find((c) => c.id === channelOffset);
        if (idAddChoice) {
          name = `${name} ${idAddChoice.label}`;
        }
      }
    }
    const valueOption = action.options?.find((opt) => opt.id === "value");
    if (valueOption?.choices && setting.valueBytes.length === 1) {
      const choice = valueOption.choices.find((c) => c.id === setting.valueBytes[0]);
      if (choice) {
        return `${prefix} | ${name}: ${choice.label} (${valDec})`;
      }
    }
    return `${prefix} | ${name}: ${valDec}`;
  }
  return `${prefix} | Unknown Setting`;
}
function parseGetAllSettingsWithDetection(model, buf) {
  const schema = getDeviceSchema(model);
  const declaredSectioned = schema?.sectioned;
  if (declaredSectioned !== void 0) {
    const settings = declaredSectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
    return { settings, detectedSectioned: null };
  }
  let flatSettings = [];
  let sectionedSettings = [];
  try {
    flatSettings = parseGetAllSettings_flat(buf, model);
  } catch (e) {
    logger2.debug(`Flat parser failed: ${e}`);
  }
  try {
    sectionedSettings = parseGetAllSettings_sectioned(buf, model);
  } catch (e) {
    logger2.debug(`Sectioned parser failed: ${e}`);
  }
  if (sectionedSettings.length > flatSettings.length) {
    logger2.info(`Auto-detected SECTIONED format (sectioned=${sectionedSettings.length} vs flat=${flatSettings.length})`);
    return { settings: sectionedSettings, detectedSectioned: true };
  } else if (flatSettings.length > 0) {
    logger2.info(`Auto-detected FLAT format (flat=${flatSettings.length} vs sectioned=${sectionedSettings.length})`);
    return { settings: flatSettings, detectedSectioned: false };
  } else {
    logger2.warn(`Warning: Both parsers returned 0 settings for model ${model}`);
    return { settings: [], detectedSectioned: null };
  }
}
function parseGetAllSettingsForModel(model, buf) {
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function valueBytesToOption(valueBytes) {
  if (valueBytes.length === 1) {
    return { id: "value", label: "Value", type: "number", default: valueBytes[0] };
  }
  if (valueBytes.length === 3) {
    const [r, g, b] = valueBytes;
    return {
      id: "value",
      label: "Color",
      type: "colorpicker",
      default: formatRgbColor(r, g, b)
    };
  }
  return { id: "value", label: "Value", type: "raw", default: [...valueBytes] };
}
function updateModelJsonFromSettings(modelJson, parsed, allModels) {
  const out = structuredClone(modelJson);
  if (!out.cmdSchema) {
    out.cmdSchema = [];
  }
  const candidates = Object.values(allModels).filter((m) => m.model !== modelJson.model).sort((a, b) => modelDistance(modelJson.model, a.model) - modelDistance(modelJson.model, b.model));
  logger2.info(`Updating model: ${modelJson.model}`);
  logger2.debug(`Candidates for inference: ${candidates.map((c) => c.model).join(", ")}`);
  const idAddDeferRanges = /* @__PURE__ */ new Map();
  for (const c of candidates) {
    for (const baseEntry of c.cmdSchema ?? []) {
      const idAddOpt = baseEntry.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        continue;
      const baseId = baseEntry.id;
      const cmdId = baseEntry.cmd_id;
      const key = `${cmdId}_${baseId}`;
      if (idAddDeferRanges.has(key))
        continue;
      const parsedOffsets = parsed.filter((p) => p.cmd_id === cmdId && p.id > baseId).map((p) => p.id - baseId).sort((a, b) => a - b);
      let maxSeq = 0;
      for (const off of parsedOffsets) {
        if (off === maxSeq + 1)
          maxSeq = off;
        else if (off > maxSeq + 1)
          break;
      }
      if (maxSeq > 0) {
        idAddDeferRanges.set(key, maxSeq);
        logger2.debug(`idAdd defer range for cmd_id=${toHex(cmdId)} base_id=${toHex(baseId)}: offsets 1\u2013${maxSeq}`);
      }
    }
  }
  const busChSeen = /* @__PURE__ */ new Map();
  for (const { cmd_id, id, busCh } of parsed) {
    if (busCh === void 0)
      continue;
    const key = `${cmd_id}_${id}`;
    if (!busChSeen.has(key))
      busChSeen.set(key, /* @__PURE__ */ new Set());
    busChSeen.get(key).add(busCh);
  }
  for (const { cmd_id, id, busCh, valueBytes } of parsed) {
    const existingExact = out.cmdSchema.find((a) => a.cmd_id === cmd_id && a.id === id);
    if (existingExact) {
      const opt = existingExact.options?.find((o) => o.id === "value");
      if (opt)
        opt.default = valueBytesToOption(valueBytes).default;
      const seenBusChValues = busChSeen.get(`${cmd_id}_${id}`);
      if (seenBusChValues && seenBusChValues.size > 0) {
        const maxBusCh = Math.max(...seenBusChValues);
        const hasBusChOption = existingExact.options?.some((o) => o.id === "busCh");
        if (maxBusCh === 0 && existingExact.busCh === void 0 && !hasBusChOption) {
          existingExact.busCh = 0;
          logger2.info(`Synced busCh=0 onto existing entry cmd_id=${toHex(cmd_id)} id=${toHex(id)}`);
        }
      }
      continue;
    }
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt = a.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        return false;
      if (id <= a.id)
        return false;
      const offset = id - a.id;
      return candidates.some((c) => {
        const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === a.id);
        const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
        return refIdAdd?.choices?.some((ch) => ch.id === offset);
      });
    });
    if (idAddBase) {
      const offset = id - idAddBase.id;
      const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
      if (idAddOpt?.choices && !idAddOpt.choices.some((c) => c.id === offset)) {
        let label = `Channel ${offset + 1}`;
        for (const c of candidates) {
          const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
          const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
          const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
          if (refChoice) {
            label = refChoice.label;
            break;
          }
        }
        idAddOpt.choices.push({ id: offset, label });
        logger2.info(`Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
      }
      continue;
    }
    let action;
    for (const c of candidates) {
      const match = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === id);
      if (match) {
        action = structuredClone(match);
        const baseName = match.name.replace(/\s*\(inferred from Model [^)]+\)/g, "").trim();
        action.name = `${baseName} (inferred from Model ${c.model})`;
        logger2.info(`Inferred cmd_id=${toHex(cmd_id)} id=${toHex(id)} from Model ${c.model} (exact)`);
        break;
      }
    }
    if (!action) {
      let shouldDefer = false;
      for (const c of candidates) {
        const baseEntry = c.cmdSchema?.find((a) => {
          if (a.cmd_id !== cmd_id)
            return false;
          const idAddOpt = a.options?.find((o) => o.id === "idAdd");
          if (!idAddOpt?.choices)
            return false;
          if (id <= a.id)
            return false;
          const offset = id - a.id;
          const maxSeq = idAddDeferRanges.get(`${cmd_id}_${a.id}`) ?? 0;
          return offset <= maxSeq;
        });
        if (baseEntry) {
          shouldDefer = true;
          logger2.debug(`cmd_id=${toHex(cmd_id)} id=${toHex(id)} is an idAdd offset of candidate base id=${toHex(baseEntry.id)} \u2014 deferring to pass 2`);
          break;
        }
      }
      if (shouldDefer)
        continue;
    }
    if (!action) {
      action = {
        cmd_id,
        id,
        name: `Unknown cmd:${toHex(cmd_id)} id:${toHex(id).toUpperCase()}`,
        options: [valueBytesToOption(valueBytes)]
      };
      if (busCh !== void 0)
        action.busCh = busCh;
      logger2.warn(`Could not infer cmd_id=${toHex(cmd_id)} id=${toHex(id)}`);
    } else {
      action.options = action.options?.filter((o) => o.id !== "busCh") ?? [];
      delete action.busCh;
      const seenBusChValues = busChSeen.get(`${cmd_id}_${id}`);
      if (seenBusChValues && seenBusChValues.size > 0) {
        const maxBusCh = Math.max(...seenBusChValues);
        if (maxBusCh === 0) {
          action.busCh = 0;
        } else {
          const busChChoices = Array.from({ length: maxBusCh + 1 }, (_, i) => ({
            id: i,
            label: `Channel ${i + 1}`
          }));
          action.options.unshift({
            id: "busCh",
            label: "Channel",
            type: "dropdown",
            choices: busChChoices,
            default: 0
          });
        }
      }
      const observedDefault = valueBytesToOption(valueBytes).default;
      const valueOpt = action.options?.find((o) => o.id === "value");
      if (valueOpt) {
        if (valueOpt.choices && Array.isArray(valueOpt.choices)) {
          const inChoices = valueOpt.choices.some((c) => c.id === observedDefault);
          if (!inChoices) {
            logger2.warn(`Inferred choices for cmd_id=${toHex(cmd_id)} id=${toHex(id)} don't contain observed value ${observedDefault} \u2014 discarding inherited choices`);
            valueOpt.type = "number";
            delete valueOpt.choices;
          }
        }
        valueOpt.default = observedDefault;
      }
    }
    out.cmdSchema.push(action);
  }
  for (const { cmd_id, id } of parsed) {
    const alreadyTopLevel = out.cmdSchema.some((a) => a.cmd_id === cmd_id && a.id === id);
    if (alreadyTopLevel)
      continue;
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt2 = a.options?.find((o) => o.id === "idAdd");
      return !!idAddOpt2?.choices && id > a.id;
    });
    if (!idAddBase)
      continue;
    const offset = id - idAddBase.id;
    const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
    if (!idAddOpt?.choices || idAddOpt.choices.some((c) => c.id === offset))
      continue;
    const refHasOffset = candidates.some((c) => {
      const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      return refIdAdd?.choices?.some((ch) => ch.id === offset);
    });
    const existingOffsets = idAddOpt.choices.map((c) => c.id).sort((a, b) => a - b);
    const isSequential = existingOffsets.length > 0 && offset === existingOffsets[existingOffsets.length - 1] + 1;
    if (!refHasOffset && !isSequential)
      continue;
    let label = `Channel ${offset + 1}`;
    for (const c of candidates) {
      const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
      if (refChoice) {
        label = refChoice.label;
        break;
      }
    }
    idAddOpt.choices.push({ id: offset, label });
    logger2.info(`Pass 2: Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
  }
  return out;
}
function saveModelJsonPretty(filePath, jsonObj) {
  try {
    const orderedObj = { model: jsonObj.model };
    if ("sectioned" in jsonObj) {
      orderedObj.sectioned = jsonObj.sectioned;
    }
    if ("cmdSchema" in jsonObj) {
      orderedObj.cmdSchema = jsonObj.cmdSchema.map((entry) => {
        const orderedEntry = {};
        if ("cmd_id" in entry)
          orderedEntry.cmd_id = entry.cmd_id;
        if ("id" in entry)
          orderedEntry.id = entry.id;
        if ("busCh" in entry)
          orderedEntry.busCh = entry.busCh;
        if ("name" in entry)
          orderedEntry.name = entry.name;
        if ("options" in entry)
          orderedEntry.options = entry.options;
        for (const key of Object.keys(entry)) {
          if (!(key in orderedEntry))
            orderedEntry[key] = entry[key];
        }
        return orderedEntry;
      });
    }
    for (const key of Object.keys(jsonObj)) {
      if (!(key in orderedObj)) {
        orderedObj[key] = jsonObj[key];
      }
    }
    let json = JSON.stringify(orderedObj, null, 2);
    json = json.replace(/\{\n\s+"id":\s*(\d+),\n\s+"label":\s*"([^"]*)"\n\s+\}/g, '{ "id": $1, "label": "$2" }');
    fs2.writeFileSync(filePath, json + "\n", "utf8");
  } catch (e) {
    logger2.error(`File Write Error: ${e}`);
  }
}

// dist/actions.js
var logger3 = createModuleLogger("Actions");
function UpdateActions(self) {
  const schemasRaw = getDeviceSchemas();
  const rawActions = buildActions();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredActions = {};
  const activeModel = self.activeModel;
  if (self.config.devMode) {
    wiredActions["global_getAllSettings"] = {
      name: "GLOBAL: Get All Settings",
      description: "Use this to create a schema for a new device",
      options: [],
      callback: async () => {
        const model = activeModel;
        const ip = self.host;
        const buf = await self.stController.requestAllSettings(ip);
        let modelJson = getDeviceSchema(model);
        const { settings: parsed, detectedSectioned } = parseGetAllSettingsWithDetection(model, buf);
        logger3.debug(`parsed reply: ${JSON.stringify(parsed)}`);
        if (!modelJson) {
          logger3.info(`Model ${model} has no schema \u2014 creating new JSON from settings`);
          modelJson = {
            model,
            sectioned: detectedSectioned ?? false,
            cmdSchema: []
          };
        } else if (detectedSectioned !== null) {
          logger3.info(`Auto-detected sectioned=${detectedSectioned}, adding to model JSON`);
          modelJson = { ...modelJson, sectioned: detectedSectioned };
        }
        const updated = updateModelJsonFromSettings(modelJson, parsed, schemas);
        logger3.debug(`new Actions json: ${JSON.stringify(updated, null, 2)}`);
        const devicesFolder2 = getDevicesFolder();
        const schemaPath = path2.join(devicesFolder2, `Model${model}.json`);
        saveModelJsonPretty(schemaPath, updated);
        reloadDeviceSchemas();
        logger3.info(`Model ${model} JSON auto-updated from getAllSettings`);
      }
    };
  }
  for (const [actionId, action] of Object.entries(rawActions)) {
    const { model, cmdId, baseId } = parseSettingId(actionId);
    if (model !== activeModel)
      continue;
    const schema = schemas[model];
    const rawAction = schema?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === baseId);
    wiredActions[actionId] = {
      ...action,
      callback: async (event) => {
        const ip = self.host;
        const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
        const value = event.options["value"];
        const idAdd = event.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        await self.stController.sendAwaitAck(cmdId, busCh, settingId, value, ip);
      }
    };
  }
  const activeSchema = schemas[activeModel];
  if (activeSchema) {
    const supportsMicKill = (activeSchema.cmdSchema ?? []).some((a) => a.name.includes("Kill"));
    if (supportsMicKill) {
      const actionId = `${activeModel}_micKill`;
      wiredActions[actionId] = {
        name: `[Model${activeModel}] Mic Kill`,
        options: [],
        callback: async () => {
          const ip = self.host;
          logger3.info(`Mic Kill \u2192 Model ${activeModel} @ ${ip}`);
          await self.stController.globalMicKill(ip);
          await self.stController.requestAllSettings(ip).catch((err) => {
            logger3.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
      };
    }
  }
  self.setActionDefinitions(wiredActions);
}

// dist/feedbacks.js
function getLabelForValue(schemas, model, cmdId, settingId, value) {
  const setting = findActionForSetting(schemas, model, cmdId, settingId);
  if (!setting || !Array.isArray(setting.options))
    return value;
  const valueOption = setting.options.find((opt) => opt.id === "value");
  if (!valueOption || !Array.isArray(valueOption.choices))
    return value;
  const choice = valueOption.choices.find((c) => c.id === value);
  return choice?.label ?? value;
}
function UpdateFeedbacks(self) {
  const schemasRaw = getDeviceSchemas();
  const rawFeedbacks = buildFeedbacks();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredFeedbacks = {};
  const activeModel = self.activeModel;
  for (const [feedbackId, feedback] of Object.entries(rawFeedbacks)) {
    const { model, cmdId, baseId } = parseSettingId(feedbackId);
    if (model !== activeModel)
      continue;
    wiredFeedbacks[feedbackId] = {
      ...feedback,
      callback: (feedbackEvent) => {
        const ip = self.host;
        const idAdd = feedbackEvent.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        let busCh = feedbackEvent.options["busCh"];
        if (busCh === void 0) {
          const schemaAction = findActionForSetting(schemas, model, cmdId, settingId);
          if (schemaAction?.busCh !== void 0) {
            busCh = schemaAction.busCh;
          }
        }
        if (busCh === void 0) {
          const rawAction = schemasRaw[model]?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === settingId);
          if (rawAction?.busCh !== void 0) {
            busCh = rawAction.busCh;
          }
        }
        const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
        if (feedbackId.endsWith("_bool")) {
          return current !== void 0 && current !== 0;
        }
        const showLabel = feedbackEvent.options["showLabel"] ?? false;
        if (showLabel && current !== void 0) {
          return getLabelForValue(schemas, model, cmdId, settingId, current);
        }
        return current ?? 0;
      }
    };
  }
  self.setFeedbackDefinitions(wiredFeedbacks);
}

// dist/stcontroller.js
import dgram2 from "dgram";
import os2 from "os";

// dist/dante.js
import dgram from "dgram";
import os from "os";
var logger4 = createModuleLogger("Dante");
var DANTE_MSG_INFO_REQUEST = 32;
var DANTE_MSG_INFO_RESPONSE = 368;
var DANTE_INFO_MIN_LEN = 204 + 64;
function buildDanteInfoRequest() {
  const buf = Buffer.alloc(32, 0);
  const seq = Math.floor(Math.random() * 65535);
  buf.writeUInt16BE(65535, 0);
  buf.writeUInt16BE(DANTE_MSG_INFO_REQUEST, 2);
  buf.writeUInt16BE(seq, 4);
  const mac = getFirstLocalMac();
  mac.copy(buf, 8);
  Buffer.from("Audinate", "ascii").copy(buf, 16);
  buf.writeUInt16BE(1849, 24);
  buf.writeUInt16BE(193, 26);
  buf.writeUInt32BE(1e6, 28);
  return buf;
}
function getFirstLocalMac() {
  try {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const addr of ifaces[name] ?? []) {
        if (!addr.internal && addr.family === "IPv4" && addr.mac && addr.mac !== "00:00:00:00:00:00") {
          return Buffer.from(addr.mac.split(":").map((h) => parseInt(h, 16)));
        }
      }
    }
  } catch {
  }
  return Buffer.alloc(6, 0);
}
function parseDanteInfoResponse(msg, srcIp) {
  if (msg.length < DANTE_INFO_MIN_LEN)
    return null;
  if (msg.readUInt16BE(0) !== 65535)
    return null;
  if (msg.readUInt16BE(2) !== DANTE_MSG_INFO_RESPONSE)
    return null;
  if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
    return null;
  const readStr = (offset, len) => msg.subarray(offset, offset + len).toString("ascii").split("\0")[0].trim();
  const eui64 = msg.subarray(8, 16);
  const macBytes = [eui64[0], eui64[1], eui64[2], eui64[5], eui64[6], eui64[7]];
  const mac = macBytes.map((b) => b.toString(16).padStart(2, "0")).join(":");
  const name = readStr(32, 31);
  const manufacturer = readStr(76, 64);
  const modelRaw = readStr(204, 64);
  const danteFirmware = `${msg[24]}.${msg[25]}`;
  if (!modelRaw)
    return null;
  const model = modelRaw.replace(/^Model\s+/i, "").trim().split(/\s+/)[0];
  return {
    ip: srcIp,
    name,
    manufacturer,
    model,
    modelName: modelRaw,
    // Full model description
    mac,
    danteFirmware
  };
}
async function getMacForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    tmp.once("error", (err) => {
      tmp.close();
      reject(new Error(err.message ?? String(err)));
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        tmp.close();
        const ifaces = os.networkInterfaces();
        for (const name of Object.keys(ifaces)) {
          for (const iface of ifaces[name] ?? []) {
            if (iface.family === "IPv4" && iface.address === localAddr && iface.mac && iface.mac !== "00:00:00:00:00:00") {
              return resolve(iface.mac.split(":").map((b) => parseInt(b, 16) & 255));
            }
          }
        }
        reject(new Error(`No interface found for local address ${localAddr}`));
      } catch (_e) {
        reject(new Error(String(_e)));
      }
    });
  });
}
async function getLocalAddressForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    let resolved = false;
    tmp.once("error", (err) => {
      if (!resolved) {
        resolved = true;
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      }
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        if (!resolved) {
          resolved = true;
          tmp.close();
          resolve(localAddr);
        }
      } catch (_e) {
        if (!resolved) {
          resolved = true;
          tmp.close();
          reject(new Error(String(_e)));
        }
      }
    });
  });
}
async function discoverDevices(txSocket, ensureMembership, timeoutMs = 5e3) {
  const DANTE_ANNOUNCE_GROUP = "224.0.0.233";
  const DANTE_ANNOUNCE_PORT = 8708;
  const DEFAULT_PORT = 8700;
  const queriedIps = /* @__PURE__ */ new Set();
  return new Promise((resolve) => {
    const announceSocket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const joinedInterfaces = [];
    const cleanup = () => {
      for (const iface of joinedInterfaces) {
        try {
          announceSocket.dropMembership(DANTE_ANNOUNCE_GROUP, iface);
        } catch {
        }
      }
      try {
        announceSocket.close();
      } catch {
      }
      resolve();
    };
    const timer = setTimeout(cleanup, timeoutMs);
    timer.unref?.();
    announceSocket.on("error", (err) => {
      logger4.warn(`Announce socket error: ${err.message}`);
    });
    announceSocket.on("message", (msg, rinfo) => {
      const srcIp = rinfo.address;
      if (msg.length < 24)
        return;
      if (msg.readUInt16BE(0) !== 65534)
        return;
      if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
        return;
      if (queriedIps.has(srcIp))
        return;
      queriedIps.add(srcIp);
      logger4.debug(`Announce from ${srcIp} \u2014 sending unicast query`);
      const sendQuery = async () => {
        await ensureMembership(srcIp);
        const query = buildDanteInfoRequest();
        txSocket.send(query, DEFAULT_PORT, srcIp, (err) => {
          if (err)
            logger4.warn(`Unicast query to ${srcIp} failed: ${err.message}`);
        });
      };
      sendQuery().catch((err) => logger4.warn(`Query setup failed: ${err}`));
    });
    announceSocket.bind(DANTE_ANNOUNCE_PORT, () => {
      const ifaces = os.networkInterfaces();
      for (const addrs of Object.values(ifaces)) {
        for (const addr of addrs ?? []) {
          if (addr.family === "IPv4" && !addr.internal) {
            try {
              announceSocket.addMembership(DANTE_ANNOUNCE_GROUP, addr.address);
              joinedInterfaces.push(addr.address);
            } catch {
            }
          }
        }
      }
      if (joinedInterfaces.length === 0) {
        logger4.warn(`Could not join announce multicast group on any interface`);
      } else {
        logger4.info(`Listening for Dante announces on ${DANTE_ANNOUNCE_GROUP}:${DANTE_ANNOUNCE_PORT}`);
      }
    });
  });
}
var _conmonPending = /* @__PURE__ */ new Map();
async function openConMonSession(deviceIp, timeoutMs = 3e3) {
  const pending = _conmonPending.get(deviceIp);
  if (pending)
    return pending;
  const promise = _doConMonSession(deviceIp, timeoutMs).finally(() => {
    _conmonPending.delete(deviceIp);
  });
  _conmonPending.set(deviceIp, promise);
  return promise;
}
async function _doConMonSession(deviceIp, timeoutMs) {
  return new Promise((resolve) => {
    let settled = false;
    let keepaliveTimer = null;
    const closeSession = (sock2) => {
      if (keepaliveTimer) {
        clearInterval(keepaliveTimer);
        keepaliveTimer = null;
      }
      try {
        sock2.close();
      } catch {
      }
      logger4.debug(`ConMon session closed for ${deviceIp}`);
    };
    const fail = (sock2) => {
      if (settled)
        return;
      settled = true;
      clearTimeout(timer);
      closeSession(sock2);
      logger4.debug(`ConMon session not established for ${deviceIp} \u2014 device may not require it`);
      resolve(null);
    };
    const sock = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const timer = setTimeout(() => fail(sock), timeoutMs);
    sock.on("error", (err) => {
      logger4.warn(`ConMon socket error for ${deviceIp}: ${err.message}`);
      fail(sock);
    });
    sock.on("message", (msg) => {
      if (!settled && msg.length >= 4 && msg[0] === 18 && msg[3] === 32) {
        settled = true;
        clearTimeout(timer);
        logger4.info(`ConMon session established with ${deviceIp}`);
        let keepaliveSeq = Math.floor(Math.random() * 65534) + 1;
        const sendKeepalive = () => {
          const pkt = Buffer.alloc(20, 0);
          pkt[0] = 18;
          pkt[3] = 78;
          pkt.writeUInt16BE(keepaliveSeq++ & 65535, 4);
          pkt[6] = 48;
          pkt[7] = 16;
          sock.send(pkt, 8800, deviceIp, () => {
          });
        };
        keepaliveTimer = setInterval(sendKeepalive, 1e3);
        resolve(() => closeSession(sock));
      }
    });
    const doInit = async () => {
      let localIp;
      let localMac;
      try {
        localIp = await getLocalAddressForDestination(deviceIp);
        localMac = await getMacForDestination(deviceIp);
      } catch (e) {
        logger4.warn(`ConMon: could not get local network info for ${deviceIp}: ${e}`);
        fail(sock);
        return;
      }
      sock.bind({ port: 8800, address: localIp }, () => {
        const seq = Math.floor(Math.random() * 65534) + 1;
        const pkt = Buffer.alloc(20, 0);
        pkt[0] = 18;
        pkt[3] = 20;
        pkt.writeUInt16BE(seq, 4);
        pkt[6] = 16;
        pkt[7] = 1;
        localMac.forEach((b, i) => {
          pkt[12 + i] = b;
        });
        logger4.debug(`ConMon TX to ${deviceIp}: ${pkt.toString("hex")}`);
        sock.send(pkt, 8800, deviceIp, (err) => {
          if (err) {
            logger4.warn(`ConMon send failed for ${deviceIp}: ${err.message}`);
            fail(sock);
          }
        });
      });
    };
    doInit().catch((e) => {
      logger4.warn(`ConMon init failed for ${deviceIp}: ${e}`);
      fail(sock);
    });
  });
}
async function probeDevice(txSocket, registerListener, removeListener, ensureMembership, ip, timeoutMs = 3e3) {
  return new Promise((resolve) => {
    const key = `__probe_${ip}__`;
    let resolved = false;
    const finish = (result) => {
      if (resolved)
        return;
      resolved = true;
      removeListener(key);
      resolve(result);
    };
    registerListener(key, (device) => {
      if (device.ip === ip)
        finish(device);
    });
    const timer = setTimeout(() => finish(null), timeoutMs);
    timer.unref?.();
    const run = async () => {
      await ensureMembership(ip);
      const query = buildDanteInfoRequest();
      txSocket.send(query, 8700, ip, (err) => {
        if (err) {
          logger4.warn(`Probe to ${ip} failed: ${err.message}`);
          clearTimeout(timer);
          finish(null);
        }
      });
    };
    run().catch((e) => {
      logger4.warn(`probeDevice setup failed for ${ip}: ${e}`);
      clearTimeout(timer);
      finish(null);
    });
  });
}

// dist/stcontroller.js
var logger5 = createModuleLogger("StController");
var StController = class _StController {
  defaultPort = 8700;
  multicastGroup = "224.0.0.231";
  rxPort = 8702;
  txSocket;
  rxSocket;
  // for receiving responses (8702)
  pendingAcks = /* @__PURE__ */ new Map();
  joinedInterfaces = /* @__PURE__ */ new Set();
  // local IPs we've joined multicast on
  /** Serializes outgoing commands so each waits for ACK before the next is sent */
  sendQueue = Promise.resolve();
  /** Tracks how many commands are queued/in-flight, to defer requestAllSettings */
  pendingCommandCount = 0;
  /** Resolves once txSocket is bound and ready to send */
  txReady;
  /** Active device model and action definitions for settings decoding */
  model = "";
  actions = [];
  /**
   * Known state of every setting per device IP.
   * Keyed by IP → Map of "${cmdId}/${settingId}" → current value byte.
   * Populated on connect via requestAllSettings(), updated on every CMD_SETTINGS_PUSH (0x0b).
   * Used to diff incoming pushes (changed = info, unchanged = debug) and for feedbacks.
   */
  deviceState = /* @__PURE__ */ new Map();
  /**
   * IPs that have been verified against the configured model and are allowed
   * to receive Studio-T commands. Populated by authorizeDevice() after a
   * successful probeDevice() model match, or after multicast discovery.
   * _sendAwaitAck() rejects any destIp not in this set.
   */
  authorizedIps = /* @__PURE__ */ new Set();
  /** Callbacks registered for Dante 0x0170 device info responses — keyed by usage */
  discoveryListeners = /* @__PURE__ */ new Map();
  /** Callback to trigger feedback updates when state changes */
  feedbackCallback;
  /** Cache of local interface MAC bytes per destination IP, to avoid repeated OS lookups */
  macCache = /* @__PURE__ */ new Map();
  /** IPs for which a Dante ConMon (port 8800) session has been successfully opened */
  sessionEstablished = /* @__PURE__ */ new Set();
  /** Cleanup functions returned by openConMonSession() — call to stop keepalives and close the socket */
  _conmonCleanups = /* @__PURE__ */ new Map();
  constructor() {
    logger5.info("StController initialized");
    this.txSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.txReady = new Promise((resolve) => {
      this.txSocket.bind(0, () => {
        logger5.debug(`TX socket bound to port ${this.txSocket.address().port}`);
        resolve();
      });
    });
    this.txSocket.on("error", (err) => {
      logger5.error(`TX socket error: ${err}`);
    });
    this.rxSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.rxSocket.on("listening", () => {
      const addr = this.rxSocket.address();
      logger5.debug(`RX socket listening on ${JSON.stringify(addr)}`);
      try {
        this.rxSocket.setMulticastLoopback(true);
      } catch (_e) {
      }
    });
    this.rxSocket.on("error", (err) => {
      logger5.error(`RX socket error: ${err}`);
    });
    this.rxSocket.on("message", (msg, rinfo) => {
      try {
        this.handleIncoming(msg, rinfo.address);
      } catch (_e) {
        logger5.error(`Error handling incoming message: ${_e}`);
      }
    });
    this.rxSocket.bind({ address: "0.0.0.0", port: this.rxPort }, () => {
      logger5.debug(`RX socket bound to 0.0.0.0:${this.rxPort}`);
      const ifaces = os2.networkInterfaces();
      for (const addrs of Object.values(ifaces)) {
        for (const addr of addrs ?? []) {
          if (addr.family === "IPv4" && !addr.internal && !this.joinedInterfaces.has(addr.address)) {
            try {
              this.rxSocket.addMembership(this.multicastGroup, addr.address);
              this.joinedInterfaces.add(addr.address);
              logger5.info(`Pre-joined multicast ${this.multicastGroup} on ${addr.address}`);
            } catch (_e) {
              logger5.warn(`Could not pre-join multicast on ${addr.address}: ${String(_e)}`);
            }
          }
        }
      }
    });
  }
  close() {
    for (const cleanup of this._conmonCleanups.values()) {
      try {
        cleanup();
      } catch {
      }
    }
    this._conmonCleanups.clear();
    try {
      for (const localAddr of Array.from(this.joinedInterfaces)) {
        try {
          this.rxSocket.dropMembership(this.multicastGroup, localAddr);
        } catch {
        }
      }
    } catch {
    }
    try {
      this.rxSocket.close();
    } catch {
    }
    try {
      this.txSocket.close();
    } catch {
    }
  }
  /**
   * Provide the active device model and action definitions so incoming messages
   * can be decoded into human-readable names. Call from main.ts after config load.
   */
  setModel(model, actions) {
    this.model = model;
    this.actions = actions;
  }
  /**
   * Set callback to trigger when device state changes (for feedbacks).
   * Call from main.ts to wire up checkFeedbacks.
   */
  setFeedbackCallback(callback) {
    this.feedbackCallback = callback;
  }
  /** Returns true if the device at the given IP has been authorized to receive commands. */
  isDeviceAuthorized(ip) {
    return this.authorizedIps.has(ip);
  }
  /** Mark an IP as verified and allowed to receive Studio-T commands. */
  authorizeDevice(ip) {
    this.authorizedIps.add(ip);
    logger5.debug(`Authorized device at ${ip}`);
  }
  /** Remove authorization for an IP (e.g. on config change or model mismatch). */
  revokeDevice(ip) {
    this.authorizedIps.delete(ip);
    this.deviceState.delete(ip);
    this.macCache.delete(ip);
    this.sessionEstablished.delete(ip);
    this._conmonCleanups.get(ip)?.();
    this._conmonCleanups.delete(ip);
    logger5.debug(`Revoked device at ${ip}`);
  }
  /**
   * Opens a Dante ConMon session for the device. Caches the result so the
   * handshake only runs once per IP. Delegates to dante.ts openConMonSession().
   */
  async openSession(deviceIp) {
    if (this.sessionEstablished.has(deviceIp))
      return true;
    const cleanup = await openConMonSession(deviceIp);
    const success = cleanup !== null;
    this.sessionEstablished.add(deviceIp);
    if (success) {
      this._conmonCleanups.set(deviceIp, cleanup);
    }
    return success;
  }
  /**
   * Sends a unicast Dante info request to a specific IP and waits for the
   * device info response. Returns the DeviceInfo if the device responds within
   * timeoutMs, or null if no response. Used to verify a manually configured IP.
   * Does NOT require authorization — this is how authorization is established.
   */
  async probeDevice(ip, timeoutMs = 3e3) {
    await this.txReady;
    return probeDevice(this.txSocket, (key, cb) => this.discoveryListeners.set(key, cb), (key) => this.discoveryListeners.delete(key), async (destIp) => this.ensureMembershipFor(destIp), ip, timeoutMs);
  }
  /**
   * Send a CMD_GET_ALL_SETTINGS (0x0a) request to the device and store the response
   * in deviceState. Returns the raw response buffer for parsing.
   */
  async requestAllSettings(deviceIp) {
    logger5.info(`Requesting all settings from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_ALL_SETTINGS, void 0, void 0, void 0, deviceIp, false);
    return response;
  }
  /**
   * Discovers Studio Technologies Dante devices on the local network.
   *
   * Listens for Dante announces on 224.0.0.233:8708, sends unicast info requests
   * to each discovered IP, and collects 0x0170 responses via the rxSocket.
   */
  async discoverDevices(timeoutMs = 5e3) {
    const DISCOVERY_KEY = "__discovery__";
    const foundDevices = [];
    this.discoveryListeners.set(DISCOVERY_KEY, (device) => {
      if (!foundDevices.some((d) => d.ip === device.ip)) {
        foundDevices.push(device);
      }
    });
    try {
      await this.txReady;
      await discoverDevices(this.txSocket, async (destIp) => this.ensureMembershipFor(destIp), timeoutMs);
      return foundDevices;
    } finally {
      this.discoveryListeners.delete(DISCOVERY_KEY);
    }
  }
  /**
   * Requests device firmware version via Studio-T protocol (CMD_GET_FIRMWARE).
   * Returns the firmware version string (e.g., "3.01", "2.2", "1.05").
   */
  async requestFirmwareVersion(deviceIp) {
    logger5.info(`Requesting firmware version from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_FIRMWARE, void 0, void 0, void 0, deviceIp, false);
    const dataStart = 26;
    if (response.length < dataStart + 3) {
      logger5.warn(`Firmware response too short: ${response.length} bytes`);
      return "Unknown";
    }
    const major = response[dataStart + 1];
    const minor = response[dataStart + 2];
    const minorStr = minor < 10 ? minor.toString().padStart(2, "0") : minor.toString();
    const firmware = `${major}.${minorStr}`;
    logger5.info(`Firmware version: ${firmware}`);
    return firmware;
  }
  /**
   * Joins the multicast response group on the interface that routes to destIp.
   * Only joins the specific interface used to reach the device, and only once per interface.
   */
  async ensureMembershipFor(destIp) {
    try {
      const localAddr = await getLocalAddressForDestination(destIp);
      if (!localAddr) {
        logger5.warn(`Could not determine local address for destination ${destIp}`);
        return;
      }
      if (this.joinedInterfaces.has(localAddr)) {
        return;
      }
      try {
        this.rxSocket.addMembership(this.multicastGroup, localAddr);
        this.joinedInterfaces.add(localAddr);
        logger5.info(`Joined multicast ${this.multicastGroup} on ${localAddr}`);
      } catch (_e) {
        logger5.warn(`Failed to join multicast on ${localAddr}: ${String(_e)}`);
      }
    } catch (_e) {
      logger5.warn(`ensureMembershipFor failed: ${_e}`);
    }
  }
  async sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    this.pendingCommandCount++;
    return new Promise((resolve, reject) => {
      this.sendQueue = this.sendQueue.then(async () => this._sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen).then((buf) => {
        this.pendingCommandCount--;
        if (this.pendingCommandCount === 0 && value !== void 0) {
          this.requestAllSettings(destIp).catch((err) => {
            logger5.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
        resolve(buf);
      }).catch((err) => {
        this.pendingCommandCount--;
        reject(err instanceof Error ? err : new Error(String(err)));
      }));
    });
  }
  async _sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    const timeoutMs = 2e3;
    const dataBlock = [];
    if (settingId !== void 0)
      dataBlock.push(settingId & 255);
    if (value !== void 0)
      dataBlock.push(..._StController.buildValueBytes(value));
    const payloadBody = [90, cmdId & 255];
    if (cmdId === CMD_MIC_PRE && busCh !== void 0 && settingId !== void 0 && value !== void 0) {
      if (!this.deviceState.has(destIp))
        this.deviceState.set(destIp, /* @__PURE__ */ new Map());
      const ipState = this.deviceState.get(destIp);
      const numPositions = 3;
      const positions = [];
      for (let i = 0; i < numPositions; i++) {
        const stateKey = makeSettingId(this.model, CMD_MIC_PRE, i, busCh);
        const val = i === settingId ? Number(value) : ipState.get(stateKey) ?? 0;
        positions.push(val);
        ipState.set(stateKey, val);
      }
      payloadBody.push(busCh & 255, ...positions);
    } else {
      if (busCh !== void 0)
        payloadBody.push(busCh & 255);
      if (addLen)
        payloadBody.push(dataBlock.length);
      if (dataBlock.length > 0)
        payloadBody.push(...dataBlock);
    }
    const crc = _StController.crc8DvbS2(payloadBody);
    const payloadWithCrc = Buffer.from([...payloadBody, crc]);
    if (settingId !== void 0 && value !== void 0) {
      const valueBytes = _StController.buildValueBytes(value);
      const setting = {
        cmd_id: cmdId,
        id: settingId,
        busCh,
        valueBytes
      };
      logger5.info(`TX ${destIp} | ${formatParsedSetting(setting, this.actions)}`);
    } else {
      logger5.info(`TX ${destIp} | ${getCommandName(cmdId)}`);
    }
    if (!this.authorizedIps.has(destIp)) {
      logger5.debug(`Packet (not sent \u2014 device not authorized) to ${destIp}: ${payloadWithCrc.toString("hex")}`);
      throw new Error(`Device at ${destIp} is not authorized \u2014 verify the IP and model match before sending commands`);
    }
    if (!this.sessionEstablished.has(destIp)) {
      await this.openSession(destIp);
    }
    await this.ensureMembershipFor(destIp);
    const totalLen = 24 + payloadWithCrc.length;
    const header = await this.buildHeader(totalLen, destIp);
    const packet = Buffer.concat([header, payloadWithCrc]);
    logger5.debug(`Sending packet to ${destIp}: ${packet.toString("hex")}`);
    const key = `${destIp}:${cmdId}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingAcks.delete(key);
        reject(new Error(`Timeout waiting for ACK from Model ${this.model} at ${destIp}:8700`));
      }, timeoutMs);
      this.pendingAcks.set(key, {
        resolve: (buf) => {
          clearTimeout(timer);
          resolve(buf);
        },
        reject: (err) => {
          clearTimeout(timer);
          reject(err);
        },
        timer
      });
      this.txSocket.send(packet, this.defaultPort, destIp, (err) => {
        if (err) {
          this.pendingAcks.delete(key);
          clearTimeout(timer);
          reject(new Error(err.message ?? String(err)));
        }
      });
    });
  }
  handleIncoming(msg, srcIp) {
    if (msg.length < 4)
      return;
    if (msg[0] !== 255 || msg[1] !== 255)
      return;
    const msgType = msg.readUInt16BE(2);
    if (msgType === DANTE_MSG_INFO_RESPONSE && this.discoveryListeners.size > 0) {
      const device = parseDanteInfoResponse(msg, srcIp);
      if (device) {
        logger5.debug(`Dante info response from ${srcIp}: DeviceID="${device.name}", Model="${device.model}", ModelName="${device.modelName}", Manufacturer="${device.manufacturer}"`);
        if (device.name === "Studio-T") {
          for (const cb of this.discoveryListeners.values()) {
            try {
              cb(device);
            } catch {
            }
          }
        } else {
          logger5.debug(`Ignoring non-Studio Technologies device: DeviceID="${device.name}" @ ${srcIp}`);
        }
      }
      return;
    }
    if (msg.length < 25)
      return;
    const sig = msg.subarray(16, 24);
    if (sig.toString("ascii") !== "Studio-T")
      return;
    if (!this.authorizedIps.has(srcIp)) {
      logger5.debug(`Ignoring Studio-T packet from unauthorized device ${srcIp}`);
      return;
    }
    const stPayload = msg.subarray(24);
    if (stPayload.length < 2)
      return;
    if (stPayload[0] !== 90)
      return;
    const respCmdId = stPayload[1];
    const isResponse = (respCmdId & 128) !== 0;
    const originalCmdId = respCmdId & 127;
    if (isResponse && originalCmdId === CMD_GET_ALL_SETTINGS) {
      logger5.debug(`Received packet from ${srcIp}: ${msg.toString("hex")}`);
    }
    this.logStPayload(srcIp, originalCmdId, msg, stPayload);
    if (isResponse) {
      const key = `${srcIp}:${originalCmdId}`;
      const pending = this.pendingAcks.get(key);
      if (pending) {
        this.pendingAcks.delete(key);
        pending.resolve(msg);
      }
    }
  }
  /**
   * Decodes and logs a Studio-T response payload.
   * Receives both the full msg (for parsers that need the Studio-T header)
   * and stPayload (msg.subarray(24), for direct byte access).
   *
   * stPayload layout:
   *   [0]      0x5a  magic
   *   [1]      cmdId | 0x80
   *   [2..-2]  data bytes
   *   [-1]     CRC-8/DVB-S2
   */
  logStPayload(srcIp, cmdId, msg, stPayload) {
    const cmdName = getCommandName(cmdId);
    const data = stPayload.subarray(2, stPayload.length - 1);
    const respCmdId = stPayload[1];
    const crc = stPayload[stPayload.length - 1];
    const fullStructure = `[cmd:${toHex(respCmdId)} data:${data.toString("hex")} crc:${toHex(crc)}]`;
    if (cmdId === CMD_GET_ALL_SETTINGS || cmdId === CMD_SETTINGS_PUSH) {
      if (!this.model) {
        logger5.info(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
        return;
      }
      try {
        const settings = cmdId === CMD_SETTINGS_PUSH ? parseSettingsResponse(this.model, msg) : parseGetAllSettingsForModel(this.model, msg);
        const prevState = this.deviceState.get(srcIp) ?? /* @__PURE__ */ new Map();
        const newState = new Map(prevState);
        for (const s of settings) {
          const stateKey = makeSettingId(this.model, s.cmd_id, s.id, s.busCh);
          const newValue = s.valueBytes.length === 3 ? s.valueBytes[0] << 16 | s.valueBytes[1] << 8 | s.valueBytes[2] : s.valueBytes[0] ?? 0;
          const prevValue = prevState.get(stateKey);
          const changed = prevValue === void 0 || prevValue !== newValue;
          newState.set(stateKey, newValue);
          const formatted = formatParsedSetting(s, this.actions);
          if (changed) {
            logger5.info(`RX ${srcIp} | ${formatted}`);
            if (this.feedbackCallback) {
              let baseId = s.id;
              const baseAction = this.actions.find((a) => {
                if (a.cmd_id !== s.cmd_id)
                  return false;
                if (a.id === s.id)
                  return true;
                const idAddOption = a.options?.find((o) => o.id === "idAdd");
                if (!idAddOption?.choices)
                  return false;
                const offset = s.id - a.id;
                return offset > 0 && idAddOption.choices.some((c) => c.id === offset);
              });
              if (baseAction)
                baseId = baseAction.id;
              const baseFeedbackKey = makeSettingId(this.model, s.cmd_id, baseId);
              this.feedbackCallback(baseFeedbackKey);
              this.feedbackCallback(baseFeedbackKey + "_bool");
            } else {
              logger5.warn(`feedbackCallback not set \u2014 skipping feedback update for ${stateKey}`);
            }
          } else {
            logger5.debug(`RX ${srcIp} | ${formatted}`);
          }
        }
        this.deviceState.set(srcIp, newState);
      } catch (e) {
        logger5.warn(`RX ${srcIp} | ${cmdName} | parse failed: ${e} | ${fullStructure}`);
      }
      return;
    }
    const decoded = this.decodeStData(cmdId, data);
    const logFn = cmdId === CMD_BUS_GET ? logger5.debug.bind(logger5) : logger5.info.bind(logger5);
    if (decoded) {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure} | ${decoded}`);
    } else {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
    }
  }
  /**
   * Attempts to decode the data bytes of a Studio-T response into a
   * human-readable string. Returns null to fall back to raw hex.
   */
  decodeStData(cmdId, data) {
    if (data.length === 0)
      return "ACK";
    if (data.length === 1) {
      if (data[0] === 0) {
        return "ACK ok";
      } else {
        return `ERROR ${toHex(data[0])}`;
      }
    }
    switch (cmdId) {
      // ── CMD_MIC_PRE (0x02): raw preamp echo — positional bytes, no setting IDs ──
      // Device echoes [busCh][val0][val1]... confirming the applied values.
      case CMD_MIC_PRE: {
        const busCh = data[0];
        const vals = Array.from(data.subarray(1)).map((b, i) => `[${i}]=0x${b.toString(16).padStart(2, "0")}(${b})`).join(" ");
        return `ch=${busCh} ${vals}`;
      }
      // ── CMD_DEV_SPEC (0x0d): single-byte ACK or echo of applied setting ──
      // Device sends two CMD_DEV_SPEC packets in response to a set:
      //   1. ACK:  [status]               (1 byte, 0x00 = ok)
      //   2. Echo: [busCh] [settingId] [value...]  (confirming what was applied)
      case CMD_DEV_SPEC: {
        if (data.length === 1) {
          return data[0] === 0 ? "ACK ok" : `ACK err=${toHex(data[0])}`;
        }
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const choices = action?.options?.[0]?.choices;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ? `${choiceLabel} (${toHex(valueNum)})` : bytesToHex(Array.from(valueBytes));
          const rawTag = `[${toHex(cmdId)}/${toHex(settingId)}]=${bytesToHex(Array.from(valueBytes))}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr} ${rawTag}`;
        }
        return `raw: ${data.toString("hex")}`;
      }
      // ── CMD_MIC_PRE_BUS (0x12): Multi-byte echo responses ─────────────
      case CMD_MIC_PRE_BUS: {
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choices = action?.options?.find((o) => o.id === "value")?.choices;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ?? `0x${valueBytes.toString("hex")}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr}`;
        }
        return null;
      }
      // ── Bus-scoped get/set ────────────────────────────────────────────
      case CMD_BUS_GET:
      case CMD_BUS_SET: {
        if (data.length < 2)
          return null;
        const busCh = data[0];
        const settingId = data[1];
        const value = data.subarray(2);
        return `ch=${busCh} setting=${toHex(settingId)} value=${value.toString("hex")}`;
      }
      default:
        return null;
    }
  }
  static buildValueBytes(value) {
    if (typeof value === "boolean")
      return [value ? 1 : 0];
    if (Array.isArray(value))
      return value.map((v) => Number(v) & 255);
    if (typeof value === "number") {
      if (value > 255)
        return [value >> 16 & 255, value >> 8 & 255, value & 255];
      return [value & 255];
    }
    throw new Error(`Unsupported value type for STcontroller: ${value}`);
  }
  async buildHeader(totalLen, destIp) {
    let mac = this.macCache.get(destIp);
    if (!mac) {
      mac = await getMacForDestination(destIp);
      this.macCache.set(destIp, mac);
    }
    return Buffer.concat([
      Buffer.from([255, 255, 0, totalLen & 255, 7, 225, 0, 0, ...mac, 0, 0]),
      Buffer.from("Studio-T", "utf8")
    ]);
  }
  static crc8DvbS2(data) {
    let crc = 0;
    for (const b of data) {
      crc ^= b;
      for (let i = 0; i < 8; i++) {
        crc = (crc & 128) !== 0 ? (crc << 1 ^ 213) & 255 : crc << 1 & 255;
      }
    }
    return crc;
  }
  /**
   * Returns the current known value for a setting on a device, or undefined if unknown.
   * Use for feedbacks — value is updated on every CMD_SETTINGS_PUSH (0x0b) from the device.
   *
   * @param ip        Device IP address
   * @param cmdId     Command ID (e.g. CMD_DEV_SPEC)
   * @param settingId Setting ID (e.g. 0x02 for Control Source)
   * @param busCh     Optional bus/channel ID for multi-channel commands
   */
  getSettingValue(ip, cmdId, settingId, busCh) {
    const key = makeSettingId(this.model, cmdId, settingId, busCh);
    return this.deviceState.get(ip)?.get(key);
  }
  async resetDevice(destIp) {
    return this.sendAwaitAck(CMD_RESET_DEVICE, void 0, 0, void 0, destIp, false);
  }
  async globalMicKill(destIp) {
    return this.sendAwaitAck(CMD_GLOBAL_MIC_KILL, void 0, void 0, void 0, destIp, false);
  }
};

// dist/main.js
var logger6 = createModuleLogger("ModuleInstance");
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  stController;
  /** Cached discovery results — passed into getConfigFields() so the UI
   *  can show the discovered device dropdown on subsequent config opens. */
  discoveredDevices = [];
  /** Currently active model — resolved once in syncModel() and cached here
   *  so UpdateActions, UpdateFeedbacks etc. don't each call resolveModel independently. */
  activeModel = "";
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    if (!this.stController) {
      this.stController = new StController();
    }
    this.updateStatus(InstanceStatus.Connecting, "Discovering devices...");
    this.stController.setFeedbackCallback((feedbackId) => {
      this.checkFeedbacks(feedbackId);
    });
    this.runDiscovery().catch((e) => {
      logger6.error(`Discovery failed: ${e}`);
    });
  }
  /**
   * Run device discovery, then resolve the model and update all UI.
   * - If discovery finds devices, resolveModel picks from those.
   * - Only if the list is empty do we fall back to the manual config selection.
   * All actions/feedbacks/variables are built after the model is known.
   */
  async runDiscovery() {
    logger6.info("Starting device discovery...");
    this.discoveredDevices = await this.stController.discoverDevices();
    let effectiveModel;
    if (this.discoveredDevices.length === 0) {
      if (this.config.deviceMac) {
        const modelLabel = this.config.activeModel ? `Model ${this.config.activeModel} ` : "";
        logger6.warn(`Saved device MAC "${this.config.deviceMac}" not found during discovery \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `${modelLabel}[${this.config.deviceMac}] not found`);
        return;
      }
      const manualModel = this.config.activeModel;
      if (!this.config.host || !manualModel) {
        logger6.warn("No devices discovered and no manual IP/model configured");
        return;
      }
      logger6.info("No devices discovered \u2014 will probe manual IP during authorization");
      effectiveModel = manualModel;
    } else {
      logger6.info(`Discovered ${this.discoveredDevices.length} device(s):`);
      for (const d of this.discoveredDevices) {
        logger6.info(`  - Model ${d.model} ${d.manufacturer ?? ""} @ ${d.ip}`);
      }
      for (const device of this.discoveredDevices) {
        this.stController.authorizeDevice(device.ip);
      }
      for (const device of this.discoveredDevices) {
        try {
          const firmware = await this.stController.requestFirmwareVersion(device.ip);
          device.firmwareMain = firmware;
          logger6.info(`  - ${device.ip}: Firmware ${firmware}, Dante ${device.danteFirmware}`);
        } catch (e) {
          logger6.warn(`  - ${device.ip}: Failed to get firmware: ${e}`);
          device.firmwareMain = "Unknown";
        }
      }
      effectiveModel = resolveModel(this.config, this.discoveredDevices);
      if (!effectiveModel && this.config.deviceMac) {
        const modelLabel = this.config.activeModel ? `Model ${this.config.activeModel} ` : "";
        logger6.warn(`Saved device MAC "${this.config.deviceMac}" not found among discovered devices \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `${modelLabel}[${this.config.deviceMac}] not found`);
        return;
      }
    }
    this.syncModel(effectiveModel);
    const targetHost = this.host;
    await this.verifyAuthorization("", targetHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
    this.updateStatus(InstanceStatus.Ok);
    logger6.info("Device discovery complete");
  }
  // When module gets deleted
  async destroy() {
    this.stController?.close();
    logger6.debug("destroy");
  }
  async configUpdated(config) {
    const previousHost = this.host;
    this.config = config;
    const effectiveModel = resolveModel(config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.updateVariableValues();
    const newHost = this.host;
    await this.verifyAuthorization(previousHost, newHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
  }
  /**
   * Re-evaluates whether the current config is authorized to send commands.
   *
   * Auto mode (deviceMac set):
   *   - Find the discovered device with matching MAC → get its current IP
   *   - Revoke the previous IP, authorize the new IP
   *   - If MAC not found in discovery, revoke and block
   *
   * Manual mode (deviceMac empty):
   *   - Check discovered list by IP+model match, or probe directly
   */
  async verifyAuthorization(previousHost, newHost) {
    if (!newHost) {
      if (previousHost)
        this.stController.revokeDevice(previousHost);
      return;
    }
    if (this.config.deviceMac) {
      const device = this.discoveredDevices.find((d) => d.mac === this.config.deviceMac);
      if (!device) {
        logger6.warn(`Device MAC "${this.config.deviceMac}" not found in current discovery \u2014 not authorizing`);
        if (previousHost)
          this.stController.revokeDevice(previousHost);
        return;
      }
      if (previousHost && previousHost !== newHost) {
        this.stController.revokeDevice(previousHost);
      }
      const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
      if (!wasAuthorized) {
        this.stController.authorizeDevice(newHost);
      }
      if (newHost !== previousHost || !wasAuthorized) {
        await this.fetchSettingsAndEnsureSchema(device.model, newHost);
      }
      this.updateStatus(InstanceStatus.Ok);
      return;
    }
    const manualModel = String(this.config.activeModel ?? "");
    const discoveredAtIp = this.discoveredDevices.find((d) => d.ip === newHost);
    if (discoveredAtIp) {
      if (discoveredAtIp.model === manualModel) {
        if (previousHost && previousHost !== newHost)
          this.stController.revokeDevice(previousHost);
        const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
        if (!wasAuthorized) {
          this.stController.authorizeDevice(newHost);
        }
        if (newHost !== previousHost || !wasAuthorized) {
          await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
        }
        this.updateStatus(InstanceStatus.Ok);
      } else {
        logger6.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${discoveredAtIp.model}) at ${newHost} \u2014 commands blocked`);
        this.stController.revokeDevice(newHost);
        this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${discoveredAtIp.model}`);
      }
      return;
    }
    logger6.info(`${newHost} not in discovered list \u2014 probing`);
    if (previousHost && previousHost !== newHost)
      this.stController.revokeDevice(previousHost);
    this.stController.revokeDevice(newHost);
    const probed = await this.stController.probeDevice(newHost);
    if (!probed) {
      logger6.error(`No device responded at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.UnknownWarning, `Device offline: ${newHost}`);
    } else if (probed.model !== manualModel) {
      logger6.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${probed.model}) at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${probed.model}`);
    } else {
      logger6.info(`Verified Model ${probed.model} at ${newHost}`);
      this.stController.authorizeDevice(newHost);
      await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
      this.updateStatus(InstanceStatus.Ok);
    }
  }
  /**
   * Fetches all settings from the device. If no schema exists for the model,
   * creates one from the response and reloads the schema cache.
   */
  async fetchSettingsAndEnsureSchema(model, ip) {
    try {
      await this.stController.requestAllSettings(ip);
      if (!getDeviceSchema(model)) {
        logger6.warn(`No schema found for Model ${model} \u2014 run "GLOBAL: Get All Settings" to create one`);
        return;
      }
    } catch (e) {
      logger6.warn(`Failed to fetch settings from ${ip}: ${e}`);
    }
  }
  /** Loads the device JSON for the given model, caches it as activeModel, and pushes it to the controller. */
  syncModel(model) {
    this.activeModel = model;
    const schema = getDeviceSchema(model);
    if (!schema) {
      logger6.warn(`Model "${model}" not found in device schemas`);
      this.stController.setModel(model, []);
      return;
    }
    const actions = Array.isArray(schema.cmdSchema) ? schema.cmdSchema : [];
    this.stController.setModel(model, actions);
    if (actions.length === 0) {
      logger6.warn(`No actions found for model "${model}" \u2014 settings decoding will use raw IDs`);
    } else {
      logger6.debug(`Loaded ${actions.length} actions for model "${model}", sectioned=${schema.sectioned}`);
    }
  }
  getConfigFields() {
    return GetConfigFields(this.discoveredDevices);
  }
  /** Returns the effective host IP, resolved from MAC→IP via discoveredDevices (auto) or config.host (manual). */
  get host() {
    return resolveHost(this.config, this.discoveredDevices);
  }
  /** Returns discovered devices for use in actions/config */
  get devices() {
    return this.discoveredDevices;
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  updateVariableValues() {
    UpdateVariableValues(this);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2xvZ2dpbmcudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL3V0aWwudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvc2hhcmVkLXVkcC1zb2NrZXQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2hvc3QtYXBpL2NvbnRleHQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvYmFzZS50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9lbnVtcy50cyIsICIuLi8uLi9zcmMvY29uZmlnLnRzIiwgIi4uLy4uL3NyYy92YXJpYWJsZXMudHMiLCAiLi4vLi4vc3JjL3VwZ3JhZGVzLnRzIiwgIi4uLy4uL3NyYy90eXBlcy50cyIsICIuLi8uLi9zcmMvYnVpbGQtY29tbWFuZHMudHMiLCAiLi4vLi4vc3JjL2FjdGlvbnMudHMiLCAiLi4vLi4vc3JjL3NldHRpbmdzUGFyc2VyLnRzIiwgIi4uLy4uL3NyYy9mZWVkYmFja3MudHMiLCAiLi4vLi4vc3JjL3N0Y29udHJvbGxlci50cyIsICIuLi8uLi9zcmMvZGFudGUudHMiLCAiLi4vLi4vc3JjL21haW4udHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5pbXBvcnQgeyBSZWdleCwgdHlwZSBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsIHR5cGUgSnNvbk9iamVjdCwgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignQ29uZmlnJylcblxuZXhwb3J0IHR5cGUgTW9kdWxlQ29uZmlnID0gSnNvbk9iamVjdCAmIHtcblx0LyoqIE1BQyBvZiB0aGUgc2VsZWN0ZWQgZGlzY292ZXJlZCBkZXZpY2UgKGUuZy4gXCIwMDoxZDpjMTo5YjphNjpjZFwiKSwgb3IgJycgZm9yIG1hbnVhbCBtb2RlICovXG5cdGRldmljZU1hYzogc3RyaW5nXG5cdC8qKiBNYW51YWwgSVAgYWRkcmVzcyBcdTIwMTQgb25seSB1c2VkIHdoZW4gZGV2aWNlTWFjIGlzICcnICovXG5cdGhvc3Q6IHN0cmluZ1xuXHQvKiogTWFudWFsIG1vZGVsIHNlbGVjdGlvbiBcdTIwMTQgb25seSB1c2VkIHdoZW4gZGV2aWNlTWFjIGlzICcnICovXG5cdGFjdGl2ZU1vZGVsOiBzdHJpbmdcblx0LyoqIEVuYWJsZSBwYXJzaW5nIG9mIHVuc3VwcG9ydGVkIFNUIGRldmljZXMgKi9cblx0ZGV2TW9kZTogYm9vbGVhblxufVxuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBDRU5UUkFMSVpFRCBERVZJQ0UgU0NIRU1BIENBQ0hFXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBBbGwgZGV2aWNlIEpTT04gZmlsZXMgYXJlIGxvYWRlZCBvbmNlIGludG8gbWVtb3J5IGhlcmUuIE90aGVyIG1vZHVsZXMgc2hvdWxkXG4vLyB1c2UgZ2V0RGV2aWNlc0ZvbGRlcigpLCBnZXREZXZpY2VTY2hlbWFzKCksIGFuZCBnZXREZXZpY2VTY2hlbWEoKSBpbnN0ZWFkIG9mXG4vLyByZWFkaW5nIGZpbGVzIGRpcmVjdGx5LiBDYWxsIHJlbG9hZERldmljZVNjaGVtYXMoKSBhZnRlciB3cml0aW5nIHRvIGEgZmlsZS5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuLyoqXG4gKiBEZXRlcm1pbmVzIHRoZSBjb3JyZWN0IGRldmljZXMgZm9sZGVyIHBhdGggd2l0aCBmYWxsYmFjayBzdXBwb3J0LlxuICogQ2hlY2tzIHByaW1hcnkgcGF0aCBmaXJzdCwgdGhlbiBmYWxsYmFjaywgdGhlbiB0aHJvd3MgZXJyb3IgaWYgbmVpdGhlciBleGlzdHMuXG4gKi9cbmZ1bmN0aW9uIHJlc29sdmVEZXZpY2VzRm9sZGVyKCk6IHN0cmluZyB7XG5cdGNvbnN0IHByaW1hcnlQYXRoID0gcGF0aC5qb2luKGltcG9ydC5tZXRhLmRpcm5hbWUsICcuLi9kZXZpY2VzJylcblx0Y29uc3QgZmFsbGJhY2tQYXRoID0gcGF0aC5qb2luKGltcG9ydC5tZXRhLmRpcm5hbWUsICcuL2RldmljZXMnKVxuXG5cdC8vIENoZWNrIHByaW1hcnkgcGF0aFxuXHRpZiAoZnMuZXhpc3RzU3luYyhwcmltYXJ5UGF0aCkpIHtcblx0XHRsb2dnZXIuZGVidWcoYFVzaW5nIGRldmljZXMgZm9sZGVyOiAke3ByaW1hcnlQYXRofWApXG5cdFx0cmV0dXJuIHByaW1hcnlQYXRoXG5cdH1cblxuXHQvLyBDaGVjayBmYWxsYmFjayBwYXRoXG5cdGlmIChmcy5leGlzdHNTeW5jKGZhbGxiYWNrUGF0aCkpIHtcblx0XHRsb2dnZXIud2FybihgUHJpbWFyeSBkZXZpY2VzIGZvbGRlciBub3QgZm91bmQsIHVzaW5nIGZhbGxiYWNrOiAke2ZhbGxiYWNrUGF0aH1gKVxuXHRcdHJldHVybiBmYWxsYmFja1BhdGhcblx0fVxuXG5cdC8vIE5laXRoZXIgcGF0aCBleGlzdHMgLSBmYXRhbCBlcnJvclxuXHRjb25zdCBlcnJvck1zZyA9IGBEZXZpY2VzIGZvbGRlciBub3QgZm91bmQhXFxuVHJpZWQ6XFxuICAtICR7cHJpbWFyeVBhdGh9XFxuICAtICR7ZmFsbGJhY2tQYXRofVxcbk1vZHVsZSBjYW5ub3QgY29udGludWUgd2l0aG91dCBkZXZpY2Ugc2NoZW1hcy5gXG5cdGxvZ2dlci5lcnJvcihlcnJvck1zZylcblx0dGhyb3cgbmV3IEVycm9yKGVycm9yTXNnKVxufVxuXG4vLyBSZXNvbHZlIHRoZSBkZXZpY2VzIGZvbGRlciBwYXRoICh3aXRoIGV4aXN0ZW5jZSBjaGVjayBhbmQgZmFsbGJhY2spXG5jb25zdCBkZXZpY2VzRm9sZGVyID0gcmVzb2x2ZURldmljZXNGb2xkZXIoKVxuXG4vLyBJbi1tZW1vcnkgY2FjaGUgb2YgYWxsIGRldmljZSBzY2hlbWFzLCBrZXllZCBieSBtb2RlbCBudW1iZXJcbmxldCBkZXZpY2VTY2hlbWFzQ2FjaGU6IFJlY29yZDxzdHJpbmcsIGFueT4gfCBudWxsID0gbnVsbFxuXG4vKipcbiAqIFJldHVybnMgdGhlIGFic29sdXRlIHBhdGggdG8gdGhlIGRldmljZXMgZm9sZGVyLlxuICogVXNlIHRoaXMgaW5zdGVhZCBvZiByZWRlZmluaW5nIHRoZSBwYXRoIGluIGV2ZXJ5IGZpbGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREZXZpY2VzRm9sZGVyKCk6IHN0cmluZyB7XG5cdHJldHVybiBkZXZpY2VzRm9sZGVyXG59XG5cbi8qKlxuICogTG9hZHMgYWxsIGRldmljZSBKU09OIGZpbGVzIGZyb20gdGhlIGRldmljZXMgZm9sZGVyIGludG8gbWVtb3J5LlxuICogVGhpcyBzaG91bGQgb25seSBiZSBjYWxsZWQgb25jZSBhdCBpbml0aWFsaXphdGlvbiwgb3IgYWZ0ZXIgYSBmaWxlIGlzIHdyaXR0ZW4uXG4gKi9cbmZ1bmN0aW9uIGxvYWREZXZpY2VTY2hlbWFzKCk6IFJlY29yZDxzdHJpbmcsIGFueT4ge1xuXHRjb25zdCBzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCBhbnk+ID0ge31cblx0dHJ5IHtcblx0XHRjb25zdCBmaWxlcyA9IGZzLnJlYWRkaXJTeW5jKGRldmljZXNGb2xkZXIpLmZpbHRlcigoZikgPT4gZi5lbmRzV2l0aCgnLmpzb24nKSlcblxuXHRcdGZvciAoY29uc3QgZiBvZiBmaWxlcykge1xuXHRcdFx0Y29uc3QgZnVsbFBhdGggPSBwYXRoLmpvaW4oZGV2aWNlc0ZvbGRlciwgZilcblx0XHRcdGNvbnN0IGpzb24gPSBKU09OLnBhcnNlKGZzLnJlYWRGaWxlU3luYyhmdWxsUGF0aCwgJ3V0ZjgnKSlcblx0XHRcdGlmIChqc29uPy5tb2RlbCkge1xuXHRcdFx0XHRzY2hlbWFzW1N0cmluZyhqc29uLm1vZGVsKV0gPSBqc29uXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0bG9nZ2VyLmRlYnVnKGBMb2FkZWQgJHtPYmplY3Qua2V5cyhzY2hlbWFzKS5sZW5ndGh9IGRldmljZSBzY2hlbWFzIGludG8gY2FjaGVgKVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0bG9nZ2VyLmVycm9yKGBGYWlsZWQgdG8gbG9hZCBkZXZpY2Ugc2NoZW1hczogJHtlfWApXG5cdH1cblx0cmV0dXJuIHNjaGVtYXNcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGFsbCBkZXZpY2Ugc2NoZW1hcyBmcm9tIHRoZSBjYWNoZS5cbiAqIEluaXRpYWxpemVzIHRoZSBjYWNoZSBvbiBmaXJzdCBjYWxsLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlU2NoZW1hcygpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHtcblx0aWYgKCFkZXZpY2VTY2hlbWFzQ2FjaGUpIHtcblx0XHRkZXZpY2VTY2hlbWFzQ2FjaGUgPSBsb2FkRGV2aWNlU2NoZW1hcygpXG5cdH1cblx0cmV0dXJuIGRldmljZVNjaGVtYXNDYWNoZVxufVxuXG4vKipcbiAqIFJldHVybnMgYSBzcGVjaWZpYyBkZXZpY2Ugc2NoZW1hIGJ5IG1vZGVsIG51bWJlci5cbiAqIFJldHVybnMgdW5kZWZpbmVkIGlmIHRoZSBtb2RlbCBkb2Vzbid0IGV4aXN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsOiBzdHJpbmcpOiBhbnkge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdHJldHVybiBzY2hlbWFzW21vZGVsXVxufVxuXG4vKipcbiAqIFJlbG9hZHMgYWxsIGRldmljZSBzY2hlbWFzIGZyb20gZGlzay5cbiAqIENhbGwgdGhpcyBhZnRlciB3cml0aW5nIHRvIGEgZGV2aWNlIEpTT04gZmlsZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlbG9hZERldmljZVNjaGVtYXMoKTogdm9pZCB7XG5cdGxvZ2dlci5pbmZvKCdSZWxvYWRpbmcgZGV2aWNlIHNjaGVtYXMgZnJvbSBkaXNrLi4uJylcblx0ZGV2aWNlU2NoZW1hc0NhY2hlID0gbG9hZERldmljZVNjaGVtYXMoKVxufVxuXG4vKipcbiAqIFJldHVybnMgYSBsaXN0IG9mIGF2YWlsYWJsZSBtb2RlbCBudW1iZXJzLCBzb3J0ZWQuXG4gKi9cbmZ1bmN0aW9uIGxvYWRBdmFpbGFibGVNb2RlbHMoKTogc3RyaW5nW10ge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdHJldHVybiBPYmplY3Qua2V5cyhzY2hlbWFzKS5zb3J0KClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEdldENvbmZpZ0ZpZWxkcyhkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW10pOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdGNvbnN0IG1vZGVscyA9IGxvYWRBdmFpbGFibGVNb2RlbHMoKVxuXG5cdC8vIERyb3Bkb3duIGlkIGlzIHRoZSBkZXZpY2UgTUFDIFx1MjAxNCBzdGFibGUgYWNyb3NzIElQIGNoYW5nZXMuXG5cdC8vIEVtcHR5IGlkID0gTWFudWFsIG1vZGUuXG5cdGNvbnN0IGRldmljZUNob2ljZXMgPSBbXG5cdFx0eyBpZDogJycsIGxhYmVsOiAnTWFudWFsIChlbnRlciBJUCArIG1vZGVsIGJlbG93KScgfSxcblx0XHQuLi5kaXNjb3ZlcmVkRGV2aWNlcy5tYXAoKGQpID0+ICh7XG5cdFx0XHRpZDogZC5tYWMgPz8gJycsXG5cdFx0XHRsYWJlbDogYE1vZGVsICR7ZC5tb2RlbH0gWyR7ZC5tYWN9XSBAICR7ZC5pcH1gLFxuXHRcdH0pKSxcblx0XVxuXG5cdHJldHVybiBbXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIERldmljZSBzZWxlY3Rpb24gZHJvcGRvd24gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gU3RvcmVzIHRoZSBNQUMgc28gcmUtZGlzY292ZXJ5IHdpdGggYSBjaGFuZ2VkIElQIHN0aWxsIG1hdGNoZXMuXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdGlkOiAnZGV2aWNlTWFjJyxcblx0XHRcdGxhYmVsOiAnRGV2aWNlJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogJycsXG5cdFx0XHRjaG9pY2VzOiBkZXZpY2VDaG9pY2VzLFxuXHRcdFx0dG9vbHRpcDogJ1NlbGVjdCBhbiBhdXRvLWRpc2NvdmVyZWQgU3R1ZGlvIFRlY2hub2xvZ2llcyBkZXZpY2UsIG9yIGNob29zZSBNYW51YWwgdG8gZW50ZXIgYW4gSVAgYWRkcmVzcy4nLFxuXHRcdH0sXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgTWFudWFsIElQIGVudHJ5IFx1MjAxNCBvbmx5IHZpc2libGUgaW4gbWFudWFsIG1vZGUgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0e1xuXHRcdFx0dHlwZTogJ3RleHRpbnB1dCcsXG5cdFx0XHRpZDogJ2hvc3QnLFxuXHRcdFx0bGFiZWw6ICdUYXJnZXQgSVAnLFxuXHRcdFx0d2lkdGg6IDgsXG5cdFx0XHRkZWZhdWx0OiAnJyxcblx0XHRcdHJlZ2V4OiBSZWdleC5JUCxcblx0XHRcdGlzVmlzaWJsZUV4cHJlc3Npb246IGAhJChvcHRpb25zOmRldmljZU1hYylgLFxuXHRcdFx0dG9vbHRpcDogJ0VudGVyIHRoZSBJUCBhZGRyZXNzIG9mIHRoZSBkZXZpY2UgbWFudWFsbHkuJyxcblx0XHR9LFxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIE1hbnVhbCBtb2RlbCBzZWxlY3RvciBcdTIwMTQgb25seSB2aXNpYmxlIGluIG1hbnVhbCBtb2RlIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdHtcblx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRpZDogJ2FjdGl2ZU1vZGVsJyxcblx0XHRcdGxhYmVsOiAnQWN0aXZlIERldmljZSBNb2RlbCcsXG5cdFx0XHR3aWR0aDogOCxcblx0XHRcdGRlZmF1bHQ6IG1vZGVsc1swXSA/PyAnJyxcblx0XHRcdGNob2ljZXM6IG1vZGVscy5tYXAoKG1vZGVsKSA9PiAoe1xuXHRcdFx0XHRpZDogbW9kZWwsXG5cdFx0XHRcdGxhYmVsOiBgTW9kZWwgJHttb2RlbH1gLFxuXHRcdFx0fSkpLFxuXHRcdFx0aXNWaXNpYmxlRXhwcmVzc2lvbjogYCEkKG9wdGlvbnM6ZGV2aWNlTWFjKWAsXG5cdFx0XHR0b29sdGlwOiAnU2VsZWN0IHdoaWNoIFN0dWRpbyBUZWNobm9sb2dpZXMgbW9kZWwgaXMgYWN0aXZlIGZvciBhY3Rpb25zIGFuZCBmZWVkYmFja3MuJyxcblx0XHR9LFxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIERldiBNb2RlIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdHtcblx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRpZDogJ2Rldk1vZGUnLFxuXHRcdFx0bGFiZWw6ICdEZXYgTW9kZScsXG5cdFx0XHR3aWR0aDogMTIsXG5cdFx0XHRkZWZhdWx0OiBmYWxzZSxcblx0XHRcdHRvb2x0aXA6ICdFbmFibGUgdG8gYWxsb3cgcGFyc2luZyBvZiBTVCBEZXZpY2VzIG5vdCBjdXJyZW50bHkgc3VwcG9ydGVkJyxcblx0XHR9LFxuXHRdXG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgZWZmZWN0aXZlIGhvc3QgSVAuXG4gKiBBdXRvIG1vZGUgKGRldmljZU1hYyBzZXQpOiBmaW5kcyB0aGUgY3VycmVudCBJUCBvZiB0aGUgZGlzY292ZXJlZCBkZXZpY2Ugd2l0aCB0aGF0IE1BQy5cbiAqIE1hbnVhbCBtb2RlIChkZXZpY2VNYWMgZW1wdHkpOiByZXR1cm5zIHRoZSBtYW51YWxseSBlbnRlcmVkIGhvc3QgSVAuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlSG9zdChjb25maWc6IE1vZHVsZUNvbmZpZywgZGlzY292ZXJlZERldmljZXM6IERldmljZUluZm9bXSk6IHN0cmluZyB7XG5cdGlmIChjb25maWcuZGV2aWNlTWFjKSB7XG5cdFx0Y29uc3QgZGV2aWNlID0gZGlzY292ZXJlZERldmljZXMuZmluZCgoZCkgPT4gZC5tYWMgPT09IGNvbmZpZy5kZXZpY2VNYWMpXG5cdFx0cmV0dXJuIGRldmljZT8uaXAgPz8gJydcblx0fVxuXHRyZXR1cm4gU3RyaW5nKGNvbmZpZy5ob3N0ID8/ICcnKVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBtb2RlbC5cbiAqIEF1dG8gbW9kZTogdXNlcyB0aGUgbW9kZWwgZnJvbSB0aGUgZGlzY292ZXJlZCBkZXZpY2UgbWF0Y2hpbmcgdGhlIHN0b3JlZCBNQUMuXG4gKiBNYW51YWwgbW9kZTogdXNlcyB0aGUgbWFudWFsbHkgc2VsZWN0ZWQgYWN0aXZlTW9kZWwuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlTW9kZWwoY29uZmlnOiBNb2R1bGVDb25maWcsIGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10pOiBzdHJpbmcge1xuXHRpZiAoY29uZmlnLmRldmljZU1hYykge1xuXHRcdGNvbnN0IGRldmljZSA9IGRpc2NvdmVyZWREZXZpY2VzLmZpbmQoKGQpID0+IGQubWFjID09PSBjb25maWcuZGV2aWNlTWFjKVxuXHRcdGxvZ2dlci5kZWJ1ZyhgcmVzb2x2ZU1vZGVsOiBkZXZpY2VNYWM9XCIke2NvbmZpZy5kZXZpY2VNYWN9XCIsIGZvdW5kIGRldmljZTogJHtkZXZpY2U/Lm1vZGVsID8/ICdub25lJ31gKVxuXHRcdHJldHVybiBkZXZpY2U/Lm1vZGVsID8/ICcnXG5cdH1cblx0bG9nZ2VyLmRlYnVnKGByZXNvbHZlTW9kZWw6IG1hbnVhbCBtb2RlLCBhY3RpdmVNb2RlbD1cIiR7Y29uZmlnLmFjdGl2ZU1vZGVsfVwiYClcblx0cmV0dXJuIFN0cmluZyhjb25maWcuYWN0aXZlTW9kZWwgPz8gJycpXG59XG4iLCAiaW1wb3J0IHR5cGUgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuXG4vKipcbiAqIERlZmluZSBDb21wYW5pb24gdmFyaWFibGVzIGZvciB0aGlzIG1vZHVsZS5cbiAqIFZhcmlhYmxlcyBjYW4gYmUgdXNlZCB0byBkaXNwbGF5IGR5bmFtaWMgc3RhdGUgaW4gYnV0dG9uIGxhYmVscywgdHJpZ2dlcnMsIGV0Yy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0c2VsZi5zZXRWYXJpYWJsZURlZmluaXRpb25zKHtcblx0XHRtb2RlbDogeyBuYW1lOiAnRGV2aWNlIE1vZGVsIE51bWJlcicgfSxcblx0XHRtb2RlbE5hbWU6IHsgbmFtZTogJ0RldmljZSBNb2RlbCBOYW1lIChGdWxsIERlc2NyaXB0aW9uKScgfSxcblx0XHRtYW51ZmFjdHVyZXI6IHsgbmFtZTogJ0RldmljZSBNYW51ZmFjdHVyZXInIH0sXG5cdFx0ZmlybXdhcmU6IHsgbmFtZTogJ0RldmljZSBGaXJtd2FyZSBWZXJzaW9uJyB9LFxuXHRcdGRhbnRlRlc6IHsgbmFtZTogJ0RhbnRlIE1vZHVsZSBGaXJtd2FyZSBWZXJzaW9uJyB9LFxuXHRcdG1hYzogeyBuYW1lOiAnRGV2aWNlIE1BQyBBZGRyZXNzJyB9LFxuXHRcdGlwOiB7IG5hbWU6ICdEZXZpY2UgSVAgQWRkcmVzcycgfSxcblx0fSlcbn1cblxuY29uc3QgQ0xFQVJFRF9WQVJJQUJMRVMgPSB7XG5cdG1vZGVsOiAnJyxcblx0bW9kZWxOYW1lOiAnJyxcblx0bWFudWZhY3R1cmVyOiAnJyxcblx0ZmlybXdhcmU6ICcnLFxuXHRkYW50ZUZXOiAnJyxcblx0bWFjOiAnJyxcblx0aXA6ICcnLFxufVxuXG4vKipcbiAqIFVwZGF0ZSB2YXJpYWJsZSB2YWx1ZXMgZnJvbSBkaXNjb3ZlcmVkIGRldmljZSBpbmZvcm1hdGlvbi5cbiAqIE9ubHkgcG9wdWxhdGVzIHZhcmlhYmxlcyB3aGVuIHRoZSBjdXJyZW50IGhvc3QgaXMgYXV0aG9yaXplZC5cbiAqIENsZWFycyBhbGwgdmFyaWFibGVzIGlmIHRoZSBkZXZpY2UgaXMgbm90IGF1dGhvcml6ZWQgb3Igbm90IGZvdW5kLlxuICovXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlVmFyaWFibGVWYWx1ZXMoc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3QgY3VycmVudEhvc3QgPSBzZWxmLmhvc3RcblxuXHQvLyBDbGVhciB2YXJpYWJsZXMgaWYgbm8gaG9zdCBjb25maWd1cmVkIG9yIGRldmljZSBpcyBub3QgYXV0aG9yaXplZFxuXHRpZiAoIWN1cnJlbnRIb3N0IHx8ICFzZWxmLnN0Q29udHJvbGxlci5pc0RldmljZUF1dGhvcml6ZWQoY3VycmVudEhvc3QpKSB7XG5cdFx0c2VsZi5zZXRWYXJpYWJsZVZhbHVlcyhDTEVBUkVEX1ZBUklBQkxFUylcblx0XHRyZXR1cm5cblx0fVxuXG5cdGNvbnN0IGRldmljZSA9IHNlbGYuZGV2aWNlcy5maW5kKChkKSA9PiBkLmlwID09PSBjdXJyZW50SG9zdClcblx0aWYgKGRldmljZSkge1xuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoe1xuXHRcdFx0bW9kZWw6IGRldmljZS5tb2RlbCB8fCAnJyxcblx0XHRcdG1vZGVsTmFtZTogZGV2aWNlLm1vZGVsTmFtZSB8fCAnJyxcblx0XHRcdG1hbnVmYWN0dXJlcjogZGV2aWNlLm1hbnVmYWN0dXJlciB8fCAnJyxcblx0XHRcdGZpcm13YXJlOiBkZXZpY2UuZmlybXdhcmVNYWluIHx8ICcnLFxuXHRcdFx0ZGFudGVGVzogZGV2aWNlLmRhbnRlRmlybXdhcmUgfHwgJycsXG5cdFx0XHRtYWM6IGRldmljZS5tYWMgfHwgJycsXG5cdFx0XHRpcDogZGV2aWNlLmlwLFxuXHRcdH0pXG5cdH0gZWxzZSB7XG5cdFx0Ly8gQXV0aG9yaXplZCBidXQgbm90IGluIGRpc2NvdmVyZWQgbGlzdCAobWFudWFsIElQIHRoYXQgcHJvYmVkIHN1Y2Nlc3NmdWxseSlcblx0XHQvLyBXZSBrbm93IGl0J3MgdGhlIHJpZ2h0IGRldmljZSBidXQgZG9uJ3QgaGF2ZSBmdWxsIGluZm8geWV0XG5cdFx0c2VsZi5zZXRWYXJpYWJsZVZhbHVlcyh7XG5cdFx0XHQuLi5DTEVBUkVEX1ZBUklBQkxFUyxcblx0XHRcdGlwOiBjdXJyZW50SG9zdCxcblx0XHR9KVxuXHR9XG59XG4iLCAiaW1wb3J0IHR5cGUgeyBDb21wYW5pb25TdGF0aWNVcGdyYWRlU2NyaXB0IH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi9jb25maWcuanMnXG5cbmV4cG9ydCBjb25zdCBVcGdyYWRlU2NyaXB0czogQ29tcGFuaW9uU3RhdGljVXBncmFkZVNjcmlwdDxNb2R1bGVDb25maWc+W10gPSBbXG5cdC8qXG5cdCAqIFBsYWNlIHlvdXIgdXBncmFkZSBzY3JpcHRzIGhlcmVcblx0ICogUmVtZW1iZXIgdGhhdCBvbmNlIGl0IGhhcyBiZWVuIGFkZGVkIGl0IGNhbm5vdCBiZSByZW1vdmVkIVxuXHQgKi9cblx0Ly8gZnVuY3Rpb24gKGNvbnRleHQsIHByb3BzKSB7XG5cdC8vIFx0cmV0dXJuIHtcblx0Ly8gXHRcdHVwZGF0ZWRDb25maWc6IG51bGwsXG5cdC8vIFx0XHR1cGRhdGVkQWN0aW9uczogW10sXG5cdC8vIFx0XHR1cGRhdGVkRmVlZGJhY2tzOiBbXSxcblx0Ly8gXHR9XG5cdC8vIH0sXG5dXG4iLCAiZXhwb3J0IHR5cGUgQ29tcGFuaW9uSW5wdXRDaG9pY2UgPSB7XG5cdGlkOiBzdHJpbmcgfCBudW1iZXJcblx0bGFiZWw6IHN0cmluZ1xufVxuXG5leHBvcnQgdHlwZSBEZXZpY2VTZXR0aW5nID0ge1xuXHR0eXBlOiBzdHJpbmdcblx0bGFiZWw6IHN0cmluZ1xuXHRkZWZhdWx0OiBzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuXG5cdGNob2ljZXM/OiBDb21wYW5pb25JbnB1dENob2ljZVtdXG59XG5cbmV4cG9ydCB0eXBlIERldmljZUluZm8gPSB7XG5cdG1vZGVsOiBzdHJpbmcgLy8gTW9kZWwgbnVtYmVyIChlLmcuLCBcIjM3NEFcIilcblx0bW9kZWxOYW1lPzogc3RyaW5nIC8vIEZ1bGwgbW9kZWwgZGVzY3JpcHRpb24gKGUuZy4sIFwiTW9kZWwgMzc0QSBJbnRlcmNvbSBCZWx0cGFja1wiKVxuXHRpcDogc3RyaW5nXG5cdG5hbWU/OiBzdHJpbmcgLy8gRGFudGUgZGV2aWNlIG5hbWUgKHVzZXItY29uZmlndXJhYmxlIGxhYmVsLCBlLmcuIFwiU1QtTTM3NEEtQmVsdHBhY2tcIilcblx0bWFudWZhY3R1cmVyPzogc3RyaW5nIC8vIGUuZy4gXCJTdHVkaW8gVGVjaG5vbG9naWVzLCBJbmMuXCJcblx0ZmlybXdhcmVNYWluPzogc3RyaW5nIC8vIERldmljZSBmaXJtd2FyZSB2ZXJzaW9uIGZyb20gRGFudGUgZGlzY292ZXJ5IChlLmcuLCBcIjQuOS4wXCIpXG5cdGRhbnRlRmlybXdhcmU/OiBzdHJpbmcgLy8gRGFudGUgbW9kdWxlIGZpcm13YXJlIHZlcnNpb25cblx0bWFjPzogc3RyaW5nXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBTdHVkaW8tVCBDb21tYW5kIElEIENvbnN0YW50cyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbmV4cG9ydCBjb25zdCBDTURfR0VUX0ZJUk1XQVJFID0gMHgwMCAvLyBSZXF1ZXN0IGRldmljZSBmaXJtd2FyZSB2ZXJzaW9uXG5leHBvcnQgY29uc3QgQ01EX01JQ19QUkUgPSAweDAyIC8vIE1pYyBwcmVhbXAgcmF3IHNldCAoZ2FpbiwgcGhhbnRvbSkgXHUyMDE0IHBvc2l0aW9uYWwgYnl0ZXMsIG5vIHNldHRpbmcgSURzXG5leHBvcnQgY29uc3QgQ01EX0JVU19HRVQgPSAweDAzIC8vIEhlYXJ0YmVhdCAvIGtlZXBhbGl2ZSBwaW5nXG5leHBvcnQgY29uc3QgQ01EX0JVU19TRVQgPSAweDA0IC8vIFNldCBzZXR0aW5nIG9uIHNwZWNpZmljIGJ1cy9jaGFubmVsXG5leHBvcnQgY29uc3QgQ01EX0hFQURQSE9ORSA9IDB4MDUgLy8gSGVhZHBob25lIGNvbnRyb2xzXG5leHBvcnQgY29uc3QgQ01EX0JVVFRPTl9NT0RFID0gMHgwNyAvLyBCdXR0b24gbW9kZSBjb25maWd1cmF0aW9uXG5leHBvcnQgY29uc3QgQ01EX1NZU1RFTSA9IDB4MDkgLy8gU3lzdGVtLWxldmVsIGNvbW1hbmRzXG5leHBvcnQgY29uc3QgQ01EX0dFVF9BTExfU0VUVElOR1MgPSAweDBhIC8vIFJlcXVlc3QgYWxsIGN1cnJlbnQgc2V0dGluZ3MgZnJvbSBkZXZpY2VcbmV4cG9ydCBjb25zdCBDTURfU0VUVElOR1NfUFVTSCA9IDB4MGIgLy8gVW5zb2xpY2l0ZWQgc2V0dGluZ3MgdXBkYXRlIGZyb20gZGV2aWNlXG5leHBvcnQgY29uc3QgQ01EX0RFVl9TUEVDID0gMHgwZCAvLyBEZXZpY2Utc3BlY2lmaWMgc2V0dGluZyBnZXQvc2V0IHdpdGggQUNLXG5leHBvcnQgY29uc3QgQ01EX1JFU0VUX0RFVklDRSA9IDB4MGUgLy8gRmFjdG9yeSByZXNldCBjb21tYW5kXG5leHBvcnQgY29uc3QgQ01EX0dMT0JBTF9NSUNfS0lMTCA9IDB4MTAgLy8gRW1lcmdlbmN5IG1pYyBraWxsIChhbGwgY2hhbm5lbHMpXG5leHBvcnQgY29uc3QgQ01EX01JQ19QUkVfQlVTID0gMHgxMiAvLyBNaWMvcHJlYW1wIHNldHRpbmdzIHBlciBidXMgKGdhaW4sIHBoYW50b20sIGV0YylcbmV4cG9ydCBjb25zdCBDTURfQ0hBTk5FTCA9IDB4MTQgLy8gQ2hhbm5lbC1zcGVjaWZpYyBjb250cm9sc1xuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgQ29tbWFuZCBOYW1lIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbmV4cG9ydCBmdW5jdGlvbiBnZXRDb21tYW5kTmFtZShjbWRJZDogbnVtYmVyKTogc3RyaW5nIHtcblx0c3dpdGNoIChjbWRJZCkge1xuXHRcdGNhc2UgQ01EX0dFVF9GSVJNV0FSRTpcblx0XHRcdHJldHVybiAnR2V0IEZpcm13YXJlIFZlcnNpb24nXG5cdFx0Y2FzZSBDTURfTUlDX1BSRTpcblx0XHRcdHJldHVybiAnTWljIFByZWFtcCdcblx0XHRjYXNlIENNRF9CVVNfR0VUOlxuXHRcdFx0cmV0dXJuICdIZWFydGJlYXQnXG5cdFx0Y2FzZSBDTURfQlVTX1NFVDpcblx0XHRcdHJldHVybiAnU2V0IEJ1cyBTZXR0aW5nJ1xuXHRcdGNhc2UgQ01EX0hFQURQSE9ORTpcblx0XHRcdHJldHVybiAnSGVhZHBob25lIENvbnRyb2wnXG5cdFx0Y2FzZSBDTURfQlVUVE9OX01PREU6XG5cdFx0XHRyZXR1cm4gJ0J1dHRvbiBNb2RlJ1xuXHRcdGNhc2UgQ01EX1NZU1RFTTpcblx0XHRcdHJldHVybiAnU3lzdGVtIENvbW1hbmQnXG5cdFx0Y2FzZSBDTURfR0VUX0FMTF9TRVRUSU5HUzpcblx0XHRcdHJldHVybiAnUmVxdWVzdCBBbGwgU2V0dGluZ3MnXG5cdFx0Y2FzZSBDTURfU0VUVElOR1NfUFVTSDpcblx0XHRcdHJldHVybiAnU2V0dGluZ3MgUHVzaCdcblx0XHRjYXNlIENNRF9NSUNfUFJFX0JVUzpcblx0XHRcdHJldHVybiAnTWljL1ByZSBCdXMnXG5cdFx0Y2FzZSBDTURfREVWX1NQRUM6XG5cdFx0XHRyZXR1cm4gJ0RldmljZSBTZXR0aW5nJ1xuXHRcdGNhc2UgQ01EX0NIQU5ORUw6XG5cdFx0XHRyZXR1cm4gJ0NoYW5uZWwgU2V0dGluZydcblx0XHRjYXNlIENNRF9SRVNFVF9ERVZJQ0U6XG5cdFx0XHRyZXR1cm4gJ1Jlc2V0IERldmljZSdcblx0XHRjYXNlIENNRF9HTE9CQUxfTUlDX0tJTEw6XG5cdFx0XHRyZXR1cm4gJ0dsb2JhbCBNaWMgS2lsbCdcblx0XHRkZWZhdWx0OlxuXHRcdFx0cmV0dXJuIGBjbWRfMHgke2NtZElkLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpfWBcblx0fVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgSUQgR2VuZXJhdGlvbiBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENyZWF0ZXMgYSBjb25zaXN0ZW50IElEIGZvciBhY3Rpb25zLCBmZWVkYmFja3MsIGFuZCBzdGF0ZSBrZXlzLlxuICogRm9ybWF0OiBgJHttb2RlbH1fJHtjbWRfaWR9XyR7YnVzQ2h9XyR7aWR9YCBmb3IgY29tbWFuZHMgd2l0aCBidXNDaCAoZS5nLiwgXCI1MzA0XzE0XzBfMFwiKVxuICogRm9ybWF0OiBgJHttb2RlbH1fJHtjbWRfaWR9XyR7aWR9YCBmb3IgY29tbWFuZHMgd2l0aG91dCBidXNDaCAoZS5nLiwgXCI1MzA0XzEyX2RcIilcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1ha2VTZXR0aW5nSWQoXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIgfCBzdHJpbmcsXG5cdHNldHRpbmdJZDogbnVtYmVyIHwgc3RyaW5nLFxuXHRidXNDaD86IG51bWJlciB8IHN0cmluZyxcbik6IHN0cmluZyB7XG5cdGNvbnN0IGNtZCA9IHR5cGVvZiBjbWRJZCA9PT0gJ251bWJlcicgPyBjbWRJZC50b1N0cmluZygxNikgOiBjbWRJZFxuXHRjb25zdCBpZCA9IHR5cGVvZiBzZXR0aW5nSWQgPT09ICdudW1iZXInID8gc2V0dGluZ0lkLnRvU3RyaW5nKDE2KSA6IHNldHRpbmdJZFxuXG5cdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0Y29uc3QgY2ggPSB0eXBlb2YgYnVzQ2ggPT09ICdudW1iZXInID8gYnVzQ2gudG9TdHJpbmcoMTYpIDogYnVzQ2hcblx0XHRyZXR1cm4gYCR7bW9kZWx9XyR7Y21kfV8ke2NofV8ke2lkfWBcblx0fVxuXG5cdHJldHVybiBgJHttb2RlbH1fJHtjbWR9XyR7aWR9YFxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgSGV4IEZvcm1hdHRpbmcgSGVscGVycyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogQ29udmVydHMgYSBudW1iZXIgdG8gYSBoZXggc3RyaW5nIHdpdGggMHggcHJlZml4IGFuZCBwYWRkaW5nLlxuICogQHBhcmFtIHZhbHVlIC0gVGhlIG51bWJlciB0byBjb252ZXJ0XG4gKiBAcGFyYW0gcGFkTGVuZ3RoIC0gTnVtYmVyIG9mIGhleCBkaWdpdHMgdG8gcGFkIHRvIChkZWZhdWx0OiAyKVxuICogQHJldHVybnMgRm9ybWF0dGVkIGhleCBzdHJpbmcgKGUuZy4sIFwiMHgwZFwiLCBcIjB4ZmZcIilcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSGV4KHZhbHVlOiBudW1iZXIsIHBhZExlbmd0aCA9IDIpOiBzdHJpbmcge1xuXHRyZXR1cm4gYDB4JHt2YWx1ZS50b1N0cmluZygxNikucGFkU3RhcnQocGFkTGVuZ3RoLCAnMCcpfWBcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBhcnJheSBvZiBieXRlcyB0byBhIGhleCBzdHJpbmcgd2l0aCAweCBwcmVmaXguXG4gKiBAcGFyYW0gYnl0ZXMgLSBBcnJheSBvZiBieXRlcyBvciBCdWZmZXJcbiAqIEByZXR1cm5zIEZvcm1hdHRlZCBoZXggc3RyaW5nIChlLmcuLCBcIjB4MGFmZjEyXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBieXRlc1RvSGV4KGJ5dGVzOiBudW1iZXJbXSB8IEJ1ZmZlcik6IHN0cmluZyB7XG5cdHJldHVybiBgMHgke0FycmF5LmZyb20oYnl0ZXMpXG5cdFx0Lm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcblx0XHQuam9pbignJyl9YFxufVxuXG4vKipcbiAqIEZvcm1hdHMgUkdCIGNvbG9yIGJ5dGVzIGFzIGEgQ1NTIGhleCBjb2xvciBzdHJpbmcuXG4gKiBAcGFyYW0gciAtIFJlZCBjb21wb25lbnQgKDAtMjU1KVxuICogQHBhcmFtIGcgLSBHcmVlbiBjb21wb25lbnQgKDAtMjU1KVxuICogQHBhcmFtIGIgLSBCbHVlIGNvbXBvbmVudCAoMC0yNTUpXG4gKiBAcmV0dXJucyBDU1MgaGV4IGNvbG9yIHN0cmluZyAoZS5nLiwgXCIjRkYwMEFCXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRSZ2JDb2xvcihyOiBudW1iZXIsIGc6IG51bWJlciwgYjogbnVtYmVyKTogc3RyaW5nIHtcblx0cmV0dXJuIGAjJHtbciwgZywgYl1cblx0XHQubWFwKCh2KSA9PiB2LnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKVxuXHRcdC5qb2luKCcnKVxuXHRcdC50b1VwcGVyQ2FzZSgpfWBcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIElEIFBhcnNpbmcgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBQYXJzZXMgYSBzZXR0aW5nIElEIHN0cmluZyBpbnRvIGl0cyBjb21wb25lbnRzLlxuICogQHBhcmFtIGlkIC0gU2V0dGluZyBJRCBzdHJpbmcgKGUuZy4sIFwiMzkxX2RfMFwiIG9yIFwiNTMwNF8xNF8wXzFcIilcbiAqIEByZXR1cm5zIFBhcnNlZCBjb21wb25lbnRzIHdpdGggaGV4IHN0cmluZ3MgY29udmVydGVkIHRvIG51bWJlcnNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlU2V0dGluZ0lkKGlkOiBzdHJpbmcpOiB7IG1vZGVsOiBzdHJpbmc7IGNtZElkOiBudW1iZXI7IGJhc2VJZDogbnVtYmVyIH0ge1xuXHRjb25zdCBbbW9kZWwsIGNtZElkU3RyLCBpZFN0cl0gPSBpZC5zcGxpdCgnXycpXG5cdHJldHVybiB7XG5cdFx0bW9kZWwsXG5cdFx0Y21kSWQ6IHBhcnNlSW50KGNtZElkU3RyLCAxNiksXG5cdFx0YmFzZUlkOiBwYXJzZUludChpZFN0ciwgMTYpLFxuXHR9XG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBNb2RlbCBEaXN0YW5jZSBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENhbGN1bGF0ZXMgbnVtZXJpYyBkaXN0YW5jZSBiZXR3ZWVuIHR3byBtb2RlbCBudW1iZXJzLlxuICogVXNlZCBmb3IgZmluZGluZyBzaW1pbGFyIG1vZGVscyBmb3Igc2V0dGluZyBpbmZlcmVuY2UuXG4gKiBAcGFyYW0gbW9kZWxBIC0gRmlyc3QgbW9kZWwgbnVtYmVyIChlLmcuLCBcIjM5MVwiKVxuICogQHBhcmFtIG1vZGVsQiAtIFNlY29uZCBtb2RlbCBudW1iZXIgKGUuZy4sIFwiMzkyXCIpXG4gKiBAcmV0dXJucyBOdW1lcmljIGRpc3RhbmNlIGJldHdlZW4gbW9kZWxzLCBvciBJbmZpbml0eSBpZiBlaXRoZXIgaXMgbm9uLW51bWVyaWNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1vZGVsRGlzdGFuY2UobW9kZWxBOiBzdHJpbmcsIG1vZGVsQjogc3RyaW5nKTogbnVtYmVyIHtcblx0Y29uc3QgbmEgPSBwYXJzZUludChtb2RlbEEucmVwbGFjZSgvXFxEL2csICcnKSwgMTApXG5cdGNvbnN0IG5iID0gcGFyc2VJbnQobW9kZWxCLnJlcGxhY2UoL1xcRC9nLCAnJyksIDEwKVxuXHRpZiAoTnVtYmVyLmlzTmFOKG5hKSB8fCBOdW1iZXIuaXNOYU4obmIpKSByZXR1cm4gSW5maW5pdHlcblx0cmV0dXJuIE1hdGguYWJzKG5hIC0gbmIpXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBTY2hlbWEgTm9ybWFsaXphdGlvbiBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIE5vcm1hbGl6ZXMgZGV2aWNlIHNjaGVtYXMgdG8gZW5zdXJlIGNtZFNjaGVtYSBpcyBhbHdheXMgYW4gYXJyYXkuXG4gKiBUaGlzIGhlbHBlciBlbGltaW5hdGVzIGR1cGxpY2F0ZSBzY2hlbWEgdHJhbnNmb3JtYXRpb24gY29kZS5cbiAqIEBwYXJhbSBzY2hlbWFzUmF3IC0gUmF3IHNjaGVtYXMgZnJvbSBnZXREZXZpY2VTY2hlbWFzKClcbiAqIEByZXR1cm5zIE5vcm1hbGl6ZWQgc2NoZW1hcyB3aXRoIGd1YXJhbnRlZWQgY21kU2NoZW1hIGFycmF5c1xuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0Tm9ybWFsaXplZFNjaGVtYXMoXG5cdHNjaGVtYXNSYXc6IFJlY29yZDxzdHJpbmcsIGFueT4sXG4pOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4ge1xuXHRjb25zdCBub3JtYWxpemVkOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4gPSB7fVxuXHRmb3IgKGNvbnN0IFttb2RlbCwganNvbl0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hc1JhdykpIHtcblx0XHRub3JtYWxpemVkW21vZGVsXSA9IHtcblx0XHRcdG1vZGVsOiBqc29uLm1vZGVsLFxuXHRcdFx0Y21kU2NoZW1hOiBBcnJheS5pc0FycmF5KGpzb24uY21kU2NoZW1hKSA/IGpzb24uY21kU2NoZW1hIDogW10sXG5cdFx0fVxuXHR9XG5cdHJldHVybiBub3JtYWxpemVkXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBBY3Rpb24gTG9va3VwIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogRmluZHMgYW4gYWN0aW9uL3NldHRpbmcgaW4gdGhlIHNjaGVtYSwgc3VwcG9ydGluZyBib3RoIGV4YWN0IG1hdGNoZXMgYW5kIGlkQWRkIG9mZnNldHMuXG4gKiBUaGlzIGhlbHBlciBlbGltaW5hdGVzIGR1cGxpY2F0ZSBhY3Rpb24gbG9va3VwIGxvZ2ljIGFjcm9zcyBtdWx0aXBsZSBmaWxlcy5cbiAqIEBwYXJhbSBzY2hlbWFzIC0gTm9ybWFsaXplZCBkZXZpY2Ugc2NoZW1hc1xuICogQHBhcmFtIG1vZGVsIC0gRGV2aWNlIG1vZGVsIChlLmcuLCBcIjM5MVwiKVxuICogQHBhcmFtIGNtZElkIC0gQ29tbWFuZCBJRFxuICogQHBhcmFtIHNldHRpbmdJZCAtIFNldHRpbmcgSUQgKG1heSBpbmNsdWRlIGlkQWRkIG9mZnNldClcbiAqIEByZXR1cm5zIE1hdGNoaW5nIGFjdGlvbi9zZXR0aW5nIG9yIHVuZGVmaW5lZFxuICovXG5leHBvcnQgZnVuY3Rpb24gZmluZEFjdGlvbkZvclNldHRpbmcoXG5cdHNjaGVtYXM6IFJlY29yZDxzdHJpbmcsIHsgbW9kZWw6IHN0cmluZzsgY21kU2NoZW1hOiBhbnlbXSB9Pixcblx0bW9kZWw6IHN0cmluZyxcblx0Y21kSWQ6IG51bWJlcixcblx0c2V0dGluZ0lkOiBudW1iZXIsXG4pOiBhbnkge1xuXHRjb25zdCBzY2hlbWEgPSBzY2hlbWFzW21vZGVsXVxuXHRpZiAoIXNjaGVtYSB8fCAhQXJyYXkuaXNBcnJheShzY2hlbWEuY21kU2NoZW1hKSkgcmV0dXJuIHVuZGVmaW5lZFxuXG5cdC8vIFRyeSBleGFjdCBtYXRjaCBmaXJzdFxuXHRsZXQgYWN0aW9uID0gc2NoZW1hLmNtZFNjaGVtYS5maW5kKChzOiBhbnkpID0+IHMuY21kX2lkID09PSBjbWRJZCAmJiBzLmlkID09PSBzZXR0aW5nSWQpXG5cblx0Ly8gSWYgbm8gZXhhY3QgbWF0Y2gsIHRyeSB0byBmaW5kIGJhc2UgYWN0aW9uIHdpdGggaWRBZGRcblx0aWYgKCFhY3Rpb24pIHtcblx0XHRhY3Rpb24gPSBzY2hlbWEuY21kU2NoZW1hLmZpbmQoKHM6IGFueSkgPT4ge1xuXHRcdFx0aWYgKHMuY21kX2lkICE9PSBjbWRJZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IHMub3B0aW9ucz8uZmluZCgob3B0OiBhbnkpID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmICghaWRBZGRPcHRpb24/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0Ly8gQ2hlY2sgaWYgc2V0dGluZ0lkIG1hdGNoZXMgYmFzZSArIGFueSBpZEFkZCBvZmZzZXRcblx0XHRcdGNvbnN0IG9mZnNldCA9IHNldHRpbmdJZCAtIHMuaWRcblx0XHRcdHJldHVybiBpZEFkZE9wdGlvbi5jaG9pY2VzLnNvbWUoKGM6IGFueSkgPT4gYy5pZCA9PT0gb2Zmc2V0KVxuXHRcdH0pXG5cdH1cblxuXHRyZXR1cm4gYWN0aW9uXG59XG4iLCAiLyoqXG4gKiBidWlsZC1jb21tYW5kcy50c1xuICogLSBVc2VzIGNlbnRyYWxpemVkIGRldmljZSBzY2hlbWEgY2FjaGUgZnJvbSBjb25maWcudHNcbiAqIC0gUHJvZHVjZXMgQ29tcGFuaW9uIGFjdGlvbiBkZWZpbml0aW9ucyBhbmQgZmVlZGJhY2tzXG4gKi9cblxuaW1wb3J0IHtcblx0Q29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbnMsXG5cdENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb24sXG5cdENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbnMsXG5cdGNvbWJpbmVSZ2IsXG59IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBtYWtlU2V0dGluZ0lkIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGdldERldmljZVNjaGVtYXMgfSBmcm9tICcuL2NvbmZpZy5qcydcblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLSBPcHRpb24gQnVpbGRlciAtLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5mdW5jdGlvbiBidWlsZE9wdGlvbihvOiBhbnkpOiBhbnkge1xuXHRjb25zdCBiYXNlID0ge1xuXHRcdHR5cGU6IG8udHlwZSxcblx0XHRpZDogby5pZCxcblx0XHRsYWJlbDogby5sYWJlbCxcblx0XHRkZWZhdWx0OiBvLmRlZmF1bHQsXG5cdFx0dG9vbHRpcDogby50b29sdGlwLFxuXHR9XG5cblx0c3dpdGNoIChvLnR5cGUpIHtcblx0XHRjYXNlICdkcm9wZG93bic6XG5cdFx0XHRyZXR1cm4geyAuLi5iYXNlLCBjaG9pY2VzOiBvLmNob2ljZXMgPz8gW10gfVxuXG5cdFx0Y2FzZSAnbnVtYmVyJzpcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdC4uLmJhc2UsXG5cdFx0XHRcdG1pbjogby5taW4sXG5cdFx0XHRcdG1heDogby5tYXgsXG5cdFx0XHRcdHN0ZXA6IG8uc3RlcCA/PyAxLFxuXHRcdFx0XHRyYW5nZTogdHJ1ZSxcblx0XHRcdH1cblxuXHRcdGNhc2UgJ2NoZWNrYm94Jzpcblx0XHRcdHJldHVybiB7IC4uLmJhc2UsIGRlZmF1bHQ6IG8uZGVmYXVsdCA/PyBmYWxzZSB9XG5cblx0XHRjYXNlICdzdGF0aWMtdGV4dCc6XG5cdFx0XHRyZXR1cm4geyAuLi5iYXNlLCB2YWx1ZTogby52YWx1ZSA/PyAnJyB9XG5cblx0XHRjYXNlICd0ZXh0aW5wdXQnOlxuXHRcdGNhc2UgJ2NvbG9ycGlja2VyJzpcblx0XHRkZWZhdWx0OlxuXHRcdFx0cmV0dXJuIGJhc2Vcblx0fVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tIEFjdGlvbnMgLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG5cbmV4cG9ydCBmdW5jdGlvbiBidWlsZEFjdGlvbnMoKTogQ29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbnMge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdGNvbnN0IGFjdGlvbnM6IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zID0ge31cblxuXHRmb3IgKGNvbnN0IFttb2RlbCwgc2NoZW1hXSBvZiBPYmplY3QuZW50cmllcyhzY2hlbWFzKSkge1xuXHRcdGNvbnN0IGNtZFNjaGVtYSA9IHNjaGVtYS5jbWRTY2hlbWFcblx0XHRpZiAoIUFycmF5LmlzQXJyYXkoY21kU2NoZW1hKSkgY29udGludWVcblxuXHRcdGZvciAoY29uc3QgYSBvZiBjbWRTY2hlbWEpIHtcblx0XHRcdC8vIFNraXAgcmVhZC1vbmx5IGVudHJpZXMgXHUyMDE0IHRoZXkgYXJlIGZlZWRiYWNrLW9ubHkgKGluZGljYXRvcnMsIHN0YXR1cylcblx0XHRcdGlmIChhLnJlYWRvbmx5ID09PSB0cnVlKSBjb250aW51ZVxuXG5cdFx0XHRjb25zdCBhY3Rpb25JZCA9IG1ha2VTZXR0aW5nSWQobW9kZWwsIGEuY21kX2lkLCBhLmlkKVxuXG5cdFx0XHRjb25zdCBvcHRpb25zID0gKGEub3B0aW9ucyA/PyBbXSkubWFwKGJ1aWxkT3B0aW9uKVxuXG5cdFx0XHRjb25zdCBhY3Rpb246IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb24gPSB7XG5cdFx0XHRcdG5hbWU6IGBbTW9kZWwke21vZGVsfV0gJHthLm5hbWV9YCxcblx0XHRcdFx0b3B0aW9ucyxcblx0XHRcdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVBY3Rpb25zICovXG5cdFx0XHRcdH0sXG5cdFx0XHR9XG5cblx0XHRcdGFjdGlvbnNbYWN0aW9uSWRdID0gYWN0aW9uXG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIGFjdGlvbnNcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBGZWVkYmFja3MgLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG4vKipcbiAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgdmFsdWUgb3B0aW9uIG9mIGEgc2NoZW1hIGVudHJ5IGlzIGEgc2ltcGxlIE9mZi9PbiBkcm9wZG93blxuICogKGV4YWN0bHkgdHdvIGNob2ljZXMsIG9uZSBsYWJlbGxlZCBcIk9mZlwiIGFuZCBvbmUgbGFiZWxsZWQgXCJPblwiKS5cbiAqL1xuZnVuY3Rpb24gaXNPbk9mZkRyb3Bkb3duKHNldHRpbmc6IGFueSk6IGJvb2xlYW4ge1xuXHRjb25zdCB2YWx1ZU9wdCA9IHNldHRpbmcub3B0aW9ucz8uZmluZCgobzogYW55KSA9PiBvLmlkID09PSAndmFsdWUnKVxuXHRpZiAoIXZhbHVlT3B0IHx8IHZhbHVlT3B0LnR5cGUgIT09ICdkcm9wZG93bicgfHwgIUFycmF5LmlzQXJyYXkodmFsdWVPcHQuY2hvaWNlcykpIHJldHVybiBmYWxzZVxuXHRpZiAodmFsdWVPcHQuY2hvaWNlcy5sZW5ndGggIT09IDIpIHJldHVybiBmYWxzZVxuXHRjb25zdCBsYWJlbHMgPSB2YWx1ZU9wdC5jaG9pY2VzLm1hcCgoYzogYW55KSA9PiBTdHJpbmcoYy5sYWJlbCkudG9Mb3dlckNhc2UoKSlcblx0cmV0dXJuIGxhYmVscy5pbmNsdWRlcygnb2ZmJykgJiYgbGFiZWxzLmluY2x1ZGVzKCdvbicpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBidWlsZEZlZWRiYWNrcygpOiBDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCBmZWVkYmFja3M6IENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbnMgPSB7fVxuXG5cdGZvciAoY29uc3QgW21vZGVsLCBzY2hlbWFdIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYXMpKSB7XG5cdFx0Y29uc3QgY21kU2NoZW1hID0gc2NoZW1hLmNtZFNjaGVtYVxuXHRcdGlmICghQXJyYXkuaXNBcnJheShjbWRTY2hlbWEpKSBjb250aW51ZVxuXG5cdFx0Zm9yIChjb25zdCBzZXR0aW5nIG9mIGNtZFNjaGVtYSkge1xuXHRcdFx0Ly8gU2tpcCB3cml0ZS1vbmx5IGVudHJpZXMgXHUyMDE0IHRoZXkgYXJlIGFjdGlvbi1vbmx5IChkZXZpY2UgbmV2ZXIgcmVwb3J0cyB2YWx1ZSBiYWNrKVxuXHRcdFx0aWYgKHNldHRpbmcud3JpdGVvbmx5ID09PSB0cnVlKSBjb250aW51ZVxuXG5cdFx0XHRjb25zdCBiYXNlRmVlZGJhY2tJZCA9IG1ha2VTZXR0aW5nSWQobW9kZWwsIHNldHRpbmcuY21kX2lkLCBzZXR0aW5nLmlkKVxuXG5cdFx0XHQvLyBCdWlsZCBvcHRpb25zXG5cdFx0XHRjb25zdCBhbGxPcHRpb25zID0gKHNldHRpbmcub3B0aW9ucyA/PyBbXSkubWFwKGJ1aWxkT3B0aW9uKVxuXG5cdFx0XHQvLyBGaWx0ZXIgb3V0ICd2YWx1ZScgb3B0aW9uIGZvciB2YWx1ZSBmZWVkYmFjayAoa2VlcCBvbmx5IGJ1c0NoL2lkQWRkKVxuXHRcdFx0Y29uc3QgdmFsdWVPcHRpb25zID0gYWxsT3B0aW9ucy5maWx0ZXIoKG9wdDogYW55KSA9PiBvcHQuaWQgIT09ICd2YWx1ZScpXG5cblx0XHRcdC8vIEFkZCBhIGNoZWNrYm94IG9wdGlvbiB0byByZXR1cm4gbGFiZWwgaW5zdGVhZCBvZiB2YWx1ZVxuXHRcdFx0dmFsdWVPcHRpb25zLnB1c2goe1xuXHRcdFx0XHR0eXBlOiAnY2hlY2tib3gnLFxuXHRcdFx0XHRpZDogJ3Nob3dMYWJlbCcsXG5cdFx0XHRcdGxhYmVsOiAnU2hvdyBMYWJlbCcsXG5cdFx0XHRcdGRlZmF1bHQ6IGZhbHNlLFxuXHRcdFx0XHR0b29sdGlwOiAnUmV0dXJuIHRoZSBsYWJlbCB0ZXh0IGluc3RlYWQgb2YgdGhlIG51bWVyaWMgdmFsdWUnLFxuXHRcdFx0fSlcblxuXHRcdFx0Ly8gVmFsdWUgZmVlZGJhY2sgZm9yIGFsbCBzZXR0aW5ncyAoYXBwZWFycyBpbiBWYXJpYWJsZXMgbGlzdClcblx0XHRcdGNvbnN0IHZhbHVlRmVlZGJhY2s6IGFueSA9IHtcblx0XHRcdFx0dHlwZTogJ3ZhbHVlJyxcblx0XHRcdFx0bmFtZTogYFtNb2RlbCR7bW9kZWx9XSAke3NldHRpbmcubmFtZX1gLFxuXHRcdFx0XHRvcHRpb25zOiB2YWx1ZU9wdGlvbnMsXG5cdFx0XHRcdGNhbGxiYWNrOiAoKSA9PiB7XG5cdFx0XHRcdFx0Lyogd2lyZWQgbGF0ZXIgaW4gVXBkYXRlRmVlZGJhY2tzICovXG5cdFx0XHRcdFx0cmV0dXJuIDBcblx0XHRcdFx0fSxcblx0XHRcdH1cblxuXHRcdFx0Ly8gQm9vbGVhbiBmZWVkYmFjayBmb3IgT2ZmL09uIGRyb3Bkb3ducyBcdTIwMTQgcmVwbGFjZXMgdGhlIHZhbHVlIGZlZWRiYWNrXG5cdFx0XHRpZiAoaXNPbk9mZkRyb3Bkb3duKHNldHRpbmcpKSB7XG5cdFx0XHRcdGNvbnN0IGJvb2xGZWVkYmFja0lkID0gYCR7YmFzZUZlZWRiYWNrSWR9X2Jvb2xgXG5cblx0XHRcdFx0Ly8gT3B0aW9ucyB3aXRob3V0ICd2YWx1ZScgKGJ1c0NoL2lkQWRkIHNlbGVjdG9ycyBvbmx5LCBpZiBwcmVzZW50KVxuXHRcdFx0XHRjb25zdCBib29sT3B0aW9ucyA9IGFsbE9wdGlvbnMuZmlsdGVyKChvcHQ6IGFueSkgPT4gb3B0LmlkICE9PSAndmFsdWUnKVxuXG5cdFx0XHRcdGNvbnN0IGJvb2xGZWVkYmFjazogYW55ID0ge1xuXHRcdFx0XHRcdHR5cGU6ICdib29sZWFuJyxcblx0XHRcdFx0XHRuYW1lOiBgW01vZGVsJHttb2RlbH1dICR7c2V0dGluZy5uYW1lfSBcdTIwMTQgSXMgT25gLFxuXHRcdFx0XHRcdGRlZmF1bHRTdHlsZToge1xuXHRcdFx0XHRcdFx0Ymdjb2xvcjogY29tYmluZVJnYigwLCAyMDAsIDApLFxuXHRcdFx0XHRcdFx0Y29sb3I6IGNvbWJpbmVSZ2IoMCwgMCwgMCksXG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0XHRvcHRpb25zOiBib29sT3B0aW9ucyxcblx0XHRcdFx0XHRjYWxsYmFjazogKCkgPT4ge1xuXHRcdFx0XHRcdFx0Lyogd2lyZWQgbGF0ZXIgaW4gVXBkYXRlRmVlZGJhY2tzICovXG5cdFx0XHRcdFx0XHRyZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHR9XG5cblx0XHRcdFx0ZmVlZGJhY2tzW2Jvb2xGZWVkYmFja0lkXSA9IGJvb2xGZWVkYmFja1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0ZmVlZGJhY2tzW2Jhc2VGZWVkYmFja0lkXSA9IHZhbHVlRmVlZGJhY2tcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHRyZXR1cm4gZmVlZGJhY2tzXG59XG4iLCAiaW1wb3J0IE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcbmltcG9ydCB7IGJ1aWxkQWN0aW9ucyB9IGZyb20gJy4vYnVpbGQtY29tbWFuZHMuanMnXG5pbXBvcnQgeyBnZXREZXZpY2VzRm9sZGVyLCBnZXREZXZpY2VTY2hlbWEsIGdldERldmljZVNjaGVtYXMsIHJlbG9hZERldmljZVNjaGVtYXMgfSBmcm9tICcuL2NvbmZpZy5qcydcbmltcG9ydCB7IHBhcnNlU2V0dGluZ0lkLCBnZXROb3JtYWxpemVkU2NoZW1hcyB9IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCdcblxuaW1wb3J0IHsgcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24sIHNhdmVNb2RlbEpzb25QcmV0dHksIHVwZGF0ZU1vZGVsSnNvbkZyb21TZXR0aW5ncyB9IGZyb20gJy4vc2V0dGluZ3NQYXJzZXIuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignQWN0aW9ucycpXG5cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVBY3Rpb25zKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IHNjaGVtYXNSYXcgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgcmF3QWN0aW9ucyA9IGJ1aWxkQWN0aW9ucygpXG5cdGNvbnN0IHNjaGVtYXMgPSBnZXROb3JtYWxpemVkU2NoZW1hcyhzY2hlbWFzUmF3KVxuXHRjb25zdCB3aXJlZEFjdGlvbnM6IGFueSA9IHt9XG5cblx0Y29uc3QgYWN0aXZlTW9kZWwgPSBzZWxmLmFjdGl2ZU1vZGVsXG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBHTE9CQUw6IEdFVCBBTEwgU0VUVElOR1MgKEFVVE8gSlNPTiBVUERBVEUpIFx1MjAxNCBEZXYgTW9kZSBvbmx5XG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdGlmIChzZWxmLmNvbmZpZy5kZXZNb2RlKSB7XG5cdFx0d2lyZWRBY3Rpb25zWydnbG9iYWxfZ2V0QWxsU2V0dGluZ3MnXSA9IHtcblx0XHRcdG5hbWU6ICdHTE9CQUw6IEdldCBBbGwgU2V0dGluZ3MnLFxuXHRcdFx0ZGVzY3JpcHRpb246ICdVc2UgdGhpcyB0byBjcmVhdGUgYSBzY2hlbWEgZm9yIGEgbmV3IGRldmljZScsXG5cdFx0XHRvcHRpb25zOiBbXSxcblx0XHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdGNvbnN0IG1vZGVsID0gYWN0aXZlTW9kZWxcblx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3RcblxuXHRcdFx0XHRjb25zdCBidWYgPSBhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5yZXF1ZXN0QWxsU2V0dGluZ3MoaXApXG5cblx0XHRcdFx0bGV0IG1vZGVsSnNvbiA9IGdldERldmljZVNjaGVtYShtb2RlbClcblxuXHRcdFx0XHRjb25zdCB7IHNldHRpbmdzOiBwYXJzZWQsIGRldGVjdGVkU2VjdGlvbmVkIH0gPSBwYXJzZUdldEFsbFNldHRpbmdzV2l0aERldGVjdGlvbihtb2RlbCwgYnVmKVxuXHRcdFx0XHRsb2dnZXIuZGVidWcoYHBhcnNlZCByZXBseTogJHtKU09OLnN0cmluZ2lmeShwYXJzZWQpfWApXG5cblx0XHRcdFx0aWYgKCFtb2RlbEpzb24pIHtcblx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgTW9kZWwgJHttb2RlbH0gaGFzIG5vIHNjaGVtYSBcdTIwMTQgY3JlYXRpbmcgbmV3IEpTT04gZnJvbSBzZXR0aW5nc2ApXG5cdFx0XHRcdFx0bW9kZWxKc29uID0ge1xuXHRcdFx0XHRcdFx0bW9kZWwsXG5cdFx0XHRcdFx0XHRzZWN0aW9uZWQ6IGRldGVjdGVkU2VjdGlvbmVkID8/IGZhbHNlLFxuXHRcdFx0XHRcdFx0Y21kU2NoZW1hOiBbXSxcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gZWxzZSBpZiAoZGV0ZWN0ZWRTZWN0aW9uZWQgIT09IG51bGwpIHtcblx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgQXV0by1kZXRlY3RlZCBzZWN0aW9uZWQ9JHtkZXRlY3RlZFNlY3Rpb25lZH0sIGFkZGluZyB0byBtb2RlbCBKU09OYClcblx0XHRcdFx0XHRtb2RlbEpzb24gPSB7IC4uLm1vZGVsSnNvbiwgc2VjdGlvbmVkOiBkZXRlY3RlZFNlY3Rpb25lZCB9XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRjb25zdCB1cGRhdGVkID0gdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzKG1vZGVsSnNvbiwgcGFyc2VkLCBzY2hlbWFzKVxuXHRcdFx0XHRsb2dnZXIuZGVidWcoYG5ldyBBY3Rpb25zIGpzb246ICR7SlNPTi5zdHJpbmdpZnkodXBkYXRlZCwgbnVsbCwgMil9YClcblxuXHRcdFx0XHRjb25zdCBkZXZpY2VzRm9sZGVyID0gZ2V0RGV2aWNlc0ZvbGRlcigpXG5cdFx0XHRcdGNvbnN0IHNjaGVtYVBhdGggPSBwYXRoLmpvaW4oZGV2aWNlc0ZvbGRlciwgYE1vZGVsJHttb2RlbH0uanNvbmApXG5cdFx0XHRcdHNhdmVNb2RlbEpzb25QcmV0dHkoc2NoZW1hUGF0aCwgdXBkYXRlZClcblxuXHRcdFx0XHRyZWxvYWREZXZpY2VTY2hlbWFzKClcblxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgTW9kZWwgJHttb2RlbH0gSlNPTiBhdXRvLXVwZGF0ZWQgZnJvbSBnZXRBbGxTZXR0aW5nc2ApXG5cdFx0XHR9LFxuXHRcdH1cblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgQlVJTEQgUEVSLVNFVFRJTkcgQUNUSU9OUyAoRklMVEVSRUQgQlkgQUNUSVZFIE1PREVMKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHRmb3IgKGNvbnN0IFthY3Rpb25JZCwgYWN0aW9uXSBvZiBPYmplY3QuZW50cmllcyhyYXdBY3Rpb25zKSkge1xuXHRcdGNvbnN0IHsgbW9kZWwsIGNtZElkLCBiYXNlSWQgfSA9IHBhcnNlU2V0dGluZ0lkKGFjdGlvbklkKVxuXG5cdFx0Ly8gT25seSBpbmNsdWRlIGFjdGlvbnMgZm9yIHRoZSBjdXJyZW50bHkgYWN0aXZlIG1vZGVsXG5cdFx0aWYgKG1vZGVsICE9PSBhY3RpdmVNb2RlbCkgY29udGludWVcblxuXHRcdC8vIEdldCB0aGUgcmF3IGFjdGlvbiBzY2hlbWEgdG8gYWNjZXNzIGZpeGVkIGJ1c0NoIHZhbHVlXG5cdFx0Y29uc3Qgc2NoZW1hID0gc2NoZW1hc1ttb2RlbF1cblx0XHRjb25zdCByYXdBY3Rpb24gPSBzY2hlbWE/LmNtZFNjaGVtYT8uZmluZCgoYTogYW55KSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gYmFzZUlkKVxuXG5cdFx0d2lyZWRBY3Rpb25zW2FjdGlvbklkXSA9IHtcblx0XHRcdC4uLmFjdGlvbixcblx0XHRcdGNhbGxiYWNrOiBhc3luYyAoZXZlbnQ6IGFueSkgPT4ge1xuXHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXHRcdFx0XHRjb25zdCBidXNDaCA9IGV2ZW50Lm9wdGlvbnNbJ2J1c0NoJ10gIT09IHVuZGVmaW5lZCA/IGV2ZW50Lm9wdGlvbnNbJ2J1c0NoJ10gOiByYXdBY3Rpb24/LmJ1c0NoXG5cdFx0XHRcdGNvbnN0IHZhbHVlID0gZXZlbnQub3B0aW9uc1sndmFsdWUnXVxuXHRcdFx0XHRjb25zdCBpZEFkZCA9IGV2ZW50Lm9wdGlvbnNbJ2lkQWRkJ10gPz8gMFxuXHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBiYXNlSWQgKyBpZEFkZFxuXG5cdFx0XHRcdGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLnNlbmRBd2FpdEFjayhjbWRJZCwgYnVzQ2gsIHNldHRpbmdJZCwgdmFsdWUsIGlwKVxuXHRcdFx0fSxcblx0XHR9XG5cdH1cblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IE1JQyBLSUxMIChPTkxZIElGIEFDVElWRSBNT0RFTCBTVVBQT1JUUyBJVClcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdGNvbnN0IGFjdGl2ZVNjaGVtYSA9IHNjaGVtYXNbYWN0aXZlTW9kZWxdXG5cdGlmIChhY3RpdmVTY2hlbWEpIHtcblx0XHRjb25zdCBzdXBwb3J0c01pY0tpbGwgPSAoYWN0aXZlU2NoZW1hLmNtZFNjaGVtYSA/PyBbXSkuc29tZSgoYTogYW55KSA9PiBhLm5hbWUuaW5jbHVkZXMoJ0tpbGwnKSlcblxuXHRcdGlmIChzdXBwb3J0c01pY0tpbGwpIHtcblx0XHRcdGNvbnN0IGFjdGlvbklkID0gYCR7YWN0aXZlTW9kZWx9X21pY0tpbGxgXG5cblx0XHRcdHdpcmVkQWN0aW9uc1thY3Rpb25JZF0gPSB7XG5cdFx0XHRcdG5hbWU6IGBbTW9kZWwke2FjdGl2ZU1vZGVsfV0gTWljIEtpbGxgLFxuXHRcdFx0XHRvcHRpb25zOiBbXSxcblx0XHRcdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXHRcdFx0XHRcdGxvZ2dlci5pbmZvKGBNaWMgS2lsbCBcdTIxOTIgTW9kZWwgJHthY3RpdmVNb2RlbH0gQCAke2lwfWApXG5cdFx0XHRcdFx0YXdhaXQgc2VsZi5zdENvbnRyb2xsZXIuZ2xvYmFsTWljS2lsbChpcClcblx0XHRcdFx0XHRhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5yZXF1ZXN0QWxsU2V0dGluZ3MoaXApLmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gcmVmcmVzaCBzZXR0aW5ncyBhZnRlciBjb21tYW5kOiAke2Vycn1gKVxuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdH0sXG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cblx0c2VsZi5zZXRBY3Rpb25EZWZpbml0aW9ucyh3aXJlZEFjdGlvbnMpXG5cblx0Ly9jb25zb2xlLmxvZygnQWN0aW9uczpcXG4nLCBKU09OLnN0cmluZ2lmeSh3aXJlZEFjdGlvbnMsIG51bGwsIDIpKVxufVxuIiwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCB7IGdldERldmljZVNjaGVtYSB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7XG5cdENNRF9NSUNfUFJFLFxuXHRDTURfQlVTX1NFVCxcblx0Q01EX0NIQU5ORUwsXG5cdENNRF9ERVZfU1BFQyxcblx0Q01EX0dFVF9BTExfU0VUVElOR1MsXG5cdENNRF9NSUNfUFJFX0JVUyxcblx0Q01EX1NFVFRJTkdTX1BVU0gsXG5cdHRvSGV4LFxuXHRieXRlc1RvSGV4LFxuXHRmb3JtYXRSZ2JDb2xvcixcblx0bW9kZWxEaXN0YW5jZSxcbn0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdTZXR0aW5nc1BhcnNlcicpXG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFRZUEVTXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCB0eXBlIFBhcnNlZFNldHRpbmcgPSB7XG5cdGNtZF9pZDogbnVtYmVyXG5cdGlkOiBudW1iZXJcblx0YnVzQ2g/OiBudW1iZXIgLy8gT3B0aW9uYWw6IG9ubHkgcHJlc2VudCBmb3IgY29tbWFuZHMgd2l0aCBidXNDaCAoMHgwNCwgMHgxMiwgMHgxNClcblx0dmFsdWVCeXRlczogbnVtYmVyW11cbn1cblxuZXhwb3J0IHR5cGUgU3RBY3Rpb25PcHRpb24gPSB7XG5cdGlkPzogc3RyaW5nXG5cdGxhYmVsOiBzdHJpbmdcblx0dHlwZTogc3RyaW5nXG5cdGRlZmF1bHQ6IHVua25vd25cblx0dG9vbHRpcD86IHN0cmluZ1xuXHRjaG9pY2VzPzogQXJyYXk8eyBpZDogbnVtYmVyOyBsYWJlbDogc3RyaW5nIH0+XG59XG5cbmV4cG9ydCB0eXBlIFN0QWN0aW9uID0ge1xuXHRjbWRfaWQ6IG51bWJlclxuXHRpZDogbnVtYmVyXG5cdG5hbWU6IHN0cmluZ1xuXHRvcHRpb25zOiBTdEFjdGlvbk9wdGlvbltdXG5cdGJ1c0NoPzogbnVtYmVyIC8vIEZpeGVkIGNoYW5uZWwgdmFsdWUgZm9yIGFjdGlvbnMgdGhhdCBkb24ndCBoYXZlIGEgY2hhbm5lbCBvcHRpb25cblx0cmVhZG9ubHk/OiBib29sZWFuIC8vIElmIHRydWUsIGVudHJ5IGlzIGZlZWRiYWNrLW9ubHkgXHUyMDE0IG5vIGFjdGlvbiB3aWxsIGJlIGNyZWF0ZWRcblx0d3JpdGVvbmx5PzogYm9vbGVhbiAvLyBJZiB0cnVlLCBlbnRyeSBpcyBhY3Rpb24tb25seSBcdTIwMTQgbm8gZmVlZGJhY2sgd2lsbCBiZSBjcmVhdGVkIChkZXZpY2UgbmV2ZXIgcmVwb3J0cyB0aGlzIHZhbHVlIGJhY2spXG59XG5cbmV4cG9ydCB0eXBlIFN0TW9kZWxKc29uID0ge1xuXHRtb2RlbDogc3RyaW5nXG5cdHNlY3Rpb25lZD86IGJvb2xlYW5cblx0Y21kU2NoZW1hOiBTdEFjdGlvbltdXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZPUk1BVCBIRUxQRVJTXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIGdldE1vZGVsQ29uZmlnKG1vZGVsOiBzdHJpbmcpOiB7IHNlY3Rpb25lZDogYm9vbGVhbjsgcmdiSWRzOiBTZXQ8bnVtYmVyPiB9IHtcblx0Y29uc3QgcmdiSWRzID0gbmV3IFNldDxudW1iZXI+KClcblx0bGV0IHNlY3Rpb25lZCA9IGZhbHNlXG5cblx0dHJ5IHtcblx0XHQvLyBVc2UgY2VudHJhbGl6ZWQgY2FjaGUgaW5zdGVhZCBvZiByZWFkaW5nIGZyb20gZGlza1xuXHRcdGNvbnN0IGpzb24gPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdFx0aWYgKCFqc29uKSB7XG5cdFx0XHQvLyBJZiB3ZSBjYW4ndCBsb2FkIHRoZSBzY2hlbWEsIHJldHVybiBkZWZhdWx0c1xuXHRcdFx0cmV0dXJuIHsgc2VjdGlvbmVkLCByZ2JJZHMgfVxuXHRcdH1cblxuXHRcdC8vIFJlYWQgc2VjdGlvbmVkIHByb3BlcnR5IChkZWZhdWx0IHRvIGZhbHNlIGlmIG5vdCBzcGVjaWZpZWQpXG5cdFx0c2VjdGlvbmVkID0ganNvbi5zZWN0aW9uZWQgPz8gZmFsc2VcblxuXHRcdC8vIEJ1aWxkIFJHQiBJRHMgc2V0XG5cdFx0Zm9yIChjb25zdCBhY3Rpb24gb2YganNvbi5jbWRTY2hlbWEgfHwgW10pIHtcblx0XHRcdGNvbnN0IGhhc0NvbG9ycGlja2VyID0gYWN0aW9uLm9wdGlvbnM/LnNvbWUoKG9wdDogU3RBY3Rpb25PcHRpb24pID0+IG9wdC50eXBlID09PSAnY29sb3JwaWNrZXInKVxuXHRcdFx0aWYgKGhhc0NvbG9ycGlja2VyKSB7XG5cdFx0XHRcdC8vIEFkZCB0aGUgYmFzZSBJRFxuXHRcdFx0XHRyZ2JJZHMuYWRkKGFjdGlvbi5pZClcblxuXHRcdFx0XHQvLyBJZiB0aGlzIGFjdGlvbiBoYXMgaWRBZGQgY2hvaWNlcywgYWRkIGFsbCB0aGUgb2Zmc2V0IElEcyB0b29cblx0XHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgob3B0OiBTdEFjdGlvbk9wdGlvbikgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRpZiAoaWRBZGRPcHRpb24/LmNob2ljZXMpIHtcblx0XHRcdFx0XHRmb3IgKGNvbnN0IGNob2ljZSBvZiBpZEFkZE9wdGlvbi5jaG9pY2VzKSB7XG5cdFx0XHRcdFx0XHRpZiAodHlwZW9mIGNob2ljZS5pZCA9PT0gJ251bWJlcicpIHtcblx0XHRcdFx0XHRcdFx0cmdiSWRzLmFkZChhY3Rpb24uaWQgKyBjaG9pY2UuaWQpXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHR9IGNhdGNoIChfZXJyKSB7XG5cdFx0Ly8gSWYgd2UgY2FuJ3QgbG9hZCB0aGUgc2NoZW1hLCByZXR1cm4gZGVmYXVsdHNcblx0fVxuXG5cdHJldHVybiB7IHNlY3Rpb25lZCwgcmdiSWRzIH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgRklORCBUSEUgUkVBTCA1QSBQQVlMT0FEIElOREVYXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIGV4dHJhY3RTdFBheWxvYWRJbmRleChidWY6IEJ1ZmZlcik6IG51bWJlciB7XG5cdGNvbnN0IHNpZ0luZGV4ID0gYnVmLmluZGV4T2YoQnVmZmVyLmZyb20oJ1N0dWRpby1UJykpXG5cdGlmIChzaWdJbmRleCA8IDApIHRocm93IG5ldyBFcnJvcignTm8gU3R1ZGlvLVQgc2lnbmF0dXJlIGluIHBhY2tldCcpXG5cblx0Y29uc3QgcGF5bG9hZEluZGV4ID0gc2lnSW5kZXggKyA4XG5cdGlmIChidWZbcGF5bG9hZEluZGV4XSAhPT0gMHg1YSkge1xuXHRcdHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgMHg1QSBhZnRlciBTdHVkaW8tVCwgZm91bmQgJHtidWZbcGF5bG9hZEluZGV4XS50b1N0cmluZygxNil9YClcblx0fVxuXG5cdHJldHVybiBwYXlsb2FkSW5kZXhcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgRkxBVCBQQVJTRVJcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZnVuY3Rpb24gcGFyc2VGbGF0SWRWYWxTZXF1ZW5jZShibG9jazogQnVmZmVyLCByZ2JJZHM6IFNldDxudW1iZXI+ID0gbmV3IFNldCgpKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0bGV0IHAgPSAwXG5cdGNvbnN0IG91dDogUGFyc2VkU2V0dGluZ1tdID0gW11cblxuXHR3aGlsZSAocCA8IGJsb2NrLmxlbmd0aCkge1xuXHRcdGNvbnN0IGlkID0gYmxvY2tbcF1cblx0XHRpZiAocCArIDEgPj0gYmxvY2subGVuZ3RoKSBicmVha1xuXG5cdFx0Ly8gUkdCIGNhc2UgLSBjaGVjayBpZiB0aGlzIElEIGlzIGEga25vd24gY29sb3JwaWNrZXJcblx0XHRpZiAocmdiSWRzLmhhcyhpZCkgJiYgcCArIDMgPCBibG9jay5sZW5ndGgpIHtcblx0XHRcdG91dC5wdXNoKHtcblx0XHRcdFx0Y21kX2lkOiBDTURfREVWX1NQRUMsXG5cdFx0XHRcdGlkLFxuXHRcdFx0XHR2YWx1ZUJ5dGVzOiBbYmxvY2tbcCArIDFdLCBibG9ja1twICsgMl0sIGJsb2NrW3AgKyAzXV0sXG5cdFx0XHR9KVxuXHRcdFx0cCArPSA0XG5cdFx0XHRjb250aW51ZVxuXHRcdH1cblxuXHRcdG91dC5wdXNoKHsgY21kX2lkOiBDTURfREVWX1NQRUMsIGlkLCB2YWx1ZUJ5dGVzOiBbYmxvY2tbcCArIDFdXSB9KVxuXHRcdHAgKz0gMlxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZjogQnVmZmVyLCBtb2RlbDogc3RyaW5nKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0Y29uc3QgaWR4ID0gZXh0cmFjdFN0UGF5bG9hZEluZGV4KGJ1Zilcblx0Y29uc3QgY21kSWQgPSBidWZbaWR4ICsgMV0gJiAweDdmXG5cdGlmIChjbWRJZCAhPT0gQ01EX0dFVF9BTExfU0VUVElOR1MgJiYgY21kSWQgIT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKCdOb3QgYSBnZXRBbGxTZXR0aW5ncyByZXBseScpXG5cdH1cblxuXHRjb25zdCBibG9ja0xlbiA9IGJ1ZltpZHggKyAyXVxuXHRjb25zdCBzdGFydCA9IGlkeCArIDNcblx0Y29uc3QgZW5kID0gc3RhcnQgKyBibG9ja0xlblxuXHRpZiAoZW5kID4gYnVmLmxlbmd0aCkgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIGJsb2NrIGxlbmd0aCcpXG5cblx0Y29uc3QgeyByZ2JJZHMgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXHRyZXR1cm4gcGFyc2VGbGF0SWRWYWxTZXF1ZW5jZShidWYuc3ViYXJyYXkoc3RhcnQsIGVuZCksIHJnYklkcylcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgU0VDVElPTkVEIFBBUlNFUlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmOiBCdWZmZXIsIG1vZGVsOiBzdHJpbmcpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRjb25zdCBpZHggPSBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmKVxuXHRjb25zdCBjbWRJZCA9IGJ1ZltpZHggKyAxXSAmIDB4N2Zcblx0aWYgKGNtZElkICE9PSBDTURfR0VUX0FMTF9TRVRUSU5HUyAmJiBjbWRJZCAhPT0gQ01EX1NFVFRJTkdTX1BVU0gpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoJ05vdCBhIGdldEFsbFNldHRpbmdzIHJlcGx5Jylcblx0fVxuXG5cdC8vIENNRF9HRVRfQUxMX1NFVFRJTkdTIGhhcyBhIHRvdGFsLWxlbmd0aCBieXRlIGF0IGlkeCsyIGJlZm9yZSB0aGUgc2VjdGlvbnM7IENNRF9TRVRUSU5HU19QVVNIIGRvZXMgbm90LlxuXHRsZXQgcCA9IGNtZElkID09PSBDTURfR0VUX0FMTF9TRVRUSU5HUyA/IGlkeCArIDMgOiBpZHggKyAyXG5cdGNvbnN0IGVuZCA9IGJ1Zi5sZW5ndGggLSAxXG5cdGNvbnN0IG91dDogUGFyc2VkU2V0dGluZ1tdID0gW11cblxuXHQvLyBHZXQgUkdCIElEcyBmb3IgdGhpcyBtb2RlbFxuXHRjb25zdCB7IHJnYklkcyB9ID0gZ2V0TW9kZWxDb25maWcobW9kZWwpXG5cblx0Ly8gQ29tbWFuZCBJRHMgdGhhdCBpbmNsdWRlIGEgYnVzQ2ggYnl0ZSBpbiB0aGVpciBzZWN0aW9uIHN0cnVjdHVyZSxcblx0Ly8gZm9sbG93ZWQgYnkgYSBkYXRhTGVuIGJ5dGUgYW5kIHRoZW4gaWQ6dmFsIHBhaXJzLlxuXHRjb25zdCBjb21tYW5kc1dpdGhCdXNDaCA9IFtDTURfQlVTX1NFVCwgQ01EX01JQ19QUkVfQlVTLCBDTURfQ0hBTk5FTF1cblxuXHQvLyBDb21tYW5kIElEcyB0aGF0IGluY2x1ZGUgYSBidXNDaCBieXRlIGJ1dCBzdG9yZSByYXcgcG9zaXRpb25hbCB2YWx1ZSBieXRlc1xuXHQvLyByYXRoZXIgdGhhbiBpZDp2YWwgcGFpcnMgKG5vIGRhdGFMZW4gYnl0ZSwgbm8gc2V0dGluZyBJRHMpLlxuXHQvLyBGb3JtYXQ6IFtjbWRMZW5dIFtjbWRJZF0gW2J1c0NoXSBbdmFsMF0gW3ZhbDFdIC4uLlxuXHRjb25zdCBjb21tYW5kc1Jhd1ZhbHVlID0gW0NNRF9NSUNfUFJFXSAvLyBjbWQ9MHgwMlxuXG5cdHdoaWxlIChwICsgMiA8IGVuZCkge1xuXHRcdGNvbnN0IGNtZExlbiA9IGJ1ZltwXVxuXHRcdGNvbnN0IHNlY3Rpb25DbWRJZCA9IGJ1ZltwICsgMV1cblxuXHRcdGNvbnN0IHNlY3Rpb25FbmQgPSBwICsgMSArIGNtZExlblxuXHRcdGlmIChzZWN0aW9uRW5kID4gZW5kKSBicmVha1xuXG5cdFx0Y29uc3QgaGFzQnVzQ2ggPSBjb21tYW5kc1dpdGhCdXNDaC5pbmNsdWRlcyhzZWN0aW9uQ21kSWQpXG5cdFx0Y29uc3QgaXNSYXdWYWx1ZSA9IGNvbW1hbmRzUmF3VmFsdWUuaW5jbHVkZXMoc2VjdGlvbkNtZElkKVxuXG5cdFx0bGV0IGJ1c0NoOiBudW1iZXIgfCB1bmRlZmluZWRcblx0XHRsZXQgZGF0YUxlbjogbnVtYmVyXG5cdFx0bGV0IHE6IG51bWJlclxuXG5cdFx0aWYgKGlzUmF3VmFsdWUpIHtcblx0XHRcdC8vIFN0cnVjdHVyZTogW2NtZExlbl0gW2NtZElkXSBbYnVzQ2hdIFt2YWwwXSBbdmFsMV0gLi4uXG5cdFx0XHQvLyBCdWlsZCBwb3NpdGlvbmFsIG1hcCBmcm9tIHNjaGVtYTogZmluZCBhbGwgZW50cmllcyBmb3IgQ01EX01JQ19QUkUgKDB4MDIpIG9yXG5cdFx0XHQvLyBDTURfTUlDX1BSRV9CVVMgKDB4MTIpIHdpdGggYSBmaXhlZCBidXNDaCwgc29ydGVkIGJ5IGlkIFx1MjAxNCBlYWNoIGJlY29tZXMgb25lXG5cdFx0XHQvLyBwb3NpdGlvbmFsIHNsb3QuIFRoaXMgbWFrZXMgdGhlIHJlbWFwIHNjaGVtYS1kcml2ZW46XG5cdFx0XHQvLyAgIDIxNCAgKGNtZF9pZD0yLCAgaWQ9MC8xKSBcdTIxOTIgcG9zMFx1MjE5MigyLDApLCAgcG9zMVx1MjE5MigyLDEpXG5cdFx0XHQvLyAgIDIxNEEgKGNtZF9pZD0xOCwgaWQ9MS8yKSBcdTIxOTIgcG9zMFx1MjE5MigxOCwxKSwgcG9zMVx1MjE5MigxOCwyKVxuXHRcdFx0Ly8gUG9zaXRpb25zIHdpdGggbm8gc2NoZW1hIGVudHJ5IGFyZSBkcm9wcGVkIChlLmcuIHVua25vd24gM3JkIGJ5dGUpLlxuXHRcdFx0YnVzQ2ggPSBidWZbcCArIDJdXG5cdFx0XHRjb25zdCByYXdCeXRlcyA9IGJ1Zi5zdWJhcnJheShwICsgMywgc2VjdGlvbkVuZClcblxuXHRcdFx0Y29uc3Qgc2NoZW1hID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRcdFx0Y29uc3QgbWljUHJlRW50cmllcyA9IChzY2hlbWE/LmNtZFNjaGVtYSA/PyBbXSlcblx0XHRcdFx0LmZpbHRlcigoYTogU3RBY3Rpb24pID0+IChhLmNtZF9pZCA9PT0gQ01EX01JQ19QUkUgfHwgYS5jbWRfaWQgPT09IENNRF9NSUNfUFJFX0JVUykgJiYgYS5idXNDaCAhPT0gdW5kZWZpbmVkKVxuXHRcdFx0XHQuc29ydCgoYTogU3RBY3Rpb24sIGI6IFN0QWN0aW9uKSA9PiBhLmlkIC0gYi5pZClcblxuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCByYXdCeXRlcy5sZW5ndGg7IGkrKykge1xuXHRcdFx0XHRjb25zdCBlbnRyeSA9IG1pY1ByZUVudHJpZXNbaV1cblx0XHRcdFx0aWYgKGVudHJ5KSB7XG5cdFx0XHRcdFx0b3V0LnB1c2goeyBjbWRfaWQ6IGVudHJ5LmNtZF9pZCwgaWQ6IGVudHJ5LmlkLCBidXNDaCwgdmFsdWVCeXRlczogW3Jhd0J5dGVzW2ldXSB9KVxuXHRcdFx0XHR9XG5cdFx0XHRcdC8vIG5vIGVudHJ5ID0gdW5rbm93biBwb3NpdGlvbmFsIGJ5dGUsIGRyb3AgaXRcblx0XHRcdH1cblx0XHRcdHAgPSBzZWN0aW9uRW5kXG5cdFx0XHRjb250aW51ZVxuXHRcdH0gZWxzZSBpZiAoaGFzQnVzQ2gpIHtcblx0XHRcdC8vIFN0cnVjdHVyZTogW2NtZExlbl0gW2NtZElkXSBbYnVzQ2hdIFtkYXRhTGVuXSBbaWQ6dmFsIHBhaXJzXVxuXHRcdFx0YnVzQ2ggPSBidWZbcCArIDJdXG5cdFx0XHRkYXRhTGVuID0gYnVmW3AgKyAzXVxuXHRcdFx0cSA9IHAgKyA0XG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIFN0cnVjdHVyZTogW2NtZExlbl0gW2NtZElkXSBbZGF0YUxlbl0gW2lkOnZhbCBwYWlyc11cblx0XHRcdGRhdGFMZW4gPSBidWZbcCArIDJdXG5cdFx0XHRxID0gcCArIDNcblx0XHR9XG5cblx0XHRjb25zdCBxRW5kID0gcSArIGRhdGFMZW5cblx0XHRjb25zdCBxU3RhcnQgPSBxXG5cblx0XHR3aGlsZSAocSArIDEgPCBxRW5kKSB7XG5cdFx0XHRjb25zdCBpZCA9IGJ1ZltxXVxuXHRcdFx0bGV0IHZhbHVlQnl0ZXM6IG51bWJlcltdXG5cblx0XHRcdC8vIENoZWNrIGlmIHRoaXMgSUQgaXMgYW4gUkdCIGNvbG9ycGlja2VyIChuZWVkcyAzIGJ5dGVzKVxuXHRcdFx0aWYgKHJnYklkcy5oYXMoaWQpICYmIHEgKyAzIDwgcUVuZCkge1xuXHRcdFx0XHR2YWx1ZUJ5dGVzID0gW2J1ZltxICsgMV0sIGJ1ZltxICsgMl0sIGJ1ZltxICsgM11dXG5cdFx0XHRcdHEgKz0gNFxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0dmFsdWVCeXRlcyA9IFtidWZbcSArIDFdXVxuXHRcdFx0XHRxICs9IDJcblx0XHRcdH1cblxuXHRcdFx0Y29uc3Qgc2V0dGluZzogUGFyc2VkU2V0dGluZyA9IHtcblx0XHRcdFx0Y21kX2lkOiBzZWN0aW9uQ21kSWQsXG5cdFx0XHRcdGlkLFxuXHRcdFx0XHR2YWx1ZUJ5dGVzLFxuXHRcdFx0fVxuXHRcdFx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0c2V0dGluZy5idXNDaCA9IGJ1c0NoXG5cdFx0XHR9XG5cdFx0XHRvdXQucHVzaChzZXR0aW5nKVxuXHRcdH1cblxuXHRcdC8vIFBvc2l0aW9uYWwgZmFsbGJhY2s6IGlmIHRoZSBieXRlIHdlIHJlYWQgYXMgZGF0YUxlbiB3YXMgMHgwMCBidXQgdGhlIHNlY3Rpb25cblx0XHQvLyBzdGlsbCBjb250YWlucyBkYXRhIGJ5dGVzLCB0aGlzIHNlY3Rpb24gbGlrZWx5IHVzZXMgYSBuby1kYXRhTGVuIGZvcm1hdCB3aGVyZVxuXHRcdC8vIGVhY2ggYnl0ZSBhZnRlciBjbWRJZCBpcyBhIHJhdyB2YWx1ZSBhdCBhIGZpeGVkIHBvc2l0aW9uIChwb3NpdGlvbiA9IGlkKS5cblx0XHQvLyBSZS1wYXJzZSBmcm9tIHArMiAocmlnaHQgYWZ0ZXIgY21kSWQpLCB0cmVhdGluZyB0aGUgXCJkYXRhTGVuXCIgYnl0ZSBhcyBpZD0wLlxuXHRcdC8vIE9ubHkgZmlyZSBpZiBubyBieXRlcyB3ZXJlIGNvbnN1bWVkIGJ5IHRoZSBtYWluIGxvb3AgKHEgPT09IHFTdGFydCksIHRvIGF2b2lkXG5cdFx0Ly8gcmUtcGFyc2luZyBieXRlcyB0aGF0IHdlcmUgYWxyZWFkeSBzdWNjZXNzZnVsbHkgcGFyc2VkLlxuXHRcdGlmIChxID09PSBxU3RhcnQgJiYgc2VjdGlvbkVuZCA+IHAgKyAzKSB7XG5cdFx0XHRsZXQgcG9zID0gaGFzQnVzQ2ggPyBwICsgMyA6IHAgKyAyIC8vIHNraXAgY21kSWQgKGFuZCBidXNDaCBpZiBwcmVzZW50KVxuXHRcdFx0bGV0IHBvc0lkID0gMFxuXHRcdFx0d2hpbGUgKHBvcyA8IHNlY3Rpb25FbmQpIHtcblx0XHRcdFx0Y29uc3Qgc2V0dGluZzogUGFyc2VkU2V0dGluZyA9IHsgY21kX2lkOiBzZWN0aW9uQ21kSWQsIGlkOiBwb3NJZCsrLCB2YWx1ZUJ5dGVzOiBbYnVmW3BvcysrXV0gfVxuXHRcdFx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkgc2V0dGluZy5idXNDaCA9IGJ1c0NoXG5cdFx0XHRcdG91dC5wdXNoKHNldHRpbmcpXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0cCA9IHNlY3Rpb25FbmRcblx0fVxuXG5cdHJldHVybiBvdXRcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgR0VORVJJQyBTRVRUSU5HUyBSRVNQT05TRSBQQVJTRVIgKDB4MGEgZ2V0LWFsbCArIDB4MGIgdW5zb2xpY2l0ZWQgcHVzaClcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBQYXJzZXMgYW55IGZ1bGwgc2V0dGluZ3MgYmxvY2sgcmVnYXJkbGVzcyBvZiB3aGV0aGVyIHRoZSBjbWRJZCBpcyAweDBhXG4gKiAocmVzcG9uc2UgdG8gR2V0IEFsbCBTZXR0aW5ncykgb3IgMHgwYiAodW5zb2xpY2l0ZWQgcHVzaCBhZnRlciBhIHNldCkuXG4gKiBCb3RoIHVzZSB0aGUgc2FtZSBzZWN0aW9uZWQgb3IgZmxhdCBibG9jayBsYXlvdXQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVNldHRpbmdzUmVzcG9uc2UobW9kZWw6IHN0cmluZywgYnVmOiBCdWZmZXIpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRjb25zdCBpZHggPSBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmKVxuXHRjb25zdCBjbWRJZCA9IGJ1ZltpZHggKyAxXSAmIDB4N2Zcblx0aWYgKGNtZElkICE9PSBDTURfR0VUX0FMTF9TRVRUSU5HUyAmJiBjbWRJZCAhPT0gQ01EX1NFVFRJTkdTX1BVU0gpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoYE5vdCBhIHNldHRpbmdzIGJsb2NrIChjbWRJZD0weCR7Y21kSWQudG9TdHJpbmcoMTYpfSlgKVxuXHR9XG5cdGNvbnN0IHsgc2VjdGlvbmVkIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblx0cmV0dXJuIHNlY3Rpb25lZCA/IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpIDogcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZiwgbW9kZWwpXG59XG5cbi8qKlxuICogRm9ybWF0cyBhIHNpbmdsZSBwYXJzZWQgc2V0dGluZyBpbnRvIGEgaHVtYW4tcmVhZGFibGUgc3RyaW5nIHVzaW5nIGFjdGlvblxuICogZGVmaW5pdGlvbnMgZnJvbSB0aGUgZGV2aWNlIEpTT04uIEZhbGxzIGJhY2sgdG8gaGV4IElEcyB3aGVuIHVua25vd24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRQYXJzZWRTZXR0aW5nKHNldHRpbmc6IFBhcnNlZFNldHRpbmcsIGFjdGlvbnM6IFN0QWN0aW9uW10pOiBzdHJpbmcge1xuXHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0bGV0IGFjdGlvbiA9IGFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IHNldHRpbmcuY21kX2lkICYmIGEuaWQgPT09IHNldHRpbmcuaWQpXG5cblx0Ly8gSWYgbm8gZXhhY3QgbWF0Y2ggYW5kIGlkID4gYmFzZSBpZCwgdHJ5IHRvIGZpbmQgYWN0aW9uIHdpdGggaWRBZGQgb3B0aW9uXG5cdC8vIFRoaXMgaGFuZGxlcyBjYXNlcyBsaWtlIENNRF9IRUFEUEhPTkUgKDB4MDUsIGUuZy4gUGhvbmVzIFJvdXRpbmcpIGFuZFxuXHQvLyBDTURfQlVUVE9OX01PREUgKDB4MDcsIGUuZy4gQnV0dG9ucykgd2hlcmUgaWQgMC0zIHJlcHJlc2VudHMgY2hhbm5lbHMgMS00XG5cdGlmICghYWN0aW9uKSB7XG5cdFx0Y29uc3QgYmFzZUFjdGlvbiA9IGFjdGlvbnMuZmluZCgoYSkgPT4ge1xuXHRcdFx0aWYgKGEuY21kX2lkICE9PSBzZXR0aW5nLmNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiB0aGlzIGFjdGlvbiBoYXMgYW4gaWRBZGQgb3B0aW9uIChpbmRpY2F0aW5nIGNoYW5uZWwgc2VsZWN0aW9uKVxuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdGlvbj8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiB0aGUgc2V0dGluZy5pZCBvZmZzZXQgbWF0Y2hlcyBvbmUgb2YgdGhlIGlkQWRkIGNob2ljZSBJRHNcblx0XHRcdGNvbnN0IGNoYW5uZWxPZmZzZXQgPSBzZXR0aW5nLmlkIC0gYS5pZFxuXHRcdFx0cmV0dXJuIGlkQWRkT3B0aW9uLmNob2ljZXMuc29tZSgoYykgPT4gYy5pZCA9PT0gY2hhbm5lbE9mZnNldClcblx0XHR9KVxuXHRcdGlmIChiYXNlQWN0aW9uKSB7XG5cdFx0XHRhY3Rpb24gPSBiYXNlQWN0aW9uXG5cdFx0fVxuXHR9XG5cblx0Y29uc3QgY21kSGV4ID0gdG9IZXgoc2V0dGluZy5jbWRfaWQpXG5cdGNvbnN0IGlkSGV4ID0gdG9IZXgoc2V0dGluZy5pZClcblx0Y29uc3QgdmFsSGV4ID0gYnl0ZXNUb0hleChzZXR0aW5nLnZhbHVlQnl0ZXMpXG5cdGNvbnN0IHZhbERlYyA9XG5cdFx0c2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gM1xuXHRcdFx0PyBmb3JtYXRSZ2JDb2xvcihzZXR0aW5nLnZhbHVlQnl0ZXNbMF0sIHNldHRpbmcudmFsdWVCeXRlc1sxXSwgc2V0dGluZy52YWx1ZUJ5dGVzWzJdKVxuXHRcdFx0OiBzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAxXG5cdFx0XHRcdD8gc2V0dGluZy52YWx1ZUJ5dGVzWzBdXG5cdFx0XHRcdDogc2V0dGluZy52YWx1ZUJ5dGVzLmpvaW4oJywnKVxuXG5cdC8vIEJ1aWxkIHRoZSBwcmVmaXg6IGNtZDoweDEyIGNoOjAgaWQ6MHgwMSB2YWw6MHgxNCAoY2ggb25seSBmb3IgY29tbWFuZHMgd2l0aCBidXNDaClcblx0Y29uc3QgYnVzQ2hTdHIgPSBzZXR0aW5nLmJ1c0NoICE9PSB1bmRlZmluZWQgPyBgIGNoOiR7c2V0dGluZy5idXNDaH1gIDogJydcblx0Y29uc3QgcHJlZml4ID0gYGNtZDoke2NtZEhleH0ke2J1c0NoU3RyfSBpZDoke2lkSGV4fSB2YWw6JHt2YWxIZXh9YFxuXG5cdC8vIElmIHdlIGhhdmUgYW4gYWN0aW9uIHdpdGggYSBuYW1lIGFuZCBjaG9pY2UgbGFiZWwsIHVzZSBpdFxuXHRpZiAoYWN0aW9uKSB7XG5cdFx0bGV0IG5hbWUgPSBhY3Rpb24ubmFtZVxuXG5cdFx0Ly8gSWYgc2V0dGluZyBoYXMgYnVzQ2gsIGFkZCBjaGFubmVsIGluZm8gdG8gbmFtZVxuXHRcdGlmIChzZXR0aW5nLmJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdG5hbWUgPSBgJHtuYW1lfSBDaCR7c2V0dGluZy5idXNDaCArIDF9YFxuXHRcdH1cblx0XHQvLyBPdGhlcndpc2UsIGlmIHRoaXMgYWN0aW9uIGhhcyBpZEFkZCwgaW5jbHVkZSB0aGUgaWRBZGQgbGFiZWxcblx0XHRlbHNlIHtcblx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKGlkQWRkT3B0aW9uPy5jaG9pY2VzKSB7XG5cdFx0XHRcdGNvbnN0IGNoYW5uZWxPZmZzZXQgPSBzZXR0aW5nLmlkIC0gYWN0aW9uLmlkXG5cdFx0XHRcdGNvbnN0IGlkQWRkQ2hvaWNlID0gaWRBZGRPcHRpb24uY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSBjaGFubmVsT2Zmc2V0KVxuXHRcdFx0XHRpZiAoaWRBZGRDaG9pY2UpIHtcblx0XHRcdFx0XHRuYW1lID0gYCR7bmFtZX0gJHtpZEFkZENob2ljZS5sYWJlbH1gXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBMb29rIGZvciB0aGUgdmFsdWUgb3B0aW9uIChub3QgYnVzQ2ggb3IgaWRBZGQpXG5cdFx0Y29uc3QgdmFsdWVPcHRpb24gPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgob3B0KSA9PiBvcHQuaWQgPT09ICd2YWx1ZScpXG5cdFx0aWYgKHZhbHVlT3B0aW9uPy5jaG9pY2VzICYmIHNldHRpbmcudmFsdWVCeXRlcy5sZW5ndGggPT09IDEpIHtcblx0XHRcdGNvbnN0IGNob2ljZSA9IHZhbHVlT3B0aW9uLmNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gc2V0dGluZy52YWx1ZUJ5dGVzWzBdKVxuXHRcdFx0aWYgKGNob2ljZSkge1xuXHRcdFx0XHRyZXR1cm4gYCR7cHJlZml4fSB8ICR7bmFtZX06ICR7Y2hvaWNlLmxhYmVsfSAoJHt2YWxEZWN9KWBcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIGAke3ByZWZpeH0gfCAke25hbWV9OiAke3ZhbERlY31gXG5cdH1cblxuXHQvLyBObyBhY3Rpb24gZm91bmQgLSBqdXN0IHNob3cgdGhlIHJhdyB2YWx1ZXNcblx0cmV0dXJuIGAke3ByZWZpeH0gfCBVbmtub3duIFNldHRpbmdgXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFBBUlNFUiBESVNQQVRDSCBXSVRIIEFVVE8tREVURUNUSU9OXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbi8qKlxuICogUGFyc2VzIGdldEFsbFNldHRpbmdzIHJlc3BvbnNlIHdpdGggYXV0b21hdGljIGZvcm1hdCBkZXRlY3Rpb24uXG4gKlxuICogQHJldHVybnMge3NldHRpbmdzOiBQYXJzZWRTZXR0aW5nW10sIGRldGVjdGVkU2VjdGlvbmVkOiBib29sZWFuIHwgbnVsbH1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3NXaXRoRGV0ZWN0aW9uKFxuXHRtb2RlbDogc3RyaW5nLFxuXHRidWY6IEJ1ZmZlcixcbik6IHsgc2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXTsgZGV0ZWN0ZWRTZWN0aW9uZWQ6IGJvb2xlYW4gfCBudWxsIH0ge1xuXHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdGNvbnN0IGRlY2xhcmVkU2VjdGlvbmVkID0gc2NoZW1hPy5zZWN0aW9uZWRcblxuXHQvLyBJZiBleHBsaWNpdGx5IGRlY2xhcmVkIGluIEpTT04sIHVzZSB0aGF0XG5cdGlmIChkZWNsYXJlZFNlY3Rpb25lZCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0Y29uc3Qgc2V0dGluZ3MgPSBkZWNsYXJlZFNlY3Rpb25lZFxuXHRcdFx0PyBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWYsIG1vZGVsKVxuXHRcdFx0OiBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmLCBtb2RlbClcblx0XHRyZXR1cm4geyBzZXR0aW5ncywgZGV0ZWN0ZWRTZWN0aW9uZWQ6IG51bGwgfSAvLyBudWxsID0gdXNlZCBkZWNsYXJlZCB2YWx1ZVxuXHR9XG5cblx0Ly8gTm8gZGVjbGFyYXRpb24gLSB0cnkgYm90aCBwYXJzZXJzIGFuZCBwaWNrIHRoZSBiZXN0IG9uZVxuXHRsZXQgZmxhdFNldHRpbmdzOiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXHRsZXQgc2VjdGlvbmVkU2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cblx0dHJ5IHtcblx0XHRmbGF0U2V0dGluZ3MgPSBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmLCBtb2RlbClcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5kZWJ1ZyhgRmxhdCBwYXJzZXIgZmFpbGVkOiAke2V9YClcblx0fVxuXG5cdHRyeSB7XG5cdFx0c2VjdGlvbmVkU2V0dGluZ3MgPSBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWYsIG1vZGVsKVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0bG9nZ2VyLmRlYnVnKGBTZWN0aW9uZWQgcGFyc2VyIGZhaWxlZDogJHtlfWApXG5cdH1cblxuXHQvLyBQaWNrIHRoZSBwYXJzZXIgdGhhdCByZXR1cm5lZCBtb3JlIHNldHRpbmdzXG5cdGlmIChzZWN0aW9uZWRTZXR0aW5ncy5sZW5ndGggPiBmbGF0U2V0dGluZ3MubGVuZ3RoKSB7XG5cdFx0bG9nZ2VyLmluZm8oYEF1dG8tZGV0ZWN0ZWQgU0VDVElPTkVEIGZvcm1hdCAoc2VjdGlvbmVkPSR7c2VjdGlvbmVkU2V0dGluZ3MubGVuZ3RofSB2cyBmbGF0PSR7ZmxhdFNldHRpbmdzLmxlbmd0aH0pYClcblx0XHRyZXR1cm4geyBzZXR0aW5nczogc2VjdGlvbmVkU2V0dGluZ3MsIGRldGVjdGVkU2VjdGlvbmVkOiB0cnVlIH1cblx0fSBlbHNlIGlmIChmbGF0U2V0dGluZ3MubGVuZ3RoID4gMCkge1xuXHRcdGxvZ2dlci5pbmZvKGBBdXRvLWRldGVjdGVkIEZMQVQgZm9ybWF0IChmbGF0PSR7ZmxhdFNldHRpbmdzLmxlbmd0aH0gdnMgc2VjdGlvbmVkPSR7c2VjdGlvbmVkU2V0dGluZ3MubGVuZ3RofSlgKVxuXHRcdHJldHVybiB7IHNldHRpbmdzOiBmbGF0U2V0dGluZ3MsIGRldGVjdGVkU2VjdGlvbmVkOiBmYWxzZSB9XG5cdH0gZWxzZSB7XG5cdFx0Ly8gQm90aCBwYXJzZXJzIHJldHVybmVkIDAgc2V0dGluZ3Ncblx0XHRsb2dnZXIud2FybihgV2FybmluZzogQm90aCBwYXJzZXJzIHJldHVybmVkIDAgc2V0dGluZ3MgZm9yIG1vZGVsICR7bW9kZWx9YClcblx0XHRyZXR1cm4geyBzZXR0aW5nczogW10sIGRldGVjdGVkU2VjdGlvbmVkOiBudWxsIH1cblx0fVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc0Zvck1vZGVsKG1vZGVsOiBzdHJpbmcsIGJ1ZjogQnVmZmVyKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0Y29uc3QgeyBzZWN0aW9uZWQgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXHRyZXR1cm4gc2VjdGlvbmVkID8gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbCkgOiBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmLCBtb2RlbClcbn1cblxuLyogXHUyNzA1IGJhY2t3YXJkLWNvbXBhdGlibGUgZXhwb3J0ICovXG5leHBvcnQgY29uc3QgcGFyc2VHZXRBbGxTZXR0aW5ncyA9IHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbFxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBWQUxVRSBcdTIxOTIgT1BUSU9OXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIHZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzOiBudW1iZXJbXSk6IFN0QWN0aW9uT3B0aW9uIHtcblx0aWYgKHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxKSB7XG5cdFx0cmV0dXJuIHsgaWQ6ICd2YWx1ZScsIGxhYmVsOiAnVmFsdWUnLCB0eXBlOiAnbnVtYmVyJywgZGVmYXVsdDogdmFsdWVCeXRlc1swXSB9XG5cdH1cblxuXHRpZiAodmFsdWVCeXRlcy5sZW5ndGggPT09IDMpIHtcblx0XHRjb25zdCBbciwgZywgYl0gPSB2YWx1ZUJ5dGVzXG5cdFx0cmV0dXJuIHtcblx0XHRcdGlkOiAndmFsdWUnLFxuXHRcdFx0bGFiZWw6ICdDb2xvcicsXG5cdFx0XHR0eXBlOiAnY29sb3JwaWNrZXInLFxuXHRcdFx0ZGVmYXVsdDogZm9ybWF0UmdiQ29sb3IociwgZywgYiksXG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIHsgaWQ6ICd2YWx1ZScsIGxhYmVsOiAnVmFsdWUnLCB0eXBlOiAncmF3JywgZGVmYXVsdDogWy4uLnZhbHVlQnl0ZXNdIH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgU01BUlQgSlNPTiBVUERBVEVcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZU1vZGVsSnNvbkZyb21TZXR0aW5ncyhcblx0bW9kZWxKc29uOiBTdE1vZGVsSnNvbixcblx0cGFyc2VkOiBQYXJzZWRTZXR0aW5nW10sXG5cdGFsbE1vZGVsczogUmVjb3JkPHN0cmluZywgU3RNb2RlbEpzb24+LFxuKTogU3RNb2RlbEpzb24ge1xuXHRjb25zdCBvdXQgPSBzdHJ1Y3R1cmVkQ2xvbmUobW9kZWxKc29uKVxuXG5cdC8vIEVuc3VyZSBjbWRTY2hlbWEgYXJyYXkgZXhpc3RzXG5cdGlmICghb3V0LmNtZFNjaGVtYSkge1xuXHRcdG91dC5jbWRTY2hlbWEgPSBbXVxuXHR9XG5cblx0Ly8gU29ydCBvdGhlciBtb2RlbHMgYnkgbnVtZXJpYyBkaXN0YW5jZSB0byBjdXJyZW50IG1vZGVsXG5cdGNvbnN0IGNhbmRpZGF0ZXMgPSBPYmplY3QudmFsdWVzKGFsbE1vZGVscylcblx0XHQuZmlsdGVyKChtKSA9PiBtLm1vZGVsICE9PSBtb2RlbEpzb24ubW9kZWwpIC8vIGV4Y2x1ZGUgc2VsZlxuXHRcdC5zb3J0KChhLCBiKSA9PiBtb2RlbERpc3RhbmNlKG1vZGVsSnNvbi5tb2RlbCwgYS5tb2RlbCkgLSBtb2RlbERpc3RhbmNlKG1vZGVsSnNvbi5tb2RlbCwgYi5tb2RlbCkpXG5cblx0bG9nZ2VyLmluZm8oYFVwZGF0aW5nIG1vZGVsOiAke21vZGVsSnNvbi5tb2RlbH1gKVxuXHRsb2dnZXIuZGVidWcoYENhbmRpZGF0ZXMgZm9yIGluZmVyZW5jZTogJHtjYW5kaWRhdGVzLm1hcCgoYykgPT4gYy5tb2RlbCkuam9pbignLCAnKX1gKVxuXG5cdC8vIFByZS1zY2FuOiBmb3IgZWFjaCBjYW5kaWRhdGUgaWRBZGQgYmFzZSBlbnRyeSwgZmluZCB0aGUgbWF4aW11bSBzZXF1ZW50aWFsXG5cdC8vIG9mZnNldCB0aGUgcGFja2V0IGNvbnRhaW5zIChldmVuIGJleW9uZCB3aGF0IHRoZSByZWZlcmVuY2UgbW9kZWwga25vd3MpLlxuXHQvLyBLZXk6IGAke2NtZF9pZH1fJHtiYXNlX2lkfWAsIHZhbHVlOiBtYXggc2VxdWVudGlhbCBvZmZzZXQgc2VlbiBpbiBwYXJzZWQgZGF0YS5cblx0Y29uc3QgaWRBZGREZWZlclJhbmdlcyA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KClcblx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRmb3IgKGNvbnN0IGJhc2VFbnRyeSBvZiBjLmNtZFNjaGVtYSA/PyBbXSkge1xuXHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBiYXNlRW50cnkub3B0aW9ucz8uZmluZCgobzogYW55KSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdD8uY2hvaWNlcykgY29udGludWVcblx0XHRcdGNvbnN0IGJhc2VJZCA9IGJhc2VFbnRyeS5pZFxuXHRcdFx0Y29uc3QgY21kSWQgPSBiYXNlRW50cnkuY21kX2lkXG5cdFx0XHRjb25zdCBrZXkgPSBgJHtjbWRJZH1fJHtiYXNlSWR9YFxuXHRcdFx0aWYgKGlkQWRkRGVmZXJSYW5nZXMuaGFzKGtleSkpIGNvbnRpbnVlXG5cdFx0XHQvLyBGaW5kIHRoZSBtYXggc2VxdWVudGlhbCBvZmZzZXQgcHJlc2VudCBpbiB0aGUgcGFyc2VkIHBhY2tldCBmb3IgdGhpcyBiYXNlXG5cdFx0XHRjb25zdCBwYXJzZWRPZmZzZXRzID0gcGFyc2VkXG5cdFx0XHRcdC5maWx0ZXIoKHApID0+IHAuY21kX2lkID09PSBjbWRJZCAmJiBwLmlkID4gYmFzZUlkKVxuXHRcdFx0XHQubWFwKChwKSA9PiBwLmlkIC0gYmFzZUlkKVxuXHRcdFx0XHQuc29ydCgoYSwgYikgPT4gYSAtIGIpXG5cdFx0XHQvLyBXYWxrIGZyb20gMSB1cHdhcmQgXHUyMDE0IHN0b3AgYXQgZmlyc3QgZ2FwXG5cdFx0XHRsZXQgbWF4U2VxID0gMFxuXHRcdFx0Zm9yIChjb25zdCBvZmYgb2YgcGFyc2VkT2Zmc2V0cykge1xuXHRcdFx0XHRpZiAob2ZmID09PSBtYXhTZXEgKyAxKSBtYXhTZXEgPSBvZmZcblx0XHRcdFx0ZWxzZSBpZiAob2ZmID4gbWF4U2VxICsgMSkgYnJlYWtcblx0XHRcdH1cblx0XHRcdGlmIChtYXhTZXEgPiAwKSB7XG5cdFx0XHRcdGlkQWRkRGVmZXJSYW5nZXMuc2V0KGtleSwgbWF4U2VxKVxuXHRcdFx0XHRsb2dnZXIuZGVidWcoYGlkQWRkIGRlZmVyIHJhbmdlIGZvciBjbWRfaWQ9JHt0b0hleChjbWRJZCl9IGJhc2VfaWQ9JHt0b0hleChiYXNlSWQpfTogb2Zmc2V0cyAxXHUyMDEzJHttYXhTZXF9YClcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHQvLyBQcmUtY29tcHV0ZSB0aGUgc2V0IG9mIGFsbCBidXNDaCB2YWx1ZXMgc2VlbiBwZXIgKGNtZF9pZCwgaWQpIHBhaXIgYWNyb3NzIHRoZSBmdWxsXG5cdC8vIHBhcnNlZCByZXNwb25zZSBcdTIwMTQgdXNlZCBsYXRlciB0byBkZWNpZGUgZml4ZWQgdnMuIHNlbGVjdGFibGUgYnVzQ2guXG5cdGNvbnN0IGJ1c0NoU2VlbiA9IG5ldyBNYXA8c3RyaW5nLCBTZXQ8bnVtYmVyPj4oKVxuXHRmb3IgKGNvbnN0IHsgY21kX2lkLCBpZCwgYnVzQ2ggfSBvZiBwYXJzZWQpIHtcblx0XHRpZiAoYnVzQ2ggPT09IHVuZGVmaW5lZCkgY29udGludWVcblx0XHRjb25zdCBrZXkgPSBgJHtjbWRfaWR9XyR7aWR9YFxuXHRcdGlmICghYnVzQ2hTZWVuLmhhcyhrZXkpKSBidXNDaFNlZW4uc2V0KGtleSwgbmV3IFNldCgpKVxuXHRcdGJ1c0NoU2Vlbi5nZXQoa2V5KSEuYWRkKGJ1c0NoKVxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBQQVNTIDE6IHJlc29sdmUgZWFjaCBwYXJzZWQgZW50cnkgXHUyMDE0IGV4YWN0IG1hdGNoLCBpbmZlcnJlZCxcblx0Ly8gaWRBZGQtZm9sZCAob2Zmc2V0IGludG8gYW4gYWxyZWFkeS1hZGRlZCBiYXNlIGVudHJ5KSwgb3IgdW5rbm93blxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdGZvciAoY29uc3QgeyBjbWRfaWQsIGlkLCBidXNDaCwgdmFsdWVCeXRlcyB9IG9mIHBhcnNlZCkge1xuXHRcdC8vIDFhLiBFeGFjdCBtYXRjaCBhbHJlYWR5IGluIG91dHB1dCBzY2hlbWEgXHUyMDE0IHJlZnJlc2ggdGhlIGRlZmF1bHQgYW5kIHN5bmMgYnVzQ2hcblx0XHRjb25zdCBleGlzdGluZ0V4YWN0ID0gb3V0LmNtZFNjaGVtYS5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXHRcdGlmIChleGlzdGluZ0V4YWN0KSB7XG5cdFx0XHRjb25zdCBvcHQgPSBleGlzdGluZ0V4YWN0Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICd2YWx1ZScpXG5cdFx0XHRpZiAob3B0KSBvcHQuZGVmYXVsdCA9IHZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzKS5kZWZhdWx0XG5cblx0XHRcdC8vIFN5bmMgYnVzQ2ggZnJvbSBwYWNrZXQgZGF0YSBpZiB0aGUgZXhpc3RpbmcgZW50cnkgaXMgbWlzc2luZyBpdFxuXHRcdFx0Y29uc3Qgc2VlbkJ1c0NoVmFsdWVzID0gYnVzQ2hTZWVuLmdldChgJHtjbWRfaWR9XyR7aWR9YClcblx0XHRcdGlmIChzZWVuQnVzQ2hWYWx1ZXMgJiYgc2VlbkJ1c0NoVmFsdWVzLnNpemUgPiAwKSB7XG5cdFx0XHRcdGNvbnN0IG1heEJ1c0NoID0gTWF0aC5tYXgoLi4uc2VlbkJ1c0NoVmFsdWVzKVxuXHRcdFx0XHRjb25zdCBoYXNCdXNDaE9wdGlvbiA9IGV4aXN0aW5nRXhhY3Qub3B0aW9ucz8uc29tZSgobykgPT4gby5pZCA9PT0gJ2J1c0NoJylcblx0XHRcdFx0aWYgKG1heEJ1c0NoID09PSAwICYmIGV4aXN0aW5nRXhhY3QuYnVzQ2ggPT09IHVuZGVmaW5lZCAmJiAhaGFzQnVzQ2hPcHRpb24pIHtcblx0XHRcdFx0XHRleGlzdGluZ0V4YWN0LmJ1c0NoID0gMFxuXHRcdFx0XHRcdGxvZ2dlci5pbmZvKGBTeW5jZWQgYnVzQ2g9MCBvbnRvIGV4aXN0aW5nIGVudHJ5IGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfWApXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGNvbnRpbnVlXG5cdFx0fVxuXG5cdFx0Ly8gMWIuIENoZWNrIGlmIHRoaXMgaWQgZm9sZHMgaW50byBhbiBhbHJlYWR5LWFkZGVkIGJhc2UgZW50cnkgdmlhIGlkQWRkLlxuXHRcdC8vICAgICBHYXRlOiB0aGUgb2Zmc2V0IG11c3QgYWN0dWFsbHkgZXhpc3QgaW4gdGhlIHJlZmVyZW5jZSBtb2RlbCdzIGlkQWRkIGNob2ljZXNcblx0XHQvLyAgICAgdG8gYXZvaWQgc3dhbGxvd2luZyB1bnJlbGF0ZWQgc2FtZS1jbWRfaWQgZW50cmllcyAoZS5nLiBTaWRldG9uZSBhdCBpZD0yMSkuXG5cdFx0Y29uc3QgaWRBZGRCYXNlID0gb3V0LmNtZFNjaGVtYS5maW5kKChhKSA9PiB7XG5cdFx0XHRpZiAoYS5jbWRfaWQgIT09IGNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBpZEFkZE9wdCA9IGEub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmICghaWRBZGRPcHQ/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0aWYgKGlkIDw9IGEuaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3Qgb2Zmc2V0ID0gaWQgLSBhLmlkXG5cdFx0XHQvLyBPbmx5IGZvbGQgaWYgYSByZWZlcmVuY2UgbW9kZWwgZXhwbGljaXRseSBsaXN0cyB0aGlzIG9mZnNldCBpbiBpdHMgaWRBZGQgY2hvaWNlc1xuXHRcdFx0cmV0dXJuIGNhbmRpZGF0ZXMuc29tZSgoYykgPT4ge1xuXHRcdFx0XHRjb25zdCByZWZFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChyKSA9PiByLmNtZF9pZCA9PT0gY21kX2lkICYmIHIuaWQgPT09IGEuaWQpXG5cdFx0XHRcdGNvbnN0IHJlZklkQWRkID0gcmVmRW50cnk/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdHJldHVybiByZWZJZEFkZD8uY2hvaWNlcz8uc29tZSgoY2g6IGFueSkgPT4gY2guaWQgPT09IG9mZnNldClcblx0XHRcdH0pXG5cdFx0fSlcblx0XHRpZiAoaWRBZGRCYXNlKSB7XG5cdFx0XHRjb25zdCBvZmZzZXQgPSBpZCAtIGlkQWRkQmFzZS5pZFxuXHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBpZEFkZEJhc2Uub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmIChpZEFkZE9wdD8uY2hvaWNlcyAmJiAhaWRBZGRPcHQuY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9mZnNldCkpIHtcblx0XHRcdFx0bGV0IGxhYmVsID0gYENoYW5uZWwgJHtvZmZzZXQgKyAxfWBcblx0XHRcdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdFx0XHRjb25zdCByZWZFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkQWRkQmFzZS5pZClcblx0XHRcdFx0XHRjb25zdCByZWZJZEFkZCA9IHJlZkVudHJ5Py5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRcdGNvbnN0IHJlZkNob2ljZSA9IHJlZklkQWRkPy5jaG9pY2VzPy5maW5kKChjaDogYW55KSA9PiBjaC5pZCA9PT0gb2Zmc2V0KVxuXHRcdFx0XHRcdGlmIChyZWZDaG9pY2UpIHtcblx0XHRcdFx0XHRcdGxhYmVsID0gcmVmQ2hvaWNlLmxhYmVsXG5cdFx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRpZEFkZE9wdC5jaG9pY2VzLnB1c2goeyBpZDogb2Zmc2V0LCBsYWJlbCB9KVxuXHRcdFx0XHRsb2dnZXIuaW5mbyhcblx0XHRcdFx0XHRgRm9sZGVkIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfSBpbnRvIGlkQWRkIGJhc2UgaWQ9JHt0b0hleChpZEFkZEJhc2UuaWQpfSBhcyBvZmZzZXQgJHtvZmZzZXR9IChcIiR7bGFiZWx9XCIpYCxcblx0XHRcdFx0KVxuXHRcdFx0fVxuXHRcdFx0Y29udGludWVcblx0XHR9XG5cblx0XHQvLyAxYy4gTm8gZXhhY3QgbWF0Y2ggXHUyMDE0IHRyeSBpbmZlcmVuY2UgZnJvbSBjYW5kaWRhdGUgbW9kZWxzXG5cdFx0bGV0IGFjdGlvbjogU3RBY3Rpb24gfCB1bmRlZmluZWRcblxuXHRcdGZvciAoY29uc3QgYyBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0XHRjb25zdCBtYXRjaCA9IGMuY21kU2NoZW1hPy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXHRcdFx0aWYgKG1hdGNoKSB7XG5cdFx0XHRcdGFjdGlvbiA9IHN0cnVjdHVyZWRDbG9uZShtYXRjaClcblx0XHRcdFx0Ly8gU3RyaXAgYW55IGV4aXN0aW5nIFwiKGluZmVycmVkIGZyb20gTW9kZWwgWClcIiBzdWZmaXhlcyBiZWZvcmUgYWRkaW5nIG91ciBvd25cblx0XHRcdFx0Y29uc3QgYmFzZU5hbWUgPSBtYXRjaC5uYW1lLnJlcGxhY2UoL1xccypcXChpbmZlcnJlZCBmcm9tIE1vZGVsIFteKV0rXFwpL2csICcnKS50cmltKClcblx0XHRcdFx0YWN0aW9uLm5hbWUgPSBgJHtiYXNlTmFtZX0gKGluZmVycmVkIGZyb20gTW9kZWwgJHtjLm1vZGVsfSlgXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBJbmZlcnJlZCBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gZnJvbSBNb2RlbCAke2MubW9kZWx9IChleGFjdClgKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIENoZWNrIGlmIHRoaXMgaWQgc2hvdWxkIGJlIGRlZmVycmVkIHRvIHBhc3MgMiBcdTIwMTRcblx0XHQvLyBpdCdzIGEgc2VxdWVudGlhbCBpZEFkZCBvZmZzZXQgb2YgYSBrbm93biBjYW5kaWRhdGUgYmFzZSBlbnRyeS5cblx0XHRpZiAoIWFjdGlvbikge1xuXHRcdFx0bGV0IHNob3VsZERlZmVyID0gZmFsc2Vcblx0XHRcdGZvciAoY29uc3QgYyBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0XHRcdGNvbnN0IGJhc2VFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChhOiBhbnkpID0+IHtcblx0XHRcdFx0XHRpZiAoYS5jbWRfaWQgIT09IGNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBhLm9wdGlvbnM/LmZpbmQoKG86IGFueSkgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0XHRpZiAoIWlkQWRkT3B0Py5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRpZiAoaWQgPD0gYS5pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0Y29uc3Qgb2Zmc2V0ID0gaWQgLSBhLmlkXG5cdFx0XHRcdFx0Y29uc3QgbWF4U2VxID0gaWRBZGREZWZlclJhbmdlcy5nZXQoYCR7Y21kX2lkfV8ke2EuaWR9YCkgPz8gMFxuXHRcdFx0XHRcdHJldHVybiBvZmZzZXQgPD0gbWF4U2VxXG5cdFx0XHRcdH0pXG5cdFx0XHRcdGlmIChiYXNlRW50cnkpIHtcblx0XHRcdFx0XHRzaG91bGREZWZlciA9IHRydWVcblx0XHRcdFx0XHRsb2dnZXIuZGVidWcoXG5cdFx0XHRcdFx0XHRgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9IGlzIGFuIGlkQWRkIG9mZnNldCBvZiBjYW5kaWRhdGUgYmFzZSBpZD0ke3RvSGV4KGJhc2VFbnRyeS5pZCl9IFx1MjAxNCBkZWZlcnJpbmcgdG8gcGFzcyAyYCxcblx0XHRcdFx0XHQpXG5cdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKHNob3VsZERlZmVyKSBjb250aW51ZVxuXHRcdH1cblxuXHRcdC8vIEZhbGxiYWNrOiB1bmtub3duIHNldHRpbmdcblx0XHRpZiAoIWFjdGlvbikge1xuXHRcdFx0YWN0aW9uID0ge1xuXHRcdFx0XHRjbWRfaWQsXG5cdFx0XHRcdGlkLFxuXHRcdFx0XHRuYW1lOiBgVW5rbm93biBjbWQ6JHt0b0hleChjbWRfaWQpfSBpZDoke3RvSGV4KGlkKS50b1VwcGVyQ2FzZSgpfWAsXG5cdFx0XHRcdG9wdGlvbnM6IFt2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlcyldLFxuXHRcdFx0fVxuXHRcdFx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIGFjdGlvbi5idXNDaCA9IGJ1c0NoXG5cdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IGluZmVyIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfWApXG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBGaXggMTogYnVzQ2ggaGFuZGxpbmcgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHQvLyBTdHJpcCBhbnkgaW5oZXJpdGVkIGJ1c0NoIG9wdGlvbiBmcm9tIHRoZSBjYW5kaWRhdGUgXHUyMDE0IHdlJ2xsIHJlLWRlcml2ZVxuXHRcdFx0Ly8gaXQgZnJvbSB3aGF0IHRoZSBwYWNrZXQgYWN0dWFsbHkgcmVwb3J0ZWQgZm9yIHRoaXMgZGV2aWNlLlxuXHRcdFx0YWN0aW9uLm9wdGlvbnMgPSBhY3Rpb24ub3B0aW9ucz8uZmlsdGVyKChvKSA9PiBvLmlkICE9PSAnYnVzQ2gnKSA/PyBbXVxuXHRcdFx0ZGVsZXRlIGFjdGlvbi5idXNDaFxuXG5cdFx0XHRjb25zdCBzZWVuQnVzQ2hWYWx1ZXMgPSBidXNDaFNlZW4uZ2V0KGAke2NtZF9pZH1fJHtpZH1gKVxuXHRcdFx0aWYgKHNlZW5CdXNDaFZhbHVlcyAmJiBzZWVuQnVzQ2hWYWx1ZXMuc2l6ZSA+IDApIHtcblx0XHRcdFx0Y29uc3QgbWF4QnVzQ2ggPSBNYXRoLm1heCguLi5zZWVuQnVzQ2hWYWx1ZXMpXG5cdFx0XHRcdGlmIChtYXhCdXNDaCA9PT0gMCkge1xuXHRcdFx0XHRcdC8vIE9ubHkgZXZlciBzYXcgYnVzQ2g9MCBcdTIxOTIgZml4ZWQgcHJvcGVydHksIG5vdCBhbiBvcHRpb25cblx0XHRcdFx0XHRhY3Rpb24uYnVzQ2ggPSAwXG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0Ly8gTXVsdGlwbGUgY2hhbm5lbHMgb2JzZXJ2ZWQgXHUyMTkyIHNlbGVjdGFibGUgb3B0aW9uXG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2hDaG9pY2VzID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogbWF4QnVzQ2ggKyAxIH0sIChfLCBpKSA9PiAoe1xuXHRcdFx0XHRcdFx0aWQ6IGksXG5cdFx0XHRcdFx0XHRsYWJlbDogYENoYW5uZWwgJHtpICsgMX1gLFxuXHRcdFx0XHRcdH0pKVxuXHRcdFx0XHRcdGFjdGlvbi5vcHRpb25zLnVuc2hpZnQoe1xuXHRcdFx0XHRcdFx0aWQ6ICdidXNDaCcsXG5cdFx0XHRcdFx0XHRsYWJlbDogJ0NoYW5uZWwnLFxuXHRcdFx0XHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdFx0XHRcdGNob2ljZXM6IGJ1c0NoQ2hvaWNlcyxcblx0XHRcdFx0XHRcdGRlZmF1bHQ6IDAsXG5cdFx0XHRcdFx0fSBhcyBhbnkpXG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIEZpeCAyOiBkZWZhdWx0IG11c3QgZXhpc3QgaW4gY2hvaWNlcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRcdC8vIFNldCB0aGUgZGVmYXVsdCB0byB0aGUgb2JzZXJ2ZWQgdmFsdWUuIElmIHRoYXQgdmFsdWUgaXNuJ3QgaW4gdGhlXG5cdFx0XHQvLyBpbmhlcml0ZWQgY2hvaWNlcyBsaXN0LCB0aGUgY2hvaWNlcyBhcmUgZnJvbSBhIHN0cnVjdHVyYWxseSBkaWZmZXJlbnRcblx0XHRcdC8vIG1vZGVsIGFuZCBjYW4ndCBiZSB0cnVzdGVkIFx1MjAxNCBkaXNjYXJkIHRoZW0gYW5kIGZhbGwgYmFjayB0byBhIHBsYWluIG51bWJlci5cblx0XHRcdGNvbnN0IG9ic2VydmVkRGVmYXVsdCA9IHZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzKS5kZWZhdWx0XG5cdFx0XHRjb25zdCB2YWx1ZU9wdCA9IGFjdGlvbi5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAndmFsdWUnKVxuXHRcdFx0aWYgKHZhbHVlT3B0KSB7XG5cdFx0XHRcdGlmICh2YWx1ZU9wdC5jaG9pY2VzICYmIEFycmF5LmlzQXJyYXkodmFsdWVPcHQuY2hvaWNlcykpIHtcblx0XHRcdFx0XHRjb25zdCBpbkNob2ljZXMgPSB2YWx1ZU9wdC5jaG9pY2VzLnNvbWUoKGM6IGFueSkgPT4gYy5pZCA9PT0gb2JzZXJ2ZWREZWZhdWx0KVxuXHRcdFx0XHRcdGlmICghaW5DaG9pY2VzKSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIud2Fybihcblx0XHRcdFx0XHRcdFx0YEluZmVycmVkIGNob2ljZXMgZm9yIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfSBkb24ndCBjb250YWluIG9ic2VydmVkIHZhbHVlICR7b2JzZXJ2ZWREZWZhdWx0fSBcdTIwMTQgZGlzY2FyZGluZyBpbmhlcml0ZWQgY2hvaWNlc2AsXG5cdFx0XHRcdFx0XHQpXG5cdFx0XHRcdFx0XHQvLyBLZWVwIGxhYmVsL3Rvb2x0aXAgYnV0IGRyb3AgY2hvaWNlcywgc3dpdGNoIHRvIHBsYWluIG51bWJlclxuXHRcdFx0XHRcdFx0dmFsdWVPcHQudHlwZSA9ICdudW1iZXInXG5cdFx0XHRcdFx0XHRkZWxldGUgKHZhbHVlT3B0IGFzIGFueSkuY2hvaWNlc1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHR2YWx1ZU9wdC5kZWZhdWx0ID0gb2JzZXJ2ZWREZWZhdWx0XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0b3V0LmNtZFNjaGVtYS5wdXNoKGFjdGlvbilcblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gUEFTUyAyOiBmb2xkIGFueSBkZWZlcnJlZCBpZEFkZCBvZmZzZXRzIHdob3NlIGJhc2UgZW50cnlcblx0Ly8gaXMgbm93IHByZXNlbnQgaW4gdGhlIG91dHB1dCBzY2hlbWEuXG5cdC8vIEdhdGU6IHRoZSBvZmZzZXQgbXVzdCBlaXRoZXIgZXhpc3QgaW4gYSByZWZlcmVuY2UgbW9kZWwncyBjaG9pY2VzLFxuXHQvLyBPUiB0aGUgYmFzZSBlbnRyeSBpdHNlbGYgd2FzIGluZmVycmVkIChoYXMgaWRBZGQpIGFuZCB0aGUgb2Zmc2V0XG5cdC8vIGNvbnRpbnVlcyBzZXF1ZW50aWFsbHkgYmV5b25kIHRoZSByZWZlcmVuY2UgbW9kZWwncyBrbm93biByYW5nZS5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHRmb3IgKGNvbnN0IHsgY21kX2lkLCBpZCB9IG9mIHBhcnNlZCkge1xuXHRcdGNvbnN0IGFscmVhZHlUb3BMZXZlbCA9IG91dC5jbWRTY2hlbWEuc29tZSgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZF9pZCAmJiBhLmlkID09PSBpZClcblx0XHRpZiAoYWxyZWFkeVRvcExldmVsKSBjb250aW51ZVxuXG5cdFx0Ly8gRmluZCBhIGJhc2UgZW50cnkgaW4gdGhlIG91dHB1dCB0aGF0IGhhcyBpZEFkZCBhbmQgd2hvc2UgaWQgPCB0aGlzIGlkXG5cdFx0Y29uc3QgaWRBZGRCYXNlID0gb3V0LmNtZFNjaGVtYS5maW5kKChhKSA9PiB7XG5cdFx0XHRpZiAoYS5jbWRfaWQgIT09IGNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBpZEFkZE9wdCA9IGEub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdHJldHVybiAhIWlkQWRkT3B0Py5jaG9pY2VzICYmIGlkID4gYS5pZFxuXHRcdH0pXG5cdFx0aWYgKCFpZEFkZEJhc2UpIGNvbnRpbnVlXG5cblx0XHRjb25zdCBvZmZzZXQgPSBpZCAtIGlkQWRkQmFzZS5pZFxuXHRcdGNvbnN0IGlkQWRkT3B0ID0gaWRBZGRCYXNlLm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0aWYgKCFpZEFkZE9wdD8uY2hvaWNlcyB8fCBpZEFkZE9wdC5jaG9pY2VzLnNvbWUoKGM6IGFueSkgPT4gYy5pZCA9PT0gb2Zmc2V0KSkgY29udGludWVcblxuXHRcdC8vIEFjY2VwdCB0aGUgZm9sZCBpZjogYSByZWZlcmVuY2UgbW9kZWwgZXhwbGljaXRseSBoYXMgdGhpcyBvZmZzZXQsXG5cdFx0Ly8gT1IgdGhlIG9mZnNldHMgYXJlIHN0cmljdGx5IHNlcXVlbnRpYWwgZnJvbSAwIChkZXZpY2UgaGFzIG1vcmUgY2hhbm5lbHMgdGhhbiByZWZlcmVuY2UpXG5cdFx0Y29uc3QgcmVmSGFzT2Zmc2V0ID0gY2FuZGlkYXRlcy5zb21lKChjKSA9PiB7XG5cdFx0XHRjb25zdCByZWZFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChyKSA9PiByLmNtZF9pZCA9PT0gY21kX2lkICYmIHIuaWQgPT09IGlkQWRkQmFzZS5pZClcblx0XHRcdGNvbnN0IHJlZklkQWRkID0gcmVmRW50cnk/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRyZXR1cm4gcmVmSWRBZGQ/LmNob2ljZXM/LnNvbWUoKGNoOiBhbnkpID0+IGNoLmlkID09PSBvZmZzZXQpXG5cdFx0fSlcblx0XHRjb25zdCBleGlzdGluZ09mZnNldHMgPSBpZEFkZE9wdC5jaG9pY2VzLm1hcCgoYzogYW55KSA9PiBjLmlkIGFzIG51bWJlcikuc29ydCgoYSwgYikgPT4gYSAtIGIpXG5cdFx0Y29uc3QgaXNTZXF1ZW50aWFsID0gZXhpc3RpbmdPZmZzZXRzLmxlbmd0aCA+IDAgJiYgb2Zmc2V0ID09PSBleGlzdGluZ09mZnNldHNbZXhpc3RpbmdPZmZzZXRzLmxlbmd0aCAtIDFdICsgMVxuXG5cdFx0aWYgKCFyZWZIYXNPZmZzZXQgJiYgIWlzU2VxdWVudGlhbCkgY29udGludWVcblxuXHRcdC8vIEluaGVyaXQgbGFiZWwgZnJvbSByZWZlcmVuY2UgbW9kZWwgaWYgYXZhaWxhYmxlLCBvdGhlcndpc2UgZ2VuZXJhdGUgb25lXG5cdFx0bGV0IGxhYmVsID0gYENoYW5uZWwgJHtvZmZzZXQgKyAxfWBcblx0XHRmb3IgKGNvbnN0IGMgb2YgY2FuZGlkYXRlcykge1xuXHRcdFx0Y29uc3QgcmVmRW50cnkgPSBjLmNtZFNjaGVtYT8uZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZF9pZCAmJiBhLmlkID09PSBpZEFkZEJhc2UuaWQpXG5cdFx0XHRjb25zdCByZWZJZEFkZCA9IHJlZkVudHJ5Py5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0Y29uc3QgcmVmQ2hvaWNlID0gcmVmSWRBZGQ/LmNob2ljZXM/LmZpbmQoKGNoOiBhbnkpID0+IGNoLmlkID09PSBvZmZzZXQpXG5cdFx0XHRpZiAocmVmQ2hvaWNlKSB7XG5cdFx0XHRcdGxhYmVsID0gcmVmQ2hvaWNlLmxhYmVsXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0aWRBZGRPcHQuY2hvaWNlcy5wdXNoKHsgaWQ6IG9mZnNldCwgbGFiZWwgfSlcblx0XHRsb2dnZXIuaW5mbyhcblx0XHRcdGBQYXNzIDI6IEZvbGRlZCBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gaW50byBpZEFkZCBiYXNlIGlkPSR7dG9IZXgoaWRBZGRCYXNlLmlkKX0gYXMgb2Zmc2V0ICR7b2Zmc2V0fSAoXCIke2xhYmVsfVwiKWAsXG5cdFx0KVxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBTQVZFXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCBmdW5jdGlvbiBzYXZlTW9kZWxKc29uUHJldHR5KGZpbGVQYXRoOiBzdHJpbmcsIGpzb25PYmo6IFN0TW9kZWxKc29uKTogdm9pZCB7XG5cdHRyeSB7XG5cdFx0Ly8gRW5zdXJlIHByb3BlciBrZXkgb3JkZXJpbmc6IG1vZGVsLCBzZWN0aW9uZWQgKGlmIHByZXNlbnQpLCByZWZyZXNoQWZ0ZXJDb21tYW5kLCBjbWRTY2hlbWFcblx0XHRjb25zdCBvcmRlcmVkT2JqOiBhbnkgPSB7IG1vZGVsOiBqc29uT2JqLm1vZGVsIH1cblxuXHRcdC8vIEFkZCBzZWN0aW9uZWQga2V5IGlmIHByZXNlbnQgKHJpZ2h0IGFmdGVyIG1vZGVsKVxuXHRcdGlmICgnc2VjdGlvbmVkJyBpbiBqc29uT2JqKSB7XG5cdFx0XHRvcmRlcmVkT2JqLnNlY3Rpb25lZCA9IGpzb25PYmouc2VjdGlvbmVkXG5cdFx0fVxuXG5cdFx0Ly8gQWRkIG90aGVyIGtleXMgaW4gb3JkZXJcblx0XHRpZiAoJ2NtZFNjaGVtYScgaW4ganNvbk9iaikge1xuXHRcdFx0b3JkZXJlZE9iai5jbWRTY2hlbWEgPSBqc29uT2JqLmNtZFNjaGVtYS5tYXAoKGVudHJ5OiBhbnkpID0+IHtcblx0XHRcdFx0Ly8gRW5mb3JjZSBrZXkgb3JkZXIgd2l0aGluIGVhY2ggc2NoZW1hIGVudHJ5OiBjbWRfaWQsIGlkLCBidXNDaCwgbmFtZSwgb3B0aW9uc1xuXHRcdFx0XHRjb25zdCBvcmRlcmVkRW50cnk6IGFueSA9IHt9XG5cdFx0XHRcdGlmICgnY21kX2lkJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5LmNtZF9pZCA9IGVudHJ5LmNtZF9pZFxuXHRcdFx0XHRpZiAoJ2lkJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5LmlkID0gZW50cnkuaWRcblx0XHRcdFx0aWYgKCdidXNDaCcgaW4gZW50cnkpIG9yZGVyZWRFbnRyeS5idXNDaCA9IGVudHJ5LmJ1c0NoXG5cdFx0XHRcdGlmICgnbmFtZScgaW4gZW50cnkpIG9yZGVyZWRFbnRyeS5uYW1lID0gZW50cnkubmFtZVxuXHRcdFx0XHRpZiAoJ29wdGlvbnMnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkub3B0aW9ucyA9IGVudHJ5Lm9wdGlvbnNcblx0XHRcdFx0Ly8gQ29weSBhbnkgcmVtYWluaW5nIGtleXNcblx0XHRcdFx0Zm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMoZW50cnkpKSB7XG5cdFx0XHRcdFx0aWYgKCEoa2V5IGluIG9yZGVyZWRFbnRyeSkpIG9yZGVyZWRFbnRyeVtrZXldID0gZW50cnlba2V5XVxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBvcmRlcmVkRW50cnlcblx0XHRcdH0pXG5cdFx0fVxuXHRcdC8vIENvcHkgYW55IG90aGVyIGtleXMgdGhhdCBtaWdodCBleGlzdFxuXHRcdGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGpzb25PYmopKSB7XG5cdFx0XHRpZiAoIShrZXkgaW4gb3JkZXJlZE9iaikpIHtcblx0XHRcdFx0b3JkZXJlZE9ialtrZXldID0gKGpzb25PYmogYXMgYW55KVtrZXldXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gQ3VzdG9tIGZvcm1hdHRlcjoga2VlcCBjaG9pY2Ugb2JqZWN0cyBjb21wYWN0IG9uIG9uZSBsaW5lXG5cdFx0bGV0IGpzb24gPSBKU09OLnN0cmluZ2lmeShvcmRlcmVkT2JqLCBudWxsLCAyKVxuXG5cdFx0Ly8gUmVwbGFjZSBleHBhbmRlZCBjaG9pY2Ugb2JqZWN0cyB3aXRoIGNvbXBhY3Qgc2luZ2xlLWxpbmUgZm9ybWF0XG5cdFx0Ly8gTWF0Y2hlczoge1xcbiAgICAgICAgICAgIFwiaWRcIjogWCxcXG4gICAgICAgICAgICBcImxhYmVsXCI6IFwiWVwiXFxuICAgICAgICAgIH1cblx0XHQvLyBSZXBsYWNlcyB3aXRoOiB7IFwiaWRcIjogWCwgXCJsYWJlbFwiOiBcIllcIiB9XG5cdFx0anNvbiA9IGpzb24ucmVwbGFjZSgvXFx7XFxuXFxzK1wiaWRcIjpcXHMqKFxcZCspLFxcblxccytcImxhYmVsXCI6XFxzKlwiKFteXCJdKilcIlxcblxccytcXH0vZywgJ3sgXCJpZFwiOiAkMSwgXCJsYWJlbFwiOiBcIiQyXCIgfScpXG5cblx0XHRmcy53cml0ZUZpbGVTeW5jKGZpbGVQYXRoLCBqc29uICsgJ1xcbicsICd1dGY4Jylcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5lcnJvcihgRmlsZSBXcml0ZSBFcnJvcjogJHtlfWApXG5cdH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgTE9BRCBERVZJQ0UgSlNPTlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIExvYWRzIHRoZSBhY3Rpb25zIGFycmF5IGZvciBhIGdpdmVuIG1vZGVsIGZyb20gdGhlIGNlbnRyYWxpemVkIGNhY2hlLlxuICogUmV0dXJucyBhbiBlbXB0eSBhcnJheSBpZiB0aGUgbW9kZWwgaXMgbm90IGZvdW5kLlxuICogQGRlcHJlY2F0ZWQgLSBUaGlzIGZ1bmN0aW9uIGlzIG5vIGxvbmdlciBuZWVkZWQuIFVzZSBnZXREZXZpY2VTY2hlbWEoKSBmcm9tIGNvbmZpZy50cyBpbnN0ZWFkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbG9hZEFjdGlvbnNGb3JNb2RlbChfZGV2aWNlc0ZvbGRlcjogc3RyaW5nLCBtb2RlbDogc3RyaW5nKTogU3RBY3Rpb25bXSB7XG5cdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0cmV0dXJuIHNjaGVtYT8uY21kU2NoZW1hID8/IFtdXG59XG4iLCAiaW1wb3J0IE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcbmltcG9ydCB7IGJ1aWxkRmVlZGJhY2tzIH0gZnJvbSAnLi9idWlsZC1jb21tYW5kcy5qcydcbmltcG9ydCB7IGdldERldmljZVNjaGVtYXMgfSBmcm9tICcuL2NvbmZpZy5qcydcbmltcG9ydCB7IHBhcnNlU2V0dGluZ0lkLCBnZXROb3JtYWxpemVkU2NoZW1hcywgZmluZEFjdGlvbkZvclNldHRpbmcgfSBmcm9tICcuL3R5cGVzLmpzJ1xuXG4vKipcbiAqIEhlbHBlciBmdW5jdGlvbiB0byBnZXQgbGFiZWwgZnJvbSBjaG9pY2VzIGJhc2VkIG9uIHZhbHVlXG4gKi9cbmZ1bmN0aW9uIGdldExhYmVsRm9yVmFsdWUoXG5cdHNjaGVtYXM6IFJlY29yZDxzdHJpbmcsIHsgbW9kZWw6IHN0cmluZzsgY21kU2NoZW1hOiBhbnlbXSB9Pixcblx0bW9kZWw6IHN0cmluZyxcblx0Y21kSWQ6IG51bWJlcixcblx0c2V0dGluZ0lkOiBudW1iZXIsXG5cdHZhbHVlOiBudW1iZXIsXG4pOiBzdHJpbmcgfCBudW1iZXIge1xuXHRjb25zdCBzZXR0aW5nID0gZmluZEFjdGlvbkZvclNldHRpbmcoc2NoZW1hcywgbW9kZWwsIGNtZElkLCBzZXR0aW5nSWQpXG5cdGlmICghc2V0dGluZyB8fCAhQXJyYXkuaXNBcnJheShzZXR0aW5nLm9wdGlvbnMpKSByZXR1cm4gdmFsdWVcblxuXHQvLyBGaW5kIHRoZSAndmFsdWUnIG9wdGlvbiB3aGljaCBjb250YWlucyB0aGUgY2hvaWNlc1xuXHRjb25zdCB2YWx1ZU9wdGlvbiA9IHNldHRpbmcub3B0aW9ucy5maW5kKChvcHQ6IGFueSkgPT4gb3B0LmlkID09PSAndmFsdWUnKVxuXHRpZiAoIXZhbHVlT3B0aW9uIHx8ICFBcnJheS5pc0FycmF5KHZhbHVlT3B0aW9uLmNob2ljZXMpKSByZXR1cm4gdmFsdWVcblxuXHQvLyBGaW5kIHRoZSBjaG9pY2Ugd2l0aCBtYXRjaGluZyBpZFxuXHRjb25zdCBjaG9pY2UgPSB2YWx1ZU9wdGlvbi5jaG9pY2VzLmZpbmQoKGM6IGFueSkgPT4gYy5pZCA9PT0gdmFsdWUpXG5cdHJldHVybiBjaG9pY2U/LmxhYmVsID8/IHZhbHVlXG59XG5cbi8qKlxuICogQnVpbGQgYW5kIHdpcmUgQ29tcGFuaW9uIGZlZWRiYWNrIGRlZmluaXRpb25zXG4gKiBQYXR0ZXJuIG1hdGNoZXMgYWN0aW9ucy50cyAtIGZpbHRlcnMgYnkgYWN0aXZlIG1vZGVsIGFuZCB3aXJlcyBjYWxsYmFja3NcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZUZlZWRiYWNrcyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRjb25zdCBzY2hlbWFzUmF3ID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdGNvbnN0IHJhd0ZlZWRiYWNrcyA9IGJ1aWxkRmVlZGJhY2tzKClcblx0Y29uc3Qgc2NoZW1hcyA9IGdldE5vcm1hbGl6ZWRTY2hlbWFzKHNjaGVtYXNSYXcpXG5cdGNvbnN0IHdpcmVkRmVlZGJhY2tzOiBhbnkgPSB7fVxuXG5cdC8vIEdldCB0aGUgYWN0aXZlIG1vZGVsIGZyb20gdGhlIGNhY2hlZCB2YWx1ZSBzZXQgYnkgc3luY01vZGVsKClcblx0Y29uc3QgYWN0aXZlTW9kZWwgPSBzZWxmLmFjdGl2ZU1vZGVsXG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBCVUlMRCBQRVItU0VUVElORyBGRUVEQkFDS1MgKEZJTFRFUkVEIEJZIEFDVElWRSBNT0RFTClcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0Zm9yIChjb25zdCBbZmVlZGJhY2tJZCwgZmVlZGJhY2tdIG9mIE9iamVjdC5lbnRyaWVzKHJhd0ZlZWRiYWNrcykpIHtcblx0XHRjb25zdCB7IG1vZGVsLCBjbWRJZCwgYmFzZUlkIH0gPSBwYXJzZVNldHRpbmdJZChmZWVkYmFja0lkKVxuXG5cdFx0Ly8gT25seSBpbmNsdWRlIGZlZWRiYWNrcyBmb3IgdGhlIGN1cnJlbnRseSBhY3RpdmUgbW9kZWxcblx0XHRpZiAobW9kZWwgIT09IGFjdGl2ZU1vZGVsKSBjb250aW51ZVxuXG5cdFx0Ly8gVkFMVUUgRkVFREJBQ0s6IFJldHVybnMgY3VycmVudCB2YWx1ZSBmb3IgbG9jYWwgdmFyaWFibGVcblx0XHR3aXJlZEZlZWRiYWNrc1tmZWVkYmFja0lkXSA9IHtcblx0XHRcdC4uLmZlZWRiYWNrLFxuXHRcdFx0Y2FsbGJhY2s6IChmZWVkYmFja0V2ZW50OiBhbnkpID0+IHtcblx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3Rcblx0XHRcdFx0Y29uc3QgaWRBZGQgPSBmZWVkYmFja0V2ZW50Lm9wdGlvbnNbJ2lkQWRkJ10gPz8gMFxuXHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBiYXNlSWQgKyBpZEFkZFxuXG5cdFx0XHRcdC8vIGJ1c0NoIGZyb20gb3B0aW9ucyB0YWtlcyBwcmlvcml0eTsgZmFsbCBiYWNrIHRvIGZpeGVkIGJ1c0NoIGluIHNjaGVtYVxuXHRcdFx0XHRsZXQgYnVzQ2ggPSBmZWVkYmFja0V2ZW50Lm9wdGlvbnNbJ2J1c0NoJ11cblx0XHRcdFx0aWYgKGJ1c0NoID09PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRjb25zdCBzY2hlbWFBY3Rpb24gPSBmaW5kQWN0aW9uRm9yU2V0dGluZyhzY2hlbWFzLCBtb2RlbCwgY21kSWQsIHNldHRpbmdJZClcblx0XHRcdFx0XHRpZiAoc2NoZW1hQWN0aW9uPy5idXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0XHRidXNDaCA9IHNjaGVtYUFjdGlvbi5idXNDaFxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHQvLyBMYXN0IHJlc29ydDogbG9vayB1cCBmaXhlZCBidXNDaCBkaXJlY3RseSBmcm9tIHRoZSByYXcgZGV2aWNlIHNjaGVtYSxcblx0XHRcdFx0Ly8gaW4gY2FzZSBnZXROb3JtYWxpemVkU2NoZW1hcygpIHN0cmlwcGVkIHRoZSBwcm9wZXJ0eSAoZS5nLiBNaWMgRWxlY3RyZXQgUG93ZXIpLlxuXHRcdFx0XHRpZiAoYnVzQ2ggPT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdGNvbnN0IHJhd0FjdGlvbiA9IHNjaGVtYXNSYXdbbW9kZWxdPy5jbWRTY2hlbWE/LmZpbmQoKGE6IGFueSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IHNldHRpbmdJZClcblx0XHRcdFx0XHRpZiAocmF3QWN0aW9uPy5idXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0XHRidXNDaCA9IHJhd0FjdGlvbi5idXNDaFxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXG5cdFx0XHRcdGNvbnN0IGN1cnJlbnQgPSBzZWxmLnN0Q29udHJvbGxlci5nZXRTZXR0aW5nVmFsdWUoaXAsIGNtZElkLCBzZXR0aW5nSWQsIGJ1c0NoKVxuXG5cdFx0XHRcdC8vIEJvb2xlYW4gZmVlZGJhY2tzOiBhbnkgbm9uLXplcm8gdmFsdWUgPSBhY3RpdmUgKHRydWUpLCB6ZXJvID0gaW5hY3RpdmUgKGZhbHNlKS5cblx0XHRcdFx0Ly8gVGhpcyB3b3JrcyBmb3IgYWxsIE9uL09mZiBzZXR0aW5ncyByZWdhcmRsZXNzIG9mIHdoYXQgdGhlIFwiT25cIiBJRCB2YWx1ZSBpc1xuXHRcdFx0XHQvLyBpbiB0aGUgc2NoZW1hIChlLmcuIE1pYyBFbGVjdHJldCBQb3dlciB1c2VzIDUgZm9yIE9uLCBub3QgMSkuXG5cdFx0XHRcdGlmIChmZWVkYmFja0lkLmVuZHNXaXRoKCdfYm9vbCcpKSB7XG5cdFx0XHRcdFx0cmV0dXJuIGN1cnJlbnQgIT09IHVuZGVmaW5lZCAmJiBjdXJyZW50ICE9PSAwXG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBDaGVjayBpZiB1c2VyIHdhbnRzIGxhYmVsIGluc3RlYWQgb2YgbnVtZXJpYyB2YWx1ZVxuXHRcdFx0XHRjb25zdCBzaG93TGFiZWwgPSBmZWVkYmFja0V2ZW50Lm9wdGlvbnNbJ3Nob3dMYWJlbCddID8/IGZhbHNlXG5cblx0XHRcdFx0aWYgKHNob3dMYWJlbCAmJiBjdXJyZW50ICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHQvLyBSZXR1cm4gdGhlIGxhYmVsIGZyb20gY2hvaWNlc1xuXHRcdFx0XHRcdHJldHVybiBnZXRMYWJlbEZvclZhbHVlKHNjaGVtYXMsIG1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkLCBjdXJyZW50KVxuXHRcdFx0XHR9XG5cblx0XHRcdFx0Ly8gUmV0dXJuIG51bWVyaWMgdmFsdWUgZGlyZWN0bHkgZm9yIGxvY2FsIHZhcmlhYmxlICh0eXBlOiAndmFsdWUnKVxuXHRcdFx0XHRyZXR1cm4gY3VycmVudCA/PyAwXG5cdFx0XHR9LFxuXHRcdH1cblx0fVxuXG5cdHNlbGYuc2V0RmVlZGJhY2tEZWZpbml0aW9ucyh3aXJlZEZlZWRiYWNrcylcblxuXHQvL2NvbnNvbGUubG9nKCdGZWVkYmFja3M6XFxuJywgSlNPTi5zdHJpbmdpZnkod2lyZWRGZWVkYmFja3MsIG51bGwsIDIpKVxufVxuIiwgImltcG9ydCBkZ3JhbSBmcm9tICdkZ3JhbSdcbmltcG9ydCBvcyBmcm9tICdvcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQge1xuXHRDTURfQlVTX0dFVCxcblx0Q01EX0JVU19TRVQsXG5cdENNRF9ERVZfU1BFQyxcblx0Q01EX0dFVF9BTExfU0VUVElOR1MsXG5cdENNRF9HRVRfRklSTVdBUkUsXG5cdENNRF9HTE9CQUxfTUlDX0tJTEwsXG5cdENNRF9NSUNfUFJFLFxuXHRDTURfTUlDX1BSRV9CVVMsXG5cdENNRF9SRVNFVF9ERVZJQ0UsXG5cdENNRF9TRVRUSU5HU19QVVNILFxuXHRnZXRDb21tYW5kTmFtZSxcblx0bWFrZVNldHRpbmdJZCxcblx0dG9IZXgsXG5cdGJ5dGVzVG9IZXgsXG5cdHR5cGUgRGV2aWNlSW5mbyxcbn0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7XG5cdHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbCxcblx0cGFyc2VTZXR0aW5nc1Jlc3BvbnNlLFxuXHRmb3JtYXRQYXJzZWRTZXR0aW5nLFxuXHR0eXBlIFN0QWN0aW9uLFxuXHR0eXBlIFBhcnNlZFNldHRpbmcsXG59IGZyb20gJy4vc2V0dGluZ3NQYXJzZXIuanMnXG5pbXBvcnQge1xuXHREQU5URV9NU0dfSU5GT19SRVNQT05TRSxcblx0cGFyc2VEYW50ZUluZm9SZXNwb25zZSxcblx0ZGlzY292ZXJEZXZpY2VzLFxuXHRvcGVuQ29uTW9uU2Vzc2lvbixcblx0cHJvYmVEZXZpY2UgYXMgZGFudGVQcm9iZURldmljZSxcblx0Z2V0TWFjRm9yRGVzdGluYXRpb24sXG5cdGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uLFxufSBmcm9tICcuL2RhbnRlLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ1N0Q29udHJvbGxlcicpXG5cbmV4cG9ydCBjbGFzcyBTdENvbnRyb2xsZXIge1xuXHRwcml2YXRlIHJlYWRvbmx5IGRlZmF1bHRQb3J0OiBudW1iZXIgPSA4NzAwXG5cdHByaXZhdGUgcmVhZG9ubHkgbXVsdGljYXN0R3JvdXAgPSAnMjI0LjAuMC4yMzEnXG5cdHByaXZhdGUgcmVhZG9ubHkgcnhQb3J0ID0gODcwMlxuXG5cdHByaXZhdGUgdHhTb2NrZXQ6IGRncmFtLlNvY2tldFxuXHRwcml2YXRlIHJ4U29ja2V0OiBkZ3JhbS5Tb2NrZXQgLy8gZm9yIHJlY2VpdmluZyByZXNwb25zZXMgKDg3MDIpXG5cdHByaXZhdGUgcGVuZGluZ0Fja3M6IE1hcDxcblx0XHRzdHJpbmcsXG5cdFx0eyByZXNvbHZlOiAoYnVmOiBCdWZmZXIpID0+IHZvaWQ7IHJlamVjdDogKGU6IEVycm9yKSA9PiB2b2lkOyB0aW1lcjogTm9kZUpTLlRpbWVvdXQgfVxuXHQ+ID0gbmV3IE1hcCgpXG5cdHByaXZhdGUgam9pbmVkSW50ZXJmYWNlczogU2V0PHN0cmluZz4gPSBuZXcgU2V0KCkgLy8gbG9jYWwgSVBzIHdlJ3ZlIGpvaW5lZCBtdWx0aWNhc3Qgb25cblxuXHQvKiogU2VyaWFsaXplcyBvdXRnb2luZyBjb21tYW5kcyBzbyBlYWNoIHdhaXRzIGZvciBBQ0sgYmVmb3JlIHRoZSBuZXh0IGlzIHNlbnQgKi9cblx0cHJpdmF0ZSBzZW5kUXVldWU6IFByb21pc2U8dm9pZD4gPSBQcm9taXNlLnJlc29sdmUoKVxuXG5cdC8qKiBUcmFja3MgaG93IG1hbnkgY29tbWFuZHMgYXJlIHF1ZXVlZC9pbi1mbGlnaHQsIHRvIGRlZmVyIHJlcXVlc3RBbGxTZXR0aW5ncyAqL1xuXHRwcml2YXRlIHBlbmRpbmdDb21tYW5kQ291bnQgPSAwXG5cblx0LyoqIFJlc29sdmVzIG9uY2UgdHhTb2NrZXQgaXMgYm91bmQgYW5kIHJlYWR5IHRvIHNlbmQgKi9cblx0cHJpdmF0ZSB0eFJlYWR5OiBQcm9taXNlPHZvaWQ+XG5cblx0LyoqIEFjdGl2ZSBkZXZpY2UgbW9kZWwgYW5kIGFjdGlvbiBkZWZpbml0aW9ucyBmb3Igc2V0dGluZ3MgZGVjb2RpbmcgKi9cblx0cHJpdmF0ZSBtb2RlbDogc3RyaW5nID0gJydcblx0cHJpdmF0ZSBhY3Rpb25zOiBTdEFjdGlvbltdID0gW11cblxuXHQvKipcblx0ICogS25vd24gc3RhdGUgb2YgZXZlcnkgc2V0dGluZyBwZXIgZGV2aWNlIElQLlxuXHQgKiBLZXllZCBieSBJUCBcdTIxOTIgTWFwIG9mIFwiJHtjbWRJZH0vJHtzZXR0aW5nSWR9XCIgXHUyMTkyIGN1cnJlbnQgdmFsdWUgYnl0ZS5cblx0ICogUG9wdWxhdGVkIG9uIGNvbm5lY3QgdmlhIHJlcXVlc3RBbGxTZXR0aW5ncygpLCB1cGRhdGVkIG9uIGV2ZXJ5IENNRF9TRVRUSU5HU19QVVNIICgweDBiKS5cblx0ICogVXNlZCB0byBkaWZmIGluY29taW5nIHB1c2hlcyAoY2hhbmdlZCA9IGluZm8sIHVuY2hhbmdlZCA9IGRlYnVnKSBhbmQgZm9yIGZlZWRiYWNrcy5cblx0ICovXG5cdHByaXZhdGUgZGV2aWNlU3RhdGU6IE1hcDxzdHJpbmcsIE1hcDxzdHJpbmcsIG51bWJlcj4+ID0gbmV3IE1hcCgpXG5cblx0LyoqXG5cdCAqIElQcyB0aGF0IGhhdmUgYmVlbiB2ZXJpZmllZCBhZ2FpbnN0IHRoZSBjb25maWd1cmVkIG1vZGVsIGFuZCBhcmUgYWxsb3dlZFxuXHQgKiB0byByZWNlaXZlIFN0dWRpby1UIGNvbW1hbmRzLiBQb3B1bGF0ZWQgYnkgYXV0aG9yaXplRGV2aWNlKCkgYWZ0ZXIgYVxuXHQgKiBzdWNjZXNzZnVsIHByb2JlRGV2aWNlKCkgbW9kZWwgbWF0Y2gsIG9yIGFmdGVyIG11bHRpY2FzdCBkaXNjb3ZlcnkuXG5cdCAqIF9zZW5kQXdhaXRBY2soKSByZWplY3RzIGFueSBkZXN0SXAgbm90IGluIHRoaXMgc2V0LlxuXHQgKi9cblx0cHJpdmF0ZSBhdXRob3JpemVkSXBzOiBTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKVxuXG5cdC8qKiBDYWxsYmFja3MgcmVnaXN0ZXJlZCBmb3IgRGFudGUgMHgwMTcwIGRldmljZSBpbmZvIHJlc3BvbnNlcyBcdTIwMTQga2V5ZWQgYnkgdXNhZ2UgKi9cblx0cHJpdmF0ZSBkaXNjb3ZlcnlMaXN0ZW5lcnM6IE1hcDxzdHJpbmcsIChkZXZpY2U6IERldmljZUluZm8pID0+IHZvaWQ+ID0gbmV3IE1hcCgpXG5cblx0LyoqIENhbGxiYWNrIHRvIHRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlcyB3aGVuIHN0YXRlIGNoYW5nZXMgKi9cblx0cHJpdmF0ZSBmZWVkYmFja0NhbGxiYWNrPzogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZFxuXG5cdC8qKiBDYWNoZSBvZiBsb2NhbCBpbnRlcmZhY2UgTUFDIGJ5dGVzIHBlciBkZXN0aW5hdGlvbiBJUCwgdG8gYXZvaWQgcmVwZWF0ZWQgT1MgbG9va3VwcyAqL1xuXHRwcml2YXRlIG1hY0NhY2hlOiBNYXA8c3RyaW5nLCBudW1iZXJbXT4gPSBuZXcgTWFwKClcblxuXHQvKiogSVBzIGZvciB3aGljaCBhIERhbnRlIENvbk1vbiAocG9ydCA4ODAwKSBzZXNzaW9uIGhhcyBiZWVuIHN1Y2Nlc3NmdWxseSBvcGVuZWQgKi9cblx0cHJpdmF0ZSBzZXNzaW9uRXN0YWJsaXNoZWQ6IFNldDxzdHJpbmc+ID0gbmV3IFNldCgpXG5cblx0LyoqIENsZWFudXAgZnVuY3Rpb25zIHJldHVybmVkIGJ5IG9wZW5Db25Nb25TZXNzaW9uKCkgXHUyMDE0IGNhbGwgdG8gc3RvcCBrZWVwYWxpdmVzIGFuZCBjbG9zZSB0aGUgc29ja2V0ICovXG5cdHByaXZhdGUgX2Nvbm1vbkNsZWFudXBzOiBNYXA8c3RyaW5nLCAoKSA9PiB2b2lkPiA9IG5ldyBNYXAoKVxuXG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdGxvZ2dlci5pbmZvKCdTdENvbnRyb2xsZXIgaW5pdGlhbGl6ZWQnKVxuXG5cdFx0Ly8gU2VuZCBzb2NrZXQgXHUyMDE0IGJpbmQgdG8gZXBoZW1lcmFsIHBvcnQuIFJlc3BvbnNlcyBhbHdheXMgZ28gdG8gcnhTb2NrZXQgb25cblx0XHQvLyBwb3J0IDg3MDIgKERhbnRlIGhhcmRjb2RlcyB0aGUgcmVzcG9uc2UgZGVzdGluYXRpb24gcG9ydCB0byA4NzAyKS5cblx0XHR0aGlzLnR4U29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblx0XHR0aGlzLnR4UmVhZHkgPSBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuXHRcdFx0dGhpcy50eFNvY2tldC5iaW5kKDAsICgpID0+IHtcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBUWCBzb2NrZXQgYm91bmQgdG8gcG9ydCAkeyh0aGlzLnR4U29ja2V0LmFkZHJlc3MoKSBhcyB7IHBvcnQ6IG51bWJlciB9KS5wb3J0fWApXG5cdFx0XHRcdHJlc29sdmUoKVxuXHRcdFx0fSlcblx0XHR9KVxuXHRcdHRoaXMudHhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBUWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdC8vIFJlY2VpdmUgc29ja2V0IC0gYmluZCB0byBhbGwgYWRkcmVzc2VzIHNvIGtlcm5lbCBjYW4gZGVsaXZlciBtdWx0aWNhc3QgcGFja2V0c1xuXHRcdHRoaXMucnhTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXG5cdFx0dGhpcy5yeFNvY2tldC5vbignbGlzdGVuaW5nJywgKCkgPT4ge1xuXHRcdFx0Y29uc3QgYWRkciA9IHRoaXMucnhTb2NrZXQuYWRkcmVzcygpXG5cdFx0XHRsb2dnZXIuZGVidWcoYFJYIHNvY2tldCBsaXN0ZW5pbmcgb24gJHtKU09OLnN0cmluZ2lmeShhZGRyKX1gKVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5yeFNvY2tldC5zZXRNdWx0aWNhc3RMb29wYmFjayh0cnVlKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBSWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ21lc3NhZ2UnLCAobXNnLCByaW5mbykgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5oYW5kbGVJbmNvbWluZyhtc2csIHJpbmZvLmFkZHJlc3MpXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRsb2dnZXIuZXJyb3IoYEVycm9yIGhhbmRsaW5nIGluY29taW5nIG1lc3NhZ2U6ICR7X2V9YClcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0Ly8gQmluZCB0byB3aWxkY2FyZCBzbyBrZXJuZWwgY2FuIGRlbGl2ZXIgbXVsdGljYXN0IHBhY2tldHMgZm9yIGpvaW5lZCBpbnRlcmZhY2VzLlxuXHRcdC8vIEFmdGVyIGJpbmRpbmcsIGVhZ2VybHkgam9pbiAyMjQuMC4wLjIzMSBvbiBldmVyeSBub24tbG9vcGJhY2sgSVB2NCBpbnRlcmZhY2Ugc29cblx0XHQvLyB0aGF0IHVuc29saWNpdGVkIENNRF9TRVRUSU5HU19QVVNIICgweDBiKSBwYWNrZXRzIGFyZSBub3QgbWlzc2VkIGJlZm9yZSB0aGVcblx0XHQvLyBmaXJzdCBvdXRnb2luZyBjb21tYW5kIHRyaWdnZXJzIHRoZSBsYXp5IGVuc3VyZU1lbWJlcnNoaXBGb3IoKSBqb2luLlxuXHRcdHRoaXMucnhTb2NrZXQuYmluZCh7IGFkZHJlc3M6ICcwLjAuMC4wJywgcG9ydDogdGhpcy5yeFBvcnQgfSwgKCkgPT4ge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCBzb2NrZXQgYm91bmQgdG8gMC4wLjAuMDoke3RoaXMucnhQb3J0fWApXG5cdFx0XHRjb25zdCBpZmFjZXMgPSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpIGFzIFJlY29yZDxzdHJpbmcsIGltcG9ydCgnb3MnKS5OZXR3b3JrSW50ZXJmYWNlSW5mb1tdPlxuXHRcdFx0Zm9yIChjb25zdCBhZGRycyBvZiBPYmplY3QudmFsdWVzKGlmYWNlcykpIHtcblx0XHRcdFx0Zm9yIChjb25zdCBhZGRyIG9mIGFkZHJzID8/IFtdKSB7XG5cdFx0XHRcdFx0aWYgKGFkZHIuZmFtaWx5ID09PSAnSVB2NCcgJiYgIWFkZHIuaW50ZXJuYWwgJiYgIXRoaXMuam9pbmVkSW50ZXJmYWNlcy5oYXMoYWRkci5hZGRyZXNzKSkge1xuXHRcdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdFx0dGhpcy5yeFNvY2tldC5hZGRNZW1iZXJzaGlwKHRoaXMubXVsdGljYXN0R3JvdXAsIGFkZHIuYWRkcmVzcylcblx0XHRcdFx0XHRcdFx0dGhpcy5qb2luZWRJbnRlcmZhY2VzLmFkZChhZGRyLmFkZHJlc3MpXG5cdFx0XHRcdFx0XHRcdGxvZ2dlci5pbmZvKGBQcmUtam9pbmVkIG11bHRpY2FzdCAke3RoaXMubXVsdGljYXN0R3JvdXB9IG9uICR7YWRkci5hZGRyZXNzfWApXG5cdFx0XHRcdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRcdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IHByZS1qb2luIG11bHRpY2FzdCBvbiAke2FkZHIuYWRkcmVzc306ICR7U3RyaW5nKF9lKX1gKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pXG5cdH1cblxuXHRwdWJsaWMgY2xvc2UoKTogdm9pZCB7XG5cdFx0Ly8gU3RvcCBhbGwgQ29uTW9uIGtlZXBhbGl2ZXMgYW5kIGNsb3NlIHRoZWlyIHNvY2tldHMgYmVmb3JlIGNsb3NpbmcgdGhlIG1haW4gc29ja2V0c1xuXHRcdGZvciAoY29uc3QgY2xlYW51cCBvZiB0aGlzLl9jb25tb25DbGVhbnVwcy52YWx1ZXMoKSkge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y2xlYW51cCgpXG5cdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0fVxuXHRcdHRoaXMuX2Nvbm1vbkNsZWFudXBzLmNsZWFyKClcblx0XHR0cnkge1xuXHRcdFx0Zm9yIChjb25zdCBsb2NhbEFkZHIgb2YgQXJyYXkuZnJvbSh0aGlzLmpvaW5lZEludGVyZmFjZXMpKSB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0dGhpcy5yeFNvY2tldC5kcm9wTWVtYmVyc2hpcCh0aGlzLm11bHRpY2FzdEdyb3VwLCBsb2NhbEFkZHIpXG5cdFx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdFx0dHJ5IHtcblx0XHRcdHRoaXMucnhTb2NrZXQuY2xvc2UoKVxuXHRcdH0gY2F0Y2gge1xuXHRcdFx0LyogaWdub3JlICovXG5cdFx0fVxuXHRcdHRyeSB7XG5cdFx0XHR0aGlzLnR4U29ja2V0LmNsb3NlKClcblx0XHR9IGNhdGNoIHtcblx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBQcm92aWRlIHRoZSBhY3RpdmUgZGV2aWNlIG1vZGVsIGFuZCBhY3Rpb24gZGVmaW5pdGlvbnMgc28gaW5jb21pbmcgbWVzc2FnZXNcblx0ICogY2FuIGJlIGRlY29kZWQgaW50byBodW1hbi1yZWFkYWJsZSBuYW1lcy4gQ2FsbCBmcm9tIG1haW4udHMgYWZ0ZXIgY29uZmlnIGxvYWQuXG5cdCAqL1xuXHRwdWJsaWMgc2V0TW9kZWwobW9kZWw6IHN0cmluZywgYWN0aW9uczogU3RBY3Rpb25bXSk6IHZvaWQge1xuXHRcdHRoaXMubW9kZWwgPSBtb2RlbFxuXHRcdHRoaXMuYWN0aW9ucyA9IGFjdGlvbnNcblx0fVxuXG5cdC8qKlxuXHQgKiBTZXQgY2FsbGJhY2sgdG8gdHJpZ2dlciB3aGVuIGRldmljZSBzdGF0ZSBjaGFuZ2VzIChmb3IgZmVlZGJhY2tzKS5cblx0ICogQ2FsbCBmcm9tIG1haW4udHMgdG8gd2lyZSB1cCBjaGVja0ZlZWRiYWNrcy5cblx0ICovXG5cdHB1YmxpYyBzZXRGZWVkYmFja0NhbGxiYWNrKGNhbGxiYWNrOiAoZmVlZGJhY2tJZDogc3RyaW5nKSA9PiB2b2lkKTogdm9pZCB7XG5cdFx0dGhpcy5mZWVkYmFja0NhbGxiYWNrID0gY2FsbGJhY2tcblx0fVxuXG5cdC8qKiBSZXR1cm5zIHRydWUgaWYgdGhlIGRldmljZSBhdCB0aGUgZ2l2ZW4gSVAgaGFzIGJlZW4gYXV0aG9yaXplZCB0byByZWNlaXZlIGNvbW1hbmRzLiAqL1xuXHRwdWJsaWMgaXNEZXZpY2VBdXRob3JpemVkKGlwOiBzdHJpbmcpOiBib29sZWFuIHtcblx0XHRyZXR1cm4gdGhpcy5hdXRob3JpemVkSXBzLmhhcyhpcClcblx0fVxuXG5cdC8qKiBNYXJrIGFuIElQIGFzIHZlcmlmaWVkIGFuZCBhbGxvd2VkIHRvIHJlY2VpdmUgU3R1ZGlvLVQgY29tbWFuZHMuICovXG5cdHB1YmxpYyBhdXRob3JpemVEZXZpY2UoaXA6IHN0cmluZyk6IHZvaWQge1xuXHRcdHRoaXMuYXV0aG9yaXplZElwcy5hZGQoaXApXG5cdFx0bG9nZ2VyLmRlYnVnKGBBdXRob3JpemVkIGRldmljZSBhdCAke2lwfWApXG5cdH1cblxuXHQvKiogUmVtb3ZlIGF1dGhvcml6YXRpb24gZm9yIGFuIElQIChlLmcuIG9uIGNvbmZpZyBjaGFuZ2Ugb3IgbW9kZWwgbWlzbWF0Y2gpLiAqL1xuXHRwdWJsaWMgcmV2b2tlRGV2aWNlKGlwOiBzdHJpbmcpOiB2b2lkIHtcblx0XHR0aGlzLmF1dGhvcml6ZWRJcHMuZGVsZXRlKGlwKVxuXHRcdHRoaXMuZGV2aWNlU3RhdGUuZGVsZXRlKGlwKVxuXHRcdHRoaXMubWFjQ2FjaGUuZGVsZXRlKGlwKVxuXHRcdHRoaXMuc2Vzc2lvbkVzdGFibGlzaGVkLmRlbGV0ZShpcClcblx0XHR0aGlzLl9jb25tb25DbGVhbnVwcy5nZXQoaXApPy4oKVxuXHRcdHRoaXMuX2Nvbm1vbkNsZWFudXBzLmRlbGV0ZShpcClcblx0XHRsb2dnZXIuZGVidWcoYFJldm9rZWQgZGV2aWNlIGF0ICR7aXB9YClcblx0fVxuXG5cdC8qKlxuXHQgKiBPcGVucyBhIERhbnRlIENvbk1vbiBzZXNzaW9uIGZvciB0aGUgZGV2aWNlLiBDYWNoZXMgdGhlIHJlc3VsdCBzbyB0aGVcblx0ICogaGFuZHNoYWtlIG9ubHkgcnVucyBvbmNlIHBlciBJUC4gRGVsZWdhdGVzIHRvIGRhbnRlLnRzIG9wZW5Db25Nb25TZXNzaW9uKCkuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgb3BlblNlc3Npb24oZGV2aWNlSXA6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xuXHRcdGlmICh0aGlzLnNlc3Npb25Fc3RhYmxpc2hlZC5oYXMoZGV2aWNlSXApKSByZXR1cm4gdHJ1ZVxuXHRcdGNvbnN0IGNsZWFudXAgPSBhd2FpdCBvcGVuQ29uTW9uU2Vzc2lvbihkZXZpY2VJcClcblx0XHRjb25zdCBzdWNjZXNzID0gY2xlYW51cCAhPT0gbnVsbFxuXHRcdC8vIE1hcmsgYXMgYXR0ZW1wdGVkIHJlZ2FyZGxlc3Mgb2Ygb3V0Y29tZSBcdTIwMTQgcmV0cnlpbmcgaW1tZWRpYXRlbHkgd291bGQgaGl0IHRoZVxuXHRcdC8vIHNhbWUgYmluZCBlcnJvciAoRUFERFJJTlVTRSkuIERldmljZXMgdGhhdCBkb24ndCBuZWVkIENvbk1vbiB3b3JrIGZpbmUgd2l0aG91dCBpdC5cblx0XHR0aGlzLnNlc3Npb25Fc3RhYmxpc2hlZC5hZGQoZGV2aWNlSXApXG5cdFx0aWYgKHN1Y2Nlc3MpIHtcblx0XHRcdHRoaXMuX2Nvbm1vbkNsZWFudXBzLnNldChkZXZpY2VJcCwgY2xlYW51cClcblx0XHR9XG5cdFx0cmV0dXJuIHN1Y2Nlc3Ncblx0fVxuXG5cdC8qKlxuXHQgKiBTZW5kcyBhIHVuaWNhc3QgRGFudGUgaW5mbyByZXF1ZXN0IHRvIGEgc3BlY2lmaWMgSVAgYW5kIHdhaXRzIGZvciB0aGVcblx0ICogZGV2aWNlIGluZm8gcmVzcG9uc2UuIFJldHVybnMgdGhlIERldmljZUluZm8gaWYgdGhlIGRldmljZSByZXNwb25kcyB3aXRoaW5cblx0ICogdGltZW91dE1zLCBvciBudWxsIGlmIG5vIHJlc3BvbnNlLiBVc2VkIHRvIHZlcmlmeSBhIG1hbnVhbGx5IGNvbmZpZ3VyZWQgSVAuXG5cdCAqIERvZXMgTk9UIHJlcXVpcmUgYXV0aG9yaXphdGlvbiBcdTIwMTQgdGhpcyBpcyBob3cgYXV0aG9yaXphdGlvbiBpcyBlc3RhYmxpc2hlZC5cblx0ICovXG5cdHB1YmxpYyBhc3luYyBwcm9iZURldmljZShpcDogc3RyaW5nLCB0aW1lb3V0TXMgPSAzMDAwKTogUHJvbWlzZTxEZXZpY2VJbmZvIHwgbnVsbD4ge1xuXHRcdGF3YWl0IHRoaXMudHhSZWFkeVxuXHRcdHJldHVybiBkYW50ZVByb2JlRGV2aWNlKFxuXHRcdFx0dGhpcy50eFNvY2tldCxcblx0XHRcdChrZXksIGNiKSA9PiB0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5zZXQoa2V5LCBjYiksXG5cdFx0XHQoa2V5KSA9PiB0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5kZWxldGUoa2V5KSxcblx0XHRcdGFzeW5jIChkZXN0SXApID0+IHRoaXMuZW5zdXJlTWVtYmVyc2hpcEZvcihkZXN0SXApLFxuXHRcdFx0aXAsXG5cdFx0XHR0aW1lb3V0TXMsXG5cdFx0KVxuXHR9XG5cblx0LyoqXG5cdCAqIFNlbmQgYSBDTURfR0VUX0FMTF9TRVRUSU5HUyAoMHgwYSkgcmVxdWVzdCB0byB0aGUgZGV2aWNlIGFuZCBzdG9yZSB0aGUgcmVzcG9uc2Vcblx0ICogaW4gZGV2aWNlU3RhdGUuIFJldHVybnMgdGhlIHJhdyByZXNwb25zZSBidWZmZXIgZm9yIHBhcnNpbmcuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgcmVxdWVzdEFsbFNldHRpbmdzKGRldmljZUlwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdGxvZ2dlci5pbmZvKGBSZXF1ZXN0aW5nIGFsbCBzZXR0aW5ncyBmcm9tICR7ZGV2aWNlSXB9YClcblx0XHRjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuc2VuZEF3YWl0QWNrKENNRF9HRVRfQUxMX1NFVFRJTkdTLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBkZXZpY2VJcCwgZmFsc2UpXG5cdFx0Ly8gZGV2aWNlU3RhdGUgaXMgcG9wdWxhdGVkIGJ5IGxvZ1N0UGF5bG9hZCB3aGVuIHRoZSBDTURfR0VUX0FMTF9TRVRUSU5HUyByZXNwb25zZSBhcnJpdmVzXG5cdFx0cmV0dXJuIHJlc3BvbnNlXG5cdH1cblxuXHQvKipcblx0ICogRGlzY292ZXJzIFN0dWRpbyBUZWNobm9sb2dpZXMgRGFudGUgZGV2aWNlcyBvbiB0aGUgbG9jYWwgbmV0d29yay5cblx0ICpcblx0ICogTGlzdGVucyBmb3IgRGFudGUgYW5ub3VuY2VzIG9uIDIyNC4wLjAuMjMzOjg3MDgsIHNlbmRzIHVuaWNhc3QgaW5mbyByZXF1ZXN0c1xuXHQgKiB0byBlYWNoIGRpc2NvdmVyZWQgSVAsIGFuZCBjb2xsZWN0cyAweDAxNzAgcmVzcG9uc2VzIHZpYSB0aGUgcnhTb2NrZXQuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgZGlzY292ZXJEZXZpY2VzKHRpbWVvdXRNcyA9IDUwMDApOiBQcm9taXNlPERldmljZUluZm9bXT4ge1xuXHRcdGNvbnN0IERJU0NPVkVSWV9LRVkgPSAnX19kaXNjb3ZlcnlfXydcblx0XHRjb25zdCBmb3VuZERldmljZXM6IERldmljZUluZm9bXSA9IFtdXG5cblx0XHR0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5zZXQoRElTQ09WRVJZX0tFWSwgKGRldmljZTogRGV2aWNlSW5mbykgPT4ge1xuXHRcdFx0aWYgKCFmb3VuZERldmljZXMuc29tZSgoZCkgPT4gZC5pcCA9PT0gZGV2aWNlLmlwKSkge1xuXHRcdFx0XHRmb3VuZERldmljZXMucHVzaChkZXZpY2UpXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdHRyeSB7XG5cdFx0XHRhd2FpdCB0aGlzLnR4UmVhZHlcblx0XHRcdGF3YWl0IGRpc2NvdmVyRGV2aWNlcyh0aGlzLnR4U29ja2V0LCBhc3luYyAoZGVzdElwKSA9PiB0aGlzLmVuc3VyZU1lbWJlcnNoaXBGb3IoZGVzdElwKSwgdGltZW91dE1zKVxuXHRcdFx0cmV0dXJuIGZvdW5kRGV2aWNlc1xuXHRcdH0gZmluYWxseSB7XG5cdFx0XHR0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy5kZWxldGUoRElTQ09WRVJZX0tFWSlcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogUmVxdWVzdHMgZGV2aWNlIGZpcm13YXJlIHZlcnNpb24gdmlhIFN0dWRpby1UIHByb3RvY29sIChDTURfR0VUX0ZJUk1XQVJFKS5cblx0ICogUmV0dXJucyB0aGUgZmlybXdhcmUgdmVyc2lvbiBzdHJpbmcgKGUuZy4sIFwiMy4wMVwiLCBcIjIuMlwiLCBcIjEuMDVcIikuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgcmVxdWVzdEZpcm13YXJlVmVyc2lvbihkZXZpY2VJcDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcblx0XHRsb2dnZXIuaW5mbyhgUmVxdWVzdGluZyBmaXJtd2FyZSB2ZXJzaW9uIGZyb20gJHtkZXZpY2VJcH1gKVxuXHRcdGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5zZW5kQXdhaXRBY2soQ01EX0dFVF9GSVJNV0FSRSwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgZGV2aWNlSXAsIGZhbHNlKVxuXG5cdFx0Ly8gUmVzcG9uc2Ugc3RydWN0dXJlOiBbaGVhZGVyXSAweDVhIDB4ODAgW2Zpcm13YXJlX2RhdGFdIENSQ1xuXHRcdC8vIEZpcm13YXJlIGRhdGEgc3RhcnRzIGF0IGJ5dGUgMjYgKDI0LWJ5dGUgaGVhZGVyICsgMHg1YSArIDB4ODApXG5cdFx0Y29uc3QgZGF0YVN0YXJ0ID0gMjZcblxuXHRcdGlmIChyZXNwb25zZS5sZW5ndGggPCBkYXRhU3RhcnQgKyAzKSB7XG5cdFx0XHRsb2dnZXIud2FybihgRmlybXdhcmUgcmVzcG9uc2UgdG9vIHNob3J0OiAke3Jlc3BvbnNlLmxlbmd0aH0gYnl0ZXNgKVxuXHRcdFx0cmV0dXJuICdVbmtub3duJ1xuXHRcdH1cblxuXHRcdC8vIEZpcm13YXJlIGZvcm1hdDogW3Vua25vd25fYnl0ZSwgbWFqb3IsIG1pbm9yXVxuXHRcdGNvbnN0IG1ham9yID0gcmVzcG9uc2VbZGF0YVN0YXJ0ICsgMV1cblx0XHRjb25zdCBtaW5vciA9IHJlc3BvbnNlW2RhdGFTdGFydCArIDJdXG5cblx0XHRjb25zdCBtaW5vclN0ciA9XG5cdFx0XHRtaW5vciA8IDEwXG5cdFx0XHRcdD8gbWlub3IudG9TdHJpbmcoKS5wYWRTdGFydCgyLCAnMCcpIC8vIGUuZy4gMSBcdTIxOTIgXCIwMVwiLCA1IFx1MjE5MiBcIjA1XCJcblx0XHRcdFx0OiBtaW5vci50b1N0cmluZygpIC8vIGUuZy4gMTAgXHUyMTkyIFwiMTBcIlxuXG5cdFx0Y29uc3QgZmlybXdhcmUgPSBgJHttYWpvcn0uJHttaW5vclN0cn1gXG5cblx0XHRsb2dnZXIuaW5mbyhgRmlybXdhcmUgdmVyc2lvbjogJHtmaXJtd2FyZX1gKVxuXHRcdHJldHVybiBmaXJtd2FyZVxuXHR9XG5cblx0LyoqXG5cdCAqIEpvaW5zIHRoZSBtdWx0aWNhc3QgcmVzcG9uc2UgZ3JvdXAgb24gdGhlIGludGVyZmFjZSB0aGF0IHJvdXRlcyB0byBkZXN0SXAuXG5cdCAqIE9ubHkgam9pbnMgdGhlIHNwZWNpZmljIGludGVyZmFjZSB1c2VkIHRvIHJlYWNoIHRoZSBkZXZpY2UsIGFuZCBvbmx5IG9uY2UgcGVyIGludGVyZmFjZS5cblx0ICovXG5cdHByaXZhdGUgYXN5bmMgZW5zdXJlTWVtYmVyc2hpcEZvcihkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBsb2NhbEFkZHIgPSBhd2FpdCBnZXRMb2NhbEFkZHJlc3NGb3JEZXN0aW5hdGlvbihkZXN0SXApXG5cdFx0XHRpZiAoIWxvY2FsQWRkcikge1xuXHRcdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IGRldGVybWluZSBsb2NhbCBhZGRyZXNzIGZvciBkZXN0aW5hdGlvbiAke2Rlc3RJcH1gKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0aWYgKHRoaXMuam9pbmVkSW50ZXJmYWNlcy5oYXMobG9jYWxBZGRyKSkge1xuXHRcdFx0XHQvLyBhbHJlYWR5IGpvaW5lZFxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5yeFNvY2tldC5hZGRNZW1iZXJzaGlwKHRoaXMubXVsdGljYXN0R3JvdXAsIGxvY2FsQWRkcilcblx0XHRcdFx0dGhpcy5qb2luZWRJbnRlcmZhY2VzLmFkZChsb2NhbEFkZHIpXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBKb2luZWQgbXVsdGljYXN0ICR7dGhpcy5tdWx0aWNhc3RHcm91cH0gb24gJHtsb2NhbEFkZHJ9YClcblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gam9pbiBtdWx0aWNhc3Qgb24gJHtsb2NhbEFkZHJ9OiAke1N0cmluZyhfZSl9YClcblx0XHRcdH1cblx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYGVuc3VyZU1lbWJlcnNoaXBGb3IgZmFpbGVkOiAke19lfWApXG5cdFx0fVxuXHR9XG5cblx0cHVibGljIGFzeW5jIHNlbmRBd2FpdEFjayhcblx0XHRjbWRJZDogbnVtYmVyLFxuXHRcdGJ1c0NoOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0c2V0dGluZ0lkOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0dmFsdWU6IHVua25vd24sXG5cdFx0ZGVzdElwOiBzdHJpbmcsXG5cdFx0YWRkTGVuID0gdHJ1ZSxcblx0KTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHR0aGlzLnBlbmRpbmdDb21tYW5kQ291bnQrK1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZTxCdWZmZXI+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdHRoaXMuc2VuZFF1ZXVlID0gdGhpcy5zZW5kUXVldWUudGhlbihhc3luYyAoKSA9PlxuXHRcdFx0XHR0aGlzLl9zZW5kQXdhaXRBY2soY21kSWQsIGJ1c0NoLCBzZXR0aW5nSWQsIHZhbHVlLCBkZXN0SXAsIGFkZExlbilcblx0XHRcdFx0XHQudGhlbigoYnVmKSA9PiB7XG5cdFx0XHRcdFx0XHR0aGlzLnBlbmRpbmdDb21tYW5kQ291bnQtLVxuXHRcdFx0XHRcdFx0Ly8gT25seSB0cmlnZ2VyIHJlcXVlc3RBbGxTZXR0aW5ncyBhZnRlciBhIHdyaXRlIChTRVQpIGNvbW1hbmQsIG5vdCBhIHJlYWQvcG9sbC5cblx0XHRcdFx0XHRcdC8vIEEgd3JpdGUgYWx3YXlzIGhhcyBhIHZhbHVlOyByZWFkcyAoR0VULCBCVVNfR0VUKSBuZXZlciBkby5cblx0XHRcdFx0XHRcdGlmICh0aGlzLnBlbmRpbmdDb21tYW5kQ291bnQgPT09IDAgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdFx0XHR0aGlzLnJlcXVlc3RBbGxTZXR0aW5ncyhkZXN0SXApLmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIHJlZnJlc2ggc2V0dGluZ3MgYWZ0ZXIgY29tbWFuZDogJHtlcnJ9YClcblx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdHJlc29sdmUoYnVmKVxuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0LmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0XHRcdHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudC0tXG5cdFx0XHRcdFx0XHRyZWplY3QoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIgOiBuZXcgRXJyb3IoU3RyaW5nKGVycikpKVxuXHRcdFx0XHRcdH0pLFxuXHRcdFx0KVxuXHRcdH0pXG5cdH1cblxuXHRwcml2YXRlIGFzeW5jIF9zZW5kQXdhaXRBY2soXG5cdFx0Y21kSWQ6IG51bWJlcixcblx0XHRidXNDaDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHNldHRpbmdJZDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHZhbHVlOiB1bmtub3duLFxuXHRcdGRlc3RJcDogc3RyaW5nLFxuXHRcdGFkZExlbiA9IHRydWUsXG5cdCk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0Y29uc3QgdGltZW91dE1zID0gMjAwMFxuXG5cdFx0Y29uc3QgZGF0YUJsb2NrOiBudW1iZXJbXSA9IFtdXG5cdFx0aWYgKHNldHRpbmdJZCAhPT0gdW5kZWZpbmVkKSBkYXRhQmxvY2sucHVzaChzZXR0aW5nSWQgJiAweGZmKVxuXHRcdGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkKSBkYXRhQmxvY2sucHVzaCguLi5TdENvbnRyb2xsZXIuYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlKSlcblxuXHRcdGNvbnN0IHBheWxvYWRCb2R5OiBudW1iZXJbXSA9IFsweDVhLCBjbWRJZCAmIDB4ZmZdXG5cblx0XHRpZiAoY21kSWQgPT09IENNRF9NSUNfUFJFICYmIGJ1c0NoICE9PSB1bmRlZmluZWQgJiYgc2V0dGluZ0lkICE9PSB1bmRlZmluZWQgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0Ly8gUG9zaXRpb25hbCBmb3JtYXQ6IFsweDVhXSBbMHgwMl0gW2J1c0NoXSBbdmFsMF0gW3ZhbDFdIFt2YWwyXSAuLi5cblx0XHRcdC8vIFJlYWQgYWxsIHBvc2l0aW9ucyBmcm9tIGRldmljZVN0YXRlLCBvdmVycmlkZSB0aGUgdGFyZ2V0IHBvc2l0aW9uIHdpdGggbmV3IHZhbHVlLlxuXHRcdFx0Ly8gQWxzbyB1cGRhdGUgZGV2aWNlU3RhdGUgb3B0aW1pc3RpY2FsbHkgc28gY29uc2VjdXRpdmUgQ01EX01JQ19QUkUgY29tbWFuZHMgY2hhaW4gY29ycmVjdGx5LlxuXHRcdFx0aWYgKCF0aGlzLmRldmljZVN0YXRlLmhhcyhkZXN0SXApKSB0aGlzLmRldmljZVN0YXRlLnNldChkZXN0SXAsIG5ldyBNYXAoKSlcblx0XHRcdGNvbnN0IGlwU3RhdGUgPSB0aGlzLmRldmljZVN0YXRlLmdldChkZXN0SXApIVxuXHRcdFx0Y29uc3QgbnVtUG9zaXRpb25zID0gMyAvLyBnYWluLCBlbGVjdHJldC9waGFudG9tLCB1bmtub3duXG5cdFx0XHRjb25zdCBwb3NpdGlvbnM6IG51bWJlcltdID0gW11cblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgbnVtUG9zaXRpb25zOyBpKyspIHtcblx0XHRcdFx0Y29uc3Qgc3RhdGVLZXkgPSBtYWtlU2V0dGluZ0lkKHRoaXMubW9kZWwsIENNRF9NSUNfUFJFLCBpLCBidXNDaClcblx0XHRcdFx0Y29uc3QgdmFsID0gaSA9PT0gc2V0dGluZ0lkID8gTnVtYmVyKHZhbHVlKSA6IChpcFN0YXRlLmdldChzdGF0ZUtleSkgPz8gMClcblx0XHRcdFx0cG9zaXRpb25zLnB1c2godmFsKVxuXHRcdFx0XHRpcFN0YXRlLnNldChzdGF0ZUtleSwgdmFsKSAvLyBvcHRpbWlzdGljIHVwZGF0ZVxuXHRcdFx0fVxuXHRcdFx0cGF5bG9hZEJvZHkucHVzaChidXNDaCAmIDB4ZmYsIC4uLnBvc2l0aW9ucylcblx0XHR9IGVsc2Uge1xuXHRcdFx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIHBheWxvYWRCb2R5LnB1c2goYnVzQ2ggJiAweGZmKVxuXHRcdFx0aWYgKGFkZExlbikgcGF5bG9hZEJvZHkucHVzaChkYXRhQmxvY2subGVuZ3RoKVxuXHRcdFx0aWYgKGRhdGFCbG9jay5sZW5ndGggPiAwKSBwYXlsb2FkQm9keS5wdXNoKC4uLmRhdGFCbG9jaylcblx0XHR9XG5cblx0XHRjb25zdCBjcmMgPSBTdENvbnRyb2xsZXIuY3JjOER2YlMyKHBheWxvYWRCb2R5KVxuXHRcdGNvbnN0IHBheWxvYWRXaXRoQ3JjID0gQnVmZmVyLmZyb20oWy4uLnBheWxvYWRCb2R5LCBjcmNdKVxuXG5cdFx0Ly8gSHVtYW4tcmVhZGFibGUgaW5mbyBsb2cgZm9yIHRoZSBvdXRnb2luZyBjb21tYW5kXG5cdFx0aWYgKHNldHRpbmdJZCAhPT0gdW5kZWZpbmVkICYmIHZhbHVlICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdGNvbnN0IHZhbHVlQnl0ZXMgPSBTdENvbnRyb2xsZXIuYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlKVxuXHRcdFx0Y29uc3Qgc2V0dGluZzogUGFyc2VkU2V0dGluZyA9IHtcblx0XHRcdFx0Y21kX2lkOiBjbWRJZCxcblx0XHRcdFx0aWQ6IHNldHRpbmdJZCxcblx0XHRcdFx0YnVzQ2gsXG5cdFx0XHRcdHZhbHVlQnl0ZXMsXG5cdFx0XHR9XG5cdFx0XHRsb2dnZXIuaW5mbyhgVFggJHtkZXN0SXB9IHwgJHtmb3JtYXRQYXJzZWRTZXR0aW5nKHNldHRpbmcsIHRoaXMuYWN0aW9ucyl9YClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYFRYICR7ZGVzdElwfSB8ICR7Z2V0Q29tbWFuZE5hbWUoY21kSWQpfWApXG5cdFx0fVxuXG5cdFx0Ly8gUmVqZWN0IGNvbW1hbmRzIHRvIHVudmVyaWZpZWQgZGV2aWNlcyBcdTIwMTQgbG9nIHRoZSB3b3VsZC1iZSBwYWNrZXQgZmlyc3QgYXQgZGVidWdcblx0XHQvLyBzbyB0aGUgYnl0ZXMgYXJlIHZpc2libGUgZXZlbiB3aGVuIHRoZSBkZXZpY2UgaXMgb2ZmbGluZS5cblx0XHRpZiAoIXRoaXMuYXV0aG9yaXplZElwcy5oYXMoZGVzdElwKSkge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBQYWNrZXQgKG5vdCBzZW50IFx1MjAxNCBkZXZpY2Ugbm90IGF1dGhvcml6ZWQpIHRvICR7ZGVzdElwfTogJHtwYXlsb2FkV2l0aENyYy50b1N0cmluZygnaGV4Jyl9YClcblx0XHRcdHRocm93IG5ldyBFcnJvcihgRGV2aWNlIGF0ICR7ZGVzdElwfSBpcyBub3QgYXV0aG9yaXplZCBcdTIwMTQgdmVyaWZ5IHRoZSBJUCBhbmQgbW9kZWwgbWF0Y2ggYmVmb3JlIHNlbmRpbmcgY29tbWFuZHNgKVxuXHRcdH1cblxuXHRcdC8vIEVuc3VyZSB0aGUgRGFudGUgQ29uTW9uIHNlc3Npb24gKHBvcnQgODgwMCkgaXMgb3BlbiBiZWZvcmUgc2VuZGluZyBhbnkgU3R1ZGlvLVRcblx0XHQvLyBjb21tYW5kLiBvcGVuU2Vzc2lvbigpIGNhY2hlcyB0aGUgcmVzdWx0IFx1MjAxNCBoYW5kc2hha2Ugb25seSBydW5zIG9uY2UgcGVyIElQLlxuXHRcdGlmICghdGhpcy5zZXNzaW9uRXN0YWJsaXNoZWQuaGFzKGRlc3RJcCkpIHtcblx0XHRcdGF3YWl0IHRoaXMub3BlblNlc3Npb24oZGVzdElwKVxuXHRcdFx0Ly8gU2Vzc2lvbiBmYWlsdXJlIGlzIG5vbi1mYXRhbCBcdTIwMTQgbWFueSBkZXZpY2VzIHJlc3BvbmQgdG8gU3R1ZGlvLVQgcmVnYXJkbGVzcy5cblx0XHR9XG5cblx0XHQvLyBFbnN1cmUgd2UgYXJlIGxpc3RlbmluZyBmb3IgcmVwbGllcyBvbiB0aGUgaW50ZXJmYWNlIHRoYXQgd2lsbCByZWNlaXZlIHRoZW1cblx0XHRhd2FpdCB0aGlzLmVuc3VyZU1lbWJlcnNoaXBGb3IoZGVzdElwKVxuXG5cdFx0Y29uc3QgdG90YWxMZW4gPSAyNCArIHBheWxvYWRXaXRoQ3JjLmxlbmd0aFxuXHRcdGNvbnN0IGhlYWRlciA9IGF3YWl0IHRoaXMuYnVpbGRIZWFkZXIodG90YWxMZW4sIGRlc3RJcClcblx0XHRjb25zdCBwYWNrZXQgPSBCdWZmZXIuY29uY2F0KFtoZWFkZXIsIHBheWxvYWRXaXRoQ3JjXSlcblxuXHRcdGxvZ2dlci5kZWJ1ZyhgU2VuZGluZyBwYWNrZXQgdG8gJHtkZXN0SXB9OiAke3BhY2tldC50b1N0cmluZygnaGV4Jyl9YClcblxuXHRcdGNvbnN0IGtleSA9IGAke2Rlc3RJcH06JHtjbWRJZH1gXG5cblx0XHRyZXR1cm4gbmV3IFByb21pc2U8QnVmZmVyPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoYFRpbWVvdXQgd2FpdGluZyBmb3IgQUNLIGZyb20gTW9kZWwgJHt0aGlzLm1vZGVsfSBhdCAke2Rlc3RJcH06ODcwMGApKVxuXHRcdFx0fSwgdGltZW91dE1zKVxuXG5cdFx0XHR0aGlzLnBlbmRpbmdBY2tzLnNldChrZXksIHtcblx0XHRcdFx0cmVzb2x2ZTogKGJ1ZikgPT4ge1xuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRyZXNvbHZlKGJ1Zilcblx0XHRcdFx0fSxcblx0XHRcdFx0cmVqZWN0OiAoZXJyKSA9PiB7XG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdHJlamVjdChlcnIpXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHRpbWVyLFxuXHRcdFx0fSlcblxuXHRcdFx0dGhpcy50eFNvY2tldC5zZW5kKHBhY2tldCwgdGhpcy5kZWZhdWx0UG9ydCwgZGVzdElwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdGlmIChlcnIpIHtcblx0XHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVycikpKVxuXHRcdFx0XHR9XG5cdFx0XHR9KVxuXHRcdH0pXG5cdH1cblxuXHRwcml2YXRlIGhhbmRsZUluY29taW5nKG1zZzogQnVmZmVyLCBzcmNJcDogc3RyaW5nKSB7XG5cdFx0aWYgKG1zZy5sZW5ndGggPCA0KSByZXR1cm5cblx0XHRpZiAobXNnWzBdICE9PSAweGZmIHx8IG1zZ1sxXSAhPT0gMHhmZikgcmV0dXJuXG5cblx0XHRjb25zdCBtc2dUeXBlID0gbXNnLnJlYWRVSW50MTZCRSgyKVxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlICgweDAxNzApIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIFRoZXNlIGhhdmUgXCJBdWRpbmF0ZVwiIGF0IG9mZnNldCAxNiwgbm90IFwiU3R1ZGlvLVRcIiBcdTIwMTQgaGFuZGxlIGJlZm9yZVxuXHRcdC8vIHRoZSBTdHVkaW8tVCBzaWduYXR1cmUgY2hlY2sgYmVsb3cuXG5cdFx0aWYgKG1zZ1R5cGUgPT09IERBTlRFX01TR19JTkZPX1JFU1BPTlNFICYmIHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNpemUgPiAwKSB7XG5cdFx0XHRjb25zdCBkZXZpY2UgPSBwYXJzZURhbnRlSW5mb1Jlc3BvbnNlKG1zZywgc3JjSXApXG5cdFx0XHRpZiAoZGV2aWNlKSB7XG5cdFx0XHRcdGxvZ2dlci5kZWJ1Zyhcblx0XHRcdFx0XHRgRGFudGUgaW5mbyByZXNwb25zZSBmcm9tICR7c3JjSXB9OiBgICtcblx0XHRcdFx0XHRcdGBEZXZpY2VJRD1cIiR7ZGV2aWNlLm5hbWV9XCIsIGAgK1xuXHRcdFx0XHRcdFx0YE1vZGVsPVwiJHtkZXZpY2UubW9kZWx9XCIsIGAgK1xuXHRcdFx0XHRcdFx0YE1vZGVsTmFtZT1cIiR7ZGV2aWNlLm1vZGVsTmFtZX1cIiwgYCArXG5cdFx0XHRcdFx0XHRgTWFudWZhY3R1cmVyPVwiJHtkZXZpY2UubWFudWZhY3R1cmVyfVwiYCxcblx0XHRcdFx0KVxuXG5cdFx0XHRcdC8vIE9ubHkgYWNjZXB0IFN0dWRpbyBUZWNobm9sb2dpZXMgZGV2aWNlcyAoaWRlbnRpZmllZCBieSBEZXZpY2VJRCBcIlN0dWRpby1UXCIpXG5cdFx0XHRcdGlmIChkZXZpY2UubmFtZSA9PT0gJ1N0dWRpby1UJykge1xuXHRcdFx0XHRcdGZvciAoY29uc3QgY2Igb2YgdGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMudmFsdWVzKCkpIHtcblx0XHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRcdGNiKGRldmljZSlcblx0XHRcdFx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBJZ25vcmluZyBub24tU3R1ZGlvIFRlY2hub2xvZ2llcyBkZXZpY2U6IERldmljZUlEPVwiJHtkZXZpY2UubmFtZX1cIiBAICR7c3JjSXB9YClcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0aWYgKG1zZy5sZW5ndGggPCAyNSkgcmV0dXJuXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgY29udHJvbCBwcm90b2NvbCBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRjb25zdCBzaWcgPSBtc2cuc3ViYXJyYXkoMTYsIDI0KVxuXHRcdGlmIChzaWcudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdTdHVkaW8tVCcpIHJldHVyblxuXG5cdFx0Ly8gSWdub3JlIFN0dWRpby1UIHBhY2tldHMgZnJvbSBkZXZpY2VzIHdlIGhhdmVuJ3QgYXV0aG9yaXplZC5cblx0XHQvLyBUaGlzIHByZXZlbnRzIGNyb3NzLWNvbnRhbWluYXRpb24gd2hlbiBtdWx0aXBsZSBkZXZpY2VzIChvciBtdWx0aXBsZVxuXHRcdC8vIENvbXBhbmlvbiBpbnN0YW5jZXMpIGFyZSBvbiB0aGUgc2FtZSBuZXR3b3JrIFx1MjAxNCBhbGwgc2hhcmUgdGhlIG11bHRpY2FzdFxuXHRcdC8vIGdyb3VwIDIyNC4wLjAuMjMxOjg3MDIgYW5kIHdpbGwgcmVjZWl2ZSBlYWNoIG90aGVyJ3MgQUNLcyBhbmQgcHVzaGVzLlxuXHRcdGlmICghdGhpcy5hdXRob3JpemVkSXBzLmhhcyhzcmNJcCkpIHtcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgSWdub3JpbmcgU3R1ZGlvLVQgcGFja2V0IGZyb20gdW5hdXRob3JpemVkIGRldmljZSAke3NyY0lwfWApXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBQYXlsb2FkIHN0YXJ0cyBhdCBvZmZzZXQgMjRcblx0XHQvLyBMYXlvdXQ6IFsweDVhXSBbY21kSWR8MHg4MF0gW2RhdGEuLi5dIFtjcmNdXG5cdFx0Y29uc3Qgc3RQYXlsb2FkID0gbXNnLnN1YmFycmF5KDI0KVxuXHRcdGlmIChzdFBheWxvYWQubGVuZ3RoIDwgMikgcmV0dXJuXG5cdFx0aWYgKHN0UGF5bG9hZFswXSAhPT0gMHg1YSkgcmV0dXJuXG5cblx0XHQvLyBEZXZpY2UgcmVwbGllcyB3aXRoIGNtZCB8IDB4ODBcblx0XHRjb25zdCByZXNwQ21kSWQgPSBzdFBheWxvYWRbMV1cblx0XHRjb25zdCBpc1Jlc3BvbnNlID0gKHJlc3BDbWRJZCAmIDB4ODApICE9PSAwXG5cdFx0Y29uc3Qgb3JpZ2luYWxDbWRJZCA9IHJlc3BDbWRJZCAmIDB4N2YgLy8gc3RyaXAgdGhlIHJlc3BvbnNlIGZsYWdcblxuXHRcdC8vIExvZyByYXcgcGFja2V0IGZvciBDTURfR0VUX0FMTF9TRVRUSU5HUyAoMHgwYSkgcmVzcG9uc2VzIGJlZm9yZSBwYXJzaW5nXG5cdFx0aWYgKGlzUmVzcG9uc2UgJiYgb3JpZ2luYWxDbWRJZCA9PT0gQ01EX0dFVF9BTExfU0VUVElOR1MpIHtcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgUmVjZWl2ZWQgcGFja2V0IGZyb20gJHtzcmNJcH06ICR7bXNnLnRvU3RyaW5nKCdoZXgnKX1gKVxuXHRcdH1cblxuXHRcdC8vIExvZyB0aGUgcGF5bG9hZCAod29ya3MgZm9yIGJvdGggcmVxdWVzdHMgYW5kIHJlc3BvbnNlcylcblx0XHR0aGlzLmxvZ1N0UGF5bG9hZChzcmNJcCwgb3JpZ2luYWxDbWRJZCwgbXNnLCBzdFBheWxvYWQpXG5cblx0XHQvLyBPbmx5IHByb2Nlc3MgYXMgQUNLIGlmIHRoaXMgaXMgYSByZXNwb25zZSB0byBvdXIgcmVxdWVzdFxuXHRcdGlmIChpc1Jlc3BvbnNlKSB7XG5cdFx0XHRjb25zdCBrZXkgPSBgJHtzcmNJcH06JHtvcmlnaW5hbENtZElkfWBcblx0XHRcdGNvbnN0IHBlbmRpbmcgPSB0aGlzLnBlbmRpbmdBY2tzLmdldChrZXkpXG5cdFx0XHRpZiAocGVuZGluZykge1xuXHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdHBlbmRpbmcucmVzb2x2ZShtc2cpXG5cdFx0XHR9XG5cdFx0fVxuXHRcdC8vIFVuc29saWNpdGVkIG1lc3NhZ2VzIGFuZCByZXF1ZXN0cyBmcm9tIG90aGVyIHNvdXJjZXMgYXJlIGxvZ2dlZCBhYm92ZVxuXHR9XG5cblx0LyoqXG5cdCAqIERlY29kZXMgYW5kIGxvZ3MgYSBTdHVkaW8tVCByZXNwb25zZSBwYXlsb2FkLlxuXHQgKiBSZWNlaXZlcyBib3RoIHRoZSBmdWxsIG1zZyAoZm9yIHBhcnNlcnMgdGhhdCBuZWVkIHRoZSBTdHVkaW8tVCBoZWFkZXIpXG5cdCAqIGFuZCBzdFBheWxvYWQgKG1zZy5zdWJhcnJheSgyNCksIGZvciBkaXJlY3QgYnl0ZSBhY2Nlc3MpLlxuXHQgKlxuXHQgKiBzdFBheWxvYWQgbGF5b3V0OlxuXHQgKiAgIFswXSAgICAgIDB4NWEgIG1hZ2ljXG5cdCAqICAgWzFdICAgICAgY21kSWQgfCAweDgwXG5cdCAqICAgWzIuLi0yXSAgZGF0YSBieXRlc1xuXHQgKiAgIFstMV0gICAgIENSQy04L0RWQi1TMlxuXHQgKi9cblx0cHJpdmF0ZSBsb2dTdFBheWxvYWQoc3JjSXA6IHN0cmluZywgY21kSWQ6IG51bWJlciwgbXNnOiBCdWZmZXIsIHN0UGF5bG9hZDogQnVmZmVyKTogdm9pZCB7XG5cdFx0Y29uc3QgY21kTmFtZSA9IGdldENvbW1hbmROYW1lKGNtZElkKVxuXHRcdGNvbnN0IGRhdGEgPSBzdFBheWxvYWQuc3ViYXJyYXkoMiwgc3RQYXlsb2FkLmxlbmd0aCAtIDEpIC8vIHN0cmlwIG1hZ2ljK2NtZElkIGhlYWRlciBhbmQgQ1JDXG5cblx0XHQvLyBQYXlsb2FkIHN0cnVjdHVyZTogW2NtZDoweDhkXSBbZGF0YSBieXRlcy4uLl0gW2NyY11cblx0XHRjb25zdCByZXNwQ21kSWQgPSBzdFBheWxvYWRbMV1cblx0XHRjb25zdCBjcmMgPSBzdFBheWxvYWRbc3RQYXlsb2FkLmxlbmd0aCAtIDFdXG5cdFx0Y29uc3QgZnVsbFN0cnVjdHVyZSA9IGBbY21kOiR7dG9IZXgocmVzcENtZElkKX0gZGF0YToke2RhdGEudG9TdHJpbmcoJ2hleCcpfSBjcmM6JHt0b0hleChjcmMpfV1gXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX0dFVF9BTExfU0VUVElOR1MgKDB4MGEpIGFuZCBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gUGFyc2UgYWxsIHNldHRpbmdzLCBkaWZmIGFnYWluc3QgZGV2aWNlU3RhdGUsIGxvZyBjaGFuZ2VkIGF0IGluZm8gLyB1bmNoYW5nZWQgYXQgZGVidWcsXG5cdFx0Ly8gdGhlbiB1cGRhdGUgZGV2aWNlU3RhdGUuIENNRF9HRVRfQUxMX1NFVFRJTkdTIGFsc28gc2VydmVzIGFzIHRoZSBpbml0aWFsIHN0YXRlIHBvcHVsYXRpb24gb24gY29ubmVjdC5cblx0XHRpZiAoY21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTIHx8IGNtZElkID09PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdFx0aWYgKCF0aGlzLm1vZGVsKSB7XG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBzZXR0aW5ncyA9XG5cdFx0XHRcdFx0Y21kSWQgPT09IENNRF9TRVRUSU5HU19QVVNIXG5cdFx0XHRcdFx0XHQ/IHBhcnNlU2V0dGluZ3NSZXNwb25zZSh0aGlzLm1vZGVsLCBtc2cpXG5cdFx0XHRcdFx0XHQ6IHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbCh0aGlzLm1vZGVsLCBtc2cpXG5cblx0XHRcdFx0Y29uc3QgcHJldlN0YXRlID0gdGhpcy5kZXZpY2VTdGF0ZS5nZXQoc3JjSXApID8/IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KClcblx0XHRcdFx0Y29uc3QgbmV3U3RhdGUgPSBuZXcgTWFwPHN0cmluZywgbnVtYmVyPihwcmV2U3RhdGUpIC8vIGNvcHkgXHUyMDE0IHVwZGF0ZSBpbiBwbGFjZVxuXG5cdFx0XHRcdGZvciAoY29uc3QgcyBvZiBzZXR0aW5ncykge1xuXHRcdFx0XHRcdGNvbnN0IHN0YXRlS2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBzLmNtZF9pZCwgcy5pZCwgcy5idXNDaClcblx0XHRcdFx0XHQvLyBGb3IgUkdCIGNvbG9ycyAoMyBieXRlcyksIHBhY2sgaW50byBzaW5nbGUgbnVtYmVyOiAoUiA8PCAxNikgfCAoRyA8PCA4KSB8IEJcblx0XHRcdFx0XHRjb25zdCBuZXdWYWx1ZSA9XG5cdFx0XHRcdFx0XHRzLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAzXG5cdFx0XHRcdFx0XHRcdD8gKHMudmFsdWVCeXRlc1swXSA8PCAxNikgfCAocy52YWx1ZUJ5dGVzWzFdIDw8IDgpIHwgcy52YWx1ZUJ5dGVzWzJdXG5cdFx0XHRcdFx0XHRcdDogKHMudmFsdWVCeXRlc1swXSA/PyAwKVxuXHRcdFx0XHRcdGNvbnN0IHByZXZWYWx1ZSA9IHByZXZTdGF0ZS5nZXQoc3RhdGVLZXkpXG5cdFx0XHRcdFx0Y29uc3QgY2hhbmdlZCA9IHByZXZWYWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHByZXZWYWx1ZSAhPT0gbmV3VmFsdWVcblxuXHRcdFx0XHRcdG5ld1N0YXRlLnNldChzdGF0ZUtleSwgbmV3VmFsdWUpXG5cblx0XHRcdFx0XHRjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXRQYXJzZWRTZXR0aW5nKHMsIHRoaXMuYWN0aW9ucylcblx0XHRcdFx0XHRpZiAoY2hhbmdlZCkge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLmluZm8oYFJYICR7c3JjSXB9IHwgJHtmb3JtYXR0ZWR9YClcblx0XHRcdFx0XHRcdC8vIFRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlIFx1MjAxNCB1c2UgYmFzZSBrZXkgd2l0aG91dCBidXNDaCBzbyBpdCBtYXRjaGVzIHRoZSBmZWVkYmFjayBkZWZpbml0aW9uIElEXG5cdFx0XHRcdFx0XHRpZiAodGhpcy5mZWVkYmFja0NhbGxiYWNrKSB7XG5cdFx0XHRcdFx0XHRcdGxldCBiYXNlSWQgPSBzLmlkXG5cdFx0XHRcdFx0XHRcdGNvbnN0IGJhc2VBY3Rpb24gPSB0aGlzLmFjdGlvbnMuZmluZCgoYSkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdGlmIChhLmNtZF9pZCAhPT0gcy5jbWRfaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdFx0XHRcdGlmIChhLmlkID09PSBzLmlkKSByZXR1cm4gdHJ1ZVxuXHRcdFx0XHRcdFx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYS5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRcdFx0XHRcdGlmICghaWRBZGRPcHRpb24/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdFx0XHRcdGNvbnN0IG9mZnNldCA9IHMuaWQgLSBhLmlkXG5cdFx0XHRcdFx0XHRcdFx0cmV0dXJuIG9mZnNldCA+IDAgJiYgaWRBZGRPcHRpb24uY2hvaWNlcy5zb21lKChjKSA9PiBjLmlkID09PSBvZmZzZXQpXG5cdFx0XHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0XHRcdGlmIChiYXNlQWN0aW9uKSBiYXNlSWQgPSBiYXNlQWN0aW9uLmlkXG5cdFx0XHRcdFx0XHRcdGNvbnN0IGJhc2VGZWVkYmFja0tleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgcy5jbWRfaWQsIGJhc2VJZClcblx0XHRcdFx0XHRcdFx0dGhpcy5mZWVkYmFja0NhbGxiYWNrKGJhc2VGZWVkYmFja0tleSlcblx0XHRcdFx0XHRcdFx0dGhpcy5mZWVkYmFja0NhbGxiYWNrKGJhc2VGZWVkYmFja0tleSArICdfYm9vbCcpXG5cdFx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0XHRsb2dnZXIud2FybihgZmVlZGJhY2tDYWxsYmFjayBub3Qgc2V0IFx1MjAxNCBza2lwcGluZyBmZWVkYmFjayB1cGRhdGUgZm9yICR7c3RhdGVLZXl9YClcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCAke3NyY0lwfSB8ICR7Zm9ybWF0dGVkfWApXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdHRoaXMuZGV2aWNlU3RhdGUuc2V0KHNyY0lwLCBuZXdTdGF0ZSlcblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYFJYICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8IHBhcnNlIGZhaWxlZDogJHtlfSB8ICR7ZnVsbFN0cnVjdHVyZX1gKVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIEFsbCBvdGhlciBjb21tYW5kcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRjb25zdCBkZWNvZGVkID0gdGhpcy5kZWNvZGVTdERhdGEoY21kSWQsIGRhdGEpXG5cdFx0Ly8gQ01EX0JVU19HRVQgKGtlZXBhbGl2ZSkgaXMgaGlnaC1mcmVxdWVuY3kgbm9pc2UgXHUyMDE0IGxvZyBhdCBkZWJ1ZyBvbmx5XG5cdFx0Y29uc3QgbG9nRm4gPSBjbWRJZCA9PT0gQ01EX0JVU19HRVQgPyBsb2dnZXIuZGVidWcuYmluZChsb2dnZXIpIDogbG9nZ2VyLmluZm8uYmluZChsb2dnZXIpXG5cdFx0aWYgKGRlY29kZWQpIHtcblx0XHRcdGxvZ0ZuKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9IHwgJHtkZWNvZGVkfWApXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ0ZuKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogQXR0ZW1wdHMgdG8gZGVjb2RlIHRoZSBkYXRhIGJ5dGVzIG9mIGEgU3R1ZGlvLVQgcmVzcG9uc2UgaW50byBhXG5cdCAqIGh1bWFuLXJlYWRhYmxlIHN0cmluZy4gUmV0dXJucyBudWxsIHRvIGZhbGwgYmFjayB0byByYXcgaGV4LlxuXHQgKi9cblx0cHJpdmF0ZSBkZWNvZGVTdERhdGEoY21kSWQ6IG51bWJlciwgZGF0YTogQnVmZmVyKTogc3RyaW5nIHwgbnVsbCB7XG5cdFx0aWYgKGRhdGEubGVuZ3RoID09PSAwKSByZXR1cm4gJ0FDSydcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBDaGVjayBmb3Igc2luZ2xlLWJ5dGUgcmVzcG9uc2VzIChBQ0sgb3IgZXJyb3IpIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0aWYgKGRhdGFbMF0gPT09IDB4MDApIHtcblx0XHRcdFx0cmV0dXJuICdBQ0sgb2snXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRyZXR1cm4gYEVSUk9SICR7dG9IZXgoZGF0YVswXSl9YFxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdHN3aXRjaCAoY21kSWQpIHtcblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfTUlDX1BSRSAoMHgwMik6IHJhdyBwcmVhbXAgZWNobyBcdTIwMTQgcG9zaXRpb25hbCBieXRlcywgbm8gc2V0dGluZyBJRHMgXHUyNTAwXHUyNTAwXG5cdFx0XHQvLyBEZXZpY2UgZWNob2VzIFtidXNDaF1bdmFsMF1bdmFsMV0uLi4gY29uZmlybWluZyB0aGUgYXBwbGllZCB2YWx1ZXMuXG5cdFx0XHRjYXNlIENNRF9NSUNfUFJFOiB7XG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRjb25zdCB2YWxzID0gQXJyYXkuZnJvbShkYXRhLnN1YmFycmF5KDEpKVxuXHRcdFx0XHRcdC5tYXAoKGIsIGkpID0+IGBbJHtpfV09MHgke2IudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJyl9KCR7Yn0pYClcblx0XHRcdFx0XHQuam9pbignICcpXG5cdFx0XHRcdHJldHVybiBgY2g9JHtidXNDaH0gJHt2YWxzfWBcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9ERVZfU1BFQyAoMHgwZCk6IHNpbmdsZS1ieXRlIEFDSyBvciBlY2hvIG9mIGFwcGxpZWQgc2V0dGluZyBcdTI1MDBcdTI1MDBcblx0XHRcdC8vIERldmljZSBzZW5kcyB0d28gQ01EX0RFVl9TUEVDIHBhY2tldHMgaW4gcmVzcG9uc2UgdG8gYSBzZXQ6XG5cdFx0XHQvLyAgIDEuIEFDSzogIFtzdGF0dXNdICAgICAgICAgICAgICAgKDEgYnl0ZSwgMHgwMCA9IG9rKVxuXHRcdFx0Ly8gICAyLiBFY2hvOiBbYnVzQ2hdIFtzZXR0aW5nSWRdIFt2YWx1ZS4uLl0gIChjb25maXJtaW5nIHdoYXQgd2FzIGFwcGxpZWQpXG5cdFx0XHRjYXNlIENNRF9ERVZfU1BFQzoge1xuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPT09IDEpIHtcblx0XHRcdFx0XHRyZXR1cm4gZGF0YVswXSA9PT0gMHgwMCA/ICdBQ0sgb2snIDogYEFDSyBlcnI9JHt0b0hleChkYXRhWzBdKX1gXG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKGRhdGEubGVuZ3RoID49IDMpIHtcblx0XHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBkYXRhWzFdXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IGRhdGEuc3ViYXJyYXkoMilcblx0XHRcdFx0XHRjb25zdCBhY3Rpb24gPSB0aGlzLmFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IHNldHRpbmdJZClcblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nTmFtZSA9IGFjdGlvbj8ubmFtZSA/PyBgc2V0dGluZz0ke3RvSGV4KHNldHRpbmdJZCl9YFxuXHRcdFx0XHRcdGNvbnN0IGNob2ljZXMgPSBhY3Rpb24/Lm9wdGlvbnM/LlswXT8uY2hvaWNlc1xuXHRcdFx0XHRcdGNvbnN0IHZhbHVlTnVtID0gdmFsdWVCeXRlcy5sZW5ndGggPT09IDEgPyB2YWx1ZUJ5dGVzWzBdIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlTGFiZWwgPVxuXHRcdFx0XHRcdFx0Y2hvaWNlcyAmJiB2YWx1ZU51bSAhPT0gdW5kZWZpbmVkID8gY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSB2YWx1ZU51bSk/LmxhYmVsIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVTdHIgPSBjaG9pY2VMYWJlbCA/IGAke2Nob2ljZUxhYmVsfSAoJHt0b0hleCh2YWx1ZU51bSEpfSlgIDogYnl0ZXNUb0hleChBcnJheS5mcm9tKHZhbHVlQnl0ZXMpKVxuXHRcdFx0XHRcdGNvbnN0IHJhd1RhZyA9IGBbJHt0b0hleChjbWRJZCl9LyR7dG9IZXgoc2V0dGluZ0lkKX1dPSR7Ynl0ZXNUb0hleChBcnJheS5mcm9tKHZhbHVlQnl0ZXMpKX1gXG5cdFx0XHRcdFx0cmV0dXJuIGBlY2hvIGNoPSR7YnVzQ2h9IHwgJHtzZXR0aW5nTmFtZX06ICR7dmFsdWVTdHJ9ICR7cmF3VGFnfWBcblx0XHRcdFx0fVxuXHRcdFx0XHRyZXR1cm4gYHJhdzogJHtkYXRhLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHR9XG5cblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfTUlDX1BSRV9CVVMgKDB4MTIpOiBNdWx0aS1ieXRlIGVjaG8gcmVzcG9uc2VzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdFx0Y2FzZSBDTURfTUlDX1BSRV9CVVM6IHtcblx0XHRcdFx0Ly8gQWxyZWFkeSBoYW5kbGVkIHNpbmdsZS1ieXRlIGFib3ZlLCBzbyBtdWx0aS1ieXRlIG11c3QgYmUgZWNob1xuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPj0gMykge1xuXHRcdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGRhdGFbMV1cblx0XHRcdFx0XHRjb25zdCB2YWx1ZUJ5dGVzID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRcdGNvbnN0IGFjdGlvbiA9IHRoaXMuYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gc2V0dGluZ0lkKVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdOYW1lID0gYWN0aW9uPy5uYW1lID8/IGBzZXR0aW5nPSR7dG9IZXgoc2V0dGluZ0lkKX1gXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVOdW0gPSB2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSA/IHZhbHVlQnl0ZXNbMF0gOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VzID0gYWN0aW9uPy5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAndmFsdWUnKT8uY2hvaWNlc1xuXHRcdFx0XHRcdGNvbnN0IGNob2ljZUxhYmVsID1cblx0XHRcdFx0XHRcdGNob2ljZXMgJiYgdmFsdWVOdW0gIT09IHVuZGVmaW5lZCA/IGNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gdmFsdWVOdW0pPy5sYWJlbCA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlU3RyID0gY2hvaWNlTGFiZWwgPz8gYDB4JHt2YWx1ZUJ5dGVzLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHRcdFx0cmV0dXJuIGBlY2hvIGNoPSR7YnVzQ2h9IHwgJHtzZXR0aW5nTmFtZX06ICR7dmFsdWVTdHJ9YFxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBudWxsXG5cdFx0XHR9XG5cblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBCdXMtc2NvcGVkIGdldC9zZXQgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHRjYXNlIENNRF9CVVNfR0VUOlxuXHRcdFx0Y2FzZSBDTURfQlVTX1NFVDoge1xuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPCAyKSByZXR1cm4gbnVsbFxuXHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gZGF0YVsxXVxuXHRcdFx0XHRjb25zdCB2YWx1ZSA9IGRhdGEuc3ViYXJyYXkoMilcblx0XHRcdFx0cmV0dXJuIGBjaD0ke2J1c0NofSBzZXR0aW5nPSR7dG9IZXgoc2V0dGluZ0lkKX0gdmFsdWU9JHt2YWx1ZS50b1N0cmluZygnaGV4Jyl9YFxuXHRcdFx0fVxuXG5cdFx0XHRkZWZhdWx0OlxuXHRcdFx0XHRyZXR1cm4gbnVsbCAvLyBmYWxsIHRocm91Z2ggdG8gcmF3IGhleFxuXHRcdH1cblx0fVxuXG5cdHByaXZhdGUgc3RhdGljIGJ1aWxkVmFsdWVCeXRlcyh2YWx1ZTogdW5rbm93bik6IG51bWJlcltdIHtcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicpIHJldHVybiBbdmFsdWUgPyAxIDogMF1cblx0XHRpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHJldHVybiB2YWx1ZS5tYXAoKHYpID0+IE51bWJlcih2KSAmIDB4ZmYpXG5cdFx0aWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicpIHtcblx0XHRcdGlmICh2YWx1ZSA+IDB4ZmYpIHJldHVybiBbKHZhbHVlID4+IDE2KSAmIDB4ZmYsICh2YWx1ZSA+PiA4KSAmIDB4ZmYsIHZhbHVlICYgMHhmZl1cblx0XHRcdHJldHVybiBbdmFsdWUgJiAweGZmXVxuXHRcdH1cblx0XHR0aHJvdyBuZXcgRXJyb3IoYFVuc3VwcG9ydGVkIHZhbHVlIHR5cGUgZm9yIFNUY29udHJvbGxlcjogJHt2YWx1ZX1gKVxuXHR9XG5cblx0cHJpdmF0ZSBhc3luYyBidWlsZEhlYWRlcih0b3RhbExlbjogbnVtYmVyLCBkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0bGV0IG1hYyA9IHRoaXMubWFjQ2FjaGUuZ2V0KGRlc3RJcClcblx0XHRpZiAoIW1hYykge1xuXHRcdFx0bWFjID0gYXdhaXQgZ2V0TWFjRm9yRGVzdGluYXRpb24oZGVzdElwKVxuXHRcdFx0dGhpcy5tYWNDYWNoZS5zZXQoZGVzdElwLCBtYWMpXG5cdFx0fVxuXG5cdFx0cmV0dXJuIEJ1ZmZlci5jb25jYXQoW1xuXHRcdFx0QnVmZmVyLmZyb20oWzB4ZmYsIDB4ZmYsIDB4MDAsIHRvdGFsTGVuICYgMHhmZiwgMHgwNywgMHhlMSwgMHgwMCwgMHgwMCwgLi4ubWFjLCAweDAwLCAweDAwXSksXG5cdFx0XHRCdWZmZXIuZnJvbSgnU3R1ZGlvLVQnLCAndXRmOCcpLFxuXHRcdF0pXG5cdH1cblxuXHRwcml2YXRlIHN0YXRpYyBjcmM4RHZiUzIoZGF0YTogbnVtYmVyW10pOiBudW1iZXIge1xuXHRcdGxldCBjcmMgPSAwXG5cdFx0Zm9yIChjb25zdCBiIG9mIGRhdGEpIHtcblx0XHRcdGNyYyBePSBiXG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IDg7IGkrKykge1xuXHRcdFx0XHRjcmMgPSAoY3JjICYgMHg4MCkgIT09IDAgPyAoKGNyYyA8PCAxKSBeIDB4ZDUpICYgMHhmZiA6IChjcmMgPDwgMSkgJiAweGZmXG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiBjcmNcblx0fVxuXG5cdC8qKlxuXHQgKiBSZXR1cm5zIHRoZSBjdXJyZW50IGtub3duIHZhbHVlIGZvciBhIHNldHRpbmcgb24gYSBkZXZpY2UsIG9yIHVuZGVmaW5lZCBpZiB1bmtub3duLlxuXHQgKiBVc2UgZm9yIGZlZWRiYWNrcyBcdTIwMTQgdmFsdWUgaXMgdXBkYXRlZCBvbiBldmVyeSBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikgZnJvbSB0aGUgZGV2aWNlLlxuXHQgKlxuXHQgKiBAcGFyYW0gaXAgICAgICAgIERldmljZSBJUCBhZGRyZXNzXG5cdCAqIEBwYXJhbSBjbWRJZCAgICAgQ29tbWFuZCBJRCAoZS5nLiBDTURfREVWX1NQRUMpXG5cdCAqIEBwYXJhbSBzZXR0aW5nSWQgU2V0dGluZyBJRCAoZS5nLiAweDAyIGZvciBDb250cm9sIFNvdXJjZSlcblx0ICogQHBhcmFtIGJ1c0NoICAgICBPcHRpb25hbCBidXMvY2hhbm5lbCBJRCBmb3IgbXVsdGktY2hhbm5lbCBjb21tYW5kc1xuXHQgKi9cblx0cHVibGljIGdldFNldHRpbmdWYWx1ZShpcDogc3RyaW5nLCBjbWRJZDogbnVtYmVyLCBzZXR0aW5nSWQ6IG51bWJlciwgYnVzQ2g/OiBudW1iZXIpOiBudW1iZXIgfCB1bmRlZmluZWQge1xuXHRcdGNvbnN0IGtleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgY21kSWQsIHNldHRpbmdJZCwgYnVzQ2gpXG5cdFx0cmV0dXJuIHRoaXMuZGV2aWNlU3RhdGUuZ2V0KGlwKT8uZ2V0KGtleSlcblx0fVxuXG5cdHB1YmxpYyBhc3luYyByZXNldERldmljZShkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0cmV0dXJuIHRoaXMuc2VuZEF3YWl0QWNrKENNRF9SRVNFVF9ERVZJQ0UsIHVuZGVmaW5lZCwgMHgwMCwgdW5kZWZpbmVkLCBkZXN0SXAsIGZhbHNlKVxuXHR9XG5cblx0cHVibGljIGFzeW5jIGdsb2JhbE1pY0tpbGwoZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdHJldHVybiB0aGlzLnNlbmRBd2FpdEFjayhDTURfR0xPQkFMX01JQ19LSUxMLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBkZXN0SXAsIGZhbHNlKVxuXHR9XG59XG4iLCAiaW1wb3J0IGRncmFtIGZyb20gJ2RncmFtJ1xuaW1wb3J0IG9zIGZyb20gJ29zJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignRGFudGUnKVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgRGFudGUgZGlzY292ZXJ5IGNvbnN0YW50cyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuLyoqIERhbnRlIGRldmljZSBpbmZvIHJlcXVlc3QgbWVzc2FnZSB0eXBlIChzZW50IHRvIHBvcnQgODcwMCkgKi9cbmV4cG9ydCBjb25zdCBEQU5URV9NU0dfSU5GT19SRVFVRVNUID0gMHgwMDIwXG4vKiogRGFudGUgZGV2aWNlIGluZm8gcmVzcG9uc2UgbWVzc2FnZSB0eXBlIChyZWNlaXZlZCBvbiBwb3J0IDg3MDIpICovXG5leHBvcnQgY29uc3QgREFOVEVfTVNHX0lORk9fUkVTUE9OU0UgPSAweDAxNzBcbmV4cG9ydCBjb25zdCBEQU5URV9JTkZPX01JTl9MRU4gPSAweGNjICsgNjQgLy8gMjY4IGJ5dGVzIFx1MjAxNCBuZWVkIGZ1bGwgbW9kZWwgZmllbGRcblxuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkRGFudGVJbmZvUmVxdWVzdCgpOiBCdWZmZXIge1xuXHRjb25zdCBidWYgPSBCdWZmZXIuYWxsb2MoMzIsIDApXG5cdGNvbnN0IHNlcSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDB4ZmZmZilcblxuXHRidWYud3JpdGVVSW50MTZCRSgweGZmZmYsIDApXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKERBTlRFX01TR19JTkZPX1JFUVVFU1QsIDIpXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKHNlcSwgNClcblxuXHRjb25zdCBtYWMgPSBnZXRGaXJzdExvY2FsTWFjKClcblx0bWFjLmNvcHkoYnVmLCA4KVxuXG5cdEJ1ZmZlci5mcm9tKCdBdWRpbmF0ZScsICdhc2NpaScpLmNvcHkoYnVmLCAxNilcblx0YnVmLndyaXRlVUludDE2QkUoMHgwNzM5LCAyNClcblx0YnVmLndyaXRlVUludDE2QkUoMHgwMGMxLCAyNilcblx0YnVmLndyaXRlVUludDMyQkUoMHgwMDBmNDI0MCwgMjgpXG5cblx0cmV0dXJuIGJ1ZlxufVxuXG4vKiogUmV0dXJucyB0aGUgZmlyc3Qgbm9uLWxvb3BiYWNrIE1BQyBhcyBhIDYtYnl0ZSBCdWZmZXIsIG9yIHplcm9zLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldEZpcnN0TG9jYWxNYWMoKTogQnVmZmVyIHtcblx0dHJ5IHtcblx0XHRjb25zdCBpZmFjZXMgPSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpXG5cdFx0Zm9yIChjb25zdCBuYW1lIG9mIE9iamVjdC5rZXlzKGlmYWNlcykpIHtcblx0XHRcdGZvciAoY29uc3QgYWRkciBvZiBpZmFjZXNbbmFtZV0gPz8gW10pIHtcblx0XHRcdFx0aWYgKCFhZGRyLmludGVybmFsICYmIGFkZHIuZmFtaWx5ID09PSAnSVB2NCcgJiYgYWRkci5tYWMgJiYgYWRkci5tYWMgIT09ICcwMDowMDowMDowMDowMDowMCcpIHtcblx0XHRcdFx0XHRyZXR1cm4gQnVmZmVyLmZyb20oYWRkci5tYWMuc3BsaXQoJzonKS5tYXAoKGg6IHN0cmluZykgPT4gcGFyc2VJbnQoaCwgMTYpKSlcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fSBjYXRjaCB7XG5cdFx0LyogaWdub3JlICovXG5cdH1cblx0cmV0dXJuIEJ1ZmZlci5hbGxvYyg2LCAwKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VEYW50ZUluZm9SZXNwb25zZShtc2c6IEJ1ZmZlciwgc3JjSXA6IHN0cmluZyk6IERldmljZUluZm8gfCBudWxsIHtcblx0aWYgKG1zZy5sZW5ndGggPCBEQU5URV9JTkZPX01JTl9MRU4pIHJldHVybiBudWxsXG5cdGlmIChtc2cucmVhZFVJbnQxNkJFKDApICE9PSAweGZmZmYpIHJldHVybiBudWxsXG5cdGlmIChtc2cucmVhZFVJbnQxNkJFKDIpICE9PSBEQU5URV9NU0dfSU5GT19SRVNQT05TRSkgcmV0dXJuIG51bGxcblx0aWYgKG1zZy5zdWJhcnJheSgxNiwgMjQpLnRvU3RyaW5nKCdhc2NpaScpICE9PSAnQXVkaW5hdGUnKSByZXR1cm4gbnVsbFxuXG5cdGNvbnN0IHJlYWRTdHIgPSAob2Zmc2V0OiBudW1iZXIsIGxlbjogbnVtYmVyKTogc3RyaW5nID0+XG5cdFx0bXNnXG5cdFx0XHQuc3ViYXJyYXkob2Zmc2V0LCBvZmZzZXQgKyBsZW4pXG5cdFx0XHQudG9TdHJpbmcoJ2FzY2lpJylcblx0XHRcdC5zcGxpdCgnXFwwJylbMF1cblx0XHRcdC50cmltKClcblxuXHRjb25zdCBldWk2NCA9IG1zZy5zdWJhcnJheSg4LCAxNilcblx0Y29uc3QgbWFjQnl0ZXMgPSBbZXVpNjRbMF0sIGV1aTY0WzFdLCBldWk2NFsyXSwgZXVpNjRbNV0sIGV1aTY0WzZdLCBldWk2NFs3XV1cblx0Y29uc3QgbWFjID0gbWFjQnl0ZXMubWFwKChiKSA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKS5qb2luKCc6JylcblxuXHRjb25zdCBuYW1lID0gcmVhZFN0cigweDIwLCAzMSkgLy8gRGFudGUgZGV2aWNlIGxhYmVsIChjYW4gYmUgdXAgdG8gMzEgY2hhcnMgcGVyIERhbnRlIHNwZWMpXG5cdGNvbnN0IG1hbnVmYWN0dXJlciA9IHJlYWRTdHIoMHg0YywgNjQpIC8vIGUuZy4gXCJTdHVkaW8gVGVjaG5vbG9naWVzLCBJbmMuXCJcblx0Y29uc3QgbW9kZWxSYXcgPSByZWFkU3RyKDB4Y2MsIDY0KVxuXHRjb25zdCBkYW50ZUZpcm13YXJlID0gYCR7bXNnWzB4MThdfS4ke21zZ1sweDE5XX1gXG5cblx0aWYgKCFtb2RlbFJhdykgcmV0dXJuIG51bGxcblxuXHQvLyBFeHRyYWN0IGp1c3QgdGhlIG1vZGVsIG51bWJlci9jb2RlIChlLmcuIFwiTW9kZWwgMzkxIEFsZXJ0aW5nIFVuaXRcIiBcdTIxOTIgXCIzOTFcIilcblx0Ly8gU3RyaXAgXCJNb2RlbCBcIiBwcmVmaXgsIHRoZW4gdGFrZSBvbmx5IHRoZSBmaXJzdCB3b3JkICh0aGUgbW9kZWwgbnVtYmVyKVxuXHRjb25zdCBtb2RlbCA9IG1vZGVsUmF3XG5cdFx0LnJlcGxhY2UoL15Nb2RlbFxccysvaSwgJycpXG5cdFx0LnRyaW0oKVxuXHRcdC5zcGxpdCgvXFxzKy8pWzBdXG5cblx0cmV0dXJuIHtcblx0XHRpcDogc3JjSXAsXG5cdFx0bmFtZSxcblx0XHRtYW51ZmFjdHVyZXIsXG5cdFx0bW9kZWwsXG5cdFx0bW9kZWxOYW1lOiBtb2RlbFJhdywgLy8gRnVsbCBtb2RlbCBkZXNjcmlwdGlvblxuXHRcdG1hYyxcblx0XHRkYW50ZUZpcm13YXJlLFxuXHR9XG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgTUFDIGFkZHJlc3MgYnl0ZXMgb2YgdGhlIGxvY2FsIGludGVyZmFjZSB1c2VkIHRvIHJvdXRlIHRvIGRlc3RJcC5cbiAqIFVzZXMgYSB0ZW1wb3JhcnkgVURQIGNvbm5lY3QgdG8gbGV0IHRoZSBPUyBzZWxlY3QgdGhlIG91dGdvaW5nIGludGVyZmFjZSxcbiAqIHRoZW4gZmluZHMgdGhlIG1hdGNoaW5nIE1BQyBmcm9tIG9zLm5ldHdvcmtJbnRlcmZhY2VzKCkuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNYWNGb3JEZXN0aW5hdGlvbihkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8bnVtYmVyW10+IHtcblx0cmV0dXJuIG5ldyBQcm9taXNlPG51bWJlcltdPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0Y29uc3QgdG1wID0gZGdyYW0uY3JlYXRlU29ja2V0KCd1ZHA0JylcblxuXHRcdHRtcC5vbmNlKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRyZWplY3QobmV3IEVycm9yKGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpKSlcblx0XHR9KVxuXG5cdFx0dG1wLmNvbm5lY3QoOSwgZGVzdElwLCAoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBhZGRyID0gdG1wLmFkZHJlc3MoKSBhcyB7IGFkZHJlc3M6IHN0cmluZyB9XG5cdFx0XHRcdGNvbnN0IGxvY2FsQWRkciA9IGFkZHIuYWRkcmVzc1xuXHRcdFx0XHR0bXAuY2xvc2UoKVxuXG5cdFx0XHRcdGNvbnN0IGlmYWNlcyA9IG9zLm5ldHdvcmtJbnRlcmZhY2VzKClcblx0XHRcdFx0Zm9yIChjb25zdCBuYW1lIG9mIE9iamVjdC5rZXlzKGlmYWNlcykpIHtcblx0XHRcdFx0XHRmb3IgKGNvbnN0IGlmYWNlIG9mIGlmYWNlc1tuYW1lXSA/PyBbXSkge1xuXHRcdFx0XHRcdFx0aWYgKFxuXHRcdFx0XHRcdFx0XHRpZmFjZS5mYW1pbHkgPT09ICdJUHY0JyAmJlxuXHRcdFx0XHRcdFx0XHRpZmFjZS5hZGRyZXNzID09PSBsb2NhbEFkZHIgJiZcblx0XHRcdFx0XHRcdFx0aWZhY2UubWFjICYmXG5cdFx0XHRcdFx0XHRcdGlmYWNlLm1hYyAhPT0gJzAwOjAwOjAwOjAwOjAwOjAwJ1xuXHRcdFx0XHRcdFx0KSB7XG5cdFx0XHRcdFx0XHRcdHJldHVybiByZXNvbHZlKGlmYWNlLm1hYy5zcGxpdCgnOicpLm1hcCgoYikgPT4gcGFyc2VJbnQoYiwgMTYpICYgMHhmZikpXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoYE5vIGludGVyZmFjZSBmb3VuZCBmb3IgbG9jYWwgYWRkcmVzcyAke2xvY2FsQWRkcn1gKSlcblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoU3RyaW5nKF9lKSkpXG5cdFx0XHR9XG5cdFx0fSlcblx0fSlcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBsb2NhbCBJUCBhZGRyZXNzIHVzZWQgYnkgdGhlIE9TIHRvIHJvdXRlIHRvIGRlc3RJcC5cbiAqIFVzZXMgYSB0ZW1wb3JhcnkgVURQIHNvY2tldCBjb25uZWN0IHRvIGxldCB0aGUgT1Mgc2VsZWN0IHRoZSBvdXRnb2luZyBpbnRlcmZhY2UuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRMb2NhbEFkZHJlc3NGb3JEZXN0aW5hdGlvbihkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG5cdHJldHVybiBuZXcgUHJvbWlzZTxzdHJpbmc+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRjb25zdCB0bXAgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoJ3VkcDQnKVxuXG5cdFx0bGV0IHJlc29sdmVkID0gZmFsc2Vcblx0XHR0bXAub25jZSgnZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHRpZiAoIXJlc29sdmVkKSB7XG5cdFx0XHRcdHJlc29sdmVkID0gdHJ1ZVxuXHRcdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpKSlcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0Ly8gVXNlIGFuIGFyYml0cmFyeSBwb3J0IGZvciBjb25uZWN0OyB3ZSBvbmx5IG5lZWQgdGhlIGtlcm5lbCB0byBhc3NpZ24gYSBsb2NhbCBhZGRyZXNzLlxuXHRcdHRtcC5jb25uZWN0KDksIGRlc3RJcCwgKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3QgYWRkciA9IHRtcC5hZGRyZXNzKCkgYXMgeyBhZGRyZXNzOiBzdHJpbmcgfVxuXHRcdFx0XHRjb25zdCBsb2NhbEFkZHIgPSBhZGRyLmFkZHJlc3Ncblx0XHRcdFx0aWYgKCFyZXNvbHZlZCkge1xuXHRcdFx0XHRcdHJlc29sdmVkID0gdHJ1ZVxuXHRcdFx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRcdFx0cmVzb2x2ZShsb2NhbEFkZHIpXG5cdFx0XHRcdH1cblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdGlmICghcmVzb2x2ZWQpIHtcblx0XHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoU3RyaW5nKF9lKSkpXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KVxuXHR9KVxufVxuXG4vKipcbiAqIExpc3RlbnMgZm9yIERhbnRlIGRldmljZSBhbm5vdW5jZXMgb24gdGhlIGxvY2FsIG5ldHdvcmsgYW5kIHNlbmRzIHVuaWNhc3RcbiAqIGluZm8gcmVxdWVzdHMgdG8gZWFjaCBkaXNjb3ZlcmVkIElQLiBSZXNwb25zZXMgYXJyaXZlIG9uIHRoZSBjYWxsZXIncyByeFNvY2tldFxuICogdmlhIGhhbmRsZUluY29taW5nKCkgXHUyMTkyIGRpc2NvdmVyeUxpc3RlbmVycy5cbiAqXG4gKiBAcGFyYW0gdHhTb2NrZXQgLSBUaGUgc29ja2V0IHRvIHVzZSBmb3Igc2VuZGluZyBkaXNjb3ZlcnkgcmVxdWVzdHNcbiAqIEBwYXJhbSBlbnN1cmVNZW1iZXJzaGlwIC0gQ2FsbGJhY2sgdG8gZW5zdXJlIG11bHRpY2FzdCBtZW1iZXJzaGlwIGJlZm9yZSBxdWVyeWluZ1xuICogQHBhcmFtIHRpbWVvdXRNcyAtIEhvdyBsb25nIHRvIGxpc3RlbiBmb3IgYW5ub3VuY2VzIGJlZm9yZSByZXNvbHZpbmdcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRpc2NvdmVyRGV2aWNlcyhcblx0dHhTb2NrZXQ6IGRncmFtLlNvY2tldCxcblx0ZW5zdXJlTWVtYmVyc2hpcDogKGRlc3RJcDogc3RyaW5nKSA9PiBQcm9taXNlPHZvaWQ+LFxuXHR0aW1lb3V0TXMgPSA1MDAwLFxuKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IERBTlRFX0FOTk9VTkNFX0dST1VQID0gJzIyNC4wLjAuMjMzJ1xuXHRjb25zdCBEQU5URV9BTk5PVU5DRV9QT1JUID0gODcwOFxuXHRjb25zdCBERUZBVUxUX1BPUlQgPSA4NzAwXG5cblx0Y29uc3QgcXVlcmllZElwcyA9IG5ldyBTZXQ8c3RyaW5nPigpXG5cblx0cmV0dXJuIG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlKSA9PiB7XG5cdFx0Y29uc3QgYW5ub3VuY2VTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXHRcdGNvbnN0IGpvaW5lZEludGVyZmFjZXM6IHN0cmluZ1tdID0gW11cblxuXHRcdGNvbnN0IGNsZWFudXAgPSAoKSA9PiB7XG5cdFx0XHRmb3IgKGNvbnN0IGlmYWNlIG9mIGpvaW5lZEludGVyZmFjZXMpIHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRhbm5vdW5jZVNvY2tldC5kcm9wTWVtYmVyc2hpcChEQU5URV9BTk5PVU5DRV9HUk9VUCwgaWZhY2UpXG5cdFx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRhbm5vdW5jZVNvY2tldC5jbG9zZSgpXG5cdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0XHRyZXNvbHZlKClcblx0XHR9XG5cblx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoY2xlYW51cCwgdGltZW91dE1zKVxuXHRcdHRpbWVyLnVucmVmPy4oKVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLndhcm4oYEFubm91bmNlIHNvY2tldCBlcnJvcjogJHtlcnIubWVzc2FnZX1gKVxuXHRcdH0pXG5cblx0XHRhbm5vdW5jZVNvY2tldC5vbignbWVzc2FnZScsIChtc2csIHJpbmZvKSA9PiB7XG5cdFx0XHRjb25zdCBzcmNJcCA9IHJpbmZvLmFkZHJlc3Ncblx0XHRcdC8vIFZhbGlkYXRlIGl0J3MgYSBEYW50ZSBhbm5vdW5jZSAobWFnaWMgMHhmZmZlICsgXCJBdWRpbmF0ZVwiIGF0IG9mZnNldCAxNilcblx0XHRcdGlmIChtc2cubGVuZ3RoIDwgMjQpIHJldHVyblxuXHRcdFx0aWYgKG1zZy5yZWFkVUludDE2QkUoMCkgIT09IDB4ZmZmZSkgcmV0dXJuXG5cdFx0XHRpZiAobXNnLnN1YmFycmF5KDE2LCAyNCkudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdBdWRpbmF0ZScpIHJldHVyblxuXG5cdFx0XHRpZiAocXVlcmllZElwcy5oYXMoc3JjSXApKSByZXR1cm5cblx0XHRcdHF1ZXJpZWRJcHMuYWRkKHNyY0lwKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBBbm5vdW5jZSBmcm9tICR7c3JjSXB9IFx1MjAxNCBzZW5kaW5nIHVuaWNhc3QgcXVlcnlgKVxuXG5cdFx0XHQvLyBKb2luIDIyNC4wLjAuMjMxIG9uIHRoZSBpbnRlcmZhY2UgdGhhdCByb3V0ZXMgdG8gdGhpcyBkZXZpY2UgQkVGT1JFIHNlbmRpbmdcblx0XHRcdC8vIHRoZSBxdWVyeS4gVGhlIGRldmljZSBtdWx0aWNhc3RzIGl0cyAweDAxNzAgcmVzcG9uc2UgdG8gMjI0LjAuMC4yMzE6ODcwMlxuXHRcdFx0Ly8gaW4gYWRkaXRpb24gdG8gdW5pY2FzdGluZyBpdCBcdTIwMTQgcnhTb2NrZXQgbXVzdCBiZSBhIG1lbWJlciB0byByZWNlaXZlIGl0LlxuXHRcdFx0Y29uc3Qgc2VuZFF1ZXJ5ID0gYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRhd2FpdCBlbnN1cmVNZW1iZXJzaGlwKHNyY0lwKVxuXHRcdFx0XHRjb25zdCBxdWVyeSA9IGJ1aWxkRGFudGVJbmZvUmVxdWVzdCgpXG5cdFx0XHRcdHR4U29ja2V0LnNlbmQocXVlcnksIERFRkFVTFRfUE9SVCwgc3JjSXAsIChlcnIpID0+IHtcblx0XHRcdFx0XHRpZiAoZXJyKSBsb2dnZXIud2FybihgVW5pY2FzdCBxdWVyeSB0byAke3NyY0lwfSBmYWlsZWQ6ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHRcdFx0fSlcblx0XHRcdH1cblx0XHRcdHNlbmRRdWVyeSgpLmNhdGNoKChlcnIpID0+IGxvZ2dlci53YXJuKGBRdWVyeSBzZXR1cCBmYWlsZWQ6ICR7ZXJyfWApKVxuXHRcdH0pXG5cblx0XHRhbm5vdW5jZVNvY2tldC5iaW5kKERBTlRFX0FOTk9VTkNFX1BPUlQsICgpID0+IHtcblx0XHRcdC8vIEpvaW4gMjI0LjAuMC4yMzMgb24gZXZlcnkgbm9uLWxvb3BiYWNrIElQdjQgaW50ZXJmYWNlIHNvIHRoYXQgYW5ub3VuY2VzXG5cdFx0XHQvLyBhcmUgcmVjZWl2ZWQgcmVnYXJkbGVzcyBvZiB3aGljaCBpbnRlcmZhY2UgdGhlIGRldmljZSBpcyBvbi5cblx0XHRcdC8vIE9uIFdpbmRvd3Mgd2l0aCBtdWx0aXBsZSBpbnRlcmZhY2VzIChlLmcuIEh5cGVyLVYgKyBMQU4pLCB0aGUgT1MgZGVmYXVsdFxuXHRcdFx0Ly8gbXVsdGljYXN0IGludGVyZmFjZSBtYXkgbm90IGJlIHRoZSBvbmUgY29ubmVjdGVkIHRvIHRoZSBEYW50ZSBuZXR3b3JrLlxuXHRcdFx0Y29uc3QgaWZhY2VzID0gb3MubmV0d29ya0ludGVyZmFjZXMoKVxuXHRcdFx0Zm9yIChjb25zdCBhZGRycyBvZiBPYmplY3QudmFsdWVzKGlmYWNlcykpIHtcblx0XHRcdFx0Zm9yIChjb25zdCBhZGRyIG9mIGFkZHJzID8/IFtdKSB7XG5cdFx0XHRcdFx0aWYgKGFkZHIuZmFtaWx5ID09PSAnSVB2NCcgJiYgIWFkZHIuaW50ZXJuYWwpIHtcblx0XHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRcdGFubm91bmNlU29ja2V0LmFkZE1lbWJlcnNoaXAoREFOVEVfQU5OT1VOQ0VfR1JPVVAsIGFkZHIuYWRkcmVzcylcblx0XHRcdFx0XHRcdFx0am9pbmVkSW50ZXJmYWNlcy5wdXNoKGFkZHIuYWRkcmVzcylcblx0XHRcdFx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRcdFx0XHQvKiBpZ25vcmUgXHUyMDE0IGludGVyZmFjZSBtYXkgbm90IHN1cHBvcnQgbXVsdGljYXN0ICovXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRpZiAoam9pbmVkSW50ZXJmYWNlcy5sZW5ndGggPT09IDApIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYENvdWxkIG5vdCBqb2luIGFubm91bmNlIG11bHRpY2FzdCBncm91cCBvbiBhbnkgaW50ZXJmYWNlYClcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBMaXN0ZW5pbmcgZm9yIERhbnRlIGFubm91bmNlcyBvbiAke0RBTlRFX0FOTk9VTkNFX0dST1VQfToke0RBTlRFX0FOTk9VTkNFX1BPUlR9YClcblx0XHRcdH1cblx0XHR9KVxuXHR9KVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgQ29uTW9uIHNlc3Npb24gKHBvcnQgODgwMCkgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbi8qKiBDb2FsZXNjZXMgY29uY3VycmVudCBvcGVuQ29uTW9uU2Vzc2lvbiBjYWxscyBwZXIgSVAgKi9cbmNvbnN0IF9jb25tb25QZW5kaW5nID0gbmV3IE1hcDxzdHJpbmcsIFByb21pc2U8KCgpID0+IHZvaWQpIHwgbnVsbD4+KClcblxuLyoqXG4gKiBPcGVucyBhIERhbnRlIENvbk1vbiAoQ29udHJvbCAmIE1vbml0b3JpbmcpIHNlc3Npb24gd2l0aCB0aGUgZGV2aWNlIG9uIHBvcnQgODgwMC5cbiAqIENvYWxlc2NlcyBjb25jdXJyZW50IGNhbGxzIGZvciB0aGUgc2FtZSBJUCBcdTIwMTQgb25seSBvbmUgaGFuZHNoYWtlIHJ1bnMgYXQgYSB0aW1lLlxuICpcbiAqIFJldHVybnMgYSBjbGVhbnVwIGZ1bmN0aW9uIHRoYXQgc3RvcHMga2VlcGFsaXZlcyBhbmQgY2xvc2VzIHRoZSBzb2NrZXQsXG4gKiBvciBudWxsIGlmIHRoZSBzZXNzaW9uIGNvdWxkIG5vdCBiZSBlc3RhYmxpc2hlZC5cbiAqXG4gKiBUaGUgNTQwMUEgKGFuZCBwb3NzaWJseSBvdGhlciBkZXZpY2VzKSByZXF1aXJlIHRoZSBDb25Nb24gc2Vzc2lvbiB0byBvcmlnaW5hdGVcbiAqIGZyb20gcG9ydCA4ODAwIEFORCByZW1haW4gYWxpdmUgd2l0aCBwZXJpb2RpYyBrZWVwYWxpdmVzICh0eXBlIDB4MDA0ZSkgYmVmb3JlXG4gKiB0aGV5IHdpbGwgcmVzcG9uZCB0byBTdHVkaW8tVCBjb21tYW5kcy4gT3RoZXIgZGV2aWNlcyAoMzc0QSwgMzkxKSBhY2NlcHRcbiAqIENvbk1vbiBmcm9tIGFueSBlcGhlbWVyYWwgcG9ydCBhbmQgZG9uJ3QgcmVxdWlyZSBrZWVwYWxpdmVzIHRvIHJlc3BvbmQuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBvcGVuQ29uTW9uU2Vzc2lvbihkZXZpY2VJcDogc3RyaW5nLCB0aW1lb3V0TXMgPSAzMDAwKTogUHJvbWlzZTwoKCkgPT4gdm9pZCkgfCBudWxsPiB7XG5cdGNvbnN0IHBlbmRpbmcgPSBfY29ubW9uUGVuZGluZy5nZXQoZGV2aWNlSXApXG5cdGlmIChwZW5kaW5nKSByZXR1cm4gcGVuZGluZ1xuXG5cdGNvbnN0IHByb21pc2UgPSBfZG9Db25Nb25TZXNzaW9uKGRldmljZUlwLCB0aW1lb3V0TXMpLmZpbmFsbHkoKCkgPT4ge1xuXHRcdF9jb25tb25QZW5kaW5nLmRlbGV0ZShkZXZpY2VJcClcblx0fSlcblx0X2Nvbm1vblBlbmRpbmcuc2V0KGRldmljZUlwLCBwcm9taXNlKVxuXHRyZXR1cm4gcHJvbWlzZVxufVxuXG5hc3luYyBmdW5jdGlvbiBfZG9Db25Nb25TZXNzaW9uKGRldmljZUlwOiBzdHJpbmcsIHRpbWVvdXRNczogbnVtYmVyKTogUHJvbWlzZTwoKCkgPT4gdm9pZCkgfCBudWxsPiB7XG5cdHJldHVybiBuZXcgUHJvbWlzZTwoKCkgPT4gdm9pZCkgfCBudWxsPigocmVzb2x2ZSkgPT4ge1xuXHRcdGxldCBzZXR0bGVkID0gZmFsc2Vcblx0XHRsZXQga2VlcGFsaXZlVGltZXI6IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGwgPSBudWxsXG5cblx0XHRjb25zdCBjbG9zZVNlc3Npb24gPSAoc29jazogZGdyYW0uU29ja2V0KSA9PiB7XG5cdFx0XHRpZiAoa2VlcGFsaXZlVGltZXIpIHtcblx0XHRcdFx0Y2xlYXJJbnRlcnZhbChrZWVwYWxpdmVUaW1lcilcblx0XHRcdFx0a2VlcGFsaXZlVGltZXIgPSBudWxsXG5cdFx0XHR9XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRzb2NrLmNsb3NlKClcblx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdH1cblx0XHRcdGxvZ2dlci5kZWJ1ZyhgQ29uTW9uIHNlc3Npb24gY2xvc2VkIGZvciAke2RldmljZUlwfWApXG5cdFx0fVxuXG5cdFx0Y29uc3QgZmFpbCA9IChzb2NrOiBkZ3JhbS5Tb2NrZXQpID0+IHtcblx0XHRcdGlmIChzZXR0bGVkKSByZXR1cm5cblx0XHRcdHNldHRsZWQgPSB0cnVlXG5cdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRjbG9zZVNlc3Npb24oc29jaylcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgQ29uTW9uIHNlc3Npb24gbm90IGVzdGFibGlzaGVkIGZvciAke2RldmljZUlwfSBcdTIwMTQgZGV2aWNlIG1heSBub3QgcmVxdWlyZSBpdGApXG5cdFx0XHRyZXNvbHZlKG51bGwpXG5cdFx0fVxuXG5cdFx0Ly8gQmluZCB0byBwb3J0IDg4MDAgXHUyMDE0IHRoZSA1NDAxQSBnYXRlcyBTdHVkaW8tVCByZXNwb25zZXMgb24gQ29uTW9uXG5cdFx0Ly8gb3JpZ2luYXRpbmcgZnJvbSB0aGlzIHBvcnQuIE90aGVyIGRldmljZXMgYWNjZXB0IGVwaGVtZXJhbCBwb3J0cy5cblx0XHRjb25zdCBzb2NrID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4gZmFpbChzb2NrKSwgdGltZW91dE1zKVxuXG5cdFx0c29jay5vbignZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHRsb2dnZXIud2FybihgQ29uTW9uIHNvY2tldCBlcnJvciBmb3IgJHtkZXZpY2VJcH06ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHRcdGZhaWwoc29jaylcblx0XHR9KVxuXG5cdFx0c29jay5vbignbWVzc2FnZScsIChtc2c6IEJ1ZmZlcikgPT4ge1xuXHRcdFx0Ly8gRGV2aWNlIEFDSzogMTIgMDAgMDAgMjAgLi4uIChsZW5ndGggZmllbGQgPSAweDIwKVxuXHRcdFx0aWYgKCFzZXR0bGVkICYmIG1zZy5sZW5ndGggPj0gNCAmJiBtc2dbMF0gPT09IDB4MTIgJiYgbXNnWzNdID09PSAweDIwKSB7XG5cdFx0XHRcdHNldHRsZWQgPSB0cnVlXG5cdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0bG9nZ2VyLmluZm8oYENvbk1vbiBzZXNzaW9uIGVzdGFibGlzaGVkIHdpdGggJHtkZXZpY2VJcH1gKVxuXG5cdFx0XHRcdC8vIFN0YXJ0IGtlZXBhbGl2ZXMgXHUyMDE0IHR5cGUgMHgwMDRlLCBzYW1lIDIwLWJ5dGUgZm9ybWF0IGFzIHRoZSBvcGVuIHBhY2tldC5cblx0XHRcdFx0Ly8gUmVxdWlyZWQgdG8ga2VlcCB0aGUgc2Vzc2lvbiBhbGl2ZSBvbiB0aGUgZGV2aWNlIHNpZGUuXG5cdFx0XHRcdC8vIEludGVydmFsIG1hdGNoZXMgU1RDb250cm9sbGVyICh+MSBzZWNvbmQgb2JzZXJ2ZWQgaW4gY2FwdHVyZXMpLlxuXHRcdFx0XHRsZXQga2VlcGFsaXZlU2VxID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMHhmZmZlKSArIDFcblx0XHRcdFx0Y29uc3Qgc2VuZEtlZXBhbGl2ZSA9ICgpID0+IHtcblx0XHRcdFx0XHRjb25zdCBwa3QgPSBCdWZmZXIuYWxsb2MoMjAsIDApXG5cdFx0XHRcdFx0cGt0WzBdID0gMHgxMlxuXHRcdFx0XHRcdHBrdFszXSA9IDB4NGUgLy8ga2VlcGFsaXZlIHR5cGVcblx0XHRcdFx0XHRwa3Qud3JpdGVVSW50MTZCRShrZWVwYWxpdmVTZXErKyAmIDB4ZmZmZiwgNClcblx0XHRcdFx0XHRwa3RbNl0gPSAweDMwXG5cdFx0XHRcdFx0cGt0WzddID0gMHgxMFxuXHRcdFx0XHRcdHNvY2suc2VuZChwa3QsIDg4MDAsIGRldmljZUlwLCAoKSA9PiB7XG5cdFx0XHRcdFx0XHQvKiBmaXJlIGFuZCBmb3JnZXQgKi9cblx0XHRcdFx0XHR9KVxuXHRcdFx0XHR9XG5cdFx0XHRcdGtlZXBhbGl2ZVRpbWVyID0gc2V0SW50ZXJ2YWwoc2VuZEtlZXBhbGl2ZSwgMTAwMClcblxuXHRcdFx0XHQvLyBSZXR1cm4gY2xlYW51cCBmdW5jdGlvbiB0byBjYWxsZXJcblx0XHRcdFx0cmVzb2x2ZSgoKSA9PiBjbG9zZVNlc3Npb24oc29jaykpXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdGNvbnN0IGRvSW5pdCA9IGFzeW5jICgpID0+IHtcblx0XHRcdGxldCBsb2NhbElwOiBzdHJpbmdcblx0XHRcdGxldCBsb2NhbE1hYzogbnVtYmVyW11cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGxvY2FsSXAgPSBhd2FpdCBnZXRMb2NhbEFkZHJlc3NGb3JEZXN0aW5hdGlvbihkZXZpY2VJcClcblx0XHRcdFx0bG9jYWxNYWMgPSBhd2FpdCBnZXRNYWNGb3JEZXN0aW5hdGlvbihkZXZpY2VJcClcblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYENvbk1vbjogY291bGQgbm90IGdldCBsb2NhbCBuZXR3b3JrIGluZm8gZm9yICR7ZGV2aWNlSXB9OiAke2V9YClcblx0XHRcdFx0ZmFpbChzb2NrKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0Ly8gQmluZCB0byBwb3J0IDg4MDAgc28gdGhlIGRldmljZSBzZWVzIHRoZSBzZXNzaW9uIGFzIGNvbWluZyBmcm9tIHRoZVxuXHRcdFx0Ly8gc3RhbmRhcmQgQ29uTW9uIHBvcnQuIHJldXNlQWRkciBhbGxvd3MgdGhpcyBldmVuIGlmIGFub3RoZXIgcHJvY2Vzc1xuXHRcdFx0Ly8gKGUuZy4gU1RDb250cm9sbGVyKSBpcyBhbHNvIHJ1bm5pbmcgYSBDb25Nb24gc2Vzc2lvbi5cblx0XHRcdHNvY2suYmluZCh7IHBvcnQ6IDg4MDAsIGFkZHJlc3M6IGxvY2FsSXAgfSwgKCkgPT4ge1xuXHRcdFx0XHRjb25zdCBzZXEgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAweGZmZmUpICsgMVxuXHRcdFx0XHQvLyAyMC1ieXRlIGNvbm5lY3QgcGFja2V0OiAxMiAwMCAwMCAxNCBbc2VxXSAxMCAwMSAwMCAwMCAwMCAwMCBbTUFDIDZCXSAwMCAwMFxuXHRcdFx0XHRjb25zdCBwa3QgPSBCdWZmZXIuYWxsb2MoMjAsIDApXG5cdFx0XHRcdHBrdFswXSA9IDB4MTJcblx0XHRcdFx0cGt0WzNdID0gMHgxNCAvLyBvcGVuIHR5cGVcblx0XHRcdFx0cGt0LndyaXRlVUludDE2QkUoc2VxLCA0KVxuXHRcdFx0XHRwa3RbNl0gPSAweDEwXG5cdFx0XHRcdHBrdFs3XSA9IDB4MDFcblx0XHRcdFx0bG9jYWxNYWMuZm9yRWFjaCgoYiwgaSkgPT4ge1xuXHRcdFx0XHRcdHBrdFsxMiArIGldID0gYlxuXHRcdFx0XHR9KVxuXHRcdFx0XHRsb2dnZXIuZGVidWcoYENvbk1vbiBUWCB0byAke2RldmljZUlwfTogJHtwa3QudG9TdHJpbmcoJ2hleCcpfWApXG5cdFx0XHRcdHNvY2suc2VuZChwa3QsIDg4MDAsIGRldmljZUlwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdFx0aWYgKGVycikge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oYENvbk1vbiBzZW5kIGZhaWxlZCBmb3IgJHtkZXZpY2VJcH06ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHRcdFx0XHRcdGZhaWwoc29jaylcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0pXG5cdFx0XHR9KVxuXHRcdH1cblxuXHRcdGRvSW5pdCgpLmNhdGNoKChlKSA9PiB7XG5cdFx0XHRsb2dnZXIud2FybihgQ29uTW9uIGluaXQgZmFpbGVkIGZvciAke2RldmljZUlwfTogJHtlfWApXG5cdFx0XHRmYWlsKHNvY2spXG5cdFx0fSlcblx0fSlcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIERldmljZSBwcm9iZSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuLyoqXG4gKiBTZW5kcyBhIHVuaWNhc3QgRGFudGUgaW5mbyByZXF1ZXN0IHRvIGEgc3BlY2lmaWMgSVAgYW5kIHdhaXRzIGZvciB0aGUgZGV2aWNlIGluZm9cbiAqIHJlc3BvbnNlLiBVc2VkIHRvIHZlcmlmeSBhIG1hbnVhbGx5IGNvbmZpZ3VyZWQgSVAuXG4gKlxuICogQHBhcmFtIHR4U29ja2V0ICAgICAgICAgQm91bmQgc29ja2V0IHRvIHNlbmQgdGhlIHF1ZXJ5IGZyb21cbiAqIEBwYXJhbSByZWdpc3Rlckxpc3RlbmVyIFJlZ2lzdGVyIGEgY2FsbGJhY2sgKGtleWVkKSB0byByZWNlaXZlIHBhcnNlZCBEZXZpY2VJbmZvIHJlc3BvbnNlc1xuICogQHBhcmFtIHJlbW92ZUxpc3RlbmVyICAgUmVtb3ZlIGEgcHJldmlvdXNseSByZWdpc3RlcmVkIGxpc3RlbmVyIGJ5IGtleVxuICogQHBhcmFtIGVuc3VyZU1lbWJlcnNoaXAgRW5zdXJlIG11bHRpY2FzdCBtZW1iZXJzaGlwIG9uIHRoZSBvdXRnb2luZyBpbnRlcmZhY2VcbiAqIEBwYXJhbSBpcCAgICAgICAgICAgICAgIFRhcmdldCBkZXZpY2UgSVBcbiAqIEBwYXJhbSB0aW1lb3V0TXMgICAgICAgIFRpbWVvdXQgaW4gbWlsbGlzZWNvbmRzXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcm9iZURldmljZShcblx0dHhTb2NrZXQ6IGRncmFtLlNvY2tldCxcblx0cmVnaXN0ZXJMaXN0ZW5lcjogKGtleTogc3RyaW5nLCBjYjogKGRldmljZTogRGV2aWNlSW5mbykgPT4gdm9pZCkgPT4gdm9pZCxcblx0cmVtb3ZlTGlzdGVuZXI6IChrZXk6IHN0cmluZykgPT4gdm9pZCxcblx0ZW5zdXJlTWVtYmVyc2hpcDogKGlwOiBzdHJpbmcpID0+IFByb21pc2U8dm9pZD4sXG5cdGlwOiBzdHJpbmcsXG5cdHRpbWVvdXRNcyA9IDMwMDAsXG4pOiBQcm9taXNlPERldmljZUluZm8gfCBudWxsPiB7XG5cdHJldHVybiBuZXcgUHJvbWlzZTxEZXZpY2VJbmZvIHwgbnVsbD4oKHJlc29sdmUpID0+IHtcblx0XHRjb25zdCBrZXkgPSBgX19wcm9iZV8ke2lwfV9fYFxuXHRcdGxldCByZXNvbHZlZCA9IGZhbHNlXG5cblx0XHRjb25zdCBmaW5pc2ggPSAocmVzdWx0OiBEZXZpY2VJbmZvIHwgbnVsbCkgPT4ge1xuXHRcdFx0aWYgKHJlc29sdmVkKSByZXR1cm5cblx0XHRcdHJlc29sdmVkID0gdHJ1ZVxuXHRcdFx0cmVtb3ZlTGlzdGVuZXIoa2V5KVxuXHRcdFx0cmVzb2x2ZShyZXN1bHQpXG5cdFx0fVxuXG5cdFx0cmVnaXN0ZXJMaXN0ZW5lcihrZXksIChkZXZpY2U6IERldmljZUluZm8pID0+IHtcblx0XHRcdGlmIChkZXZpY2UuaXAgPT09IGlwKSBmaW5pc2goZGV2aWNlKVxuXHRcdH0pXG5cblx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4gZmluaXNoKG51bGwpLCB0aW1lb3V0TXMpXG5cdFx0dGltZXIudW5yZWY/LigpXG5cblx0XHRjb25zdCBydW4gPSBhc3luYyAoKSA9PiB7XG5cdFx0XHRhd2FpdCBlbnN1cmVNZW1iZXJzaGlwKGlwKVxuXHRcdFx0Y29uc3QgcXVlcnkgPSBidWlsZERhbnRlSW5mb1JlcXVlc3QoKVxuXHRcdFx0dHhTb2NrZXQuc2VuZChxdWVyeSwgODcwMCwgaXAsIChlcnIpID0+IHtcblx0XHRcdFx0aWYgKGVycikge1xuXHRcdFx0XHRcdGxvZ2dlci53YXJuKGBQcm9iZSB0byAke2lwfSBmYWlsZWQ6ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0ZmluaXNoKG51bGwpXG5cdFx0XHRcdH1cblx0XHRcdH0pXG5cdFx0fVxuXG5cdFx0cnVuKCkuY2F0Y2goKGUpID0+IHtcblx0XHRcdGxvZ2dlci53YXJuKGBwcm9iZURldmljZSBzZXR1cCBmYWlsZWQgZm9yICR7aXB9OiAke2V9YClcblx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdGZpbmlzaChudWxsKVxuXHRcdH0pXG5cdH0pXG59XG4iLCAiaW1wb3J0IHtcblx0SW5zdGFuY2VUeXBlcyxcblx0SW5zdGFuY2VCYXNlLFxuXHRJbnN0YW5jZVN0YXR1cyxcblx0U29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkLFxuXHRjcmVhdGVNb2R1bGVMb2dnZXIsXG59IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBHZXRDb25maWdGaWVsZHMsIHJlc29sdmVIb3N0LCByZXNvbHZlTW9kZWwsIGdldERldmljZVNjaGVtYSwgdHlwZSBNb2R1bGVDb25maWcgfSBmcm9tICcuL2NvbmZpZy5qcydcbmltcG9ydCB7IFVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMsIFVwZGF0ZVZhcmlhYmxlVmFsdWVzIH0gZnJvbSAnLi92YXJpYWJsZXMuanMnXG5pbXBvcnQgeyBVcGdyYWRlU2NyaXB0cyB9IGZyb20gJy4vdXBncmFkZXMuanMnXG5pbXBvcnQgeyBVcGRhdGVBY3Rpb25zIH0gZnJvbSAnLi9hY3Rpb25zLmpzJ1xuaW1wb3J0IHsgVXBkYXRlRmVlZGJhY2tzIH0gZnJvbSAnLi9mZWVkYmFja3MuanMnXG5pbXBvcnQgeyBTdENvbnRyb2xsZXIgfSBmcm9tICcuL3N0Y29udHJvbGxlci5qcydcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignTW9kdWxlSW5zdGFuY2UnKVxuXG5leHBvcnQgdHlwZSBNb2R1bGVUeXBlcyA9IEluc3RhbmNlVHlwZXMgJiB7XG5cdGNvbmZpZzogTW9kdWxlQ29uZmlnXG59XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1vZHVsZUluc3RhbmNlIGV4dGVuZHMgSW5zdGFuY2VCYXNlPE1vZHVsZVR5cGVzPiB7XG5cdGNvbmZpZyE6IE1vZHVsZUNvbmZpZyAvLyBTZXR1cCBpbiBpbml0KClcblx0c3RDb250cm9sbGVyITogU3RDb250cm9sbGVyXG5cblx0LyoqIENhY2hlZCBkaXNjb3ZlcnkgcmVzdWx0cyBcdTIwMTQgcGFzc2VkIGludG8gZ2V0Q29uZmlnRmllbGRzKCkgc28gdGhlIFVJXG5cdCAqICBjYW4gc2hvdyB0aGUgZGlzY292ZXJlZCBkZXZpY2UgZHJvcGRvd24gb24gc3Vic2VxdWVudCBjb25maWcgb3BlbnMuICovXG5cdHByaXZhdGUgZGlzY292ZXJlZERldmljZXM6IERldmljZUluZm9bXSA9IFtdXG5cblx0LyoqIEN1cnJlbnRseSBhY3RpdmUgbW9kZWwgXHUyMDE0IHJlc29sdmVkIG9uY2UgaW4gc3luY01vZGVsKCkgYW5kIGNhY2hlZCBoZXJlXG5cdCAqICBzbyBVcGRhdGVBY3Rpb25zLCBVcGRhdGVGZWVkYmFja3MgZXRjLiBkb24ndCBlYWNoIGNhbGwgcmVzb2x2ZU1vZGVsIGluZGVwZW5kZW50bHkuICovXG5cdGFjdGl2ZU1vZGVsOiBzdHJpbmcgPSAnJ1xuXG5cdGNvbnN0cnVjdG9yKGludGVybmFsOiB1bmtub3duKSB7XG5cdFx0c3VwZXIoaW50ZXJuYWwpXG5cdH1cblxuXHRhc3luYyBpbml0KGNvbmZpZzogTW9kdWxlQ29uZmlnKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dGhpcy5jb25maWcgPSBjb25maWdcblx0XHRpZiAoIXRoaXMuc3RDb250cm9sbGVyKSB7XG5cdFx0XHR0aGlzLnN0Q29udHJvbGxlciA9IG5ldyBTdENvbnRyb2xsZXIoKVxuXHRcdH1cblx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5Db25uZWN0aW5nLCAnRGlzY292ZXJpbmcgZGV2aWNlcy4uLicpXG5cblx0XHQvLyBXaXJlIGZlZWRiYWNrIGNhbGxiYWNrIHNvIHN0Q29udHJvbGxlciBjYW4gdHJpZ2dlciBmZWVkYmFjayB1cGRhdGVzXG5cdFx0dGhpcy5zdENvbnRyb2xsZXIuc2V0RmVlZGJhY2tDYWxsYmFjaygoZmVlZGJhY2tJZDogc3RyaW5nKSA9PiB7XG5cdFx0XHR0aGlzLmNoZWNrRmVlZGJhY2tzKGZlZWRiYWNrSWQpXG5cdFx0fSlcblxuXHRcdC8vIFN0YXJ0IGRpc2NvdmVyeSBpbiB0aGUgYmFja2dyb3VuZCBcdTIwMTQgYWxsIG1vZGVsIHJlc29sdXRpb24sIHNjaGVtYSBzeW5jLFxuXHRcdC8vIGFuZCBVSSB1cGRhdGVzIGhhcHBlbiBpbnNpZGUgcnVuRGlzY292ZXJ5KCkgb25jZSB0aGUgZGV2aWNlIGxpc3QgaXMga25vd24uXG5cdFx0dGhpcy5ydW5EaXNjb3ZlcnkoKS5jYXRjaCgoZSkgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBEaXNjb3ZlcnkgZmFpbGVkOiAke2V9YClcblx0XHR9KVxuXHR9XG5cblx0LyoqXG5cdCAqIFJ1biBkZXZpY2UgZGlzY292ZXJ5LCB0aGVuIHJlc29sdmUgdGhlIG1vZGVsIGFuZCB1cGRhdGUgYWxsIFVJLlxuXHQgKiAtIElmIGRpc2NvdmVyeSBmaW5kcyBkZXZpY2VzLCByZXNvbHZlTW9kZWwgcGlja3MgZnJvbSB0aG9zZS5cblx0ICogLSBPbmx5IGlmIHRoZSBsaXN0IGlzIGVtcHR5IGRvIHdlIGZhbGwgYmFjayB0byB0aGUgbWFudWFsIGNvbmZpZyBzZWxlY3Rpb24uXG5cdCAqIEFsbCBhY3Rpb25zL2ZlZWRiYWNrcy92YXJpYWJsZXMgYXJlIGJ1aWx0IGFmdGVyIHRoZSBtb2RlbCBpcyBrbm93bi5cblx0ICovXG5cdHByaXZhdGUgYXN5bmMgcnVuRGlzY292ZXJ5KCk6IFByb21pc2U8dm9pZD4ge1xuXHRcdGxvZ2dlci5pbmZvKCdTdGFydGluZyBkZXZpY2UgZGlzY292ZXJ5Li4uJylcblxuXHRcdHRoaXMuZGlzY292ZXJlZERldmljZXMgPSBhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5kaXNjb3ZlckRldmljZXMoKVxuXG5cdFx0Ly8gRGV0ZXJtaW5lIGVmZmVjdGl2ZSBtb2RlbCBcdTIwMTQgZnJvbSBkaXNjb3ZlcmVkIGRldmljZXMgZmlyc3QsIG1hbnVhbCBjb25maWcgb25seSBhcyBmYWxsYmFja1xuXHRcdGxldCBlZmZlY3RpdmVNb2RlbDogc3RyaW5nXG5cdFx0aWYgKHRoaXMuZGlzY292ZXJlZERldmljZXMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHQvLyBJZiBhIHNwZWNpZmljIGRldmljZSBNQUMgd2FzIHNhdmVkIGluIGNvbmZpZywgaXQgd2Fzbid0IGZvdW5kIFx1MjAxNCBzdG9wIGhlcmUuXG5cdFx0XHRpZiAodGhpcy5jb25maWcuZGV2aWNlTWFjKSB7XG5cdFx0XHRcdGNvbnN0IG1vZGVsTGFiZWwgPSB0aGlzLmNvbmZpZy5hY3RpdmVNb2RlbCA/IGBNb2RlbCAke3RoaXMuY29uZmlnLmFjdGl2ZU1vZGVsfSBgIDogJydcblx0XHRcdFx0bG9nZ2VyLndhcm4oYFNhdmVkIGRldmljZSBNQUMgXCIke3RoaXMuY29uZmlnLmRldmljZU1hY31cIiBub3QgZm91bmQgZHVyaW5nIGRpc2NvdmVyeSBcdTIwMTQgc3RvcHBpbmdgKVxuXHRcdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5Db25uZWN0aW9uRmFpbHVyZSwgYCR7bW9kZWxMYWJlbH1bJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XSBub3QgZm91bmRgKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHRcdGNvbnN0IG1hbnVhbE1vZGVsID0gdGhpcy5jb25maWcuYWN0aXZlTW9kZWxcblx0XHRcdGlmICghdGhpcy5jb25maWcuaG9zdCB8fCAhbWFudWFsTW9kZWwpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oJ05vIGRldmljZXMgZGlzY292ZXJlZCBhbmQgbm8gbWFudWFsIElQL21vZGVsIGNvbmZpZ3VyZWQnKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHRcdGxvZ2dlci5pbmZvKCdObyBkZXZpY2VzIGRpc2NvdmVyZWQgXHUyMDE0IHdpbGwgcHJvYmUgbWFudWFsIElQIGR1cmluZyBhdXRob3JpemF0aW9uJylcblx0XHRcdGVmZmVjdGl2ZU1vZGVsID0gbWFudWFsTW9kZWxcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYERpc2NvdmVyZWQgJHt0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmxlbmd0aH0gZGV2aWNlKHMpOmApXG5cdFx0XHRmb3IgKGNvbnN0IGQgb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHRsb2dnZXIuaW5mbyhgICAtIE1vZGVsICR7ZC5tb2RlbH0gJHtkLm1hbnVmYWN0dXJlciA/PyAnJ30gQCAke2QuaXB9YClcblx0XHRcdH1cblxuXHRcdFx0Ly8gQXV0aG9yaXplIGFsbCBkaXNjb3ZlcmVkIGRldmljZXMgc28gZmlybXdhcmUgcmVxdWVzdHMgY2FuIHByb2NlZWQuXG5cdFx0XHQvLyB2ZXJpZnlBdXRob3JpemF0aW9uIChjYWxsZWQgYmVsb3cpIHdpbGwgcmV2b2tlIGFueSB0aGF0IGRvbid0IG1hdGNoXG5cdFx0XHQvLyB0aGUgY3VycmVudCBjb25maWcgc2VsZWN0aW9uLlxuXHRcdFx0Zm9yIChjb25zdCBkZXZpY2Ugb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5hdXRob3JpemVEZXZpY2UoZGV2aWNlLmlwKVxuXHRcdFx0fVxuXG5cdFx0XHQvLyBSZXF1ZXN0IGZpcm13YXJlIHZlcnNpb24gZnJvbSBlYWNoIGRpc2NvdmVyZWQgZGV2aWNlXG5cdFx0XHRmb3IgKGNvbnN0IGRldmljZSBvZiB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKSB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0Y29uc3QgZmlybXdhcmUgPSBhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5yZXF1ZXN0RmlybXdhcmVWZXJzaW9uKGRldmljZS5pcClcblx0XHRcdFx0XHRkZXZpY2UuZmlybXdhcmVNYWluID0gZmlybXdhcmVcblx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgICAtICR7ZGV2aWNlLmlwfTogRmlybXdhcmUgJHtmaXJtd2FyZX0sIERhbnRlICR7ZGV2aWNlLmRhbnRlRmlybXdhcmV9YClcblx0XHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRcdGxvZ2dlci53YXJuKGAgIC0gJHtkZXZpY2UuaXB9OiBGYWlsZWQgdG8gZ2V0IGZpcm13YXJlOiAke2V9YClcblx0XHRcdFx0XHRkZXZpY2UuZmlybXdhcmVNYWluID0gJ1Vua25vd24nXG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0ZWZmZWN0aXZlTW9kZWwgPSByZXNvbHZlTW9kZWwodGhpcy5jb25maWcsIHRoaXMuZGlzY292ZXJlZERldmljZXMpXG5cblx0XHRcdC8vIElmIGEgc3BlY2lmaWMgTUFDIHdhcyBzYXZlZCBidXQgaXNuJ3QgaW4gdGhlIGRpc2NvdmVyZWQgbGlzdCwgc3RvcC5cblx0XHRcdGlmICghZWZmZWN0aXZlTW9kZWwgJiYgdGhpcy5jb25maWcuZGV2aWNlTWFjKSB7XG5cdFx0XHRcdGNvbnN0IG1vZGVsTGFiZWwgPSB0aGlzLmNvbmZpZy5hY3RpdmVNb2RlbCA/IGBNb2RlbCAke3RoaXMuY29uZmlnLmFjdGl2ZU1vZGVsfSBgIDogJydcblx0XHRcdFx0bG9nZ2VyLndhcm4oYFNhdmVkIGRldmljZSBNQUMgXCIke3RoaXMuY29uZmlnLmRldmljZU1hY31cIiBub3QgZm91bmQgYW1vbmcgZGlzY292ZXJlZCBkZXZpY2VzIFx1MjAxNCBzdG9wcGluZ2ApXG5cdFx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLkNvbm5lY3Rpb25GYWlsdXJlLCBgJHttb2RlbExhYmVsfVske3RoaXMuY29uZmlnLmRldmljZU1hY31dIG5vdCBmb3VuZGApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIFN5bmMgbW9kZWwgc2NoZW1hIHRvIGNvbnRyb2xsZXJcblx0XHR0aGlzLnN5bmNNb2RlbChlZmZlY3RpdmVNb2RlbClcblxuXHRcdC8vIFZlcmlmeSB0aGF0IHRoZSBjdXJyZW50bHkgY29uZmlndXJlZCBob3N0K21vZGVsIGlzIHZhbGlkIG5vdyB0aGF0XG5cdFx0Ly8gZGlzY292ZXJ5IHJlc3VsdHMgYXJlIGtub3duLiBUaGlzIGlzIHRoZSBzYW1lIGNoZWNrIGNvbmZpZ1VwZGF0ZWQgdXNlcy5cblx0XHRjb25zdCB0YXJnZXRIb3N0ID0gdGhpcy5ob3N0XG5cdFx0YXdhaXQgdGhpcy52ZXJpZnlBdXRob3JpemF0aW9uKCcnLCB0YXJnZXRIb3N0KVxuXG5cdFx0Ly8gQnVpbGQgYWxsIFVJIG5vdyB0aGF0IG1vZGVsIGFuZCBhdXRob3JpemF0aW9uIHN0YXRlIGFyZSBrbm93blxuXHRcdHRoaXMudXBkYXRlQWN0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVGZWVkYmFja3MoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZVZhbHVlcygpXG5cblx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5Paylcblx0XHRsb2dnZXIuaW5mbygnRGV2aWNlIGRpc2NvdmVyeSBjb21wbGV0ZScpXG5cdH1cblxuXHQvLyBXaGVuIG1vZHVsZSBnZXRzIGRlbGV0ZWRcblx0YXN5bmMgZGVzdHJveSgpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0aGlzLnN0Q29udHJvbGxlcj8uY2xvc2UoKVxuXHRcdGxvZ2dlci5kZWJ1ZygnZGVzdHJveScpXG5cdH1cblxuXHRhc3luYyBjb25maWdVcGRhdGVkKGNvbmZpZzogTW9kdWxlQ29uZmlnKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0Y29uc3QgcHJldmlvdXNIb3N0ID0gdGhpcy5ob3N0XG5cdFx0dGhpcy5jb25maWcgPSBjb25maWdcblx0XHRjb25zdCBlZmZlY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbChjb25maWcsIHRoaXMuZGlzY292ZXJlZERldmljZXMpXG5cdFx0dGhpcy5zeW5jTW9kZWwoZWZmZWN0aXZlTW9kZWwpXG5cblx0XHQvLyBDbGVhciB2YXJpYWJsZXMgaW1tZWRpYXRlbHkgXHUyMDE0IHRoZSBuZXcgc2VsZWN0aW9uIGlzbid0IGF1dGhvcml6ZWQgeWV0LlxuXHRcdC8vIFRoZXknbGwgYmUgcmVwb3B1bGF0ZWQgYmVsb3cgb25jZSB2ZXJpZnlBdXRob3JpemF0aW9uIGNvbXBsZXRlcy5cblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlVmFsdWVzKClcblxuXHRcdGNvbnN0IG5ld0hvc3QgPSB0aGlzLmhvc3RcblxuXHRcdC8vIFJlLXZlcmlmeSBhdXRob3JpemF0aW9uIG9uIGV2ZXJ5IGNvbmZpZyBjaGFuZ2UgKG1vZGVsIG9yIElQKS5cblx0XHQvLyBUaGlzIGhhbmRsZXMgc3dpdGNoaW5nIGZyb20gYSB2YWxpZCBkZXZpY2UgdG8gYW4gaW52YWxpZCBvbmUgYW5kIGJhY2suXG5cdFx0YXdhaXQgdGhpcy52ZXJpZnlBdXRob3JpemF0aW9uKHByZXZpb3VzSG9zdCwgbmV3SG9zdClcblxuXHRcdC8vIFJlYnVpbGQgVUkgYWZ0ZXIgYXV0aG9yaXphdGlvbiBzdGF0ZSBpcyBzZXR0bGVkXG5cdFx0dGhpcy51cGRhdGVBY3Rpb25zKClcblx0XHR0aGlzLnVwZGF0ZUZlZWRiYWNrcygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlVmFsdWVzKClcblx0fVxuXG5cdC8qKlxuXHQgKiBSZS1ldmFsdWF0ZXMgd2hldGhlciB0aGUgY3VycmVudCBjb25maWcgaXMgYXV0aG9yaXplZCB0byBzZW5kIGNvbW1hbmRzLlxuXHQgKlxuXHQgKiBBdXRvIG1vZGUgKGRldmljZU1hYyBzZXQpOlxuXHQgKiAgIC0gRmluZCB0aGUgZGlzY292ZXJlZCBkZXZpY2Ugd2l0aCBtYXRjaGluZyBNQUMgXHUyMTkyIGdldCBpdHMgY3VycmVudCBJUFxuXHQgKiAgIC0gUmV2b2tlIHRoZSBwcmV2aW91cyBJUCwgYXV0aG9yaXplIHRoZSBuZXcgSVBcblx0ICogICAtIElmIE1BQyBub3QgZm91bmQgaW4gZGlzY292ZXJ5LCByZXZva2UgYW5kIGJsb2NrXG5cdCAqXG5cdCAqIE1hbnVhbCBtb2RlIChkZXZpY2VNYWMgZW1wdHkpOlxuXHQgKiAgIC0gQ2hlY2sgZGlzY292ZXJlZCBsaXN0IGJ5IElQK21vZGVsIG1hdGNoLCBvciBwcm9iZSBkaXJlY3RseVxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyB2ZXJpZnlBdXRob3JpemF0aW9uKHByZXZpb3VzSG9zdDogc3RyaW5nLCBuZXdIb3N0OiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHRpZiAoIW5ld0hvc3QpIHtcblx0XHRcdGlmIChwcmV2aW91c0hvc3QpIHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRpZiAodGhpcy5jb25maWcuZGV2aWNlTWFjKSB7XG5cdFx0XHQvLyBBdXRvIG1vZGUgXHUyMDE0IG1hdGNoIGJ5IE1BQywgdXNlIHdoYXRldmVyIElQIGRpc2NvdmVyeSBmb3VuZCBpdCBhdFxuXHRcdFx0Y29uc3QgZGV2aWNlID0gdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLm1hYyA9PT0gdGhpcy5jb25maWcuZGV2aWNlTWFjKVxuXHRcdFx0aWYgKCFkZXZpY2UpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYERldmljZSBNQUMgXCIke3RoaXMuY29uZmlnLmRldmljZU1hY31cIiBub3QgZm91bmQgaW4gY3VycmVudCBkaXNjb3ZlcnkgXHUyMDE0IG5vdCBhdXRob3JpemluZ2ApXG5cdFx0XHRcdGlmIChwcmV2aW91c0hvc3QpIHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHRpZiAocHJldmlvdXNIb3N0ICYmIHByZXZpb3VzSG9zdCAhPT0gbmV3SG9zdCkge1xuXHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdFx0fVxuXHRcdFx0Y29uc3Qgd2FzQXV0aG9yaXplZCA9IHRoaXMuc3RDb250cm9sbGVyLmlzRGV2aWNlQXV0aG9yaXplZChuZXdIb3N0KVxuXHRcdFx0aWYgKCF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShuZXdIb3N0KVxuXHRcdFx0fVxuXHRcdFx0aWYgKG5ld0hvc3QgIT09IHByZXZpb3VzSG9zdCB8fCAhd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHRhd2FpdCB0aGlzLmZldGNoU2V0dGluZ3NBbmRFbnN1cmVTY2hlbWEoZGV2aWNlLm1vZGVsLCBuZXdIb3N0KVxuXHRcdFx0fVxuXHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuT2spXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBNYW51YWwgbW9kZSBcdTIwMTQgY29uZmlnLmhvc3QgKyBjb25maWcuYWN0aXZlTW9kZWwgbXVzdCBtYXRjaFxuXHRcdGNvbnN0IG1hbnVhbE1vZGVsID0gU3RyaW5nKHRoaXMuY29uZmlnLmFjdGl2ZU1vZGVsID8/ICcnKVxuXHRcdGNvbnN0IGRpc2NvdmVyZWRBdElwID0gdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLmlwID09PSBuZXdIb3N0KVxuXG5cdFx0aWYgKGRpc2NvdmVyZWRBdElwKSB7XG5cdFx0XHRpZiAoZGlzY292ZXJlZEF0SXAubW9kZWwgPT09IG1hbnVhbE1vZGVsKSB7XG5cdFx0XHRcdGlmIChwcmV2aW91c0hvc3QgJiYgcHJldmlvdXNIb3N0ICE9PSBuZXdIb3N0KSB0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdFx0XHRjb25zdCB3YXNBdXRob3JpemVkID0gdGhpcy5zdENvbnRyb2xsZXIuaXNEZXZpY2VBdXRob3JpemVkKG5ld0hvc3QpXG5cdFx0XHRcdGlmICghd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShuZXdIb3N0KVxuXHRcdFx0XHR9XG5cdFx0XHRcdGlmIChuZXdIb3N0ICE9PSBwcmV2aW91c0hvc3QgfHwgIXdhc0F1dGhvcml6ZWQpIHtcblx0XHRcdFx0XHRhd2FpdCB0aGlzLmZldGNoU2V0dGluZ3NBbmRFbnN1cmVTY2hlbWEobWFudWFsTW9kZWwsIG5ld0hvc3QpXG5cdFx0XHRcdH1cblx0XHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuT2spXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRsb2dnZXIuZXJyb3IoXG5cdFx0XHRcdFx0YERldmljZSBzZWxlY3RlZCAoTW9kZWwgJHttYW51YWxNb2RlbH0pIGRvZXMgbm90IG1hdGNoIGRldGVjdGVkIGRldmljZSAoTW9kZWwgJHtkaXNjb3ZlcmVkQXRJcC5tb2RlbH0pIGF0ICR7bmV3SG9zdH0gXHUyMDE0IGNvbW1hbmRzIGJsb2NrZWRgLFxuXHRcdFx0XHQpXG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShuZXdIb3N0KVxuXHRcdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhcblx0XHRcdFx0XHRJbnN0YW5jZVN0YXR1cy5Db25uZWN0aW9uRmFpbHVyZSxcblx0XHRcdFx0XHRgTW9kZWwgbWlzbWF0Y2g6IGV4cGVjdGVkICR7bWFudWFsTW9kZWx9LCBnb3QgJHtkaXNjb3ZlcmVkQXRJcC5tb2RlbH1gLFxuXHRcdFx0XHQpXG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBJUCBub3QgaW4gZGlzY292ZXJlZCBsaXN0IFx1MjAxNCBwcm9iZSBpdCBkaXJlY3RseSB2aWEgRGFudGVcblx0XHRsb2dnZXIuaW5mbyhgJHtuZXdIb3N0fSBub3QgaW4gZGlzY292ZXJlZCBsaXN0IFx1MjAxNCBwcm9iaW5nYClcblx0XHRpZiAocHJldmlvdXNIb3N0ICYmIHByZXZpb3VzSG9zdCAhPT0gbmV3SG9zdCkgdGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHR0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UobmV3SG9zdClcblxuXHRcdGNvbnN0IHByb2JlZCA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnByb2JlRGV2aWNlKG5ld0hvc3QpXG5cdFx0aWYgKCFwcm9iZWQpIHtcblx0XHRcdGxvZ2dlci5lcnJvcihgTm8gZGV2aWNlIHJlc3BvbmRlZCBhdCAke25ld0hvc3R9IFx1MjAxNCBjb21tYW5kcyBibG9ja2VkYClcblx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLlVua25vd25XYXJuaW5nLCBgRGV2aWNlIG9mZmxpbmU6ICR7bmV3SG9zdH1gKVxuXHRcdH0gZWxzZSBpZiAocHJvYmVkLm1vZGVsICE9PSBtYW51YWxNb2RlbCkge1xuXHRcdFx0bG9nZ2VyLmVycm9yKFxuXHRcdFx0XHRgRGV2aWNlIHNlbGVjdGVkIChNb2RlbCAke21hbnVhbE1vZGVsfSkgZG9lcyBub3QgbWF0Y2ggZGV0ZWN0ZWQgZGV2aWNlIChNb2RlbCAke3Byb2JlZC5tb2RlbH0pIGF0ICR7bmV3SG9zdH0gXHUyMDE0IGNvbW1hbmRzIGJsb2NrZWRgLFxuXHRcdFx0KVxuXHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoXG5cdFx0XHRcdEluc3RhbmNlU3RhdHVzLkNvbm5lY3Rpb25GYWlsdXJlLFxuXHRcdFx0XHRgTW9kZWwgbWlzbWF0Y2g6IGV4cGVjdGVkICR7bWFudWFsTW9kZWx9LCBnb3QgJHtwcm9iZWQubW9kZWx9YCxcblx0XHRcdClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYFZlcmlmaWVkIE1vZGVsICR7cHJvYmVkLm1vZGVsfSBhdCAke25ld0hvc3R9YClcblx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShuZXdIb3N0KVxuXHRcdFx0YXdhaXQgdGhpcy5mZXRjaFNldHRpbmdzQW5kRW5zdXJlU2NoZW1hKG1hbnVhbE1vZGVsLCBuZXdIb3N0KVxuXHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuT2spXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIEZldGNoZXMgYWxsIHNldHRpbmdzIGZyb20gdGhlIGRldmljZS4gSWYgbm8gc2NoZW1hIGV4aXN0cyBmb3IgdGhlIG1vZGVsLFxuXHQgKiBjcmVhdGVzIG9uZSBmcm9tIHRoZSByZXNwb25zZSBhbmQgcmVsb2FkcyB0aGUgc2NoZW1hIGNhY2hlLlxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyBmZXRjaFNldHRpbmdzQW5kRW5zdXJlU2NoZW1hKG1vZGVsOiBzdHJpbmcsIGlwOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0cnkge1xuXHRcdFx0YXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucmVxdWVzdEFsbFNldHRpbmdzKGlwKVxuXG5cdFx0XHRpZiAoIWdldERldmljZVNjaGVtYShtb2RlbCkpIHtcblx0XHRcdFx0Ly8gTm8gc2NoZW1hIGV4aXN0cyBcdTIwMTQgZG8gTk9UIGF1dG8tY3JlYXRlIG9uZSBoZXJlLlxuXHRcdFx0XHQvLyBUaGUgdXNlciBtdXN0IHJ1biBcIkdMT0JBTDogR2V0IEFsbCBTZXR0aW5nc1wiIHRvIGNyZWF0ZSBpdC5cblx0XHRcdFx0bG9nZ2VyLndhcm4oYE5vIHNjaGVtYSBmb3VuZCBmb3IgTW9kZWwgJHttb2RlbH0gXHUyMDE0IHJ1biBcIkdMT0JBTDogR2V0IEFsbCBTZXR0aW5nc1wiIHRvIGNyZWF0ZSBvbmVgKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIGZldGNoIHNldHRpbmdzIGZyb20gJHtpcH06ICR7ZX1gKVxuXHRcdH1cblx0fVxuXG5cdC8qKiBMb2FkcyB0aGUgZGV2aWNlIEpTT04gZm9yIHRoZSBnaXZlbiBtb2RlbCwgY2FjaGVzIGl0IGFzIGFjdGl2ZU1vZGVsLCBhbmQgcHVzaGVzIGl0IHRvIHRoZSBjb250cm9sbGVyLiAqL1xuXHRwcml2YXRlIHN5bmNNb2RlbChtb2RlbDogc3RyaW5nKTogdm9pZCB7XG5cdFx0dGhpcy5hY3RpdmVNb2RlbCA9IG1vZGVsXG5cdFx0Y29uc3Qgc2NoZW1hID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRcdGlmICghc2NoZW1hKSB7XG5cdFx0XHRsb2dnZXIud2FybihgTW9kZWwgXCIke21vZGVsfVwiIG5vdCBmb3VuZCBpbiBkZXZpY2Ugc2NoZW1hc2ApXG5cdFx0XHR0aGlzLnN0Q29udHJvbGxlci5zZXRNb2RlbChtb2RlbCwgW10pXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRjb25zdCBhY3Rpb25zID0gQXJyYXkuaXNBcnJheShzY2hlbWEuY21kU2NoZW1hKSA/IHNjaGVtYS5jbWRTY2hlbWEgOiBbXVxuXG5cdFx0dGhpcy5zdENvbnRyb2xsZXIuc2V0TW9kZWwobW9kZWwsIGFjdGlvbnMpXG5cdFx0aWYgKGFjdGlvbnMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRsb2dnZXIud2FybihgTm8gYWN0aW9ucyBmb3VuZCBmb3IgbW9kZWwgXCIke21vZGVsfVwiIFx1MjAxNCBzZXR0aW5ncyBkZWNvZGluZyB3aWxsIHVzZSByYXcgSURzYClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBMb2FkZWQgJHthY3Rpb25zLmxlbmd0aH0gYWN0aW9ucyBmb3IgbW9kZWwgXCIke21vZGVsfVwiLCBzZWN0aW9uZWQ9JHtzY2hlbWEuc2VjdGlvbmVkfWApXG5cdFx0fVxuXHR9XG5cblx0Z2V0Q29uZmlnRmllbGRzKCk6IFNvbWVDb21wYW5pb25Db25maWdGaWVsZFtdIHtcblx0XHRyZXR1cm4gR2V0Q29uZmlnRmllbGRzKHRoaXMuZGlzY292ZXJlZERldmljZXMpXG5cdH1cblxuXHQvKiogUmV0dXJucyB0aGUgZWZmZWN0aXZlIGhvc3QgSVAsIHJlc29sdmVkIGZyb20gTUFDXHUyMTkySVAgdmlhIGRpc2NvdmVyZWREZXZpY2VzIChhdXRvKSBvciBjb25maWcuaG9zdCAobWFudWFsKS4gKi9cblx0Z2V0IGhvc3QoKTogc3RyaW5nIHtcblx0XHRyZXR1cm4gcmVzb2x2ZUhvc3QodGhpcy5jb25maWcsIHRoaXMuZGlzY292ZXJlZERldmljZXMpXG5cdH1cblxuXHQvKiogUmV0dXJucyBkaXNjb3ZlcmVkIGRldmljZXMgZm9yIHVzZSBpbiBhY3Rpb25zL2NvbmZpZyAqL1xuXHRnZXQgZGV2aWNlcygpOiBEZXZpY2VJbmZvW10ge1xuXHRcdHJldHVybiB0aGlzLmRpc2NvdmVyZWREZXZpY2VzXG5cdH1cblxuXHR1cGRhdGVBY3Rpb25zKCk6IHZvaWQge1xuXHRcdFVwZGF0ZUFjdGlvbnModGhpcylcblx0fVxuXG5cdHVwZGF0ZUZlZWRiYWNrcygpOiB2b2lkIHtcblx0XHRVcGRhdGVGZWVkYmFja3ModGhpcylcblx0fVxuXG5cdHVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKTogdm9pZCB7XG5cdFx0VXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucyh0aGlzKVxuXHR9XG5cblx0dXBkYXRlVmFyaWFibGVWYWx1ZXMoKTogdm9pZCB7XG5cdFx0VXBkYXRlVmFyaWFibGVWYWx1ZXModGhpcylcblx0fVxufVxuXG5leHBvcnQgeyBVcGdyYWRlU2NyaXB0cyB9XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7OztBQWtCQSxJQUFNLHFCQUFrQyxDQUFDLFFBQVEsT0FBTyxZQUFXO0FBRWxFLFVBQVEsSUFBSSxJQUFJLE1BQU0sWUFBVyxDQUFFLElBQUksU0FBUyxLQUFLLE1BQU0sTUFBTSxFQUFFLElBQUksT0FBTyxFQUFFO0FBQ2pGO0FBRUEsU0FBUyxVQUFVLFFBQTRCLE9BQWlCLFNBQWU7QUFDOUUsUUFBTSxPQUFPLE9BQU8sT0FBTyxxQkFBcUIsYUFBYSxPQUFPLG1CQUFtQjtBQUN2RixPQUFLLFFBQVEsT0FBTyxPQUFPO0FBQzVCO0FBT00sU0FBVSxtQkFBbUIsUUFBZTtBQUNqRCxTQUFPO0lBQ04sT0FBTyxDQUFDLFlBQW9CLFVBQVUsUUFBUSxTQUFTLE9BQU87SUFDOUQsTUFBTSxDQUFDLFlBQW9CLFVBQVUsUUFBUSxRQUFRLE9BQU87SUFDNUQsTUFBTSxDQUFDLFlBQW9CLFVBQVUsUUFBUSxRQUFRLE9BQU87SUFDNUQsT0FBTyxDQUFDLFlBQW9CLFVBQVUsUUFBUSxTQUFTLE9BQU87O0FBRWhFOzs7QUNUTSxTQUFVLFlBQVksTUFBVztBQUV2QztBQXlCTSxTQUFVLFdBQVcsR0FBVyxHQUFXLEdBQVcsR0FBVTtBQUNyRSxNQUFJLGVBQXdCLElBQUksUUFBUyxNQUFRLElBQUksUUFBUyxJQUFNLElBQUk7QUFDeEUsTUFBSSxLQUFLLEtBQUssS0FBSyxJQUFJLEdBQUc7QUFDekIsbUJBQWUsV0FBWSxLQUFLLE1BQU0sT0FBTyxJQUFJLEVBQUU7RUFDcEQ7QUFDQSxTQUFPO0FBQ1I7OztBQy9EQSxTQUFTLG9CQUFvQjtBQTJFdkIsSUFBTyxzQkFBUCxjQUFtQyxhQUFtQztFQUNsRTtFQUNBO0VBRVQsSUFBVyxXQUFRO0FBQ2xCLFdBQU8sS0FBSyxZQUFZO0VBQ3pCO0VBQ0EsSUFBVyxhQUFVO0FBQ3BCLFdBQU8sS0FBSyxZQUFZO0VBQ3pCO0VBRUEsSUFBWSxhQUFVO0FBQ3JCLFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXLFVBQVU7QUFDbkQsYUFBTyxLQUFLO0lBQ2IsT0FBTztBQUNOLGFBQU87SUFDUjtFQUNEO0VBRUEsU0FBdUU7RUFFdkUsWUFBWSxTQUF5QyxTQUErQjtBQUNuRixVQUFLO0FBRUwsU0FBSyxXQUFXO0FBQ2hCLFNBQUssV0FBVyxFQUFFLEdBQUcsUUFBTztFQUM3QjtFQUVBLEtBQUssTUFBYyxVQUFtQixVQUFxQjtBQUMxRCxRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVztBQUFVLFlBQU0sSUFBSSxNQUFNLHlCQUF5QjtBQUM3RixZQUFRLEtBQUssUUFBUTtNQUNwQixLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0sb0NBQW9DO01BQ3JELEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSx5QkFBeUI7TUFDMUMsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtNQUNwQyxLQUFLO0FBQ0o7TUFDRDtBQUNDLG9CQUFZLEtBQUssTUFBTTtBQUN2QixjQUFNLElBQUksTUFBTSxzQkFBc0I7SUFDeEM7QUFFQSxTQUFLLFNBQVM7QUFFZCxRQUFJO0FBQVUsV0FBSyxHQUFHLGFBQWEsUUFBUTtBQUUzQyxTQUFLLFNBQ0gsb0JBQW9CO01BQ3BCLFFBQVEsS0FBSyxTQUFTO01BQ3RCLFlBQVk7O0tBRVosRUFDQSxLQUNBLENBQUMsYUFBWTtBQUNaLFdBQUssU0FBUyxFQUFFLFlBQVksTUFBTSxTQUFRO0FBQzFDLFdBQUssU0FBUyx3QkFBd0IsSUFBSSxVQUFVLElBQUk7QUFDeEQsV0FBSyxLQUFLLFdBQVc7SUFDdEIsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLFNBQVM7QUFDZCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQUVBLE1BQU0sVUFBcUI7QUFDMUIsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVcsVUFBVTtJQUVwRCxPQUFPO0FBQ04sY0FBUSxLQUFLLFFBQVE7UUFDcEIsS0FBSztBQUNKLGdCQUFNLElBQUksTUFBTSxvQ0FBb0M7UUFDckQsS0FBSztRQUNMLEtBQUs7UUFDTCxLQUFLO0FBQ0osZ0JBQU0sSUFBSSxNQUFNLG9CQUFvQjtRQUNyQztBQUNDLHNCQUFZLEtBQUssTUFBTTtBQUN2QixnQkFBTSxJQUFJLE1BQU0sc0JBQXNCO01BQ3hDO0lBQ0Q7QUFFQSxVQUFNLFdBQVcsS0FBSyxPQUFPO0FBQzdCLFNBQUssU0FBUztBQUVkLFFBQUk7QUFBVSxXQUFLLEdBQUcsU0FBUyxRQUFRO0FBRXZDLFNBQUssU0FDSCxxQkFBcUI7TUFDckI7S0FDQSxFQUNBLEtBQ0EsTUFBSztBQUNKLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxRQUFRO0FBQ3JELFdBQUssS0FBSyxPQUFPO0lBQ2xCLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxTQUFTLHdCQUF3QixPQUFPLFFBQVE7QUFDckQsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFXQSxLQUNDLGNBQ0EsY0FDQSxpQkFDQSxnQkFDQSxTQUNBLFVBQXFCO0FBRXJCLFFBQUksT0FBTyxpQkFBaUI7QUFBVSxZQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDekUsUUFBSSxPQUFPLG9CQUFvQixVQUFVO0FBQ3hDLFVBQUksT0FBTyxtQkFBbUIsWUFBWSxPQUFPLFlBQVk7QUFBVSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDMUcsVUFBSSxhQUFhLFVBQWEsT0FBTyxhQUFhO0FBQVksY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBRWpHLFlBQU0sU0FBUyxLQUFLLGVBQWUsY0FBYyxjQUFjLGVBQWU7QUFDOUUsV0FBSyxXQUFXLFFBQVEsZ0JBQWdCLFNBQVMsUUFBUTtJQUMxRCxXQUFXLE9BQU8sb0JBQW9CLFVBQVU7QUFDL0MsVUFBSSxtQkFBbUIsVUFBYSxPQUFPLG1CQUFtQjtBQUFZLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUU3RyxZQUFNLFNBQVMsS0FBSyxlQUFlLGNBQWMsR0FBRyxNQUFTO0FBQzdELFdBQUssV0FBVyxRQUFRLGNBQWMsaUJBQWlCLGNBQWM7SUFDdEUsT0FBTztBQUNOLFlBQU0sSUFBSSxNQUFNLG1CQUFtQjtJQUNwQztFQUNEO0VBRUEsZUFDQyxjQUNBLFFBQ0EsUUFBMEI7QUFFMUIsUUFBSTtBQUNKLFFBQUksT0FBTyxpQkFBaUIsVUFBVTtBQUNyQyxlQUFTLE9BQU8sS0FBSyxjQUFjLE9BQU87SUFDM0MsV0FBVyxPQUFPLFNBQVMsWUFBWSxHQUFHO0FBQ3pDLGVBQVM7SUFDVixXQUFXLE1BQU0sUUFBUSxZQUFZLEdBQUc7QUFFdkMsYUFBTyxPQUFPLEtBQUssWUFBWTtJQUNoQyxPQUFPO0FBQ04sZUFBUyxPQUFPLEtBQUssYUFBYSxRQUFRLGFBQWEsWUFBWSxhQUFhLFVBQVU7SUFDM0Y7QUFFQSxXQUFPLE9BQU8sU0FBUyxRQUFRLFdBQVcsU0FBWSxTQUFTLFNBQVMsTUFBUztFQUNsRjtFQUVBLFdBQVcsUUFBZ0IsTUFBYyxTQUFpQixVQUFxQjtBQUM5RSxRQUFJLENBQUMsS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXO0FBQVUsWUFBTSxJQUFJLE1BQU0sb0JBQW9CO0FBRXpGLFNBQUssU0FDSCxvQkFBb0I7TUFDcEIsVUFBVSxLQUFLLE9BQU87TUFDdEIsU0FBUztNQUVUO01BQ0E7S0FDQSxFQUNBLEtBQ0EsTUFBSztBQUNKLGlCQUFVO0lBQ1gsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQUVBLHFCQUFxQixTQUErQjtBQUNuRCxRQUFJO0FBQ0gsV0FBSyxLQUFLLFdBQVcsUUFBUSxTQUFTLFFBQVEsTUFBTTtJQUNyRCxTQUFTLElBQUk7SUFFYjtFQUNEO0VBQ0EsbUJBQW1CLE9BQVk7QUFDOUIsU0FBSyxTQUFTO0FBRWQsVUFBTSxhQUFhLEtBQUs7QUFDeEIsUUFBSTtBQUFZLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxXQUFXLFFBQVE7QUFFaEYsUUFBSTtBQUNILFdBQUssS0FBSyxTQUFTLEtBQUs7SUFDekIsU0FBUyxJQUFJO0lBRWI7RUFDRDs7OztBQzlQSyxTQUFVLGtCQUFtRCxLQUFZO0FBQzlFLFFBQU0sT0FBTztBQUNiLFNBQU8sQ0FBQyxDQUFDLFFBQVEsT0FBTyxTQUFTLFlBQVksT0FBTyxLQUFLLE9BQU8sWUFBWSxLQUFLLHVCQUF1QjtBQUN6Rzs7O0FDNkJNLElBQWdCLGVBQWhCLE1BQTRCO0VBQ3hCO0VBQ0E7RUFFQTtFQUVULElBQVcsS0FBRTtBQUNaLFdBQU8sS0FBSyxTQUFTO0VBQ3RCO0VBRUEsSUFBVyxrQkFBZTtBQUN6QixXQUFPLEtBQUs7RUFDYjs7Ozs7RUFNQSxJQUFXLFFBQUs7QUFDZixXQUFPLEtBQUssU0FBUztFQUN0Qjs7OztFQUtBLFlBQVksVUFBaUI7QUFDNUIsUUFBSSxDQUFDLGtCQUE2QixRQUFRLEtBQUssQ0FBQyxTQUFTO0FBQ3hELFlBQU0sSUFBSSxNQUNULG1HQUFtRztBQUdyRyxTQUFLLFdBQVc7QUFFaEIsU0FBSyxVQUFVLG1CQUFrQjtBQUVqQyxTQUFLLHdCQUF3QixLQUFLLHNCQUFzQixLQUFLLElBQUk7QUFFakUsU0FBSyxXQUFXO01BQ2YsMkJBQTJCO01BQzNCLHdCQUF3Qjs7QUFHekIsU0FBSyxJQUFJLFNBQVMsY0FBYztFQUNqQztFQStCQSxXQUFXLFdBQTRDLFlBQWlDO0FBQ3ZGLFNBQUssU0FBUyxXQUFXLFdBQVcsVUFBVTtFQUMvQzs7Ozs7RUF1QkEscUJBQXFCLFNBQXlEO0FBQzdFLFNBQUssU0FBUyxxQkFBcUIsT0FBTztFQUMzQzs7Ozs7RUFNQSx1QkFBdUIsV0FBK0Q7QUFDckYsU0FBSyxTQUFTLHVCQUF1QixTQUFTO0VBQy9DOzs7Ozs7RUFPQSxxQkFDQyxXQUNBLFNBQThDO0FBRTlDLFNBQUssU0FBUyxxQkFBcUIsV0FBVyxPQUFPO0VBQ3REOzs7OztFQU1BLHVCQUF1QixXQUErRDtBQUNyRixRQUFJLE1BQU0sUUFBUSxTQUFTO0FBQUcsWUFBTSxJQUFJLE1BQU0sd0RBQXdEO0FBRXRHLFNBQUssU0FBUyx1QkFBdUIsU0FBUztFQUMvQzs7Ozs7RUFNQSxrQkFBa0IsUUFBdUM7QUFDeEQsU0FBSyxTQUFTLGtCQUFrQixNQUFNO0VBQ3ZDOzs7Ozs7RUFPQSxpQkFBbUMsWUFBYTtBQUMvQyxXQUFPLEtBQUssU0FBUyxpQkFBaUIsVUFBVTtFQUNqRDs7OztFQUtBLG9CQUFpQjtBQUNoQixTQUFLLFNBQVMsa0JBQWlCO0VBQ2hDOzs7Ozs7O0VBUUEsZUFDQyxpQkFDRyxlQUFtRDtBQUV0RCxTQUFLLFNBQVMsZUFBZSxDQUFDLGNBQWMsR0FBRyxhQUFhLENBQUM7RUFDOUQ7Ozs7O0VBTUEsc0JBQXNCLGFBQXFCO0FBQzFDLFNBQUssU0FBUyxtQkFBbUIsV0FBVztFQUM3Qzs7Ozs7O0VBT0Esb0JBQW9CLFdBQW1CO0FBQ3RDLFNBQUssU0FBUyxpQkFBaUIsU0FBUztFQUN6Qzs7Ozs7O0VBTUEsc0JBQXNCLFdBQW1CO0FBQ3hDLFNBQUssU0FBUyxtQkFBbUIsU0FBUztFQUMzQzs7Ozs7O0VBT0Esd0JBQXdCLGFBQXFCO0FBQzVDLFNBQUssU0FBUyxxQkFBcUIsV0FBVztFQUMvQzs7Ozs7O0VBT0EsYUFBYSxRQUFpQyxjQUFxQjtBQUNsRSxTQUFLLFNBQVMsYUFBYSxRQUFRLFlBQVk7RUFDaEQ7Ozs7Ozs7O0VBU0EsUUFBUSxNQUFjLE1BQWNBLE9BQWMsTUFBc0I7QUFDdkUsU0FBSyxTQUFTLFFBQVEsTUFBTSxNQUFNQSxPQUFNLElBQUk7RUFDN0M7Ozs7Ozs7Ozs7O0VBWUEsYUFBYSxRQUF3QixTQUF1QjtBQUMzRCxTQUFLLFNBQVMsYUFBYSxRQUFRLFdBQVcsSUFBSTtFQUNuRDs7Ozs7O0VBT0EsSUFBSSxPQUFpQixTQUFlO0FBQ25DLFlBQVEsT0FBTztNQUNkLEtBQUs7QUFDSixhQUFLLFFBQVEsTUFBTSxPQUFPO0FBQzFCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsTUFBTSxPQUFPO0FBQzFCO01BQ0Q7QUFDQyxvQkFBWSxLQUFLO0FBQ2pCLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7SUFDRjtFQUNEO0VBWUEsc0JBQ0MsZUFDQSxVQUF5QztBQUV6QyxVQUFNLFVBQWtDLE9BQU8sa0JBQWtCLFdBQVcsRUFBRSxNQUFNLGNBQWEsSUFBSztBQUV0RyxVQUFNLFNBQVMsSUFBSSxvQkFBb0IsS0FBSyxVQUFVLE9BQU87QUFDN0QsUUFBSTtBQUFVLGFBQU8sR0FBRyxXQUFXLFFBQVE7QUFFM0MsV0FBTztFQUNSOzs7O0FDL1VELElBQVk7Q0FBWixTQUFZQyxpQkFBYztBQUN6QixFQUFBQSxnQkFBQSxJQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxZQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxjQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxtQkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsV0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsY0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsZ0JBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLHVCQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSx5QkFBQSxJQUFBO0FBQ0QsR0FWWSxtQkFBQSxpQkFBYyxDQUFBLEVBQUE7QUFhcEIsSUFBVztDQUFqQixTQUFpQkMsUUFBSztBQUVSLEVBQUFBLE9BQUEsS0FBSztBQUNMLEVBQUFBLE9BQUEsV0FDWjtBQUNZLEVBQUFBLE9BQUEsVUFBVTtBQUNWLEVBQUFBLE9BQUEsT0FDWjtBQUNZLEVBQUFBLE9BQUEsY0FBYztBQUNkLEVBQUFBLE9BQUEsVUFBVTtBQUNWLEVBQUFBLE9BQUEsUUFBUTtBQUNSLEVBQUFBLE9BQUEsZUFBZTtBQUNmLEVBQUFBLE9BQUEsZUFBZTtBQUNmLEVBQUFBLE9BQUEsU0FBUztBQUNULEVBQUFBLE9BQUEsZ0JBQWdCO0FBQ2hCLEVBQUFBLE9BQUEsWUFBWTtBQUNaLEVBQUFBLE9BQUEsV0FDWjtBQUNGLEdBbEJpQixVQUFBLFFBQUssQ0FBQSxFQUFBOzs7QUNqQnRCLE9BQU8sUUFBUTtBQUNmLE9BQU8sVUFBVTtBQUlqQixJQUFNLFNBQVMsbUJBQW1CLFFBQVE7QUF5QjFDLFNBQVMsdUJBQW9CO0FBQzVCLFFBQU0sY0FBYyxLQUFLLEtBQUssWUFBWSxTQUFTLFlBQVk7QUFDL0QsUUFBTSxlQUFlLEtBQUssS0FBSyxZQUFZLFNBQVMsV0FBVztBQUcvRCxNQUFJLEdBQUcsV0FBVyxXQUFXLEdBQUc7QUFDL0IsV0FBTyxNQUFNLHlCQUF5QixXQUFXLEVBQUU7QUFDbkQsV0FBTztFQUNSO0FBR0EsTUFBSSxHQUFHLFdBQVcsWUFBWSxHQUFHO0FBQ2hDLFdBQU8sS0FBSyxxREFBcUQsWUFBWSxFQUFFO0FBQy9FLFdBQU87RUFDUjtBQUdBLFFBQU0sV0FBVzs7TUFBMEMsV0FBVztNQUFTLFlBQVk7O0FBQzNGLFNBQU8sTUFBTSxRQUFRO0FBQ3JCLFFBQU0sSUFBSSxNQUFNLFFBQVE7QUFDekI7QUFHQSxJQUFNLGdCQUFnQixxQkFBb0I7QUFHMUMsSUFBSSxxQkFBaUQ7QUFNL0MsU0FBVSxtQkFBZ0I7QUFDL0IsU0FBTztBQUNSO0FBTUEsU0FBUyxvQkFBaUI7QUFDekIsUUFBTSxVQUErQixDQUFBO0FBQ3JDLE1BQUk7QUFDSCxVQUFNLFFBQVEsR0FBRyxZQUFZLGFBQWEsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLFNBQVMsT0FBTyxDQUFDO0FBRTdFLGVBQVcsS0FBSyxPQUFPO0FBQ3RCLFlBQU0sV0FBVyxLQUFLLEtBQUssZUFBZSxDQUFDO0FBQzNDLFlBQU0sT0FBTyxLQUFLLE1BQU0sR0FBRyxhQUFhLFVBQVUsTUFBTSxDQUFDO0FBQ3pELFVBQUksTUFBTSxPQUFPO0FBQ2hCLGdCQUFRLE9BQU8sS0FBSyxLQUFLLENBQUMsSUFBSTtNQUMvQjtJQUNEO0FBRUEsV0FBTyxNQUFNLFVBQVUsT0FBTyxLQUFLLE9BQU8sRUFBRSxNQUFNLDRCQUE0QjtFQUMvRSxTQUFTLEdBQUc7QUFDWCxXQUFPLE1BQU0sa0NBQWtDLENBQUMsRUFBRTtFQUNuRDtBQUNBLFNBQU87QUFDUjtBQU1NLFNBQVUsbUJBQWdCO0FBQy9CLE1BQUksQ0FBQyxvQkFBb0I7QUFDeEIseUJBQXFCLGtCQUFpQjtFQUN2QztBQUNBLFNBQU87QUFDUjtBQU1NLFNBQVUsZ0JBQWdCLE9BQWE7QUFDNUMsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxTQUFPLFFBQVEsS0FBSztBQUNyQjtBQU1NLFNBQVUsc0JBQW1CO0FBQ2xDLFNBQU8sS0FBSyx1Q0FBdUM7QUFDbkQsdUJBQXFCLGtCQUFpQjtBQUN2QztBQUtBLFNBQVMsc0JBQW1CO0FBQzNCLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsU0FBTyxPQUFPLEtBQUssT0FBTyxFQUFFLEtBQUk7QUFDakM7QUFFTSxTQUFVLGdCQUFnQixvQkFBa0MsQ0FBQSxHQUFFO0FBQ25FLFFBQU0sU0FBUyxvQkFBbUI7QUFJbEMsUUFBTSxnQkFBZ0I7SUFDckIsRUFBRSxJQUFJLElBQUksT0FBTyxrQ0FBaUM7SUFDbEQsR0FBRyxrQkFBa0IsSUFBSSxDQUFDLE9BQU87TUFDaEMsSUFBSSxFQUFFLE9BQU87TUFDYixPQUFPLFNBQVMsRUFBRSxLQUFLLEtBQUssRUFBRSxHQUFHLE9BQU8sRUFBRSxFQUFFO01BQzNDOztBQUdILFNBQU87OztJQUdOO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVM7TUFDVCxTQUFTO01BQ1QsU0FBUzs7O0lBSVY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUztNQUNULE9BQU8sTUFBTTtNQUNiLHFCQUFxQjtNQUNyQixTQUFTOzs7SUFJVjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTLE9BQU8sQ0FBQyxLQUFLO01BQ3RCLFNBQVMsT0FBTyxJQUFJLENBQUMsV0FBVztRQUMvQixJQUFJO1FBQ0osT0FBTyxTQUFTLEtBQUs7UUFDcEI7TUFDRixxQkFBcUI7TUFDckIsU0FBUzs7O0lBSVY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUztNQUNULFNBQVM7OztBQUdaO0FBT00sU0FBVSxZQUFZLFFBQXNCLG1CQUErQjtBQUNoRixNQUFJLE9BQU8sV0FBVztBQUNyQixVQUFNLFNBQVMsa0JBQWtCLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxPQUFPLFNBQVM7QUFDdkUsV0FBTyxRQUFRLE1BQU07RUFDdEI7QUFDQSxTQUFPLE9BQU8sT0FBTyxRQUFRLEVBQUU7QUFDaEM7QUFPTSxTQUFVLGFBQWEsUUFBc0IsbUJBQStCO0FBQ2pGLE1BQUksT0FBTyxXQUFXO0FBQ3JCLFVBQU0sU0FBUyxrQkFBa0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLE9BQU8sU0FBUztBQUN2RSxXQUFPLE1BQU0sNEJBQTRCLE9BQU8sU0FBUyxvQkFBb0IsUUFBUSxTQUFTLE1BQU0sRUFBRTtBQUN0RyxXQUFPLFFBQVEsU0FBUztFQUN6QjtBQUNBLFNBQU8sTUFBTSwyQ0FBMkMsT0FBTyxXQUFXLEdBQUc7QUFDN0UsU0FBTyxPQUFPLE9BQU8sZUFBZSxFQUFFO0FBQ3ZDOzs7QUNwTk0sU0FBVSwwQkFBMEIsTUFBb0I7QUFDN0QsT0FBSyx1QkFBdUI7SUFDM0IsT0FBTyxFQUFFLE1BQU0sc0JBQXFCO0lBQ3BDLFdBQVcsRUFBRSxNQUFNLHVDQUFzQztJQUN6RCxjQUFjLEVBQUUsTUFBTSxzQkFBcUI7SUFDM0MsVUFBVSxFQUFFLE1BQU0sMEJBQXlCO0lBQzNDLFNBQVMsRUFBRSxNQUFNLGdDQUErQjtJQUNoRCxLQUFLLEVBQUUsTUFBTSxxQkFBb0I7SUFDakMsSUFBSSxFQUFFLE1BQU0sb0JBQW1CO0dBQy9CO0FBQ0Y7QUFFQSxJQUFNLG9CQUFvQjtFQUN6QixPQUFPO0VBQ1AsV0FBVztFQUNYLGNBQWM7RUFDZCxVQUFVO0VBQ1YsU0FBUztFQUNULEtBQUs7RUFDTCxJQUFJOztBQVFDLFNBQVUscUJBQXFCLE1BQW9CO0FBQ3hELFFBQU0sY0FBYyxLQUFLO0FBR3pCLE1BQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxhQUFhLG1CQUFtQixXQUFXLEdBQUc7QUFDdkUsU0FBSyxrQkFBa0IsaUJBQWlCO0FBQ3hDO0VBQ0Q7QUFFQSxRQUFNLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxXQUFXO0FBQzVELE1BQUksUUFBUTtBQUNYLFNBQUssa0JBQWtCO01BQ3RCLE9BQU8sT0FBTyxTQUFTO01BQ3ZCLFdBQVcsT0FBTyxhQUFhO01BQy9CLGNBQWMsT0FBTyxnQkFBZ0I7TUFDckMsVUFBVSxPQUFPLGdCQUFnQjtNQUNqQyxTQUFTLE9BQU8saUJBQWlCO01BQ2pDLEtBQUssT0FBTyxPQUFPO01BQ25CLElBQUksT0FBTztLQUNYO0VBQ0YsT0FBTztBQUdOLFNBQUssa0JBQWtCO01BQ3RCLEdBQUc7TUFDSCxJQUFJO0tBQ0o7RUFDRjtBQUNEOzs7QUMxRE8sSUFBTSxpQkFBK0Q7Ozs7Ozs7Ozs7Ozs7OztBQ3FCckUsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxjQUFjO0FBQ3BCLElBQU0sY0FBYztBQUNwQixJQUFNLGNBQWM7QUFDcEIsSUFBTSxnQkFBZ0I7QUFDdEIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxhQUFhO0FBQ25CLElBQU0sdUJBQXVCO0FBQzdCLElBQU0sb0JBQW9CO0FBQzFCLElBQU0sZUFBZTtBQUNyQixJQUFNLG1CQUFtQjtBQUN6QixJQUFNLHNCQUFzQjtBQUM1QixJQUFNLGtCQUFrQjtBQUN4QixJQUFNLGNBQWM7QUFHckIsU0FBVSxlQUFlLE9BQWE7QUFDM0MsVUFBUSxPQUFPO0lBQ2QsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSO0FBQ0MsYUFBTyxTQUFTLE1BQU0sU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztFQUNyRDtBQUNEO0FBUU0sU0FBVSxjQUNmLE9BQ0EsT0FDQSxXQUNBLE9BQXVCO0FBRXZCLFFBQU0sTUFBTSxPQUFPLFVBQVUsV0FBVyxNQUFNLFNBQVMsRUFBRSxJQUFJO0FBQzdELFFBQU0sS0FBSyxPQUFPLGNBQWMsV0FBVyxVQUFVLFNBQVMsRUFBRSxJQUFJO0FBRXBFLE1BQUksVUFBVSxRQUFXO0FBQ3hCLFVBQU0sS0FBSyxPQUFPLFVBQVUsV0FBVyxNQUFNLFNBQVMsRUFBRSxJQUFJO0FBQzVELFdBQU8sR0FBRyxLQUFLLElBQUksR0FBRyxJQUFJLEVBQUUsSUFBSSxFQUFFO0VBQ25DO0FBRUEsU0FBTyxHQUFHLEtBQUssSUFBSSxHQUFHLElBQUksRUFBRTtBQUM3QjtBQVNNLFNBQVUsTUFBTSxPQUFlLFlBQVksR0FBQztBQUNqRCxTQUFPLEtBQUssTUFBTSxTQUFTLEVBQUUsRUFBRSxTQUFTLFdBQVcsR0FBRyxDQUFDO0FBQ3hEO0FBT00sU0FBVSxXQUFXLE9BQXdCO0FBQ2xELFNBQU8sS0FBSyxNQUFNLEtBQUssS0FBSyxFQUMxQixJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFLENBQUM7QUFDWDtBQVNNLFNBQVUsZUFBZSxHQUFXLEdBQVcsR0FBUztBQUM3RCxTQUFPLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxFQUNqQixJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFLEVBQ1AsWUFBVyxDQUFFO0FBQ2hCO0FBUU0sU0FBVSxlQUFlLElBQVU7QUFDeEMsUUFBTSxDQUFDLE9BQU8sVUFBVSxLQUFLLElBQUksR0FBRyxNQUFNLEdBQUc7QUFDN0MsU0FBTztJQUNOO0lBQ0EsT0FBTyxTQUFTLFVBQVUsRUFBRTtJQUM1QixRQUFRLFNBQVMsT0FBTyxFQUFFOztBQUU1QjtBQVVNLFNBQVUsY0FBYyxRQUFnQixRQUFjO0FBQzNELFFBQU0sS0FBSyxTQUFTLE9BQU8sUUFBUSxPQUFPLEVBQUUsR0FBRyxFQUFFO0FBQ2pELFFBQU0sS0FBSyxTQUFTLE9BQU8sUUFBUSxPQUFPLEVBQUUsR0FBRyxFQUFFO0FBQ2pELE1BQUksT0FBTyxNQUFNLEVBQUUsS0FBSyxPQUFPLE1BQU0sRUFBRTtBQUFHLFdBQU87QUFDakQsU0FBTyxLQUFLLElBQUksS0FBSyxFQUFFO0FBQ3hCO0FBU00sU0FBVSxxQkFDZixZQUErQjtBQUUvQixRQUFNLGFBQWtFLENBQUE7QUFDeEUsYUFBVyxDQUFDLE9BQU8sSUFBSSxLQUFLLE9BQU8sUUFBUSxVQUFVLEdBQUc7QUFDdkQsZUFBVyxLQUFLLElBQUk7TUFDbkIsT0FBTyxLQUFLO01BQ1osV0FBVyxNQUFNLFFBQVEsS0FBSyxTQUFTLElBQUksS0FBSyxZQUFZLENBQUE7O0VBRTlEO0FBQ0EsU0FBTztBQUNSO0FBWU0sU0FBVSxxQkFDZixTQUNBLE9BQ0EsT0FDQSxXQUFpQjtBQUVqQixRQUFNLFNBQVMsUUFBUSxLQUFLO0FBQzVCLE1BQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxRQUFRLE9BQU8sU0FBUztBQUFHLFdBQU87QUFHeEQsTUFBSSxTQUFTLE9BQU8sVUFBVSxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUd2RixNQUFJLENBQUMsUUFBUTtBQUNaLGFBQVMsT0FBTyxVQUFVLEtBQUssQ0FBQyxNQUFVO0FBQ3pDLFVBQUksRUFBRSxXQUFXO0FBQU8sZUFBTztBQUMvQixZQUFNLGNBQWMsRUFBRSxTQUFTLEtBQUssQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBQ3BFLFVBQUksQ0FBQyxhQUFhO0FBQVMsZUFBTztBQUVsQyxZQUFNLFNBQVMsWUFBWSxFQUFFO0FBQzdCLGFBQU8sWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxNQUFNO0lBQzVELENBQUM7RUFDRjtBQUVBLFNBQU87QUFDUjs7O0FDeE1BLFNBQVMsWUFBWSxHQUFNO0FBQzFCLFFBQU0sT0FBTztJQUNaLE1BQU0sRUFBRTtJQUNSLElBQUksRUFBRTtJQUNOLE9BQU8sRUFBRTtJQUNULFNBQVMsRUFBRTtJQUNYLFNBQVMsRUFBRTs7QUFHWixVQUFRLEVBQUUsTUFBTTtJQUNmLEtBQUs7QUFDSixhQUFPLEVBQUUsR0FBRyxNQUFNLFNBQVMsRUFBRSxXQUFXLENBQUEsRUFBRTtJQUUzQyxLQUFLO0FBQ0osYUFBTztRQUNOLEdBQUc7UUFDSCxLQUFLLEVBQUU7UUFDUCxLQUFLLEVBQUU7UUFDUCxNQUFNLEVBQUUsUUFBUTtRQUNoQixPQUFPOztJQUdULEtBQUs7QUFDSixhQUFPLEVBQUUsR0FBRyxNQUFNLFNBQVMsRUFBRSxXQUFXLE1BQUs7SUFFOUMsS0FBSztBQUNKLGFBQU8sRUFBRSxHQUFHLE1BQU0sT0FBTyxFQUFFLFNBQVMsR0FBRTtJQUV2QyxLQUFLO0lBQ0wsS0FBSztJQUNMO0FBQ0MsYUFBTztFQUNUO0FBQ0Q7QUFNTSxTQUFVLGVBQVk7QUFDM0IsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxRQUFNLFVBQXNDLENBQUE7QUFFNUMsYUFBVyxDQUFDLE9BQU8sTUFBTSxLQUFLLE9BQU8sUUFBUSxPQUFPLEdBQUc7QUFDdEQsVUFBTSxZQUFZLE9BQU87QUFDekIsUUFBSSxDQUFDLE1BQU0sUUFBUSxTQUFTO0FBQUc7QUFFL0IsZUFBVyxLQUFLLFdBQVc7QUFFMUIsVUFBSSxFQUFFLGFBQWE7QUFBTTtBQUV6QixZQUFNLFdBQVcsY0FBYyxPQUFPLEVBQUUsUUFBUSxFQUFFLEVBQUU7QUFFcEQsWUFBTSxXQUFXLEVBQUUsV0FBVyxDQUFBLEdBQUksSUFBSSxXQUFXO0FBRWpELFlBQU0sU0FBb0M7UUFDekMsTUFBTSxTQUFTLEtBQUssS0FBSyxFQUFFLElBQUk7UUFDL0I7UUFDQSxVQUFVLFlBQVc7UUFFckI7O0FBR0QsY0FBUSxRQUFRLElBQUk7SUFDckI7RUFDRDtBQUVBLFNBQU87QUFDUjtBQVVBLFNBQVMsZ0JBQWdCLFNBQVk7QUFDcEMsUUFBTSxXQUFXLFFBQVEsU0FBUyxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sT0FBTztBQUNuRSxNQUFJLENBQUMsWUFBWSxTQUFTLFNBQVMsY0FBYyxDQUFDLE1BQU0sUUFBUSxTQUFTLE9BQU87QUFBRyxXQUFPO0FBQzFGLE1BQUksU0FBUyxRQUFRLFdBQVc7QUFBRyxXQUFPO0FBQzFDLFFBQU0sU0FBUyxTQUFTLFFBQVEsSUFBSSxDQUFDLE1BQVcsT0FBTyxFQUFFLEtBQUssRUFBRSxZQUFXLENBQUU7QUFDN0UsU0FBTyxPQUFPLFNBQVMsS0FBSyxLQUFLLE9BQU8sU0FBUyxJQUFJO0FBQ3REO0FBRU0sU0FBVSxpQkFBYztBQUM3QixRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFFBQU0sWUFBMEMsQ0FBQTtBQUVoRCxhQUFXLENBQUMsT0FBTyxNQUFNLEtBQUssT0FBTyxRQUFRLE9BQU8sR0FBRztBQUN0RCxVQUFNLFlBQVksT0FBTztBQUN6QixRQUFJLENBQUMsTUFBTSxRQUFRLFNBQVM7QUFBRztBQUUvQixlQUFXLFdBQVcsV0FBVztBQUVoQyxVQUFJLFFBQVEsY0FBYztBQUFNO0FBRWhDLFlBQU0saUJBQWlCLGNBQWMsT0FBTyxRQUFRLFFBQVEsUUFBUSxFQUFFO0FBR3RFLFlBQU0sY0FBYyxRQUFRLFdBQVcsQ0FBQSxHQUFJLElBQUksV0FBVztBQUcxRCxZQUFNLGVBQWUsV0FBVyxPQUFPLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUd2RSxtQkFBYSxLQUFLO1FBQ2pCLE1BQU07UUFDTixJQUFJO1FBQ0osT0FBTztRQUNQLFNBQVM7UUFDVCxTQUFTO09BQ1Q7QUFHRCxZQUFNLGdCQUFxQjtRQUMxQixNQUFNO1FBQ04sTUFBTSxTQUFTLEtBQUssS0FBSyxRQUFRLElBQUk7UUFDckMsU0FBUztRQUNULFVBQVUsTUFBSztBQUVkLGlCQUFPO1FBQ1I7O0FBSUQsVUFBSSxnQkFBZ0IsT0FBTyxHQUFHO0FBQzdCLGNBQU0saUJBQWlCLEdBQUcsY0FBYztBQUd4QyxjQUFNLGNBQWMsV0FBVyxPQUFPLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUV0RSxjQUFNLGVBQW9CO1VBQ3pCLE1BQU07VUFDTixNQUFNLFNBQVMsS0FBSyxLQUFLLFFBQVEsSUFBSTtVQUNyQyxjQUFjO1lBQ2IsU0FBUyxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBQzdCLE9BQU8sV0FBVyxHQUFHLEdBQUcsQ0FBQzs7VUFFMUIsU0FBUztVQUNULFVBQVUsTUFBSztBQUVkLG1CQUFPO1VBQ1I7O0FBR0Qsa0JBQVUsY0FBYyxJQUFJO01BQzdCLE9BQU87QUFDTixrQkFBVSxjQUFjLElBQUk7TUFDN0I7SUFDRDtFQUNEO0FBRUEsU0FBTztBQUNSOzs7QUN6S0EsT0FBT0MsV0FBVTs7O0FDTGpCLE9BQU9DLFNBQVE7QUFpQmYsSUFBTUMsVUFBUyxtQkFBbUIsZ0JBQWdCO0FBMENsRCxTQUFTLGVBQWUsT0FBYTtBQUNwQyxRQUFNLFNBQVMsb0JBQUksSUFBRztBQUN0QixNQUFJLFlBQVk7QUFFaEIsTUFBSTtBQUVILFVBQU0sT0FBTyxnQkFBZ0IsS0FBSztBQUNsQyxRQUFJLENBQUMsTUFBTTtBQUVWLGFBQU8sRUFBRSxXQUFXLE9BQU07SUFDM0I7QUFHQSxnQkFBWSxLQUFLLGFBQWE7QUFHOUIsZUFBVyxVQUFVLEtBQUssYUFBYSxDQUFBLEdBQUk7QUFDMUMsWUFBTSxpQkFBaUIsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUF3QixJQUFJLFNBQVMsYUFBYTtBQUMvRixVQUFJLGdCQUFnQjtBQUVuQixlQUFPLElBQUksT0FBTyxFQUFFO0FBR3BCLGNBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQXdCLElBQUksT0FBTyxPQUFPO0FBQ3BGLFlBQUksYUFBYSxTQUFTO0FBQ3pCLHFCQUFXLFVBQVUsWUFBWSxTQUFTO0FBQ3pDLGdCQUFJLE9BQU8sT0FBTyxPQUFPLFVBQVU7QUFDbEMscUJBQU8sSUFBSSxPQUFPLEtBQUssT0FBTyxFQUFFO1lBQ2pDO1VBQ0Q7UUFDRDtNQUNEO0lBQ0Q7RUFDRCxTQUFTLE1BQU07RUFFZjtBQUVBLFNBQU8sRUFBRSxXQUFXLE9BQU07QUFDM0I7QUFNQSxTQUFTLHNCQUFzQixLQUFXO0FBQ3pDLFFBQU0sV0FBVyxJQUFJLFFBQVEsT0FBTyxLQUFLLFVBQVUsQ0FBQztBQUNwRCxNQUFJLFdBQVc7QUFBRyxVQUFNLElBQUksTUFBTSxpQ0FBaUM7QUFFbkUsUUFBTSxlQUFlLFdBQVc7QUFDaEMsTUFBSSxJQUFJLFlBQVksTUFBTSxJQUFNO0FBQy9CLFVBQU0sSUFBSSxNQUFNLHVDQUF1QyxJQUFJLFlBQVksRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFO0VBQ3hGO0FBRUEsU0FBTztBQUNSO0FBTUEsU0FBUyx1QkFBdUIsT0FBZSxTQUFzQixvQkFBSSxJQUFHLEdBQUU7QUFDN0UsTUFBSSxJQUFJO0FBQ1IsUUFBTSxNQUF1QixDQUFBO0FBRTdCLFNBQU8sSUFBSSxNQUFNLFFBQVE7QUFDeEIsVUFBTSxLQUFLLE1BQU0sQ0FBQztBQUNsQixRQUFJLElBQUksS0FBSyxNQUFNO0FBQVE7QUFHM0IsUUFBSSxPQUFPLElBQUksRUFBRSxLQUFLLElBQUksSUFBSSxNQUFNLFFBQVE7QUFDM0MsVUFBSSxLQUFLO1FBQ1IsUUFBUTtRQUNSO1FBQ0EsWUFBWSxDQUFDLE1BQU0sSUFBSSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQyxDQUFDO09BQ3JEO0FBQ0QsV0FBSztBQUNMO0lBQ0Q7QUFFQSxRQUFJLEtBQUssRUFBRSxRQUFRLGNBQWMsSUFBSSxZQUFZLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUU7QUFDakUsU0FBSztFQUNOO0FBRUEsU0FBTztBQUNSO0FBRU0sU0FBVSx5QkFBeUIsS0FBYSxPQUFhO0FBQ2xFLFFBQU0sTUFBTSxzQkFBc0IsR0FBRztBQUNyQyxRQUFNLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSTtBQUM3QixNQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQU0sSUFBSSxNQUFNLDRCQUE0QjtFQUM3QztBQUVBLFFBQU0sV0FBVyxJQUFJLE1BQU0sQ0FBQztBQUM1QixRQUFNLFFBQVEsTUFBTTtBQUNwQixRQUFNLE1BQU0sUUFBUTtBQUNwQixNQUFJLE1BQU0sSUFBSTtBQUFRLFVBQU0sSUFBSSxNQUFNLHNCQUFzQjtBQUU1RCxRQUFNLEVBQUUsT0FBTSxJQUFLLGVBQWUsS0FBSztBQUN2QyxTQUFPLHVCQUF1QixJQUFJLFNBQVMsT0FBTyxHQUFHLEdBQUcsTUFBTTtBQUMvRDtBQU1NLFNBQVUsOEJBQThCLEtBQWEsT0FBYTtBQUN2RSxRQUFNLE1BQU0sc0JBQXNCLEdBQUc7QUFDckMsUUFBTSxRQUFRLElBQUksTUFBTSxDQUFDLElBQUk7QUFDN0IsTUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFNLElBQUksTUFBTSw0QkFBNEI7RUFDN0M7QUFHQSxNQUFJLElBQUksVUFBVSx1QkFBdUIsTUFBTSxJQUFJLE1BQU07QUFDekQsUUFBTSxNQUFNLElBQUksU0FBUztBQUN6QixRQUFNLE1BQXVCLENBQUE7QUFHN0IsUUFBTSxFQUFFLE9BQU0sSUFBSyxlQUFlLEtBQUs7QUFJdkMsUUFBTSxvQkFBb0IsQ0FBQyxhQUFhLGlCQUFpQixXQUFXO0FBS3BFLFFBQU0sbUJBQW1CLENBQUMsV0FBVztBQUVyQyxTQUFPLElBQUksSUFBSSxLQUFLO0FBQ25CLFVBQU0sU0FBUyxJQUFJLENBQUM7QUFDcEIsVUFBTSxlQUFlLElBQUksSUFBSSxDQUFDO0FBRTlCLFVBQU0sYUFBYSxJQUFJLElBQUk7QUFDM0IsUUFBSSxhQUFhO0FBQUs7QUFFdEIsVUFBTSxXQUFXLGtCQUFrQixTQUFTLFlBQVk7QUFDeEQsVUFBTSxhQUFhLGlCQUFpQixTQUFTLFlBQVk7QUFFekQsUUFBSTtBQUNKLFFBQUk7QUFDSixRQUFJO0FBRUosUUFBSSxZQUFZO0FBUWYsY0FBUSxJQUFJLElBQUksQ0FBQztBQUNqQixZQUFNLFdBQVcsSUFBSSxTQUFTLElBQUksR0FBRyxVQUFVO0FBRS9DLFlBQU0sU0FBUyxnQkFBZ0IsS0FBSztBQUNwQyxZQUFNLGlCQUFpQixRQUFRLGFBQWEsQ0FBQSxHQUMxQyxPQUFPLENBQUMsT0FBaUIsRUFBRSxXQUFXLGVBQWUsRUFBRSxXQUFXLG9CQUFvQixFQUFFLFVBQVUsTUFBUyxFQUMzRyxLQUFLLENBQUMsR0FBYSxNQUFnQixFQUFFLEtBQUssRUFBRSxFQUFFO0FBRWhELGVBQVMsSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7QUFDekMsY0FBTSxRQUFRLGNBQWMsQ0FBQztBQUM3QixZQUFJLE9BQU87QUFDVixjQUFJLEtBQUssRUFBRSxRQUFRLE1BQU0sUUFBUSxJQUFJLE1BQU0sSUFBSSxPQUFPLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFDLENBQUU7UUFDbEY7TUFFRDtBQUNBLFVBQUk7QUFDSjtJQUNELFdBQVcsVUFBVTtBQUVwQixjQUFRLElBQUksSUFBSSxDQUFDO0FBQ2pCLGdCQUFVLElBQUksSUFBSSxDQUFDO0FBQ25CLFVBQUksSUFBSTtJQUNULE9BQU87QUFFTixnQkFBVSxJQUFJLElBQUksQ0FBQztBQUNuQixVQUFJLElBQUk7SUFDVDtBQUVBLFVBQU0sT0FBTyxJQUFJO0FBQ2pCLFVBQU0sU0FBUztBQUVmLFdBQU8sSUFBSSxJQUFJLE1BQU07QUFDcEIsWUFBTSxLQUFLLElBQUksQ0FBQztBQUNoQixVQUFJO0FBR0osVUFBSSxPQUFPLElBQUksRUFBRSxLQUFLLElBQUksSUFBSSxNQUFNO0FBQ25DLHFCQUFhLENBQUMsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLENBQUM7QUFDaEQsYUFBSztNQUNOLE9BQU87QUFDTixxQkFBYSxDQUFDLElBQUksSUFBSSxDQUFDLENBQUM7QUFDeEIsYUFBSztNQUNOO0FBRUEsWUFBTSxVQUF5QjtRQUM5QixRQUFRO1FBQ1I7UUFDQTs7QUFFRCxVQUFJLFVBQVUsUUFBVztBQUN4QixnQkFBUSxRQUFRO01BQ2pCO0FBQ0EsVUFBSSxLQUFLLE9BQU87SUFDakI7QUFRQSxRQUFJLE1BQU0sVUFBVSxhQUFhLElBQUksR0FBRztBQUN2QyxVQUFJLE1BQU0sV0FBVyxJQUFJLElBQUksSUFBSTtBQUNqQyxVQUFJLFFBQVE7QUFDWixhQUFPLE1BQU0sWUFBWTtBQUN4QixjQUFNLFVBQXlCLEVBQUUsUUFBUSxjQUFjLElBQUksU0FBUyxZQUFZLENBQUMsSUFBSSxLQUFLLENBQUMsRUFBQztBQUM1RixZQUFJLFVBQVU7QUFBVyxrQkFBUSxRQUFRO0FBQ3pDLFlBQUksS0FBSyxPQUFPO01BQ2pCO0lBQ0Q7QUFFQSxRQUFJO0VBQ0w7QUFFQSxTQUFPO0FBQ1I7QUFXTSxTQUFVLHNCQUFzQixPQUFlLEtBQVc7QUFDL0QsUUFBTSxNQUFNLHNCQUFzQixHQUFHO0FBQ3JDLFFBQU0sUUFBUSxJQUFJLE1BQU0sQ0FBQyxJQUFJO0FBQzdCLE1BQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBTSxJQUFJLE1BQU0saUNBQWlDLE1BQU0sU0FBUyxFQUFFLENBQUMsR0FBRztFQUN2RTtBQUNBLFFBQU0sRUFBRSxVQUFTLElBQUssZUFBZSxLQUFLO0FBQzFDLFNBQU8sWUFBWSw4QkFBOEIsS0FBSyxLQUFLLElBQUkseUJBQXlCLEtBQUssS0FBSztBQUNuRztBQU1NLFNBQVUsb0JBQW9CLFNBQXdCLFNBQW1CO0FBRTlFLE1BQUksU0FBUyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxRQUFRLFVBQVUsRUFBRSxPQUFPLFFBQVEsRUFBRTtBQUtuRixNQUFJLENBQUMsUUFBUTtBQUNaLFVBQU0sYUFBYSxRQUFRLEtBQUssQ0FBQyxNQUFLO0FBQ3JDLFVBQUksRUFBRSxXQUFXLFFBQVE7QUFBUSxlQUFPO0FBRXhDLFlBQU0sY0FBYyxFQUFFLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDL0QsVUFBSSxDQUFDLGFBQWE7QUFBUyxlQUFPO0FBRWxDLFlBQU0sZ0JBQWdCLFFBQVEsS0FBSyxFQUFFO0FBQ3JDLGFBQU8sWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxhQUFhO0lBQzlELENBQUM7QUFDRCxRQUFJLFlBQVk7QUFDZixlQUFTO0lBQ1Y7RUFDRDtBQUVBLFFBQU0sU0FBUyxNQUFNLFFBQVEsTUFBTTtBQUNuQyxRQUFNLFFBQVEsTUFBTSxRQUFRLEVBQUU7QUFDOUIsUUFBTSxTQUFTLFdBQVcsUUFBUSxVQUFVO0FBQzVDLFFBQU0sU0FDTCxRQUFRLFdBQVcsV0FBVyxJQUMzQixlQUFlLFFBQVEsV0FBVyxDQUFDLEdBQUcsUUFBUSxXQUFXLENBQUMsR0FBRyxRQUFRLFdBQVcsQ0FBQyxDQUFDLElBQ2xGLFFBQVEsV0FBVyxXQUFXLElBQzdCLFFBQVEsV0FBVyxDQUFDLElBQ3BCLFFBQVEsV0FBVyxLQUFLLEdBQUc7QUFHaEMsUUFBTSxXQUFXLFFBQVEsVUFBVSxTQUFZLE9BQU8sUUFBUSxLQUFLLEtBQUs7QUFDeEUsUUFBTSxTQUFTLE9BQU8sTUFBTSxHQUFHLFFBQVEsT0FBTyxLQUFLLFFBQVEsTUFBTTtBQUdqRSxNQUFJLFFBQVE7QUFDWCxRQUFJLE9BQU8sT0FBTztBQUdsQixRQUFJLFFBQVEsVUFBVSxRQUFXO0FBQ2hDLGFBQU8sR0FBRyxJQUFJLE1BQU0sUUFBUSxRQUFRLENBQUM7SUFDdEMsT0FFSztBQUNKLFlBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDcEUsVUFBSSxhQUFhLFNBQVM7QUFDekIsY0FBTSxnQkFBZ0IsUUFBUSxLQUFLLE9BQU87QUFDMUMsY0FBTSxjQUFjLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sYUFBYTtBQUMxRSxZQUFJLGFBQWE7QUFDaEIsaUJBQU8sR0FBRyxJQUFJLElBQUksWUFBWSxLQUFLO1FBQ3BDO01BQ0Q7SUFDRDtBQUdBLFVBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDcEUsUUFBSSxhQUFhLFdBQVcsUUFBUSxXQUFXLFdBQVcsR0FBRztBQUM1RCxZQUFNLFNBQVMsWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLFdBQVcsQ0FBQyxDQUFDO0FBQzdFLFVBQUksUUFBUTtBQUNYLGVBQU8sR0FBRyxNQUFNLE1BQU0sSUFBSSxLQUFLLE9BQU8sS0FBSyxLQUFLLE1BQU07TUFDdkQ7SUFDRDtBQUNBLFdBQU8sR0FBRyxNQUFNLE1BQU0sSUFBSSxLQUFLLE1BQU07RUFDdEM7QUFHQSxTQUFPLEdBQUcsTUFBTTtBQUNqQjtBQVdNLFNBQVUsaUNBQ2YsT0FDQSxLQUFXO0FBRVgsUUFBTSxTQUFTLGdCQUFnQixLQUFLO0FBQ3BDLFFBQU0sb0JBQW9CLFFBQVE7QUFHbEMsTUFBSSxzQkFBc0IsUUFBVztBQUNwQyxVQUFNLFdBQVcsb0JBQ2QsOEJBQThCLEtBQUssS0FBSyxJQUN4Qyx5QkFBeUIsS0FBSyxLQUFLO0FBQ3RDLFdBQU8sRUFBRSxVQUFVLG1CQUFtQixLQUFJO0VBQzNDO0FBR0EsTUFBSSxlQUFnQyxDQUFBO0FBQ3BDLE1BQUksb0JBQXFDLENBQUE7QUFFekMsTUFBSTtBQUNILG1CQUFlLHlCQUF5QixLQUFLLEtBQUs7RUFDbkQsU0FBUyxHQUFHO0FBQ1gsSUFBQUEsUUFBTyxNQUFNLHVCQUF1QixDQUFDLEVBQUU7RUFDeEM7QUFFQSxNQUFJO0FBQ0gsd0JBQW9CLDhCQUE4QixLQUFLLEtBQUs7RUFDN0QsU0FBUyxHQUFHO0FBQ1gsSUFBQUEsUUFBTyxNQUFNLDRCQUE0QixDQUFDLEVBQUU7RUFDN0M7QUFHQSxNQUFJLGtCQUFrQixTQUFTLGFBQWEsUUFBUTtBQUNuRCxJQUFBQSxRQUFPLEtBQUssNkNBQTZDLGtCQUFrQixNQUFNLFlBQVksYUFBYSxNQUFNLEdBQUc7QUFDbkgsV0FBTyxFQUFFLFVBQVUsbUJBQW1CLG1CQUFtQixLQUFJO0VBQzlELFdBQVcsYUFBYSxTQUFTLEdBQUc7QUFDbkMsSUFBQUEsUUFBTyxLQUFLLG1DQUFtQyxhQUFhLE1BQU0saUJBQWlCLGtCQUFrQixNQUFNLEdBQUc7QUFDOUcsV0FBTyxFQUFFLFVBQVUsY0FBYyxtQkFBbUIsTUFBSztFQUMxRCxPQUFPO0FBRU4sSUFBQUEsUUFBTyxLQUFLLHVEQUF1RCxLQUFLLEVBQUU7QUFDMUUsV0FBTyxFQUFFLFVBQVUsQ0FBQSxHQUFJLG1CQUFtQixLQUFJO0VBQy9DO0FBQ0Q7QUFFTSxTQUFVLDRCQUE0QixPQUFlLEtBQVc7QUFDckUsUUFBTSxFQUFFLFVBQVMsSUFBSyxlQUFlLEtBQUs7QUFDMUMsU0FBTyxZQUFZLDhCQUE4QixLQUFLLEtBQUssSUFBSSx5QkFBeUIsS0FBSyxLQUFLO0FBQ25HO0FBU0EsU0FBUyxtQkFBbUIsWUFBb0I7QUFDL0MsTUFBSSxXQUFXLFdBQVcsR0FBRztBQUM1QixXQUFPLEVBQUUsSUFBSSxTQUFTLE9BQU8sU0FBUyxNQUFNLFVBQVUsU0FBUyxXQUFXLENBQUMsRUFBQztFQUM3RTtBQUVBLE1BQUksV0FBVyxXQUFXLEdBQUc7QUFDNUIsVUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDLElBQUk7QUFDbEIsV0FBTztNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsTUFBTTtNQUNOLFNBQVMsZUFBZSxHQUFHLEdBQUcsQ0FBQzs7RUFFakM7QUFFQSxTQUFPLEVBQUUsSUFBSSxTQUFTLE9BQU8sU0FBUyxNQUFNLE9BQU8sU0FBUyxDQUFDLEdBQUcsVUFBVSxFQUFDO0FBQzVFO0FBTU0sU0FBVSw0QkFDZixXQUNBLFFBQ0EsV0FBc0M7QUFFdEMsUUFBTSxNQUFNLGdCQUFnQixTQUFTO0FBR3JDLE1BQUksQ0FBQyxJQUFJLFdBQVc7QUFDbkIsUUFBSSxZQUFZLENBQUE7RUFDakI7QUFHQSxRQUFNLGFBQWEsT0FBTyxPQUFPLFNBQVMsRUFDeEMsT0FBTyxDQUFDLE1BQU0sRUFBRSxVQUFVLFVBQVUsS0FBSyxFQUN6QyxLQUFLLENBQUMsR0FBRyxNQUFNLGNBQWMsVUFBVSxPQUFPLEVBQUUsS0FBSyxJQUFJLGNBQWMsVUFBVSxPQUFPLEVBQUUsS0FBSyxDQUFDO0FBRWxHLEVBQUFDLFFBQU8sS0FBSyxtQkFBbUIsVUFBVSxLQUFLLEVBQUU7QUFDaEQsRUFBQUEsUUFBTyxNQUFNLDZCQUE2QixXQUFXLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssSUFBSSxDQUFDLEVBQUU7QUFLckYsUUFBTSxtQkFBbUIsb0JBQUksSUFBRztBQUNoQyxhQUFXLEtBQUssWUFBWTtBQUMzQixlQUFXLGFBQWEsRUFBRSxhQUFhLENBQUEsR0FBSTtBQUMxQyxZQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxPQUFPO0FBQ3JFLFVBQUksQ0FBQyxVQUFVO0FBQVM7QUFDeEIsWUFBTSxTQUFTLFVBQVU7QUFDekIsWUFBTSxRQUFRLFVBQVU7QUFDeEIsWUFBTSxNQUFNLEdBQUcsS0FBSyxJQUFJLE1BQU07QUFDOUIsVUFBSSxpQkFBaUIsSUFBSSxHQUFHO0FBQUc7QUFFL0IsWUFBTSxnQkFBZ0IsT0FDcEIsT0FBTyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxLQUFLLE1BQU0sRUFDakQsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLE1BQU0sRUFDeEIsS0FBSyxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUM7QUFFdEIsVUFBSSxTQUFTO0FBQ2IsaUJBQVcsT0FBTyxlQUFlO0FBQ2hDLFlBQUksUUFBUSxTQUFTO0FBQUcsbUJBQVM7aUJBQ3hCLE1BQU0sU0FBUztBQUFHO01BQzVCO0FBQ0EsVUFBSSxTQUFTLEdBQUc7QUFDZix5QkFBaUIsSUFBSSxLQUFLLE1BQU07QUFDaEMsUUFBQUEsUUFBTyxNQUFNLGdDQUFnQyxNQUFNLEtBQUssQ0FBQyxZQUFZLE1BQU0sTUFBTSxDQUFDLG9CQUFlLE1BQU0sRUFBRTtNQUMxRztJQUNEO0VBQ0Q7QUFJQSxRQUFNLFlBQVksb0JBQUksSUFBRztBQUN6QixhQUFXLEVBQUUsUUFBUSxJQUFJLE1BQUssS0FBTSxRQUFRO0FBQzNDLFFBQUksVUFBVTtBQUFXO0FBQ3pCLFVBQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxFQUFFO0FBQzNCLFFBQUksQ0FBQyxVQUFVLElBQUksR0FBRztBQUFHLGdCQUFVLElBQUksS0FBSyxvQkFBSSxJQUFHLENBQUU7QUFDckQsY0FBVSxJQUFJLEdBQUcsRUFBRyxJQUFJLEtBQUs7RUFDOUI7QUFNQSxhQUFXLEVBQUUsUUFBUSxJQUFJLE9BQU8sV0FBVSxLQUFNLFFBQVE7QUFFdkQsVUFBTSxnQkFBZ0IsSUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxFQUFFO0FBQ2xGLFFBQUksZUFBZTtBQUNsQixZQUFNLE1BQU0sY0FBYyxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQy9ELFVBQUk7QUFBSyxZQUFJLFVBQVUsbUJBQW1CLFVBQVUsRUFBRTtBQUd0RCxZQUFNLGtCQUFrQixVQUFVLElBQUksR0FBRyxNQUFNLElBQUksRUFBRSxFQUFFO0FBQ3ZELFVBQUksbUJBQW1CLGdCQUFnQixPQUFPLEdBQUc7QUFDaEQsY0FBTSxXQUFXLEtBQUssSUFBSSxHQUFHLGVBQWU7QUFDNUMsY0FBTSxpQkFBaUIsY0FBYyxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQzFFLFlBQUksYUFBYSxLQUFLLGNBQWMsVUFBVSxVQUFhLENBQUMsZ0JBQWdCO0FBQzNFLHdCQUFjLFFBQVE7QUFDdEIsVUFBQUEsUUFBTyxLQUFLLDZDQUE2QyxNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLEVBQUU7UUFDekY7TUFDRDtBQUNBO0lBQ0Q7QUFLQSxVQUFNLFlBQVksSUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFLO0FBQzFDLFVBQUksRUFBRSxXQUFXO0FBQVEsZUFBTztBQUNoQyxZQUFNLFdBQVcsRUFBRSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ3hELFVBQUksQ0FBQyxVQUFVO0FBQVMsZUFBTztBQUMvQixVQUFJLE1BQU0sRUFBRTtBQUFJLGVBQU87QUFDdkIsWUFBTSxTQUFTLEtBQUssRUFBRTtBQUV0QixhQUFPLFdBQVcsS0FBSyxDQUFDLE1BQUs7QUFDNUIsY0FBTSxXQUFXLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRSxFQUFFO0FBQzlFLGNBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsZUFBTyxVQUFVLFNBQVMsS0FBSyxDQUFDLE9BQVksR0FBRyxPQUFPLE1BQU07TUFDN0QsQ0FBQztJQUNGLENBQUM7QUFDRCxRQUFJLFdBQVc7QUFDZCxZQUFNLFNBQVMsS0FBSyxVQUFVO0FBQzlCLFlBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsVUFBSSxVQUFVLFdBQVcsQ0FBQyxTQUFTLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE1BQU0sR0FBRztBQUM3RSxZQUFJLFFBQVEsV0FBVyxTQUFTLENBQUM7QUFDakMsbUJBQVcsS0FBSyxZQUFZO0FBQzNCLGdCQUFNLFdBQVcsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxVQUFVLEVBQUU7QUFDdEYsZ0JBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsZ0JBQU0sWUFBWSxVQUFVLFNBQVMsS0FBSyxDQUFDLE9BQVksR0FBRyxPQUFPLE1BQU07QUFDdkUsY0FBSSxXQUFXO0FBQ2Qsb0JBQVEsVUFBVTtBQUNsQjtVQUNEO1FBQ0Q7QUFDQSxpQkFBUyxRQUFRLEtBQUssRUFBRSxJQUFJLFFBQVEsTUFBSyxDQUFFO0FBQzNDLFFBQUFBLFFBQU8sS0FDTixpQkFBaUIsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyx1QkFBdUIsTUFBTSxVQUFVLEVBQUUsQ0FBQyxjQUFjLE1BQU0sTUFBTSxLQUFLLElBQUk7TUFFN0g7QUFDQTtJQUNEO0FBR0EsUUFBSTtBQUVKLGVBQVcsS0FBSyxZQUFZO0FBQzNCLFlBQU0sUUFBUSxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUU7QUFDekUsVUFBSSxPQUFPO0FBQ1YsaUJBQVMsZ0JBQWdCLEtBQUs7QUFFOUIsY0FBTSxXQUFXLE1BQU0sS0FBSyxRQUFRLHFDQUFxQyxFQUFFLEVBQUUsS0FBSTtBQUNqRixlQUFPLE9BQU8sR0FBRyxRQUFRLHlCQUF5QixFQUFFLEtBQUs7QUFDekQsUUFBQUEsUUFBTyxLQUFLLG1CQUFtQixNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLGVBQWUsRUFBRSxLQUFLLFVBQVU7QUFDNUY7TUFDRDtJQUNEO0FBSUEsUUFBSSxDQUFDLFFBQVE7QUFDWixVQUFJLGNBQWM7QUFDbEIsaUJBQVcsS0FBSyxZQUFZO0FBQzNCLGNBQU0sWUFBWSxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQVU7QUFDOUMsY0FBSSxFQUFFLFdBQVc7QUFBUSxtQkFBTztBQUNoQyxnQkFBTSxXQUFXLEVBQUUsU0FBUyxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sT0FBTztBQUM3RCxjQUFJLENBQUMsVUFBVTtBQUFTLG1CQUFPO0FBQy9CLGNBQUksTUFBTSxFQUFFO0FBQUksbUJBQU87QUFDdkIsZ0JBQU0sU0FBUyxLQUFLLEVBQUU7QUFDdEIsZ0JBQU0sU0FBUyxpQkFBaUIsSUFBSSxHQUFHLE1BQU0sSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLO0FBQzVELGlCQUFPLFVBQVU7UUFDbEIsQ0FBQztBQUNELFlBQUksV0FBVztBQUNkLHdCQUFjO0FBQ2QsVUFBQUEsUUFBTyxNQUNOLFVBQVUsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyw0Q0FBNEMsTUFBTSxVQUFVLEVBQUUsQ0FBQyw2QkFBd0I7QUFFL0g7UUFDRDtNQUNEO0FBQ0EsVUFBSTtBQUFhO0lBQ2xCO0FBR0EsUUFBSSxDQUFDLFFBQVE7QUFDWixlQUFTO1FBQ1I7UUFDQTtRQUNBLE1BQU0sZUFBZSxNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxFQUFFLFlBQVcsQ0FBRTtRQUNoRSxTQUFTLENBQUMsbUJBQW1CLFVBQVUsQ0FBQzs7QUFFekMsVUFBSSxVQUFVO0FBQVcsZUFBTyxRQUFRO0FBQ3hDLE1BQUFBLFFBQU8sS0FBSywwQkFBMEIsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxFQUFFO0lBQ3RFLE9BQU87QUFJTixhQUFPLFVBQVUsT0FBTyxTQUFTLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLEtBQUssQ0FBQTtBQUNwRSxhQUFPLE9BQU87QUFFZCxZQUFNLGtCQUFrQixVQUFVLElBQUksR0FBRyxNQUFNLElBQUksRUFBRSxFQUFFO0FBQ3ZELFVBQUksbUJBQW1CLGdCQUFnQixPQUFPLEdBQUc7QUFDaEQsY0FBTSxXQUFXLEtBQUssSUFBSSxHQUFHLGVBQWU7QUFDNUMsWUFBSSxhQUFhLEdBQUc7QUFFbkIsaUJBQU8sUUFBUTtRQUNoQixPQUFPO0FBRU4sZ0JBQU0sZUFBZSxNQUFNLEtBQUssRUFBRSxRQUFRLFdBQVcsRUFBQyxHQUFJLENBQUMsR0FBRyxPQUFPO1lBQ3BFLElBQUk7WUFDSixPQUFPLFdBQVcsSUFBSSxDQUFDO1lBQ3RCO0FBQ0YsaUJBQU8sUUFBUSxRQUFRO1lBQ3RCLElBQUk7WUFDSixPQUFPO1lBQ1AsTUFBTTtZQUNOLFNBQVM7WUFDVCxTQUFTO1dBQ0Y7UUFDVDtNQUNEO0FBTUEsWUFBTSxrQkFBa0IsbUJBQW1CLFVBQVUsRUFBRTtBQUN2RCxZQUFNLFdBQVcsT0FBTyxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQzdELFVBQUksVUFBVTtBQUNiLFlBQUksU0FBUyxXQUFXLE1BQU0sUUFBUSxTQUFTLE9BQU8sR0FBRztBQUN4RCxnQkFBTSxZQUFZLFNBQVMsUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sZUFBZTtBQUM1RSxjQUFJLENBQUMsV0FBVztBQUNmLFlBQUFBLFFBQU8sS0FDTiwrQkFBK0IsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxpQ0FBaUMsZUFBZSxzQ0FBaUM7QUFHOUkscUJBQVMsT0FBTztBQUNoQixtQkFBUSxTQUFpQjtVQUMxQjtRQUNEO0FBQ0EsaUJBQVMsVUFBVTtNQUNwQjtJQUNEO0FBRUEsUUFBSSxVQUFVLEtBQUssTUFBTTtFQUMxQjtBQVNBLGFBQVcsRUFBRSxRQUFRLEdBQUUsS0FBTSxRQUFRO0FBQ3BDLFVBQU0sa0JBQWtCLElBQUksVUFBVSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRTtBQUNwRixRQUFJO0FBQWlCO0FBR3JCLFVBQU0sWUFBWSxJQUFJLFVBQVUsS0FBSyxDQUFDLE1BQUs7QUFDMUMsVUFBSSxFQUFFLFdBQVc7QUFBUSxlQUFPO0FBQ2hDLFlBQU1DLFlBQVcsRUFBRSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ3hELGFBQU8sQ0FBQyxDQUFDQSxXQUFVLFdBQVcsS0FBSyxFQUFFO0lBQ3RDLENBQUM7QUFDRCxRQUFJLENBQUM7QUFBVztBQUVoQixVQUFNLFNBQVMsS0FBSyxVQUFVO0FBQzlCLFVBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsUUFBSSxDQUFDLFVBQVUsV0FBVyxTQUFTLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE1BQU07QUFBRztBQUk5RSxVQUFNLGVBQWUsV0FBVyxLQUFLLENBQUMsTUFBSztBQUMxQyxZQUFNLFdBQVcsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxVQUFVLEVBQUU7QUFDdEYsWUFBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUNoRSxhQUFPLFVBQVUsU0FBUyxLQUFLLENBQUMsT0FBWSxHQUFHLE9BQU8sTUFBTTtJQUM3RCxDQUFDO0FBQ0QsVUFBTSxrQkFBa0IsU0FBUyxRQUFRLElBQUksQ0FBQyxNQUFXLEVBQUUsRUFBWSxFQUFFLEtBQUssQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDO0FBQzdGLFVBQU0sZUFBZSxnQkFBZ0IsU0FBUyxLQUFLLFdBQVcsZ0JBQWdCLGdCQUFnQixTQUFTLENBQUMsSUFBSTtBQUU1RyxRQUFJLENBQUMsZ0JBQWdCLENBQUM7QUFBYztBQUdwQyxRQUFJLFFBQVEsV0FBVyxTQUFTLENBQUM7QUFDakMsZUFBVyxLQUFLLFlBQVk7QUFDM0IsWUFBTSxXQUFXLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sVUFBVSxFQUFFO0FBQ3RGLFlBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsWUFBTSxZQUFZLFVBQVUsU0FBUyxLQUFLLENBQUMsT0FBWSxHQUFHLE9BQU8sTUFBTTtBQUN2RSxVQUFJLFdBQVc7QUFDZCxnQkFBUSxVQUFVO0FBQ2xCO01BQ0Q7SUFDRDtBQUVBLGFBQVMsUUFBUSxLQUFLLEVBQUUsSUFBSSxRQUFRLE1BQUssQ0FBRTtBQUMzQyxJQUFBRCxRQUFPLEtBQ04seUJBQXlCLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsdUJBQXVCLE1BQU0sVUFBVSxFQUFFLENBQUMsY0FBYyxNQUFNLE1BQU0sS0FBSyxJQUFJO0VBRXJJO0FBRUEsU0FBTztBQUNSO0FBTU0sU0FBVSxvQkFBb0IsVUFBa0IsU0FBb0I7QUFDekUsTUFBSTtBQUVILFVBQU0sYUFBa0IsRUFBRSxPQUFPLFFBQVEsTUFBSztBQUc5QyxRQUFJLGVBQWUsU0FBUztBQUMzQixpQkFBVyxZQUFZLFFBQVE7SUFDaEM7QUFHQSxRQUFJLGVBQWUsU0FBUztBQUMzQixpQkFBVyxZQUFZLFFBQVEsVUFBVSxJQUFJLENBQUMsVUFBYztBQUUzRCxjQUFNLGVBQW9CLENBQUE7QUFDMUIsWUFBSSxZQUFZO0FBQU8sdUJBQWEsU0FBUyxNQUFNO0FBQ25ELFlBQUksUUFBUTtBQUFPLHVCQUFhLEtBQUssTUFBTTtBQUMzQyxZQUFJLFdBQVc7QUFBTyx1QkFBYSxRQUFRLE1BQU07QUFDakQsWUFBSSxVQUFVO0FBQU8sdUJBQWEsT0FBTyxNQUFNO0FBQy9DLFlBQUksYUFBYTtBQUFPLHVCQUFhLFVBQVUsTUFBTTtBQUVyRCxtQkFBVyxPQUFPLE9BQU8sS0FBSyxLQUFLLEdBQUc7QUFDckMsY0FBSSxFQUFFLE9BQU87QUFBZSx5QkFBYSxHQUFHLElBQUksTUFBTSxHQUFHO1FBQzFEO0FBQ0EsZUFBTztNQUNSLENBQUM7SUFDRjtBQUVBLGVBQVcsT0FBTyxPQUFPLEtBQUssT0FBTyxHQUFHO0FBQ3ZDLFVBQUksRUFBRSxPQUFPLGFBQWE7QUFDekIsbUJBQVcsR0FBRyxJQUFLLFFBQWdCLEdBQUc7TUFDdkM7SUFDRDtBQUdBLFFBQUksT0FBTyxLQUFLLFVBQVUsWUFBWSxNQUFNLENBQUM7QUFLN0MsV0FBTyxLQUFLLFFBQVEsMERBQTBELDZCQUE2QjtBQUUzRyxJQUFBRSxJQUFHLGNBQWMsVUFBVSxPQUFPLE1BQU0sTUFBTTtFQUMvQyxTQUFTLEdBQUc7QUFDWCxJQUFBRixRQUFPLE1BQU0scUJBQXFCLENBQUMsRUFBRTtFQUN0QztBQUNEOzs7QUR6eEJBLElBQU1HLFVBQVMsbUJBQW1CLFNBQVM7QUFFckMsU0FBVSxjQUFjLE1BQW9CO0FBQ2pELFFBQU0sYUFBYSxpQkFBZ0I7QUFDbkMsUUFBTSxhQUFhLGFBQVk7QUFDL0IsUUFBTSxVQUFVLHFCQUFxQixVQUFVO0FBQy9DLFFBQU0sZUFBb0IsQ0FBQTtBQUUxQixRQUFNLGNBQWMsS0FBSztBQU16QixNQUFJLEtBQUssT0FBTyxTQUFTO0FBQ3hCLGlCQUFhLHVCQUF1QixJQUFJO01BQ3ZDLE1BQU07TUFDTixhQUFhO01BQ2IsU0FBUyxDQUFBO01BQ1QsVUFBVSxZQUFXO0FBQ3BCLGNBQU0sUUFBUTtBQUNkLGNBQU0sS0FBSyxLQUFLO0FBRWhCLGNBQU0sTUFBTSxNQUFNLEtBQUssYUFBYSxtQkFBbUIsRUFBRTtBQUV6RCxZQUFJLFlBQVksZ0JBQWdCLEtBQUs7QUFFckMsY0FBTSxFQUFFLFVBQVUsUUFBUSxrQkFBaUIsSUFBSyxpQ0FBaUMsT0FBTyxHQUFHO0FBQzNGLFFBQUFBLFFBQU8sTUFBTSxpQkFBaUIsS0FBSyxVQUFVLE1BQU0sQ0FBQyxFQUFFO0FBRXRELFlBQUksQ0FBQyxXQUFXO0FBQ2YsVUFBQUEsUUFBTyxLQUFLLFNBQVMsS0FBSyx1REFBa0Q7QUFDNUUsc0JBQVk7WUFDWDtZQUNBLFdBQVcscUJBQXFCO1lBQ2hDLFdBQVcsQ0FBQTs7UUFFYixXQUFXLHNCQUFzQixNQUFNO0FBQ3RDLFVBQUFBLFFBQU8sS0FBSywyQkFBMkIsaUJBQWlCLHdCQUF3QjtBQUNoRixzQkFBWSxFQUFFLEdBQUcsV0FBVyxXQUFXLGtCQUFpQjtRQUN6RDtBQUVBLGNBQU0sVUFBVSw0QkFBNEIsV0FBVyxRQUFRLE9BQU87QUFDdEUsUUFBQUEsUUFBTyxNQUFNLHFCQUFxQixLQUFLLFVBQVUsU0FBUyxNQUFNLENBQUMsQ0FBQyxFQUFFO0FBRXBFLGNBQU1DLGlCQUFnQixpQkFBZ0I7QUFDdEMsY0FBTSxhQUFhQyxNQUFLLEtBQUtELGdCQUFlLFFBQVEsS0FBSyxPQUFPO0FBQ2hFLDRCQUFvQixZQUFZLE9BQU87QUFFdkMsNEJBQW1CO0FBRW5CLFFBQUFELFFBQU8sS0FBSyxTQUFTLEtBQUssd0NBQXdDO01BQ25FOztFQUVGO0FBTUEsYUFBVyxDQUFDLFVBQVUsTUFBTSxLQUFLLE9BQU8sUUFBUSxVQUFVLEdBQUc7QUFDNUQsVUFBTSxFQUFFLE9BQU8sT0FBTyxPQUFNLElBQUssZUFBZSxRQUFRO0FBR3hELFFBQUksVUFBVTtBQUFhO0FBRzNCLFVBQU0sU0FBUyxRQUFRLEtBQUs7QUFDNUIsVUFBTSxZQUFZLFFBQVEsV0FBVyxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sTUFBTTtBQUUzRixpQkFBYSxRQUFRLElBQUk7TUFDeEIsR0FBRztNQUNILFVBQVUsT0FBTyxVQUFjO0FBQzlCLGNBQU0sS0FBSyxLQUFLO0FBQ2hCLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVksTUFBTSxRQUFRLE9BQU8sSUFBSSxXQUFXO0FBQ3pGLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTztBQUNuQyxjQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU8sS0FBSztBQUN4QyxjQUFNLFlBQVksU0FBUztBQUUzQixjQUFNLEtBQUssYUFBYSxhQUFhLE9BQU8sT0FBTyxXQUFXLE9BQU8sRUFBRTtNQUN4RTs7RUFFRjtBQUtBLFFBQU0sZUFBZSxRQUFRLFdBQVc7QUFDeEMsTUFBSSxjQUFjO0FBQ2pCLFVBQU0sbUJBQW1CLGFBQWEsYUFBYSxDQUFBLEdBQUksS0FBSyxDQUFDLE1BQVcsRUFBRSxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBRS9GLFFBQUksaUJBQWlCO0FBQ3BCLFlBQU0sV0FBVyxHQUFHLFdBQVc7QUFFL0IsbUJBQWEsUUFBUSxJQUFJO1FBQ3hCLE1BQU0sU0FBUyxXQUFXO1FBQzFCLFNBQVMsQ0FBQTtRQUNULFVBQVUsWUFBVztBQUNwQixnQkFBTSxLQUFLLEtBQUs7QUFDaEIsVUFBQUEsUUFBTyxLQUFLLHlCQUFvQixXQUFXLE1BQU0sRUFBRSxFQUFFO0FBQ3JELGdCQUFNLEtBQUssYUFBYSxjQUFjLEVBQUU7QUFDeEMsZ0JBQU0sS0FBSyxhQUFhLG1CQUFtQixFQUFFLEVBQUUsTUFBTSxDQUFDLFFBQU87QUFDNUQsWUFBQUEsUUFBTyxLQUFLLDZDQUE2QyxHQUFHLEVBQUU7VUFDL0QsQ0FBQztRQUNGOztJQUVGO0VBQ0Q7QUFFQSxPQUFLLHFCQUFxQixZQUFZO0FBR3ZDOzs7QUVqSEEsU0FBUyxpQkFDUixTQUNBLE9BQ0EsT0FDQSxXQUNBLE9BQWE7QUFFYixRQUFNLFVBQVUscUJBQXFCLFNBQVMsT0FBTyxPQUFPLFNBQVM7QUFDckUsTUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLFFBQVEsUUFBUSxPQUFPO0FBQUcsV0FBTztBQUd4RCxRQUFNLGNBQWMsUUFBUSxRQUFRLEtBQUssQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBQ3pFLE1BQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxRQUFRLFlBQVksT0FBTztBQUFHLFdBQU87QUFHaEUsUUFBTSxTQUFTLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sS0FBSztBQUNsRSxTQUFPLFFBQVEsU0FBUztBQUN6QjtBQU1NLFNBQVUsZ0JBQWdCLE1BQW9CO0FBQ25ELFFBQU0sYUFBYSxpQkFBZ0I7QUFDbkMsUUFBTSxlQUFlLGVBQWM7QUFDbkMsUUFBTSxVQUFVLHFCQUFxQixVQUFVO0FBQy9DLFFBQU0saUJBQXNCLENBQUE7QUFHNUIsUUFBTSxjQUFjLEtBQUs7QUFNekIsYUFBVyxDQUFDLFlBQVksUUFBUSxLQUFLLE9BQU8sUUFBUSxZQUFZLEdBQUc7QUFDbEUsVUFBTSxFQUFFLE9BQU8sT0FBTyxPQUFNLElBQUssZUFBZSxVQUFVO0FBRzFELFFBQUksVUFBVTtBQUFhO0FBRzNCLG1CQUFlLFVBQVUsSUFBSTtNQUM1QixHQUFHO01BQ0gsVUFBVSxDQUFDLGtCQUFzQjtBQUNoQyxjQUFNLEtBQUssS0FBSztBQUNoQixjQUFNLFFBQVEsY0FBYyxRQUFRLE9BQU8sS0FBSztBQUNoRCxjQUFNLFlBQVksU0FBUztBQUczQixZQUFJLFFBQVEsY0FBYyxRQUFRLE9BQU87QUFDekMsWUFBSSxVQUFVLFFBQVc7QUFDeEIsZ0JBQU0sZUFBZSxxQkFBcUIsU0FBUyxPQUFPLE9BQU8sU0FBUztBQUMxRSxjQUFJLGNBQWMsVUFBVSxRQUFXO0FBQ3RDLG9CQUFRLGFBQWE7VUFDdEI7UUFDRDtBQUdBLFlBQUksVUFBVSxRQUFXO0FBQ3hCLGdCQUFNLFlBQVksV0FBVyxLQUFLLEdBQUcsV0FBVyxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUN6RyxjQUFJLFdBQVcsVUFBVSxRQUFXO0FBQ25DLG9CQUFRLFVBQVU7VUFDbkI7UUFDRDtBQUVBLGNBQU0sVUFBVSxLQUFLLGFBQWEsZ0JBQWdCLElBQUksT0FBTyxXQUFXLEtBQUs7QUFLN0UsWUFBSSxXQUFXLFNBQVMsT0FBTyxHQUFHO0FBQ2pDLGlCQUFPLFlBQVksVUFBYSxZQUFZO1FBQzdDO0FBR0EsY0FBTSxZQUFZLGNBQWMsUUFBUSxXQUFXLEtBQUs7QUFFeEQsWUFBSSxhQUFhLFlBQVksUUFBVztBQUV2QyxpQkFBTyxpQkFBaUIsU0FBUyxPQUFPLE9BQU8sV0FBVyxPQUFPO1FBQ2xFO0FBR0EsZUFBTyxXQUFXO01BQ25COztFQUVGO0FBRUEsT0FBSyx1QkFBdUIsY0FBYztBQUczQzs7O0FDckdBLE9BQU9HLFlBQVc7QUFDbEIsT0FBT0MsU0FBUTs7O0FDRGYsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sUUFBUTtBQUlmLElBQU1DLFVBQVMsbUJBQW1CLE9BQU87QUFLbEMsSUFBTSx5QkFBeUI7QUFFL0IsSUFBTSwwQkFBMEI7QUFDaEMsSUFBTSxxQkFBcUIsTUFBTztBQUVuQyxTQUFVLHdCQUFxQjtBQUNwQyxRQUFNLE1BQU0sT0FBTyxNQUFNLElBQUksQ0FBQztBQUM5QixRQUFNLE1BQU0sS0FBSyxNQUFNLEtBQUssT0FBTSxJQUFLLEtBQU07QUFFN0MsTUFBSSxjQUFjLE9BQVEsQ0FBQztBQUMzQixNQUFJLGNBQWMsd0JBQXdCLENBQUM7QUFDM0MsTUFBSSxjQUFjLEtBQUssQ0FBQztBQUV4QixRQUFNLE1BQU0saUJBQWdCO0FBQzVCLE1BQUksS0FBSyxLQUFLLENBQUM7QUFFZixTQUFPLEtBQUssWUFBWSxPQUFPLEVBQUUsS0FBSyxLQUFLLEVBQUU7QUFDN0MsTUFBSSxjQUFjLE1BQVEsRUFBRTtBQUM1QixNQUFJLGNBQWMsS0FBUSxFQUFFO0FBQzVCLE1BQUksY0FBYyxLQUFZLEVBQUU7QUFFaEMsU0FBTztBQUNSO0FBR00sU0FBVSxtQkFBZ0I7QUFDL0IsTUFBSTtBQUNILFVBQU0sU0FBUyxHQUFHLGtCQUFpQjtBQUNuQyxlQUFXLFFBQVEsT0FBTyxLQUFLLE1BQU0sR0FBRztBQUN2QyxpQkFBVyxRQUFRLE9BQU8sSUFBSSxLQUFLLENBQUEsR0FBSTtBQUN0QyxZQUFJLENBQUMsS0FBSyxZQUFZLEtBQUssV0FBVyxVQUFVLEtBQUssT0FBTyxLQUFLLFFBQVEscUJBQXFCO0FBQzdGLGlCQUFPLE9BQU8sS0FBSyxLQUFLLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQWMsU0FBUyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBQzNFO01BQ0Q7SUFDRDtFQUNELFFBQVE7RUFFUjtBQUNBLFNBQU8sT0FBTyxNQUFNLEdBQUcsQ0FBQztBQUN6QjtBQUVNLFNBQVUsdUJBQXVCLEtBQWEsT0FBYTtBQUNoRSxNQUFJLElBQUksU0FBUztBQUFvQixXQUFPO0FBQzVDLE1BQUksSUFBSSxhQUFhLENBQUMsTUFBTTtBQUFRLFdBQU87QUFDM0MsTUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQXlCLFdBQU87QUFDNUQsTUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFLEVBQUUsU0FBUyxPQUFPLE1BQU07QUFBWSxXQUFPO0FBRWxFLFFBQU0sVUFBVSxDQUFDLFFBQWdCLFFBQ2hDLElBQ0UsU0FBUyxRQUFRLFNBQVMsR0FBRyxFQUM3QixTQUFTLE9BQU8sRUFDaEIsTUFBTSxJQUFJLEVBQUUsQ0FBQyxFQUNiLEtBQUk7QUFFUCxRQUFNLFFBQVEsSUFBSSxTQUFTLEdBQUcsRUFBRTtBQUNoQyxRQUFNLFdBQVcsQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQztBQUM1RSxRQUFNLE1BQU0sU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFBRSxLQUFLLEdBQUc7QUFFekUsUUFBTSxPQUFPLFFBQVEsSUFBTSxFQUFFO0FBQzdCLFFBQU0sZUFBZSxRQUFRLElBQU0sRUFBRTtBQUNyQyxRQUFNLFdBQVcsUUFBUSxLQUFNLEVBQUU7QUFDakMsUUFBTSxnQkFBZ0IsR0FBRyxJQUFJLEVBQUksQ0FBQyxJQUFJLElBQUksRUFBSSxDQUFDO0FBRS9DLE1BQUksQ0FBQztBQUFVLFdBQU87QUFJdEIsUUFBTSxRQUFRLFNBQ1osUUFBUSxjQUFjLEVBQUUsRUFDeEIsS0FBSSxFQUNKLE1BQU0sS0FBSyxFQUFFLENBQUM7QUFFaEIsU0FBTztJQUNOLElBQUk7SUFDSjtJQUNBO0lBQ0E7SUFDQSxXQUFXOztJQUNYO0lBQ0E7O0FBRUY7QUFPQSxlQUFzQixxQkFBcUIsUUFBYztBQUN4RCxTQUFPLElBQUksUUFBa0IsQ0FBQyxTQUFTLFdBQVU7QUFDaEQsVUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBRXJDLFFBQUksS0FBSyxTQUFTLENBQUMsUUFBTztBQUN6QixVQUFJLE1BQUs7QUFDVCxhQUFPLElBQUksTUFBTSxJQUFJLFdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQztJQUM3QyxDQUFDO0FBRUQsUUFBSSxRQUFRLEdBQUcsUUFBUSxNQUFLO0FBQzNCLFVBQUk7QUFDSCxjQUFNLE9BQU8sSUFBSSxRQUFPO0FBQ3hCLGNBQU0sWUFBWSxLQUFLO0FBQ3ZCLFlBQUksTUFBSztBQUVULGNBQU0sU0FBUyxHQUFHLGtCQUFpQjtBQUNuQyxtQkFBVyxRQUFRLE9BQU8sS0FBSyxNQUFNLEdBQUc7QUFDdkMscUJBQVcsU0FBUyxPQUFPLElBQUksS0FBSyxDQUFBLEdBQUk7QUFDdkMsZ0JBQ0MsTUFBTSxXQUFXLFVBQ2pCLE1BQU0sWUFBWSxhQUNsQixNQUFNLE9BQ04sTUFBTSxRQUFRLHFCQUNiO0FBQ0QscUJBQU8sUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sU0FBUyxHQUFHLEVBQUUsSUFBSSxHQUFJLENBQUM7WUFDdkU7VUFDRDtRQUNEO0FBQ0EsZUFBTyxJQUFJLE1BQU0sd0NBQXdDLFNBQVMsRUFBRSxDQUFDO01BQ3RFLFNBQVMsSUFBSTtBQUNaLGVBQU8sSUFBSSxNQUFNLE9BQU8sRUFBRSxDQUFDLENBQUM7TUFDN0I7SUFDRCxDQUFDO0VBQ0YsQ0FBQztBQUNGO0FBTUEsZUFBc0IsOEJBQThCLFFBQWM7QUFDakUsU0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFVBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUVyQyxRQUFJLFdBQVc7QUFDZixRQUFJLEtBQUssU0FBUyxDQUFDLFFBQU87QUFDekIsVUFBSSxDQUFDLFVBQVU7QUFDZCxtQkFBVztBQUNYLFlBQUksTUFBSztBQUNULGVBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO01BQzdDO0lBQ0QsQ0FBQztBQUdELFFBQUksUUFBUSxHQUFHLFFBQVEsTUFBSztBQUMzQixVQUFJO0FBQ0gsY0FBTSxPQUFPLElBQUksUUFBTztBQUN4QixjQUFNLFlBQVksS0FBSztBQUN2QixZQUFJLENBQUMsVUFBVTtBQUNkLHFCQUFXO0FBQ1gsY0FBSSxNQUFLO0FBQ1Qsa0JBQVEsU0FBUztRQUNsQjtNQUNELFNBQVMsSUFBSTtBQUNaLFlBQUksQ0FBQyxVQUFVO0FBQ2QscUJBQVc7QUFDWCxjQUFJLE1BQUs7QUFDVCxpQkFBTyxJQUFJLE1BQU0sT0FBTyxFQUFFLENBQUMsQ0FBQztRQUM3QjtNQUNEO0lBQ0QsQ0FBQztFQUNGLENBQUM7QUFDRjtBQVdBLGVBQXNCLGdCQUNyQixVQUNBLGtCQUNBLFlBQVksS0FBSTtBQUVoQixRQUFNLHVCQUF1QjtBQUM3QixRQUFNLHNCQUFzQjtBQUM1QixRQUFNLGVBQWU7QUFFckIsUUFBTSxhQUFhLG9CQUFJLElBQUc7QUFFMUIsU0FBTyxJQUFJLFFBQWMsQ0FBQyxZQUFXO0FBQ3BDLFVBQU0saUJBQWlCLE1BQU0sYUFBYSxFQUFFLE1BQU0sUUFBUSxXQUFXLEtBQUksQ0FBRTtBQUMzRSxVQUFNLG1CQUE2QixDQUFBO0FBRW5DLFVBQU0sVUFBVSxNQUFLO0FBQ3BCLGlCQUFXLFNBQVMsa0JBQWtCO0FBQ3JDLFlBQUk7QUFDSCx5QkFBZSxlQUFlLHNCQUFzQixLQUFLO1FBQzFELFFBQVE7UUFFUjtNQUNEO0FBQ0EsVUFBSTtBQUNILHVCQUFlLE1BQUs7TUFDckIsUUFBUTtNQUVSO0FBQ0EsY0FBTztJQUNSO0FBRUEsVUFBTSxRQUFRLFdBQVcsU0FBUyxTQUFTO0FBQzNDLFVBQU0sUUFBTztBQUViLG1CQUFlLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDbEMsTUFBQUEsUUFBTyxLQUFLLDBCQUEwQixJQUFJLE9BQU8sRUFBRTtJQUNwRCxDQUFDO0FBRUQsbUJBQWUsR0FBRyxXQUFXLENBQUMsS0FBSyxVQUFTO0FBQzNDLFlBQU0sUUFBUSxNQUFNO0FBRXBCLFVBQUksSUFBSSxTQUFTO0FBQUk7QUFDckIsVUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQVE7QUFDcEMsVUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFLEVBQUUsU0FBUyxPQUFPLE1BQU07QUFBWTtBQUUzRCxVQUFJLFdBQVcsSUFBSSxLQUFLO0FBQUc7QUFDM0IsaUJBQVcsSUFBSSxLQUFLO0FBQ3BCLE1BQUFBLFFBQU8sTUFBTSxpQkFBaUIsS0FBSywrQkFBMEI7QUFLN0QsWUFBTSxZQUFZLFlBQVc7QUFDNUIsY0FBTSxpQkFBaUIsS0FBSztBQUM1QixjQUFNLFFBQVEsc0JBQXFCO0FBQ25DLGlCQUFTLEtBQUssT0FBTyxjQUFjLE9BQU8sQ0FBQyxRQUFPO0FBQ2pELGNBQUk7QUFBSyxZQUFBQSxRQUFPLEtBQUssb0JBQW9CLEtBQUssWUFBWSxJQUFJLE9BQU8sRUFBRTtRQUN4RSxDQUFDO01BQ0Y7QUFDQSxnQkFBUyxFQUFHLE1BQU0sQ0FBQyxRQUFRQSxRQUFPLEtBQUssdUJBQXVCLEdBQUcsRUFBRSxDQUFDO0lBQ3JFLENBQUM7QUFFRCxtQkFBZSxLQUFLLHFCQUFxQixNQUFLO0FBSzdDLFlBQU0sU0FBUyxHQUFHLGtCQUFpQjtBQUNuQyxpQkFBVyxTQUFTLE9BQU8sT0FBTyxNQUFNLEdBQUc7QUFDMUMsbUJBQVcsUUFBUSxTQUFTLENBQUEsR0FBSTtBQUMvQixjQUFJLEtBQUssV0FBVyxVQUFVLENBQUMsS0FBSyxVQUFVO0FBQzdDLGdCQUFJO0FBQ0gsNkJBQWUsY0FBYyxzQkFBc0IsS0FBSyxPQUFPO0FBQy9ELCtCQUFpQixLQUFLLEtBQUssT0FBTztZQUNuQyxRQUFRO1lBRVI7VUFDRDtRQUNEO01BQ0Q7QUFDQSxVQUFJLGlCQUFpQixXQUFXLEdBQUc7QUFDbEMsUUFBQUEsUUFBTyxLQUFLLDBEQUEwRDtNQUN2RSxPQUFPO0FBQ04sUUFBQUEsUUFBTyxLQUFLLG9DQUFvQyxvQkFBb0IsSUFBSSxtQkFBbUIsRUFBRTtNQUM5RjtJQUNELENBQUM7RUFDRixDQUFDO0FBQ0Y7QUFLQSxJQUFNLGlCQUFpQixvQkFBSSxJQUFHO0FBYzlCLGVBQXNCLGtCQUFrQixVQUFrQixZQUFZLEtBQUk7QUFDekUsUUFBTSxVQUFVLGVBQWUsSUFBSSxRQUFRO0FBQzNDLE1BQUk7QUFBUyxXQUFPO0FBRXBCLFFBQU0sVUFBVSxpQkFBaUIsVUFBVSxTQUFTLEVBQUUsUUFBUSxNQUFLO0FBQ2xFLG1CQUFlLE9BQU8sUUFBUTtFQUMvQixDQUFDO0FBQ0QsaUJBQWUsSUFBSSxVQUFVLE9BQU87QUFDcEMsU0FBTztBQUNSO0FBRUEsZUFBZSxpQkFBaUIsVUFBa0IsV0FBaUI7QUFDbEUsU0FBTyxJQUFJLFFBQTZCLENBQUMsWUFBVztBQUNuRCxRQUFJLFVBQVU7QUFDZCxRQUFJLGlCQUF3RDtBQUU1RCxVQUFNLGVBQWUsQ0FBQ0MsVUFBc0I7QUFDM0MsVUFBSSxnQkFBZ0I7QUFDbkIsc0JBQWMsY0FBYztBQUM1Qix5QkFBaUI7TUFDbEI7QUFDQSxVQUFJO0FBQ0gsUUFBQUEsTUFBSyxNQUFLO01BQ1gsUUFBUTtNQUVSO0FBQ0EsTUFBQUQsUUFBTyxNQUFNLDZCQUE2QixRQUFRLEVBQUU7SUFDckQ7QUFFQSxVQUFNLE9BQU8sQ0FBQ0MsVUFBc0I7QUFDbkMsVUFBSTtBQUFTO0FBQ2IsZ0JBQVU7QUFDVixtQkFBYSxLQUFLO0FBQ2xCLG1CQUFhQSxLQUFJO0FBQ2pCLE1BQUFELFFBQU8sTUFBTSxzQ0FBc0MsUUFBUSxtQ0FBOEI7QUFDekYsY0FBUSxJQUFJO0lBQ2I7QUFJQSxVQUFNLE9BQU8sTUFBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBQ2pFLFVBQU0sUUFBUSxXQUFXLE1BQU0sS0FBSyxJQUFJLEdBQUcsU0FBUztBQUVwRCxTQUFLLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDeEIsTUFBQUEsUUFBTyxLQUFLLDJCQUEyQixRQUFRLEtBQUssSUFBSSxPQUFPLEVBQUU7QUFDakUsV0FBSyxJQUFJO0lBQ1YsQ0FBQztBQUVELFNBQUssR0FBRyxXQUFXLENBQUMsUUFBZTtBQUVsQyxVQUFJLENBQUMsV0FBVyxJQUFJLFVBQVUsS0FBSyxJQUFJLENBQUMsTUFBTSxNQUFRLElBQUksQ0FBQyxNQUFNLElBQU07QUFDdEUsa0JBQVU7QUFDVixxQkFBYSxLQUFLO0FBQ2xCLFFBQUFBLFFBQU8sS0FBSyxtQ0FBbUMsUUFBUSxFQUFFO0FBS3pELFlBQUksZUFBZSxLQUFLLE1BQU0sS0FBSyxPQUFNLElBQUssS0FBTSxJQUFJO0FBQ3hELGNBQU0sZ0JBQWdCLE1BQUs7QUFDMUIsZ0JBQU0sTUFBTSxPQUFPLE1BQU0sSUFBSSxDQUFDO0FBQzlCLGNBQUksQ0FBQyxJQUFJO0FBQ1QsY0FBSSxDQUFDLElBQUk7QUFDVCxjQUFJLGNBQWMsaUJBQWlCLE9BQVEsQ0FBQztBQUM1QyxjQUFJLENBQUMsSUFBSTtBQUNULGNBQUksQ0FBQyxJQUFJO0FBQ1QsZUFBSyxLQUFLLEtBQUssTUFBTSxVQUFVLE1BQUs7VUFFcEMsQ0FBQztRQUNGO0FBQ0EseUJBQWlCLFlBQVksZUFBZSxHQUFJO0FBR2hELGdCQUFRLE1BQU0sYUFBYSxJQUFJLENBQUM7TUFDakM7SUFDRCxDQUFDO0FBRUQsVUFBTSxTQUFTLFlBQVc7QUFDekIsVUFBSTtBQUNKLFVBQUk7QUFDSixVQUFJO0FBQ0gsa0JBQVUsTUFBTSw4QkFBOEIsUUFBUTtBQUN0RCxtQkFBVyxNQUFNLHFCQUFxQixRQUFRO01BQy9DLFNBQVMsR0FBRztBQUNYLFFBQUFBLFFBQU8sS0FBSyxnREFBZ0QsUUFBUSxLQUFLLENBQUMsRUFBRTtBQUM1RSxhQUFLLElBQUk7QUFDVDtNQUNEO0FBS0EsV0FBSyxLQUFLLEVBQUUsTUFBTSxNQUFNLFNBQVMsUUFBTyxHQUFJLE1BQUs7QUFDaEQsY0FBTSxNQUFNLEtBQUssTUFBTSxLQUFLLE9BQU0sSUFBSyxLQUFNLElBQUk7QUFFakQsY0FBTSxNQUFNLE9BQU8sTUFBTSxJQUFJLENBQUM7QUFDOUIsWUFBSSxDQUFDLElBQUk7QUFDVCxZQUFJLENBQUMsSUFBSTtBQUNULFlBQUksY0FBYyxLQUFLLENBQUM7QUFDeEIsWUFBSSxDQUFDLElBQUk7QUFDVCxZQUFJLENBQUMsSUFBSTtBQUNULGlCQUFTLFFBQVEsQ0FBQyxHQUFHLE1BQUs7QUFDekIsY0FBSSxLQUFLLENBQUMsSUFBSTtRQUNmLENBQUM7QUFDRCxRQUFBQSxRQUFPLE1BQU0sZ0JBQWdCLFFBQVEsS0FBSyxJQUFJLFNBQVMsS0FBSyxDQUFDLEVBQUU7QUFDL0QsYUFBSyxLQUFLLEtBQUssTUFBTSxVQUFVLENBQUMsUUFBTztBQUN0QyxjQUFJLEtBQUs7QUFDUixZQUFBQSxRQUFPLEtBQUssMEJBQTBCLFFBQVEsS0FBSyxJQUFJLE9BQU8sRUFBRTtBQUNoRSxpQkFBSyxJQUFJO1VBQ1Y7UUFDRCxDQUFDO01BQ0YsQ0FBQztJQUNGO0FBRUEsV0FBTSxFQUFHLE1BQU0sQ0FBQyxNQUFLO0FBQ3BCLE1BQUFBLFFBQU8sS0FBSywwQkFBMEIsUUFBUSxLQUFLLENBQUMsRUFBRTtBQUN0RCxXQUFLLElBQUk7SUFDVixDQUFDO0VBQ0YsQ0FBQztBQUNGO0FBZUEsZUFBc0IsWUFDckIsVUFDQSxrQkFDQSxnQkFDQSxrQkFDQSxJQUNBLFlBQVksS0FBSTtBQUVoQixTQUFPLElBQUksUUFBMkIsQ0FBQyxZQUFXO0FBQ2pELFVBQU0sTUFBTSxXQUFXLEVBQUU7QUFDekIsUUFBSSxXQUFXO0FBRWYsVUFBTSxTQUFTLENBQUMsV0FBNkI7QUFDNUMsVUFBSTtBQUFVO0FBQ2QsaUJBQVc7QUFDWCxxQkFBZSxHQUFHO0FBQ2xCLGNBQVEsTUFBTTtJQUNmO0FBRUEscUJBQWlCLEtBQUssQ0FBQyxXQUFzQjtBQUM1QyxVQUFJLE9BQU8sT0FBTztBQUFJLGVBQU8sTUFBTTtJQUNwQyxDQUFDO0FBRUQsVUFBTSxRQUFRLFdBQVcsTUFBTSxPQUFPLElBQUksR0FBRyxTQUFTO0FBQ3RELFVBQU0sUUFBTztBQUViLFVBQU0sTUFBTSxZQUFXO0FBQ3RCLFlBQU0saUJBQWlCLEVBQUU7QUFDekIsWUFBTSxRQUFRLHNCQUFxQjtBQUNuQyxlQUFTLEtBQUssT0FBTyxNQUFNLElBQUksQ0FBQyxRQUFPO0FBQ3RDLFlBQUksS0FBSztBQUNSLFVBQUFBLFFBQU8sS0FBSyxZQUFZLEVBQUUsWUFBWSxJQUFJLE9BQU8sRUFBRTtBQUNuRCx1QkFBYSxLQUFLO0FBQ2xCLGlCQUFPLElBQUk7UUFDWjtNQUNELENBQUM7SUFDRjtBQUVBLFFBQUcsRUFBRyxNQUFNLENBQUMsTUFBSztBQUNqQixNQUFBQSxRQUFPLEtBQUssZ0NBQWdDLEVBQUUsS0FBSyxDQUFDLEVBQUU7QUFDdEQsbUJBQWEsS0FBSztBQUNsQixhQUFPLElBQUk7SUFDWixDQUFDO0VBQ0YsQ0FBQztBQUNGOzs7QUQ1YUEsSUFBTUUsVUFBUyxtQkFBbUIsY0FBYztBQUUxQyxJQUFPLGVBQVAsTUFBTyxjQUFZO0VBQ1AsY0FBc0I7RUFDdEIsaUJBQWlCO0VBQ2pCLFNBQVM7RUFFbEI7RUFDQTs7RUFDQSxjQUdKLG9CQUFJLElBQUc7RUFDSCxtQkFBZ0Msb0JBQUksSUFBRzs7O0VBR3ZDLFlBQTJCLFFBQVEsUUFBTzs7RUFHMUMsc0JBQXNCOztFQUd0Qjs7RUFHQSxRQUFnQjtFQUNoQixVQUFzQixDQUFBOzs7Ozs7O0VBUXRCLGNBQWdELG9CQUFJLElBQUc7Ozs7Ozs7RUFRdkQsZ0JBQTZCLG9CQUFJLElBQUc7O0VBR3BDLHFCQUFnRSxvQkFBSSxJQUFHOztFQUd2RTs7RUFHQSxXQUFrQyxvQkFBSSxJQUFHOztFQUd6QyxxQkFBa0Msb0JBQUksSUFBRzs7RUFHekMsa0JBQTJDLG9CQUFJLElBQUc7RUFFMUQsY0FBQTtBQUNDLElBQUFBLFFBQU8sS0FBSywwQkFBMEI7QUFJdEMsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFDcEUsU0FBSyxVQUFVLElBQUksUUFBYyxDQUFDLFlBQVc7QUFDNUMsV0FBSyxTQUFTLEtBQUssR0FBRyxNQUFLO0FBQzFCLFFBQUFELFFBQU8sTUFBTSwyQkFBNEIsS0FBSyxTQUFTLFFBQU8sRUFBd0IsSUFBSSxFQUFFO0FBQzVGLGdCQUFPO01BQ1IsQ0FBQztJQUNGLENBQUM7QUFDRCxTQUFLLFNBQVMsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNqQyxNQUFBQSxRQUFPLE1BQU0sb0JBQW9CLEdBQUcsRUFBRTtJQUN2QyxDQUFDO0FBR0QsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFFcEUsU0FBSyxTQUFTLEdBQUcsYUFBYSxNQUFLO0FBQ2xDLFlBQU0sT0FBTyxLQUFLLFNBQVMsUUFBTztBQUNsQyxNQUFBRCxRQUFPLE1BQU0sMEJBQTBCLEtBQUssVUFBVSxJQUFJLENBQUMsRUFBRTtBQUM3RCxVQUFJO0FBQ0gsYUFBSyxTQUFTLHFCQUFxQixJQUFJO01BQ3hDLFNBQVMsSUFBSTtNQUViO0lBQ0QsQ0FBQztBQUVELFNBQUssU0FBUyxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ2pDLE1BQUFBLFFBQU8sTUFBTSxvQkFBb0IsR0FBRyxFQUFFO0lBQ3ZDLENBQUM7QUFFRCxTQUFLLFNBQVMsR0FBRyxXQUFXLENBQUMsS0FBSyxVQUFTO0FBQzFDLFVBQUk7QUFDSCxhQUFLLGVBQWUsS0FBSyxNQUFNLE9BQU87TUFDdkMsU0FBUyxJQUFJO0FBQ1osUUFBQUEsUUFBTyxNQUFNLG9DQUFvQyxFQUFFLEVBQUU7TUFDdEQ7SUFDRCxDQUFDO0FBTUQsU0FBSyxTQUFTLEtBQUssRUFBRSxTQUFTLFdBQVcsTUFBTSxLQUFLLE9BQU0sR0FBSSxNQUFLO0FBQ2xFLE1BQUFBLFFBQU8sTUFBTSw4QkFBOEIsS0FBSyxNQUFNLEVBQUU7QUFDeEQsWUFBTSxTQUFTRSxJQUFHLGtCQUFpQjtBQUNuQyxpQkFBVyxTQUFTLE9BQU8sT0FBTyxNQUFNLEdBQUc7QUFDMUMsbUJBQVcsUUFBUSxTQUFTLENBQUEsR0FBSTtBQUMvQixjQUFJLEtBQUssV0FBVyxVQUFVLENBQUMsS0FBSyxZQUFZLENBQUMsS0FBSyxpQkFBaUIsSUFBSSxLQUFLLE9BQU8sR0FBRztBQUN6RixnQkFBSTtBQUNILG1CQUFLLFNBQVMsY0FBYyxLQUFLLGdCQUFnQixLQUFLLE9BQU87QUFDN0QsbUJBQUssaUJBQWlCLElBQUksS0FBSyxPQUFPO0FBQ3RDLGNBQUFGLFFBQU8sS0FBSyx3QkFBd0IsS0FBSyxjQUFjLE9BQU8sS0FBSyxPQUFPLEVBQUU7WUFDN0UsU0FBUyxJQUFJO0FBQ1osY0FBQUEsUUFBTyxLQUFLLG1DQUFtQyxLQUFLLE9BQU8sS0FBSyxPQUFPLEVBQUUsQ0FBQyxFQUFFO1lBQzdFO1VBQ0Q7UUFDRDtNQUNEO0lBQ0QsQ0FBQztFQUNGO0VBRU8sUUFBSztBQUVYLGVBQVcsV0FBVyxLQUFLLGdCQUFnQixPQUFNLEdBQUk7QUFDcEQsVUFBSTtBQUNILGdCQUFPO01BQ1IsUUFBUTtNQUVSO0lBQ0Q7QUFDQSxTQUFLLGdCQUFnQixNQUFLO0FBQzFCLFFBQUk7QUFDSCxpQkFBVyxhQUFhLE1BQU0sS0FBSyxLQUFLLGdCQUFnQixHQUFHO0FBQzFELFlBQUk7QUFDSCxlQUFLLFNBQVMsZUFBZSxLQUFLLGdCQUFnQixTQUFTO1FBQzVELFFBQVE7UUFFUjtNQUNEO0lBQ0QsUUFBUTtJQUVSO0FBQ0EsUUFBSTtBQUNILFdBQUssU0FBUyxNQUFLO0lBQ3BCLFFBQVE7SUFFUjtBQUNBLFFBQUk7QUFDSCxXQUFLLFNBQVMsTUFBSztJQUNwQixRQUFRO0lBRVI7RUFDRDs7Ozs7RUFNTyxTQUFTLE9BQWUsU0FBbUI7QUFDakQsU0FBSyxRQUFRO0FBQ2IsU0FBSyxVQUFVO0VBQ2hCOzs7OztFQU1PLG9CQUFvQixVQUFzQztBQUNoRSxTQUFLLG1CQUFtQjtFQUN6Qjs7RUFHTyxtQkFBbUIsSUFBVTtBQUNuQyxXQUFPLEtBQUssY0FBYyxJQUFJLEVBQUU7RUFDakM7O0VBR08sZ0JBQWdCLElBQVU7QUFDaEMsU0FBSyxjQUFjLElBQUksRUFBRTtBQUN6QixJQUFBQSxRQUFPLE1BQU0sd0JBQXdCLEVBQUUsRUFBRTtFQUMxQzs7RUFHTyxhQUFhLElBQVU7QUFDN0IsU0FBSyxjQUFjLE9BQU8sRUFBRTtBQUM1QixTQUFLLFlBQVksT0FBTyxFQUFFO0FBQzFCLFNBQUssU0FBUyxPQUFPLEVBQUU7QUFDdkIsU0FBSyxtQkFBbUIsT0FBTyxFQUFFO0FBQ2pDLFNBQUssZ0JBQWdCLElBQUksRUFBRSxJQUFHO0FBQzlCLFNBQUssZ0JBQWdCLE9BQU8sRUFBRTtBQUM5QixJQUFBQSxRQUFPLE1BQU0scUJBQXFCLEVBQUUsRUFBRTtFQUN2Qzs7Ozs7RUFNTyxNQUFNLFlBQVksVUFBZ0I7QUFDeEMsUUFBSSxLQUFLLG1CQUFtQixJQUFJLFFBQVE7QUFBRyxhQUFPO0FBQ2xELFVBQU0sVUFBVSxNQUFNLGtCQUFrQixRQUFRO0FBQ2hELFVBQU0sVUFBVSxZQUFZO0FBRzVCLFNBQUssbUJBQW1CLElBQUksUUFBUTtBQUNwQyxRQUFJLFNBQVM7QUFDWixXQUFLLGdCQUFnQixJQUFJLFVBQVUsT0FBTztJQUMzQztBQUNBLFdBQU87RUFDUjs7Ozs7OztFQVFPLE1BQU0sWUFBWSxJQUFZLFlBQVksS0FBSTtBQUNwRCxVQUFNLEtBQUs7QUFDWCxXQUFPLFlBQ04sS0FBSyxVQUNMLENBQUMsS0FBSyxPQUFPLEtBQUssbUJBQW1CLElBQUksS0FBSyxFQUFFLEdBQ2hELENBQUMsUUFBUSxLQUFLLG1CQUFtQixPQUFPLEdBQUcsR0FDM0MsT0FBTyxXQUFXLEtBQUssb0JBQW9CLE1BQU0sR0FDakQsSUFDQSxTQUFTO0VBRVg7Ozs7O0VBTU8sTUFBTSxtQkFBbUIsVUFBZ0I7QUFDL0MsSUFBQUEsUUFBTyxLQUFLLGdDQUFnQyxRQUFRLEVBQUU7QUFDdEQsVUFBTSxXQUFXLE1BQU0sS0FBSyxhQUFhLHNCQUFzQixRQUFXLFFBQVcsUUFBVyxVQUFVLEtBQUs7QUFFL0csV0FBTztFQUNSOzs7Ozs7O0VBUU8sTUFBTSxnQkFBZ0IsWUFBWSxLQUFJO0FBQzVDLFVBQU0sZ0JBQWdCO0FBQ3RCLFVBQU0sZUFBNkIsQ0FBQTtBQUVuQyxTQUFLLG1CQUFtQixJQUFJLGVBQWUsQ0FBQyxXQUFzQjtBQUNqRSxVQUFJLENBQUMsYUFBYSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTyxFQUFFLEdBQUc7QUFDbEQscUJBQWEsS0FBSyxNQUFNO01BQ3pCO0lBQ0QsQ0FBQztBQUVELFFBQUk7QUFDSCxZQUFNLEtBQUs7QUFDWCxZQUFNLGdCQUFnQixLQUFLLFVBQVUsT0FBTyxXQUFXLEtBQUssb0JBQW9CLE1BQU0sR0FBRyxTQUFTO0FBQ2xHLGFBQU87SUFDUjtBQUNDLFdBQUssbUJBQW1CLE9BQU8sYUFBYTtJQUM3QztFQUNEOzs7OztFQU1PLE1BQU0sdUJBQXVCLFVBQWdCO0FBQ25ELElBQUFBLFFBQU8sS0FBSyxvQ0FBb0MsUUFBUSxFQUFFO0FBQzFELFVBQU0sV0FBVyxNQUFNLEtBQUssYUFBYSxrQkFBa0IsUUFBVyxRQUFXLFFBQVcsVUFBVSxLQUFLO0FBSTNHLFVBQU0sWUFBWTtBQUVsQixRQUFJLFNBQVMsU0FBUyxZQUFZLEdBQUc7QUFDcEMsTUFBQUEsUUFBTyxLQUFLLGdDQUFnQyxTQUFTLE1BQU0sUUFBUTtBQUNuRSxhQUFPO0lBQ1I7QUFHQSxVQUFNLFFBQVEsU0FBUyxZQUFZLENBQUM7QUFDcEMsVUFBTSxRQUFRLFNBQVMsWUFBWSxDQUFDO0FBRXBDLFVBQU0sV0FDTCxRQUFRLEtBQ0wsTUFBTSxTQUFRLEVBQUcsU0FBUyxHQUFHLEdBQUcsSUFDaEMsTUFBTSxTQUFRO0FBRWxCLFVBQU0sV0FBVyxHQUFHLEtBQUssSUFBSSxRQUFRO0FBRXJDLElBQUFBLFFBQU8sS0FBSyxxQkFBcUIsUUFBUSxFQUFFO0FBQzNDLFdBQU87RUFDUjs7Ozs7RUFNUSxNQUFNLG9CQUFvQixRQUFjO0FBQy9DLFFBQUk7QUFDSCxZQUFNLFlBQVksTUFBTSw4QkFBOEIsTUFBTTtBQUM1RCxVQUFJLENBQUMsV0FBVztBQUNmLFFBQUFBLFFBQU8sS0FBSyxxREFBcUQsTUFBTSxFQUFFO0FBQ3pFO01BQ0Q7QUFFQSxVQUFJLEtBQUssaUJBQWlCLElBQUksU0FBUyxHQUFHO0FBRXpDO01BQ0Q7QUFFQSxVQUFJO0FBQ0gsYUFBSyxTQUFTLGNBQWMsS0FBSyxnQkFBZ0IsU0FBUztBQUMxRCxhQUFLLGlCQUFpQixJQUFJLFNBQVM7QUFDbkMsUUFBQUEsUUFBTyxLQUFLLG9CQUFvQixLQUFLLGNBQWMsT0FBTyxTQUFTLEVBQUU7TUFDdEUsU0FBUyxJQUFJO0FBQ1osUUFBQUEsUUFBTyxLQUFLLCtCQUErQixTQUFTLEtBQUssT0FBTyxFQUFFLENBQUMsRUFBRTtNQUN0RTtJQUNELFNBQVMsSUFBSTtBQUNaLE1BQUFBLFFBQU8sS0FBSywrQkFBK0IsRUFBRSxFQUFFO0lBQ2hEO0VBQ0Q7RUFFTyxNQUFNLGFBQ1osT0FDQSxPQUNBLFdBQ0EsT0FDQSxRQUNBLFNBQVMsTUFBSTtBQUViLFNBQUs7QUFDTCxXQUFPLElBQUksUUFBZ0IsQ0FBQyxTQUFTLFdBQVU7QUFDOUMsV0FBSyxZQUFZLEtBQUssVUFBVSxLQUFLLFlBQ3BDLEtBQUssY0FBYyxPQUFPLE9BQU8sV0FBVyxPQUFPLFFBQVEsTUFBTSxFQUMvRCxLQUFLLENBQUMsUUFBTztBQUNiLGFBQUs7QUFHTCxZQUFJLEtBQUssd0JBQXdCLEtBQUssVUFBVSxRQUFXO0FBQzFELGVBQUssbUJBQW1CLE1BQU0sRUFBRSxNQUFNLENBQUMsUUFBTztBQUM3QyxZQUFBQSxRQUFPLEtBQUssNkNBQTZDLEdBQUcsRUFBRTtVQUMvRCxDQUFDO1FBQ0Y7QUFDQSxnQkFBUSxHQUFHO01BQ1osQ0FBQyxFQUNBLE1BQU0sQ0FBQyxRQUFPO0FBQ2QsYUFBSztBQUNMLGVBQU8sZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUM7TUFDM0QsQ0FBQyxDQUFDO0lBRUwsQ0FBQztFQUNGO0VBRVEsTUFBTSxjQUNiLE9BQ0EsT0FDQSxXQUNBLE9BQ0EsUUFDQSxTQUFTLE1BQUk7QUFFYixVQUFNLFlBQVk7QUFFbEIsVUFBTSxZQUFzQixDQUFBO0FBQzVCLFFBQUksY0FBYztBQUFXLGdCQUFVLEtBQUssWUFBWSxHQUFJO0FBQzVELFFBQUksVUFBVTtBQUFXLGdCQUFVLEtBQUssR0FBRyxjQUFhLGdCQUFnQixLQUFLLENBQUM7QUFFOUUsVUFBTSxjQUF3QixDQUFDLElBQU0sUUFBUSxHQUFJO0FBRWpELFFBQUksVUFBVSxlQUFlLFVBQVUsVUFBYSxjQUFjLFVBQWEsVUFBVSxRQUFXO0FBSW5HLFVBQUksQ0FBQyxLQUFLLFlBQVksSUFBSSxNQUFNO0FBQUcsYUFBSyxZQUFZLElBQUksUUFBUSxvQkFBSSxJQUFHLENBQUU7QUFDekUsWUFBTSxVQUFVLEtBQUssWUFBWSxJQUFJLE1BQU07QUFDM0MsWUFBTSxlQUFlO0FBQ3JCLFlBQU0sWUFBc0IsQ0FBQTtBQUM1QixlQUFTLElBQUksR0FBRyxJQUFJLGNBQWMsS0FBSztBQUN0QyxjQUFNLFdBQVcsY0FBYyxLQUFLLE9BQU8sYUFBYSxHQUFHLEtBQUs7QUFDaEUsY0FBTSxNQUFNLE1BQU0sWUFBWSxPQUFPLEtBQUssSUFBSyxRQUFRLElBQUksUUFBUSxLQUFLO0FBQ3hFLGtCQUFVLEtBQUssR0FBRztBQUNsQixnQkFBUSxJQUFJLFVBQVUsR0FBRztNQUMxQjtBQUNBLGtCQUFZLEtBQUssUUFBUSxLQUFNLEdBQUcsU0FBUztJQUM1QyxPQUFPO0FBQ04sVUFBSSxVQUFVO0FBQVcsb0JBQVksS0FBSyxRQUFRLEdBQUk7QUFDdEQsVUFBSTtBQUFRLG9CQUFZLEtBQUssVUFBVSxNQUFNO0FBQzdDLFVBQUksVUFBVSxTQUFTO0FBQUcsb0JBQVksS0FBSyxHQUFHLFNBQVM7SUFDeEQ7QUFFQSxVQUFNLE1BQU0sY0FBYSxVQUFVLFdBQVc7QUFDOUMsVUFBTSxpQkFBaUIsT0FBTyxLQUFLLENBQUMsR0FBRyxhQUFhLEdBQUcsQ0FBQztBQUd4RCxRQUFJLGNBQWMsVUFBYSxVQUFVLFFBQVc7QUFDbkQsWUFBTSxhQUFhLGNBQWEsZ0JBQWdCLEtBQUs7QUFDckQsWUFBTSxVQUF5QjtRQUM5QixRQUFRO1FBQ1IsSUFBSTtRQUNKO1FBQ0E7O0FBRUQsTUFBQUEsUUFBTyxLQUFLLE1BQU0sTUFBTSxNQUFNLG9CQUFvQixTQUFTLEtBQUssT0FBTyxDQUFDLEVBQUU7SUFDM0UsT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSyxNQUFNLE1BQU0sTUFBTSxlQUFlLEtBQUssQ0FBQyxFQUFFO0lBQ3REO0FBSUEsUUFBSSxDQUFDLEtBQUssY0FBYyxJQUFJLE1BQU0sR0FBRztBQUNwQyxNQUFBQSxRQUFPLE1BQU0scURBQWdELE1BQU0sS0FBSyxlQUFlLFNBQVMsS0FBSyxDQUFDLEVBQUU7QUFDeEcsWUFBTSxJQUFJLE1BQU0sYUFBYSxNQUFNLGlGQUE0RTtJQUNoSDtBQUlBLFFBQUksQ0FBQyxLQUFLLG1CQUFtQixJQUFJLE1BQU0sR0FBRztBQUN6QyxZQUFNLEtBQUssWUFBWSxNQUFNO0lBRTlCO0FBR0EsVUFBTSxLQUFLLG9CQUFvQixNQUFNO0FBRXJDLFVBQU0sV0FBVyxLQUFLLGVBQWU7QUFDckMsVUFBTSxTQUFTLE1BQU0sS0FBSyxZQUFZLFVBQVUsTUFBTTtBQUN0RCxVQUFNLFNBQVMsT0FBTyxPQUFPLENBQUMsUUFBUSxjQUFjLENBQUM7QUFFckQsSUFBQUEsUUFBTyxNQUFNLHFCQUFxQixNQUFNLEtBQUssT0FBTyxTQUFTLEtBQUssQ0FBQyxFQUFFO0FBRXJFLFVBQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxLQUFLO0FBRTlCLFdBQU8sSUFBSSxRQUFnQixDQUFDLFNBQVMsV0FBVTtBQUM5QyxZQUFNLFFBQVEsV0FBVyxNQUFLO0FBQzdCLGFBQUssWUFBWSxPQUFPLEdBQUc7QUFDM0IsZUFBTyxJQUFJLE1BQU0sc0NBQXNDLEtBQUssS0FBSyxPQUFPLE1BQU0sT0FBTyxDQUFDO01BQ3ZGLEdBQUcsU0FBUztBQUVaLFdBQUssWUFBWSxJQUFJLEtBQUs7UUFDekIsU0FBUyxDQUFDLFFBQU87QUFDaEIsdUJBQWEsS0FBSztBQUNsQixrQkFBUSxHQUFHO1FBQ1o7UUFDQSxRQUFRLENBQUMsUUFBTztBQUNmLHVCQUFhLEtBQUs7QUFDbEIsaUJBQU8sR0FBRztRQUNYO1FBQ0E7T0FDQTtBQUVELFdBQUssU0FBUyxLQUFLLFFBQVEsS0FBSyxhQUFhLFFBQVEsQ0FBQyxRQUFPO0FBQzVELFlBQUksS0FBSztBQUNSLGVBQUssWUFBWSxPQUFPLEdBQUc7QUFDM0IsdUJBQWEsS0FBSztBQUNsQixpQkFBTyxJQUFJLE1BQU0sSUFBSSxXQUFXLE9BQU8sR0FBRyxDQUFDLENBQUM7UUFDN0M7TUFDRCxDQUFDO0lBQ0YsQ0FBQztFQUNGO0VBRVEsZUFBZSxLQUFhLE9BQWE7QUFDaEQsUUFBSSxJQUFJLFNBQVM7QUFBRztBQUNwQixRQUFJLElBQUksQ0FBQyxNQUFNLE9BQVEsSUFBSSxDQUFDLE1BQU07QUFBTTtBQUV4QyxVQUFNLFVBQVUsSUFBSSxhQUFhLENBQUM7QUFLbEMsUUFBSSxZQUFZLDJCQUEyQixLQUFLLG1CQUFtQixPQUFPLEdBQUc7QUFDNUUsWUFBTSxTQUFTLHVCQUF1QixLQUFLLEtBQUs7QUFDaEQsVUFBSSxRQUFRO0FBQ1gsUUFBQUEsUUFBTyxNQUNOLDRCQUE0QixLQUFLLGVBQ25CLE9BQU8sSUFBSSxhQUNkLE9BQU8sS0FBSyxpQkFDUixPQUFPLFNBQVMsb0JBQ2IsT0FBTyxZQUFZLEdBQUc7QUFJekMsWUFBSSxPQUFPLFNBQVMsWUFBWTtBQUMvQixxQkFBVyxNQUFNLEtBQUssbUJBQW1CLE9BQU0sR0FBSTtBQUNsRCxnQkFBSTtBQUNILGlCQUFHLE1BQU07WUFDVixRQUFRO1lBRVI7VUFDRDtRQUNELE9BQU87QUFDTixVQUFBQSxRQUFPLE1BQU0sc0RBQXNELE9BQU8sSUFBSSxPQUFPLEtBQUssRUFBRTtRQUM3RjtNQUNEO0FBQ0E7SUFDRDtBQUVBLFFBQUksSUFBSSxTQUFTO0FBQUk7QUFHckIsVUFBTSxNQUFNLElBQUksU0FBUyxJQUFJLEVBQUU7QUFDL0IsUUFBSSxJQUFJLFNBQVMsT0FBTyxNQUFNO0FBQVk7QUFNMUMsUUFBSSxDQUFDLEtBQUssY0FBYyxJQUFJLEtBQUssR0FBRztBQUNuQyxNQUFBQSxRQUFPLE1BQU0scURBQXFELEtBQUssRUFBRTtBQUN6RTtJQUNEO0FBSUEsVUFBTSxZQUFZLElBQUksU0FBUyxFQUFFO0FBQ2pDLFFBQUksVUFBVSxTQUFTO0FBQUc7QUFDMUIsUUFBSSxVQUFVLENBQUMsTUFBTTtBQUFNO0FBRzNCLFVBQU0sWUFBWSxVQUFVLENBQUM7QUFDN0IsVUFBTSxjQUFjLFlBQVksU0FBVTtBQUMxQyxVQUFNLGdCQUFnQixZQUFZO0FBR2xDLFFBQUksY0FBYyxrQkFBa0Isc0JBQXNCO0FBQ3pELE1BQUFBLFFBQU8sTUFBTSx3QkFBd0IsS0FBSyxLQUFLLElBQUksU0FBUyxLQUFLLENBQUMsRUFBRTtJQUNyRTtBQUdBLFNBQUssYUFBYSxPQUFPLGVBQWUsS0FBSyxTQUFTO0FBR3RELFFBQUksWUFBWTtBQUNmLFlBQU0sTUFBTSxHQUFHLEtBQUssSUFBSSxhQUFhO0FBQ3JDLFlBQU0sVUFBVSxLQUFLLFlBQVksSUFBSSxHQUFHO0FBQ3hDLFVBQUksU0FBUztBQUNaLGFBQUssWUFBWSxPQUFPLEdBQUc7QUFDM0IsZ0JBQVEsUUFBUSxHQUFHO01BQ3BCO0lBQ0Q7RUFFRDs7Ozs7Ozs7Ozs7O0VBYVEsYUFBYSxPQUFlLE9BQWUsS0FBYSxXQUFpQjtBQUNoRixVQUFNLFVBQVUsZUFBZSxLQUFLO0FBQ3BDLFVBQU0sT0FBTyxVQUFVLFNBQVMsR0FBRyxVQUFVLFNBQVMsQ0FBQztBQUd2RCxVQUFNLFlBQVksVUFBVSxDQUFDO0FBQzdCLFVBQU0sTUFBTSxVQUFVLFVBQVUsU0FBUyxDQUFDO0FBQzFDLFVBQU0sZ0JBQWdCLFFBQVEsTUFBTSxTQUFTLENBQUMsU0FBUyxLQUFLLFNBQVMsS0FBSyxDQUFDLFFBQVEsTUFBTSxHQUFHLENBQUM7QUFLN0YsUUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFJLENBQUMsS0FBSyxPQUFPO0FBQ2hCLFFBQUFBLFFBQU8sS0FBSyxNQUFNLEtBQUssTUFBTSxPQUFPLE1BQU0sYUFBYSxFQUFFO0FBQ3pEO01BQ0Q7QUFDQSxVQUFJO0FBQ0gsY0FBTSxXQUNMLFVBQVUsb0JBQ1Asc0JBQXNCLEtBQUssT0FBTyxHQUFHLElBQ3JDLDRCQUE0QixLQUFLLE9BQU8sR0FBRztBQUUvQyxjQUFNLFlBQVksS0FBSyxZQUFZLElBQUksS0FBSyxLQUFLLG9CQUFJLElBQUc7QUFDeEQsY0FBTSxXQUFXLElBQUksSUFBb0IsU0FBUztBQUVsRCxtQkFBVyxLQUFLLFVBQVU7QUFDekIsZ0JBQU0sV0FBVyxjQUFjLEtBQUssT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSztBQUVsRSxnQkFBTSxXQUNMLEVBQUUsV0FBVyxXQUFXLElBQ3BCLEVBQUUsV0FBVyxDQUFDLEtBQUssS0FBTyxFQUFFLFdBQVcsQ0FBQyxLQUFLLElBQUssRUFBRSxXQUFXLENBQUMsSUFDaEUsRUFBRSxXQUFXLENBQUMsS0FBSztBQUN4QixnQkFBTSxZQUFZLFVBQVUsSUFBSSxRQUFRO0FBQ3hDLGdCQUFNLFVBQVUsY0FBYyxVQUFhLGNBQWM7QUFFekQsbUJBQVMsSUFBSSxVQUFVLFFBQVE7QUFFL0IsZ0JBQU0sWUFBWSxvQkFBb0IsR0FBRyxLQUFLLE9BQU87QUFDckQsY0FBSSxTQUFTO0FBQ1osWUFBQUEsUUFBTyxLQUFLLE1BQU0sS0FBSyxNQUFNLFNBQVMsRUFBRTtBQUV4QyxnQkFBSSxLQUFLLGtCQUFrQjtBQUMxQixrQkFBSSxTQUFTLEVBQUU7QUFDZixvQkFBTSxhQUFhLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBSztBQUMxQyxvQkFBSSxFQUFFLFdBQVcsRUFBRTtBQUFRLHlCQUFPO0FBQ2xDLG9CQUFJLEVBQUUsT0FBTyxFQUFFO0FBQUkseUJBQU87QUFDMUIsc0JBQU0sY0FBYyxFQUFFLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDM0Qsb0JBQUksQ0FBQyxhQUFhO0FBQVMseUJBQU87QUFDbEMsc0JBQU0sU0FBUyxFQUFFLEtBQUssRUFBRTtBQUN4Qix1QkFBTyxTQUFTLEtBQUssWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxNQUFNO2NBQ3JFLENBQUM7QUFDRCxrQkFBSTtBQUFZLHlCQUFTLFdBQVc7QUFDcEMsb0JBQU0sa0JBQWtCLGNBQWMsS0FBSyxPQUFPLEVBQUUsUUFBUSxNQUFNO0FBQ2xFLG1CQUFLLGlCQUFpQixlQUFlO0FBQ3JDLG1CQUFLLGlCQUFpQixrQkFBa0IsT0FBTztZQUNoRCxPQUFPO0FBQ04sY0FBQUEsUUFBTyxLQUFLLGdFQUEyRCxRQUFRLEVBQUU7WUFDbEY7VUFDRCxPQUFPO0FBQ04sWUFBQUEsUUFBTyxNQUFNLE1BQU0sS0FBSyxNQUFNLFNBQVMsRUFBRTtVQUMxQztRQUNEO0FBQ0EsYUFBSyxZQUFZLElBQUksT0FBTyxRQUFRO01BQ3JDLFNBQVMsR0FBRztBQUNYLFFBQUFBLFFBQU8sS0FBSyxNQUFNLEtBQUssTUFBTSxPQUFPLG9CQUFvQixDQUFDLE1BQU0sYUFBYSxFQUFFO01BQy9FO0FBQ0E7SUFDRDtBQUdBLFVBQU0sVUFBVSxLQUFLLGFBQWEsT0FBTyxJQUFJO0FBRTdDLFVBQU0sUUFBUSxVQUFVLGNBQWNBLFFBQU8sTUFBTSxLQUFLQSxPQUFNLElBQUlBLFFBQU8sS0FBSyxLQUFLQSxPQUFNO0FBQ3pGLFFBQUksU0FBUztBQUNaLFlBQU0sTUFBTSxLQUFLLE1BQU0sT0FBTyxNQUFNLGFBQWEsTUFBTSxPQUFPLEVBQUU7SUFDakUsT0FBTztBQUNOLFlBQU0sTUFBTSxLQUFLLE1BQU0sT0FBTyxNQUFNLGFBQWEsRUFBRTtJQUNwRDtFQUNEOzs7OztFQU1RLGFBQWEsT0FBZSxNQUFZO0FBQy9DLFFBQUksS0FBSyxXQUFXO0FBQUcsYUFBTztBQUc5QixRQUFJLEtBQUssV0FBVyxHQUFHO0FBQ3RCLFVBQUksS0FBSyxDQUFDLE1BQU0sR0FBTTtBQUNyQixlQUFPO01BQ1IsT0FBTztBQUNOLGVBQU8sU0FBUyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7TUFDL0I7SUFDRDtBQUVBLFlBQVEsT0FBTzs7O01BR2QsS0FBSyxhQUFhO0FBQ2pCLGNBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsY0FBTSxPQUFPLE1BQU0sS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDLEVBQ3RDLElBQUksQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQ2pFLEtBQUssR0FBRztBQUNWLGVBQU8sTUFBTSxLQUFLLElBQUksSUFBSTtNQUMzQjs7Ozs7TUFNQSxLQUFLLGNBQWM7QUFDbEIsWUFBSSxLQUFLLFdBQVcsR0FBRztBQUN0QixpQkFBTyxLQUFLLENBQUMsTUFBTSxJQUFPLFdBQVcsV0FBVyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDL0Q7QUFDQSxZQUFJLEtBQUssVUFBVSxHQUFHO0FBQ3JCLGdCQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGdCQUFNLFlBQVksS0FBSyxDQUFDO0FBQ3hCLGdCQUFNLGFBQWEsS0FBSyxTQUFTLENBQUM7QUFDbEMsZ0JBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFDaEYsZ0JBQU0sY0FBYyxRQUFRLFFBQVEsV0FBVyxNQUFNLFNBQVMsQ0FBQztBQUMvRCxnQkFBTSxVQUFVLFFBQVEsVUFBVSxDQUFDLEdBQUc7QUFDdEMsZ0JBQU0sV0FBVyxXQUFXLFdBQVcsSUFBSSxXQUFXLENBQUMsSUFBSTtBQUMzRCxnQkFBTSxjQUNMLFdBQVcsYUFBYSxTQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO0FBQ3JGLGdCQUFNLFdBQVcsY0FBYyxHQUFHLFdBQVcsS0FBSyxNQUFNLFFBQVMsQ0FBQyxNQUFNLFdBQVcsTUFBTSxLQUFLLFVBQVUsQ0FBQztBQUN6RyxnQkFBTSxTQUFTLElBQUksTUFBTSxLQUFLLENBQUMsSUFBSSxNQUFNLFNBQVMsQ0FBQyxLQUFLLFdBQVcsTUFBTSxLQUFLLFVBQVUsQ0FBQyxDQUFDO0FBQzFGLGlCQUFPLFdBQVcsS0FBSyxNQUFNLFdBQVcsS0FBSyxRQUFRLElBQUksTUFBTTtRQUNoRTtBQUNBLGVBQU8sUUFBUSxLQUFLLFNBQVMsS0FBSyxDQUFDO01BQ3BDOztNQUdBLEtBQUssaUJBQWlCO0FBRXJCLFlBQUksS0FBSyxVQUFVLEdBQUc7QUFDckIsZ0JBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsZ0JBQU0sWUFBWSxLQUFLLENBQUM7QUFDeEIsZ0JBQU0sYUFBYSxLQUFLLFNBQVMsQ0FBQztBQUNsQyxnQkFBTSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUNoRixnQkFBTSxjQUFjLFFBQVEsUUFBUSxXQUFXLE1BQU0sU0FBUyxDQUFDO0FBQy9ELGdCQUFNLFdBQVcsV0FBVyxXQUFXLElBQUksV0FBVyxDQUFDLElBQUk7QUFDM0QsZ0JBQU0sVUFBVSxRQUFRLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU8sR0FBRztBQUNoRSxnQkFBTSxjQUNMLFdBQVcsYUFBYSxTQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO0FBQ3JGLGdCQUFNLFdBQVcsZUFBZSxLQUFLLFdBQVcsU0FBUyxLQUFLLENBQUM7QUFDL0QsaUJBQU8sV0FBVyxLQUFLLE1BQU0sV0FBVyxLQUFLLFFBQVE7UUFDdEQ7QUFDQSxlQUFPO01BQ1I7O01BR0EsS0FBSztNQUNMLEtBQUssYUFBYTtBQUNqQixZQUFJLEtBQUssU0FBUztBQUFHLGlCQUFPO0FBQzVCLGNBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsY0FBTSxZQUFZLEtBQUssQ0FBQztBQUN4QixjQUFNLFFBQVEsS0FBSyxTQUFTLENBQUM7QUFDN0IsZUFBTyxNQUFNLEtBQUssWUFBWSxNQUFNLFNBQVMsQ0FBQyxVQUFVLE1BQU0sU0FBUyxLQUFLLENBQUM7TUFDOUU7TUFFQTtBQUNDLGVBQU87SUFDVDtFQUNEO0VBRVEsT0FBTyxnQkFBZ0IsT0FBYztBQUM1QyxRQUFJLE9BQU8sVUFBVTtBQUFXLGFBQU8sQ0FBQyxRQUFRLElBQUksQ0FBQztBQUNyRCxRQUFJLE1BQU0sUUFBUSxLQUFLO0FBQUcsYUFBTyxNQUFNLElBQUksQ0FBQyxNQUFNLE9BQU8sQ0FBQyxJQUFJLEdBQUk7QUFDbEUsUUFBSSxPQUFPLFVBQVUsVUFBVTtBQUM5QixVQUFJLFFBQVE7QUFBTSxlQUFPLENBQUUsU0FBUyxLQUFNLEtBQU8sU0FBUyxJQUFLLEtBQU0sUUFBUSxHQUFJO0FBQ2pGLGFBQU8sQ0FBQyxRQUFRLEdBQUk7SUFDckI7QUFDQSxVQUFNLElBQUksTUFBTSw0Q0FBNEMsS0FBSyxFQUFFO0VBQ3BFO0VBRVEsTUFBTSxZQUFZLFVBQWtCLFFBQWM7QUFDekQsUUFBSSxNQUFNLEtBQUssU0FBUyxJQUFJLE1BQU07QUFDbEMsUUFBSSxDQUFDLEtBQUs7QUFDVCxZQUFNLE1BQU0scUJBQXFCLE1BQU07QUFDdkMsV0FBSyxTQUFTLElBQUksUUFBUSxHQUFHO0lBQzlCO0FBRUEsV0FBTyxPQUFPLE9BQU87TUFDcEIsT0FBTyxLQUFLLENBQUMsS0FBTSxLQUFNLEdBQU0sV0FBVyxLQUFNLEdBQU0sS0FBTSxHQUFNLEdBQU0sR0FBRyxLQUFLLEdBQU0sQ0FBSSxDQUFDO01BQzNGLE9BQU8sS0FBSyxZQUFZLE1BQU07S0FDOUI7RUFDRjtFQUVRLE9BQU8sVUFBVSxNQUFjO0FBQ3RDLFFBQUksTUFBTTtBQUNWLGVBQVcsS0FBSyxNQUFNO0FBQ3JCLGFBQU87QUFDUCxlQUFTLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztBQUMzQixlQUFPLE1BQU0sU0FBVSxLQUFNLE9BQU8sSUFBSyxPQUFRLE1BQVEsT0FBTyxJQUFLO01BQ3RFO0lBQ0Q7QUFDQSxXQUFPO0VBQ1I7Ozs7Ozs7Ozs7RUFXTyxnQkFBZ0IsSUFBWSxPQUFlLFdBQW1CLE9BQWM7QUFDbEYsVUFBTSxNQUFNLGNBQWMsS0FBSyxPQUFPLE9BQU8sV0FBVyxLQUFLO0FBQzdELFdBQU8sS0FBSyxZQUFZLElBQUksRUFBRSxHQUFHLElBQUksR0FBRztFQUN6QztFQUVPLE1BQU0sWUFBWSxRQUFjO0FBQ3RDLFdBQU8sS0FBSyxhQUFhLGtCQUFrQixRQUFXLEdBQU0sUUFBVyxRQUFRLEtBQUs7RUFDckY7RUFFTyxNQUFNLGNBQWMsUUFBYztBQUN4QyxXQUFPLEtBQUssYUFBYSxxQkFBcUIsUUFBVyxRQUFXLFFBQVcsUUFBUSxLQUFLO0VBQzdGOzs7O0FFanlCRCxJQUFNRyxVQUFTLG1CQUFtQixnQkFBZ0I7QUFNbEQsSUFBcUIsaUJBQXJCLGNBQTRDLGFBQXlCO0VBQ3BFOztFQUNBOzs7RUFJUSxvQkFBa0MsQ0FBQTs7O0VBSTFDLGNBQXNCO0VBRXRCLFlBQVksVUFBaUI7QUFDNUIsVUFBTSxRQUFRO0VBQ2Y7RUFFQSxNQUFNLEtBQUssUUFBb0I7QUFDOUIsU0FBSyxTQUFTO0FBQ2QsUUFBSSxDQUFDLEtBQUssY0FBYztBQUN2QixXQUFLLGVBQWUsSUFBSSxhQUFZO0lBQ3JDO0FBQ0EsU0FBSyxhQUFhLGVBQWUsWUFBWSx3QkFBd0I7QUFHckUsU0FBSyxhQUFhLG9CQUFvQixDQUFDLGVBQXNCO0FBQzVELFdBQUssZUFBZSxVQUFVO0lBQy9CLENBQUM7QUFJRCxTQUFLLGFBQVksRUFBRyxNQUFNLENBQUMsTUFBSztBQUMvQixNQUFBQSxRQUFPLE1BQU0scUJBQXFCLENBQUMsRUFBRTtJQUN0QyxDQUFDO0VBQ0Y7Ozs7Ozs7RUFRUSxNQUFNLGVBQVk7QUFDekIsSUFBQUEsUUFBTyxLQUFLLDhCQUE4QjtBQUUxQyxTQUFLLG9CQUFvQixNQUFNLEtBQUssYUFBYSxnQkFBZTtBQUdoRSxRQUFJO0FBQ0osUUFBSSxLQUFLLGtCQUFrQixXQUFXLEdBQUc7QUFFeEMsVUFBSSxLQUFLLE9BQU8sV0FBVztBQUMxQixjQUFNLGFBQWEsS0FBSyxPQUFPLGNBQWMsU0FBUyxLQUFLLE9BQU8sV0FBVyxNQUFNO0FBQ25GLFFBQUFBLFFBQU8sS0FBSyxxQkFBcUIsS0FBSyxPQUFPLFNBQVMsOENBQXlDO0FBQy9GLGFBQUssYUFBYSxlQUFlLG1CQUFtQixHQUFHLFVBQVUsSUFBSSxLQUFLLE9BQU8sU0FBUyxhQUFhO0FBQ3ZHO01BQ0Q7QUFDQSxZQUFNLGNBQWMsS0FBSyxPQUFPO0FBQ2hDLFVBQUksQ0FBQyxLQUFLLE9BQU8sUUFBUSxDQUFDLGFBQWE7QUFDdEMsUUFBQUEsUUFBTyxLQUFLLHlEQUF5RDtBQUNyRTtNQUNEO0FBQ0EsTUFBQUEsUUFBTyxLQUFLLHdFQUFtRTtBQUMvRSx1QkFBaUI7SUFDbEIsT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSyxjQUFjLEtBQUssa0JBQWtCLE1BQU0sYUFBYTtBQUNwRSxpQkFBVyxLQUFLLEtBQUssbUJBQW1CO0FBQ3ZDLFFBQUFBLFFBQU8sS0FBSyxhQUFhLEVBQUUsS0FBSyxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRTtNQUNyRTtBQUtBLGlCQUFXLFVBQVUsS0FBSyxtQkFBbUI7QUFDNUMsYUFBSyxhQUFhLGdCQUFnQixPQUFPLEVBQUU7TUFDNUM7QUFHQSxpQkFBVyxVQUFVLEtBQUssbUJBQW1CO0FBQzVDLFlBQUk7QUFDSCxnQkFBTSxXQUFXLE1BQU0sS0FBSyxhQUFhLHVCQUF1QixPQUFPLEVBQUU7QUFDekUsaUJBQU8sZUFBZTtBQUN0QixVQUFBQSxRQUFPLEtBQUssT0FBTyxPQUFPLEVBQUUsY0FBYyxRQUFRLFdBQVcsT0FBTyxhQUFhLEVBQUU7UUFDcEYsU0FBUyxHQUFHO0FBQ1gsVUFBQUEsUUFBTyxLQUFLLE9BQU8sT0FBTyxFQUFFLDZCQUE2QixDQUFDLEVBQUU7QUFDNUQsaUJBQU8sZUFBZTtRQUN2QjtNQUNEO0FBRUEsdUJBQWlCLGFBQWEsS0FBSyxRQUFRLEtBQUssaUJBQWlCO0FBR2pFLFVBQUksQ0FBQyxrQkFBa0IsS0FBSyxPQUFPLFdBQVc7QUFDN0MsY0FBTSxhQUFhLEtBQUssT0FBTyxjQUFjLFNBQVMsS0FBSyxPQUFPLFdBQVcsTUFBTTtBQUNuRixRQUFBQSxRQUFPLEtBQUsscUJBQXFCLEtBQUssT0FBTyxTQUFTLHNEQUFpRDtBQUN2RyxhQUFLLGFBQWEsZUFBZSxtQkFBbUIsR0FBRyxVQUFVLElBQUksS0FBSyxPQUFPLFNBQVMsYUFBYTtBQUN2RztNQUNEO0lBQ0Q7QUFHQSxTQUFLLFVBQVUsY0FBYztBQUk3QixVQUFNLGFBQWEsS0FBSztBQUN4QixVQUFNLEtBQUssb0JBQW9CLElBQUksVUFBVTtBQUc3QyxTQUFLLGNBQWE7QUFDbEIsU0FBSyxnQkFBZTtBQUNwQixTQUFLLDBCQUF5QjtBQUM5QixTQUFLLHFCQUFvQjtBQUV6QixTQUFLLGFBQWEsZUFBZSxFQUFFO0FBQ25DLElBQUFBLFFBQU8sS0FBSywyQkFBMkI7RUFDeEM7O0VBR0EsTUFBTSxVQUFPO0FBQ1osU0FBSyxjQUFjLE1BQUs7QUFDeEIsSUFBQUEsUUFBTyxNQUFNLFNBQVM7RUFDdkI7RUFFQSxNQUFNLGNBQWMsUUFBb0I7QUFDdkMsVUFBTSxlQUFlLEtBQUs7QUFDMUIsU0FBSyxTQUFTO0FBQ2QsVUFBTSxpQkFBaUIsYUFBYSxRQUFRLEtBQUssaUJBQWlCO0FBQ2xFLFNBQUssVUFBVSxjQUFjO0FBSTdCLFNBQUsscUJBQW9CO0FBRXpCLFVBQU0sVUFBVSxLQUFLO0FBSXJCLFVBQU0sS0FBSyxvQkFBb0IsY0FBYyxPQUFPO0FBR3BELFNBQUssY0FBYTtBQUNsQixTQUFLLGdCQUFlO0FBQ3BCLFNBQUssMEJBQXlCO0FBQzlCLFNBQUsscUJBQW9CO0VBQzFCOzs7Ozs7Ozs7Ozs7RUFhUSxNQUFNLG9CQUFvQixjQUFzQixTQUFlO0FBQ3RFLFFBQUksQ0FBQyxTQUFTO0FBQ2IsVUFBSTtBQUFjLGFBQUssYUFBYSxhQUFhLFlBQVk7QUFDN0Q7SUFDRDtBQUVBLFFBQUksS0FBSyxPQUFPLFdBQVc7QUFFMUIsWUFBTSxTQUFTLEtBQUssa0JBQWtCLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxLQUFLLE9BQU8sU0FBUztBQUNqRixVQUFJLENBQUMsUUFBUTtBQUNaLFFBQUFBLFFBQU8sS0FBSyxlQUFlLEtBQUssT0FBTyxTQUFTLHlEQUFvRDtBQUNwRyxZQUFJO0FBQWMsZUFBSyxhQUFhLGFBQWEsWUFBWTtBQUM3RDtNQUNEO0FBRUEsVUFBSSxnQkFBZ0IsaUJBQWlCLFNBQVM7QUFDN0MsYUFBSyxhQUFhLGFBQWEsWUFBWTtNQUM1QztBQUNBLFlBQU0sZ0JBQWdCLEtBQUssYUFBYSxtQkFBbUIsT0FBTztBQUNsRSxVQUFJLENBQUMsZUFBZTtBQUNuQixhQUFLLGFBQWEsZ0JBQWdCLE9BQU87TUFDMUM7QUFDQSxVQUFJLFlBQVksZ0JBQWdCLENBQUMsZUFBZTtBQUMvQyxjQUFNLEtBQUssNkJBQTZCLE9BQU8sT0FBTyxPQUFPO01BQzlEO0FBQ0EsV0FBSyxhQUFhLGVBQWUsRUFBRTtBQUNuQztJQUNEO0FBR0EsVUFBTSxjQUFjLE9BQU8sS0FBSyxPQUFPLGVBQWUsRUFBRTtBQUN4RCxVQUFNLGlCQUFpQixLQUFLLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUUxRSxRQUFJLGdCQUFnQjtBQUNuQixVQUFJLGVBQWUsVUFBVSxhQUFhO0FBQ3pDLFlBQUksZ0JBQWdCLGlCQUFpQjtBQUFTLGVBQUssYUFBYSxhQUFhLFlBQVk7QUFDekYsY0FBTSxnQkFBZ0IsS0FBSyxhQUFhLG1CQUFtQixPQUFPO0FBQ2xFLFlBQUksQ0FBQyxlQUFlO0FBQ25CLGVBQUssYUFBYSxnQkFBZ0IsT0FBTztRQUMxQztBQUNBLFlBQUksWUFBWSxnQkFBZ0IsQ0FBQyxlQUFlO0FBQy9DLGdCQUFNLEtBQUssNkJBQTZCLGFBQWEsT0FBTztRQUM3RDtBQUNBLGFBQUssYUFBYSxlQUFlLEVBQUU7TUFDcEMsT0FBTztBQUNOLFFBQUFBLFFBQU8sTUFDTiwwQkFBMEIsV0FBVywyQ0FBMkMsZUFBZSxLQUFLLFFBQVEsT0FBTywwQkFBcUI7QUFFekksYUFBSyxhQUFhLGFBQWEsT0FBTztBQUN0QyxhQUFLLGFBQ0osZUFBZSxtQkFDZiw0QkFBNEIsV0FBVyxTQUFTLGVBQWUsS0FBSyxFQUFFO01BRXhFO0FBQ0E7SUFDRDtBQUdBLElBQUFBLFFBQU8sS0FBSyxHQUFHLE9BQU8sd0NBQW1DO0FBQ3pELFFBQUksZ0JBQWdCLGlCQUFpQjtBQUFTLFdBQUssYUFBYSxhQUFhLFlBQVk7QUFDekYsU0FBSyxhQUFhLGFBQWEsT0FBTztBQUV0QyxVQUFNLFNBQVMsTUFBTSxLQUFLLGFBQWEsWUFBWSxPQUFPO0FBQzFELFFBQUksQ0FBQyxRQUFRO0FBQ1osTUFBQUEsUUFBTyxNQUFNLDBCQUEwQixPQUFPLDBCQUFxQjtBQUNuRSxXQUFLLGFBQWEsZUFBZSxnQkFBZ0IsbUJBQW1CLE9BQU8sRUFBRTtJQUM5RSxXQUFXLE9BQU8sVUFBVSxhQUFhO0FBQ3hDLE1BQUFBLFFBQU8sTUFDTiwwQkFBMEIsV0FBVywyQ0FBMkMsT0FBTyxLQUFLLFFBQVEsT0FBTywwQkFBcUI7QUFFakksV0FBSyxhQUNKLGVBQWUsbUJBQ2YsNEJBQTRCLFdBQVcsU0FBUyxPQUFPLEtBQUssRUFBRTtJQUVoRSxPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLGtCQUFrQixPQUFPLEtBQUssT0FBTyxPQUFPLEVBQUU7QUFDMUQsV0FBSyxhQUFhLGdCQUFnQixPQUFPO0FBQ3pDLFlBQU0sS0FBSyw2QkFBNkIsYUFBYSxPQUFPO0FBQzVELFdBQUssYUFBYSxlQUFlLEVBQUU7SUFDcEM7RUFDRDs7Ozs7RUFNUSxNQUFNLDZCQUE2QixPQUFlLElBQVU7QUFDbkUsUUFBSTtBQUNILFlBQU0sS0FBSyxhQUFhLG1CQUFtQixFQUFFO0FBRTdDLFVBQUksQ0FBQyxnQkFBZ0IsS0FBSyxHQUFHO0FBRzVCLFFBQUFBLFFBQU8sS0FBSyw2QkFBNkIsS0FBSyxzREFBaUQ7QUFDL0Y7TUFDRDtJQUNELFNBQVMsR0FBRztBQUNYLE1BQUFBLFFBQU8sS0FBSyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsRUFBRTtJQUN4RDtFQUNEOztFQUdRLFVBQVUsT0FBYTtBQUM5QixTQUFLLGNBQWM7QUFDbkIsVUFBTSxTQUFTLGdCQUFnQixLQUFLO0FBQ3BDLFFBQUksQ0FBQyxRQUFRO0FBQ1osTUFBQUEsUUFBTyxLQUFLLFVBQVUsS0FBSywrQkFBK0I7QUFDMUQsV0FBSyxhQUFhLFNBQVMsT0FBTyxDQUFBLENBQUU7QUFDcEM7SUFDRDtBQUVBLFVBQU0sVUFBVSxNQUFNLFFBQVEsT0FBTyxTQUFTLElBQUksT0FBTyxZQUFZLENBQUE7QUFFckUsU0FBSyxhQUFhLFNBQVMsT0FBTyxPQUFPO0FBQ3pDLFFBQUksUUFBUSxXQUFXLEdBQUc7QUFDekIsTUFBQUEsUUFBTyxLQUFLLCtCQUErQixLQUFLLDZDQUF3QztJQUN6RixPQUFPO0FBQ04sTUFBQUEsUUFBTyxNQUFNLFVBQVUsUUFBUSxNQUFNLHVCQUF1QixLQUFLLGdCQUFnQixPQUFPLFNBQVMsRUFBRTtJQUNwRztFQUNEO0VBRUEsa0JBQWU7QUFDZCxXQUFPLGdCQUFnQixLQUFLLGlCQUFpQjtFQUM5Qzs7RUFHQSxJQUFJLE9BQUk7QUFDUCxXQUFPLFlBQVksS0FBSyxRQUFRLEtBQUssaUJBQWlCO0VBQ3ZEOztFQUdBLElBQUksVUFBTztBQUNWLFdBQU8sS0FBSztFQUNiO0VBRUEsZ0JBQWE7QUFDWixrQkFBYyxJQUFJO0VBQ25CO0VBRUEsa0JBQWU7QUFDZCxvQkFBZ0IsSUFBSTtFQUNyQjtFQUVBLDRCQUF5QjtBQUN4Qiw4QkFBMEIsSUFBSTtFQUMvQjtFQUVBLHVCQUFvQjtBQUNuQix5QkFBcUIsSUFBSTtFQUMxQjs7IiwKICAibmFtZXMiOiBbInBhdGgiLCAiSW5zdGFuY2VTdGF0dXMiLCAiUmVnZXgiLCAicGF0aCIsICJmcyIsICJsb2dnZXIiLCAibG9nZ2VyIiwgImlkQWRkT3B0IiwgImZzIiwgImxvZ2dlciIsICJkZXZpY2VzRm9sZGVyIiwgInBhdGgiLCAiZGdyYW0iLCAib3MiLCAibG9nZ2VyIiwgInNvY2siLCAibG9nZ2VyIiwgImRncmFtIiwgIm9zIiwgImxvZ2dlciJdCn0K
