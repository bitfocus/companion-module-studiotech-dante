import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}
function combineRgb(r, g, b, a) {
  let colorNumber = (r & 255) << 16 | (g & 255) << 8 | b & 255;
  if (a && a >= 0 && a < 1) {
    colorNumber += 16777216 * Math.round(255 * (1 - a));
  }
  return colorNumber;
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path3, args) {
    this.#context.oscSend(host, port, path3, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/config.js
import fs from "fs";
import path from "path";
var logger = createModuleLogger("Config");
function resolveDevicesFolder() {
  const primaryPath = path.join(import.meta.dirname, "../devices");
  const fallbackPath = path.join(import.meta.dirname, "./devices");
  if (fs.existsSync(primaryPath)) {
    logger.debug(`Using devices folder: ${primaryPath}`);
    return primaryPath;
  }
  if (fs.existsSync(fallbackPath)) {
    logger.warn(`Primary devices folder not found, using fallback: ${fallbackPath}`);
    return fallbackPath;
  }
  const errorMsg = `Devices folder not found!
Tried:
  - ${primaryPath}
  - ${fallbackPath}
Module cannot continue without device schemas.`;
  logger.error(errorMsg);
  throw new Error(errorMsg);
}
var devicesFolder = resolveDevicesFolder();
var deviceSchemasCache = null;
function getDevicesFolder() {
  return devicesFolder;
}
function loadDeviceSchemas() {
  const schemas = {};
  try {
    const files = fs.readdirSync(devicesFolder).filter((f) => f.endsWith(".json"));
    for (const f of files) {
      const fullPath = path.join(devicesFolder, f);
      const json = JSON.parse(fs.readFileSync(fullPath, "utf8"));
      if (json?.model) {
        schemas[String(json.model)] = json;
      }
    }
    logger.debug(`Loaded ${Object.keys(schemas).length} device schemas into cache`);
  } catch (e) {
    logger.error(`Failed to load device schemas: ${e}`);
  }
  return schemas;
}
function getDeviceSchemas() {
  if (!deviceSchemasCache) {
    deviceSchemasCache = loadDeviceSchemas();
  }
  return deviceSchemasCache;
}
function getDeviceSchema(model) {
  const schemas = getDeviceSchemas();
  return schemas[model];
}
function reloadDeviceSchemas() {
  logger.info("Reloading device schemas from disk...");
  deviceSchemasCache = loadDeviceSchemas();
}
function loadAvailableModels() {
  const schemas = getDeviceSchemas();
  return Object.keys(schemas).sort();
}
function GetConfigFields(discoveredDevices = []) {
  const models = loadAvailableModels();
  const deviceChoices = [
    { id: "", label: "Manual (enter IP + model below)" },
    ...discoveredDevices.map((d) => ({
      id: d.mac ?? "",
      label: `Model ${d.model} [${d.mac}] @ ${d.ip}`
    }))
  ];
  return [
    // ── Device selection dropdown ────────────────────────────────────────
    // Stores the MAC so re-discovery with a changed IP still matches.
    {
      type: "dropdown",
      id: "deviceMac",
      label: "Device",
      width: 8,
      default: "",
      choices: deviceChoices,
      tooltip: "Select an auto-discovered Studio Technologies device, or choose Manual to enter an IP address."
    },
    // ── Manual IP entry — only visible in manual mode ────────────────────
    {
      type: "textinput",
      id: "host",
      label: "Target IP",
      width: 8,
      default: "",
      regex: Regex.IP,
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Enter the IP address of the device manually."
    },
    // ── Manual model selector — only visible in manual mode ──────────────
    {
      type: "dropdown",
      id: "activeModel",
      label: "Active Device Model",
      width: 8,
      default: models[0] ?? "",
      choices: models.map((model) => ({
        id: model,
        label: `Model ${model}`
      })),
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Select which Studio Technologies model is active for actions and feedbacks."
    },
    // ── Dev Mode ─────────────────────────────────────────────────────────
    {
      type: "checkbox",
      id: "devMode",
      label: "Dev Mode",
      width: 12,
      default: false,
      tooltip: "Enable to allow parsing of ST Devices not currently supported"
    }
  ];
}
function resolveHost(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    return device?.ip ?? "";
  }
  return String(config.host ?? "");
}
function resolveModel(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    logger.debug(`resolveModel: deviceMac="${config.deviceMac}", found device: ${device?.model ?? "none"}`);
    return device?.model ?? "";
  }
  logger.debug(`resolveModel: manual mode, activeModel="${config.activeModel}"`);
  return String(config.activeModel ?? "");
}

// dist/variables.js
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions({
    model: { name: "Device Model Number" },
    modelName: { name: "Device Model Name (Full Description)" },
    manufacturer: { name: "Device Manufacturer" },
    firmware: { name: "Device Firmware Version" },
    danteFW: { name: "Dante Module Firmware Version" },
    mac: { name: "Device MAC Address" },
    ip: { name: "Device IP Address" }
  });
}
var CLEARED_VARIABLES = {
  model: "",
  modelName: "",
  manufacturer: "",
  firmware: "",
  danteFW: "",
  mac: "",
  ip: ""
};
function UpdateVariableValues(self) {
  const currentHost = self.host;
  if (!currentHost || !self.stController.isDeviceAuthorized(currentHost)) {
    self.setVariableValues(CLEARED_VARIABLES);
    return;
  }
  const device = self.devices.find((d) => d.ip === currentHost);
  if (device) {
    self.setVariableValues({
      model: device.model || "",
      modelName: device.modelName || "",
      manufacturer: device.manufacturer || "",
      firmware: device.firmwareMain || "",
      danteFW: device.danteFirmware || "",
      mac: device.mac || "",
      ip: device.ip
    });
  } else {
    self.setVariableValues({
      ...CLEARED_VARIABLES,
      ip: currentHost
    });
  }
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  // function (context, props) {
  // 	return {
  // 		updatedConfig: null,
  // 		updatedActions: [],
  // 		updatedFeedbacks: [],
  // 	}
  // },
];

// dist/types.js
var CMD_GET_FIRMWARE = 0;
var CMD_MIC_PRE = 2;
var CMD_BUS_GET = 3;
var CMD_BUS_SET = 4;
var CMD_HEADPHONE = 5;
var CMD_BUTTON_MODE = 7;
var CMD_SYSTEM = 9;
var CMD_GET_ALL_SETTINGS = 10;
var CMD_SETTINGS_PUSH = 11;
var CMD_DEV_SPEC = 13;
var CMD_RESET_DEVICE = 14;
var CMD_GLOBAL_MIC_KILL = 16;
var CMD_MIC_PRE_BUS = 18;
var CMD_CHANNEL = 20;
function getCommandName(cmdId) {
  switch (cmdId) {
    case CMD_GET_FIRMWARE:
      return "Get Firmware Version";
    case CMD_MIC_PRE:
      return "Mic Preamp";
    case CMD_BUS_GET:
      return "Heartbeat";
    case CMD_BUS_SET:
      return "Set Bus Setting";
    case CMD_HEADPHONE:
      return "Headphone Control";
    case CMD_BUTTON_MODE:
      return "Button Mode";
    case CMD_SYSTEM:
      return "System Command";
    case CMD_GET_ALL_SETTINGS:
      return "Request All Settings";
    case CMD_SETTINGS_PUSH:
      return "Settings Push";
    case CMD_MIC_PRE_BUS:
      return "Mic/Pre Bus";
    case CMD_DEV_SPEC:
      return "Device Setting";
    case CMD_CHANNEL:
      return "Channel Setting";
    case CMD_RESET_DEVICE:
      return "Reset Device";
    case CMD_GLOBAL_MIC_KILL:
      return "Global Mic Kill";
    default:
      return `cmd_0x${cmdId.toString(16).padStart(2, "0")}`;
  }
}
function makeSettingId(model, cmdId, settingId, busCh) {
  const cmd = typeof cmdId === "number" ? cmdId.toString(16) : cmdId;
  const id = typeof settingId === "number" ? settingId.toString(16) : settingId;
  if (busCh !== void 0) {
    const ch = typeof busCh === "number" ? busCh.toString(16) : busCh;
    return `${model}_${cmd}_${ch}_${id}`;
  }
  return `${model}_${cmd}_${id}`;
}
function toHex(value, padLength = 2) {
  return `0x${value.toString(16).padStart(padLength, "0")}`;
}
function bytesToHex(bytes) {
  return `0x${Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}
function formatRgbColor(r, g, b) {
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}
function parseSettingId(id) {
  const [model, cmdIdStr, idStr] = id.split("_");
  return {
    model,
    cmdId: parseInt(cmdIdStr, 16),
    baseId: parseInt(idStr, 16)
  };
}
function modelDistance(modelA, modelB) {
  const na = parseInt(modelA.replace(/\D/g, ""), 10);
  const nb = parseInt(modelB.replace(/\D/g, ""), 10);
  if (Number.isNaN(na) || Number.isNaN(nb))
    return Infinity;
  return Math.abs(na - nb);
}
function getNormalizedSchemas(schemasRaw) {
  const normalized = {};
  for (const [model, json] of Object.entries(schemasRaw)) {
    normalized[model] = {
      model: json.model,
      cmdSchema: Array.isArray(json.cmdSchema) ? json.cmdSchema : []
    };
  }
  return normalized;
}
function findActionForSetting(schemas, model, cmdId, settingId) {
  const schema = schemas[model];
  if (!schema || !Array.isArray(schema.cmdSchema))
    return void 0;
  let action = schema.cmdSchema.find((s) => s.cmd_id === cmdId && s.id === settingId);
  if (!action) {
    action = schema.cmdSchema.find((s) => {
      if (s.cmd_id !== cmdId)
        return false;
      const idAddOption = s.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const offset = settingId - s.id;
      return idAddOption.choices.some((c) => c.id === offset);
    });
  }
  return action;
}

// dist/build-commands.js
function buildOption(o) {
  const base = {
    type: o.type,
    id: o.id,
    label: o.label,
    default: o.default,
    tooltip: o.tooltip
  };
  switch (o.type) {
    case "dropdown":
      return { ...base, choices: o.choices ?? [] };
    case "number":
      return {
        ...base,
        min: o.min,
        max: o.max,
        step: o.step ?? 1,
        range: true
      };
    case "checkbox":
      return { ...base, default: o.default ?? false };
    case "static-text":
      return { ...base, value: o.value ?? "" };
    case "textinput":
    case "colorpicker":
    default:
      return base;
  }
}
function buildActions() {
  const schemas = getDeviceSchemas();
  const actions = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const a of cmdSchema) {
      if (a.readonly === true)
        continue;
      const actionId = makeSettingId(model, a.cmd_id, a.id);
      const allBuiltOptions = (a.options ?? []).map(buildOption);
      const options = a.value !== void 0 ? allBuiltOptions.filter((o) => o.id !== "value") : allBuiltOptions;
      const action = {
        name: `[Model${model}] ${a.name}`,
        options,
        callback: async () => {
        }
      };
      actions[actionId] = action;
    }
  }
  return actions;
}
function isBooleanDropdown(setting) {
  const valueOpt = setting.options?.find((o) => o.id === "value");
  if (!valueOpt)
    return false;
  if (valueOpt.type === "checkbox")
    return true;
  if (valueOpt.type !== "dropdown" || !Array.isArray(valueOpt.choices))
    return false;
  if (valueOpt.choices.length !== 2)
    return false;
  const labels = valueOpt.choices.map((c) => String(c.label).toLowerCase());
  return labels.includes("off") && labels.includes("on");
}
function buildFeedbacks() {
  const schemas = getDeviceSchemas();
  const feedbacks = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const setting of cmdSchema) {
      if (setting.writeonly === true)
        continue;
      const baseFeedbackId = makeSettingId(model, setting.cmd_id, setting.id);
      if (setting.value !== void 0) {
        const fixedOptions = (setting.options ?? []).map(buildOption).filter((opt) => opt.id === "busCh" || opt.id === "idAdd");
        feedbacks[baseFeedbackId] = {
          type: "boolean",
          name: `[Model${model}] ${setting.name} \u2014 Active`,
          defaultStyle: {
            bgcolor: combineRgb(0, 200, 0),
            color: combineRgb(0, 0, 0)
          },
          options: fixedOptions,
          callback: () => {
            return false;
          }
        };
        continue;
      }
      const allOptions = (setting.options ?? []).map(buildOption);
      const valueOptions = allOptions.filter((opt) => opt.id !== "value");
      const isColorSetting = setting.options?.some((o) => o.id === "value" && o.type === "colorpicker");
      if (!isColorSetting) {
        valueOptions.push({
          type: "checkbox",
          id: "showLabel",
          label: "Use Label for Value",
          default: false,
          tooltip: "Return the label text instead of the numeric value"
        });
      }
      const valueFeedback = {
        type: "value",
        name: `[Model${model}] ${setting.name}`,
        options: valueOptions,
        callback: () => {
          return 0;
        }
      };
      feedbacks[baseFeedbackId] = valueFeedback;
      if (isBooleanDropdown(setting)) {
        const boolFeedbackId = `${baseFeedbackId}_bool`;
        const boolOptions = allOptions.filter((opt) => opt.id !== "value");
        const boolFeedback = {
          type: "boolean",
          name: `[Model${model}] ${setting.name} \u2014 Is On`,
          defaultStyle: {
            bgcolor: combineRgb(0, 200, 0),
            color: combineRgb(0, 0, 0)
          },
          options: boolOptions,
          callback: () => {
            return false;
          }
        };
        feedbacks[boolFeedbackId] = boolFeedback;
      }
    }
  }
  return feedbacks;
}

// dist/actions.js
import path2 from "path";

// dist/settingsParser.js
import fs2 from "fs";
var logger2 = createModuleLogger("SettingsParser");
function getRgbIds(model) {
  const rgbIds = /* @__PURE__ */ new Set();
  try {
    const json = getDeviceSchema(model);
    if (!json)
      return rgbIds;
    for (const action of json.cmdSchema || []) {
      const hasColorpicker = action.options?.some((opt) => opt.type === "colorpicker");
      if (hasColorpicker) {
        rgbIds.add(action.id);
        const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
        if (idAddOption?.choices) {
          for (const choice of idAddOption.choices) {
            if (typeof choice.id === "number") {
              rgbIds.add(action.id + choice.id);
            }
          }
        }
      }
    }
  } catch (_err) {
  }
  return rgbIds;
}
function extractStPayloadIndex(buf) {
  const sigIndex = buf.indexOf(Buffer.from("Studio-T"));
  if (sigIndex < 0)
    throw new Error("No Studio-T signature in packet");
  const payloadIndex = sigIndex + 8;
  if (buf[payloadIndex] !== 90) {
    throw new Error(`Expected 0x5A after Studio-T, found ${buf[payloadIndex].toString(16)}`);
  }
  return payloadIndex;
}
function parseGetAllSettings_sectioned(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  let p = cmdId === CMD_GET_ALL_SETTINGS ? idx + 3 : idx + 2;
  const end = buf.length - 1;
  const out = [];
  const rgbIds = getRgbIds(model);
  const commandsWithBusCh = [CMD_BUS_SET, CMD_MIC_PRE_BUS, CMD_CHANNEL];
  const commandsRawValue = [CMD_MIC_PRE];
  while (p + 2 < end) {
    const cmdLen = buf[p];
    const sectionCmdId = buf[p + 1];
    const sectionEnd = p + 1 + cmdLen;
    if (sectionEnd > end)
      break;
    const hasBusCh = commandsWithBusCh.includes(sectionCmdId);
    const isRawValue = commandsRawValue.includes(sectionCmdId);
    let busCh;
    let dataLen;
    let q;
    if (isRawValue) {
      busCh = buf[p + 2];
      const rawBytes = buf.subarray(p + 3, sectionEnd);
      const schema = getDeviceSchema(model);
      const micPreEntries = (schema?.cmdSchema ?? []).filter((a) => (a.cmd_id === CMD_MIC_PRE || a.cmd_id === CMD_MIC_PRE_BUS) && a.busCh !== void 0).sort((a, b) => a.id - b.id);
      for (let i = 0; i < rawBytes.length; i++) {
        const entry = micPreEntries[i];
        if (entry) {
          out.push({ cmd_id: entry.cmd_id, id: entry.id, busCh, valueBytes: [rawBytes[i]] });
        }
      }
      p = sectionEnd;
      continue;
    } else if (hasBusCh) {
      busCh = buf[p + 2];
      dataLen = buf[p + 3];
      q = p + 4;
    } else {
      dataLen = buf[p + 2];
      q = p + 3;
    }
    const qEnd = q + dataLen;
    const qStart = q;
    while (q + 1 < qEnd) {
      const id = buf[q];
      let valueBytes;
      if (rgbIds.has(id) && q + 3 < qEnd) {
        valueBytes = [buf[q + 1], buf[q + 2], buf[q + 3]];
        q += 4;
      } else {
        valueBytes = [buf[q + 1]];
        q += 2;
      }
      const setting = {
        cmd_id: sectionCmdId,
        id,
        valueBytes
      };
      if (busCh !== void 0) {
        setting.busCh = busCh;
      }
      out.push(setting);
    }
    if (q === qStart && sectionEnd > p + 3) {
      let pos = hasBusCh ? p + 3 : p + 2;
      let posId = 0;
      while (pos < sectionEnd) {
        const setting = { cmd_id: sectionCmdId, id: posId++, valueBytes: [buf[pos++]] };
        if (busCh !== void 0)
          setting.busCh = busCh;
        out.push(setting);
      }
    }
    p = sectionEnd;
  }
  return out;
}
function parseSettingsResponse(model, buf) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error(`Not a settings block (cmdId=0x${cmdId.toString(16)})`);
  }
  return parseGetAllSettings_sectioned(buf, model);
}
function formatParsedSetting(setting, actions) {
  let action = actions.find((a) => a.cmd_id === setting.cmd_id && a.id === setting.id);
  if (!action) {
    const baseAction = actions.find((a) => {
      if (a.cmd_id !== setting.cmd_id)
        return false;
      const idAddOption = a.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const channelOffset = setting.id - a.id;
      return idAddOption.choices.some((c) => c.id === channelOffset);
    });
    if (baseAction) {
      action = baseAction;
    }
  }
  const cmdHex = toHex(setting.cmd_id);
  const idHex = toHex(setting.id);
  const valHex = bytesToHex(setting.valueBytes);
  const valDec = setting.valueBytes.length === 3 ? formatRgbColor(setting.valueBytes[0], setting.valueBytes[1], setting.valueBytes[2]) : setting.valueBytes.length === 1 ? setting.valueBytes[0] : setting.valueBytes.join(",");
  const busChStr = setting.busCh !== void 0 ? ` ch:${setting.busCh}` : "";
  const prefix = `cmd:${cmdHex}${busChStr} id:${idHex} val:${valHex}`;
  if (action) {
    let name = action.name;
    if (setting.busCh !== void 0) {
      name = `${name} Ch${setting.busCh + 1}`;
    } else {
      const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
      if (idAddOption?.choices) {
        const channelOffset = setting.id - action.id;
        const idAddChoice = idAddOption.choices.find((c) => c.id === channelOffset);
        if (idAddChoice) {
          name = `${name} ${idAddChoice.label}`;
        }
      }
    }
    const valueOption = action.options?.find((opt) => opt.id === "value");
    const fixedValue = action.value;
    if (fixedValue !== void 0 && valueOption === void 0) {
      return `${prefix} | ${name}: ${fixedValue}`;
    }
    if (valueOption?.choices && setting.valueBytes.length === 1) {
      const choice = valueOption.choices.find((c) => c.id === setting.valueBytes[0]);
      if (choice) {
        return `${prefix} | ${name}: ${choice.label} (${valDec})`;
      }
    }
    return `${prefix} | ${name}: ${valDec}`;
  }
  return `${prefix} | Unknown Setting`;
}
function parseGetAllSettingsWithDetection(model, buf) {
  const settings = parseGetAllSettings_sectioned(buf, model);
  return { settings, detectedSectioned: null };
}
function parseGetAllSettingsForModel(model, buf) {
  return parseGetAllSettings_sectioned(buf, model);
}
function valueBytesToOption(valueBytes) {
  if (valueBytes.length === 1) {
    return { id: "value", label: "Value", type: "number", default: valueBytes[0] };
  }
  if (valueBytes.length === 3) {
    const [r, g, b] = valueBytes;
    return {
      id: "value",
      label: "Color",
      type: "colorpicker",
      default: formatRgbColor(r, g, b)
    };
  }
  return { id: "value", label: "Value", type: "raw", default: [...valueBytes] };
}
function updateModelJsonFromSettings(modelJson, parsed, allModels) {
  const out = structuredClone(modelJson);
  if (!out.cmdSchema) {
    out.cmdSchema = [];
  }
  const candidates = Object.values(allModels).filter((m) => m.model !== modelJson.model).sort((a, b) => modelDistance(modelJson.model, a.model) - modelDistance(modelJson.model, b.model));
  logger2.info(`Updating model: ${modelJson.model}`);
  logger2.debug(`Candidates for inference: ${candidates.map((c) => c.model).join(", ")}`);
  const idAddDeferRanges = /* @__PURE__ */ new Map();
  for (const c of candidates) {
    for (const baseEntry of c.cmdSchema ?? []) {
      const idAddOpt = baseEntry.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        continue;
      const baseId = baseEntry.id;
      const cmdId = baseEntry.cmd_id;
      const key = `${cmdId}_${baseId}`;
      if (idAddDeferRanges.has(key))
        continue;
      const parsedOffsets = parsed.filter((p) => p.cmd_id === cmdId && p.id > baseId).map((p) => p.id - baseId).sort((a, b) => a - b);
      let maxSeq = 0;
      for (const off of parsedOffsets) {
        if (off === maxSeq + 1)
          maxSeq = off;
        else if (off > maxSeq + 1)
          break;
      }
      if (maxSeq > 0) {
        idAddDeferRanges.set(key, maxSeq);
        logger2.debug(`idAdd defer range for cmd_id=${toHex(cmdId)} base_id=${toHex(baseId)}: offsets 1\u2013${maxSeq}`);
      }
    }
  }
  const busChSeen = /* @__PURE__ */ new Map();
  for (const { cmd_id, id, busCh } of parsed) {
    if (busCh === void 0)
      continue;
    const key = `${cmd_id}_${id}`;
    if (!busChSeen.has(key))
      busChSeen.set(key, /* @__PURE__ */ new Set());
    busChSeen.get(key).add(busCh);
  }
  for (const { cmd_id, id, busCh, valueBytes } of parsed) {
    const existingExact = out.cmdSchema.find((a) => a.cmd_id === cmd_id && a.id === id);
    if (existingExact) {
      const opt = existingExact.options?.find((o) => o.id === "value");
      if (opt)
        opt.default = valueBytesToOption(valueBytes).default;
      const seenBusChValues = busChSeen.get(`${cmd_id}_${id}`);
      if (seenBusChValues && seenBusChValues.size > 0) {
        const maxBusCh = Math.max(...seenBusChValues);
        const hasBusChOption = existingExact.options?.some((o) => o.id === "busCh");
        if (maxBusCh === 0 && existingExact.busCh === void 0 && !hasBusChOption) {
          existingExact.busCh = 0;
          logger2.info(`Synced busCh=0 onto existing entry cmd_id=${toHex(cmd_id)} id=${toHex(id)}`);
        }
      }
      continue;
    }
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt = a.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        return false;
      if (id <= a.id)
        return false;
      const offset = id - a.id;
      return candidates.some((c) => {
        const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === a.id);
        const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
        return refIdAdd?.choices?.some((ch) => ch.id === offset);
      });
    });
    if (idAddBase) {
      const offset = id - idAddBase.id;
      const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
      if (idAddOpt?.choices && !idAddOpt.choices.some((c) => c.id === offset)) {
        let label = `Channel ${offset + 1}`;
        for (const c of candidates) {
          const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
          const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
          const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
          if (refChoice) {
            label = refChoice.label;
            break;
          }
        }
        idAddOpt.choices.push({ id: offset, label });
        logger2.info(`Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
      }
      continue;
    }
    let action;
    for (const c of candidates) {
      const match = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === id);
      if (match) {
        action = structuredClone(match);
        const baseName = match.name.replace(/\s*\(inferred from Model [^)]+\)/g, "").trim();
        action.name = `${baseName} (inferred from Model ${c.model})`;
        logger2.info(`Inferred cmd_id=${toHex(cmd_id)} id=${toHex(id)} from Model ${c.model} (exact)`);
        break;
      }
    }
    if (!action) {
      let shouldDefer = false;
      for (const c of candidates) {
        const baseEntry = c.cmdSchema?.find((a) => {
          if (a.cmd_id !== cmd_id)
            return false;
          const idAddOpt = a.options?.find((o) => o.id === "idAdd");
          if (!idAddOpt?.choices)
            return false;
          if (id <= a.id)
            return false;
          const offset = id - a.id;
          const maxSeq = idAddDeferRanges.get(`${cmd_id}_${a.id}`) ?? 0;
          return offset <= maxSeq;
        });
        if (baseEntry) {
          shouldDefer = true;
          logger2.debug(`cmd_id=${toHex(cmd_id)} id=${toHex(id)} is an idAdd offset of candidate base id=${toHex(baseEntry.id)} \u2014 deferring to pass 2`);
          break;
        }
      }
      if (shouldDefer)
        continue;
    }
    if (!action) {
      action = {
        cmd_id,
        id,
        name: `Unknown cmd:${toHex(cmd_id)} id:${toHex(id).toUpperCase()}`,
        options: [valueBytesToOption(valueBytes)]
      };
      if (busCh !== void 0)
        action.busCh = busCh;
      logger2.warn(`Could not infer cmd_id=${toHex(cmd_id)} id=${toHex(id)}`);
    } else {
      action.options = action.options?.filter((o) => o.id !== "busCh") ?? [];
      delete action.busCh;
      const seenBusChValues = busChSeen.get(`${cmd_id}_${id}`);
      if (seenBusChValues && seenBusChValues.size > 0) {
        const maxBusCh = Math.max(...seenBusChValues);
        if (maxBusCh === 0) {
          action.busCh = 0;
        } else {
          const busChChoices = Array.from({ length: maxBusCh + 1 }, (_, i) => ({
            id: i,
            label: `Channel ${i + 1}`
          }));
          action.options.unshift({
            id: "busCh",
            label: "Channel",
            type: "dropdown",
            choices: busChChoices,
            default: 0
          });
        }
      }
      const observedDefault = valueBytesToOption(valueBytes).default;
      const valueOpt = action.options?.find((o) => o.id === "value");
      if (valueOpt) {
        if (valueOpt.choices && Array.isArray(valueOpt.choices)) {
          const inChoices = valueOpt.choices.some((c) => c.id === observedDefault);
          if (!inChoices) {
            logger2.warn(`Inferred choices for cmd_id=${toHex(cmd_id)} id=${toHex(id)} don't contain observed value ${observedDefault} \u2014 discarding inherited choices`);
            valueOpt.type = "number";
            delete valueOpt.choices;
          }
        }
        valueOpt.default = observedDefault;
      }
    }
    out.cmdSchema.push(action);
  }
  for (const { cmd_id, id } of parsed) {
    const alreadyTopLevel = out.cmdSchema.some((a) => a.cmd_id === cmd_id && a.id === id);
    if (alreadyTopLevel)
      continue;
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt2 = a.options?.find((o) => o.id === "idAdd");
      return !!idAddOpt2?.choices && id > a.id;
    });
    if (!idAddBase)
      continue;
    const offset = id - idAddBase.id;
    const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
    if (!idAddOpt?.choices || idAddOpt.choices.some((c) => c.id === offset))
      continue;
    const refHasOffset = candidates.some((c) => {
      const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      return refIdAdd?.choices?.some((ch) => ch.id === offset);
    });
    const existingOffsets = idAddOpt.choices.map((c) => c.id).sort((a, b) => a - b);
    const isSequential = existingOffsets.length > 0 && offset === existingOffsets[existingOffsets.length - 1] + 1;
    if (!refHasOffset && !isSequential)
      continue;
    let label = `Channel ${offset + 1}`;
    for (const c of candidates) {
      const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
      if (refChoice) {
        label = refChoice.label;
        break;
      }
    }
    idAddOpt.choices.push({ id: offset, label });
    logger2.info(`Pass 2: Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
  }
  return out;
}
function saveModelJsonPretty(filePath, jsonObj) {
  try {
    const orderedObj = { model: jsonObj.model };
    if ("useConMon" in jsonObj) {
      orderedObj.useConMon = jsonObj.useConMon;
    }
    if ("cmdSchema" in jsonObj) {
      orderedObj.cmdSchema = jsonObj.cmdSchema.map((entry) => {
        const orderedEntry = {};
        if ("cmd_id" in entry)
          orderedEntry.cmd_id = entry.cmd_id;
        if ("id" in entry)
          orderedEntry.id = entry.id;
        if ("busCh" in entry)
          orderedEntry.busCh = entry.busCh;
        if ("name" in entry)
          orderedEntry.name = entry.name;
        if ("value" in entry)
          orderedEntry.value = entry.value;
        if ("options" in entry)
          orderedEntry.options = entry.options;
        for (const key of Object.keys(entry)) {
          if (!(key in orderedEntry))
            orderedEntry[key] = entry[key];
        }
        return orderedEntry;
      });
    }
    for (const key of Object.keys(jsonObj)) {
      if (!(key in orderedObj)) {
        orderedObj[key] = jsonObj[key];
      }
    }
    let json = JSON.stringify(orderedObj, null, 2);
    json = json.replace(/\{\n\s+"id":\s*(\d+),\n\s+"label":\s*"([^"]*)"\n\s+\}/g, '{ "id": $1, "label": "$2" }');
    fs2.writeFileSync(filePath, json + "\n", "utf8");
  } catch (e) {
    logger2.error(`File Write Error: ${e}`);
  }
}

// dist/actions.js
var logger3 = createModuleLogger("Actions");
function UpdateActions(self) {
  const schemasRaw = getDeviceSchemas();
  const rawActions = buildActions();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredActions = {};
  const activeModel = self.activeModel;
  if (self.config.devMode) {
    wiredActions["global_getAllSettings"] = {
      name: "GLOBAL: Get All Settings",
      description: "Use this to create a schema for a new device",
      options: [],
      callback: async () => {
        const model = activeModel;
        const ip = self.host;
        const buf = await self.stController.requestAllSettings(ip);
        let modelJson = getDeviceSchema(model);
        const { settings: parsed } = parseGetAllSettingsWithDetection(model, buf);
        logger3.debug(`parsed reply: ${JSON.stringify(parsed)}`);
        if (!modelJson) {
          logger3.info(`Model ${model} has no schema \u2014 creating new JSON from settings`);
          modelJson = {
            model,
            cmdSchema: []
          };
        }
        const updated = updateModelJsonFromSettings(modelJson, parsed, schemas);
        logger3.debug(`new Actions json: ${JSON.stringify(updated, null, 2)}`);
        const devicesFolder2 = getDevicesFolder();
        const schemaPath = path2.join(devicesFolder2, `Model${model}.json`);
        saveModelJsonPretty(schemaPath, updated);
        reloadDeviceSchemas();
        logger3.info(`Model ${model} JSON auto-updated from getAllSettings`);
      }
    };
  }
  for (const [actionId, action] of Object.entries(rawActions)) {
    const { model, cmdId, baseId } = parseSettingId(actionId);
    if (model !== activeModel)
      continue;
    const rawSchema = schemasRaw[model];
    const rawAction = rawSchema?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === baseId);
    wiredActions[actionId] = {
      ...action,
      callback: async (event) => {
        const ip = self.host;
        const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
        const value = rawAction?.value !== void 0 ? rawAction.value : event.options["value"];
        const idAdd = event.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        await self.stController.sendAwaitAck(cmdId, busCh, settingId, value, ip);
      },
      ...rawAction?.value === void 0 && {
        learn: (event) => {
          const ip = self.host;
          const idAdd = event.options["idAdd"] ?? 0;
          const settingId = baseId + idAdd;
          const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
          const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
          if (current === void 0)
            return void 0;
          return { ...event.options, value: current };
        }
      }
    };
  }
  const activeSchema = schemas[activeModel];
  if (activeSchema) {
    const supportsMicKill = (activeSchema.cmdSchema ?? []).some((a) => a.name.includes("Kill"));
    if (supportsMicKill) {
      const actionId = `${activeModel}_micKill`;
      wiredActions[actionId] = {
        name: `[Model${activeModel}] Mic Kill`,
        options: [],
        callback: async () => {
          const ip = self.host;
          logger3.info(`Mic Kill \u2192 Model ${activeModel} @ ${ip}`);
          await self.stController.globalMicKill(ip);
          await self.stController.requestAllSettings(ip).catch((err) => {
            logger3.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
      };
    }
  }
  self.setActionDefinitions(wiredActions);
}

// dist/feedbacks.js
function getLabelForValue(schemas, model, cmdId, settingId, value) {
  const setting = findActionForSetting(schemas, model, cmdId, settingId);
  if (!setting || !Array.isArray(setting.options))
    return value;
  const valueOption = setting.options.find((opt) => opt.id === "value");
  if (!valueOption || !Array.isArray(valueOption.choices))
    return value;
  const choice = valueOption.choices.find((c) => c.id === value);
  return choice?.label ?? value;
}
function UpdateFeedbacks(self) {
  const schemasRaw = getDeviceSchemas();
  const rawFeedbacks = buildFeedbacks();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredFeedbacks = {};
  const activeModel = self.activeModel;
  for (const [feedbackId, feedback] of Object.entries(rawFeedbacks)) {
    const parseId = feedbackId.endsWith("_bool") ? feedbackId.slice(0, -5) : feedbackId;
    const { model, cmdId, baseId } = parseSettingId(parseId);
    if (model !== activeModel)
      continue;
    wiredFeedbacks[feedbackId] = {
      ...feedback,
      callback: (feedbackEvent) => {
        const ip = self.host;
        const idAdd = feedbackEvent.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        let busCh = feedbackEvent.options["busCh"];
        if (busCh === void 0) {
          const schemaAction = findActionForSetting(schemas, model, cmdId, settingId);
          if (schemaAction?.busCh !== void 0) {
            busCh = schemaAction.busCh;
          }
        }
        if (busCh === void 0) {
          const rawAction = schemasRaw[model]?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === settingId);
          if (rawAction?.busCh !== void 0) {
            busCh = rawAction.busCh;
          }
        }
        const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
        if (feedbackId.endsWith("_bool")) {
          return current !== void 0 && current !== 0;
        }
        const showLabel = feedbackEvent.options["showLabel"] ?? false;
        if (showLabel && current !== void 0) {
          const label = getLabelForValue(schemas, model, cmdId, settingId, current);
          if (typeof label === "number") {
            return label !== 0 ? "true" : "false";
          }
          return label;
        }
        return current ?? 0;
      }
    };
  }
  self.setFeedbackDefinitions(wiredFeedbacks);
}

// dist/stcontroller.js
import dgram3 from "dgram";
import os2 from "os";

// dist/dante.js
import dgram from "dgram";
import os from "os";
var logger4 = createModuleLogger("Dante");
var DANTE_MSG_INFO_REQUEST = 32;
var DANTE_MSG_INFO_RESPONSE = 368;
var DANTE_INFO_MIN_LEN = 204 + 64;
function buildDanteInfoRequest() {
  const buf = Buffer.alloc(32, 0);
  const seq = Math.floor(Math.random() * 65535);
  buf.writeUInt16BE(65535, 0);
  buf.writeUInt16BE(DANTE_MSG_INFO_REQUEST, 2);
  buf.writeUInt16BE(seq, 4);
  const mac = getFirstLocalMac();
  mac.copy(buf, 8);
  Buffer.from("Audinate", "ascii").copy(buf, 16);
  buf.writeUInt16BE(1849, 24);
  buf.writeUInt16BE(193, 26);
  buf.writeUInt32BE(1e6, 28);
  return buf;
}
function getFirstLocalMac() {
  try {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const addr of ifaces[name] ?? []) {
        if (!addr.internal && addr.family === "IPv4" && addr.mac && addr.mac !== "00:00:00:00:00:00") {
          return Buffer.from(addr.mac.split(":").map((h) => parseInt(h, 16)));
        }
      }
    }
  } catch {
  }
  return Buffer.alloc(6, 0);
}
function parseDanteInfoResponse(msg, srcIp) {
  if (msg.length < DANTE_INFO_MIN_LEN)
    return null;
  if (msg.readUInt16BE(0) !== 65535)
    return null;
  if (msg.readUInt16BE(2) !== DANTE_MSG_INFO_RESPONSE)
    return null;
  if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
    return null;
  const readStr = (offset, len) => msg.subarray(offset, offset + len).toString("ascii").split("\0")[0].trim();
  const eui64 = msg.subarray(8, 16);
  const macBytes = [eui64[0], eui64[1], eui64[2], eui64[5], eui64[6], eui64[7]];
  const mac = macBytes.map((b) => b.toString(16).padStart(2, "0")).join(":");
  const name = readStr(32, 31);
  const manufacturer = readStr(76, 64);
  const modelRaw = readStr(204, 64);
  const danteFirmware = `${msg[24]}.${msg[25]}`;
  if (!modelRaw)
    return null;
  const model = modelRaw.replace(/^Model\s+/i, "").trim().split(/\s+/)[0];
  return {
    ip: srcIp,
    name,
    manufacturer,
    model,
    modelName: modelRaw,
    // Full model description
    mac,
    danteFirmware
  };
}
async function getMacForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    tmp.once("error", (err) => {
      tmp.close();
      reject(new Error(err.message ?? String(err)));
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        tmp.close();
        const ifaces = os.networkInterfaces();
        for (const name of Object.keys(ifaces)) {
          for (const iface of ifaces[name] ?? []) {
            if (iface.family === "IPv4" && iface.address === localAddr && iface.mac && iface.mac !== "00:00:00:00:00:00") {
              return resolve(iface.mac.split(":").map((b) => parseInt(b, 16) & 255));
            }
          }
        }
        reject(new Error(`No interface found for local address ${localAddr}`));
      } catch (_e) {
        reject(new Error(String(_e)));
      }
    });
  });
}
async function getLocalAddressForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    let resolved = false;
    tmp.once("error", (err) => {
      if (!resolved) {
        resolved = true;
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      }
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        if (!resolved) {
          resolved = true;
          tmp.close();
          resolve(localAddr);
        }
      } catch (_e) {
        if (!resolved) {
          resolved = true;
          tmp.close();
          reject(new Error(String(_e)));
        }
      }
    });
  });
}
async function discoverDevices(txSocket, ensureMembership, timeoutMs = 5e3) {
  const DANTE_ANNOUNCE_GROUP = "224.0.0.233";
  const DANTE_ANNOUNCE_PORT = 8708;
  const DEFAULT_PORT = 8700;
  const queriedIps = /* @__PURE__ */ new Set();
  return new Promise((resolve) => {
    const announceSocket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const joinedInterfaces = [];
    const cleanup = () => {
      for (const iface of joinedInterfaces) {
        try {
          announceSocket.dropMembership(DANTE_ANNOUNCE_GROUP, iface);
        } catch {
        }
      }
      try {
        announceSocket.close();
      } catch {
      }
      resolve();
    };
    const timer = setTimeout(cleanup, timeoutMs);
    timer.unref?.();
    announceSocket.on("error", (err) => {
      logger4.warn(`Announce socket error: ${err.message}`);
    });
    announceSocket.on("message", (msg, rinfo) => {
      const srcIp = rinfo.address;
      if (msg.length < 24)
        return;
      if (msg.readUInt16BE(0) !== 65534)
        return;
      if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
        return;
      if (queriedIps.has(srcIp))
        return;
      queriedIps.add(srcIp);
      logger4.debug(`Announce from ${srcIp} \u2014 sending unicast query`);
      const sendQuery = async () => {
        await ensureMembership(srcIp);
        const query = buildDanteInfoRequest();
        txSocket.send(query, DEFAULT_PORT, srcIp, (err) => {
          if (err)
            logger4.warn(`Unicast query to ${srcIp} failed: ${err.message}`);
        });
      };
      sendQuery().catch((err) => logger4.warn(`Query setup failed: ${err}`));
    });
    announceSocket.bind(DANTE_ANNOUNCE_PORT, () => {
      const ifaces = os.networkInterfaces();
      for (const addrs of Object.values(ifaces)) {
        for (const addr of addrs ?? []) {
          if (addr.family === "IPv4" && !addr.internal) {
            try {
              announceSocket.addMembership(DANTE_ANNOUNCE_GROUP, addr.address);
              joinedInterfaces.push(addr.address);
            } catch {
            }
          }
        }
      }
      if (joinedInterfaces.length === 0) {
        logger4.warn(`Could not join announce multicast group on any interface`);
      } else {
        logger4.debug(`Listening for Dante announces on ${DANTE_ANNOUNCE_GROUP}:${DANTE_ANNOUNCE_PORT}`);
      }
    });
  });
}
async function probeDevice(txSocket, registerListener, removeListener, ensureMembership, ip, timeoutMs = 3e3) {
  return new Promise((resolve) => {
    const key = `__probe_${ip}__`;
    let resolved = false;
    const finish = (result) => {
      if (resolved)
        return;
      resolved = true;
      removeListener(key);
      resolve(result);
    };
    registerListener(key, (device) => {
      if (device.ip === ip)
        finish(device);
    });
    const timer = setTimeout(() => finish(null), timeoutMs);
    timer.unref?.();
    const run = async () => {
      await ensureMembership(ip);
      const query = buildDanteInfoRequest();
      txSocket.send(query, 8700, ip, (err) => {
        if (err) {
          logger4.warn(`Probe to ${ip} failed: ${err.message}`);
          clearTimeout(timer);
          finish(null);
        }
      });
    };
    run().catch((e) => {
      logger4.warn(`probeDevice setup failed for ${ip}: ${e}`);
      clearTimeout(timer);
      finish(null);
    });
  });
}

// dist/conmon.js
import dgram2 from "dgram";
var logger5 = createModuleLogger("ConMon");
var _conmonPending = /* @__PURE__ */ new Map();
async function openConMonSession(deviceIp, timeoutMs = 3e3) {
  const pending = _conmonPending.get(deviceIp);
  if (pending)
    return pending;
  const promise = _doConMonSession(deviceIp, timeoutMs).finally(() => {
    _conmonPending.delete(deviceIp);
  });
  _conmonPending.set(deviceIp, promise);
  return promise;
}
async function _doConMonSession(deviceIp, timeoutMs) {
  return new Promise((resolve) => {
    let settled = false;
    let keepaliveTimer = null;
    const closeSession = (sock2) => {
      if (keepaliveTimer) {
        clearInterval(keepaliveTimer);
        keepaliveTimer = null;
      }
      try {
        sock2.close();
      } catch {
      }
      logger5.debug(`ConMon session closed for ${deviceIp}`);
    };
    const fail = (sock2) => {
      if (settled)
        return;
      settled = true;
      clearTimeout(timer);
      closeSession(sock2);
      logger5.debug(`ConMon session not established for ${deviceIp}`);
      resolve(null);
    };
    const sock = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    const timer = setTimeout(() => fail(sock), timeoutMs);
    sock.on("error", (err) => {
      logger5.warn(`ConMon socket error for ${deviceIp}: ${err.message}`);
      fail(sock);
    });
    sock.on("message", (msg) => {
      if (!settled && msg.length >= 4 && msg[0] === 18 && msg[3] === 32) {
        settled = true;
        clearTimeout(timer);
        logger5.info(`ConMon session established with ${deviceIp}`);
        let keepaliveSeq = Math.floor(Math.random() * 65534) + 1;
        const sendKeepalive = () => {
          const pkt = Buffer.alloc(20, 0);
          pkt[0] = 18;
          pkt[3] = 78;
          pkt.writeUInt16BE(keepaliveSeq++ & 65535, 4);
          pkt[6] = 48;
          pkt[7] = 16;
          sock.send(pkt, 8800, deviceIp, () => {
          });
        };
        keepaliveTimer = setInterval(sendKeepalive, 1e3);
        resolve(() => closeSession(sock));
      }
    });
    const doInit = async () => {
      let localIp;
      let localMac;
      try {
        localIp = await getLocalAddressForDestination(deviceIp);
        localMac = await getMacForDestination(deviceIp);
      } catch (e) {
        logger5.warn(`ConMon: could not get local network info for ${deviceIp}: ${e}`);
        fail(sock);
        return;
      }
      sock.bind({ port: 8800, address: localIp }, () => {
        const seq = Math.floor(Math.random() * 65534) + 1;
        const pkt = Buffer.alloc(20, 0);
        pkt[0] = 18;
        pkt[3] = 20;
        pkt.writeUInt16BE(seq, 4);
        pkt[6] = 16;
        pkt[7] = 1;
        localMac.forEach((b, i) => {
          pkt[12 + i] = b;
        });
        logger5.debug(`ConMon TX to ${deviceIp}: ${pkt.toString("hex")}`);
        sock.send(pkt, 8800, deviceIp, (err) => {
          if (err) {
            logger5.warn(`ConMon send failed for ${deviceIp}: ${err.message}`);
            fail(sock);
          }
        });
      });
    };
    doInit().catch((e) => {
      logger5.warn(`ConMon init failed for ${deviceIp}: ${e}`);
      fail(sock);
    });
  });
}

// dist/stcontroller.js
var logger6 = createModuleLogger("StController");
var StController = class _StController {
  defaultPort = 8700;
  multicastGroup = "224.0.0.231";
  rxPort = 8702;
  txSocket;
  rxSocket;
  // for receiving responses (8702)
  rxMcastSocket = null;
  // diagnostic: tracks which responses arrive via multicast
  mcastDeliveries = /* @__PURE__ */ new Set();
  // keys seen on multicast socket this cycle
  pendingAcks = /* @__PURE__ */ new Map();
  joinedInterfaces = /* @__PURE__ */ new Set();
  // local IPs we've joined multicast on
  /** Serializes outgoing commands so each waits for ACK before the next is sent */
  sendQueue = Promise.resolve();
  /** Tracks how many commands are queued/in-flight, to defer requestAllSettings */
  pendingCommandCount = 0;
  /** Resolves once txSocket is bound and ready to send */
  txReady;
  /** Active device model and action definitions for settings decoding */
  model = "";
  actions = [];
  /**
   * Known state of every setting per device IP.
   * Keyed by IP → Map of "${cmdId}/${settingId}" → current value byte.
   * Populated on connect via requestAllSettings(), updated on every CMD_SETTINGS_PUSH (0x0b).
   * Used to diff incoming pushes (changed = info, unchanged = debug) and for feedbacks.
   */
  deviceState = /* @__PURE__ */ new Map();
  /**
   * IPs that have been verified against the configured model and are allowed
   * to receive Studio-T commands. Populated by authorizeDevice() after a
   * successful probeDevice() model match, or after multicast discovery.
   * _sendAwaitAck() rejects any destIp not in this set.
   */
  authorizedIps = /* @__PURE__ */ new Set();
  /** Callbacks registered for Dante 0x0170 device info responses — keyed by usage */
  discoveryListeners = /* @__PURE__ */ new Map();
  /** Callback to trigger feedback updates when state changes */
  feedbackCallback;
  /** Cache of local interface MAC bytes per destination IP, to avoid repeated OS lookups */
  macCache = /* @__PURE__ */ new Map();
  /** Tracks session readiness per IP — set for devices that established ConMon, and also
   *  for devices that don't require ConMon (useConMon not set), so the check is only done once. */
  sessionEstablished = /* @__PURE__ */ new Set();
  /** Cleanup functions returned by openConMonSession() — call to stop keepalives and close the socket */
  _conmonCleanups = /* @__PURE__ */ new Map();
  constructor() {
    logger6.info("StController initialized");
    this.txSocket = dgram3.createSocket({ type: "udp4", reuseAddr: true });
    this.txReady = new Promise((resolve) => {
      this.txSocket.bind(0, () => {
        logger6.debug(`TX socket bound to port ${this.txSocket.address().port}`);
        resolve();
      });
    });
    this.txSocket.on("error", (err) => {
      logger6.error(`TX socket error: ${err}`);
    });
    this.rxSocket = dgram3.createSocket({ type: "udp4", reuseAddr: true });
    this.rxSocket.on("listening", () => {
      const addr = this.rxSocket.address();
      logger6.debug(`RX socket listening on ${JSON.stringify(addr)}`);
      try {
        this.rxSocket.setMulticastLoopback(true);
      } catch (_e) {
      }
    });
    this.rxSocket.on("error", (err) => {
      logger6.error(`RX socket error: ${err}`);
    });
    this.rxSocket.on("message", (msg, rinfo) => {
      try {
        this.handleIncoming(msg, rinfo.address);
      } catch (_e) {
        logger6.error(`Error handling incoming message: ${_e}`);
      }
    });
    this.rxSocket.bind({ address: "0.0.0.0", port: this.rxPort }, () => {
      logger6.debug(`RX socket bound to 0.0.0.0:${this.rxPort}`);
      const ifaces = os2.networkInterfaces();
      for (const addrs of Object.values(ifaces)) {
        for (const addr of addrs ?? []) {
          if (addr.family === "IPv4" && !addr.internal && !this.joinedInterfaces.has(addr.address)) {
            try {
              this.rxSocket.addMembership(this.multicastGroup, addr.address);
              this.joinedInterfaces.add(addr.address);
              logger6.debug(`Pre-joined multicast ${this.multicastGroup} on ${addr.address}`);
            } catch (_e) {
              logger6.warn(`Could not pre-join multicast on ${addr.address}: ${String(_e)}`);
            }
          }
        }
      }
    });
    this.rxMcastSocket = dgram3.createSocket({ type: "udp4", reuseAddr: true });
    this.rxMcastSocket.on("error", (err) => {
      logger6.debug(`RX mcast socket error: ${err.message}`);
    });
    this.rxMcastSocket.on("message", (msg, rinfo) => {
      if (msg.length < 25)
        return;
      if (msg[0] !== 255 || msg[1] !== 255)
        return;
      const sig = msg.subarray(16, 24);
      if (sig.toString("ascii") !== "Studio-T")
        return;
      const stPayload = msg.subarray(24);
      if (stPayload.length < 2 || stPayload[0] !== 90)
        return;
      const respCmdId = stPayload[1];
      const isResponse = (respCmdId & 128) !== 0;
      const originalCmdId = respCmdId & 127;
      if (isResponse) {
        const key = `${rinfo.address}:${originalCmdId}`;
        const wasUnicastAlready = !this.mcastDeliveries.has(key);
        this.mcastDeliveries.add(key);
        logger6.debug(`Multicast delivery: ${rinfo.address} cmd:${toHex(originalCmdId)}` + (wasUnicastAlready ? " (unicast also pending)" : " (multicast only so far)"));
        setTimeout(() => this.mcastDeliveries.delete(key), 500);
      }
    });
    this.rxMcastSocket.bind({ address: this.multicastGroup, port: this.rxPort }, () => {
      logger6.debug(`RX mcast socket bound to ${this.multicastGroup}:${this.rxPort}`);
    });
  }
  close() {
    for (const cleanup of this._conmonCleanups.values()) {
      try {
        cleanup();
      } catch {
      }
    }
    this._conmonCleanups.clear();
    try {
      for (const localAddr of Array.from(this.joinedInterfaces)) {
        try {
          this.rxSocket.dropMembership(this.multicastGroup, localAddr);
        } catch {
        }
      }
    } catch {
    }
    try {
      this.rxMcastSocket?.close();
      this.rxMcastSocket = null;
    } catch {
    }
    try {
      this.rxSocket.close();
    } catch {
    }
    try {
      this.txSocket.close();
    } catch {
    }
  }
  /**
   * Provide the active device model and action definitions so incoming messages
   * can be decoded into human-readable names. Call from main.ts after config load.
   */
  setModel(model, actions) {
    this.model = model;
    this.actions = actions;
  }
  /**
   * Set callback to trigger when device state changes (for feedbacks).
   * Call from main.ts to wire up checkFeedbacks.
   */
  setFeedbackCallback(callback) {
    this.feedbackCallback = callback;
  }
  /** Returns true if the device at the given IP has been authorized to receive commands. */
  isDeviceAuthorized(ip) {
    return this.authorizedIps.has(ip);
  }
  /** Mark an IP as verified and allowed to receive Studio-T commands. */
  authorizeDevice(ip) {
    this.authorizedIps.add(ip);
    logger6.debug(`Authorized device at ${ip}`);
  }
  /** Remove authorization for an IP (e.g. on config change or model mismatch). */
  revokeDevice(ip) {
    this.authorizedIps.delete(ip);
    this.deviceState.delete(ip);
    this.macCache.delete(ip);
    this.sessionEstablished.delete(ip);
    this._conmonCleanups.get(ip)?.();
    this._conmonCleanups.delete(ip);
    logger6.debug(`Revoked device at ${ip}`);
  }
  /**
   * Opens a Dante ConMon session for the device if "useConMon": true is set in its
   * device JSON. Caches the result so the handshake only runs once per IP.
   * Delegates to conmon.ts. Devices without useConMon are marked as ready immediately.
   */
  async openSession(deviceIp) {
    if (this.sessionEstablished.has(deviceIp))
      return true;
    const schema = getDeviceSchema(this.model);
    if (!schema?.useConMon) {
      this.sessionEstablished.add(deviceIp);
      return true;
    }
    const cleanup = await openConMonSession(deviceIp);
    const success = cleanup !== null;
    this.sessionEstablished.add(deviceIp);
    if (success) {
      this._conmonCleanups.set(deviceIp, cleanup);
    }
    return success;
  }
  /**
   * Sends a unicast Dante info request to a specific IP and waits for the
   * device info response. Returns the DeviceInfo if the device responds within
   * timeoutMs, or null if no response. Used to verify a manually configured IP.
   * Does NOT require authorization — this is how authorization is established.
   */
  async probeDevice(ip, timeoutMs = 3e3) {
    await this.txReady;
    return probeDevice(this.txSocket, (key, cb) => this.discoveryListeners.set(key, cb), (key) => this.discoveryListeners.delete(key), async (destIp) => this.ensureMembershipFor(destIp), ip, timeoutMs);
  }
  /**
   * Send a CMD_GET_ALL_SETTINGS (0x0a) request to the device and store the response
   * in deviceState. Returns the raw response buffer for parsing.
   */
  async requestAllSettings(deviceIp) {
    logger6.info(`Requesting all settings from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_ALL_SETTINGS, void 0, void 0, void 0, deviceIp, false);
    return response;
  }
  /**
   * Discovers Studio Technologies Dante devices on the local network.
   *
   * Listens for Dante announces on 224.0.0.233:8708, sends unicast info requests
   * to each discovered IP, and collects 0x0170 responses via the rxSocket.
   */
  async discoverDevices(timeoutMs = 5e3) {
    const DISCOVERY_KEY = "__discovery__";
    const foundDevices = [];
    this.discoveryListeners.set(DISCOVERY_KEY, (device) => {
      if (!foundDevices.some((d) => d.ip === device.ip)) {
        foundDevices.push(device);
      }
    });
    try {
      await this.txReady;
      await discoverDevices(this.txSocket, async (destIp) => this.ensureMembershipFor(destIp), timeoutMs);
      return foundDevices;
    } finally {
      this.discoveryListeners.delete(DISCOVERY_KEY);
    }
  }
  /**
   * Requests device firmware version via Studio-T protocol (CMD_GET_FIRMWARE).
   * Returns the firmware version string (e.g., "3.01", "2.2", "1.05").
   */
  async requestFirmwareVersion(deviceIp) {
    logger6.info(`Requesting firmware version from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_FIRMWARE, void 0, void 0, void 0, deviceIp, false);
    const dataStart = 26;
    if (response.length < dataStart + 3) {
      logger6.warn(`Firmware response too short: ${response.length} bytes`);
      return "Unknown";
    }
    const major = response[dataStart + 1];
    const minor = response[dataStart + 2];
    const minorStr = minor < 10 ? minor.toString().padStart(2, "0") : minor.toString();
    const firmware = `${major}.${minorStr}`;
    logger6.debug(`Firmware version: ${firmware}`);
    return firmware;
  }
  /**
   * Joins the multicast response group on the interface that routes to destIp.
   * Only joins the specific interface used to reach the device, and only once per interface.
   */
  async ensureMembershipFor(destIp) {
    try {
      const localAddr = await getLocalAddressForDestination(destIp);
      if (!localAddr) {
        logger6.warn(`Could not determine local address for destination ${destIp}`);
        return;
      }
      if (this.joinedInterfaces.has(localAddr)) {
        return;
      }
      try {
        this.rxSocket.addMembership(this.multicastGroup, localAddr);
        this.joinedInterfaces.add(localAddr);
        logger6.info(`Joined multicast ${this.multicastGroup} on ${localAddr}`);
      } catch (_e) {
        logger6.warn(`Failed to join multicast on ${localAddr}: ${String(_e)}`);
      }
    } catch (_e) {
      logger6.warn(`ensureMembershipFor failed: ${_e}`);
    }
  }
  async sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    this.pendingCommandCount++;
    return new Promise((resolve, reject) => {
      this.sendQueue = this.sendQueue.then(async () => this._sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen).then((buf) => {
        this.pendingCommandCount--;
        if (this.pendingCommandCount === 0 && value !== void 0) {
          this.requestAllSettings(destIp).catch((err) => {
            logger6.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
        resolve(buf);
      }).catch((err) => {
        this.pendingCommandCount--;
        reject(err instanceof Error ? err : new Error(String(err)));
      }));
    });
  }
  async _sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    const timeoutMs = 2e3;
    const dataBlock = [];
    if (settingId !== void 0)
      dataBlock.push(settingId & 255);
    if (value !== void 0)
      dataBlock.push(..._StController.buildValueBytes(value));
    const payloadBody = [90, cmdId & 255];
    if (cmdId === CMD_MIC_PRE && busCh !== void 0 && settingId !== void 0 && value !== void 0) {
      if (!this.deviceState.has(destIp))
        this.deviceState.set(destIp, /* @__PURE__ */ new Map());
      const ipState = this.deviceState.get(destIp);
      const numPositions = 3;
      const positions = [];
      for (let i = 0; i < numPositions; i++) {
        const stateKey = makeSettingId(this.model, CMD_MIC_PRE, i, busCh);
        const val = i === settingId ? Number(value) : ipState.get(stateKey) ?? 0;
        positions.push(val);
        ipState.set(stateKey, val);
      }
      payloadBody.push(busCh & 255, ...positions);
    } else {
      if (busCh !== void 0)
        payloadBody.push(busCh & 255);
      if (addLen)
        payloadBody.push(dataBlock.length);
      if (dataBlock.length > 0)
        payloadBody.push(...dataBlock);
    }
    const crc = _StController.crc8DvbS2(payloadBody);
    const payloadWithCrc = Buffer.from([...payloadBody, crc]);
    if (settingId !== void 0 && value !== void 0) {
      const valueBytes = _StController.buildValueBytes(value);
      const setting = {
        cmd_id: cmdId,
        id: settingId,
        busCh,
        valueBytes
      };
      logger6.info(`TX ${destIp} | ${formatParsedSetting(setting, this.actions)}`);
    } else {
      logger6.info(`TX ${destIp} | ${getCommandName(cmdId)}`);
    }
    if (!this.authorizedIps.has(destIp)) {
      logger6.debug(`Packet (not sent \u2014 device not authorized) to ${destIp}: ${payloadWithCrc.toString("hex")}`);
      throw new Error(`Device at ${destIp} is not authorized \u2014 verify the IP and model match before sending commands`);
    }
    if (!this.sessionEstablished.has(destIp)) {
      await this.openSession(destIp);
    }
    await this.ensureMembershipFor(destIp);
    const totalLen = 24 + payloadWithCrc.length;
    const header = await this.buildHeader(totalLen, destIp);
    const packet = Buffer.concat([header, payloadWithCrc]);
    logger6.debug(`Sending packet to ${destIp}: ${packet.toString("hex")}`);
    const key = `${destIp}:${cmdId}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingAcks.delete(key);
        reject(new Error(`Timeout waiting for ACK from Model ${this.model} at ${destIp}:8700`));
      }, timeoutMs);
      this.pendingAcks.set(key, {
        resolve: (buf) => {
          clearTimeout(timer);
          resolve(buf);
        },
        reject: (err) => {
          clearTimeout(timer);
          reject(err);
        },
        timer
      });
      this.txSocket.send(packet, this.defaultPort, destIp, (err) => {
        if (err) {
          this.pendingAcks.delete(key);
          clearTimeout(timer);
          reject(new Error(err.message ?? String(err)));
        }
      });
    });
  }
  handleIncoming(msg, srcIp) {
    if (msg.length < 4)
      return;
    if (msg[0] !== 255 || msg[1] !== 255)
      return;
    const msgType = msg.readUInt16BE(2);
    if (msgType === DANTE_MSG_INFO_RESPONSE && this.discoveryListeners.size > 0) {
      const device = parseDanteInfoResponse(msg, srcIp);
      if (device) {
        logger6.debug(`Dante info response from ${srcIp}: DeviceID="${device.name}", Model="${device.model}", ModelName="${device.modelName}", Manufacturer="${device.manufacturer}"`);
        if (device.name === "Studio-T") {
          for (const cb of this.discoveryListeners.values()) {
            try {
              cb(device);
            } catch {
            }
          }
        } else {
          logger6.debug(`Ignoring non-Studio Technologies device: DeviceID="${device.name}" @ ${srcIp}`);
        }
      }
      return;
    }
    if (msg.length < 25)
      return;
    const sig = msg.subarray(16, 24);
    if (sig.toString("ascii") !== "Studio-T")
      return;
    if (!this.authorizedIps.has(srcIp)) {
      logger6.debug(`Ignoring Studio-T packet from unauthorized device ${srcIp}`);
      return;
    }
    const stPayload = msg.subarray(24);
    if (stPayload.length < 2)
      return;
    if (stPayload[0] !== 90)
      return;
    const respCmdId = stPayload[1];
    const isResponse = (respCmdId & 128) !== 0;
    const originalCmdId = respCmdId & 127;
    if (isResponse) {
      const key = `${srcIp}:${originalCmdId}`;
      const pending = this.pendingAcks.get(key);
      if (pending) {
        this.pendingAcks.delete(key);
        const viaMulticast = this.mcastDeliveries.has(key);
        logger6.debug(`RX delivery method: ${srcIp} cmd:${toHex(originalCmdId)} via ${viaMulticast ? "multicast" : "unicast"}`);
        if (originalCmdId === CMD_GET_ALL_SETTINGS) {
          logger6.debug(`Received packet from ${srcIp}: ${msg.toString("hex")}`);
        }
        this.logStPayload(srcIp, originalCmdId, msg, stPayload);
        pending.resolve(msg);
      } else if (originalCmdId === CMD_SETTINGS_PUSH) {
        this.logStPayload(srcIp, originalCmdId, msg, stPayload);
      }
    } else {
      this.logStPayload(srcIp, originalCmdId, msg, stPayload);
    }
  }
  /**
   * Decodes and logs a Studio-T response payload.
   * Receives both the full msg (for parsers that need the Studio-T header)
   * and stPayload (msg.subarray(24), for direct byte access).
   *
   * stPayload layout:
   *   [0]      0x5a  magic
   *   [1]      cmdId | 0x80
   *   [2..-2]  data bytes
   *   [-1]     CRC-8/DVB-S2
   */
  logStPayload(srcIp, cmdId, msg, stPayload) {
    const cmdName = getCommandName(cmdId);
    const data = stPayload.subarray(2, stPayload.length - 1);
    const respCmdId = stPayload[1];
    const crc = stPayload[stPayload.length - 1];
    const fullStructure = `[cmd:${toHex(respCmdId)} data:${data.toString("hex")} crc:${toHex(crc)}]`;
    if (cmdId === CMD_GET_ALL_SETTINGS || cmdId === CMD_SETTINGS_PUSH) {
      if (!this.model) {
        logger6.info(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
        return;
      }
      try {
        const settings = cmdId === CMD_SETTINGS_PUSH ? parseSettingsResponse(this.model, msg) : parseGetAllSettingsForModel(this.model, msg);
        const prevState = this.deviceState.get(srcIp) ?? /* @__PURE__ */ new Map();
        const newState = new Map(prevState);
        for (const s of settings) {
          const stateKey = makeSettingId(this.model, s.cmd_id, s.id, s.busCh);
          const newValue = s.valueBytes.length === 3 ? s.valueBytes[0] << 16 | s.valueBytes[1] << 8 | s.valueBytes[2] : s.valueBytes[0] ?? 0;
          const prevValue = prevState.get(stateKey);
          const changed = prevValue === void 0 || prevValue !== newValue;
          newState.set(stateKey, newValue);
          const formatted = formatParsedSetting(s, this.actions);
          if (changed) {
            logger6.info(`RX ${srcIp} | ${formatted}`);
            if (this.feedbackCallback) {
              let baseId = s.id;
              const baseAction = this.actions.find((a) => {
                if (a.cmd_id !== s.cmd_id)
                  return false;
                if (a.id === s.id)
                  return true;
                const idAddOption = a.options?.find((o) => o.id === "idAdd");
                if (!idAddOption?.choices)
                  return false;
                const offset = s.id - a.id;
                return offset > 0 && idAddOption.choices.some((c) => c.id === offset);
              });
              if (baseAction)
                baseId = baseAction.id;
              const baseFeedbackKey = makeSettingId(this.model, s.cmd_id, baseId);
              this.feedbackCallback(baseFeedbackKey);
              this.feedbackCallback(baseFeedbackKey + "_bool");
            } else {
              logger6.warn(`feedbackCallback not set \u2014 skipping feedback update for ${stateKey}`);
            }
          } else {
            logger6.debug(`RX ${srcIp} | ${formatted}`);
          }
        }
        this.deviceState.set(srcIp, newState);
      } catch (e) {
        logger6.warn(`RX ${srcIp} | ${cmdName} | parse failed: ${e} | ${fullStructure}`);
      }
      return;
    }
    const decoded = this.decodeStData(cmdId, data);
    const logFn = cmdId === CMD_BUS_GET ? logger6.debug.bind(logger6) : logger6.info.bind(logger6);
    if (decoded) {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure} | ${decoded}`);
    } else {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
    }
  }
  /**
   * Attempts to decode the data bytes of a Studio-T response into a
   * human-readable string. Returns null to fall back to raw hex.
   */
  decodeStData(cmdId, data) {
    if (data.length === 0)
      return "ACK";
    if (data.length === 1) {
      if (data[0] === 0) {
        return "ACK ok";
      } else {
        return `ERROR ${toHex(data[0])}`;
      }
    }
    switch (cmdId) {
      // ── CMD_MIC_PRE (0x02): raw preamp echo — positional bytes, no setting IDs ──
      // Device echoes [busCh][val0][val1]... confirming the applied values.
      case CMD_MIC_PRE: {
        const busCh = data[0];
        const vals = Array.from(data.subarray(1)).map((b, i) => `[${i}]=0x${b.toString(16).padStart(2, "0")}(${b})`).join(" ");
        return `ch=${busCh} ${vals}`;
      }
      // ── CMD_DEV_SPEC (0x0d): single-byte ACK or echo of applied setting ──
      // Device sends two CMD_DEV_SPEC packets in response to a set:
      //   1. ACK:  [status]               (1 byte, 0x00 = ok)
      //   2. Echo: [busCh] [settingId] [value...]  (confirming what was applied)
      case CMD_DEV_SPEC: {
        if (data.length === 1) {
          return data[0] === 0 ? "ACK ok" : `ACK err=${toHex(data[0])}`;
        }
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const choices = action?.options?.[0]?.choices;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ? `${choiceLabel} (${toHex(valueNum)})` : bytesToHex(Array.from(valueBytes));
          const rawTag = `[${toHex(cmdId)}/${toHex(settingId)}]=${bytesToHex(Array.from(valueBytes))}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr} ${rawTag}`;
        }
        return `raw: ${data.toString("hex")}`;
      }
      // ── CMD_MIC_PRE_BUS (0x12): Multi-byte echo responses ─────────────
      case CMD_MIC_PRE_BUS: {
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choices = action?.options?.find((o) => o.id === "value")?.choices;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ?? `0x${valueBytes.toString("hex")}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr}`;
        }
        return null;
      }
      // ── Bus-scoped get/set ────────────────────────────────────────────
      case CMD_BUS_GET:
      case CMD_BUS_SET: {
        if (data.length < 2)
          return null;
        const busCh = data[0];
        const settingId = data[1];
        const value = data.subarray(2);
        return `ch=${busCh} setting=${toHex(settingId)} value=${value.toString("hex")}`;
      }
      default:
        return null;
    }
  }
  static buildValueBytes(value) {
    if (typeof value === "boolean")
      return [value ? 1 : 0];
    if (Array.isArray(value))
      return value.map((v) => Number(v) & 255);
    if (typeof value === "number") {
      if (value > 255)
        return [value >> 16 & 255, value >> 8 & 255, value & 255];
      return [value & 255];
    }
    throw new Error(`Unsupported value type for STcontroller: ${value}`);
  }
  async buildHeader(totalLen, destIp) {
    let mac = this.macCache.get(destIp);
    if (!mac) {
      mac = await getMacForDestination(destIp);
      this.macCache.set(destIp, mac);
    }
    return Buffer.concat([
      Buffer.from([255, 255, 0, totalLen & 255, 7, 225, 0, 0, ...mac, 0, 0]),
      Buffer.from("Studio-T", "utf8")
    ]);
  }
  static crc8DvbS2(data) {
    let crc = 0;
    for (const b of data) {
      crc ^= b;
      for (let i = 0; i < 8; i++) {
        crc = (crc & 128) !== 0 ? (crc << 1 ^ 213) & 255 : crc << 1 & 255;
      }
    }
    return crc;
  }
  /**
   * Returns the current known value for a setting on a device, or undefined if unknown.
   * Use for feedbacks — value is updated on every CMD_SETTINGS_PUSH (0x0b) from the device.
   *
   * @param ip        Device IP address
   * @param cmdId     Command ID (e.g. CMD_DEV_SPEC)
   * @param settingId Setting ID (e.g. 0x02 for Control Source)
   * @param busCh     Optional bus/channel ID for multi-channel commands
   */
  getSettingValue(ip, cmdId, settingId, busCh) {
    const key = makeSettingId(this.model, cmdId, settingId, busCh);
    return this.deviceState.get(ip)?.get(key);
  }
  async resetDevice(destIp) {
    return this.sendAwaitAck(CMD_RESET_DEVICE, void 0, 0, void 0, destIp, false);
  }
  async globalMicKill(destIp) {
    return this.sendAwaitAck(CMD_GLOBAL_MIC_KILL, void 0, void 0, void 0, destIp, false);
  }
};

// dist/main.js
var logger7 = createModuleLogger("ModuleInstance");
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  stController;
  /** Cached discovery results — passed into getConfigFields() so the UI
   *  can show the discovered device dropdown on subsequent config opens. */
  discoveredDevices = [];
  /** Currently active model — resolved once in syncModel() and cached here
   *  so UpdateActions, UpdateFeedbacks etc. don't each call resolveModel independently. */
  activeModel = "";
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    if (!this.stController) {
      this.stController = new StController();
    }
    this.updateStatus(InstanceStatus.Connecting, "Discovering devices...");
    this.stController.setFeedbackCallback((feedbackId) => {
      this.checkFeedbacks(feedbackId);
    });
    this.runDiscovery().catch((e) => {
      logger7.error(`Discovery failed: ${e}`);
    });
  }
  /**
   * Run device discovery, then resolve the model and update all UI.
   * - If discovery finds devices, resolveModel picks from those.
   * - Only if the list is empty do we fall back to the manual config selection.
   * All actions/feedbacks/variables are built after the model is known.
   */
  async runDiscovery() {
    logger7.info("Starting device discovery...");
    this.discoveredDevices = await this.stController.discoverDevices();
    let effectiveModel;
    if (this.discoveredDevices.length === 0) {
      if (this.config.deviceMac) {
        logger7.warn(`Saved device MAC "${this.config.deviceMac}" not found during discovery \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `[${this.config.deviceMac}] not found`);
        return;
      }
      const manualModel = this.config.activeModel;
      if (!this.config.host || !manualModel) {
        logger7.warn("No devices discovered and no manual IP/model configured");
        return;
      }
      logger7.info("No devices discovered \u2014 will probe manual IP during authorization");
      effectiveModel = manualModel;
    } else {
      logger7.info(`Discovered ${this.discoveredDevices.length} device(s):`);
      for (const d of this.discoveredDevices) {
        logger7.info(`  - Model ${d.model} ${d.manufacturer ?? ""} @ ${d.ip}`);
      }
      for (const device of this.discoveredDevices) {
        this.stController.authorizeDevice(device.ip);
      }
      for (const device of this.discoveredDevices) {
        try {
          const firmware = await this.stController.requestFirmwareVersion(device.ip);
          device.firmwareMain = firmware;
          logger7.info(`  - ${device.ip}: Firmware ${firmware}, Dante ${device.danteFirmware}`);
        } catch (e) {
          logger7.warn(`  - ${device.ip}: Failed to get firmware: ${e}`);
          device.firmwareMain = "Unknown";
        }
      }
      effectiveModel = resolveModel(this.config, this.discoveredDevices);
      if (!effectiveModel && this.config.deviceMac) {
        logger7.warn(`Saved device MAC "${this.config.deviceMac}" not found among discovered devices \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `[${this.config.deviceMac}] not found`);
        return;
      }
    }
    this.syncModel(effectiveModel);
    const targetHost = this.host;
    await this.verifyAuthorization("", targetHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
    logger7.info("Device discovery complete");
  }
  // When module gets deleted
  async destroy() {
    this.stController?.close();
    logger7.debug("destroy");
  }
  async configUpdated(config) {
    const previousHost = this.host;
    this.config = config;
    const effectiveModel = resolveModel(config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.updateVariableValues();
    const newHost = this.host;
    await this.verifyAuthorization(previousHost, newHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
  }
  /**
   * Re-evaluates whether the current config is authorized to send commands.
   *
   * Auto mode (deviceMac set):
   *   - Find the discovered device with matching MAC → get its current IP
   *   - Revoke the previous IP, authorize the new IP
   *   - If MAC not found in discovery, revoke and block
   *
   * Manual mode (deviceMac empty):
   *   - Check discovered list by IP+model match, or probe directly
   */
  async verifyAuthorization(previousHost, newHost) {
    if (!newHost) {
      if (previousHost)
        this.stController.revokeDevice(previousHost);
      return;
    }
    if (this.config.deviceMac) {
      const device = this.discoveredDevices.find((d) => d.mac === this.config.deviceMac);
      if (!device) {
        logger7.warn(`Device MAC "${this.config.deviceMac}" not found in current discovery \u2014 not authorizing`);
        if (previousHost)
          this.stController.revokeDevice(previousHost);
        return;
      }
      if (previousHost && previousHost !== newHost) {
        this.stController.revokeDevice(previousHost);
      }
      const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
      if (!wasAuthorized) {
        this.stController.authorizeDevice(newHost);
      }
      if (newHost !== previousHost || !wasAuthorized) {
        await this.fetchSettingsAndEnsureSchema(device.model, newHost);
      }
      this.updateStatus(InstanceStatus.Ok, `Model ${device.model} @ ${newHost}`);
      return;
    }
    const manualModel = String(this.config.activeModel ?? "");
    const discoveredAtIp = this.discoveredDevices.find((d) => d.ip === newHost);
    if (discoveredAtIp) {
      if (discoveredAtIp.model === manualModel) {
        if (previousHost && previousHost !== newHost)
          this.stController.revokeDevice(previousHost);
        const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
        if (!wasAuthorized) {
          this.stController.authorizeDevice(newHost);
        }
        if (newHost !== previousHost || !wasAuthorized) {
          await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
        }
        this.updateStatus(InstanceStatus.Ok, `Model ${manualModel} @ ${newHost}`);
      } else {
        logger7.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${discoveredAtIp.model}) at ${newHost} \u2014 commands blocked`);
        this.stController.revokeDevice(newHost);
        this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${discoveredAtIp.model}`);
      }
      return;
    }
    logger7.info(`${newHost} not in discovered list \u2014 probing`);
    if (previousHost && previousHost !== newHost)
      this.stController.revokeDevice(previousHost);
    this.stController.revokeDevice(newHost);
    const probed = await this.stController.probeDevice(newHost);
    if (!probed) {
      logger7.error(`No device responded at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.UnknownWarning, `Device offline: ${newHost}`);
    } else if (probed.model !== manualModel) {
      logger7.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${probed.model}) at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${probed.model}`);
    } else {
      logger7.info(`Verified Model ${probed.model} at ${newHost}`);
      this.stController.authorizeDevice(newHost);
      await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
      this.updateStatus(InstanceStatus.Ok, `Model ${probed.model} @ ${newHost}`);
    }
  }
  /**
   * Fetches all settings from the device. If no schema exists for the model,
   * creates one from the response and reloads the schema cache.
   */
  async fetchSettingsAndEnsureSchema(model, ip) {
    try {
      await this.stController.requestAllSettings(ip);
      if (!getDeviceSchema(model)) {
        logger7.warn(`No schema found for Model ${model} \u2014 run "GLOBAL: Get All Settings" to create one`);
        return;
      }
    } catch (e) {
      logger7.warn(`Failed to fetch settings from ${ip}: ${e}`);
    }
  }
  /** Loads the device JSON for the given model, caches it as activeModel, and pushes it to the controller. */
  syncModel(model) {
    this.activeModel = model;
    const schema = getDeviceSchema(model);
    if (!schema) {
      logger7.warn(`Model "${model}" not found in device schemas`);
      this.stController.setModel(model, []);
      return;
    }
    const actions = Array.isArray(schema.cmdSchema) ? schema.cmdSchema : [];
    this.stController.setModel(model, actions);
    if (actions.length === 0) {
      logger7.warn(`No actions found for model "${model}" \u2014 settings decoding will use raw IDs`);
    } else {
      logger7.debug(`Loaded ${actions.length} actions for model "${model}"`);
    }
  }
  getConfigFields() {
    return GetConfigFields(this.discoveredDevices);
  }
  /** Returns the effective host IP, resolved from MAC→IP via discoveredDevices (auto) or config.host (manual). */
  get host() {
    return resolveHost(this.config, this.discoveredDevices);
  }
  /** Returns discovered devices for use in actions/config */
  get devices() {
    return this.discoveredDevices;
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  updateVariableValues() {
    UpdateVariableValues(this);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2xvZ2dpbmcudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL3V0aWwudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvc2hhcmVkLXVkcC1zb2NrZXQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2hvc3QtYXBpL2NvbnRleHQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvYmFzZS50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9lbnVtcy50cyIsICIuLi8uLi9zcmMvY29uZmlnLnRzIiwgIi4uLy4uL3NyYy92YXJpYWJsZXMudHMiLCAiLi4vLi4vc3JjL3VwZ3JhZGVzLnRzIiwgIi4uLy4uL3NyYy90eXBlcy50cyIsICIuLi8uLi9zcmMvYnVpbGQtY29tbWFuZHMudHMiLCAiLi4vLi4vc3JjL2FjdGlvbnMudHMiLCAiLi4vLi4vc3JjL3NldHRpbmdzUGFyc2VyLnRzIiwgIi4uLy4uL3NyYy9mZWVkYmFja3MudHMiLCAiLi4vLi4vc3JjL3N0Y29udHJvbGxlci50cyIsICIuLi8uLi9zcmMvZGFudGUudHMiLCAiLi4vLi4vc3JjL2Nvbm1vbi50cyIsICIuLi8uLi9zcmMvbWFpbi50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFtudWxsLCBudWxsLCBudWxsLCBudWxsLCBudWxsLCBudWxsLCAiaW1wb3J0IGZzIGZyb20gJ2ZzJ1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCdcbmltcG9ydCB7IFJlZ2V4LCB0eXBlIFNvbWVDb21wYW5pb25Db25maWdGaWVsZCwgdHlwZSBKc29uT2JqZWN0LCBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHR5cGUgeyBEZXZpY2VJbmZvIH0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdDb25maWcnKVxuXG5leHBvcnQgdHlwZSBNb2R1bGVDb25maWcgPSBKc29uT2JqZWN0ICYge1xuXHQvKiogTUFDIG9mIHRoZSBzZWxlY3RlZCBkaXNjb3ZlcmVkIGRldmljZSAoZS5nLiBcIjAwOjFkOmMxOjliOmE2OmNkXCIpLCBvciAnJyBmb3IgbWFudWFsIG1vZGUgKi9cblx0ZGV2aWNlTWFjOiBzdHJpbmdcblx0LyoqIE1hbnVhbCBJUCBhZGRyZXNzIFx1MjAxNCBvbmx5IHVzZWQgd2hlbiBkZXZpY2VNYWMgaXMgJycgKi9cblx0aG9zdDogc3RyaW5nXG5cdC8qKiBNYW51YWwgbW9kZWwgc2VsZWN0aW9uIFx1MjAxNCBvbmx5IHVzZWQgd2hlbiBkZXZpY2VNYWMgaXMgJycgKi9cblx0YWN0aXZlTW9kZWw6IHN0cmluZ1xuXHQvKiogRW5hYmxlIHBhcnNpbmcgb2YgdW5zdXBwb3J0ZWQgU1QgZGV2aWNlcyAqL1xuXHRkZXZNb2RlOiBib29sZWFuXG59XG5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbi8vIENFTlRSQUxJWkVEIERFVklDRSBTQ0hFTUEgQ0FDSEVcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbi8vIEFsbCBkZXZpY2UgSlNPTiBmaWxlcyBhcmUgbG9hZGVkIG9uY2UgaW50byBtZW1vcnkgaGVyZS4gT3RoZXIgbW9kdWxlcyBzaG91bGRcbi8vIHVzZSBnZXREZXZpY2VzRm9sZGVyKCksIGdldERldmljZVNjaGVtYXMoKSwgYW5kIGdldERldmljZVNjaGVtYSgpIGluc3RlYWQgb2Zcbi8vIHJlYWRpbmcgZmlsZXMgZGlyZWN0bHkuIENhbGwgcmVsb2FkRGV2aWNlU2NoZW1hcygpIGFmdGVyIHdyaXRpbmcgdG8gYSBmaWxlLlxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuXG4vKipcbiAqIERldGVybWluZXMgdGhlIGNvcnJlY3QgZGV2aWNlcyBmb2xkZXIgcGF0aCB3aXRoIGZhbGxiYWNrIHN1cHBvcnQuXG4gKiBDaGVja3MgcHJpbWFyeSBwYXRoIGZpcnN0LCB0aGVuIGZhbGxiYWNrLCB0aGVuIHRocm93cyBlcnJvciBpZiBuZWl0aGVyIGV4aXN0cy5cbiAqL1xuZnVuY3Rpb24gcmVzb2x2ZURldmljZXNGb2xkZXIoKTogc3RyaW5nIHtcblx0Y29uc3QgcHJpbWFyeVBhdGggPSBwYXRoLmpvaW4oaW1wb3J0Lm1ldGEuZGlybmFtZSwgJy4uL2RldmljZXMnKVxuXHRjb25zdCBmYWxsYmFja1BhdGggPSBwYXRoLmpvaW4oaW1wb3J0Lm1ldGEuZGlybmFtZSwgJy4vZGV2aWNlcycpXG5cblx0Ly8gQ2hlY2sgcHJpbWFyeSBwYXRoXG5cdGlmIChmcy5leGlzdHNTeW5jKHByaW1hcnlQYXRoKSkge1xuXHRcdGxvZ2dlci5kZWJ1ZyhgVXNpbmcgZGV2aWNlcyBmb2xkZXI6ICR7cHJpbWFyeVBhdGh9YClcblx0XHRyZXR1cm4gcHJpbWFyeVBhdGhcblx0fVxuXG5cdC8vIENoZWNrIGZhbGxiYWNrIHBhdGhcblx0aWYgKGZzLmV4aXN0c1N5bmMoZmFsbGJhY2tQYXRoKSkge1xuXHRcdGxvZ2dlci53YXJuKGBQcmltYXJ5IGRldmljZXMgZm9sZGVyIG5vdCBmb3VuZCwgdXNpbmcgZmFsbGJhY2s6ICR7ZmFsbGJhY2tQYXRofWApXG5cdFx0cmV0dXJuIGZhbGxiYWNrUGF0aFxuXHR9XG5cblx0Ly8gTmVpdGhlciBwYXRoIGV4aXN0cyAtIGZhdGFsIGVycm9yXG5cdGNvbnN0IGVycm9yTXNnID0gYERldmljZXMgZm9sZGVyIG5vdCBmb3VuZCFcXG5UcmllZDpcXG4gIC0gJHtwcmltYXJ5UGF0aH1cXG4gIC0gJHtmYWxsYmFja1BhdGh9XFxuTW9kdWxlIGNhbm5vdCBjb250aW51ZSB3aXRob3V0IGRldmljZSBzY2hlbWFzLmBcblx0bG9nZ2VyLmVycm9yKGVycm9yTXNnKVxuXHR0aHJvdyBuZXcgRXJyb3IoZXJyb3JNc2cpXG59XG5cbi8vIFJlc29sdmUgdGhlIGRldmljZXMgZm9sZGVyIHBhdGggKHdpdGggZXhpc3RlbmNlIGNoZWNrIGFuZCBmYWxsYmFjaylcbmNvbnN0IGRldmljZXNGb2xkZXIgPSByZXNvbHZlRGV2aWNlc0ZvbGRlcigpXG5cbi8vIEluLW1lbW9yeSBjYWNoZSBvZiBhbGwgZGV2aWNlIHNjaGVtYXMsIGtleWVkIGJ5IG1vZGVsIG51bWJlclxubGV0IGRldmljZVNjaGVtYXNDYWNoZTogUmVjb3JkPHN0cmluZywgYW55PiB8IG51bGwgPSBudWxsXG5cbi8qKlxuICogUmV0dXJucyB0aGUgYWJzb2x1dGUgcGF0aCB0byB0aGUgZGV2aWNlcyBmb2xkZXIuXG4gKiBVc2UgdGhpcyBpbnN0ZWFkIG9mIHJlZGVmaW5pbmcgdGhlIHBhdGggaW4gZXZlcnkgZmlsZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldERldmljZXNGb2xkZXIoKTogc3RyaW5nIHtcblx0cmV0dXJuIGRldmljZXNGb2xkZXJcbn1cblxuLyoqXG4gKiBMb2FkcyBhbGwgZGV2aWNlIEpTT04gZmlsZXMgZnJvbSB0aGUgZGV2aWNlcyBmb2xkZXIgaW50byBtZW1vcnkuXG4gKiBUaGlzIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBvbmNlIGF0IGluaXRpYWxpemF0aW9uLCBvciBhZnRlciBhIGZpbGUgaXMgd3JpdHRlbi5cbiAqL1xuZnVuY3Rpb24gbG9hZERldmljZVNjaGVtYXMoKTogUmVjb3JkPHN0cmluZywgYW55PiB7XG5cdGNvbnN0IHNjaGVtYXM6IFJlY29yZDxzdHJpbmcsIGFueT4gPSB7fVxuXHR0cnkge1xuXHRcdGNvbnN0IGZpbGVzID0gZnMucmVhZGRpclN5bmMoZGV2aWNlc0ZvbGRlcikuZmlsdGVyKChmKSA9PiBmLmVuZHNXaXRoKCcuanNvbicpKVxuXG5cdFx0Zm9yIChjb25zdCBmIG9mIGZpbGVzKSB7XG5cdFx0XHRjb25zdCBmdWxsUGF0aCA9IHBhdGguam9pbihkZXZpY2VzRm9sZGVyLCBmKVxuXHRcdFx0Y29uc3QganNvbiA9IEpTT04ucGFyc2UoZnMucmVhZEZpbGVTeW5jKGZ1bGxQYXRoLCAndXRmOCcpKVxuXHRcdFx0aWYgKGpzb24/Lm1vZGVsKSB7XG5cdFx0XHRcdHNjaGVtYXNbU3RyaW5nKGpzb24ubW9kZWwpXSA9IGpzb25cblx0XHRcdH1cblx0XHR9XG5cblx0XHRsb2dnZXIuZGVidWcoYExvYWRlZCAke09iamVjdC5rZXlzKHNjaGVtYXMpLmxlbmd0aH0gZGV2aWNlIHNjaGVtYXMgaW50byBjYWNoZWApXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRsb2dnZXIuZXJyb3IoYEZhaWxlZCB0byBsb2FkIGRldmljZSBzY2hlbWFzOiAke2V9YClcblx0fVxuXHRyZXR1cm4gc2NoZW1hc1xufVxuXG4vKipcbiAqIFJldHVybnMgYWxsIGRldmljZSBzY2hlbWFzIGZyb20gdGhlIGNhY2hlLlxuICogSW5pdGlhbGl6ZXMgdGhlIGNhY2hlIG9uIGZpcnN0IGNhbGwuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREZXZpY2VTY2hlbWFzKCk6IFJlY29yZDxzdHJpbmcsIGFueT4ge1xuXHRpZiAoIWRldmljZVNjaGVtYXNDYWNoZSkge1xuXHRcdGRldmljZVNjaGVtYXNDYWNoZSA9IGxvYWREZXZpY2VTY2hlbWFzKClcblx0fVxuXHRyZXR1cm4gZGV2aWNlU2NoZW1hc0NhY2hlXG59XG5cbi8qKlxuICogUmV0dXJucyBhIHNwZWNpZmljIGRldmljZSBzY2hlbWEgYnkgbW9kZWwgbnVtYmVyLlxuICogUmV0dXJucyB1bmRlZmluZWQgaWYgdGhlIG1vZGVsIGRvZXNuJ3QgZXhpc3QuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREZXZpY2VTY2hlbWEobW9kZWw6IHN0cmluZyk6IGFueSB7XG5cdGNvbnN0IHNjaGVtYXMgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0cmV0dXJuIHNjaGVtYXNbbW9kZWxdXG59XG5cbi8qKlxuICogUmVsb2FkcyBhbGwgZGV2aWNlIHNjaGVtYXMgZnJvbSBkaXNrLlxuICogQ2FsbCB0aGlzIGFmdGVyIHdyaXRpbmcgdG8gYSBkZXZpY2UgSlNPTiBmaWxlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVsb2FkRGV2aWNlU2NoZW1hcygpOiB2b2lkIHtcblx0bG9nZ2VyLmluZm8oJ1JlbG9hZGluZyBkZXZpY2Ugc2NoZW1hcyBmcm9tIGRpc2suLi4nKVxuXHRkZXZpY2VTY2hlbWFzQ2FjaGUgPSBsb2FkRGV2aWNlU2NoZW1hcygpXG59XG5cbi8qKlxuICogUmV0dXJucyBhIGxpc3Qgb2YgYXZhaWxhYmxlIG1vZGVsIG51bWJlcnMsIHNvcnRlZC5cbiAqL1xuZnVuY3Rpb24gbG9hZEF2YWlsYWJsZU1vZGVscygpOiBzdHJpbmdbXSB7XG5cdGNvbnN0IHNjaGVtYXMgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0cmV0dXJuIE9iamVjdC5rZXlzKHNjaGVtYXMpLnNvcnQoKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gR2V0Q29uZmlnRmllbGRzKGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10gPSBbXSk6IFNvbWVDb21wYW5pb25Db25maWdGaWVsZFtdIHtcblx0Y29uc3QgbW9kZWxzID0gbG9hZEF2YWlsYWJsZU1vZGVscygpXG5cblx0Ly8gRHJvcGRvd24gaWQgaXMgdGhlIGRldmljZSBNQUMgXHUyMDE0IHN0YWJsZSBhY3Jvc3MgSVAgY2hhbmdlcy5cblx0Ly8gRW1wdHkgaWQgPSBNYW51YWwgbW9kZS5cblx0Y29uc3QgZGV2aWNlQ2hvaWNlcyA9IFtcblx0XHR7IGlkOiAnJywgbGFiZWw6ICdNYW51YWwgKGVudGVyIElQICsgbW9kZWwgYmVsb3cpJyB9LFxuXHRcdC4uLmRpc2NvdmVyZWREZXZpY2VzLm1hcCgoZCkgPT4gKHtcblx0XHRcdGlkOiBkLm1hYyA/PyAnJyxcblx0XHRcdGxhYmVsOiBgTW9kZWwgJHtkLm1vZGVsfSBbJHtkLm1hY31dIEAgJHtkLmlwfWAsXG5cdFx0fSkpLFxuXHRdXG5cblx0cmV0dXJuIFtcblx0XHQvLyBcdTI1MDBcdTI1MDAgRGV2aWNlIHNlbGVjdGlvbiBkcm9wZG93biBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBTdG9yZXMgdGhlIE1BQyBzbyByZS1kaXNjb3Zlcnkgd2l0aCBhIGNoYW5nZWQgSVAgc3RpbGwgbWF0Y2hlcy5cblx0XHR7XG5cdFx0XHR0eXBlOiAnZHJvcGRvd24nLFxuXHRcdFx0aWQ6ICdkZXZpY2VNYWMnLFxuXHRcdFx0bGFiZWw6ICdEZXZpY2UnLFxuXHRcdFx0d2lkdGg6IDgsXG5cdFx0XHRkZWZhdWx0OiAnJyxcblx0XHRcdGNob2ljZXM6IGRldmljZUNob2ljZXMsXG5cdFx0XHR0b29sdGlwOiAnU2VsZWN0IGFuIGF1dG8tZGlzY292ZXJlZCBTdHVkaW8gVGVjaG5vbG9naWVzIGRldmljZSwgb3IgY2hvb3NlIE1hbnVhbCB0byBlbnRlciBhbiBJUCBhZGRyZXNzLicsXG5cdFx0fSxcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBNYW51YWwgSVAgZW50cnkgXHUyMDE0IG9ubHkgdmlzaWJsZSBpbiBtYW51YWwgbW9kZSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHR7XG5cdFx0XHR0eXBlOiAndGV4dGlucHV0Jyxcblx0XHRcdGlkOiAnaG9zdCcsXG5cdFx0XHRsYWJlbDogJ1RhcmdldCBJUCcsXG5cdFx0XHR3aWR0aDogOCxcblx0XHRcdGRlZmF1bHQ6ICcnLFxuXHRcdFx0cmVnZXg6IFJlZ2V4LklQLFxuXHRcdFx0aXNWaXNpYmxlRXhwcmVzc2lvbjogYCEkKG9wdGlvbnM6ZGV2aWNlTWFjKWAsXG5cdFx0XHR0b29sdGlwOiAnRW50ZXIgdGhlIElQIGFkZHJlc3Mgb2YgdGhlIGRldmljZSBtYW51YWxseS4nLFxuXHRcdH0sXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgTWFudWFsIG1vZGVsIHNlbGVjdG9yIFx1MjAxNCBvbmx5IHZpc2libGUgaW4gbWFudWFsIG1vZGUgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdGlkOiAnYWN0aXZlTW9kZWwnLFxuXHRcdFx0bGFiZWw6ICdBY3RpdmUgRGV2aWNlIE1vZGVsJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogbW9kZWxzWzBdID8/ICcnLFxuXHRcdFx0Y2hvaWNlczogbW9kZWxzLm1hcCgobW9kZWwpID0+ICh7XG5cdFx0XHRcdGlkOiBtb2RlbCxcblx0XHRcdFx0bGFiZWw6IGBNb2RlbCAke21vZGVsfWAsXG5cdFx0XHR9KSksXG5cdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiBgISQob3B0aW9uczpkZXZpY2VNYWMpYCxcblx0XHRcdHRvb2x0aXA6ICdTZWxlY3Qgd2hpY2ggU3R1ZGlvIFRlY2hub2xvZ2llcyBtb2RlbCBpcyBhY3RpdmUgZm9yIGFjdGlvbnMgYW5kIGZlZWRiYWNrcy4nLFxuXHRcdH0sXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgRGV2IE1vZGUgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2NoZWNrYm94Jyxcblx0XHRcdGlkOiAnZGV2TW9kZScsXG5cdFx0XHRsYWJlbDogJ0RldiBNb2RlJyxcblx0XHRcdHdpZHRoOiAxMixcblx0XHRcdGRlZmF1bHQ6IGZhbHNlLFxuXHRcdFx0dG9vbHRpcDogJ0VuYWJsZSB0byBhbGxvdyBwYXJzaW5nIG9mIFNUIERldmljZXMgbm90IGN1cnJlbnRseSBzdXBwb3J0ZWQnLFxuXHRcdH0sXG5cdF1cbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBlZmZlY3RpdmUgaG9zdCBJUC5cbiAqIEF1dG8gbW9kZSAoZGV2aWNlTWFjIHNldCk6IGZpbmRzIHRoZSBjdXJyZW50IElQIG9mIHRoZSBkaXNjb3ZlcmVkIGRldmljZSB3aXRoIHRoYXQgTUFDLlxuICogTWFudWFsIG1vZGUgKGRldmljZU1hYyBlbXB0eSk6IHJldHVybnMgdGhlIG1hbnVhbGx5IGVudGVyZWQgaG9zdCBJUC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVIb3N0KGNvbmZpZzogTW9kdWxlQ29uZmlnLCBkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdKTogc3RyaW5nIHtcblx0aWYgKGNvbmZpZy5kZXZpY2VNYWMpIHtcblx0XHRjb25zdCBkZXZpY2UgPSBkaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLm1hYyA9PT0gY29uZmlnLmRldmljZU1hYylcblx0XHRyZXR1cm4gZGV2aWNlPy5pcCA/PyAnJ1xuXHR9XG5cdHJldHVybiBTdHJpbmcoY29uZmlnLmhvc3QgPz8gJycpXG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgZWZmZWN0aXZlIG1vZGVsLlxuICogQXV0byBtb2RlOiB1c2VzIHRoZSBtb2RlbCBmcm9tIHRoZSBkaXNjb3ZlcmVkIGRldmljZSBtYXRjaGluZyB0aGUgc3RvcmVkIE1BQy5cbiAqIE1hbnVhbCBtb2RlOiB1c2VzIHRoZSBtYW51YWxseSBzZWxlY3RlZCBhY3RpdmVNb2RlbC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVNb2RlbChjb25maWc6IE1vZHVsZUNvbmZpZywgZGlzY292ZXJlZERldmljZXM6IERldmljZUluZm9bXSk6IHN0cmluZyB7XG5cdGlmIChjb25maWcuZGV2aWNlTWFjKSB7XG5cdFx0Y29uc3QgZGV2aWNlID0gZGlzY292ZXJlZERldmljZXMuZmluZCgoZCkgPT4gZC5tYWMgPT09IGNvbmZpZy5kZXZpY2VNYWMpXG5cdFx0bG9nZ2VyLmRlYnVnKGByZXNvbHZlTW9kZWw6IGRldmljZU1hYz1cIiR7Y29uZmlnLmRldmljZU1hY31cIiwgZm91bmQgZGV2aWNlOiAke2RldmljZT8ubW9kZWwgPz8gJ25vbmUnfWApXG5cdFx0cmV0dXJuIGRldmljZT8ubW9kZWwgPz8gJydcblx0fVxuXHRsb2dnZXIuZGVidWcoYHJlc29sdmVNb2RlbDogbWFudWFsIG1vZGUsIGFjdGl2ZU1vZGVsPVwiJHtjb25maWcuYWN0aXZlTW9kZWx9XCJgKVxuXHRyZXR1cm4gU3RyaW5nKGNvbmZpZy5hY3RpdmVNb2RlbCA/PyAnJylcbn1cbiIsICJpbXBvcnQgdHlwZSBNb2R1bGVJbnN0YW5jZSBmcm9tICcuL21haW4uanMnXG5cbi8qKlxuICogRGVmaW5lIENvbXBhbmlvbiB2YXJpYWJsZXMgZm9yIHRoaXMgbW9kdWxlLlxuICogVmFyaWFibGVzIGNhbiBiZSB1c2VkIHRvIGRpc3BsYXkgZHluYW1pYyBzdGF0ZSBpbiBidXR0b24gbGFiZWxzLCB0cmlnZ2VycywgZXRjLlxuICovXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRzZWxmLnNldFZhcmlhYmxlRGVmaW5pdGlvbnMoe1xuXHRcdG1vZGVsOiB7IG5hbWU6ICdEZXZpY2UgTW9kZWwgTnVtYmVyJyB9LFxuXHRcdG1vZGVsTmFtZTogeyBuYW1lOiAnRGV2aWNlIE1vZGVsIE5hbWUgKEZ1bGwgRGVzY3JpcHRpb24pJyB9LFxuXHRcdG1hbnVmYWN0dXJlcjogeyBuYW1lOiAnRGV2aWNlIE1hbnVmYWN0dXJlcicgfSxcblx0XHRmaXJtd2FyZTogeyBuYW1lOiAnRGV2aWNlIEZpcm13YXJlIFZlcnNpb24nIH0sXG5cdFx0ZGFudGVGVzogeyBuYW1lOiAnRGFudGUgTW9kdWxlIEZpcm13YXJlIFZlcnNpb24nIH0sXG5cdFx0bWFjOiB7IG5hbWU6ICdEZXZpY2UgTUFDIEFkZHJlc3MnIH0sXG5cdFx0aXA6IHsgbmFtZTogJ0RldmljZSBJUCBBZGRyZXNzJyB9LFxuXHR9KVxufVxuXG5jb25zdCBDTEVBUkVEX1ZBUklBQkxFUyA9IHtcblx0bW9kZWw6ICcnLFxuXHRtb2RlbE5hbWU6ICcnLFxuXHRtYW51ZmFjdHVyZXI6ICcnLFxuXHRmaXJtd2FyZTogJycsXG5cdGRhbnRlRlc6ICcnLFxuXHRtYWM6ICcnLFxuXHRpcDogJycsXG59XG5cbi8qKlxuICogVXBkYXRlIHZhcmlhYmxlIHZhbHVlcyBmcm9tIGRpc2NvdmVyZWQgZGV2aWNlIGluZm9ybWF0aW9uLlxuICogT25seSBwb3B1bGF0ZXMgdmFyaWFibGVzIHdoZW4gdGhlIGN1cnJlbnQgaG9zdCBpcyBhdXRob3JpemVkLlxuICogQ2xlYXJzIGFsbCB2YXJpYWJsZXMgaWYgdGhlIGRldmljZSBpcyBub3QgYXV0aG9yaXplZCBvciBub3QgZm91bmQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVWYXJpYWJsZVZhbHVlcyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRjb25zdCBjdXJyZW50SG9zdCA9IHNlbGYuaG9zdFxuXG5cdC8vIENsZWFyIHZhcmlhYmxlcyBpZiBubyBob3N0IGNvbmZpZ3VyZWQgb3IgZGV2aWNlIGlzIG5vdCBhdXRob3JpemVkXG5cdGlmICghY3VycmVudEhvc3QgfHwgIXNlbGYuc3RDb250cm9sbGVyLmlzRGV2aWNlQXV0aG9yaXplZChjdXJyZW50SG9zdCkpIHtcblx0XHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKENMRUFSRURfVkFSSUFCTEVTKVxuXHRcdHJldHVyblxuXHR9XG5cblx0Y29uc3QgZGV2aWNlID0gc2VsZi5kZXZpY2VzLmZpbmQoKGQpID0+IGQuaXAgPT09IGN1cnJlbnRIb3N0KVxuXHRpZiAoZGV2aWNlKSB7XG5cdFx0c2VsZi5zZXRWYXJpYWJsZVZhbHVlcyh7XG5cdFx0XHRtb2RlbDogZGV2aWNlLm1vZGVsIHx8ICcnLFxuXHRcdFx0bW9kZWxOYW1lOiBkZXZpY2UubW9kZWxOYW1lIHx8ICcnLFxuXHRcdFx0bWFudWZhY3R1cmVyOiBkZXZpY2UubWFudWZhY3R1cmVyIHx8ICcnLFxuXHRcdFx0ZmlybXdhcmU6IGRldmljZS5maXJtd2FyZU1haW4gfHwgJycsXG5cdFx0XHRkYW50ZUZXOiBkZXZpY2UuZGFudGVGaXJtd2FyZSB8fCAnJyxcblx0XHRcdG1hYzogZGV2aWNlLm1hYyB8fCAnJyxcblx0XHRcdGlwOiBkZXZpY2UuaXAsXG5cdFx0fSlcblx0fSBlbHNlIHtcblx0XHQvLyBBdXRob3JpemVkIGJ1dCBub3QgaW4gZGlzY292ZXJlZCBsaXN0IChtYW51YWwgSVAgdGhhdCBwcm9iZWQgc3VjY2Vzc2Z1bGx5KVxuXHRcdC8vIFdlIGtub3cgaXQncyB0aGUgcmlnaHQgZGV2aWNlIGJ1dCBkb24ndCBoYXZlIGZ1bGwgaW5mbyB5ZXRcblx0XHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKHtcblx0XHRcdC4uLkNMRUFSRURfVkFSSUFCTEVTLFxuXHRcdFx0aXA6IGN1cnJlbnRIb3N0LFxuXHRcdH0pXG5cdH1cbn1cbiIsICJpbXBvcnQgdHlwZSB7IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVTY3JpcHQgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHR5cGUgeyBNb2R1bGVDb25maWcgfSBmcm9tICcuL2NvbmZpZy5qcydcblxuZXhwb3J0IGNvbnN0IFVwZ3JhZGVTY3JpcHRzOiBDb21wYW5pb25TdGF0aWNVcGdyYWRlU2NyaXB0PE1vZHVsZUNvbmZpZz5bXSA9IFtcblx0Lypcblx0ICogUGxhY2UgeW91ciB1cGdyYWRlIHNjcmlwdHMgaGVyZVxuXHQgKiBSZW1lbWJlciB0aGF0IG9uY2UgaXQgaGFzIGJlZW4gYWRkZWQgaXQgY2Fubm90IGJlIHJlbW92ZWQhXG5cdCAqL1xuXHQvLyBmdW5jdGlvbiAoY29udGV4dCwgcHJvcHMpIHtcblx0Ly8gXHRyZXR1cm4ge1xuXHQvLyBcdFx0dXBkYXRlZENvbmZpZzogbnVsbCxcblx0Ly8gXHRcdHVwZGF0ZWRBY3Rpb25zOiBbXSxcblx0Ly8gXHRcdHVwZGF0ZWRGZWVkYmFja3M6IFtdLFxuXHQvLyBcdH1cblx0Ly8gfSxcbl1cbiIsICJleHBvcnQgdHlwZSBEZXZpY2VJbmZvID0ge1xuXHRtb2RlbDogc3RyaW5nIC8vIE1vZGVsIG51bWJlciAoZS5nLiwgXCIzNzRBXCIpXG5cdG1vZGVsTmFtZT86IHN0cmluZyAvLyBGdWxsIG1vZGVsIGRlc2NyaXB0aW9uIChlLmcuLCBcIk1vZGVsIDM3NEEgSW50ZXJjb20gQmVsdHBhY2tcIilcblx0aXA6IHN0cmluZ1xuXHRuYW1lPzogc3RyaW5nIC8vIERhbnRlIGRldmljZSBuYW1lICh1c2VyLWNvbmZpZ3VyYWJsZSBsYWJlbCwgZS5nLiBcIlNULU0zNzRBLUJlbHRwYWNrXCIpXG5cdG1hbnVmYWN0dXJlcj86IHN0cmluZyAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGZpcm13YXJlTWFpbj86IHN0cmluZyAvLyBEZXZpY2UgZmlybXdhcmUgdmVyc2lvbiBmcm9tIERhbnRlIGRpc2NvdmVyeSAoZS5nLiwgXCI0LjkuMFwiKVxuXHRkYW50ZUZpcm13YXJlPzogc3RyaW5nIC8vIERhbnRlIG1vZHVsZSBmaXJtd2FyZSB2ZXJzaW9uXG5cdG1hYz86IHN0cmluZ1xufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgQ29tbWFuZCBJRCBDb25zdGFudHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgY29uc3QgQ01EX0dFVF9GSVJNV0FSRSA9IDB4MDAgLy8gUmVxdWVzdCBkZXZpY2UgZmlybXdhcmUgdmVyc2lvblxuZXhwb3J0IGNvbnN0IENNRF9NSUNfUFJFID0gMHgwMiAvLyBNaWMgcHJlYW1wIHJhdyBzZXQgKGdhaW4sIHBoYW50b20pIFx1MjAxNCBwb3NpdGlvbmFsIGJ5dGVzLCBubyBzZXR0aW5nIElEc1xuZXhwb3J0IGNvbnN0IENNRF9CVVNfR0VUID0gMHgwMyAvLyBIZWFydGJlYXQgLyBrZWVwYWxpdmUgcGluZ1xuZXhwb3J0IGNvbnN0IENNRF9CVVNfU0VUID0gMHgwNCAvLyBTZXQgc2V0dGluZyBvbiBzcGVjaWZpYyBidXMvY2hhbm5lbFxuZXhwb3J0IGNvbnN0IENNRF9IRUFEUEhPTkUgPSAweDA1IC8vIEhlYWRwaG9uZSBjb250cm9sc1xuZXhwb3J0IGNvbnN0IENNRF9CVVRUT05fTU9ERSA9IDB4MDcgLy8gQnV0dG9uIG1vZGUgY29uZmlndXJhdGlvblxuZXhwb3J0IGNvbnN0IENNRF9TWVNURU0gPSAweDA5IC8vIFN5c3RlbS1sZXZlbCBjb21tYW5kc1xuZXhwb3J0IGNvbnN0IENNRF9HRVRfQUxMX1NFVFRJTkdTID0gMHgwYSAvLyBSZXF1ZXN0IGFsbCBjdXJyZW50IHNldHRpbmdzIGZyb20gZGV2aWNlXG5leHBvcnQgY29uc3QgQ01EX1NFVFRJTkdTX1BVU0ggPSAweDBiIC8vIFVuc29saWNpdGVkIHNldHRpbmdzIHVwZGF0ZSBmcm9tIGRldmljZVxuZXhwb3J0IGNvbnN0IENNRF9ERVZfU1BFQyA9IDB4MGQgLy8gRGV2aWNlLXNwZWNpZmljIHNldHRpbmcgZ2V0L3NldCB3aXRoIEFDS1xuZXhwb3J0IGNvbnN0IENNRF9SRVNFVF9ERVZJQ0UgPSAweDBlIC8vIEZhY3RvcnkgcmVzZXQgY29tbWFuZFxuZXhwb3J0IGNvbnN0IENNRF9HTE9CQUxfTUlDX0tJTEwgPSAweDEwIC8vIEVtZXJnZW5jeSBtaWMga2lsbCAoYWxsIGNoYW5uZWxzKVxuZXhwb3J0IGNvbnN0IENNRF9NSUNfUFJFX0JVUyA9IDB4MTIgLy8gTWljL3ByZWFtcCBzZXR0aW5ncyBwZXIgYnVzIChnYWluLCBwaGFudG9tLCBldGMpXG5leHBvcnQgY29uc3QgQ01EX0NIQU5ORUwgPSAweDE0IC8vIENoYW5uZWwtc3BlY2lmaWMgY29udHJvbHNcblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIENvbW1hbmQgTmFtZSBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q29tbWFuZE5hbWUoY21kSWQ6IG51bWJlcik6IHN0cmluZyB7XG5cdHN3aXRjaCAoY21kSWQpIHtcblx0XHRjYXNlIENNRF9HRVRfRklSTVdBUkU6XG5cdFx0XHRyZXR1cm4gJ0dldCBGaXJtd2FyZSBWZXJzaW9uJ1xuXHRcdGNhc2UgQ01EX01JQ19QUkU6XG5cdFx0XHRyZXR1cm4gJ01pYyBQcmVhbXAnXG5cdFx0Y2FzZSBDTURfQlVTX0dFVDpcblx0XHRcdHJldHVybiAnSGVhcnRiZWF0J1xuXHRcdGNhc2UgQ01EX0JVU19TRVQ6XG5cdFx0XHRyZXR1cm4gJ1NldCBCdXMgU2V0dGluZydcblx0XHRjYXNlIENNRF9IRUFEUEhPTkU6XG5cdFx0XHRyZXR1cm4gJ0hlYWRwaG9uZSBDb250cm9sJ1xuXHRcdGNhc2UgQ01EX0JVVFRPTl9NT0RFOlxuXHRcdFx0cmV0dXJuICdCdXR0b24gTW9kZSdcblx0XHRjYXNlIENNRF9TWVNURU06XG5cdFx0XHRyZXR1cm4gJ1N5c3RlbSBDb21tYW5kJ1xuXHRcdGNhc2UgQ01EX0dFVF9BTExfU0VUVElOR1M6XG5cdFx0XHRyZXR1cm4gJ1JlcXVlc3QgQWxsIFNldHRpbmdzJ1xuXHRcdGNhc2UgQ01EX1NFVFRJTkdTX1BVU0g6XG5cdFx0XHRyZXR1cm4gJ1NldHRpbmdzIFB1c2gnXG5cdFx0Y2FzZSBDTURfTUlDX1BSRV9CVVM6XG5cdFx0XHRyZXR1cm4gJ01pYy9QcmUgQnVzJ1xuXHRcdGNhc2UgQ01EX0RFVl9TUEVDOlxuXHRcdFx0cmV0dXJuICdEZXZpY2UgU2V0dGluZydcblx0XHRjYXNlIENNRF9DSEFOTkVMOlxuXHRcdFx0cmV0dXJuICdDaGFubmVsIFNldHRpbmcnXG5cdFx0Y2FzZSBDTURfUkVTRVRfREVWSUNFOlxuXHRcdFx0cmV0dXJuICdSZXNldCBEZXZpY2UnXG5cdFx0Y2FzZSBDTURfR0xPQkFMX01JQ19LSUxMOlxuXHRcdFx0cmV0dXJuICdHbG9iYWwgTWljIEtpbGwnXG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBgY21kXzB4JHtjbWRJZC50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX1gXG5cdH1cbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIElEIEdlbmVyYXRpb24gSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDcmVhdGVzIGEgY29uc2lzdGVudCBJRCBmb3IgYWN0aW9ucywgZmVlZGJhY2tzLCBhbmQgc3RhdGUga2V5cy5cbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2J1c0NofV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2ggKGUuZy4sIFwiNTMwNF8xNF8wXzBcIilcbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGhvdXQgYnVzQ2ggKGUuZy4sIFwiNTMwNF8xMl9kXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtYWtlU2V0dGluZ0lkKFxuXHRtb2RlbDogc3RyaW5nLFxuXHRjbWRJZDogbnVtYmVyIHwgc3RyaW5nLFxuXHRzZXR0aW5nSWQ6IG51bWJlciB8IHN0cmluZyxcblx0YnVzQ2g/OiBudW1iZXIgfCBzdHJpbmcsXG4pOiBzdHJpbmcge1xuXHRjb25zdCBjbWQgPSB0eXBlb2YgY21kSWQgPT09ICdudW1iZXInID8gY21kSWQudG9TdHJpbmcoMTYpIDogY21kSWRcblx0Y29uc3QgaWQgPSB0eXBlb2Ygc2V0dGluZ0lkID09PSAnbnVtYmVyJyA/IHNldHRpbmdJZC50b1N0cmluZygxNikgOiBzZXR0aW5nSWRcblxuXHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdGNvbnN0IGNoID0gdHlwZW9mIGJ1c0NoID09PSAnbnVtYmVyJyA/IGJ1c0NoLnRvU3RyaW5nKDE2KSA6IGJ1c0NoXG5cdFx0cmV0dXJuIGAke21vZGVsfV8ke2NtZH1fJHtjaH1fJHtpZH1gXG5cdH1cblxuXHRyZXR1cm4gYCR7bW9kZWx9XyR7Y21kfV8ke2lkfWBcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIEhleCBGb3JtYXR0aW5nIEhlbHBlcnMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENvbnZlcnRzIGEgbnVtYmVyIHRvIGEgaGV4IHN0cmluZyB3aXRoIDB4IHByZWZpeCBhbmQgcGFkZGluZy5cbiAqIEBwYXJhbSB2YWx1ZSAtIFRoZSBudW1iZXIgdG8gY29udmVydFxuICogQHBhcmFtIHBhZExlbmd0aCAtIE51bWJlciBvZiBoZXggZGlnaXRzIHRvIHBhZCB0byAoZGVmYXVsdDogMilcbiAqIEByZXR1cm5zIEZvcm1hdHRlZCBoZXggc3RyaW5nIChlLmcuLCBcIjB4MGRcIiwgXCIweGZmXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0hleCh2YWx1ZTogbnVtYmVyLCBwYWRMZW5ndGggPSAyKTogc3RyaW5nIHtcblx0cmV0dXJuIGAweCR7dmFsdWUudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KHBhZExlbmd0aCwgJzAnKX1gXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gYXJyYXkgb2YgYnl0ZXMgdG8gYSBoZXggc3RyaW5nIHdpdGggMHggcHJlZml4LlxuICogQHBhcmFtIGJ5dGVzIC0gQXJyYXkgb2YgYnl0ZXMgb3IgQnVmZmVyXG4gKiBAcmV0dXJucyBGb3JtYXR0ZWQgaGV4IHN0cmluZyAoZS5nLiwgXCIweDBhZmYxMlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gYnl0ZXNUb0hleChieXRlczogbnVtYmVyW10gfCBCdWZmZXIpOiBzdHJpbmcge1xuXHRyZXR1cm4gYDB4JHtBcnJheS5mcm9tKGJ5dGVzKVxuXHRcdC5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXG5cdFx0LmpvaW4oJycpfWBcbn1cblxuLyoqXG4gKiBGb3JtYXRzIFJHQiBjb2xvciBieXRlcyBhcyBhIENTUyBoZXggY29sb3Igc3RyaW5nLlxuICogQHBhcmFtIHIgLSBSZWQgY29tcG9uZW50ICgwLTI1NSlcbiAqIEBwYXJhbSBnIC0gR3JlZW4gY29tcG9uZW50ICgwLTI1NSlcbiAqIEBwYXJhbSBiIC0gQmx1ZSBjb21wb25lbnQgKDAtMjU1KVxuICogQHJldHVybnMgQ1NTIGhleCBjb2xvciBzdHJpbmcgKGUuZy4sIFwiI0ZGMDBBQlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0UmdiQ29sb3IocjogbnVtYmVyLCBnOiBudW1iZXIsIGI6IG51bWJlcik6IHN0cmluZyB7XG5cdHJldHVybiBgIyR7W3IsIGcsIGJdXG5cdFx0Lm1hcCgodikgPT4gdi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcblx0XHQuam9pbignJylcblx0XHQudG9VcHBlckNhc2UoKX1gXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBJRCBQYXJzaW5nIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogUGFyc2VzIGEgc2V0dGluZyBJRCBzdHJpbmcgaW50byBpdHMgY29tcG9uZW50cy5cbiAqIEBwYXJhbSBpZCAtIFNldHRpbmcgSUQgc3RyaW5nIChlLmcuLCBcIjM5MV9kXzBcIiBvciBcIjUzMDRfMTRfMF8xXCIpXG4gKiBAcmV0dXJucyBQYXJzZWQgY29tcG9uZW50cyB3aXRoIGhleCBzdHJpbmdzIGNvbnZlcnRlZCB0byBudW1iZXJzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVNldHRpbmdJZChpZDogc3RyaW5nKTogeyBtb2RlbDogc3RyaW5nOyBjbWRJZDogbnVtYmVyOyBiYXNlSWQ6IG51bWJlciB9IHtcblx0Y29uc3QgW21vZGVsLCBjbWRJZFN0ciwgaWRTdHJdID0gaWQuc3BsaXQoJ18nKVxuXHRyZXR1cm4ge1xuXHRcdG1vZGVsLFxuXHRcdGNtZElkOiBwYXJzZUludChjbWRJZFN0ciwgMTYpLFxuXHRcdGJhc2VJZDogcGFyc2VJbnQoaWRTdHIsIDE2KSxcblx0fVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgTW9kZWwgRGlzdGFuY2UgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDYWxjdWxhdGVzIG51bWVyaWMgZGlzdGFuY2UgYmV0d2VlbiB0d28gbW9kZWwgbnVtYmVycy5cbiAqIFVzZWQgZm9yIGZpbmRpbmcgc2ltaWxhciBtb2RlbHMgZm9yIHNldHRpbmcgaW5mZXJlbmNlLlxuICogQHBhcmFtIG1vZGVsQSAtIEZpcnN0IG1vZGVsIG51bWJlciAoZS5nLiwgXCIzOTFcIilcbiAqIEBwYXJhbSBtb2RlbEIgLSBTZWNvbmQgbW9kZWwgbnVtYmVyIChlLmcuLCBcIjM5MlwiKVxuICogQHJldHVybnMgTnVtZXJpYyBkaXN0YW5jZSBiZXR3ZWVuIG1vZGVscywgb3IgSW5maW5pdHkgaWYgZWl0aGVyIGlzIG5vbi1udW1lcmljXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtb2RlbERpc3RhbmNlKG1vZGVsQTogc3RyaW5nLCBtb2RlbEI6IHN0cmluZyk6IG51bWJlciB7XG5cdGNvbnN0IG5hID0gcGFyc2VJbnQobW9kZWxBLnJlcGxhY2UoL1xcRC9nLCAnJyksIDEwKVxuXHRjb25zdCBuYiA9IHBhcnNlSW50KG1vZGVsQi5yZXBsYWNlKC9cXEQvZywgJycpLCAxMClcblx0aWYgKE51bWJlci5pc05hTihuYSkgfHwgTnVtYmVyLmlzTmFOKG5iKSkgcmV0dXJuIEluZmluaXR5XG5cdHJldHVybiBNYXRoLmFicyhuYSAtIG5iKVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU2NoZW1hIE5vcm1hbGl6YXRpb24gSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBOb3JtYWxpemVzIGRldmljZSBzY2hlbWFzIHRvIGVuc3VyZSBjbWRTY2hlbWEgaXMgYWx3YXlzIGFuIGFycmF5LlxuICogVGhpcyBoZWxwZXIgZWxpbWluYXRlcyBkdXBsaWNhdGUgc2NoZW1hIHRyYW5zZm9ybWF0aW9uIGNvZGUuXG4gKiBAcGFyYW0gc2NoZW1hc1JhdyAtIFJhdyBzY2hlbWFzIGZyb20gZ2V0RGV2aWNlU2NoZW1hcygpXG4gKiBAcmV0dXJucyBOb3JtYWxpemVkIHNjaGVtYXMgd2l0aCBndWFyYW50ZWVkIGNtZFNjaGVtYSBhcnJheXNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldE5vcm1hbGl6ZWRTY2hlbWFzKFxuXHRzY2hlbWFzUmF3OiBSZWNvcmQ8c3RyaW5nLCBhbnk+LFxuKTogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+IHtcblx0Y29uc3Qgbm9ybWFsaXplZDogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+ID0ge31cblx0Zm9yIChjb25zdCBbbW9kZWwsIGpzb25dIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYXNSYXcpKSB7XG5cdFx0bm9ybWFsaXplZFttb2RlbF0gPSB7XG5cdFx0XHRtb2RlbDoganNvbi5tb2RlbCxcblx0XHRcdGNtZFNjaGVtYTogQXJyYXkuaXNBcnJheShqc29uLmNtZFNjaGVtYSkgPyBqc29uLmNtZFNjaGVtYSA6IFtdLFxuXHRcdH1cblx0fVxuXHRyZXR1cm4gbm9ybWFsaXplZFxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgQWN0aW9uIExvb2t1cCBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIEZpbmRzIGFuIGFjdGlvbi9zZXR0aW5nIGluIHRoZSBzY2hlbWEsIHN1cHBvcnRpbmcgYm90aCBleGFjdCBtYXRjaGVzIGFuZCBpZEFkZCBvZmZzZXRzLlxuICogVGhpcyBoZWxwZXIgZWxpbWluYXRlcyBkdXBsaWNhdGUgYWN0aW9uIGxvb2t1cCBsb2dpYyBhY3Jvc3MgbXVsdGlwbGUgZmlsZXMuXG4gKiBAcGFyYW0gc2NoZW1hcyAtIE5vcm1hbGl6ZWQgZGV2aWNlIHNjaGVtYXNcbiAqIEBwYXJhbSBtb2RlbCAtIERldmljZSBtb2RlbCAoZS5nLiwgXCIzOTFcIilcbiAqIEBwYXJhbSBjbWRJZCAtIENvbW1hbmQgSURcbiAqIEBwYXJhbSBzZXR0aW5nSWQgLSBTZXR0aW5nIElEIChtYXkgaW5jbHVkZSBpZEFkZCBvZmZzZXQpXG4gKiBAcmV0dXJucyBNYXRjaGluZyBhY3Rpb24vc2V0dGluZyBvciB1bmRlZmluZWRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZpbmRBY3Rpb25Gb3JTZXR0aW5nKFxuXHRzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4sXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIsXG5cdHNldHRpbmdJZDogbnVtYmVyLFxuKTogYW55IHtcblx0Y29uc3Qgc2NoZW1hID0gc2NoZW1hc1ttb2RlbF1cblx0aWYgKCFzY2hlbWEgfHwgIUFycmF5LmlzQXJyYXkoc2NoZW1hLmNtZFNjaGVtYSkpIHJldHVybiB1bmRlZmluZWRcblxuXHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0bGV0IGFjdGlvbiA9IHNjaGVtYS5jbWRTY2hlbWEuZmluZCgoczogYW55KSA9PiBzLmNtZF9pZCA9PT0gY21kSWQgJiYgcy5pZCA9PT0gc2V0dGluZ0lkKVxuXG5cdC8vIElmIG5vIGV4YWN0IG1hdGNoLCB0cnkgdG8gZmluZCBiYXNlIGFjdGlvbiB3aXRoIGlkQWRkXG5cdGlmICghYWN0aW9uKSB7XG5cdFx0YWN0aW9uID0gc2NoZW1hLmNtZFNjaGVtYS5maW5kKChzOiBhbnkpID0+IHtcblx0XHRcdGlmIChzLmNtZF9pZCAhPT0gY21kSWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBzLm9wdGlvbnM/LmZpbmQoKG9wdDogYW55KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoIWlkQWRkT3B0aW9uPy5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdC8vIENoZWNrIGlmIHNldHRpbmdJZCBtYXRjaGVzIGJhc2UgKyBhbnkgaWRBZGQgb2Zmc2V0XG5cdFx0XHRjb25zdCBvZmZzZXQgPSBzZXR0aW5nSWQgLSBzLmlkXG5cdFx0XHRyZXR1cm4gaWRBZGRPcHRpb24uY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9mZnNldClcblx0XHR9KVxuXHR9XG5cblx0cmV0dXJuIGFjdGlvblxufVxuIiwgIi8qKlxuICogYnVpbGQtY29tbWFuZHMudHNcbiAqIC0gVXNlcyBjZW50cmFsaXplZCBkZXZpY2Ugc2NoZW1hIGNhY2hlIGZyb20gY29uZmlnLnRzXG4gKiAtIFByb2R1Y2VzIENvbXBhbmlvbiBhY3Rpb24gZGVmaW5pdGlvbnMgYW5kIGZlZWRiYWNrc1xuICovXG5cbmltcG9ydCB7XG5cdENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zLFxuXHRDb21wYW5pb25BY3Rpb25EZWZpbml0aW9uLFxuXHRDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zLFxuXHRjb21iaW5lUmdiLFxufSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHsgbWFrZVNldHRpbmdJZCB9IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQgeyBnZXREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0gT3B0aW9uIEJ1aWxkZXIgLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuZnVuY3Rpb24gYnVpbGRPcHRpb24obzogYW55KTogYW55IHtcblx0Y29uc3QgYmFzZSA9IHtcblx0XHR0eXBlOiBvLnR5cGUsXG5cdFx0aWQ6IG8uaWQsXG5cdFx0bGFiZWw6IG8ubGFiZWwsXG5cdFx0ZGVmYXVsdDogby5kZWZhdWx0LFxuXHRcdHRvb2x0aXA6IG8udG9vbHRpcCxcblx0fVxuXG5cdHN3aXRjaCAoby50eXBlKSB7XG5cdFx0Y2FzZSAnZHJvcGRvd24nOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgY2hvaWNlczogby5jaG9pY2VzID8/IFtdIH1cblxuXHRcdGNhc2UgJ251bWJlcic6XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHQuLi5iYXNlLFxuXHRcdFx0XHRtaW46IG8ubWluLFxuXHRcdFx0XHRtYXg6IG8ubWF4LFxuXHRcdFx0XHRzdGVwOiBvLnN0ZXAgPz8gMSxcblx0XHRcdFx0cmFuZ2U6IHRydWUsXG5cdFx0XHR9XG5cblx0XHRjYXNlICdjaGVja2JveCc6XG5cdFx0XHRyZXR1cm4geyAuLi5iYXNlLCBkZWZhdWx0OiBvLmRlZmF1bHQgPz8gZmFsc2UgfVxuXG5cdFx0Y2FzZSAnc3RhdGljLXRleHQnOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgdmFsdWU6IG8udmFsdWUgPz8gJycgfVxuXG5cdFx0Y2FzZSAndGV4dGlucHV0Jzpcblx0XHRjYXNlICdjb2xvcnBpY2tlcic6XG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBiYXNlXG5cdH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBBY3Rpb25zIC0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRBY3Rpb25zKCk6IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCBhY3Rpb25zOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyA9IHt9XG5cblx0Zm9yIChjb25zdCBbbW9kZWwsIHNjaGVtYV0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hcykpIHtcblx0XHRjb25zdCBjbWRTY2hlbWEgPSBzY2hlbWEuY21kU2NoZW1hXG5cdFx0aWYgKCFBcnJheS5pc0FycmF5KGNtZFNjaGVtYSkpIGNvbnRpbnVlXG5cblx0XHRmb3IgKGNvbnN0IGEgb2YgY21kU2NoZW1hKSB7XG5cdFx0XHQvLyBTa2lwIHJlYWQtb25seSBlbnRyaWVzIFx1MjAxNCB0aGV5IGFyZSBmZWVkYmFjay1vbmx5IChpbmRpY2F0b3JzLCBzdGF0dXMpXG5cdFx0XHRpZiAoYS5yZWFkb25seSA9PT0gdHJ1ZSkgY29udGludWVcblxuXHRcdFx0Y29uc3QgYWN0aW9uSWQgPSBtYWtlU2V0dGluZ0lkKG1vZGVsLCBhLmNtZF9pZCwgYS5pZClcblxuXHRcdFx0Ly8gRml4ZWQtdmFsdWUgYWN0aW9uczoga2VlcCBpZEFkZC9idXNDaCBzZWxlY3RvcnMgYnV0IGRyb3AgdGhlIHZhbHVlIG9wdGlvblxuXHRcdFx0Y29uc3QgYWxsQnVpbHRPcHRpb25zID0gKGEub3B0aW9ucyA/PyBbXSkubWFwKGJ1aWxkT3B0aW9uKVxuXHRcdFx0Y29uc3Qgb3B0aW9ucyA9IGEudmFsdWUgIT09IHVuZGVmaW5lZCA/IGFsbEJ1aWx0T3B0aW9ucy5maWx0ZXIoKG86IGFueSkgPT4gby5pZCAhPT0gJ3ZhbHVlJykgOiBhbGxCdWlsdE9wdGlvbnNcblxuXHRcdFx0Y29uc3QgYWN0aW9uOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9uID0ge1xuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHttb2RlbH1dICR7YS5uYW1lfWAsXG5cdFx0XHRcdG9wdGlvbnMsXG5cdFx0XHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdFx0Lyogd2lyZWQgbGF0ZXIgaW4gVXBkYXRlQWN0aW9ucyAqL1xuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXG5cdFx0XHRhY3Rpb25zW2FjdGlvbklkXSA9IGFjdGlvblxuXHRcdH1cblx0fVxuXG5cdHJldHVybiBhY3Rpb25zXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0gRmVlZGJhY2tzIC0tLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuLyoqXG4gKiBSZXR1cm5zIHRydWUgaWYgdGhlIHNldHRpbmcncyB2YWx1ZSBvcHRpb24gcmVwcmVzZW50cyBhIGJvb2xlYW4gKG9uL29mZikgY2hvaWNlOlxuICogLSB0eXBlICdjaGVja2JveCcsIE9SXG4gKiAtIGEgMi1jaG9pY2UgZHJvcGRvd24gd2hlcmUgb25lIGxhYmVsIGlzIFwib2ZmXCIgYW5kIHRoZSBvdGhlciBpcyBcIm9uXCJcbiAqL1xuZnVuY3Rpb24gaXNCb29sZWFuRHJvcGRvd24oc2V0dGluZzogYW55KTogYm9vbGVhbiB7XG5cdGNvbnN0IHZhbHVlT3B0ID0gc2V0dGluZy5vcHRpb25zPy5maW5kKChvOiBhbnkpID0+IG8uaWQgPT09ICd2YWx1ZScpXG5cdGlmICghdmFsdWVPcHQpIHJldHVybiBmYWxzZVxuXHRpZiAodmFsdWVPcHQudHlwZSA9PT0gJ2NoZWNrYm94JykgcmV0dXJuIHRydWVcblx0aWYgKHZhbHVlT3B0LnR5cGUgIT09ICdkcm9wZG93bicgfHwgIUFycmF5LmlzQXJyYXkodmFsdWVPcHQuY2hvaWNlcykpIHJldHVybiBmYWxzZVxuXHRpZiAodmFsdWVPcHQuY2hvaWNlcy5sZW5ndGggIT09IDIpIHJldHVybiBmYWxzZVxuXHRjb25zdCBsYWJlbHMgPSB2YWx1ZU9wdC5jaG9pY2VzLm1hcCgoYzogYW55KSA9PiBTdHJpbmcoYy5sYWJlbCkudG9Mb3dlckNhc2UoKSlcblx0cmV0dXJuIGxhYmVscy5pbmNsdWRlcygnb2ZmJykgJiYgbGFiZWxzLmluY2x1ZGVzKCdvbicpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBidWlsZEZlZWRiYWNrcygpOiBDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCBmZWVkYmFja3M6IENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbnMgPSB7fVxuXG5cdGZvciAoY29uc3QgW21vZGVsLCBzY2hlbWFdIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYXMpKSB7XG5cdFx0Y29uc3QgY21kU2NoZW1hID0gc2NoZW1hLmNtZFNjaGVtYVxuXHRcdGlmICghQXJyYXkuaXNBcnJheShjbWRTY2hlbWEpKSBjb250aW51ZVxuXG5cdFx0Zm9yIChjb25zdCBzZXR0aW5nIG9mIGNtZFNjaGVtYSkge1xuXHRcdFx0Ly8gU2tpcCB3cml0ZS1vbmx5IGVudHJpZXMgXHUyMDE0IHRoZXkgYXJlIGFjdGlvbi1vbmx5IChkZXZpY2UgbmV2ZXIgcmVwb3J0cyB2YWx1ZSBiYWNrKVxuXHRcdFx0aWYgKHNldHRpbmcud3JpdGVvbmx5ID09PSB0cnVlKSBjb250aW51ZVxuXG5cdFx0XHRjb25zdCBiYXNlRmVlZGJhY2tJZCA9IG1ha2VTZXR0aW5nSWQobW9kZWwsIHNldHRpbmcuY21kX2lkLCBzZXR0aW5nLmlkKVxuXG5cdFx0XHQvLyBGaXhlZC12YWx1ZSBlbnRyaWVzOiBzaW5nbGUgYm9vbGVhbiBmZWVkYmFjayBcdTIwMTQgdHJ1ZSB3aGVuIGN1cnJlbnQgdmFsdWUgbWF0Y2hlcyB0aGUgZml4ZWQgdmFsdWVcblx0XHRcdGlmIChzZXR0aW5nLnZhbHVlICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0Y29uc3QgZml4ZWRPcHRpb25zID0gKHNldHRpbmcub3B0aW9ucyA/PyBbXSlcblx0XHRcdFx0XHQubWFwKGJ1aWxkT3B0aW9uKVxuXHRcdFx0XHRcdC5maWx0ZXIoKG9wdDogYW55KSA9PiBvcHQuaWQgPT09ICdidXNDaCcgfHwgb3B0LmlkID09PSAnaWRBZGQnKVxuXG5cdFx0XHRcdGZlZWRiYWNrc1tiYXNlRmVlZGJhY2tJZF0gPSB7XG5cdFx0XHRcdFx0dHlwZTogJ2Jvb2xlYW4nLFxuXHRcdFx0XHRcdG5hbWU6IGBbTW9kZWwke21vZGVsfV0gJHtzZXR0aW5nLm5hbWV9IFx1MjAxNCBBY3RpdmVgLFxuXHRcdFx0XHRcdGRlZmF1bHRTdHlsZToge1xuXHRcdFx0XHRcdFx0Ymdjb2xvcjogY29tYmluZVJnYigwLCAyMDAsIDApLFxuXHRcdFx0XHRcdFx0Y29sb3I6IGNvbWJpbmVSZ2IoMCwgMCwgMCksXG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0XHRvcHRpb25zOiBmaXhlZE9wdGlvbnMsXG5cdFx0XHRcdFx0Y2FsbGJhY2s6ICgpID0+IHtcblx0XHRcdFx0XHRcdC8qIHdpcmVkIGxhdGVyIGluIFVwZGF0ZUZlZWRiYWNrcyAqL1xuXHRcdFx0XHRcdFx0cmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0fSBhcyBhbnlcblx0XHRcdFx0Y29udGludWVcblx0XHRcdH1cblxuXHRcdFx0Ly8gQnVpbGQgb3B0aW9uc1xuXHRcdFx0Y29uc3QgYWxsT3B0aW9ucyA9IChzZXR0aW5nLm9wdGlvbnMgPz8gW10pLm1hcChidWlsZE9wdGlvbilcblxuXHRcdFx0Ly8gRmlsdGVyIG91dCAndmFsdWUnIG9wdGlvbiBmb3IgdmFsdWUgZmVlZGJhY2sgKGtlZXAgb25seSBidXNDaC9pZEFkZClcblx0XHRcdGNvbnN0IHZhbHVlT3B0aW9ucyA9IGFsbE9wdGlvbnMuZmlsdGVyKChvcHQ6IGFueSkgPT4gb3B0LmlkICE9PSAndmFsdWUnKVxuXG5cdFx0XHQvLyBBZGQgYSBjaGVja2JveCBvcHRpb24gdG8gcmV0dXJuIGxhYmVsIGluc3RlYWQgb2YgdmFsdWVcblx0XHRcdC8vIChub3QgYXBwbGljYWJsZSBmb3IgY29sb3JwaWNrZXIgc2V0dGluZ3MgXHUyMDE0IHRoZXkgaGF2ZSBubyBkaXNjcmV0ZSBjaG9pY2VzKVxuXHRcdFx0Y29uc3QgaXNDb2xvclNldHRpbmcgPSBzZXR0aW5nLm9wdGlvbnM/LnNvbWUoKG86IGFueSkgPT4gby5pZCA9PT0gJ3ZhbHVlJyAmJiBvLnR5cGUgPT09ICdjb2xvcnBpY2tlcicpXG5cdFx0XHRpZiAoIWlzQ29sb3JTZXR0aW5nKSB7XG5cdFx0XHRcdHZhbHVlT3B0aW9ucy5wdXNoKHtcblx0XHRcdFx0XHR0eXBlOiAnY2hlY2tib3gnLFxuXHRcdFx0XHRcdGlkOiAnc2hvd0xhYmVsJyxcblx0XHRcdFx0XHRsYWJlbDogJ1VzZSBMYWJlbCBmb3IgVmFsdWUnLFxuXHRcdFx0XHRcdGRlZmF1bHQ6IGZhbHNlLFxuXHRcdFx0XHRcdHRvb2x0aXA6ICdSZXR1cm4gdGhlIGxhYmVsIHRleHQgaW5zdGVhZCBvZiB0aGUgbnVtZXJpYyB2YWx1ZScsXG5cdFx0XHRcdH0pXG5cdFx0XHR9XG5cblx0XHRcdC8vIFZhbHVlIGZlZWRiYWNrIGZvciBhbGwgc2V0dGluZ3MgKGFwcGVhcnMgaW4gVmFyaWFibGVzIGxpc3QpXG5cdFx0XHRjb25zdCB2YWx1ZUZlZWRiYWNrOiBhbnkgPSB7XG5cdFx0XHRcdHR5cGU6ICd2YWx1ZScsXG5cdFx0XHRcdG5hbWU6IGBbTW9kZWwke21vZGVsfV0gJHtzZXR0aW5nLm5hbWV9YCxcblx0XHRcdFx0b3B0aW9uczogdmFsdWVPcHRpb25zLFxuXHRcdFx0XHRjYWxsYmFjazogKCkgPT4ge1xuXHRcdFx0XHRcdC8qIHdpcmVkIGxhdGVyIGluIFVwZGF0ZUZlZWRiYWNrcyAqL1xuXHRcdFx0XHRcdHJldHVybiAwXG5cdFx0XHRcdH0sXG5cdFx0XHR9XG5cblx0XHRcdGZlZWRiYWNrc1tiYXNlRmVlZGJhY2tJZF0gPSB2YWx1ZUZlZWRiYWNrXG5cblx0XHRcdC8vIEJvb2xlYW4gZmVlZGJhY2sgZm9yIE9mZi9PbiBkcm9wZG93bnMgXHUyMDE0IGFkZGl0aW9uYWwgZmVlZGJhY2sgZm9yIGJ1dHRvbiBjb2xvcmluZ1xuXHRcdFx0aWYgKGlzQm9vbGVhbkRyb3Bkb3duKHNldHRpbmcpKSB7XG5cdFx0XHRcdGNvbnN0IGJvb2xGZWVkYmFja0lkID0gYCR7YmFzZUZlZWRiYWNrSWR9X2Jvb2xgXG5cblx0XHRcdFx0Ly8gT3B0aW9ucyB3aXRob3V0ICd2YWx1ZScgKGJ1c0NoL2lkQWRkIHNlbGVjdG9ycyBvbmx5LCBpZiBwcmVzZW50KVxuXHRcdFx0XHRjb25zdCBib29sT3B0aW9ucyA9IGFsbE9wdGlvbnMuZmlsdGVyKChvcHQ6IGFueSkgPT4gb3B0LmlkICE9PSAndmFsdWUnKVxuXG5cdFx0XHRcdGNvbnN0IGJvb2xGZWVkYmFjazogYW55ID0ge1xuXHRcdFx0XHRcdHR5cGU6ICdib29sZWFuJyxcblx0XHRcdFx0XHRuYW1lOiBgW01vZGVsJHttb2RlbH1dICR7c2V0dGluZy5uYW1lfSBcdTIwMTQgSXMgT25gLFxuXHRcdFx0XHRcdGRlZmF1bHRTdHlsZToge1xuXHRcdFx0XHRcdFx0Ymdjb2xvcjogY29tYmluZVJnYigwLCAyMDAsIDApLFxuXHRcdFx0XHRcdFx0Y29sb3I6IGNvbWJpbmVSZ2IoMCwgMCwgMCksXG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0XHRvcHRpb25zOiBib29sT3B0aW9ucyxcblx0XHRcdFx0XHRjYWxsYmFjazogKCkgPT4ge1xuXHRcdFx0XHRcdFx0Lyogd2lyZWQgbGF0ZXIgaW4gVXBkYXRlRmVlZGJhY2tzICovXG5cdFx0XHRcdFx0XHRyZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHR9XG5cblx0XHRcdFx0ZmVlZGJhY2tzW2Jvb2xGZWVkYmFja0lkXSA9IGJvb2xGZWVkYmFja1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdHJldHVybiBmZWVkYmFja3Ncbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRBY3Rpb25zIH0gZnJvbSAnLi9idWlsZC1jb21tYW5kcy5qcydcbmltcG9ydCB7IGdldERldmljZXNGb2xkZXIsIGdldERldmljZVNjaGVtYSwgZ2V0RGV2aWNlU2NoZW1hcywgcmVsb2FkRGV2aWNlU2NoZW1hcyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgcGFyc2VTZXR0aW5nSWQsIGdldE5vcm1hbGl6ZWRTY2hlbWFzIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJ1xuXG5pbXBvcnQgeyBwYXJzZUdldEFsbFNldHRpbmdzV2l0aERldGVjdGlvbiwgc2F2ZU1vZGVsSnNvblByZXR0eSwgdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzIH0gZnJvbSAnLi9zZXR0aW5nc1BhcnNlci5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdBY3Rpb25zJylcblxuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZUFjdGlvbnMoc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3Qgc2NoZW1hc1JhdyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCByYXdBY3Rpb25zID0gYnVpbGRBY3Rpb25zKClcblx0Y29uc3Qgc2NoZW1hcyA9IGdldE5vcm1hbGl6ZWRTY2hlbWFzKHNjaGVtYXNSYXcpXG5cdGNvbnN0IHdpcmVkQWN0aW9uczogYW55ID0ge31cblxuXHRjb25zdCBhY3RpdmVNb2RlbCA9IHNlbGYuYWN0aXZlTW9kZWxcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEdMT0JBTDogR0VUIEFMTCBTRVRUSU5HUyAoQVVUTyBKU09OIFVQREFURSkgXHUyMDE0IERldiBNb2RlIG9ubHlcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0aWYgKHNlbGYuY29uZmlnLmRldk1vZGUpIHtcblx0XHR3aXJlZEFjdGlvbnNbJ2dsb2JhbF9nZXRBbGxTZXR0aW5ncyddID0ge1xuXHRcdFx0bmFtZTogJ0dMT0JBTDogR2V0IEFsbCBTZXR0aW5ncycsXG5cdFx0XHRkZXNjcmlwdGlvbjogJ1VzZSB0aGlzIHRvIGNyZWF0ZSBhIHNjaGVtYSBmb3IgYSBuZXcgZGV2aWNlJyxcblx0XHRcdG9wdGlvbnM6IFtdLFxuXHRcdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdFx0Y29uc3QgbW9kZWwgPSBhY3RpdmVNb2RlbFxuXHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXG5cdFx0XHRcdGNvbnN0IGJ1ZiA9IGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhpcClcblxuXHRcdFx0XHRsZXQgbW9kZWxKc29uID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXG5cdFx0XHRcdGNvbnN0IHsgc2V0dGluZ3M6IHBhcnNlZCB9ID0gcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24obW9kZWwsIGJ1Zilcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBwYXJzZWQgcmVwbHk6ICR7SlNPTi5zdHJpbmdpZnkocGFyc2VkKX1gKVxuXG5cdFx0XHRcdGlmICghbW9kZWxKc29uKSB7XG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYE1vZGVsICR7bW9kZWx9IGhhcyBubyBzY2hlbWEgXHUyMDE0IGNyZWF0aW5nIG5ldyBKU09OIGZyb20gc2V0dGluZ3NgKVxuXHRcdFx0XHRcdG1vZGVsSnNvbiA9IHtcblx0XHRcdFx0XHRcdG1vZGVsLFxuXHRcdFx0XHRcdFx0Y21kU2NoZW1hOiBbXSxcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRjb25zdCB1cGRhdGVkID0gdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzKG1vZGVsSnNvbiwgcGFyc2VkLCBzY2hlbWFzKVxuXHRcdFx0XHRsb2dnZXIuZGVidWcoYG5ldyBBY3Rpb25zIGpzb246ICR7SlNPTi5zdHJpbmdpZnkodXBkYXRlZCwgbnVsbCwgMil9YClcblxuXHRcdFx0XHRjb25zdCBkZXZpY2VzRm9sZGVyID0gZ2V0RGV2aWNlc0ZvbGRlcigpXG5cdFx0XHRcdGNvbnN0IHNjaGVtYVBhdGggPSBwYXRoLmpvaW4oZGV2aWNlc0ZvbGRlciwgYE1vZGVsJHttb2RlbH0uanNvbmApXG5cdFx0XHRcdHNhdmVNb2RlbEpzb25QcmV0dHkoc2NoZW1hUGF0aCwgdXBkYXRlZClcblxuXHRcdFx0XHRyZWxvYWREZXZpY2VTY2hlbWFzKClcblxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgTW9kZWwgJHttb2RlbH0gSlNPTiBhdXRvLXVwZGF0ZWQgZnJvbSBnZXRBbGxTZXR0aW5nc2ApXG5cdFx0XHR9LFxuXHRcdH1cblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgQlVJTEQgUEVSLVNFVFRJTkcgQUNUSU9OUyAoRklMVEVSRUQgQlkgQUNUSVZFIE1PREVMKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHRmb3IgKGNvbnN0IFthY3Rpb25JZCwgYWN0aW9uXSBvZiBPYmplY3QuZW50cmllcyhyYXdBY3Rpb25zKSkge1xuXHRcdGNvbnN0IHsgbW9kZWwsIGNtZElkLCBiYXNlSWQgfSA9IHBhcnNlU2V0dGluZ0lkKGFjdGlvbklkKVxuXG5cdFx0Ly8gT25seSBpbmNsdWRlIGFjdGlvbnMgZm9yIHRoZSBjdXJyZW50bHkgYWN0aXZlIG1vZGVsXG5cdFx0aWYgKG1vZGVsICE9PSBhY3RpdmVNb2RlbCkgY29udGludWVcblxuXHRcdC8vIEdldCB0aGUgcmF3IGFjdGlvbiBzY2hlbWEgdG8gYWNjZXNzIGZpeGVkIGJ1c0NoIGFuZCB2YWx1ZSBwcm9wZXJ0aWVzLlxuXHRcdC8vIFVzZSBzY2hlbWFzUmF3IChub3QgdGhlIG5vcm1hbGl6ZWQgc2NoZW1hcykgdG8gcHJlc2VydmUgdG9wLWxldmVsIGZpZWxkc1xuXHRcdC8vIGxpa2UgYHZhbHVlYCB0aGF0IG5vcm1hbGl6YXRpb24gbWF5IHN0cmlwLlxuXHRcdGNvbnN0IHJhd1NjaGVtYSA9IHNjaGVtYXNSYXdbbW9kZWxdXG5cdFx0Y29uc3QgcmF3QWN0aW9uID0gcmF3U2NoZW1hPy5jbWRTY2hlbWE/LmZpbmQoKGE6IGFueSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IGJhc2VJZClcblxuXHRcdHdpcmVkQWN0aW9uc1thY3Rpb25JZF0gPSB7XG5cdFx0XHQuLi5hY3Rpb24sXG5cdFx0XHRjYWxsYmFjazogYXN5bmMgKGV2ZW50OiBhbnkpID0+IHtcblx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3Rcblx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBldmVudC5vcHRpb25zWydidXNDaCddICE9PSB1bmRlZmluZWQgPyBldmVudC5vcHRpb25zWydidXNDaCddIDogcmF3QWN0aW9uPy5idXNDaFxuXHRcdFx0XHRjb25zdCB2YWx1ZSA9IHJhd0FjdGlvbj8udmFsdWUgIT09IHVuZGVmaW5lZCA/IHJhd0FjdGlvbi52YWx1ZSA6IGV2ZW50Lm9wdGlvbnNbJ3ZhbHVlJ11cblx0XHRcdFx0Y29uc3QgaWRBZGQgPSBldmVudC5vcHRpb25zWydpZEFkZCddID8/IDBcblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gYmFzZUlkICsgaWRBZGRcblxuXHRcdFx0XHRhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5zZW5kQXdhaXRBY2soY21kSWQsIGJ1c0NoLCBzZXR0aW5nSWQsIHZhbHVlLCBpcClcblx0XHRcdH0sXG5cdFx0XHQuLi4ocmF3QWN0aW9uPy52YWx1ZSA9PT0gdW5kZWZpbmVkICYmIHtcblx0XHRcdFx0bGVhcm46IChldmVudDogYW55KSA9PiB7XG5cdFx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3Rcblx0XHRcdFx0XHRjb25zdCBpZEFkZCA9IGV2ZW50Lm9wdGlvbnNbJ2lkQWRkJ10gPz8gMFxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGJhc2VJZCArIGlkQWRkXG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBldmVudC5vcHRpb25zWydidXNDaCddICE9PSB1bmRlZmluZWQgPyBldmVudC5vcHRpb25zWydidXNDaCddIDogcmF3QWN0aW9uPy5idXNDaFxuXG5cdFx0XHRcdFx0Y29uc3QgY3VycmVudCA9IHNlbGYuc3RDb250cm9sbGVyLmdldFNldHRpbmdWYWx1ZShpcCwgY21kSWQsIHNldHRpbmdJZCwgYnVzQ2gpXG5cdFx0XHRcdFx0aWYgKGN1cnJlbnQgPT09IHVuZGVmaW5lZCkgcmV0dXJuIHVuZGVmaW5lZFxuXG5cdFx0XHRcdFx0cmV0dXJuIHsgLi4uZXZlbnQub3B0aW9ucywgdmFsdWU6IGN1cnJlbnQgfVxuXHRcdFx0XHR9LFxuXHRcdFx0fSksXG5cdFx0fVxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBNSUMgS0lMTCAoT05MWSBJRiBBQ1RJVkUgTU9ERUwgU1VQUE9SVFMgSVQpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHRjb25zdCBhY3RpdmVTY2hlbWEgPSBzY2hlbWFzW2FjdGl2ZU1vZGVsXVxuXHRpZiAoYWN0aXZlU2NoZW1hKSB7XG5cdFx0Y29uc3Qgc3VwcG9ydHNNaWNLaWxsID0gKGFjdGl2ZVNjaGVtYS5jbWRTY2hlbWEgPz8gW10pLnNvbWUoKGE6IGFueSkgPT4gYS5uYW1lLmluY2x1ZGVzKCdLaWxsJykpXG5cblx0XHRpZiAoc3VwcG9ydHNNaWNLaWxsKSB7XG5cdFx0XHRjb25zdCBhY3Rpb25JZCA9IGAke2FjdGl2ZU1vZGVsfV9taWNLaWxsYFxuXG5cdFx0XHR3aXJlZEFjdGlvbnNbYWN0aW9uSWRdID0ge1xuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHthY3RpdmVNb2RlbH1dIE1pYyBLaWxsYCxcblx0XHRcdFx0b3B0aW9uczogW10sXG5cdFx0XHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3Rcblx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgTWljIEtpbGwgXHUyMTkyIE1vZGVsICR7YWN0aXZlTW9kZWx9IEAgJHtpcH1gKVxuXHRcdFx0XHRcdGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLmdsb2JhbE1pY0tpbGwoaXApXG5cdFx0XHRcdFx0YXdhaXQgc2VsZi5zdENvbnRyb2xsZXIucmVxdWVzdEFsbFNldHRpbmdzKGlwKS5jYXRjaCgoZXJyKSA9PiB7XG5cdFx0XHRcdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIHJlZnJlc2ggc2V0dGluZ3MgYWZ0ZXIgY29tbWFuZDogJHtlcnJ9YClcblx0XHRcdFx0XHR9KVxuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdHNlbGYuc2V0QWN0aW9uRGVmaW5pdGlvbnMod2lyZWRBY3Rpb25zKVxufVxuIiwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCB7IGdldERldmljZVNjaGVtYSB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7XG5cdENNRF9NSUNfUFJFLFxuXHRDTURfQlVTX1NFVCxcblx0Q01EX0NIQU5ORUwsXG5cdENNRF9HRVRfQUxMX1NFVFRJTkdTLFxuXHRDTURfTUlDX1BSRV9CVVMsXG5cdENNRF9TRVRUSU5HU19QVVNILFxuXHR0b0hleCxcblx0Ynl0ZXNUb0hleCxcblx0Zm9ybWF0UmdiQ29sb3IsXG5cdG1vZGVsRGlzdGFuY2UsXG59IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignU2V0dGluZ3NQYXJzZXInKVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBUWVBFU1xuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgdHlwZSBQYXJzZWRTZXR0aW5nID0ge1xuXHRjbWRfaWQ6IG51bWJlclxuXHRpZDogbnVtYmVyXG5cdGJ1c0NoPzogbnVtYmVyIC8vIE9wdGlvbmFsOiBvbmx5IHByZXNlbnQgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2ggKDB4MDQsIDB4MTIsIDB4MTQpXG5cdHZhbHVlQnl0ZXM6IG51bWJlcltdXG59XG5cbmV4cG9ydCB0eXBlIFN0QWN0aW9uT3B0aW9uID0ge1xuXHRpZD86IHN0cmluZ1xuXHRsYWJlbDogc3RyaW5nXG5cdHR5cGU6IHN0cmluZ1xuXHRkZWZhdWx0OiB1bmtub3duXG5cdHRvb2x0aXA/OiBzdHJpbmdcblx0Y2hvaWNlcz86IEFycmF5PHsgaWQ6IG51bWJlcjsgbGFiZWw6IHN0cmluZyB9PlxufVxuXG5leHBvcnQgdHlwZSBTdEFjdGlvbiA9IHtcblx0Y21kX2lkOiBudW1iZXJcblx0aWQ6IG51bWJlclxuXHRuYW1lOiBzdHJpbmdcblx0b3B0aW9uczogU3RBY3Rpb25PcHRpb25bXVxuXHRidXNDaD86IG51bWJlciAvLyBGaXhlZCBjaGFubmVsIHZhbHVlIGZvciBhY3Rpb25zIHRoYXQgZG9uJ3QgaGF2ZSBhIGNoYW5uZWwgb3B0aW9uXG5cdHZhbHVlPzogbnVtYmVyIC8vIEZpeGVkIHZhbHVlIFx1MjAxNCBhY3Rpb24gYWx3YXlzIHNlbmRzIHRoaXMgdmFsdWUsIG5vIHVzZXIgaW5wdXQgbmVlZGVkXG5cdHJlYWRvbmx5PzogYm9vbGVhbiAvLyBJZiB0cnVlLCBlbnRyeSBpcyBmZWVkYmFjay1vbmx5IFx1MjAxNCBubyBhY3Rpb24gd2lsbCBiZSBjcmVhdGVkXG5cdHdyaXRlb25seT86IGJvb2xlYW4gLy8gSWYgdHJ1ZSwgZW50cnkgaXMgYWN0aW9uLW9ubHkgXHUyMDE0IG5vIGZlZWRiYWNrIHdpbGwgYmUgY3JlYXRlZCAoZGV2aWNlIG5ldmVyIHJlcG9ydHMgdGhpcyB2YWx1ZSBiYWNrKVxufVxuXG5leHBvcnQgdHlwZSBTdE1vZGVsSnNvbiA9IHtcblx0bW9kZWw6IHN0cmluZ1xuXHR1c2VDb25Nb24/OiBib29sZWFuXG5cdGNtZFNjaGVtYTogU3RBY3Rpb25bXVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBGT1JNQVQgSEVMUEVSU1xuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBnZXRSZ2JJZHMobW9kZWw6IHN0cmluZyk6IFNldDxudW1iZXI+IHtcblx0Y29uc3QgcmdiSWRzID0gbmV3IFNldDxudW1iZXI+KClcblx0dHJ5IHtcblx0XHRjb25zdCBqc29uID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRcdGlmICghanNvbikgcmV0dXJuIHJnYklkc1xuXHRcdGZvciAoY29uc3QgYWN0aW9uIG9mIGpzb24uY21kU2NoZW1hIHx8IFtdKSB7XG5cdFx0XHRjb25zdCBoYXNDb2xvcnBpY2tlciA9IGFjdGlvbi5vcHRpb25zPy5zb21lKChvcHQ6IFN0QWN0aW9uT3B0aW9uKSA9PiBvcHQudHlwZSA9PT0gJ2NvbG9ycGlja2VyJylcblx0XHRcdGlmIChoYXNDb2xvcnBpY2tlcikge1xuXHRcdFx0XHRyZ2JJZHMuYWRkKGFjdGlvbi5pZClcblx0XHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgob3B0OiBTdEFjdGlvbk9wdGlvbikgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRpZiAoaWRBZGRPcHRpb24/LmNob2ljZXMpIHtcblx0XHRcdFx0XHRmb3IgKGNvbnN0IGNob2ljZSBvZiBpZEFkZE9wdGlvbi5jaG9pY2VzKSB7XG5cdFx0XHRcdFx0XHRpZiAodHlwZW9mIGNob2ljZS5pZCA9PT0gJ251bWJlcicpIHtcblx0XHRcdFx0XHRcdFx0cmdiSWRzLmFkZChhY3Rpb24uaWQgKyBjaG9pY2UuaWQpXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHR9IGNhdGNoIChfZXJyKSB7XG5cdFx0Ly8gcmV0dXJuIGVtcHR5IHNldCBvbiBlcnJvclxuXHR9XG5cdHJldHVybiByZ2JJZHNcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgRklORCBUSEUgUkVBTCA1QSBQQVlMT0FEIElOREVYXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIGV4dHJhY3RTdFBheWxvYWRJbmRleChidWY6IEJ1ZmZlcik6IG51bWJlciB7XG5cdGNvbnN0IHNpZ0luZGV4ID0gYnVmLmluZGV4T2YoQnVmZmVyLmZyb20oJ1N0dWRpby1UJykpXG5cdGlmIChzaWdJbmRleCA8IDApIHRocm93IG5ldyBFcnJvcignTm8gU3R1ZGlvLVQgc2lnbmF0dXJlIGluIHBhY2tldCcpXG5cblx0Y29uc3QgcGF5bG9hZEluZGV4ID0gc2lnSW5kZXggKyA4XG5cdGlmIChidWZbcGF5bG9hZEluZGV4XSAhPT0gMHg1YSkge1xuXHRcdHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgMHg1QSBhZnRlciBTdHVkaW8tVCwgZm91bmQgJHtidWZbcGF5bG9hZEluZGV4XS50b1N0cmluZygxNil9YClcblx0fVxuXG5cdHJldHVybiBwYXlsb2FkSW5kZXhcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgU0VDVElPTkVEIFBBUlNFUlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWY6IEJ1ZmZlciwgbW9kZWw6IHN0cmluZyk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcignTm90IGEgZ2V0QWxsU2V0dGluZ3MgcmVwbHknKVxuXHR9XG5cblx0Ly8gQ01EX0dFVF9BTExfU0VUVElOR1MgaGFzIGEgdG90YWwtbGVuZ3RoIGJ5dGUgYXQgaWR4KzIgYmVmb3JlIHRoZSBzZWN0aW9uczsgQ01EX1NFVFRJTkdTX1BVU0ggZG9lcyBub3QuXG5cdGxldCBwID0gY21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTID8gaWR4ICsgMyA6IGlkeCArIDJcblx0Y29uc3QgZW5kID0gYnVmLmxlbmd0aCAtIDFcblx0Y29uc3Qgb3V0OiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXG5cdGNvbnN0IHJnYklkcyA9IGdldFJnYklkcyhtb2RlbClcblxuXHQvLyBDb21tYW5kIElEcyB0aGF0IGluY2x1ZGUgYSBidXNDaCBieXRlIGluIHRoZWlyIHNlY3Rpb24gc3RydWN0dXJlLFxuXHQvLyBmb2xsb3dlZCBieSBhIGRhdGFMZW4gYnl0ZSBhbmQgdGhlbiBpZDp2YWwgcGFpcnMuXG5cdGNvbnN0IGNvbW1hbmRzV2l0aEJ1c0NoID0gW0NNRF9CVVNfU0VULCBDTURfTUlDX1BSRV9CVVMsIENNRF9DSEFOTkVMXVxuXG5cdC8vIENvbW1hbmQgSURzIHRoYXQgaW5jbHVkZSBhIGJ1c0NoIGJ5dGUgYnV0IHN0b3JlIHJhdyBwb3NpdGlvbmFsIHZhbHVlIGJ5dGVzXG5cdC8vIHJhdGhlciB0aGFuIGlkOnZhbCBwYWlycyAobm8gZGF0YUxlbiBieXRlLCBubyBzZXR0aW5nIElEcykuXG5cdC8vIEZvcm1hdDogW2NtZExlbl0gW2NtZElkXSBbYnVzQ2hdIFt2YWwwXSBbdmFsMV0gLi4uXG5cdGNvbnN0IGNvbW1hbmRzUmF3VmFsdWUgPSBbQ01EX01JQ19QUkVdIC8vIGNtZD0weDAyXG5cblx0d2hpbGUgKHAgKyAyIDwgZW5kKSB7XG5cdFx0Y29uc3QgY21kTGVuID0gYnVmW3BdXG5cdFx0Y29uc3Qgc2VjdGlvbkNtZElkID0gYnVmW3AgKyAxXVxuXG5cdFx0Y29uc3Qgc2VjdGlvbkVuZCA9IHAgKyAxICsgY21kTGVuXG5cdFx0aWYgKHNlY3Rpb25FbmQgPiBlbmQpIGJyZWFrXG5cblx0XHRjb25zdCBoYXNCdXNDaCA9IGNvbW1hbmRzV2l0aEJ1c0NoLmluY2x1ZGVzKHNlY3Rpb25DbWRJZClcblx0XHRjb25zdCBpc1Jhd1ZhbHVlID0gY29tbWFuZHNSYXdWYWx1ZS5pbmNsdWRlcyhzZWN0aW9uQ21kSWQpXG5cblx0XHRsZXQgYnVzQ2g6IG51bWJlciB8IHVuZGVmaW5lZFxuXHRcdGxldCBkYXRhTGVuOiBudW1iZXJcblx0XHRsZXQgcTogbnVtYmVyXG5cblx0XHRpZiAoaXNSYXdWYWx1ZSkge1xuXHRcdFx0Ly8gU3RydWN0dXJlOiBbY21kTGVuXSBbY21kSWRdIFtidXNDaF0gW3ZhbDBdIFt2YWwxXSAuLi5cblx0XHRcdC8vIEJ1aWxkIHBvc2l0aW9uYWwgbWFwIGZyb20gc2NoZW1hOiBmaW5kIGFsbCBlbnRyaWVzIGZvciBDTURfTUlDX1BSRSAoMHgwMikgb3Jcblx0XHRcdC8vIENNRF9NSUNfUFJFX0JVUyAoMHgxMikgd2l0aCBhIGZpeGVkIGJ1c0NoLCBzb3J0ZWQgYnkgaWQgXHUyMDE0IGVhY2ggYmVjb21lcyBvbmVcblx0XHRcdC8vIHBvc2l0aW9uYWwgc2xvdC4gVGhpcyBtYWtlcyB0aGUgcmVtYXAgc2NoZW1hLWRyaXZlbjpcblx0XHRcdC8vICAgMjE0ICAoY21kX2lkPTIsICBpZD0wLzEpIFx1MjE5MiBwb3MwXHUyMTkyKDIsMCksICBwb3MxXHUyMTkyKDIsMSlcblx0XHRcdC8vICAgMjE0QSAoY21kX2lkPTE4LCBpZD0xLzIpIFx1MjE5MiBwb3MwXHUyMTkyKDE4LDEpLCBwb3MxXHUyMTkyKDE4LDIpXG5cdFx0XHQvLyBQb3NpdGlvbnMgd2l0aCBubyBzY2hlbWEgZW50cnkgYXJlIGRyb3BwZWQgKGUuZy4gdW5rbm93biAzcmQgYnl0ZSkuXG5cdFx0XHRidXNDaCA9IGJ1ZltwICsgMl1cblx0XHRcdGNvbnN0IHJhd0J5dGVzID0gYnVmLnN1YmFycmF5KHAgKyAzLCBzZWN0aW9uRW5kKVxuXG5cdFx0XHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdFx0XHRjb25zdCBtaWNQcmVFbnRyaWVzID0gKHNjaGVtYT8uY21kU2NoZW1hID8/IFtdKVxuXHRcdFx0XHQuZmlsdGVyKChhOiBTdEFjdGlvbikgPT4gKGEuY21kX2lkID09PSBDTURfTUlDX1BSRSB8fCBhLmNtZF9pZCA9PT0gQ01EX01JQ19QUkVfQlVTKSAmJiBhLmJ1c0NoICE9PSB1bmRlZmluZWQpXG5cdFx0XHRcdC5zb3J0KChhOiBTdEFjdGlvbiwgYjogU3RBY3Rpb24pID0+IGEuaWQgLSBiLmlkKVxuXG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IHJhd0J5dGVzLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRcdGNvbnN0IGVudHJ5ID0gbWljUHJlRW50cmllc1tpXVxuXHRcdFx0XHRpZiAoZW50cnkpIHtcblx0XHRcdFx0XHRvdXQucHVzaCh7IGNtZF9pZDogZW50cnkuY21kX2lkLCBpZDogZW50cnkuaWQsIGJ1c0NoLCB2YWx1ZUJ5dGVzOiBbcmF3Qnl0ZXNbaV1dIH0pXG5cdFx0XHRcdH1cblx0XHRcdFx0Ly8gbm8gZW50cnkgPSB1bmtub3duIHBvc2l0aW9uYWwgYnl0ZSwgZHJvcCBpdFxuXHRcdFx0fVxuXHRcdFx0cCA9IHNlY3Rpb25FbmRcblx0XHRcdGNvbnRpbnVlXG5cdFx0fSBlbHNlIGlmIChoYXNCdXNDaCkge1xuXHRcdFx0Ly8gU3RydWN0dXJlOiBbY21kTGVuXSBbY21kSWRdIFtidXNDaF0gW2RhdGFMZW5dIFtpZDp2YWwgcGFpcnNdXG5cdFx0XHRidXNDaCA9IGJ1ZltwICsgMl1cblx0XHRcdGRhdGFMZW4gPSBidWZbcCArIDNdXG5cdFx0XHRxID0gcCArIDRcblx0XHR9IGVsc2Uge1xuXHRcdFx0Ly8gU3RydWN0dXJlOiBbY21kTGVuXSBbY21kSWRdIFtkYXRhTGVuXSBbaWQ6dmFsIHBhaXJzXVxuXHRcdFx0ZGF0YUxlbiA9IGJ1ZltwICsgMl1cblx0XHRcdHEgPSBwICsgM1xuXHRcdH1cblxuXHRcdGNvbnN0IHFFbmQgPSBxICsgZGF0YUxlblxuXHRcdGNvbnN0IHFTdGFydCA9IHFcblxuXHRcdHdoaWxlIChxICsgMSA8IHFFbmQpIHtcblx0XHRcdGNvbnN0IGlkID0gYnVmW3FdXG5cdFx0XHRsZXQgdmFsdWVCeXRlczogbnVtYmVyW11cblxuXHRcdFx0Ly8gQ2hlY2sgaWYgdGhpcyBJRCBpcyBhbiBSR0IgY29sb3JwaWNrZXIgKG5lZWRzIDMgYnl0ZXMpXG5cdFx0XHRpZiAocmdiSWRzLmhhcyhpZCkgJiYgcSArIDMgPCBxRW5kKSB7XG5cdFx0XHRcdHZhbHVlQnl0ZXMgPSBbYnVmW3EgKyAxXSwgYnVmW3EgKyAyXSwgYnVmW3EgKyAzXV1cblx0XHRcdFx0cSArPSA0XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHR2YWx1ZUJ5dGVzID0gW2J1ZltxICsgMV1dXG5cdFx0XHRcdHEgKz0gMlxuXHRcdFx0fVxuXG5cdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0ge1xuXHRcdFx0XHRjbWRfaWQ6IHNlY3Rpb25DbWRJZCxcblx0XHRcdFx0aWQsXG5cdFx0XHRcdHZhbHVlQnl0ZXMsXG5cdFx0XHR9XG5cdFx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRzZXR0aW5nLmJ1c0NoID0gYnVzQ2hcblx0XHRcdH1cblx0XHRcdG91dC5wdXNoKHNldHRpbmcpXG5cdFx0fVxuXG5cdFx0Ly8gUG9zaXRpb25hbCBmYWxsYmFjazogaWYgdGhlIGJ5dGUgd2UgcmVhZCBhcyBkYXRhTGVuIHdhcyAweDAwIGJ1dCB0aGUgc2VjdGlvblxuXHRcdC8vIHN0aWxsIGNvbnRhaW5zIGRhdGEgYnl0ZXMsIHRoaXMgc2VjdGlvbiBsaWtlbHkgdXNlcyBhIG5vLWRhdGFMZW4gZm9ybWF0IHdoZXJlXG5cdFx0Ly8gZWFjaCBieXRlIGFmdGVyIGNtZElkIGlzIGEgcmF3IHZhbHVlIGF0IGEgZml4ZWQgcG9zaXRpb24gKHBvc2l0aW9uID0gaWQpLlxuXHRcdC8vIFJlLXBhcnNlIGZyb20gcCsyIChyaWdodCBhZnRlciBjbWRJZCksIHRyZWF0aW5nIHRoZSBcImRhdGFMZW5cIiBieXRlIGFzIGlkPTAuXG5cdFx0Ly8gT25seSBmaXJlIGlmIG5vIGJ5dGVzIHdlcmUgY29uc3VtZWQgYnkgdGhlIG1haW4gbG9vcCAocSA9PT0gcVN0YXJ0KSwgdG8gYXZvaWRcblx0XHQvLyByZS1wYXJzaW5nIGJ5dGVzIHRoYXQgd2VyZSBhbHJlYWR5IHN1Y2Nlc3NmdWxseSBwYXJzZWQuXG5cdFx0aWYgKHEgPT09IHFTdGFydCAmJiBzZWN0aW9uRW5kID4gcCArIDMpIHtcblx0XHRcdGxldCBwb3MgPSBoYXNCdXNDaCA/IHAgKyAzIDogcCArIDIgLy8gc2tpcCBjbWRJZCAoYW5kIGJ1c0NoIGlmIHByZXNlbnQpXG5cdFx0XHRsZXQgcG9zSWQgPSAwXG5cdFx0XHR3aGlsZSAocG9zIDwgc2VjdGlvbkVuZCkge1xuXHRcdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0geyBjbWRfaWQ6IHNlY3Rpb25DbWRJZCwgaWQ6IHBvc0lkKyssIHZhbHVlQnl0ZXM6IFtidWZbcG9zKytdXSB9XG5cdFx0XHRcdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSBzZXR0aW5nLmJ1c0NoID0gYnVzQ2hcblx0XHRcdFx0b3V0LnB1c2goc2V0dGluZylcblx0XHRcdH1cblx0XHR9XG5cblx0XHRwID0gc2VjdGlvbkVuZFxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBHRU5FUklDIFNFVFRJTkdTIFJFU1BPTlNFIFBBUlNFUiAoMHgwYSBnZXQtYWxsICsgMHgwYiB1bnNvbGljaXRlZCBwdXNoKVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIFBhcnNlcyBhbnkgZnVsbCBzZXR0aW5ncyBibG9jayByZWdhcmRsZXNzIG9mIHdoZXRoZXIgdGhlIGNtZElkIGlzIDB4MGFcbiAqIChyZXNwb25zZSB0byBHZXQgQWxsIFNldHRpbmdzKSBvciAweDBiICh1bnNvbGljaXRlZCBwdXNoIGFmdGVyIGEgc2V0KS5cbiAqIEJvdGggdXNlIHRoZSBzYW1lIHNlY3Rpb25lZCBvciBmbGF0IGJsb2NrIGxheW91dC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlU2V0dGluZ3NSZXNwb25zZShtb2RlbDogc3RyaW5nLCBidWY6IEJ1ZmZlcik6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcihgTm90IGEgc2V0dGluZ3MgYmxvY2sgKGNtZElkPTB4JHtjbWRJZC50b1N0cmluZygxNil9KWApXG5cdH1cblx0cmV0dXJuIHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpXG59XG5cbi8qKlxuICogRm9ybWF0cyBhIHNpbmdsZSBwYXJzZWQgc2V0dGluZyBpbnRvIGEgaHVtYW4tcmVhZGFibGUgc3RyaW5nIHVzaW5nIGFjdGlvblxuICogZGVmaW5pdGlvbnMgZnJvbSB0aGUgZGV2aWNlIEpTT04uIEZhbGxzIGJhY2sgdG8gaGV4IElEcyB3aGVuIHVua25vd24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRQYXJzZWRTZXR0aW5nKHNldHRpbmc6IFBhcnNlZFNldHRpbmcsIGFjdGlvbnM6IFN0QWN0aW9uW10pOiBzdHJpbmcge1xuXHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0bGV0IGFjdGlvbiA9IGFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IHNldHRpbmcuY21kX2lkICYmIGEuaWQgPT09IHNldHRpbmcuaWQpXG5cblx0Ly8gSWYgbm8gZXhhY3QgbWF0Y2ggYW5kIGlkID4gYmFzZSBpZCwgdHJ5IHRvIGZpbmQgYWN0aW9uIHdpdGggaWRBZGQgb3B0aW9uXG5cdC8vIFRoaXMgaGFuZGxlcyBjYXNlcyBsaWtlIENNRF9IRUFEUEhPTkUgKDB4MDUsIGUuZy4gUGhvbmVzIFJvdXRpbmcpIGFuZFxuXHQvLyBDTURfQlVUVE9OX01PREUgKDB4MDcsIGUuZy4gQnV0dG9ucykgd2hlcmUgaWQgMC0zIHJlcHJlc2VudHMgY2hhbm5lbHMgMS00XG5cdGlmICghYWN0aW9uKSB7XG5cdFx0Y29uc3QgYmFzZUFjdGlvbiA9IGFjdGlvbnMuZmluZCgoYSkgPT4ge1xuXHRcdFx0aWYgKGEuY21kX2lkICE9PSBzZXR0aW5nLmNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiB0aGlzIGFjdGlvbiBoYXMgYW4gaWRBZGQgb3B0aW9uIChpbmRpY2F0aW5nIGNoYW5uZWwgc2VsZWN0aW9uKVxuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdGlvbj8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiB0aGUgc2V0dGluZy5pZCBvZmZzZXQgbWF0Y2hlcyBvbmUgb2YgdGhlIGlkQWRkIGNob2ljZSBJRHNcblx0XHRcdGNvbnN0IGNoYW5uZWxPZmZzZXQgPSBzZXR0aW5nLmlkIC0gYS5pZFxuXHRcdFx0cmV0dXJuIGlkQWRkT3B0aW9uLmNob2ljZXMuc29tZSgoYykgPT4gYy5pZCA9PT0gY2hhbm5lbE9mZnNldClcblx0XHR9KVxuXHRcdGlmIChiYXNlQWN0aW9uKSB7XG5cdFx0XHRhY3Rpb24gPSBiYXNlQWN0aW9uXG5cdFx0fVxuXHR9XG5cblx0Y29uc3QgY21kSGV4ID0gdG9IZXgoc2V0dGluZy5jbWRfaWQpXG5cdGNvbnN0IGlkSGV4ID0gdG9IZXgoc2V0dGluZy5pZClcblx0Y29uc3QgdmFsSGV4ID0gYnl0ZXNUb0hleChzZXR0aW5nLnZhbHVlQnl0ZXMpXG5cdGNvbnN0IHZhbERlYyA9XG5cdFx0c2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gM1xuXHRcdFx0PyBmb3JtYXRSZ2JDb2xvcihzZXR0aW5nLnZhbHVlQnl0ZXNbMF0sIHNldHRpbmcudmFsdWVCeXRlc1sxXSwgc2V0dGluZy52YWx1ZUJ5dGVzWzJdKVxuXHRcdFx0OiBzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAxXG5cdFx0XHRcdD8gc2V0dGluZy52YWx1ZUJ5dGVzWzBdXG5cdFx0XHRcdDogc2V0dGluZy52YWx1ZUJ5dGVzLmpvaW4oJywnKVxuXG5cdC8vIEJ1aWxkIHRoZSBwcmVmaXg6IGNtZDoweDEyIGNoOjAgaWQ6MHgwMSB2YWw6MHgxNCAoY2ggb25seSBmb3IgY29tbWFuZHMgd2l0aCBidXNDaClcblx0Y29uc3QgYnVzQ2hTdHIgPSBzZXR0aW5nLmJ1c0NoICE9PSB1bmRlZmluZWQgPyBgIGNoOiR7c2V0dGluZy5idXNDaH1gIDogJydcblx0Y29uc3QgcHJlZml4ID0gYGNtZDoke2NtZEhleH0ke2J1c0NoU3RyfSBpZDoke2lkSGV4fSB2YWw6JHt2YWxIZXh9YFxuXG5cdC8vIElmIHdlIGhhdmUgYW4gYWN0aW9uIHdpdGggYSBuYW1lIGFuZCBjaG9pY2UgbGFiZWwsIHVzZSBpdFxuXHRpZiAoYWN0aW9uKSB7XG5cdFx0bGV0IG5hbWUgPSBhY3Rpb24ubmFtZVxuXG5cdFx0Ly8gSWYgc2V0dGluZyBoYXMgYnVzQ2gsIGFkZCBjaGFubmVsIGluZm8gdG8gbmFtZVxuXHRcdGlmIChzZXR0aW5nLmJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdG5hbWUgPSBgJHtuYW1lfSBDaCR7c2V0dGluZy5idXNDaCArIDF9YFxuXHRcdH1cblx0XHQvLyBPdGhlcndpc2UsIGlmIHRoaXMgYWN0aW9uIGhhcyBpZEFkZCwgaW5jbHVkZSB0aGUgaWRBZGQgbGFiZWxcblx0XHRlbHNlIHtcblx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKGlkQWRkT3B0aW9uPy5jaG9pY2VzKSB7XG5cdFx0XHRcdGNvbnN0IGNoYW5uZWxPZmZzZXQgPSBzZXR0aW5nLmlkIC0gYWN0aW9uLmlkXG5cdFx0XHRcdGNvbnN0IGlkQWRkQ2hvaWNlID0gaWRBZGRPcHRpb24uY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSBjaGFubmVsT2Zmc2V0KVxuXHRcdFx0XHRpZiAoaWRBZGRDaG9pY2UpIHtcblx0XHRcdFx0XHRuYW1lID0gYCR7bmFtZX0gJHtpZEFkZENob2ljZS5sYWJlbH1gXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBMb29rIGZvciB0aGUgdmFsdWUgb3B0aW9uIChub3QgYnVzQ2ggb3IgaWRBZGQpXG5cdFx0Y29uc3QgdmFsdWVPcHRpb24gPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgob3B0KSA9PiBvcHQuaWQgPT09ICd2YWx1ZScpXG5cdFx0Ly8gRm9yIGZpeGVkLXZhbHVlIGFjdGlvbnMsIGZhbGwgYmFjayB0byB0aGUgdG9wLWxldmVsIHZhbHVlIHByb3BlcnR5XG5cdFx0Y29uc3QgZml4ZWRWYWx1ZSA9IChhY3Rpb24gYXMgYW55KS52YWx1ZVxuXHRcdGlmIChmaXhlZFZhbHVlICE9PSB1bmRlZmluZWQgJiYgdmFsdWVPcHRpb24gPT09IHVuZGVmaW5lZCkge1xuXHRcdFx0cmV0dXJuIGAke3ByZWZpeH0gfCAke25hbWV9OiAke2ZpeGVkVmFsdWV9YFxuXHRcdH1cblx0XHRpZiAodmFsdWVPcHRpb24/LmNob2ljZXMgJiYgc2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0Y29uc3QgY2hvaWNlID0gdmFsdWVPcHRpb24uY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSBzZXR0aW5nLnZhbHVlQnl0ZXNbMF0pXG5cdFx0XHRpZiAoY2hvaWNlKSB7XG5cdFx0XHRcdHJldHVybiBgJHtwcmVmaXh9IHwgJHtuYW1lfTogJHtjaG9pY2UubGFiZWx9ICgke3ZhbERlY30pYFxuXHRcdFx0fVxuXHRcdH1cblx0XHRyZXR1cm4gYCR7cHJlZml4fSB8ICR7bmFtZX06ICR7dmFsRGVjfWBcblx0fVxuXG5cdC8vIE5vIGFjdGlvbiBmb3VuZCAtIGp1c3Qgc2hvdyB0aGUgcmF3IHZhbHVlc1xuXHRyZXR1cm4gYCR7cHJlZml4fSB8IFVua25vd24gU2V0dGluZ2Bcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgUEFSU0VSIERJU1BBVENIIFdJVEggQVVUTy1ERVRFQ1RJT05cbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBQYXJzZXMgZ2V0QWxsU2V0dGluZ3MgcmVzcG9uc2Ugd2l0aCBhdXRvbWF0aWMgZm9ybWF0IGRldGVjdGlvbi5cbiAqXG4gKiBAcmV0dXJucyB7c2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXSwgZGV0ZWN0ZWRTZWN0aW9uZWQ6IGJvb2xlYW4gfCBudWxsfVxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24oXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGJ1ZjogQnVmZmVyLFxuKTogeyBzZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdOyBkZXRlY3RlZFNlY3Rpb25lZDogbnVsbCB9IHtcblx0Y29uc3Qgc2V0dGluZ3MgPSBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWYsIG1vZGVsKVxuXHRyZXR1cm4geyBzZXR0aW5ncywgZGV0ZWN0ZWRTZWN0aW9uZWQ6IG51bGwgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc0Zvck1vZGVsKG1vZGVsOiBzdHJpbmcsIGJ1ZjogQnVmZmVyKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0cmV0dXJuIHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFZBTFVFIFx1MjE5MiBPUFRJT05cbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZnVuY3Rpb24gdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXM6IG51bWJlcltdKTogU3RBY3Rpb25PcHRpb24ge1xuXHRpZiAodmFsdWVCeXRlcy5sZW5ndGggPT09IDEpIHtcblx0XHRyZXR1cm4geyBpZDogJ3ZhbHVlJywgbGFiZWw6ICdWYWx1ZScsIHR5cGU6ICdudW1iZXInLCBkZWZhdWx0OiB2YWx1ZUJ5dGVzWzBdIH1cblx0fVxuXG5cdGlmICh2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMykge1xuXHRcdGNvbnN0IFtyLCBnLCBiXSA9IHZhbHVlQnl0ZXNcblx0XHRyZXR1cm4ge1xuXHRcdFx0aWQ6ICd2YWx1ZScsXG5cdFx0XHRsYWJlbDogJ0NvbG9yJyxcblx0XHRcdHR5cGU6ICdjb2xvcnBpY2tlcicsXG5cdFx0XHRkZWZhdWx0OiBmb3JtYXRSZ2JDb2xvcihyLCBnLCBiKSxcblx0XHR9XG5cdH1cblxuXHRyZXR1cm4geyBpZDogJ3ZhbHVlJywgbGFiZWw6ICdWYWx1ZScsIHR5cGU6ICdyYXcnLCBkZWZhdWx0OiBbLi4udmFsdWVCeXRlc10gfVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBTTUFSVCBKU09OIFVQREFURVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzKFxuXHRtb2RlbEpzb246IFN0TW9kZWxKc29uLFxuXHRwYXJzZWQ6IFBhcnNlZFNldHRpbmdbXSxcblx0YWxsTW9kZWxzOiBSZWNvcmQ8c3RyaW5nLCBTdE1vZGVsSnNvbj4sXG4pOiBTdE1vZGVsSnNvbiB7XG5cdGNvbnN0IG91dCA9IHN0cnVjdHVyZWRDbG9uZShtb2RlbEpzb24pXG5cblx0Ly8gRW5zdXJlIGNtZFNjaGVtYSBhcnJheSBleGlzdHNcblx0aWYgKCFvdXQuY21kU2NoZW1hKSB7XG5cdFx0b3V0LmNtZFNjaGVtYSA9IFtdXG5cdH1cblxuXHQvLyBTb3J0IG90aGVyIG1vZGVscyBieSBudW1lcmljIGRpc3RhbmNlIHRvIGN1cnJlbnQgbW9kZWxcblx0Y29uc3QgY2FuZGlkYXRlcyA9IE9iamVjdC52YWx1ZXMoYWxsTW9kZWxzKVxuXHRcdC5maWx0ZXIoKG0pID0+IG0ubW9kZWwgIT09IG1vZGVsSnNvbi5tb2RlbCkgLy8gZXhjbHVkZSBzZWxmXG5cdFx0LnNvcnQoKGEsIGIpID0+IG1vZGVsRGlzdGFuY2UobW9kZWxKc29uLm1vZGVsLCBhLm1vZGVsKSAtIG1vZGVsRGlzdGFuY2UobW9kZWxKc29uLm1vZGVsLCBiLm1vZGVsKSlcblxuXHRsb2dnZXIuaW5mbyhgVXBkYXRpbmcgbW9kZWw6ICR7bW9kZWxKc29uLm1vZGVsfWApXG5cdGxvZ2dlci5kZWJ1ZyhgQ2FuZGlkYXRlcyBmb3IgaW5mZXJlbmNlOiAke2NhbmRpZGF0ZXMubWFwKChjKSA9PiBjLm1vZGVsKS5qb2luKCcsICcpfWApXG5cblx0Ly8gUHJlLXNjYW46IGZvciBlYWNoIGNhbmRpZGF0ZSBpZEFkZCBiYXNlIGVudHJ5LCBmaW5kIHRoZSBtYXhpbXVtIHNlcXVlbnRpYWxcblx0Ly8gb2Zmc2V0IHRoZSBwYWNrZXQgY29udGFpbnMgKGV2ZW4gYmV5b25kIHdoYXQgdGhlIHJlZmVyZW5jZSBtb2RlbCBrbm93cykuXG5cdC8vIEtleTogYCR7Y21kX2lkfV8ke2Jhc2VfaWR9YCwgdmFsdWU6IG1heCBzZXF1ZW50aWFsIG9mZnNldCBzZWVuIGluIHBhcnNlZCBkYXRhLlxuXHRjb25zdCBpZEFkZERlZmVyUmFuZ2VzID0gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4oKVxuXHRmb3IgKGNvbnN0IGMgb2YgY2FuZGlkYXRlcykge1xuXHRcdGZvciAoY29uc3QgYmFzZUVudHJ5IG9mIGMuY21kU2NoZW1hID8/IFtdKSB7XG5cdFx0XHRjb25zdCBpZEFkZE9wdCA9IGJhc2VFbnRyeS5vcHRpb25zPy5maW5kKChvOiBhbnkpID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoIWlkQWRkT3B0Py5jaG9pY2VzKSBjb250aW51ZVxuXHRcdFx0Y29uc3QgYmFzZUlkID0gYmFzZUVudHJ5LmlkXG5cdFx0XHRjb25zdCBjbWRJZCA9IGJhc2VFbnRyeS5jbWRfaWRcblx0XHRcdGNvbnN0IGtleSA9IGAke2NtZElkfV8ke2Jhc2VJZH1gXG5cdFx0XHRpZiAoaWRBZGREZWZlclJhbmdlcy5oYXMoa2V5KSkgY29udGludWVcblx0XHRcdC8vIEZpbmQgdGhlIG1heCBzZXF1ZW50aWFsIG9mZnNldCBwcmVzZW50IGluIHRoZSBwYXJzZWQgcGFja2V0IGZvciB0aGlzIGJhc2Vcblx0XHRcdGNvbnN0IHBhcnNlZE9mZnNldHMgPSBwYXJzZWRcblx0XHRcdFx0LmZpbHRlcigocCkgPT4gcC5jbWRfaWQgPT09IGNtZElkICYmIHAuaWQgPiBiYXNlSWQpXG5cdFx0XHRcdC5tYXAoKHApID0+IHAuaWQgLSBiYXNlSWQpXG5cdFx0XHRcdC5zb3J0KChhLCBiKSA9PiBhIC0gYilcblx0XHRcdC8vIFdhbGsgZnJvbSAxIHVwd2FyZCBcdTIwMTQgc3RvcCBhdCBmaXJzdCBnYXBcblx0XHRcdGxldCBtYXhTZXEgPSAwXG5cdFx0XHRmb3IgKGNvbnN0IG9mZiBvZiBwYXJzZWRPZmZzZXRzKSB7XG5cdFx0XHRcdGlmIChvZmYgPT09IG1heFNlcSArIDEpIG1heFNlcSA9IG9mZlxuXHRcdFx0XHRlbHNlIGlmIChvZmYgPiBtYXhTZXEgKyAxKSBicmVha1xuXHRcdFx0fVxuXHRcdFx0aWYgKG1heFNlcSA+IDApIHtcblx0XHRcdFx0aWRBZGREZWZlclJhbmdlcy5zZXQoa2V5LCBtYXhTZXEpXG5cdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgaWRBZGQgZGVmZXIgcmFuZ2UgZm9yIGNtZF9pZD0ke3RvSGV4KGNtZElkKX0gYmFzZV9pZD0ke3RvSGV4KGJhc2VJZCl9OiBvZmZzZXRzIDFcdTIwMTMke21heFNlcX1gKVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdC8vIFByZS1jb21wdXRlIHRoZSBzZXQgb2YgYWxsIGJ1c0NoIHZhbHVlcyBzZWVuIHBlciAoY21kX2lkLCBpZCkgcGFpciBhY3Jvc3MgdGhlIGZ1bGxcblx0Ly8gcGFyc2VkIHJlc3BvbnNlIFx1MjAxNCB1c2VkIGxhdGVyIHRvIGRlY2lkZSBmaXhlZCB2cy4gc2VsZWN0YWJsZSBidXNDaC5cblx0Y29uc3QgYnVzQ2hTZWVuID0gbmV3IE1hcDxzdHJpbmcsIFNldDxudW1iZXI+PigpXG5cdGZvciAoY29uc3QgeyBjbWRfaWQsIGlkLCBidXNDaCB9IG9mIHBhcnNlZCkge1xuXHRcdGlmIChidXNDaCA9PT0gdW5kZWZpbmVkKSBjb250aW51ZVxuXHRcdGNvbnN0IGtleSA9IGAke2NtZF9pZH1fJHtpZH1gXG5cdFx0aWYgKCFidXNDaFNlZW4uaGFzKGtleSkpIGJ1c0NoU2Vlbi5zZXQoa2V5LCBuZXcgU2V0KCkpXG5cdFx0YnVzQ2hTZWVuLmdldChrZXkpIS5hZGQoYnVzQ2gpXG5cdH1cblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFBBU1MgMTogcmVzb2x2ZSBlYWNoIHBhcnNlZCBlbnRyeSBcdTIwMTQgZXhhY3QgbWF0Y2gsIGluZmVycmVkLFxuXHQvLyBpZEFkZC1mb2xkIChvZmZzZXQgaW50byBhbiBhbHJlYWR5LWFkZGVkIGJhc2UgZW50cnkpLCBvciB1bmtub3duXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Zm9yIChjb25zdCB7IGNtZF9pZCwgaWQsIGJ1c0NoLCB2YWx1ZUJ5dGVzIH0gb2YgcGFyc2VkKSB7XG5cdFx0Ly8gMWEuIEV4YWN0IG1hdGNoIGFscmVhZHkgaW4gb3V0cHV0IHNjaGVtYSBcdTIwMTQgcmVmcmVzaCB0aGUgZGVmYXVsdCBhbmQgc3luYyBidXNDaFxuXHRcdGNvbnN0IGV4aXN0aW5nRXhhY3QgPSBvdXQuY21kU2NoZW1hLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWQpXG5cdFx0aWYgKGV4aXN0aW5nRXhhY3QpIHtcblx0XHRcdGNvbnN0IG9wdCA9IGV4aXN0aW5nRXhhY3Qub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ3ZhbHVlJylcblx0XHRcdGlmIChvcHQpIG9wdC5kZWZhdWx0ID0gdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXMpLmRlZmF1bHRcblxuXHRcdFx0Ly8gU3luYyBidXNDaCBmcm9tIHBhY2tldCBkYXRhIGlmIHRoZSBleGlzdGluZyBlbnRyeSBpcyBtaXNzaW5nIGl0XG5cdFx0XHRjb25zdCBzZWVuQnVzQ2hWYWx1ZXMgPSBidXNDaFNlZW4uZ2V0KGAke2NtZF9pZH1fJHtpZH1gKVxuXHRcdFx0aWYgKHNlZW5CdXNDaFZhbHVlcyAmJiBzZWVuQnVzQ2hWYWx1ZXMuc2l6ZSA+IDApIHtcblx0XHRcdFx0Y29uc3QgbWF4QnVzQ2ggPSBNYXRoLm1heCguLi5zZWVuQnVzQ2hWYWx1ZXMpXG5cdFx0XHRcdGNvbnN0IGhhc0J1c0NoT3B0aW9uID0gZXhpc3RpbmdFeGFjdC5vcHRpb25zPy5zb21lKChvKSA9PiBvLmlkID09PSAnYnVzQ2gnKVxuXHRcdFx0XHRpZiAobWF4QnVzQ2ggPT09IDAgJiYgZXhpc3RpbmdFeGFjdC5idXNDaCA9PT0gdW5kZWZpbmVkICYmICFoYXNCdXNDaE9wdGlvbikge1xuXHRcdFx0XHRcdGV4aXN0aW5nRXhhY3QuYnVzQ2ggPSAwXG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYFN5bmNlZCBidXNDaD0wIG9udG8gZXhpc3RpbmcgZW50cnkgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9YClcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0Y29udGludWVcblx0XHR9XG5cblx0XHQvLyAxYi4gQ2hlY2sgaWYgdGhpcyBpZCBmb2xkcyBpbnRvIGFuIGFscmVhZHktYWRkZWQgYmFzZSBlbnRyeSB2aWEgaWRBZGQuXG5cdFx0Ly8gICAgIEdhdGU6IHRoZSBvZmZzZXQgbXVzdCBhY3R1YWxseSBleGlzdCBpbiB0aGUgcmVmZXJlbmNlIG1vZGVsJ3MgaWRBZGQgY2hvaWNlc1xuXHRcdC8vICAgICB0byBhdm9pZCBzd2FsbG93aW5nIHVucmVsYXRlZCBzYW1lLWNtZF9pZCBlbnRyaWVzIChlLmcuIFNpZGV0b25lIGF0IGlkPTIxKS5cblx0XHRjb25zdCBpZEFkZEJhc2UgPSBvdXQuY21kU2NoZW1hLmZpbmQoKGEpID0+IHtcblx0XHRcdGlmIChhLmNtZF9pZCAhPT0gY21kX2lkKSByZXR1cm4gZmFsc2Vcblx0XHRcdGNvbnN0IGlkQWRkT3B0ID0gYS5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdD8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHRpZiAoaWQgPD0gYS5pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBvZmZzZXQgPSBpZCAtIGEuaWRcblx0XHRcdC8vIE9ubHkgZm9sZCBpZiBhIHJlZmVyZW5jZSBtb2RlbCBleHBsaWNpdGx5IGxpc3RzIHRoaXMgb2Zmc2V0IGluIGl0cyBpZEFkZCBjaG9pY2VzXG5cdFx0XHRyZXR1cm4gY2FuZGlkYXRlcy5zb21lKChjKSA9PiB7XG5cdFx0XHRcdGNvbnN0IHJlZkVudHJ5ID0gYy5jbWRTY2hlbWE/LmZpbmQoKHIpID0+IHIuY21kX2lkID09PSBjbWRfaWQgJiYgci5pZCA9PT0gYS5pZClcblx0XHRcdFx0Y29uc3QgcmVmSWRBZGQgPSByZWZFbnRyeT8ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0cmV0dXJuIHJlZklkQWRkPy5jaG9pY2VzPy5zb21lKChjaDogYW55KSA9PiBjaC5pZCA9PT0gb2Zmc2V0KVxuXHRcdFx0fSlcblx0XHR9KVxuXHRcdGlmIChpZEFkZEJhc2UpIHtcblx0XHRcdGNvbnN0IG9mZnNldCA9IGlkIC0gaWRBZGRCYXNlLmlkXG5cdFx0XHRjb25zdCBpZEFkZE9wdCA9IGlkQWRkQmFzZS5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKGlkQWRkT3B0Py5jaG9pY2VzICYmICFpZEFkZE9wdC5jaG9pY2VzLnNvbWUoKGM6IGFueSkgPT4gYy5pZCA9PT0gb2Zmc2V0KSkge1xuXHRcdFx0XHRsZXQgbGFiZWwgPSBgQ2hhbm5lbCAke29mZnNldCArIDF9YFxuXHRcdFx0XHRmb3IgKGNvbnN0IGMgb2YgY2FuZGlkYXRlcykge1xuXHRcdFx0XHRcdGNvbnN0IHJlZkVudHJ5ID0gYy5jbWRTY2hlbWE/LmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWRBZGRCYXNlLmlkKVxuXHRcdFx0XHRcdGNvbnN0IHJlZklkQWRkID0gcmVmRW50cnk/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdFx0Y29uc3QgcmVmQ2hvaWNlID0gcmVmSWRBZGQ/LmNob2ljZXM/LmZpbmQoKGNoOiBhbnkpID0+IGNoLmlkID09PSBvZmZzZXQpXG5cdFx0XHRcdFx0aWYgKHJlZkNob2ljZSkge1xuXHRcdFx0XHRcdFx0bGFiZWwgPSByZWZDaG9pY2UubGFiZWxcblx0XHRcdFx0XHRcdGJyZWFrXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdGlkQWRkT3B0LmNob2ljZXMucHVzaCh7IGlkOiBvZmZzZXQsIGxhYmVsIH0pXG5cdFx0XHRcdGxvZ2dlci5pbmZvKFxuXHRcdFx0XHRcdGBGb2xkZWQgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9IGludG8gaWRBZGQgYmFzZSBpZD0ke3RvSGV4KGlkQWRkQmFzZS5pZCl9IGFzIG9mZnNldCAke29mZnNldH0gKFwiJHtsYWJlbH1cIilgLFxuXHRcdFx0XHQpXG5cdFx0XHR9XG5cdFx0XHRjb250aW51ZVxuXHRcdH1cblxuXHRcdC8vIDFjLiBObyBleGFjdCBtYXRjaCBcdTIwMTQgdHJ5IGluZmVyZW5jZSBmcm9tIGNhbmRpZGF0ZSBtb2RlbHNcblx0XHRsZXQgYWN0aW9uOiBTdEFjdGlvbiB8IHVuZGVmaW5lZFxuXG5cdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdGNvbnN0IG1hdGNoID0gYy5jbWRTY2hlbWE/LmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWQpXG5cdFx0XHRpZiAobWF0Y2gpIHtcblx0XHRcdFx0YWN0aW9uID0gc3RydWN0dXJlZENsb25lKG1hdGNoKVxuXHRcdFx0XHQvLyBTdHJpcCBhbnkgZXhpc3RpbmcgXCIoaW5mZXJyZWQgZnJvbSBNb2RlbCBYKVwiIHN1ZmZpeGVzIGJlZm9yZSBhZGRpbmcgb3VyIG93blxuXHRcdFx0XHRjb25zdCBiYXNlTmFtZSA9IG1hdGNoLm5hbWUucmVwbGFjZSgvXFxzKlxcKGluZmVycmVkIGZyb20gTW9kZWwgW14pXStcXCkvZywgJycpLnRyaW0oKVxuXHRcdFx0XHRhY3Rpb24ubmFtZSA9IGAke2Jhc2VOYW1lfSAoaW5mZXJyZWQgZnJvbSBNb2RlbCAke2MubW9kZWx9KWBcblx0XHRcdFx0bG9nZ2VyLmluZm8oYEluZmVycmVkIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfSBmcm9tIE1vZGVsICR7Yy5tb2RlbH0gKGV4YWN0KWApXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gQ2hlY2sgaWYgdGhpcyBpZCBzaG91bGQgYmUgZGVmZXJyZWQgdG8gcGFzcyAyIFx1MjAxNFxuXHRcdC8vIGl0J3MgYSBzZXF1ZW50aWFsIGlkQWRkIG9mZnNldCBvZiBhIGtub3duIGNhbmRpZGF0ZSBiYXNlIGVudHJ5LlxuXHRcdGlmICghYWN0aW9uKSB7XG5cdFx0XHRsZXQgc2hvdWxkRGVmZXIgPSBmYWxzZVxuXHRcdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdFx0Y29uc3QgYmFzZUVudHJ5ID0gYy5jbWRTY2hlbWE/LmZpbmQoKGE6IGFueSkgPT4ge1xuXHRcdFx0XHRcdGlmIChhLmNtZF9pZCAhPT0gY21kX2lkKSByZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRjb25zdCBpZEFkZE9wdCA9IGEub3B0aW9ucz8uZmluZCgobzogYW55KSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRcdGlmICghaWRBZGRPcHQ/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdGlmIChpZCA8PSBhLmlkKSByZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRjb25zdCBvZmZzZXQgPSBpZCAtIGEuaWRcblx0XHRcdFx0XHRjb25zdCBtYXhTZXEgPSBpZEFkZERlZmVyUmFuZ2VzLmdldChgJHtjbWRfaWR9XyR7YS5pZH1gKSA/PyAwXG5cdFx0XHRcdFx0cmV0dXJuIG9mZnNldCA8PSBtYXhTZXFcblx0XHRcdFx0fSlcblx0XHRcdFx0aWYgKGJhc2VFbnRyeSkge1xuXHRcdFx0XHRcdHNob3VsZERlZmVyID0gdHJ1ZVxuXHRcdFx0XHRcdGxvZ2dlci5kZWJ1Zyhcblx0XHRcdFx0XHRcdGBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gaXMgYW4gaWRBZGQgb2Zmc2V0IG9mIGNhbmRpZGF0ZSBiYXNlIGlkPSR7dG9IZXgoYmFzZUVudHJ5LmlkKX0gXHUyMDE0IGRlZmVycmluZyB0byBwYXNzIDJgLFxuXHRcdFx0XHRcdClcblx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRpZiAoc2hvdWxkRGVmZXIpIGNvbnRpbnVlXG5cdFx0fVxuXG5cdFx0Ly8gRmFsbGJhY2s6IHVua25vd24gc2V0dGluZ1xuXHRcdGlmICghYWN0aW9uKSB7XG5cdFx0XHRhY3Rpb24gPSB7XG5cdFx0XHRcdGNtZF9pZCxcblx0XHRcdFx0aWQsXG5cdFx0XHRcdG5hbWU6IGBVbmtub3duIGNtZDoke3RvSGV4KGNtZF9pZCl9IGlkOiR7dG9IZXgoaWQpLnRvVXBwZXJDYXNlKCl9YCxcblx0XHRcdFx0b3B0aW9uczogW3ZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzKV0sXG5cdFx0XHR9XG5cdFx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkgYWN0aW9uLmJ1c0NoID0gYnVzQ2hcblx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3QgaW5mZXIgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9YClcblx0XHR9IGVsc2Uge1xuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIEZpeCAxOiBidXNDaCBoYW5kbGluZyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRcdC8vIFN0cmlwIGFueSBpbmhlcml0ZWQgYnVzQ2ggb3B0aW9uIGZyb20gdGhlIGNhbmRpZGF0ZSBcdTIwMTQgd2UnbGwgcmUtZGVyaXZlXG5cdFx0XHQvLyBpdCBmcm9tIHdoYXQgdGhlIHBhY2tldCBhY3R1YWxseSByZXBvcnRlZCBmb3IgdGhpcyBkZXZpY2UuXG5cdFx0XHRhY3Rpb24ub3B0aW9ucyA9IGFjdGlvbi5vcHRpb25zPy5maWx0ZXIoKG8pID0+IG8uaWQgIT09ICdidXNDaCcpID8/IFtdXG5cdFx0XHRkZWxldGUgYWN0aW9uLmJ1c0NoXG5cblx0XHRcdGNvbnN0IHNlZW5CdXNDaFZhbHVlcyA9IGJ1c0NoU2Vlbi5nZXQoYCR7Y21kX2lkfV8ke2lkfWApXG5cdFx0XHRpZiAoc2VlbkJ1c0NoVmFsdWVzICYmIHNlZW5CdXNDaFZhbHVlcy5zaXplID4gMCkge1xuXHRcdFx0XHRjb25zdCBtYXhCdXNDaCA9IE1hdGgubWF4KC4uLnNlZW5CdXNDaFZhbHVlcylcblx0XHRcdFx0aWYgKG1heEJ1c0NoID09PSAwKSB7XG5cdFx0XHRcdFx0Ly8gT25seSBldmVyIHNhdyBidXNDaD0wIFx1MjE5MiBmaXhlZCBwcm9wZXJ0eSwgbm90IGFuIG9wdGlvblxuXHRcdFx0XHRcdGFjdGlvbi5idXNDaCA9IDBcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHQvLyBNdWx0aXBsZSBjaGFubmVscyBvYnNlcnZlZCBcdTIxOTIgc2VsZWN0YWJsZSBvcHRpb25cblx0XHRcdFx0XHRjb25zdCBidXNDaENob2ljZXMgPSBBcnJheS5mcm9tKHsgbGVuZ3RoOiBtYXhCdXNDaCArIDEgfSwgKF8sIGkpID0+ICh7XG5cdFx0XHRcdFx0XHRpZDogaSxcblx0XHRcdFx0XHRcdGxhYmVsOiBgQ2hhbm5lbCAke2kgKyAxfWAsXG5cdFx0XHRcdFx0fSkpXG5cdFx0XHRcdFx0YWN0aW9uLm9wdGlvbnMudW5zaGlmdCh7XG5cdFx0XHRcdFx0XHRpZDogJ2J1c0NoJyxcblx0XHRcdFx0XHRcdGxhYmVsOiAnQ2hhbm5lbCcsXG5cdFx0XHRcdFx0XHR0eXBlOiAnZHJvcGRvd24nLFxuXHRcdFx0XHRcdFx0Y2hvaWNlczogYnVzQ2hDaG9pY2VzLFxuXHRcdFx0XHRcdFx0ZGVmYXVsdDogMCxcblx0XHRcdFx0XHR9KVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBGaXggMjogZGVmYXVsdCBtdXN0IGV4aXN0IGluIGNob2ljZXMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHQvLyBTZXQgdGhlIGRlZmF1bHQgdG8gdGhlIG9ic2VydmVkIHZhbHVlLiBJZiB0aGF0IHZhbHVlIGlzbid0IGluIHRoZVxuXHRcdFx0Ly8gaW5oZXJpdGVkIGNob2ljZXMgbGlzdCwgdGhlIGNob2ljZXMgYXJlIGZyb20gYSBzdHJ1Y3R1cmFsbHkgZGlmZmVyZW50XG5cdFx0XHQvLyBtb2RlbCBhbmQgY2FuJ3QgYmUgdHJ1c3RlZCBcdTIwMTQgZGlzY2FyZCB0aGVtIGFuZCBmYWxsIGJhY2sgdG8gYSBwbGFpbiBudW1iZXIuXG5cdFx0XHRjb25zdCBvYnNlcnZlZERlZmF1bHQgPSB2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlcykuZGVmYXVsdFxuXHRcdFx0Y29uc3QgdmFsdWVPcHQgPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ3ZhbHVlJylcblx0XHRcdGlmICh2YWx1ZU9wdCkge1xuXHRcdFx0XHRpZiAodmFsdWVPcHQuY2hvaWNlcyAmJiBBcnJheS5pc0FycmF5KHZhbHVlT3B0LmNob2ljZXMpKSB7XG5cdFx0XHRcdFx0Y29uc3QgaW5DaG9pY2VzID0gdmFsdWVPcHQuY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9ic2VydmVkRGVmYXVsdClcblx0XHRcdFx0XHRpZiAoIWluQ2hvaWNlcykge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oXG5cdFx0XHRcdFx0XHRcdGBJbmZlcnJlZCBjaG9pY2VzIGZvciBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gZG9uJ3QgY29udGFpbiBvYnNlcnZlZCB2YWx1ZSAke29ic2VydmVkRGVmYXVsdH0gXHUyMDE0IGRpc2NhcmRpbmcgaW5oZXJpdGVkIGNob2ljZXNgLFxuXHRcdFx0XHRcdFx0KVxuXHRcdFx0XHRcdFx0Ly8gS2VlcCBsYWJlbC90b29sdGlwIGJ1dCBkcm9wIGNob2ljZXMsIHN3aXRjaCB0byBwbGFpbiBudW1iZXJcblx0XHRcdFx0XHRcdHZhbHVlT3B0LnR5cGUgPSAnbnVtYmVyJ1xuXHRcdFx0XHRcdFx0ZGVsZXRlICh2YWx1ZU9wdCBhcyBhbnkpLmNob2ljZXNcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0dmFsdWVPcHQuZGVmYXVsdCA9IG9ic2VydmVkRGVmYXVsdFxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdG91dC5jbWRTY2hlbWEucHVzaChhY3Rpb24pXG5cdH1cblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFBBU1MgMjogZm9sZCBhbnkgZGVmZXJyZWQgaWRBZGQgb2Zmc2V0cyB3aG9zZSBiYXNlIGVudHJ5XG5cdC8vIGlzIG5vdyBwcmVzZW50IGluIHRoZSBvdXRwdXQgc2NoZW1hLlxuXHQvLyBHYXRlOiB0aGUgb2Zmc2V0IG11c3QgZWl0aGVyIGV4aXN0IGluIGEgcmVmZXJlbmNlIG1vZGVsJ3MgY2hvaWNlcyxcblx0Ly8gT1IgdGhlIGJhc2UgZW50cnkgaXRzZWxmIHdhcyBpbmZlcnJlZCAoaGFzIGlkQWRkKSBhbmQgdGhlIG9mZnNldFxuXHQvLyBjb250aW51ZXMgc2VxdWVudGlhbGx5IGJleW9uZCB0aGUgcmVmZXJlbmNlIG1vZGVsJ3Mga25vd24gcmFuZ2UuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Zm9yIChjb25zdCB7IGNtZF9pZCwgaWQgfSBvZiBwYXJzZWQpIHtcblx0XHRjb25zdCBhbHJlYWR5VG9wTGV2ZWwgPSBvdXQuY21kU2NoZW1hLnNvbWUoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWQpXG5cdFx0aWYgKGFscmVhZHlUb3BMZXZlbCkgY29udGludWVcblxuXHRcdC8vIEZpbmQgYSBiYXNlIGVudHJ5IGluIHRoZSBvdXRwdXQgdGhhdCBoYXMgaWRBZGQgYW5kIHdob3NlIGlkIDwgdGhpcyBpZFxuXHRcdGNvbnN0IGlkQWRkQmFzZSA9IG91dC5jbWRTY2hlbWEuZmluZCgoYSkgPT4ge1xuXHRcdFx0aWYgKGEuY21kX2lkICE9PSBjbWRfaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBhLm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRyZXR1cm4gISFpZEFkZE9wdD8uY2hvaWNlcyAmJiBpZCA+IGEuaWRcblx0XHR9KVxuXHRcdGlmICghaWRBZGRCYXNlKSBjb250aW51ZVxuXG5cdFx0Y29uc3Qgb2Zmc2V0ID0gaWQgLSBpZEFkZEJhc2UuaWRcblx0XHRjb25zdCBpZEFkZE9wdCA9IGlkQWRkQmFzZS5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdGlmICghaWRBZGRPcHQ/LmNob2ljZXMgfHwgaWRBZGRPcHQuY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9mZnNldCkpIGNvbnRpbnVlXG5cblx0XHQvLyBBY2NlcHQgdGhlIGZvbGQgaWY6IGEgcmVmZXJlbmNlIG1vZGVsIGV4cGxpY2l0bHkgaGFzIHRoaXMgb2Zmc2V0LFxuXHRcdC8vIE9SIHRoZSBvZmZzZXRzIGFyZSBzdHJpY3RseSBzZXF1ZW50aWFsIGZyb20gMCAoZGV2aWNlIGhhcyBtb3JlIGNoYW5uZWxzIHRoYW4gcmVmZXJlbmNlKVxuXHRcdGNvbnN0IHJlZkhhc09mZnNldCA9IGNhbmRpZGF0ZXMuc29tZSgoYykgPT4ge1xuXHRcdFx0Y29uc3QgcmVmRW50cnkgPSBjLmNtZFNjaGVtYT8uZmluZCgocikgPT4gci5jbWRfaWQgPT09IGNtZF9pZCAmJiByLmlkID09PSBpZEFkZEJhc2UuaWQpXG5cdFx0XHRjb25zdCByZWZJZEFkZCA9IHJlZkVudHJ5Py5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0cmV0dXJuIHJlZklkQWRkPy5jaG9pY2VzPy5zb21lKChjaDogYW55KSA9PiBjaC5pZCA9PT0gb2Zmc2V0KVxuXHRcdH0pXG5cdFx0Y29uc3QgZXhpc3RpbmdPZmZzZXRzID0gaWRBZGRPcHQuY2hvaWNlcy5tYXAoKGM6IGFueSkgPT4gYy5pZCBhcyBudW1iZXIpLnNvcnQoKGEsIGIpID0+IGEgLSBiKVxuXHRcdGNvbnN0IGlzU2VxdWVudGlhbCA9IGV4aXN0aW5nT2Zmc2V0cy5sZW5ndGggPiAwICYmIG9mZnNldCA9PT0gZXhpc3RpbmdPZmZzZXRzW2V4aXN0aW5nT2Zmc2V0cy5sZW5ndGggLSAxXSArIDFcblxuXHRcdGlmICghcmVmSGFzT2Zmc2V0ICYmICFpc1NlcXVlbnRpYWwpIGNvbnRpbnVlXG5cblx0XHQvLyBJbmhlcml0IGxhYmVsIGZyb20gcmVmZXJlbmNlIG1vZGVsIGlmIGF2YWlsYWJsZSwgb3RoZXJ3aXNlIGdlbmVyYXRlIG9uZVxuXHRcdGxldCBsYWJlbCA9IGBDaGFubmVsICR7b2Zmc2V0ICsgMX1gXG5cdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdGNvbnN0IHJlZkVudHJ5ID0gYy5jbWRTY2hlbWE/LmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWRBZGRCYXNlLmlkKVxuXHRcdFx0Y29uc3QgcmVmSWRBZGQgPSByZWZFbnRyeT8ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGNvbnN0IHJlZkNob2ljZSA9IHJlZklkQWRkPy5jaG9pY2VzPy5maW5kKChjaDogYW55KSA9PiBjaC5pZCA9PT0gb2Zmc2V0KVxuXHRcdFx0aWYgKHJlZkNob2ljZSkge1xuXHRcdFx0XHRsYWJlbCA9IHJlZkNob2ljZS5sYWJlbFxuXHRcdFx0XHRicmVha1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGlkQWRkT3B0LmNob2ljZXMucHVzaCh7IGlkOiBvZmZzZXQsIGxhYmVsIH0pXG5cdFx0bG9nZ2VyLmluZm8oXG5cdFx0XHRgUGFzcyAyOiBGb2xkZWQgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9IGludG8gaWRBZGQgYmFzZSBpZD0ke3RvSGV4KGlkQWRkQmFzZS5pZCl9IGFzIG9mZnNldCAke29mZnNldH0gKFwiJHtsYWJlbH1cIilgLFxuXHRcdClcblx0fVxuXG5cdHJldHVybiBvdXRcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgU0FWRVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgZnVuY3Rpb24gc2F2ZU1vZGVsSnNvblByZXR0eShmaWxlUGF0aDogc3RyaW5nLCBqc29uT2JqOiBTdE1vZGVsSnNvbik6IHZvaWQge1xuXHR0cnkge1xuXHRcdC8vIEVuc3VyZSBwcm9wZXIga2V5IG9yZGVyaW5nOiBtb2RlbCwgdXNlQ29uTW9uIChpZiBwcmVzZW50KSwgY21kU2NoZW1hXG5cdFx0Y29uc3Qgb3JkZXJlZE9iajogYW55ID0geyBtb2RlbDoganNvbk9iai5tb2RlbCB9XG5cblx0XHQvLyBBZGQgdXNlQ29uTW9uIGtleSBpZiBwcmVzZW50IChyaWdodCBhZnRlciBtb2RlbClcblx0XHRpZiAoJ3VzZUNvbk1vbicgaW4ganNvbk9iaikge1xuXHRcdFx0b3JkZXJlZE9iai51c2VDb25Nb24gPSBqc29uT2JqLnVzZUNvbk1vblxuXHRcdH1cblxuXHRcdC8vIEFkZCBvdGhlciBrZXlzIGluIG9yZGVyXG5cdFx0aWYgKCdjbWRTY2hlbWEnIGluIGpzb25PYmopIHtcblx0XHRcdG9yZGVyZWRPYmouY21kU2NoZW1hID0ganNvbk9iai5jbWRTY2hlbWEubWFwKChlbnRyeTogYW55KSA9PiB7XG5cdFx0XHRcdC8vIEVuZm9yY2Uga2V5IG9yZGVyIHdpdGhpbiBlYWNoIHNjaGVtYSBlbnRyeTogY21kX2lkLCBpZCwgYnVzQ2gsIG5hbWUsIHZhbHVlLCBvcHRpb25zXG5cdFx0XHRcdGNvbnN0IG9yZGVyZWRFbnRyeTogYW55ID0ge31cblx0XHRcdFx0aWYgKCdjbWRfaWQnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkuY21kX2lkID0gZW50cnkuY21kX2lkXG5cdFx0XHRcdGlmICgnaWQnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkuaWQgPSBlbnRyeS5pZFxuXHRcdFx0XHRpZiAoJ2J1c0NoJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5LmJ1c0NoID0gZW50cnkuYnVzQ2hcblx0XHRcdFx0aWYgKCduYW1lJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5Lm5hbWUgPSBlbnRyeS5uYW1lXG5cdFx0XHRcdGlmICgndmFsdWUnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkudmFsdWUgPSBlbnRyeS52YWx1ZVxuXHRcdFx0XHRpZiAoJ29wdGlvbnMnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkub3B0aW9ucyA9IGVudHJ5Lm9wdGlvbnNcblx0XHRcdFx0Ly8gQ29weSBhbnkgcmVtYWluaW5nIGtleXNcblx0XHRcdFx0Zm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMoZW50cnkpKSB7XG5cdFx0XHRcdFx0aWYgKCEoa2V5IGluIG9yZGVyZWRFbnRyeSkpIG9yZGVyZWRFbnRyeVtrZXldID0gZW50cnlba2V5XVxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBvcmRlcmVkRW50cnlcblx0XHRcdH0pXG5cdFx0fVxuXHRcdC8vIENvcHkgYW55IG90aGVyIGtleXMgdGhhdCBtaWdodCBleGlzdFxuXHRcdGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGpzb25PYmopKSB7XG5cdFx0XHRpZiAoIShrZXkgaW4gb3JkZXJlZE9iaikpIHtcblx0XHRcdFx0b3JkZXJlZE9ialtrZXldID0gKGpzb25PYmogYXMgYW55KVtrZXldXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gQ3VzdG9tIGZvcm1hdHRlcjoga2VlcCBjaG9pY2Ugb2JqZWN0cyBjb21wYWN0IG9uIG9uZSBsaW5lXG5cdFx0bGV0IGpzb24gPSBKU09OLnN0cmluZ2lmeShvcmRlcmVkT2JqLCBudWxsLCAyKVxuXG5cdFx0Ly8gUmVwbGFjZSBleHBhbmRlZCBjaG9pY2Ugb2JqZWN0cyB3aXRoIGNvbXBhY3Qgc2luZ2xlLWxpbmUgZm9ybWF0XG5cdFx0Ly8gTWF0Y2hlczoge1xcbiAgICAgICAgICAgIFwiaWRcIjogWCxcXG4gICAgICAgICAgICBcImxhYmVsXCI6IFwiWVwiXFxuICAgICAgICAgIH1cblx0XHQvLyBSZXBsYWNlcyB3aXRoOiB7IFwiaWRcIjogWCwgXCJsYWJlbFwiOiBcIllcIiB9XG5cdFx0anNvbiA9IGpzb24ucmVwbGFjZSgvXFx7XFxuXFxzK1wiaWRcIjpcXHMqKFxcZCspLFxcblxccytcImxhYmVsXCI6XFxzKlwiKFteXCJdKilcIlxcblxccytcXH0vZywgJ3sgXCJpZFwiOiAkMSwgXCJsYWJlbFwiOiBcIiQyXCIgfScpXG5cblx0XHRmcy53cml0ZUZpbGVTeW5jKGZpbGVQYXRoLCBqc29uICsgJ1xcbicsICd1dGY4Jylcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5lcnJvcihgRmlsZSBXcml0ZSBFcnJvcjogJHtlfWApXG5cdH1cbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRGZWVkYmFja3MgfSBmcm9tICcuL2J1aWxkLWNvbW1hbmRzLmpzJ1xuaW1wb3J0IHsgZ2V0RGV2aWNlU2NoZW1hcyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgcGFyc2VTZXR0aW5nSWQsIGdldE5vcm1hbGl6ZWRTY2hlbWFzLCBmaW5kQWN0aW9uRm9yU2V0dGluZyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbi8qKlxuICogSGVscGVyIGZ1bmN0aW9uIHRvIGdldCBsYWJlbCBmcm9tIGNob2ljZXMgYmFzZWQgb24gdmFsdWVcbiAqL1xuZnVuY3Rpb24gZ2V0TGFiZWxGb3JWYWx1ZShcblx0c2NoZW1hczogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+LFxuXHRtb2RlbDogc3RyaW5nLFxuXHRjbWRJZDogbnVtYmVyLFxuXHRzZXR0aW5nSWQ6IG51bWJlcixcblx0dmFsdWU6IG51bWJlcixcbik6IHN0cmluZyB8IG51bWJlciB7XG5cdGNvbnN0IHNldHRpbmcgPSBmaW5kQWN0aW9uRm9yU2V0dGluZyhzY2hlbWFzLCBtb2RlbCwgY21kSWQsIHNldHRpbmdJZClcblx0aWYgKCFzZXR0aW5nIHx8ICFBcnJheS5pc0FycmF5KHNldHRpbmcub3B0aW9ucykpIHJldHVybiB2YWx1ZVxuXG5cdC8vIEZpbmQgdGhlICd2YWx1ZScgb3B0aW9uIHdoaWNoIGNvbnRhaW5zIHRoZSBjaG9pY2VzXG5cdGNvbnN0IHZhbHVlT3B0aW9uID0gc2V0dGluZy5vcHRpb25zLmZpbmQoKG9wdDogYW55KSA9PiBvcHQuaWQgPT09ICd2YWx1ZScpXG5cdGlmICghdmFsdWVPcHRpb24gfHwgIUFycmF5LmlzQXJyYXkodmFsdWVPcHRpb24uY2hvaWNlcykpIHJldHVybiB2YWx1ZVxuXG5cdC8vIEZpbmQgdGhlIGNob2ljZSB3aXRoIG1hdGNoaW5nIGlkXG5cdGNvbnN0IGNob2ljZSA9IHZhbHVlT3B0aW9uLmNob2ljZXMuZmluZCgoYzogYW55KSA9PiBjLmlkID09PSB2YWx1ZSlcblx0cmV0dXJuIGNob2ljZT8ubGFiZWwgPz8gdmFsdWVcbn1cblxuLyoqXG4gKiBCdWlsZCBhbmQgd2lyZSBDb21wYW5pb24gZmVlZGJhY2sgZGVmaW5pdGlvbnNcbiAqIFBhdHRlcm4gbWF0Y2hlcyBhY3Rpb25zLnRzIC0gZmlsdGVycyBieSBhY3RpdmUgbW9kZWwgYW5kIHdpcmVzIGNhbGxiYWNrc1xuICovXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlRmVlZGJhY2tzKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IHNjaGVtYXNSYXcgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgcmF3RmVlZGJhY2tzID0gYnVpbGRGZWVkYmFja3MoKVxuXHRjb25zdCBzY2hlbWFzID0gZ2V0Tm9ybWFsaXplZFNjaGVtYXMoc2NoZW1hc1Jhdylcblx0Y29uc3Qgd2lyZWRGZWVkYmFja3M6IGFueSA9IHt9XG5cblx0Ly8gR2V0IHRoZSBhY3RpdmUgbW9kZWwgZnJvbSB0aGUgY2FjaGVkIHZhbHVlIHNldCBieSBzeW5jTW9kZWwoKVxuXHRjb25zdCBhY3RpdmVNb2RlbCA9IHNlbGYuYWN0aXZlTW9kZWxcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEJVSUxEIFBFUi1TRVRUSU5HIEZFRURCQUNLUyAoRklMVEVSRUQgQlkgQUNUSVZFIE1PREVMKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHRmb3IgKGNvbnN0IFtmZWVkYmFja0lkLCBmZWVkYmFja10gb2YgT2JqZWN0LmVudHJpZXMocmF3RmVlZGJhY2tzKSkge1xuXHRcdC8vIFN0cmlwIF9ib29sIHN1ZmZpeCBiZWZvcmUgcGFyc2luZyBzbyB0aGUgbW9kZWwvY21kSWQvYmFzZUlkIGFyZSBleHRyYWN0ZWQgY29ycmVjdGx5XG5cdFx0Y29uc3QgcGFyc2VJZCA9IGZlZWRiYWNrSWQuZW5kc1dpdGgoJ19ib29sJykgPyBmZWVkYmFja0lkLnNsaWNlKDAsIC01KSA6IGZlZWRiYWNrSWRcblx0XHRjb25zdCB7IG1vZGVsLCBjbWRJZCwgYmFzZUlkIH0gPSBwYXJzZVNldHRpbmdJZChwYXJzZUlkKVxuXG5cdFx0Ly8gT25seSBpbmNsdWRlIGZlZWRiYWNrcyBmb3IgdGhlIGN1cnJlbnRseSBhY3RpdmUgbW9kZWxcblx0XHRpZiAobW9kZWwgIT09IGFjdGl2ZU1vZGVsKSBjb250aW51ZVxuXG5cdFx0Ly8gVkFMVUUgRkVFREJBQ0s6IFJldHVybnMgY3VycmVudCB2YWx1ZSBmb3IgbG9jYWwgdmFyaWFibGVcblx0XHR3aXJlZEZlZWRiYWNrc1tmZWVkYmFja0lkXSA9IHtcblx0XHRcdC4uLmZlZWRiYWNrLFxuXHRcdFx0Y2FsbGJhY2s6IChmZWVkYmFja0V2ZW50OiBhbnkpID0+IHtcblx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3Rcblx0XHRcdFx0Y29uc3QgaWRBZGQgPSBmZWVkYmFja0V2ZW50Lm9wdGlvbnNbJ2lkQWRkJ10gPz8gMFxuXHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBiYXNlSWQgKyBpZEFkZFxuXG5cdFx0XHRcdC8vIGJ1c0NoIGZyb20gb3B0aW9ucyB0YWtlcyBwcmlvcml0eTsgZmFsbCBiYWNrIHRvIGZpeGVkIGJ1c0NoIGluIHNjaGVtYVxuXHRcdFx0XHRsZXQgYnVzQ2ggPSBmZWVkYmFja0V2ZW50Lm9wdGlvbnNbJ2J1c0NoJ11cblx0XHRcdFx0aWYgKGJ1c0NoID09PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRjb25zdCBzY2hlbWFBY3Rpb24gPSBmaW5kQWN0aW9uRm9yU2V0dGluZyhzY2hlbWFzLCBtb2RlbCwgY21kSWQsIHNldHRpbmdJZClcblx0XHRcdFx0XHRpZiAoc2NoZW1hQWN0aW9uPy5idXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0XHRidXNDaCA9IHNjaGVtYUFjdGlvbi5idXNDaFxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHQvLyBMYXN0IHJlc29ydDogbG9vayB1cCBmaXhlZCBidXNDaCBkaXJlY3RseSBmcm9tIHRoZSByYXcgZGV2aWNlIHNjaGVtYSxcblx0XHRcdFx0Ly8gaW4gY2FzZSBnZXROb3JtYWxpemVkU2NoZW1hcygpIHN0cmlwcGVkIHRoZSBwcm9wZXJ0eSAoZS5nLiBNaWMgRWxlY3RyZXQgUG93ZXIpLlxuXHRcdFx0XHRpZiAoYnVzQ2ggPT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdGNvbnN0IHJhd0FjdGlvbiA9IHNjaGVtYXNSYXdbbW9kZWxdPy5jbWRTY2hlbWE/LmZpbmQoKGE6IGFueSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IHNldHRpbmdJZClcblx0XHRcdFx0XHRpZiAocmF3QWN0aW9uPy5idXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0XHRidXNDaCA9IHJhd0FjdGlvbi5idXNDaFxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXG5cdFx0XHRcdGNvbnN0IGN1cnJlbnQgPSBzZWxmLnN0Q29udHJvbGxlci5nZXRTZXR0aW5nVmFsdWUoaXAsIGNtZElkLCBzZXR0aW5nSWQsIGJ1c0NoKVxuXG5cdFx0XHRcdC8vIEJvb2xlYW4gZmVlZGJhY2tzOiBhbnkgbm9uLXplcm8gdmFsdWUgPSBhY3RpdmUgKHRydWUpLCB6ZXJvID0gaW5hY3RpdmUgKGZhbHNlKS5cblx0XHRcdFx0Ly8gVGhpcyB3b3JrcyBmb3IgYWxsIE9uL09mZiBzZXR0aW5ncyByZWdhcmRsZXNzIG9mIHdoYXQgdGhlIFwiT25cIiBJRCB2YWx1ZSBpc1xuXHRcdFx0XHQvLyBpbiB0aGUgc2NoZW1hIChlLmcuIE1pYyBFbGVjdHJldCBQb3dlciB1c2VzIDUgZm9yIE9uLCBub3QgMSkuXG5cdFx0XHRcdC8vIFJldHVybnMgYSByZWFsIGJvb2xlYW4gXHUyMDE0IHVzZWQgZm9yIGJ1dHRvbiBjb2xvcmluZyBvbmx5LCBub3QgdmFyaWFibGVzLlxuXHRcdFx0XHRpZiAoZmVlZGJhY2tJZC5lbmRzV2l0aCgnX2Jvb2wnKSkge1xuXHRcdFx0XHRcdHJldHVybiBjdXJyZW50ICE9PSB1bmRlZmluZWQgJiYgY3VycmVudCAhPT0gMFxuXHRcdFx0XHR9XG5cblx0XHRcdFx0Ly8gQ2hlY2sgaWYgdXNlciB3YW50cyBsYWJlbCBpbnN0ZWFkIG9mIG51bWVyaWMgdmFsdWVcblx0XHRcdFx0Y29uc3Qgc2hvd0xhYmVsID0gZmVlZGJhY2tFdmVudC5vcHRpb25zWydzaG93TGFiZWwnXSA/PyBmYWxzZVxuXG5cdFx0XHRcdGlmIChzaG93TGFiZWwgJiYgY3VycmVudCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0Y29uc3QgbGFiZWwgPSBnZXRMYWJlbEZvclZhbHVlKHNjaGVtYXMsIG1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkLCBjdXJyZW50KVxuXHRcdFx0XHRcdC8vIElmIG5vIGNob2ljZSBsYWJlbCB3YXMgZm91bmQgKHJldHVybmVkIGEgbnVtYmVyKSwgdGhlIHNldHRpbmcgaGFzIG5vXG5cdFx0XHRcdFx0Ly8gZGlzY3JldGUgY2hvaWNlcyBcdTIwMTQgdHJlYXQgaXQgYXMgYm9vbGVhbiBhbmQgc2hvdyB0cnVlL2ZhbHNlLlxuXHRcdFx0XHRcdGlmICh0eXBlb2YgbGFiZWwgPT09ICdudW1iZXInKSB7XG5cdFx0XHRcdFx0XHRyZXR1cm4gbGFiZWwgIT09IDAgPyAndHJ1ZScgOiAnZmFsc2UnXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdHJldHVybiBsYWJlbFxuXHRcdFx0XHR9XG5cblx0XHRcdFx0Ly8gUmV0dXJuIG51bWVyaWMgdmFsdWUgZGlyZWN0bHkgZm9yIGxvY2FsIHZhcmlhYmxlICh0eXBlOiAndmFsdWUnKVxuXHRcdFx0XHRyZXR1cm4gY3VycmVudCA/PyAwXG5cdFx0XHR9LFxuXHRcdH1cblx0fVxuXG5cdHNlbGYuc2V0RmVlZGJhY2tEZWZpbml0aW9ucyh3aXJlZEZlZWRiYWNrcylcbn1cbiIsICJpbXBvcnQgZGdyYW0gZnJvbSAnZGdyYW0nXG5pbXBvcnQgb3MgZnJvbSAnb3MnXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHtcblx0Q01EX0JVU19HRVQsXG5cdENNRF9CVVNfU0VULFxuXHRDTURfREVWX1NQRUMsXG5cdENNRF9HRVRfQUxMX1NFVFRJTkdTLFxuXHRDTURfR0VUX0ZJUk1XQVJFLFxuXHRDTURfR0xPQkFMX01JQ19LSUxMLFxuXHRDTURfTUlDX1BSRSxcblx0Q01EX01JQ19QUkVfQlVTLFxuXHRDTURfUkVTRVRfREVWSUNFLFxuXHRDTURfU0VUVElOR1NfUFVTSCxcblx0Z2V0Q29tbWFuZE5hbWUsXG5cdG1ha2VTZXR0aW5nSWQsXG5cdHRvSGV4LFxuXHRieXRlc1RvSGV4LFxuXHR0eXBlIERldmljZUluZm8sXG59IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQge1xuXHRwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwsXG5cdHBhcnNlU2V0dGluZ3NSZXNwb25zZSxcblx0Zm9ybWF0UGFyc2VkU2V0dGluZyxcblx0dHlwZSBTdEFjdGlvbixcblx0dHlwZSBQYXJzZWRTZXR0aW5nLFxufSBmcm9tICcuL3NldHRpbmdzUGFyc2VyLmpzJ1xuaW1wb3J0IHsgZ2V0RGV2aWNlU2NoZW1hIH0gZnJvbSAnLi9jb25maWcuanMnXG5cbmltcG9ydCB7XG5cdERBTlRFX01TR19JTkZPX1JFU1BPTlNFLFxuXHRwYXJzZURhbnRlSW5mb1Jlc3BvbnNlLFxuXHRkaXNjb3ZlckRldmljZXMsXG5cdHByb2JlRGV2aWNlIGFzIGRhbnRlUHJvYmVEZXZpY2UsXG5cdGdldE1hY0ZvckRlc3RpbmF0aW9uLFxuXHRnZXRMb2NhbEFkZHJlc3NGb3JEZXN0aW5hdGlvbixcbn0gZnJvbSAnLi9kYW50ZS5qcydcbmltcG9ydCB7IG9wZW5Db25Nb25TZXNzaW9uIH0gZnJvbSAnLi9jb25tb24uanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignU3RDb250cm9sbGVyJylcblxuZXhwb3J0IGNsYXNzIFN0Q29udHJvbGxlciB7XG5cdHByaXZhdGUgcmVhZG9ubHkgZGVmYXVsdFBvcnQ6IG51bWJlciA9IDg3MDBcblx0cHJpdmF0ZSByZWFkb25seSBtdWx0aWNhc3RHcm91cCA9ICcyMjQuMC4wLjIzMSdcblx0cHJpdmF0ZSByZWFkb25seSByeFBvcnQgPSA4NzAyXG5cblx0cHJpdmF0ZSB0eFNvY2tldDogZGdyYW0uU29ja2V0XG5cdHByaXZhdGUgcnhTb2NrZXQ6IGRncmFtLlNvY2tldCAvLyBmb3IgcmVjZWl2aW5nIHJlc3BvbnNlcyAoODcwMilcblx0cHJpdmF0ZSByeE1jYXN0U29ja2V0OiBkZ3JhbS5Tb2NrZXQgfCBudWxsID0gbnVsbCAvLyBkaWFnbm9zdGljOiB0cmFja3Mgd2hpY2ggcmVzcG9uc2VzIGFycml2ZSB2aWEgbXVsdGljYXN0XG5cdHByaXZhdGUgbWNhc3REZWxpdmVyaWVzOiBTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKSAvLyBrZXlzIHNlZW4gb24gbXVsdGljYXN0IHNvY2tldCB0aGlzIGN5Y2xlXG5cdHByaXZhdGUgcGVuZGluZ0Fja3M6IE1hcDxcblx0XHRzdHJpbmcsXG5cdFx0eyByZXNvbHZlOiAoYnVmOiBCdWZmZXIpID0+IHZvaWQ7IHJlamVjdDogKGU6IEVycm9yKSA9PiB2b2lkOyB0aW1lcjogTm9kZUpTLlRpbWVvdXQgfVxuXHQ+ID0gbmV3IE1hcCgpXG5cdHByaXZhdGUgam9pbmVkSW50ZXJmYWNlczogU2V0PHN0cmluZz4gPSBuZXcgU2V0KCkgLy8gbG9jYWwgSVBzIHdlJ3ZlIGpvaW5lZCBtdWx0aWNhc3Qgb25cblxuXHQvKiogU2VyaWFsaXplcyBvdXRnb2luZyBjb21tYW5kcyBzbyBlYWNoIHdhaXRzIGZvciBBQ0sgYmVmb3JlIHRoZSBuZXh0IGlzIHNlbnQgKi9cblx0cHJpdmF0ZSBzZW5kUXVldWU6IFByb21pc2U8dm9pZD4gPSBQcm9taXNlLnJlc29sdmUoKVxuXG5cdC8qKiBUcmFja3MgaG93IG1hbnkgY29tbWFuZHMgYXJlIHF1ZXVlZC9pbi1mbGlnaHQsIHRvIGRlZmVyIHJlcXVlc3RBbGxTZXR0aW5ncyAqL1xuXHRwcml2YXRlIHBlbmRpbmdDb21tYW5kQ291bnQgPSAwXG5cblx0LyoqIFJlc29sdmVzIG9uY2UgdHhTb2NrZXQgaXMgYm91bmQgYW5kIHJlYWR5IHRvIHNlbmQgKi9cblx0cHJpdmF0ZSB0eFJlYWR5OiBQcm9taXNlPHZvaWQ+XG5cblx0LyoqIEFjdGl2ZSBkZXZpY2UgbW9kZWwgYW5kIGFjdGlvbiBkZWZpbml0aW9ucyBmb3Igc2V0dGluZ3MgZGVjb2RpbmcgKi9cblx0cHJpdmF0ZSBtb2RlbDogc3RyaW5nID0gJydcblx0cHJpdmF0ZSBhY3Rpb25zOiBTdEFjdGlvbltdID0gW11cblxuXHQvKipcblx0ICogS25vd24gc3RhdGUgb2YgZXZlcnkgc2V0dGluZyBwZXIgZGV2aWNlIElQLlxuXHQgKiBLZXllZCBieSBJUCBcdTIxOTIgTWFwIG9mIFwiJHtjbWRJZH0vJHtzZXR0aW5nSWR9XCIgXHUyMTkyIGN1cnJlbnQgdmFsdWUgYnl0ZS5cblx0ICogUG9wdWxhdGVkIG9uIGNvbm5lY3QgdmlhIHJlcXVlc3RBbGxTZXR0aW5ncygpLCB1cGRhdGVkIG9uIGV2ZXJ5IENNRF9TRVRUSU5HU19QVVNIICgweDBiKS5cblx0ICogVXNlZCB0byBkaWZmIGluY29taW5nIHB1c2hlcyAoY2hhbmdlZCA9IGluZm8sIHVuY2hhbmdlZCA9IGRlYnVnKSBhbmQgZm9yIGZlZWRiYWNrcy5cblx0ICovXG5cdHByaXZhdGUgZGV2aWNlU3RhdGU6IE1hcDxzdHJpbmcsIE1hcDxzdHJpbmcsIG51bWJlcj4+ID0gbmV3IE1hcCgpXG5cblx0LyoqXG5cdCAqIElQcyB0aGF0IGhhdmUgYmVlbiB2ZXJpZmllZCBhZ2FpbnN0IHRoZSBjb25maWd1cmVkIG1vZGVsIGFuZCBhcmUgYWxsb3dlZFxuXHQgKiB0byByZWNlaXZlIFN0dWRpby1UIGNvbW1hbmRzLiBQb3B1bGF0ZWQgYnkgYXV0aG9yaXplRGV2aWNlKCkgYWZ0ZXIgYVxuXHQgKiBzdWNjZXNzZnVsIHByb2JlRGV2aWNlKCkgbW9kZWwgbWF0Y2gsIG9yIGFmdGVyIG11bHRpY2FzdCBkaXNjb3ZlcnkuXG5cdCAqIF9zZW5kQXdhaXRBY2soKSByZWplY3RzIGFueSBkZXN0SXAgbm90IGluIHRoaXMgc2V0LlxuXHQgKi9cblx0cHJpdmF0ZSBhdXRob3JpemVkSXBzOiBTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKVxuXG5cdC8qKiBDYWxsYmFja3MgcmVnaXN0ZXJlZCBmb3IgRGFudGUgMHgwMTcwIGRldmljZSBpbmZvIHJlc3BvbnNlcyBcdTIwMTQga2V5ZWQgYnkgdXNhZ2UgKi9cblx0cHJpdmF0ZSBkaXNjb3ZlcnlMaXN0ZW5lcnM6IE1hcDxzdHJpbmcsIChkZXZpY2U6IERldmljZUluZm8pID0+IHZvaWQ+ID0gbmV3IE1hcCgpXG5cblx0LyoqIENhbGxiYWNrIHRvIHRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlcyB3aGVuIHN0YXRlIGNoYW5nZXMgKi9cblx0cHJpdmF0ZSBmZWVkYmFja0NhbGxiYWNrPzogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZFxuXG5cdC8qKiBDYWNoZSBvZiBsb2NhbCBpbnRlcmZhY2UgTUFDIGJ5dGVzIHBlciBkZXN0aW5hdGlvbiBJUCwgdG8gYXZvaWQgcmVwZWF0ZWQgT1MgbG9va3VwcyAqL1xuXHRwcml2YXRlIG1hY0NhY2hlOiBNYXA8c3RyaW5nLCBudW1iZXJbXT4gPSBuZXcgTWFwKClcblxuXHQvKiogVHJhY2tzIHNlc3Npb24gcmVhZGluZXNzIHBlciBJUCBcdTIwMTQgc2V0IGZvciBkZXZpY2VzIHRoYXQgZXN0YWJsaXNoZWQgQ29uTW9uLCBhbmQgYWxzb1xuXHQgKiAgZm9yIGRldmljZXMgdGhhdCBkb24ndCByZXF1aXJlIENvbk1vbiAodXNlQ29uTW9uIG5vdCBzZXQpLCBzbyB0aGUgY2hlY2sgaXMgb25seSBkb25lIG9uY2UuICovXG5cdHByaXZhdGUgc2Vzc2lvbkVzdGFibGlzaGVkOiBTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKVxuXG5cdC8qKiBDbGVhbnVwIGZ1bmN0aW9ucyByZXR1cm5lZCBieSBvcGVuQ29uTW9uU2Vzc2lvbigpIFx1MjAxNCBjYWxsIHRvIHN0b3Aga2VlcGFsaXZlcyBhbmQgY2xvc2UgdGhlIHNvY2tldCAqL1xuXHRwcml2YXRlIF9jb25tb25DbGVhbnVwczogTWFwPHN0cmluZywgKCkgPT4gdm9pZD4gPSBuZXcgTWFwKClcblxuXHRjb25zdHJ1Y3RvcigpIHtcblx0XHRsb2dnZXIuaW5mbygnU3RDb250cm9sbGVyIGluaXRpYWxpemVkJylcblxuXHRcdC8vIFNlbmQgc29ja2V0IFx1MjAxNCBiaW5kIHRvIGVwaGVtZXJhbCBwb3J0LiBSZXNwb25zZXMgYWx3YXlzIGdvIHRvIHJ4U29ja2V0IG9uXG5cdFx0Ly8gcG9ydCA4NzAyIChEYW50ZSBoYXJkY29kZXMgdGhlIHJlc3BvbnNlIGRlc3RpbmF0aW9uIHBvcnQgdG8gODcwMikuXG5cdFx0dGhpcy50eFNvY2tldCA9IGRncmFtLmNyZWF0ZVNvY2tldCh7IHR5cGU6ICd1ZHA0JywgcmV1c2VBZGRyOiB0cnVlIH0pXG5cdFx0dGhpcy50eFJlYWR5ID0gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUpID0+IHtcblx0XHRcdHRoaXMudHhTb2NrZXQuYmluZCgwLCAoKSA9PiB7XG5cdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgVFggc29ja2V0IGJvdW5kIHRvIHBvcnQgJHsodGhpcy50eFNvY2tldC5hZGRyZXNzKCkgYXMgeyBwb3J0OiBudW1iZXIgfSkucG9ydH1gKVxuXHRcdFx0XHRyZXNvbHZlKClcblx0XHRcdH0pXG5cdFx0fSlcblx0XHR0aGlzLnR4U29ja2V0Lm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGxvZ2dlci5lcnJvcihgVFggc29ja2V0IGVycm9yOiAke2Vycn1gKVxuXHRcdH0pXG5cblx0XHQvLyBSZWNlaXZlIHNvY2tldCAtIGJpbmQgdG8gYWxsIGFkZHJlc3NlcyBzbyBrZXJuZWwgY2FuIGRlbGl2ZXIgbXVsdGljYXN0IHBhY2tldHNcblx0XHR0aGlzLnJ4U29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ2xpc3RlbmluZycsICgpID0+IHtcblx0XHRcdGNvbnN0IGFkZHIgPSB0aGlzLnJ4U29ja2V0LmFkZHJlc3MoKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCBzb2NrZXQgbGlzdGVuaW5nIG9uICR7SlNPTi5zdHJpbmdpZnkoYWRkcil9YClcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHRoaXMucnhTb2NrZXQuc2V0TXVsdGljYXN0TG9vcGJhY2sodHJ1ZSlcblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdH0pXG5cblx0XHR0aGlzLnJ4U29ja2V0Lm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGxvZ2dlci5lcnJvcihgUlggc29ja2V0IGVycm9yOiAke2Vycn1gKVxuXHRcdH0pXG5cblx0XHR0aGlzLnJ4U29ja2V0Lm9uKCdtZXNzYWdlJywgKG1zZywgcmluZm8pID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHRoaXMuaGFuZGxlSW5jb21pbmcobXNnLCByaW5mby5hZGRyZXNzKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0bG9nZ2VyLmVycm9yKGBFcnJvciBoYW5kbGluZyBpbmNvbWluZyBtZXNzYWdlOiAke19lfWApXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdC8vIEJpbmQgdG8gd2lsZGNhcmQgc28ga2VybmVsIGNhbiBkZWxpdmVyIG11bHRpY2FzdCBwYWNrZXRzIGZvciBqb2luZWQgaW50ZXJmYWNlcy5cblx0XHQvLyBBZnRlciBiaW5kaW5nLCBlYWdlcmx5IGpvaW4gMjI0LjAuMC4yMzEgb24gZXZlcnkgbm9uLWxvb3BiYWNrIElQdjQgaW50ZXJmYWNlIHNvXG5cdFx0Ly8gdGhhdCB1bnNvbGljaXRlZCBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikgcGFja2V0cyBhcmUgbm90IG1pc3NlZCBiZWZvcmUgdGhlXG5cdFx0Ly8gZmlyc3Qgb3V0Z29pbmcgY29tbWFuZCB0cmlnZ2VycyB0aGUgbGF6eSBlbnN1cmVNZW1iZXJzaGlwRm9yKCkgam9pbi5cblx0XHR0aGlzLnJ4U29ja2V0LmJpbmQoeyBhZGRyZXNzOiAnMC4wLjAuMCcsIHBvcnQ6IHRoaXMucnhQb3J0IH0sICgpID0+IHtcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgUlggc29ja2V0IGJvdW5kIHRvIDAuMC4wLjA6JHt0aGlzLnJ4UG9ydH1gKVxuXHRcdFx0Y29uc3QgaWZhY2VzID0gb3MubmV0d29ya0ludGVyZmFjZXMoKSBhcyBSZWNvcmQ8c3RyaW5nLCBpbXBvcnQoJ29zJykuTmV0d29ya0ludGVyZmFjZUluZm9bXT5cblx0XHRcdGZvciAoY29uc3QgYWRkcnMgb2YgT2JqZWN0LnZhbHVlcyhpZmFjZXMpKSB7XG5cdFx0XHRcdGZvciAoY29uc3QgYWRkciBvZiBhZGRycyA/PyBbXSkge1xuXHRcdFx0XHRcdGlmIChhZGRyLmZhbWlseSA9PT0gJ0lQdjQnICYmICFhZGRyLmludGVybmFsICYmICF0aGlzLmpvaW5lZEludGVyZmFjZXMuaGFzKGFkZHIuYWRkcmVzcykpIHtcblx0XHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRcdHRoaXMucnhTb2NrZXQuYWRkTWVtYmVyc2hpcCh0aGlzLm11bHRpY2FzdEdyb3VwLCBhZGRyLmFkZHJlc3MpXG5cdFx0XHRcdFx0XHRcdHRoaXMuam9pbmVkSW50ZXJmYWNlcy5hZGQoYWRkci5hZGRyZXNzKVxuXHRcdFx0XHRcdFx0XHRsb2dnZXIuZGVidWcoYFByZS1qb2luZWQgbXVsdGljYXN0ICR7dGhpcy5tdWx0aWNhc3RHcm91cH0gb24gJHthZGRyLmFkZHJlc3N9YClcblx0XHRcdFx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3QgcHJlLWpvaW4gbXVsdGljYXN0IG9uICR7YWRkci5hZGRyZXNzfTogJHtTdHJpbmcoX2UpfWApXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdC8vIERpYWdub3N0aWMgbXVsdGljYXN0IHNvY2tldCBcdTIwMTQgYm91bmQgdG8gdGhlIG11bHRpY2FzdCBncm91cCBhZGRyZXNzIHNvIG9ubHlcblx0XHQvLyBtdWx0aWNhc3QtZGVsaXZlcmVkIHBhY2tldHMgYXJyaXZlIGhlcmUuIEFueSBTdHVkaW8tVCByZXNwb25zZSBzZWVuIG9uIHRoaXNcblx0XHQvLyBzb2NrZXQgd2FzIHNlbnQgdG8gMjI0LjAuMC4yMzE7IHJlc3BvbnNlcyBzZWVuIG9ubHkgb24gcnhTb2NrZXQgYXJlIHVuaWNhc3QuXG5cdFx0dGhpcy5yeE1jYXN0U29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblx0XHR0aGlzLnJ4TWNhc3RTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCBtY2FzdCBzb2NrZXQgZXJyb3I6ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHR9KVxuXHRcdHRoaXMucnhNY2FzdFNvY2tldC5vbignbWVzc2FnZScsIChtc2c6IEJ1ZmZlciwgcmluZm86IGRncmFtLlJlbW90ZUluZm8pID0+IHtcblx0XHRcdGlmIChtc2cubGVuZ3RoIDwgMjUpIHJldHVyblxuXHRcdFx0aWYgKG1zZ1swXSAhPT0gMHhmZiB8fCBtc2dbMV0gIT09IDB4ZmYpIHJldHVyblxuXHRcdFx0Y29uc3Qgc2lnID0gbXNnLnN1YmFycmF5KDE2LCAyNClcblx0XHRcdGlmIChzaWcudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdTdHVkaW8tVCcpIHJldHVyblxuXHRcdFx0Y29uc3Qgc3RQYXlsb2FkID0gbXNnLnN1YmFycmF5KDI0KVxuXHRcdFx0aWYgKHN0UGF5bG9hZC5sZW5ndGggPCAyIHx8IHN0UGF5bG9hZFswXSAhPT0gMHg1YSkgcmV0dXJuXG5cdFx0XHRjb25zdCByZXNwQ21kSWQgPSBzdFBheWxvYWRbMV1cblx0XHRcdGNvbnN0IGlzUmVzcG9uc2UgPSAocmVzcENtZElkICYgMHg4MCkgIT09IDBcblx0XHRcdGNvbnN0IG9yaWdpbmFsQ21kSWQgPSByZXNwQ21kSWQgJiAweDdmXG5cdFx0XHRpZiAoaXNSZXNwb25zZSkge1xuXHRcdFx0XHRjb25zdCBrZXkgPSBgJHtyaW5mby5hZGRyZXNzfToke29yaWdpbmFsQ21kSWR9YFxuXHRcdFx0XHRjb25zdCB3YXNVbmljYXN0QWxyZWFkeSA9ICF0aGlzLm1jYXN0RGVsaXZlcmllcy5oYXMoa2V5KVxuXHRcdFx0XHR0aGlzLm1jYXN0RGVsaXZlcmllcy5hZGQoa2V5KVxuXHRcdFx0XHRsb2dnZXIuZGVidWcoXG5cdFx0XHRcdFx0YE11bHRpY2FzdCBkZWxpdmVyeTogJHtyaW5mby5hZGRyZXNzfSBjbWQ6JHt0b0hleChvcmlnaW5hbENtZElkKX1gICtcblx0XHRcdFx0XHRcdCh3YXNVbmljYXN0QWxyZWFkeSA/ICcgKHVuaWNhc3QgYWxzbyBwZW5kaW5nKScgOiAnIChtdWx0aWNhc3Qgb25seSBzbyBmYXIpJyksXG5cdFx0XHRcdClcblx0XHRcdFx0Ly8gQ2xlYW4gdXAgdGhlIGtleSBhZnRlciBhIHNob3J0IGRlbGF5IHNvIHdlIGRvbid0IGFjY3VtdWxhdGUgc3RhbGUgZW50cmllc1xuXHRcdFx0XHRzZXRUaW1lb3V0KCgpID0+IHRoaXMubWNhc3REZWxpdmVyaWVzLmRlbGV0ZShrZXkpLCA1MDApXG5cdFx0XHR9XG5cdFx0fSlcblx0XHR0aGlzLnJ4TWNhc3RTb2NrZXQuYmluZCh7IGFkZHJlc3M6IHRoaXMubXVsdGljYXN0R3JvdXAsIHBvcnQ6IHRoaXMucnhQb3J0IH0sICgpID0+IHtcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgUlggbWNhc3Qgc29ja2V0IGJvdW5kIHRvICR7dGhpcy5tdWx0aWNhc3RHcm91cH06JHt0aGlzLnJ4UG9ydH1gKVxuXHRcdH0pXG5cdH1cblxuXHRwdWJsaWMgY2xvc2UoKTogdm9pZCB7XG5cdFx0Ly8gU3RvcCBhbGwgQ29uTW9uIGtlZXBhbGl2ZXMgYW5kIGNsb3NlIHRoZWlyIHNvY2tldHMgYmVmb3JlIGNsb3NpbmcgdGhlIG1haW4gc29ja2V0c1xuXHRcdGZvciAoY29uc3QgY2xlYW51cCBvZiB0aGlzLl9jb25tb25DbGVhbnVwcy52YWx1ZXMoKSkge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y2xlYW51cCgpXG5cdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0fVxuXHRcdHRoaXMuX2Nvbm1vbkNsZWFudXBzLmNsZWFyKClcblx0XHR0cnkge1xuXHRcdFx0Zm9yIChjb25zdCBsb2NhbEFkZHIgb2YgQXJyYXkuZnJvbSh0aGlzLmpvaW5lZEludGVyZmFjZXMpKSB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0dGhpcy5yeFNvY2tldC5kcm9wTWVtYmVyc2hpcCh0aGlzLm11bHRpY2FzdEdyb3VwLCBsb2NhbEFkZHIpXG5cdFx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdFx0dHJ5IHtcblx0XHRcdHRoaXMucnhNY2FzdFNvY2tldD8uY2xvc2UoKVxuXHRcdFx0dGhpcy5yeE1jYXN0U29ja2V0ID0gbnVsbFxuXHRcdH0gY2F0Y2gge1xuXHRcdFx0LyogaWdub3JlICovXG5cdFx0fVxuXHRcdHRyeSB7XG5cdFx0XHR0aGlzLnJ4U29ja2V0LmNsb3NlKClcblx0XHR9IGNhdGNoIHtcblx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdH1cblx0XHR0cnkge1xuXHRcdFx0dGhpcy50eFNvY2tldC5jbG9zZSgpXG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogUHJvdmlkZSB0aGUgYWN0aXZlIGRldmljZSBtb2RlbCBhbmQgYWN0aW9uIGRlZmluaXRpb25zIHNvIGluY29taW5nIG1lc3NhZ2VzXG5cdCAqIGNhbiBiZSBkZWNvZGVkIGludG8gaHVtYW4tcmVhZGFibGUgbmFtZXMuIENhbGwgZnJvbSBtYWluLnRzIGFmdGVyIGNvbmZpZyBsb2FkLlxuXHQgKi9cblx0cHVibGljIHNldE1vZGVsKG1vZGVsOiBzdHJpbmcsIGFjdGlvbnM6IFN0QWN0aW9uW10pOiB2b2lkIHtcblx0XHR0aGlzLm1vZGVsID0gbW9kZWxcblx0XHR0aGlzLmFjdGlvbnMgPSBhY3Rpb25zXG5cdH1cblxuXHQvKipcblx0ICogU2V0IGNhbGxiYWNrIHRvIHRyaWdnZXIgd2hlbiBkZXZpY2Ugc3RhdGUgY2hhbmdlcyAoZm9yIGZlZWRiYWNrcykuXG5cdCAqIENhbGwgZnJvbSBtYWluLnRzIHRvIHdpcmUgdXAgY2hlY2tGZWVkYmFja3MuXG5cdCAqL1xuXHRwdWJsaWMgc2V0RmVlZGJhY2tDYWxsYmFjayhjYWxsYmFjazogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZCk6IHZvaWQge1xuXHRcdHRoaXMuZmVlZGJhY2tDYWxsYmFjayA9IGNhbGxiYWNrXG5cdH1cblxuXHQvKiogUmV0dXJucyB0cnVlIGlmIHRoZSBkZXZpY2UgYXQgdGhlIGdpdmVuIElQIGhhcyBiZWVuIGF1dGhvcml6ZWQgdG8gcmVjZWl2ZSBjb21tYW5kcy4gKi9cblx0cHVibGljIGlzRGV2aWNlQXV0aG9yaXplZChpcDogc3RyaW5nKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuYXV0aG9yaXplZElwcy5oYXMoaXApXG5cdH1cblxuXHQvKiogTWFyayBhbiBJUCBhcyB2ZXJpZmllZCBhbmQgYWxsb3dlZCB0byByZWNlaXZlIFN0dWRpby1UIGNvbW1hbmRzLiAqL1xuXHRwdWJsaWMgYXV0aG9yaXplRGV2aWNlKGlwOiBzdHJpbmcpOiB2b2lkIHtcblx0XHR0aGlzLmF1dGhvcml6ZWRJcHMuYWRkKGlwKVxuXHRcdGxvZ2dlci5kZWJ1ZyhgQXV0aG9yaXplZCBkZXZpY2UgYXQgJHtpcH1gKVxuXHR9XG5cblx0LyoqIFJlbW92ZSBhdXRob3JpemF0aW9uIGZvciBhbiBJUCAoZS5nLiBvbiBjb25maWcgY2hhbmdlIG9yIG1vZGVsIG1pc21hdGNoKS4gKi9cblx0cHVibGljIHJldm9rZURldmljZShpcDogc3RyaW5nKTogdm9pZCB7XG5cdFx0dGhpcy5hdXRob3JpemVkSXBzLmRlbGV0ZShpcClcblx0XHR0aGlzLmRldmljZVN0YXRlLmRlbGV0ZShpcClcblx0XHR0aGlzLm1hY0NhY2hlLmRlbGV0ZShpcClcblx0XHR0aGlzLnNlc3Npb25Fc3RhYmxpc2hlZC5kZWxldGUoaXApXG5cdFx0dGhpcy5fY29ubW9uQ2xlYW51cHMuZ2V0KGlwKT8uKClcblx0XHR0aGlzLl9jb25tb25DbGVhbnVwcy5kZWxldGUoaXApXG5cdFx0bG9nZ2VyLmRlYnVnKGBSZXZva2VkIGRldmljZSBhdCAke2lwfWApXG5cdH1cblxuXHQvKipcblx0ICogT3BlbnMgYSBEYW50ZSBDb25Nb24gc2Vzc2lvbiBmb3IgdGhlIGRldmljZSBpZiBcInVzZUNvbk1vblwiOiB0cnVlIGlzIHNldCBpbiBpdHNcblx0ICogZGV2aWNlIEpTT04uIENhY2hlcyB0aGUgcmVzdWx0IHNvIHRoZSBoYW5kc2hha2Ugb25seSBydW5zIG9uY2UgcGVyIElQLlxuXHQgKiBEZWxlZ2F0ZXMgdG8gY29ubW9uLnRzLiBEZXZpY2VzIHdpdGhvdXQgdXNlQ29uTW9uIGFyZSBtYXJrZWQgYXMgcmVhZHkgaW1tZWRpYXRlbHkuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgb3BlblNlc3Npb24oZGV2aWNlSXA6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xuXHRcdGlmICh0aGlzLnNlc3Npb25Fc3RhYmxpc2hlZC5oYXMoZGV2aWNlSXApKSByZXR1cm4gdHJ1ZVxuXHRcdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYSh0aGlzLm1vZGVsKVxuXHRcdGlmICghc2NoZW1hPy51c2VDb25Nb24pIHtcblx0XHRcdC8vIERldmljZSBkb2VzIG5vdCByZXF1aXJlIENvbk1vbiBcdTIwMTQgc2tpcCBzaWxlbnRseVxuXHRcdFx0dGhpcy5zZXNzaW9uRXN0YWJsaXNoZWQuYWRkKGRldmljZUlwKVxuXHRcdFx0cmV0dXJuIHRydWVcblx0XHR9XG5cdFx0Y29uc3QgY2xlYW51cCA9IGF3YWl0IG9wZW5Db25Nb25TZXNzaW9uKGRldmljZUlwKVxuXHRcdGNvbnN0IHN1Y2Nlc3MgPSBjbGVhbnVwICE9PSBudWxsXG5cdFx0Ly8gTWFyayBhcyBhdHRlbXB0ZWQgcmVnYXJkbGVzcyBvZiBvdXRjb21lIFx1MjAxNCByZXRyeWluZyBpbW1lZGlhdGVseSB3b3VsZCBoaXQgdGhlXG5cdFx0Ly8gc2FtZSBiaW5kIGVycm9yIChFQUREUklOVVNFKS4gRGV2aWNlcyB0aGF0IGRvbid0IG5lZWQgQ29uTW9uIHdvcmsgZmluZSB3aXRob3V0IGl0LlxuXHRcdHRoaXMuc2Vzc2lvbkVzdGFibGlzaGVkLmFkZChkZXZpY2VJcClcblx0XHRpZiAoc3VjY2Vzcykge1xuXHRcdFx0dGhpcy5fY29ubW9uQ2xlYW51cHMuc2V0KGRldmljZUlwLCBjbGVhbnVwKVxuXHRcdH1cblx0XHRyZXR1cm4gc3VjY2Vzc1xuXHR9XG5cblx0LyoqXG5cdCAqIFNlbmRzIGEgdW5pY2FzdCBEYW50ZSBpbmZvIHJlcXVlc3QgdG8gYSBzcGVjaWZpYyBJUCBhbmQgd2FpdHMgZm9yIHRoZVxuXHQgKiBkZXZpY2UgaW5mbyByZXNwb25zZS4gUmV0dXJucyB0aGUgRGV2aWNlSW5mbyBpZiB0aGUgZGV2aWNlIHJlc3BvbmRzIHdpdGhpblxuXHQgKiB0aW1lb3V0TXMsIG9yIG51bGwgaWYgbm8gcmVzcG9uc2UuIFVzZWQgdG8gdmVyaWZ5IGEgbWFudWFsbHkgY29uZmlndXJlZCBJUC5cblx0ICogRG9lcyBOT1QgcmVxdWlyZSBhdXRob3JpemF0aW9uIFx1MjAxNCB0aGlzIGlzIGhvdyBhdXRob3JpemF0aW9uIGlzIGVzdGFibGlzaGVkLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIHByb2JlRGV2aWNlKGlwOiBzdHJpbmcsIHRpbWVvdXRNcyA9IDMwMDApOiBQcm9taXNlPERldmljZUluZm8gfCBudWxsPiB7XG5cdFx0YXdhaXQgdGhpcy50eFJlYWR5XG5cdFx0cmV0dXJuIGRhbnRlUHJvYmVEZXZpY2UoXG5cdFx0XHR0aGlzLnR4U29ja2V0LFxuXHRcdFx0KGtleSwgY2IpID0+IHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNldChrZXksIGNiKSxcblx0XHRcdChrZXkpID0+IHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLmRlbGV0ZShrZXkpLFxuXHRcdFx0YXN5bmMgKGRlc3RJcCkgPT4gdGhpcy5lbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcCksXG5cdFx0XHRpcCxcblx0XHRcdHRpbWVvdXRNcyxcblx0XHQpXG5cdH1cblxuXHQvKipcblx0ICogU2VuZCBhIENNRF9HRVRfQUxMX1NFVFRJTkdTICgweDBhKSByZXF1ZXN0IHRvIHRoZSBkZXZpY2UgYW5kIHN0b3JlIHRoZSByZXNwb25zZVxuXHQgKiBpbiBkZXZpY2VTdGF0ZS4gUmV0dXJucyB0aGUgcmF3IHJlc3BvbnNlIGJ1ZmZlciBmb3IgcGFyc2luZy5cblx0ICovXG5cdHB1YmxpYyBhc3luYyByZXF1ZXN0QWxsU2V0dGluZ3MoZGV2aWNlSXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0bG9nZ2VyLmluZm8oYFJlcXVlc3RpbmcgYWxsIHNldHRpbmdzIGZyb20gJHtkZXZpY2VJcH1gKVxuXHRcdGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5zZW5kQXdhaXRBY2soQ01EX0dFVF9BTExfU0VUVElOR1MsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIGRldmljZUlwLCBmYWxzZSlcblx0XHQvLyBkZXZpY2VTdGF0ZSBpcyBwb3B1bGF0ZWQgYnkgbG9nU3RQYXlsb2FkIHdoZW4gdGhlIENNRF9HRVRfQUxMX1NFVFRJTkdTIHJlc3BvbnNlIGFycml2ZXNcblx0XHRyZXR1cm4gcmVzcG9uc2Vcblx0fVxuXG5cdC8qKlxuXHQgKiBEaXNjb3ZlcnMgU3R1ZGlvIFRlY2hub2xvZ2llcyBEYW50ZSBkZXZpY2VzIG9uIHRoZSBsb2NhbCBuZXR3b3JrLlxuXHQgKlxuXHQgKiBMaXN0ZW5zIGZvciBEYW50ZSBhbm5vdW5jZXMgb24gMjI0LjAuMC4yMzM6ODcwOCwgc2VuZHMgdW5pY2FzdCBpbmZvIHJlcXVlc3RzXG5cdCAqIHRvIGVhY2ggZGlzY292ZXJlZCBJUCwgYW5kIGNvbGxlY3RzIDB4MDE3MCByZXNwb25zZXMgdmlhIHRoZSByeFNvY2tldC5cblx0ICovXG5cdHB1YmxpYyBhc3luYyBkaXNjb3ZlckRldmljZXModGltZW91dE1zID0gNTAwMCk6IFByb21pc2U8RGV2aWNlSW5mb1tdPiB7XG5cdFx0Y29uc3QgRElTQ09WRVJZX0tFWSA9ICdfX2Rpc2NvdmVyeV9fJ1xuXHRcdGNvbnN0IGZvdW5kRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW11cblxuXHRcdHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNldChESVNDT1ZFUllfS0VZLCAoZGV2aWNlOiBEZXZpY2VJbmZvKSA9PiB7XG5cdFx0XHRpZiAoIWZvdW5kRGV2aWNlcy5zb21lKChkKSA9PiBkLmlwID09PSBkZXZpY2UuaXApKSB7XG5cdFx0XHRcdGZvdW5kRGV2aWNlcy5wdXNoKGRldmljZSlcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0dHJ5IHtcblx0XHRcdGF3YWl0IHRoaXMudHhSZWFkeVxuXHRcdFx0YXdhaXQgZGlzY292ZXJEZXZpY2VzKHRoaXMudHhTb2NrZXQsIGFzeW5jIChkZXN0SXApID0+IHRoaXMuZW5zdXJlTWVtYmVyc2hpcEZvcihkZXN0SXApLCB0aW1lb3V0TXMpXG5cdFx0XHRyZXR1cm4gZm91bmREZXZpY2VzXG5cdFx0fSBmaW5hbGx5IHtcblx0XHRcdHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLmRlbGV0ZShESVNDT1ZFUllfS0VZKVxuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBSZXF1ZXN0cyBkZXZpY2UgZmlybXdhcmUgdmVyc2lvbiB2aWEgU3R1ZGlvLVQgcHJvdG9jb2wgKENNRF9HRVRfRklSTVdBUkUpLlxuXHQgKiBSZXR1cm5zIHRoZSBmaXJtd2FyZSB2ZXJzaW9uIHN0cmluZyAoZS5nLiwgXCIzLjAxXCIsIFwiMi4yXCIsIFwiMS4wNVwiKS5cblx0ICovXG5cdHB1YmxpYyBhc3luYyByZXF1ZXN0RmlybXdhcmVWZXJzaW9uKGRldmljZUlwOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuXHRcdGxvZ2dlci5pbmZvKGBSZXF1ZXN0aW5nIGZpcm13YXJlIHZlcnNpb24gZnJvbSAke2RldmljZUlwfWApXG5cdFx0Y29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLnNlbmRBd2FpdEFjayhDTURfR0VUX0ZJUk1XQVJFLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBkZXZpY2VJcCwgZmFsc2UpXG5cblx0XHQvLyBSZXNwb25zZSBzdHJ1Y3R1cmU6IFtoZWFkZXJdIDB4NWEgMHg4MCBbZmlybXdhcmVfZGF0YV0gQ1JDXG5cdFx0Ly8gRmlybXdhcmUgZGF0YSBzdGFydHMgYXQgYnl0ZSAyNiAoMjQtYnl0ZSBoZWFkZXIgKyAweDVhICsgMHg4MClcblx0XHRjb25zdCBkYXRhU3RhcnQgPSAyNlxuXG5cdFx0aWYgKHJlc3BvbnNlLmxlbmd0aCA8IGRhdGFTdGFydCArIDMpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBGaXJtd2FyZSByZXNwb25zZSB0b28gc2hvcnQ6ICR7cmVzcG9uc2UubGVuZ3RofSBieXRlc2ApXG5cdFx0XHRyZXR1cm4gJ1Vua25vd24nXG5cdFx0fVxuXG5cdFx0Ly8gRmlybXdhcmUgZm9ybWF0OiBbdW5rbm93bl9ieXRlLCBtYWpvciwgbWlub3JdXG5cdFx0Y29uc3QgbWFqb3IgPSByZXNwb25zZVtkYXRhU3RhcnQgKyAxXVxuXHRcdGNvbnN0IG1pbm9yID0gcmVzcG9uc2VbZGF0YVN0YXJ0ICsgMl1cblxuXHRcdGNvbnN0IG1pbm9yU3RyID1cblx0XHRcdG1pbm9yIDwgMTBcblx0XHRcdFx0PyBtaW5vci50b1N0cmluZygpLnBhZFN0YXJ0KDIsICcwJykgLy8gZS5nLiAxIFx1MjE5MiBcIjAxXCIsIDUgXHUyMTkyIFwiMDVcIlxuXHRcdFx0XHQ6IG1pbm9yLnRvU3RyaW5nKCkgLy8gZS5nLiAxMCBcdTIxOTIgXCIxMFwiXG5cblx0XHRjb25zdCBmaXJtd2FyZSA9IGAke21ham9yfS4ke21pbm9yU3RyfWBcblxuXHRcdGxvZ2dlci5kZWJ1ZyhgRmlybXdhcmUgdmVyc2lvbjogJHtmaXJtd2FyZX1gKVxuXHRcdHJldHVybiBmaXJtd2FyZVxuXHR9XG5cblx0LyoqXG5cdCAqIEpvaW5zIHRoZSBtdWx0aWNhc3QgcmVzcG9uc2UgZ3JvdXAgb24gdGhlIGludGVyZmFjZSB0aGF0IHJvdXRlcyB0byBkZXN0SXAuXG5cdCAqIE9ubHkgam9pbnMgdGhlIHNwZWNpZmljIGludGVyZmFjZSB1c2VkIHRvIHJlYWNoIHRoZSBkZXZpY2UsIGFuZCBvbmx5IG9uY2UgcGVyIGludGVyZmFjZS5cblx0ICovXG5cdHByaXZhdGUgYXN5bmMgZW5zdXJlTWVtYmVyc2hpcEZvcihkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBsb2NhbEFkZHIgPSBhd2FpdCBnZXRMb2NhbEFkZHJlc3NGb3JEZXN0aW5hdGlvbihkZXN0SXApXG5cdFx0XHRpZiAoIWxvY2FsQWRkcikge1xuXHRcdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IGRldGVybWluZSBsb2NhbCBhZGRyZXNzIGZvciBkZXN0aW5hdGlvbiAke2Rlc3RJcH1gKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0aWYgKHRoaXMuam9pbmVkSW50ZXJmYWNlcy5oYXMobG9jYWxBZGRyKSkge1xuXHRcdFx0XHQvLyBhbHJlYWR5IGpvaW5lZFxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5yeFNvY2tldC5hZGRNZW1iZXJzaGlwKHRoaXMubXVsdGljYXN0R3JvdXAsIGxvY2FsQWRkcilcblx0XHRcdFx0dGhpcy5qb2luZWRJbnRlcmZhY2VzLmFkZChsb2NhbEFkZHIpXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBKb2luZWQgbXVsdGljYXN0ICR7dGhpcy5tdWx0aWNhc3RHcm91cH0gb24gJHtsb2NhbEFkZHJ9YClcblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gam9pbiBtdWx0aWNhc3Qgb24gJHtsb2NhbEFkZHJ9OiAke1N0cmluZyhfZSl9YClcblx0XHRcdH1cblx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYGVuc3VyZU1lbWJlcnNoaXBGb3IgZmFpbGVkOiAke19lfWApXG5cdFx0fVxuXHR9XG5cblx0cHVibGljIGFzeW5jIHNlbmRBd2FpdEFjayhcblx0XHRjbWRJZDogbnVtYmVyLFxuXHRcdGJ1c0NoOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0c2V0dGluZ0lkOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0dmFsdWU6IHVua25vd24sXG5cdFx0ZGVzdElwOiBzdHJpbmcsXG5cdFx0YWRkTGVuID0gdHJ1ZSxcblx0KTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHR0aGlzLnBlbmRpbmdDb21tYW5kQ291bnQrK1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZTxCdWZmZXI+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdHRoaXMuc2VuZFF1ZXVlID0gdGhpcy5zZW5kUXVldWUudGhlbihhc3luYyAoKSA9PlxuXHRcdFx0XHR0aGlzLl9zZW5kQXdhaXRBY2soY21kSWQsIGJ1c0NoLCBzZXR0aW5nSWQsIHZhbHVlLCBkZXN0SXAsIGFkZExlbilcblx0XHRcdFx0XHQudGhlbigoYnVmKSA9PiB7XG5cdFx0XHRcdFx0XHR0aGlzLnBlbmRpbmdDb21tYW5kQ291bnQtLVxuXHRcdFx0XHRcdFx0Ly8gT25seSB0cmlnZ2VyIHJlcXVlc3RBbGxTZXR0aW5ncyBhZnRlciBhIHdyaXRlIChTRVQpIGNvbW1hbmQsIG5vdCBhIHJlYWQvcG9sbC5cblx0XHRcdFx0XHRcdC8vIEEgd3JpdGUgYWx3YXlzIGhhcyBhIHZhbHVlOyByZWFkcyAoR0VULCBCVVNfR0VUKSBuZXZlciBkby5cblx0XHRcdFx0XHRcdGlmICh0aGlzLnBlbmRpbmdDb21tYW5kQ291bnQgPT09IDAgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdFx0XHR0aGlzLnJlcXVlc3RBbGxTZXR0aW5ncyhkZXN0SXApLmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIHJlZnJlc2ggc2V0dGluZ3MgYWZ0ZXIgY29tbWFuZDogJHtlcnJ9YClcblx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdHJlc29sdmUoYnVmKVxuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0LmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0XHRcdHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudC0tXG5cdFx0XHRcdFx0XHRyZWplY3QoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIgOiBuZXcgRXJyb3IoU3RyaW5nKGVycikpKVxuXHRcdFx0XHRcdH0pLFxuXHRcdFx0KVxuXHRcdH0pXG5cdH1cblxuXHRwcml2YXRlIGFzeW5jIF9zZW5kQXdhaXRBY2soXG5cdFx0Y21kSWQ6IG51bWJlcixcblx0XHRidXNDaDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHNldHRpbmdJZDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHZhbHVlOiB1bmtub3duLFxuXHRcdGRlc3RJcDogc3RyaW5nLFxuXHRcdGFkZExlbiA9IHRydWUsXG5cdCk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0Y29uc3QgdGltZW91dE1zID0gMjAwMFxuXG5cdFx0Y29uc3QgZGF0YUJsb2NrOiBudW1iZXJbXSA9IFtdXG5cdFx0aWYgKHNldHRpbmdJZCAhPT0gdW5kZWZpbmVkKSBkYXRhQmxvY2sucHVzaChzZXR0aW5nSWQgJiAweGZmKVxuXHRcdGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkKSBkYXRhQmxvY2sucHVzaCguLi5TdENvbnRyb2xsZXIuYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlKSlcblxuXHRcdGNvbnN0IHBheWxvYWRCb2R5OiBudW1iZXJbXSA9IFsweDVhLCBjbWRJZCAmIDB4ZmZdXG5cblx0XHRpZiAoY21kSWQgPT09IENNRF9NSUNfUFJFICYmIGJ1c0NoICE9PSB1bmRlZmluZWQgJiYgc2V0dGluZ0lkICE9PSB1bmRlZmluZWQgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0Ly8gUG9zaXRpb25hbCBmb3JtYXQ6IFsweDVhXSBbMHgwMl0gW2J1c0NoXSBbdmFsMF0gW3ZhbDFdIFt2YWwyXSAuLi5cblx0XHRcdC8vIFJlYWQgYWxsIHBvc2l0aW9ucyBmcm9tIGRldmljZVN0YXRlLCBvdmVycmlkZSB0aGUgdGFyZ2V0IHBvc2l0aW9uIHdpdGggbmV3IHZhbHVlLlxuXHRcdFx0Ly8gQWxzbyB1cGRhdGUgZGV2aWNlU3RhdGUgb3B0aW1pc3RpY2FsbHkgc28gY29uc2VjdXRpdmUgQ01EX01JQ19QUkUgY29tbWFuZHMgY2hhaW4gY29ycmVjdGx5LlxuXHRcdFx0aWYgKCF0aGlzLmRldmljZVN0YXRlLmhhcyhkZXN0SXApKSB0aGlzLmRldmljZVN0YXRlLnNldChkZXN0SXAsIG5ldyBNYXAoKSlcblx0XHRcdGNvbnN0IGlwU3RhdGUgPSB0aGlzLmRldmljZVN0YXRlLmdldChkZXN0SXApIVxuXHRcdFx0Y29uc3QgbnVtUG9zaXRpb25zID0gMyAvLyBnYWluLCBlbGVjdHJldC9waGFudG9tLCB1bmtub3duXG5cdFx0XHRjb25zdCBwb3NpdGlvbnM6IG51bWJlcltdID0gW11cblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgbnVtUG9zaXRpb25zOyBpKyspIHtcblx0XHRcdFx0Y29uc3Qgc3RhdGVLZXkgPSBtYWtlU2V0dGluZ0lkKHRoaXMubW9kZWwsIENNRF9NSUNfUFJFLCBpLCBidXNDaClcblx0XHRcdFx0Y29uc3QgdmFsID0gaSA9PT0gc2V0dGluZ0lkID8gTnVtYmVyKHZhbHVlKSA6IChpcFN0YXRlLmdldChzdGF0ZUtleSkgPz8gMClcblx0XHRcdFx0cG9zaXRpb25zLnB1c2godmFsKVxuXHRcdFx0XHRpcFN0YXRlLnNldChzdGF0ZUtleSwgdmFsKSAvLyBvcHRpbWlzdGljIHVwZGF0ZVxuXHRcdFx0fVxuXHRcdFx0cGF5bG9hZEJvZHkucHVzaChidXNDaCAmIDB4ZmYsIC4uLnBvc2l0aW9ucylcblx0XHR9IGVsc2Uge1xuXHRcdFx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIHBheWxvYWRCb2R5LnB1c2goYnVzQ2ggJiAweGZmKVxuXHRcdFx0aWYgKGFkZExlbikgcGF5bG9hZEJvZHkucHVzaChkYXRhQmxvY2subGVuZ3RoKVxuXHRcdFx0aWYgKGRhdGFCbG9jay5sZW5ndGggPiAwKSBwYXlsb2FkQm9keS5wdXNoKC4uLmRhdGFCbG9jaylcblx0XHR9XG5cblx0XHRjb25zdCBjcmMgPSBTdENvbnRyb2xsZXIuY3JjOER2YlMyKHBheWxvYWRCb2R5KVxuXHRcdGNvbnN0IHBheWxvYWRXaXRoQ3JjID0gQnVmZmVyLmZyb20oWy4uLnBheWxvYWRCb2R5LCBjcmNdKVxuXG5cdFx0Ly8gSHVtYW4tcmVhZGFibGUgaW5mbyBsb2cgZm9yIHRoZSBvdXRnb2luZyBjb21tYW5kXG5cdFx0aWYgKHNldHRpbmdJZCAhPT0gdW5kZWZpbmVkICYmIHZhbHVlICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdGNvbnN0IHZhbHVlQnl0ZXMgPSBTdENvbnRyb2xsZXIuYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlKVxuXHRcdFx0Y29uc3Qgc2V0dGluZzogUGFyc2VkU2V0dGluZyA9IHtcblx0XHRcdFx0Y21kX2lkOiBjbWRJZCxcblx0XHRcdFx0aWQ6IHNldHRpbmdJZCxcblx0XHRcdFx0YnVzQ2gsXG5cdFx0XHRcdHZhbHVlQnl0ZXMsXG5cdFx0XHR9XG5cdFx0XHRsb2dnZXIuaW5mbyhgVFggJHtkZXN0SXB9IHwgJHtmb3JtYXRQYXJzZWRTZXR0aW5nKHNldHRpbmcsIHRoaXMuYWN0aW9ucyl9YClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYFRYICR7ZGVzdElwfSB8ICR7Z2V0Q29tbWFuZE5hbWUoY21kSWQpfWApXG5cdFx0fVxuXG5cdFx0Ly8gUmVqZWN0IGNvbW1hbmRzIHRvIHVudmVyaWZpZWQgZGV2aWNlcyBcdTIwMTQgbG9nIHRoZSB3b3VsZC1iZSBwYWNrZXQgZmlyc3QgYXQgZGVidWdcblx0XHQvLyBzbyB0aGUgYnl0ZXMgYXJlIHZpc2libGUgZXZlbiB3aGVuIHRoZSBkZXZpY2UgaXMgb2ZmbGluZS5cblx0XHRpZiAoIXRoaXMuYXV0aG9yaXplZElwcy5oYXMoZGVzdElwKSkge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBQYWNrZXQgKG5vdCBzZW50IFx1MjAxNCBkZXZpY2Ugbm90IGF1dGhvcml6ZWQpIHRvICR7ZGVzdElwfTogJHtwYXlsb2FkV2l0aENyYy50b1N0cmluZygnaGV4Jyl9YClcblx0XHRcdHRocm93IG5ldyBFcnJvcihgRGV2aWNlIGF0ICR7ZGVzdElwfSBpcyBub3QgYXV0aG9yaXplZCBcdTIwMTQgdmVyaWZ5IHRoZSBJUCBhbmQgbW9kZWwgbWF0Y2ggYmVmb3JlIHNlbmRpbmcgY29tbWFuZHNgKVxuXHRcdH1cblxuXHRcdC8vIElmIFwidXNlQ29uTW9uXCIgaXMgc2V0IGluIHRoZSBkZXZpY2UgSlNPTiwgZW5zdXJlIHRoZSBEYW50ZSBDb25Nb24gc2Vzc2lvblxuXHRcdC8vIChwb3J0IDg4MDApIGlzIG9wZW4gYmVmb3JlIHNlbmRpbmcuIG9wZW5TZXNzaW9uKCkgY2FjaGVzIHRoZSByZXN1bHQgXHUyMDE0IHRoZVxuXHRcdC8vIGhhbmRzaGFrZSBvbmx5IHJ1bnMgb25jZSBwZXIgSVAuIE5vbi11c2VDb25Nb24gZGV2aWNlcyBhcmUgbWFya2VkIHJlYWR5IGltbWVkaWF0ZWx5LlxuXHRcdGlmICghdGhpcy5zZXNzaW9uRXN0YWJsaXNoZWQuaGFzKGRlc3RJcCkpIHtcblx0XHRcdGF3YWl0IHRoaXMub3BlblNlc3Npb24oZGVzdElwKVxuXHRcdFx0Ly8gU2Vzc2lvbiBmYWlsdXJlIGlzIG5vbi1mYXRhbCBcdTIwMTQgbWFueSBkZXZpY2VzIHJlc3BvbmQgdG8gU3R1ZGlvLVQgcmVnYXJkbGVzcy5cblx0XHR9XG5cblx0XHQvLyBFbnN1cmUgd2UgYXJlIGxpc3RlbmluZyBmb3IgcmVwbGllcyBvbiB0aGUgaW50ZXJmYWNlIHRoYXQgd2lsbCByZWNlaXZlIHRoZW1cblx0XHRhd2FpdCB0aGlzLmVuc3VyZU1lbWJlcnNoaXBGb3IoZGVzdElwKVxuXG5cdFx0Y29uc3QgdG90YWxMZW4gPSAyNCArIHBheWxvYWRXaXRoQ3JjLmxlbmd0aFxuXHRcdGNvbnN0IGhlYWRlciA9IGF3YWl0IHRoaXMuYnVpbGRIZWFkZXIodG90YWxMZW4sIGRlc3RJcClcblx0XHRjb25zdCBwYWNrZXQgPSBCdWZmZXIuY29uY2F0KFtoZWFkZXIsIHBheWxvYWRXaXRoQ3JjXSlcblxuXHRcdGxvZ2dlci5kZWJ1ZyhgU2VuZGluZyBwYWNrZXQgdG8gJHtkZXN0SXB9OiAke3BhY2tldC50b1N0cmluZygnaGV4Jyl9YClcblxuXHRcdGNvbnN0IGtleSA9IGAke2Rlc3RJcH06JHtjbWRJZH1gXG5cblx0XHRyZXR1cm4gbmV3IFByb21pc2U8QnVmZmVyPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoYFRpbWVvdXQgd2FpdGluZyBmb3IgQUNLIGZyb20gTW9kZWwgJHt0aGlzLm1vZGVsfSBhdCAke2Rlc3RJcH06ODcwMGApKVxuXHRcdFx0fSwgdGltZW91dE1zKVxuXG5cdFx0XHR0aGlzLnBlbmRpbmdBY2tzLnNldChrZXksIHtcblx0XHRcdFx0cmVzb2x2ZTogKGJ1ZikgPT4ge1xuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRyZXNvbHZlKGJ1Zilcblx0XHRcdFx0fSxcblx0XHRcdFx0cmVqZWN0OiAoZXJyKSA9PiB7XG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdHJlamVjdChlcnIpXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHRpbWVyLFxuXHRcdFx0fSlcblxuXHRcdFx0dGhpcy50eFNvY2tldC5zZW5kKHBhY2tldCwgdGhpcy5kZWZhdWx0UG9ydCwgZGVzdElwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdGlmIChlcnIpIHtcblx0XHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVycikpKVxuXHRcdFx0XHR9XG5cdFx0XHR9KVxuXHRcdH0pXG5cdH1cblxuXHRwcml2YXRlIGhhbmRsZUluY29taW5nKG1zZzogQnVmZmVyLCBzcmNJcDogc3RyaW5nKSB7XG5cdFx0aWYgKG1zZy5sZW5ndGggPCA0KSByZXR1cm5cblx0XHRpZiAobXNnWzBdICE9PSAweGZmIHx8IG1zZ1sxXSAhPT0gMHhmZikgcmV0dXJuXG5cblx0XHRjb25zdCBtc2dUeXBlID0gbXNnLnJlYWRVSW50MTZCRSgyKVxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlICgweDAxNzApIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIFRoZXNlIGhhdmUgXCJBdWRpbmF0ZVwiIGF0IG9mZnNldCAxNiwgbm90IFwiU3R1ZGlvLVRcIiBcdTIwMTQgaGFuZGxlIGJlZm9yZVxuXHRcdC8vIHRoZSBTdHVkaW8tVCBzaWduYXR1cmUgY2hlY2sgYmVsb3cuXG5cdFx0aWYgKG1zZ1R5cGUgPT09IERBTlRFX01TR19JTkZPX1JFU1BPTlNFICYmIHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNpemUgPiAwKSB7XG5cdFx0XHRjb25zdCBkZXZpY2UgPSBwYXJzZURhbnRlSW5mb1Jlc3BvbnNlKG1zZywgc3JjSXApXG5cdFx0XHRpZiAoZGV2aWNlKSB7XG5cdFx0XHRcdGxvZ2dlci5kZWJ1Zyhcblx0XHRcdFx0XHRgRGFudGUgaW5mbyByZXNwb25zZSBmcm9tICR7c3JjSXB9OiBgICtcblx0XHRcdFx0XHRcdGBEZXZpY2VJRD1cIiR7ZGV2aWNlLm5hbWV9XCIsIGAgK1xuXHRcdFx0XHRcdFx0YE1vZGVsPVwiJHtkZXZpY2UubW9kZWx9XCIsIGAgK1xuXHRcdFx0XHRcdFx0YE1vZGVsTmFtZT1cIiR7ZGV2aWNlLm1vZGVsTmFtZX1cIiwgYCArXG5cdFx0XHRcdFx0XHRgTWFudWZhY3R1cmVyPVwiJHtkZXZpY2UubWFudWZhY3R1cmVyfVwiYCxcblx0XHRcdFx0KVxuXG5cdFx0XHRcdC8vIE9ubHkgYWNjZXB0IFN0dWRpbyBUZWNobm9sb2dpZXMgZGV2aWNlcyAoaWRlbnRpZmllZCBieSBEZXZpY2VJRCBcIlN0dWRpby1UXCIpXG5cdFx0XHRcdGlmIChkZXZpY2UubmFtZSA9PT0gJ1N0dWRpby1UJykge1xuXHRcdFx0XHRcdGZvciAoY29uc3QgY2Igb2YgdGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMudmFsdWVzKCkpIHtcblx0XHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRcdGNiKGRldmljZSlcblx0XHRcdFx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBJZ25vcmluZyBub24tU3R1ZGlvIFRlY2hub2xvZ2llcyBkZXZpY2U6IERldmljZUlEPVwiJHtkZXZpY2UubmFtZX1cIiBAICR7c3JjSXB9YClcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0aWYgKG1zZy5sZW5ndGggPCAyNSkgcmV0dXJuXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgY29udHJvbCBwcm90b2NvbCBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRjb25zdCBzaWcgPSBtc2cuc3ViYXJyYXkoMTYsIDI0KVxuXHRcdGlmIChzaWcudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdTdHVkaW8tVCcpIHJldHVyblxuXG5cdFx0Ly8gSWdub3JlIFN0dWRpby1UIHBhY2tldHMgZnJvbSBkZXZpY2VzIHdlIGhhdmVuJ3QgYXV0aG9yaXplZC5cblx0XHQvLyBUaGlzIHByZXZlbnRzIGNyb3NzLWNvbnRhbWluYXRpb24gd2hlbiBtdWx0aXBsZSBkZXZpY2VzIChvciBtdWx0aXBsZVxuXHRcdC8vIENvbXBhbmlvbiBpbnN0YW5jZXMpIGFyZSBvbiB0aGUgc2FtZSBuZXR3b3JrIFx1MjAxNCBhbGwgc2hhcmUgdGhlIG11bHRpY2FzdFxuXHRcdC8vIGdyb3VwIDIyNC4wLjAuMjMxOjg3MDIgYW5kIHdpbGwgcmVjZWl2ZSBlYWNoIG90aGVyJ3MgQUNLcyBhbmQgcHVzaGVzLlxuXHRcdGlmICghdGhpcy5hdXRob3JpemVkSXBzLmhhcyhzcmNJcCkpIHtcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgSWdub3JpbmcgU3R1ZGlvLVQgcGFja2V0IGZyb20gdW5hdXRob3JpemVkIGRldmljZSAke3NyY0lwfWApXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBQYXlsb2FkIHN0YXJ0cyBhdCBvZmZzZXQgMjRcblx0XHQvLyBMYXlvdXQ6IFsweDVhXSBbY21kSWR8MHg4MF0gW2RhdGEuLi5dIFtjcmNdXG5cdFx0Y29uc3Qgc3RQYXlsb2FkID0gbXNnLnN1YmFycmF5KDI0KVxuXHRcdGlmIChzdFBheWxvYWQubGVuZ3RoIDwgMikgcmV0dXJuXG5cdFx0aWYgKHN0UGF5bG9hZFswXSAhPT0gMHg1YSkgcmV0dXJuXG5cblx0XHQvLyBEZXZpY2UgcmVwbGllcyB3aXRoIGNtZCB8IDB4ODBcblx0XHRjb25zdCByZXNwQ21kSWQgPSBzdFBheWxvYWRbMV1cblx0XHRjb25zdCBpc1Jlc3BvbnNlID0gKHJlc3BDbWRJZCAmIDB4ODApICE9PSAwXG5cdFx0Y29uc3Qgb3JpZ2luYWxDbWRJZCA9IHJlc3BDbWRJZCAmIDB4N2YgLy8gc3RyaXAgdGhlIHJlc3BvbnNlIGZsYWdcblxuXHRcdC8vIFJlc3BvbnNlcyBhcmUgZGVsaXZlcmVkIHRvIGJvdGggdW5pY2FzdCBhbmQgbXVsdGljYXN0IDIyNC4wLjAuMjMxOjg3MDIuXG5cdFx0Ly8gV2l0aCB0d28gam9pbmVkIGludGVyZmFjZXMgdGhlIHJ4U29ja2V0IHJlY2VpdmVzIGVhY2ggcmVzcG9uc2UgdHdpY2UuXG5cdFx0Ly8gR2F0ZSBsb2dnaW5nIGFuZCBBQ0sgcmVzb2x1dGlvbiBvbiB0aGUgZmlyc3QgZGVsaXZlcnkgKHBlbmRpbmcgQUNLIHByZXNlbnQpLlxuXHRcdC8vIENNRF9TRVRUSU5HU19QVVNIICgweDBiKSBpcyB1bnNvbGljaXRlZCBcdTIwMTQgYWx3YXlzIGxvZyBpdC5cblx0XHRpZiAoaXNSZXNwb25zZSkge1xuXHRcdFx0Y29uc3Qga2V5ID0gYCR7c3JjSXB9OiR7b3JpZ2luYWxDbWRJZH1gXG5cdFx0XHRjb25zdCBwZW5kaW5nID0gdGhpcy5wZW5kaW5nQWNrcy5nZXQoa2V5KVxuXHRcdFx0aWYgKHBlbmRpbmcpIHtcblx0XHRcdFx0dGhpcy5wZW5kaW5nQWNrcy5kZWxldGUoa2V5KVxuXHRcdFx0XHRjb25zdCB2aWFNdWx0aWNhc3QgPSB0aGlzLm1jYXN0RGVsaXZlcmllcy5oYXMoa2V5KVxuXHRcdFx0XHRsb2dnZXIuZGVidWcoXG5cdFx0XHRcdFx0YFJYIGRlbGl2ZXJ5IG1ldGhvZDogJHtzcmNJcH0gY21kOiR7dG9IZXgob3JpZ2luYWxDbWRJZCl9IHZpYSAke3ZpYU11bHRpY2FzdCA/ICdtdWx0aWNhc3QnIDogJ3VuaWNhc3QnfWAsXG5cdFx0XHRcdClcblx0XHRcdFx0aWYgKG9yaWdpbmFsQ21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTKSB7XG5cdFx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBSZWNlaXZlZCBwYWNrZXQgZnJvbSAke3NyY0lwfTogJHttc2cudG9TdHJpbmcoJ2hleCcpfWApXG5cdFx0XHRcdH1cblx0XHRcdFx0dGhpcy5sb2dTdFBheWxvYWQoc3JjSXAsIG9yaWdpbmFsQ21kSWQsIG1zZywgc3RQYXlsb2FkKVxuXHRcdFx0XHRwZW5kaW5nLnJlc29sdmUobXNnKVxuXHRcdFx0fSBlbHNlIGlmIChvcmlnaW5hbENtZElkID09PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdFx0XHQvLyBVbnNvbGljaXRlZCBwdXNoIFx1MjAxNCBhbHdheXMgbG9nXG5cdFx0XHRcdHRoaXMubG9nU3RQYXlsb2FkKHNyY0lwLCBvcmlnaW5hbENtZElkLCBtc2csIHN0UGF5bG9hZClcblx0XHRcdH1cblx0XHRcdC8vIGVsc2U6IGR1cGxpY2F0ZSBtdWx0aWNhc3QgZGVsaXZlcnkgXHUyMDE0IHN1cHByZXNzXG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIE91dGdvaW5nIGNvbW1hbmQgZWNobyBvciB1bnNvbGljaXRlZCByZXF1ZXN0IGZyb20gZGV2aWNlXG5cdFx0XHR0aGlzLmxvZ1N0UGF5bG9hZChzcmNJcCwgb3JpZ2luYWxDbWRJZCwgbXNnLCBzdFBheWxvYWQpXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIERlY29kZXMgYW5kIGxvZ3MgYSBTdHVkaW8tVCByZXNwb25zZSBwYXlsb2FkLlxuXHQgKiBSZWNlaXZlcyBib3RoIHRoZSBmdWxsIG1zZyAoZm9yIHBhcnNlcnMgdGhhdCBuZWVkIHRoZSBTdHVkaW8tVCBoZWFkZXIpXG5cdCAqIGFuZCBzdFBheWxvYWQgKG1zZy5zdWJhcnJheSgyNCksIGZvciBkaXJlY3QgYnl0ZSBhY2Nlc3MpLlxuXHQgKlxuXHQgKiBzdFBheWxvYWQgbGF5b3V0OlxuXHQgKiAgIFswXSAgICAgIDB4NWEgIG1hZ2ljXG5cdCAqICAgWzFdICAgICAgY21kSWQgfCAweDgwXG5cdCAqICAgWzIuLi0yXSAgZGF0YSBieXRlc1xuXHQgKiAgIFstMV0gICAgIENSQy04L0RWQi1TMlxuXHQgKi9cblx0cHJpdmF0ZSBsb2dTdFBheWxvYWQoc3JjSXA6IHN0cmluZywgY21kSWQ6IG51bWJlciwgbXNnOiBCdWZmZXIsIHN0UGF5bG9hZDogQnVmZmVyKTogdm9pZCB7XG5cdFx0Y29uc3QgY21kTmFtZSA9IGdldENvbW1hbmROYW1lKGNtZElkKVxuXHRcdGNvbnN0IGRhdGEgPSBzdFBheWxvYWQuc3ViYXJyYXkoMiwgc3RQYXlsb2FkLmxlbmd0aCAtIDEpIC8vIHN0cmlwIG1hZ2ljK2NtZElkIGhlYWRlciBhbmQgQ1JDXG5cblx0XHQvLyBQYXlsb2FkIHN0cnVjdHVyZTogW2NtZDoweDhkXSBbZGF0YSBieXRlcy4uLl0gW2NyY11cblx0XHRjb25zdCByZXNwQ21kSWQgPSBzdFBheWxvYWRbMV1cblx0XHRjb25zdCBjcmMgPSBzdFBheWxvYWRbc3RQYXlsb2FkLmxlbmd0aCAtIDFdXG5cdFx0Y29uc3QgZnVsbFN0cnVjdHVyZSA9IGBbY21kOiR7dG9IZXgocmVzcENtZElkKX0gZGF0YToke2RhdGEudG9TdHJpbmcoJ2hleCcpfSBjcmM6JHt0b0hleChjcmMpfV1gXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX0dFVF9BTExfU0VUVElOR1MgKDB4MGEpIGFuZCBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gUGFyc2UgYWxsIHNldHRpbmdzLCBkaWZmIGFnYWluc3QgZGV2aWNlU3RhdGUsIGxvZyBjaGFuZ2VkIGF0IGluZm8gLyB1bmNoYW5nZWQgYXQgZGVidWcsXG5cdFx0Ly8gdGhlbiB1cGRhdGUgZGV2aWNlU3RhdGUuIENNRF9HRVRfQUxMX1NFVFRJTkdTIGFsc28gc2VydmVzIGFzIHRoZSBpbml0aWFsIHN0YXRlIHBvcHVsYXRpb24gb24gY29ubmVjdC5cblx0XHRpZiAoY21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTIHx8IGNtZElkID09PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdFx0aWYgKCF0aGlzLm1vZGVsKSB7XG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBzZXR0aW5ncyA9XG5cdFx0XHRcdFx0Y21kSWQgPT09IENNRF9TRVRUSU5HU19QVVNIXG5cdFx0XHRcdFx0XHQ/IHBhcnNlU2V0dGluZ3NSZXNwb25zZSh0aGlzLm1vZGVsLCBtc2cpXG5cdFx0XHRcdFx0XHQ6IHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbCh0aGlzLm1vZGVsLCBtc2cpXG5cblx0XHRcdFx0Y29uc3QgcHJldlN0YXRlID0gdGhpcy5kZXZpY2VTdGF0ZS5nZXQoc3JjSXApID8/IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KClcblx0XHRcdFx0Y29uc3QgbmV3U3RhdGUgPSBuZXcgTWFwPHN0cmluZywgbnVtYmVyPihwcmV2U3RhdGUpIC8vIGNvcHkgXHUyMDE0IHVwZGF0ZSBpbiBwbGFjZVxuXG5cdFx0XHRcdGZvciAoY29uc3QgcyBvZiBzZXR0aW5ncykge1xuXHRcdFx0XHRcdGNvbnN0IHN0YXRlS2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBzLmNtZF9pZCwgcy5pZCwgcy5idXNDaClcblx0XHRcdFx0XHQvLyBGb3IgUkdCIGNvbG9ycyAoMyBieXRlcyksIHBhY2sgaW50byBzaW5nbGUgbnVtYmVyOiAoUiA8PCAxNikgfCAoRyA8PCA4KSB8IEJcblx0XHRcdFx0XHRjb25zdCBuZXdWYWx1ZSA9XG5cdFx0XHRcdFx0XHRzLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAzXG5cdFx0XHRcdFx0XHRcdD8gKHMudmFsdWVCeXRlc1swXSA8PCAxNikgfCAocy52YWx1ZUJ5dGVzWzFdIDw8IDgpIHwgcy52YWx1ZUJ5dGVzWzJdXG5cdFx0XHRcdFx0XHRcdDogKHMudmFsdWVCeXRlc1swXSA/PyAwKVxuXHRcdFx0XHRcdGNvbnN0IHByZXZWYWx1ZSA9IHByZXZTdGF0ZS5nZXQoc3RhdGVLZXkpXG5cdFx0XHRcdFx0Y29uc3QgY2hhbmdlZCA9IHByZXZWYWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHByZXZWYWx1ZSAhPT0gbmV3VmFsdWVcblxuXHRcdFx0XHRcdG5ld1N0YXRlLnNldChzdGF0ZUtleSwgbmV3VmFsdWUpXG5cblx0XHRcdFx0XHRjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXRQYXJzZWRTZXR0aW5nKHMsIHRoaXMuYWN0aW9ucylcblx0XHRcdFx0XHRpZiAoY2hhbmdlZCkge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLmluZm8oYFJYICR7c3JjSXB9IHwgJHtmb3JtYXR0ZWR9YClcblx0XHRcdFx0XHRcdC8vIFRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlIFx1MjAxNCB1c2UgYmFzZSBrZXkgd2l0aG91dCBidXNDaCBzbyBpdCBtYXRjaGVzIHRoZSBmZWVkYmFjayBkZWZpbml0aW9uIElEXG5cdFx0XHRcdFx0XHRpZiAodGhpcy5mZWVkYmFja0NhbGxiYWNrKSB7XG5cdFx0XHRcdFx0XHRcdGxldCBiYXNlSWQgPSBzLmlkXG5cdFx0XHRcdFx0XHRcdGNvbnN0IGJhc2VBY3Rpb24gPSB0aGlzLmFjdGlvbnMuZmluZCgoYSkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdGlmIChhLmNtZF9pZCAhPT0gcy5jbWRfaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdFx0XHRcdGlmIChhLmlkID09PSBzLmlkKSByZXR1cm4gdHJ1ZVxuXHRcdFx0XHRcdFx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYS5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRcdFx0XHRcdGlmICghaWRBZGRPcHRpb24/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdFx0XHRcdGNvbnN0IG9mZnNldCA9IHMuaWQgLSBhLmlkXG5cdFx0XHRcdFx0XHRcdFx0cmV0dXJuIG9mZnNldCA+IDAgJiYgaWRBZGRPcHRpb24uY2hvaWNlcy5zb21lKChjKSA9PiBjLmlkID09PSBvZmZzZXQpXG5cdFx0XHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0XHRcdGlmIChiYXNlQWN0aW9uKSBiYXNlSWQgPSBiYXNlQWN0aW9uLmlkXG5cdFx0XHRcdFx0XHRcdGNvbnN0IGJhc2VGZWVkYmFja0tleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgcy5jbWRfaWQsIGJhc2VJZClcblx0XHRcdFx0XHRcdFx0dGhpcy5mZWVkYmFja0NhbGxiYWNrKGJhc2VGZWVkYmFja0tleSlcblx0XHRcdFx0XHRcdFx0dGhpcy5mZWVkYmFja0NhbGxiYWNrKGJhc2VGZWVkYmFja0tleSArICdfYm9vbCcpXG5cdFx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0XHRsb2dnZXIud2FybihgZmVlZGJhY2tDYWxsYmFjayBub3Qgc2V0IFx1MjAxNCBza2lwcGluZyBmZWVkYmFjayB1cGRhdGUgZm9yICR7c3RhdGVLZXl9YClcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCAke3NyY0lwfSB8ICR7Zm9ybWF0dGVkfWApXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdHRoaXMuZGV2aWNlU3RhdGUuc2V0KHNyY0lwLCBuZXdTdGF0ZSlcblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYFJYICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8IHBhcnNlIGZhaWxlZDogJHtlfSB8ICR7ZnVsbFN0cnVjdHVyZX1gKVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIEFsbCBvdGhlciBjb21tYW5kcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRjb25zdCBkZWNvZGVkID0gdGhpcy5kZWNvZGVTdERhdGEoY21kSWQsIGRhdGEpXG5cdFx0Ly8gQ01EX0JVU19HRVQgKGtlZXBhbGl2ZSkgaXMgaGlnaC1mcmVxdWVuY3kgbm9pc2UgXHUyMDE0IGxvZyBhdCBkZWJ1ZyBvbmx5XG5cdFx0Y29uc3QgbG9nRm4gPSBjbWRJZCA9PT0gQ01EX0JVU19HRVQgPyBsb2dnZXIuZGVidWcuYmluZChsb2dnZXIpIDogbG9nZ2VyLmluZm8uYmluZChsb2dnZXIpXG5cdFx0aWYgKGRlY29kZWQpIHtcblx0XHRcdGxvZ0ZuKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9IHwgJHtkZWNvZGVkfWApXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ0ZuKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogQXR0ZW1wdHMgdG8gZGVjb2RlIHRoZSBkYXRhIGJ5dGVzIG9mIGEgU3R1ZGlvLVQgcmVzcG9uc2UgaW50byBhXG5cdCAqIGh1bWFuLXJlYWRhYmxlIHN0cmluZy4gUmV0dXJucyBudWxsIHRvIGZhbGwgYmFjayB0byByYXcgaGV4LlxuXHQgKi9cblx0cHJpdmF0ZSBkZWNvZGVTdERhdGEoY21kSWQ6IG51bWJlciwgZGF0YTogQnVmZmVyKTogc3RyaW5nIHwgbnVsbCB7XG5cdFx0aWYgKGRhdGEubGVuZ3RoID09PSAwKSByZXR1cm4gJ0FDSydcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBDaGVjayBmb3Igc2luZ2xlLWJ5dGUgcmVzcG9uc2VzIChBQ0sgb3IgZXJyb3IpIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0aWYgKGRhdGFbMF0gPT09IDB4MDApIHtcblx0XHRcdFx0cmV0dXJuICdBQ0sgb2snXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRyZXR1cm4gYEVSUk9SICR7dG9IZXgoZGF0YVswXSl9YFxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdHN3aXRjaCAoY21kSWQpIHtcblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfTUlDX1BSRSAoMHgwMik6IHJhdyBwcmVhbXAgZWNobyBcdTIwMTQgcG9zaXRpb25hbCBieXRlcywgbm8gc2V0dGluZyBJRHMgXHUyNTAwXHUyNTAwXG5cdFx0XHQvLyBEZXZpY2UgZWNob2VzIFtidXNDaF1bdmFsMF1bdmFsMV0uLi4gY29uZmlybWluZyB0aGUgYXBwbGllZCB2YWx1ZXMuXG5cdFx0XHRjYXNlIENNRF9NSUNfUFJFOiB7XG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRjb25zdCB2YWxzID0gQXJyYXkuZnJvbShkYXRhLnN1YmFycmF5KDEpKVxuXHRcdFx0XHRcdC5tYXAoKGIsIGkpID0+IGBbJHtpfV09MHgke2IudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJyl9KCR7Yn0pYClcblx0XHRcdFx0XHQuam9pbignICcpXG5cdFx0XHRcdHJldHVybiBgY2g9JHtidXNDaH0gJHt2YWxzfWBcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9ERVZfU1BFQyAoMHgwZCk6IHNpbmdsZS1ieXRlIEFDSyBvciBlY2hvIG9mIGFwcGxpZWQgc2V0dGluZyBcdTI1MDBcdTI1MDBcblx0XHRcdC8vIERldmljZSBzZW5kcyB0d28gQ01EX0RFVl9TUEVDIHBhY2tldHMgaW4gcmVzcG9uc2UgdG8gYSBzZXQ6XG5cdFx0XHQvLyAgIDEuIEFDSzogIFtzdGF0dXNdICAgICAgICAgICAgICAgKDEgYnl0ZSwgMHgwMCA9IG9rKVxuXHRcdFx0Ly8gICAyLiBFY2hvOiBbYnVzQ2hdIFtzZXR0aW5nSWRdIFt2YWx1ZS4uLl0gIChjb25maXJtaW5nIHdoYXQgd2FzIGFwcGxpZWQpXG5cdFx0XHRjYXNlIENNRF9ERVZfU1BFQzoge1xuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPT09IDEpIHtcblx0XHRcdFx0XHRyZXR1cm4gZGF0YVswXSA9PT0gMHgwMCA/ICdBQ0sgb2snIDogYEFDSyBlcnI9JHt0b0hleChkYXRhWzBdKX1gXG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKGRhdGEubGVuZ3RoID49IDMpIHtcblx0XHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBkYXRhWzFdXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IGRhdGEuc3ViYXJyYXkoMilcblx0XHRcdFx0XHRjb25zdCBhY3Rpb24gPSB0aGlzLmFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IHNldHRpbmdJZClcblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nTmFtZSA9IGFjdGlvbj8ubmFtZSA/PyBgc2V0dGluZz0ke3RvSGV4KHNldHRpbmdJZCl9YFxuXHRcdFx0XHRcdGNvbnN0IGNob2ljZXMgPSBhY3Rpb24/Lm9wdGlvbnM/LlswXT8uY2hvaWNlc1xuXHRcdFx0XHRcdGNvbnN0IHZhbHVlTnVtID0gdmFsdWVCeXRlcy5sZW5ndGggPT09IDEgPyB2YWx1ZUJ5dGVzWzBdIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlTGFiZWwgPVxuXHRcdFx0XHRcdFx0Y2hvaWNlcyAmJiB2YWx1ZU51bSAhPT0gdW5kZWZpbmVkID8gY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSB2YWx1ZU51bSk/LmxhYmVsIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVTdHIgPSBjaG9pY2VMYWJlbCA/IGAke2Nob2ljZUxhYmVsfSAoJHt0b0hleCh2YWx1ZU51bSEpfSlgIDogYnl0ZXNUb0hleChBcnJheS5mcm9tKHZhbHVlQnl0ZXMpKVxuXHRcdFx0XHRcdGNvbnN0IHJhd1RhZyA9IGBbJHt0b0hleChjbWRJZCl9LyR7dG9IZXgoc2V0dGluZ0lkKX1dPSR7Ynl0ZXNUb0hleChBcnJheS5mcm9tKHZhbHVlQnl0ZXMpKX1gXG5cdFx0XHRcdFx0cmV0dXJuIGBlY2hvIGNoPSR7YnVzQ2h9IHwgJHtzZXR0aW5nTmFtZX06ICR7dmFsdWVTdHJ9ICR7cmF3VGFnfWBcblx0XHRcdFx0fVxuXHRcdFx0XHRyZXR1cm4gYHJhdzogJHtkYXRhLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHR9XG5cblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfTUlDX1BSRV9CVVMgKDB4MTIpOiBNdWx0aS1ieXRlIGVjaG8gcmVzcG9uc2VzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdFx0Y2FzZSBDTURfTUlDX1BSRV9CVVM6IHtcblx0XHRcdFx0Ly8gQWxyZWFkeSBoYW5kbGVkIHNpbmdsZS1ieXRlIGFib3ZlLCBzbyBtdWx0aS1ieXRlIG11c3QgYmUgZWNob1xuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPj0gMykge1xuXHRcdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGRhdGFbMV1cblx0XHRcdFx0XHRjb25zdCB2YWx1ZUJ5dGVzID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRcdGNvbnN0IGFjdGlvbiA9IHRoaXMuYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gc2V0dGluZ0lkKVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdOYW1lID0gYWN0aW9uPy5uYW1lID8/IGBzZXR0aW5nPSR7dG9IZXgoc2V0dGluZ0lkKX1gXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVOdW0gPSB2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSA/IHZhbHVlQnl0ZXNbMF0gOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VzID0gYWN0aW9uPy5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAndmFsdWUnKT8uY2hvaWNlc1xuXHRcdFx0XHRcdGNvbnN0IGNob2ljZUxhYmVsID1cblx0XHRcdFx0XHRcdGNob2ljZXMgJiYgdmFsdWVOdW0gIT09IHVuZGVmaW5lZCA/IGNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gdmFsdWVOdW0pPy5sYWJlbCA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlU3RyID0gY2hvaWNlTGFiZWwgPz8gYDB4JHt2YWx1ZUJ5dGVzLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHRcdFx0cmV0dXJuIGBlY2hvIGNoPSR7YnVzQ2h9IHwgJHtzZXR0aW5nTmFtZX06ICR7dmFsdWVTdHJ9YFxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBudWxsXG5cdFx0XHR9XG5cblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBCdXMtc2NvcGVkIGdldC9zZXQgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHRjYXNlIENNRF9CVVNfR0VUOlxuXHRcdFx0Y2FzZSBDTURfQlVTX1NFVDoge1xuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPCAyKSByZXR1cm4gbnVsbFxuXHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gZGF0YVsxXVxuXHRcdFx0XHRjb25zdCB2YWx1ZSA9IGRhdGEuc3ViYXJyYXkoMilcblx0XHRcdFx0cmV0dXJuIGBjaD0ke2J1c0NofSBzZXR0aW5nPSR7dG9IZXgoc2V0dGluZ0lkKX0gdmFsdWU9JHt2YWx1ZS50b1N0cmluZygnaGV4Jyl9YFxuXHRcdFx0fVxuXG5cdFx0XHRkZWZhdWx0OlxuXHRcdFx0XHRyZXR1cm4gbnVsbCAvLyBmYWxsIHRocm91Z2ggdG8gcmF3IGhleFxuXHRcdH1cblx0fVxuXG5cdHByaXZhdGUgc3RhdGljIGJ1aWxkVmFsdWVCeXRlcyh2YWx1ZTogdW5rbm93bik6IG51bWJlcltdIHtcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicpIHJldHVybiBbdmFsdWUgPyAxIDogMF1cblx0XHRpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHJldHVybiB2YWx1ZS5tYXAoKHYpID0+IE51bWJlcih2KSAmIDB4ZmYpXG5cdFx0aWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicpIHtcblx0XHRcdGlmICh2YWx1ZSA+IDB4ZmYpIHJldHVybiBbKHZhbHVlID4+IDE2KSAmIDB4ZmYsICh2YWx1ZSA+PiA4KSAmIDB4ZmYsIHZhbHVlICYgMHhmZl1cblx0XHRcdHJldHVybiBbdmFsdWUgJiAweGZmXVxuXHRcdH1cblx0XHR0aHJvdyBuZXcgRXJyb3IoYFVuc3VwcG9ydGVkIHZhbHVlIHR5cGUgZm9yIFNUY29udHJvbGxlcjogJHt2YWx1ZX1gKVxuXHR9XG5cblx0cHJpdmF0ZSBhc3luYyBidWlsZEhlYWRlcih0b3RhbExlbjogbnVtYmVyLCBkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0bGV0IG1hYyA9IHRoaXMubWFjQ2FjaGUuZ2V0KGRlc3RJcClcblx0XHRpZiAoIW1hYykge1xuXHRcdFx0bWFjID0gYXdhaXQgZ2V0TWFjRm9yRGVzdGluYXRpb24oZGVzdElwKVxuXHRcdFx0dGhpcy5tYWNDYWNoZS5zZXQoZGVzdElwLCBtYWMpXG5cdFx0fVxuXG5cdFx0cmV0dXJuIEJ1ZmZlci5jb25jYXQoW1xuXHRcdFx0QnVmZmVyLmZyb20oWzB4ZmYsIDB4ZmYsIDB4MDAsIHRvdGFsTGVuICYgMHhmZiwgMHgwNywgMHhlMSwgMHgwMCwgMHgwMCwgLi4ubWFjLCAweDAwLCAweDAwXSksXG5cdFx0XHRCdWZmZXIuZnJvbSgnU3R1ZGlvLVQnLCAndXRmOCcpLFxuXHRcdF0pXG5cdH1cblxuXHRwcml2YXRlIHN0YXRpYyBjcmM4RHZiUzIoZGF0YTogbnVtYmVyW10pOiBudW1iZXIge1xuXHRcdGxldCBjcmMgPSAwXG5cdFx0Zm9yIChjb25zdCBiIG9mIGRhdGEpIHtcblx0XHRcdGNyYyBePSBiXG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IDg7IGkrKykge1xuXHRcdFx0XHRjcmMgPSAoY3JjICYgMHg4MCkgIT09IDAgPyAoKGNyYyA8PCAxKSBeIDB4ZDUpICYgMHhmZiA6IChjcmMgPDwgMSkgJiAweGZmXG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiBjcmNcblx0fVxuXG5cdC8qKlxuXHQgKiBSZXR1cm5zIHRoZSBjdXJyZW50IGtub3duIHZhbHVlIGZvciBhIHNldHRpbmcgb24gYSBkZXZpY2UsIG9yIHVuZGVmaW5lZCBpZiB1bmtub3duLlxuXHQgKiBVc2UgZm9yIGZlZWRiYWNrcyBcdTIwMTQgdmFsdWUgaXMgdXBkYXRlZCBvbiBldmVyeSBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikgZnJvbSB0aGUgZGV2aWNlLlxuXHQgKlxuXHQgKiBAcGFyYW0gaXAgICAgICAgIERldmljZSBJUCBhZGRyZXNzXG5cdCAqIEBwYXJhbSBjbWRJZCAgICAgQ29tbWFuZCBJRCAoZS5nLiBDTURfREVWX1NQRUMpXG5cdCAqIEBwYXJhbSBzZXR0aW5nSWQgU2V0dGluZyBJRCAoZS5nLiAweDAyIGZvciBDb250cm9sIFNvdXJjZSlcblx0ICogQHBhcmFtIGJ1c0NoICAgICBPcHRpb25hbCBidXMvY2hhbm5lbCBJRCBmb3IgbXVsdGktY2hhbm5lbCBjb21tYW5kc1xuXHQgKi9cblx0cHVibGljIGdldFNldHRpbmdWYWx1ZShpcDogc3RyaW5nLCBjbWRJZDogbnVtYmVyLCBzZXR0aW5nSWQ6IG51bWJlciwgYnVzQ2g/OiBudW1iZXIpOiBudW1iZXIgfCB1bmRlZmluZWQge1xuXHRcdGNvbnN0IGtleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgY21kSWQsIHNldHRpbmdJZCwgYnVzQ2gpXG5cdFx0cmV0dXJuIHRoaXMuZGV2aWNlU3RhdGUuZ2V0KGlwKT8uZ2V0KGtleSlcblx0fVxuXG5cdHB1YmxpYyBhc3luYyByZXNldERldmljZShkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0cmV0dXJuIHRoaXMuc2VuZEF3YWl0QWNrKENNRF9SRVNFVF9ERVZJQ0UsIHVuZGVmaW5lZCwgMHgwMCwgdW5kZWZpbmVkLCBkZXN0SXAsIGZhbHNlKVxuXHR9XG5cblx0cHVibGljIGFzeW5jIGdsb2JhbE1pY0tpbGwoZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdHJldHVybiB0aGlzLnNlbmRBd2FpdEFjayhDTURfR0xPQkFMX01JQ19LSUxMLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBkZXN0SXAsIGZhbHNlKVxuXHR9XG59XG4iLCAiaW1wb3J0IGRncmFtIGZyb20gJ2RncmFtJ1xuaW1wb3J0IG9zIGZyb20gJ29zJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignRGFudGUnKVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgRGFudGUgZGlzY292ZXJ5IGNvbnN0YW50cyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuLyoqIERhbnRlIGRldmljZSBpbmZvIHJlcXVlc3QgbWVzc2FnZSB0eXBlIChzZW50IHRvIHBvcnQgODcwMCkgKi9cbmNvbnN0IERBTlRFX01TR19JTkZPX1JFUVVFU1QgPSAweDAwMjBcbi8qKiBEYW50ZSBkZXZpY2UgaW5mbyByZXNwb25zZSBtZXNzYWdlIHR5cGUgKHJlY2VpdmVkIG9uIHBvcnQgODcwMikgKi9cbmV4cG9ydCBjb25zdCBEQU5URV9NU0dfSU5GT19SRVNQT05TRSA9IDB4MDE3MFxuY29uc3QgREFOVEVfSU5GT19NSU5fTEVOID0gMHhjYyArIDY0IC8vIDI2OCBieXRlcyBcdTIwMTQgbmVlZCBmdWxsIG1vZGVsIGZpZWxkXG5cbmZ1bmN0aW9uIGJ1aWxkRGFudGVJbmZvUmVxdWVzdCgpOiBCdWZmZXIge1xuXHRjb25zdCBidWYgPSBCdWZmZXIuYWxsb2MoMzIsIDApXG5cdGNvbnN0IHNlcSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDB4ZmZmZilcblxuXHRidWYud3JpdGVVSW50MTZCRSgweGZmZmYsIDApXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKERBTlRFX01TR19JTkZPX1JFUVVFU1QsIDIpXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKHNlcSwgNClcblxuXHRjb25zdCBtYWMgPSBnZXRGaXJzdExvY2FsTWFjKClcblx0bWFjLmNvcHkoYnVmLCA4KVxuXG5cdEJ1ZmZlci5mcm9tKCdBdWRpbmF0ZScsICdhc2NpaScpLmNvcHkoYnVmLCAxNilcblx0YnVmLndyaXRlVUludDE2QkUoMHgwNzM5LCAyNClcblx0YnVmLndyaXRlVUludDE2QkUoMHgwMGMxLCAyNilcblx0YnVmLndyaXRlVUludDMyQkUoMHgwMDBmNDI0MCwgMjgpXG5cblx0cmV0dXJuIGJ1ZlxufVxuXG4vKiogUmV0dXJucyB0aGUgZmlyc3Qgbm9uLWxvb3BiYWNrIE1BQyBhcyBhIDYtYnl0ZSBCdWZmZXIsIG9yIHplcm9zLiAqL1xuZnVuY3Rpb24gZ2V0Rmlyc3RMb2NhbE1hYygpOiBCdWZmZXIge1xuXHR0cnkge1xuXHRcdGNvbnN0IGlmYWNlcyA9IG9zLm5ldHdvcmtJbnRlcmZhY2VzKClcblx0XHRmb3IgKGNvbnN0IG5hbWUgb2YgT2JqZWN0LmtleXMoaWZhY2VzKSkge1xuXHRcdFx0Zm9yIChjb25zdCBhZGRyIG9mIGlmYWNlc1tuYW1lXSA/PyBbXSkge1xuXHRcdFx0XHRpZiAoIWFkZHIuaW50ZXJuYWwgJiYgYWRkci5mYW1pbHkgPT09ICdJUHY0JyAmJiBhZGRyLm1hYyAmJiBhZGRyLm1hYyAhPT0gJzAwOjAwOjAwOjAwOjAwOjAwJykge1xuXHRcdFx0XHRcdHJldHVybiBCdWZmZXIuZnJvbShhZGRyLm1hYy5zcGxpdCgnOicpLm1hcCgoaDogc3RyaW5nKSA9PiBwYXJzZUludChoLCAxNikpKVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHR9IGNhdGNoIHtcblx0XHQvKiBpZ25vcmUgKi9cblx0fVxuXHRyZXR1cm4gQnVmZmVyLmFsbG9jKDYsIDApXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZURhbnRlSW5mb1Jlc3BvbnNlKG1zZzogQnVmZmVyLCBzcmNJcDogc3RyaW5nKTogRGV2aWNlSW5mbyB8IG51bGwge1xuXHRpZiAobXNnLmxlbmd0aCA8IERBTlRFX0lORk9fTUlOX0xFTikgcmV0dXJuIG51bGxcblx0aWYgKG1zZy5yZWFkVUludDE2QkUoMCkgIT09IDB4ZmZmZikgcmV0dXJuIG51bGxcblx0aWYgKG1zZy5yZWFkVUludDE2QkUoMikgIT09IERBTlRFX01TR19JTkZPX1JFU1BPTlNFKSByZXR1cm4gbnVsbFxuXHRpZiAobXNnLnN1YmFycmF5KDE2LCAyNCkudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdBdWRpbmF0ZScpIHJldHVybiBudWxsXG5cblx0Y29uc3QgcmVhZFN0ciA9IChvZmZzZXQ6IG51bWJlciwgbGVuOiBudW1iZXIpOiBzdHJpbmcgPT5cblx0XHRtc2dcblx0XHRcdC5zdWJhcnJheShvZmZzZXQsIG9mZnNldCArIGxlbilcblx0XHRcdC50b1N0cmluZygnYXNjaWknKVxuXHRcdFx0LnNwbGl0KCdcXDAnKVswXVxuXHRcdFx0LnRyaW0oKVxuXG5cdGNvbnN0IGV1aTY0ID0gbXNnLnN1YmFycmF5KDgsIDE2KVxuXHRjb25zdCBtYWNCeXRlcyA9IFtldWk2NFswXSwgZXVpNjRbMV0sIGV1aTY0WzJdLCBldWk2NFs1XSwgZXVpNjRbNl0sIGV1aTY0WzddXVxuXHRjb25zdCBtYWMgPSBtYWNCeXRlcy5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpLmpvaW4oJzonKVxuXG5cdGNvbnN0IG5hbWUgPSByZWFkU3RyKDB4MjAsIDMxKSAvLyBEYW50ZSBkZXZpY2UgbGFiZWwgKGNhbiBiZSB1cCB0byAzMSBjaGFycyBwZXIgRGFudGUgc3BlYylcblx0Y29uc3QgbWFudWZhY3R1cmVyID0gcmVhZFN0cigweDRjLCA2NCkgLy8gZS5nLiBcIlN0dWRpbyBUZWNobm9sb2dpZXMsIEluYy5cIlxuXHRjb25zdCBtb2RlbFJhdyA9IHJlYWRTdHIoMHhjYywgNjQpXG5cdGNvbnN0IGRhbnRlRmlybXdhcmUgPSBgJHttc2dbMHgxOF19LiR7bXNnWzB4MTldfWBcblxuXHRpZiAoIW1vZGVsUmF3KSByZXR1cm4gbnVsbFxuXG5cdC8vIEV4dHJhY3QganVzdCB0aGUgbW9kZWwgbnVtYmVyL2NvZGUgKGUuZy4gXCJNb2RlbCAzOTEgQWxlcnRpbmcgVW5pdFwiIFx1MjE5MiBcIjM5MVwiKVxuXHQvLyBTdHJpcCBcIk1vZGVsIFwiIHByZWZpeCwgdGhlbiB0YWtlIG9ubHkgdGhlIGZpcnN0IHdvcmQgKHRoZSBtb2RlbCBudW1iZXIpXG5cdGNvbnN0IG1vZGVsID0gbW9kZWxSYXdcblx0XHQucmVwbGFjZSgvXk1vZGVsXFxzKy9pLCAnJylcblx0XHQudHJpbSgpXG5cdFx0LnNwbGl0KC9cXHMrLylbMF1cblxuXHRyZXR1cm4ge1xuXHRcdGlwOiBzcmNJcCxcblx0XHRuYW1lLFxuXHRcdG1hbnVmYWN0dXJlcixcblx0XHRtb2RlbCxcblx0XHRtb2RlbE5hbWU6IG1vZGVsUmF3LCAvLyBGdWxsIG1vZGVsIGRlc2NyaXB0aW9uXG5cdFx0bWFjLFxuXHRcdGRhbnRlRmlybXdhcmUsXG5cdH1cbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBNQUMgYWRkcmVzcyBieXRlcyBvZiB0aGUgbG9jYWwgaW50ZXJmYWNlIHVzZWQgdG8gcm91dGUgdG8gZGVzdElwLlxuICogVXNlcyBhIHRlbXBvcmFyeSBVRFAgY29ubmVjdCB0byBsZXQgdGhlIE9TIHNlbGVjdCB0aGUgb3V0Z29pbmcgaW50ZXJmYWNlLFxuICogdGhlbiBmaW5kcyB0aGUgbWF0Y2hpbmcgTUFDIGZyb20gb3MubmV0d29ya0ludGVyZmFjZXMoKS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1hY0ZvckRlc3RpbmF0aW9uKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxudW1iZXJbXT4ge1xuXHRyZXR1cm4gbmV3IFByb21pc2U8bnVtYmVyW10+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRjb25zdCB0bXAgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoJ3VkcDQnKVxuXG5cdFx0dG1wLm9uY2UoJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdHJlamVjdChuZXcgRXJyb3IoZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVycikpKVxuXHRcdH0pXG5cblx0XHR0bXAuY29ubmVjdCg5LCBkZXN0SXAsICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IGFkZHIgPSB0bXAuYWRkcmVzcygpIGFzIHsgYWRkcmVzczogc3RyaW5nIH1cblx0XHRcdFx0Y29uc3QgbG9jYWxBZGRyID0gYWRkci5hZGRyZXNzXG5cdFx0XHRcdHRtcC5jbG9zZSgpXG5cblx0XHRcdFx0Y29uc3QgaWZhY2VzID0gb3MubmV0d29ya0ludGVyZmFjZXMoKVxuXHRcdFx0XHRmb3IgKGNvbnN0IG5hbWUgb2YgT2JqZWN0LmtleXMoaWZhY2VzKSkge1xuXHRcdFx0XHRcdGZvciAoY29uc3QgaWZhY2Ugb2YgaWZhY2VzW25hbWVdID8/IFtdKSB7XG5cdFx0XHRcdFx0XHRpZiAoXG5cdFx0XHRcdFx0XHRcdGlmYWNlLmZhbWlseSA9PT0gJ0lQdjQnICYmXG5cdFx0XHRcdFx0XHRcdGlmYWNlLmFkZHJlc3MgPT09IGxvY2FsQWRkciAmJlxuXHRcdFx0XHRcdFx0XHRpZmFjZS5tYWMgJiZcblx0XHRcdFx0XHRcdFx0aWZhY2UubWFjICE9PSAnMDA6MDA6MDA6MDA6MDA6MDAnXG5cdFx0XHRcdFx0XHQpIHtcblx0XHRcdFx0XHRcdFx0cmV0dXJuIHJlc29sdmUoaWZhY2UubWFjLnNwbGl0KCc6JykubWFwKChiKSA9PiBwYXJzZUludChiLCAxNikgJiAweGZmKSlcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihgTm8gaW50ZXJmYWNlIGZvdW5kIGZvciBsb2NhbCBhZGRyZXNzICR7bG9jYWxBZGRyfWApKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihTdHJpbmcoX2UpKSlcblx0XHRcdH1cblx0XHR9KVxuXHR9KVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGxvY2FsIElQIGFkZHJlc3MgdXNlZCBieSB0aGUgT1MgdG8gcm91dGUgdG8gZGVzdElwLlxuICogVXNlcyBhIHRlbXBvcmFyeSBVRFAgc29ja2V0IGNvbm5lY3QgdG8gbGV0IHRoZSBPUyBzZWxlY3QgdGhlIG91dGdvaW5nIGludGVyZmFjZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcblx0cmV0dXJuIG5ldyBQcm9taXNlPHN0cmluZz4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGNvbnN0IHRtcCA9IGRncmFtLmNyZWF0ZVNvY2tldCgndWRwNCcpXG5cblx0XHRsZXQgcmVzb2x2ZWQgPSBmYWxzZVxuXHRcdHRtcC5vbmNlKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGlmICghcmVzb2x2ZWQpIHtcblx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVycikpKVxuXHRcdFx0fVxuXHRcdH0pXG5cblx0XHQvLyBVc2UgYW4gYXJiaXRyYXJ5IHBvcnQgZm9yIGNvbm5lY3Q7IHdlIG9ubHkgbmVlZCB0aGUga2VybmVsIHRvIGFzc2lnbiBhIGxvY2FsIGFkZHJlc3MuXG5cdFx0dG1wLmNvbm5lY3QoOSwgZGVzdElwLCAoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBhZGRyID0gdG1wLmFkZHJlc3MoKSBhcyB7IGFkZHJlc3M6IHN0cmluZyB9XG5cdFx0XHRcdGNvbnN0IGxvY2FsQWRkciA9IGFkZHIuYWRkcmVzc1xuXHRcdFx0XHRpZiAoIXJlc29sdmVkKSB7XG5cdFx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0XHRyZXNvbHZlKGxvY2FsQWRkcilcblx0XHRcdFx0fVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0aWYgKCFyZXNvbHZlZCkge1xuXHRcdFx0XHRcdHJlc29sdmVkID0gdHJ1ZVxuXHRcdFx0XHRcdHRtcC5jbG9zZSgpXG5cdFx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihTdHJpbmcoX2UpKSlcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0pXG59XG5cbi8qKlxuICogTGlzdGVucyBmb3IgRGFudGUgZGV2aWNlIGFubm91bmNlcyBvbiB0aGUgbG9jYWwgbmV0d29yayBhbmQgc2VuZHMgdW5pY2FzdFxuICogaW5mbyByZXF1ZXN0cyB0byBlYWNoIGRpc2NvdmVyZWQgSVAuIFJlc3BvbnNlcyBhcnJpdmUgb24gdGhlIGNhbGxlcidzIHJ4U29ja2V0XG4gKiB2aWEgaGFuZGxlSW5jb21pbmcoKSBcdTIxOTIgZGlzY292ZXJ5TGlzdGVuZXJzLlxuICpcbiAqIEBwYXJhbSB0eFNvY2tldCAtIFRoZSBzb2NrZXQgdG8gdXNlIGZvciBzZW5kaW5nIGRpc2NvdmVyeSByZXF1ZXN0c1xuICogQHBhcmFtIGVuc3VyZU1lbWJlcnNoaXAgLSBDYWxsYmFjayB0byBlbnN1cmUgbXVsdGljYXN0IG1lbWJlcnNoaXAgYmVmb3JlIHF1ZXJ5aW5nXG4gKiBAcGFyYW0gdGltZW91dE1zIC0gSG93IGxvbmcgdG8gbGlzdGVuIGZvciBhbm5vdW5jZXMgYmVmb3JlIHJlc29sdmluZ1xuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGlzY292ZXJEZXZpY2VzKFxuXHR0eFNvY2tldDogZGdyYW0uU29ja2V0LFxuXHRlbnN1cmVNZW1iZXJzaGlwOiAoZGVzdElwOiBzdHJpbmcpID0+IFByb21pc2U8dm9pZD4sXG5cdHRpbWVvdXRNcyA9IDUwMDAsXG4pOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3QgREFOVEVfQU5OT1VOQ0VfR1JPVVAgPSAnMjI0LjAuMC4yMzMnXG5cdGNvbnN0IERBTlRFX0FOTk9VTkNFX1BPUlQgPSA4NzA4XG5cdGNvbnN0IERFRkFVTFRfUE9SVCA9IDg3MDBcblxuXHRjb25zdCBxdWVyaWVkSXBzID0gbmV3IFNldDxzdHJpbmc+KClcblxuXHRyZXR1cm4gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUpID0+IHtcblx0XHRjb25zdCBhbm5vdW5jZVNvY2tldCA9IGRncmFtLmNyZWF0ZVNvY2tldCh7IHR5cGU6ICd1ZHA0JywgcmV1c2VBZGRyOiB0cnVlIH0pXG5cdFx0Y29uc3Qgam9pbmVkSW50ZXJmYWNlczogc3RyaW5nW10gPSBbXVxuXG5cdFx0Y29uc3QgY2xlYW51cCA9ICgpID0+IHtcblx0XHRcdGZvciAoY29uc3QgaWZhY2Ugb2Ygam9pbmVkSW50ZXJmYWNlcykge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGFubm91bmNlU29ja2V0LmRyb3BNZW1iZXJzaGlwKERBTlRFX0FOTk9VTkNFX0dST1VQLCBpZmFjZSlcblx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGFubm91bmNlU29ja2V0LmNsb3NlKClcblx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdH1cblx0XHRcdHJlc29sdmUoKVxuXHRcdH1cblxuXHRcdGNvbnN0IHRpbWVyID0gc2V0VGltZW91dChjbGVhbnVwLCB0aW1lb3V0TXMpXG5cdFx0dGltZXIudW5yZWY/LigpXG5cblx0XHRhbm5vdW5jZVNvY2tldC5vbignZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHRsb2dnZXIud2FybihgQW5ub3VuY2Ugc29ja2V0IGVycm9yOiAke2Vyci5tZXNzYWdlfWApXG5cdFx0fSlcblxuXHRcdGFubm91bmNlU29ja2V0Lm9uKCdtZXNzYWdlJywgKG1zZywgcmluZm8pID0+IHtcblx0XHRcdGNvbnN0IHNyY0lwID0gcmluZm8uYWRkcmVzc1xuXHRcdFx0Ly8gVmFsaWRhdGUgaXQncyBhIERhbnRlIGFubm91bmNlIChtYWdpYyAweGZmZmUgKyBcIkF1ZGluYXRlXCIgYXQgb2Zmc2V0IDE2KVxuXHRcdFx0aWYgKG1zZy5sZW5ndGggPCAyNCkgcmV0dXJuXG5cdFx0XHRpZiAobXNnLnJlYWRVSW50MTZCRSgwKSAhPT0gMHhmZmZlKSByZXR1cm5cblx0XHRcdGlmIChtc2cuc3ViYXJyYXkoMTYsIDI0KS50b1N0cmluZygnYXNjaWknKSAhPT0gJ0F1ZGluYXRlJykgcmV0dXJuXG5cblx0XHRcdGlmIChxdWVyaWVkSXBzLmhhcyhzcmNJcCkpIHJldHVyblxuXHRcdFx0cXVlcmllZElwcy5hZGQoc3JjSXApXG5cdFx0XHRsb2dnZXIuZGVidWcoYEFubm91bmNlIGZyb20gJHtzcmNJcH0gXHUyMDE0IHNlbmRpbmcgdW5pY2FzdCBxdWVyeWApXG5cblx0XHRcdC8vIEpvaW4gMjI0LjAuMC4yMzEgb24gdGhlIGludGVyZmFjZSB0aGF0IHJvdXRlcyB0byB0aGlzIGRldmljZSBCRUZPUkUgc2VuZGluZ1xuXHRcdFx0Ly8gdGhlIHF1ZXJ5LiBUaGUgZGV2aWNlIG11bHRpY2FzdHMgaXRzIDB4MDE3MCByZXNwb25zZSB0byAyMjQuMC4wLjIzMTo4NzAyXG5cdFx0XHQvLyBpbiBhZGRpdGlvbiB0byB1bmljYXN0aW5nIGl0IFx1MjAxNCByeFNvY2tldCBtdXN0IGJlIGEgbWVtYmVyIHRvIHJlY2VpdmUgaXQuXG5cdFx0XHRjb25zdCBzZW5kUXVlcnkgPSBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdGF3YWl0IGVuc3VyZU1lbWJlcnNoaXAoc3JjSXApXG5cdFx0XHRcdGNvbnN0IHF1ZXJ5ID0gYnVpbGREYW50ZUluZm9SZXF1ZXN0KClcblx0XHRcdFx0dHhTb2NrZXQuc2VuZChxdWVyeSwgREVGQVVMVF9QT1JULCBzcmNJcCwgKGVycikgPT4ge1xuXHRcdFx0XHRcdGlmIChlcnIpIGxvZ2dlci53YXJuKGBVbmljYXN0IHF1ZXJ5IHRvICR7c3JjSXB9IGZhaWxlZDogJHtlcnIubWVzc2FnZX1gKVxuXHRcdFx0XHR9KVxuXHRcdFx0fVxuXHRcdFx0c2VuZFF1ZXJ5KCkuY2F0Y2goKGVycikgPT4gbG9nZ2VyLndhcm4oYFF1ZXJ5IHNldHVwIGZhaWxlZDogJHtlcnJ9YCkpXG5cdFx0fSlcblxuXHRcdGFubm91bmNlU29ja2V0LmJpbmQoREFOVEVfQU5OT1VOQ0VfUE9SVCwgKCkgPT4ge1xuXHRcdFx0Ly8gSm9pbiAyMjQuMC4wLjIzMyBvbiBldmVyeSBub24tbG9vcGJhY2sgSVB2NCBpbnRlcmZhY2Ugc28gdGhhdCBhbm5vdW5jZXNcblx0XHRcdC8vIGFyZSByZWNlaXZlZCByZWdhcmRsZXNzIG9mIHdoaWNoIGludGVyZmFjZSB0aGUgZGV2aWNlIGlzIG9uLlxuXHRcdFx0Ly8gT24gV2luZG93cyB3aXRoIG11bHRpcGxlIGludGVyZmFjZXMgKGUuZy4gSHlwZXItViArIExBTiksIHRoZSBPUyBkZWZhdWx0XG5cdFx0XHQvLyBtdWx0aWNhc3QgaW50ZXJmYWNlIG1heSBub3QgYmUgdGhlIG9uZSBjb25uZWN0ZWQgdG8gdGhlIERhbnRlIG5ldHdvcmsuXG5cdFx0XHRjb25zdCBpZmFjZXMgPSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpXG5cdFx0XHRmb3IgKGNvbnN0IGFkZHJzIG9mIE9iamVjdC52YWx1ZXMoaWZhY2VzKSkge1xuXHRcdFx0XHRmb3IgKGNvbnN0IGFkZHIgb2YgYWRkcnMgPz8gW10pIHtcblx0XHRcdFx0XHRpZiAoYWRkci5mYW1pbHkgPT09ICdJUHY0JyAmJiAhYWRkci5pbnRlcm5hbCkge1xuXHRcdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuYWRkTWVtYmVyc2hpcChEQU5URV9BTk5PVU5DRV9HUk9VUCwgYWRkci5hZGRyZXNzKVxuXHRcdFx0XHRcdFx0XHRqb2luZWRJbnRlcmZhY2VzLnB1c2goYWRkci5hZGRyZXNzKVxuXHRcdFx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0XHRcdC8qIGlnbm9yZSBcdTIwMTQgaW50ZXJmYWNlIG1heSBub3Qgc3VwcG9ydCBtdWx0aWNhc3QgKi9cblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGlmIChqb2luZWRJbnRlcmZhY2VzLmxlbmd0aCA9PT0gMCkge1xuXHRcdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IGpvaW4gYW5ub3VuY2UgbXVsdGljYXN0IGdyb3VwIG9uIGFueSBpbnRlcmZhY2VgKVxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBMaXN0ZW5pbmcgZm9yIERhbnRlIGFubm91bmNlcyBvbiAke0RBTlRFX0FOTk9VTkNFX0dST1VQfToke0RBTlRFX0FOTk9VTkNFX1BPUlR9YClcblx0XHRcdH1cblx0XHR9KVxuXHR9KVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgRGV2aWNlIHByb2JlIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG4vKipcbiAqIFNlbmRzIGEgdW5pY2FzdCBEYW50ZSBpbmZvIHJlcXVlc3QgdG8gYSBzcGVjaWZpYyBJUCBhbmQgd2FpdHMgZm9yIHRoZSBkZXZpY2UgaW5mb1xuICogcmVzcG9uc2UuIFVzZWQgdG8gdmVyaWZ5IGEgbWFudWFsbHkgY29uZmlndXJlZCBJUC5cbiAqXG4gKiBAcGFyYW0gdHhTb2NrZXQgICAgICAgICBCb3VuZCBzb2NrZXQgdG8gc2VuZCB0aGUgcXVlcnkgZnJvbVxuICogQHBhcmFtIHJlZ2lzdGVyTGlzdGVuZXIgUmVnaXN0ZXIgYSBjYWxsYmFjayAoa2V5ZWQpIHRvIHJlY2VpdmUgcGFyc2VkIERldmljZUluZm8gcmVzcG9uc2VzXG4gKiBAcGFyYW0gcmVtb3ZlTGlzdGVuZXIgICBSZW1vdmUgYSBwcmV2aW91c2x5IHJlZ2lzdGVyZWQgbGlzdGVuZXIgYnkga2V5XG4gKiBAcGFyYW0gZW5zdXJlTWVtYmVyc2hpcCBFbnN1cmUgbXVsdGljYXN0IG1lbWJlcnNoaXAgb24gdGhlIG91dGdvaW5nIGludGVyZmFjZVxuICogQHBhcmFtIGlwICAgICAgICAgICAgICAgVGFyZ2V0IGRldmljZSBJUFxuICogQHBhcmFtIHRpbWVvdXRNcyAgICAgICAgVGltZW91dCBpbiBtaWxsaXNlY29uZHNcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHByb2JlRGV2aWNlKFxuXHR0eFNvY2tldDogZGdyYW0uU29ja2V0LFxuXHRyZWdpc3Rlckxpc3RlbmVyOiAoa2V5OiBzdHJpbmcsIGNiOiAoZGV2aWNlOiBEZXZpY2VJbmZvKSA9PiB2b2lkKSA9PiB2b2lkLFxuXHRyZW1vdmVMaXN0ZW5lcjogKGtleTogc3RyaW5nKSA9PiB2b2lkLFxuXHRlbnN1cmVNZW1iZXJzaGlwOiAoaXA6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPixcblx0aXA6IHN0cmluZyxcblx0dGltZW91dE1zID0gMzAwMCxcbik6IFByb21pc2U8RGV2aWNlSW5mbyB8IG51bGw+IHtcblx0cmV0dXJuIG5ldyBQcm9taXNlPERldmljZUluZm8gfCBudWxsPigocmVzb2x2ZSkgPT4ge1xuXHRcdGNvbnN0IGtleSA9IGBfX3Byb2JlXyR7aXB9X19gXG5cdFx0bGV0IHJlc29sdmVkID0gZmFsc2VcblxuXHRcdGNvbnN0IGZpbmlzaCA9IChyZXN1bHQ6IERldmljZUluZm8gfCBudWxsKSA9PiB7XG5cdFx0XHRpZiAocmVzb2x2ZWQpIHJldHVyblxuXHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRyZW1vdmVMaXN0ZW5lcihrZXkpXG5cdFx0XHRyZXNvbHZlKHJlc3VsdClcblx0XHR9XG5cblx0XHRyZWdpc3Rlckxpc3RlbmVyKGtleSwgKGRldmljZTogRGV2aWNlSW5mbykgPT4ge1xuXHRcdFx0aWYgKGRldmljZS5pcCA9PT0gaXApIGZpbmlzaChkZXZpY2UpXG5cdFx0fSlcblxuXHRcdGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiBmaW5pc2gobnVsbCksIHRpbWVvdXRNcylcblx0XHR0aW1lci51bnJlZj8uKClcblxuXHRcdGNvbnN0IHJ1biA9IGFzeW5jICgpID0+IHtcblx0XHRcdGF3YWl0IGVuc3VyZU1lbWJlcnNoaXAoaXApXG5cdFx0XHRjb25zdCBxdWVyeSA9IGJ1aWxkRGFudGVJbmZvUmVxdWVzdCgpXG5cdFx0XHR0eFNvY2tldC5zZW5kKHF1ZXJ5LCA4NzAwLCBpcCwgKGVycikgPT4ge1xuXHRcdFx0XHRpZiAoZXJyKSB7XG5cdFx0XHRcdFx0bG9nZ2VyLndhcm4oYFByb2JlIHRvICR7aXB9IGZhaWxlZDogJHtlcnIubWVzc2FnZX1gKVxuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRmaW5pc2gobnVsbClcblx0XHRcdFx0fVxuXHRcdFx0fSlcblx0XHR9XG5cblx0XHRydW4oKS5jYXRjaCgoZSkgPT4ge1xuXHRcdFx0bG9nZ2VyLndhcm4oYHByb2JlRGV2aWNlIHNldHVwIGZhaWxlZCBmb3IgJHtpcH06ICR7ZX1gKVxuXHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0ZmluaXNoKG51bGwpXG5cdFx0fSlcblx0fSlcbn1cbiIsICJpbXBvcnQgZGdyYW0gZnJvbSAnZGdyYW0nXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHsgZ2V0TWFjRm9yRGVzdGluYXRpb24sIGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uIH0gZnJvbSAnLi9kYW50ZS5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdDb25Nb24nKVxuXG4vKiogQ29hbGVzY2VzIGNvbmN1cnJlbnQgb3BlbkNvbk1vblNlc3Npb24gY2FsbHMgcGVyIElQICovXG5jb25zdCBfY29ubW9uUGVuZGluZyA9IG5ldyBNYXA8c3RyaW5nLCBQcm9taXNlPCgoKSA9PiB2b2lkKSB8IG51bGw+PigpXG5cbi8qKlxuICogT3BlbnMgYSBEYW50ZSBDb25Nb24gc2Vzc2lvbiB3aXRoIHRoZSBkZXZpY2Ugb24gcG9ydCA4ODAwLlxuICogT25seSBuZWVkZWQgZm9yIGRldmljZXMgd2l0aCBcInVzZUNvbk1vblwiOiB0cnVlIGluIHRoZWlyIGRldmljZSBKU09OLlxuICogUmV0dXJucyBhIGNsZWFudXAgZnVuY3Rpb24gdG8gc3RvcCBrZWVwYWxpdmVzIGFuZCBjbG9zZSB0aGUgc29ja2V0LCBvciBudWxsIG9uIGZhaWx1cmUuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBvcGVuQ29uTW9uU2Vzc2lvbihkZXZpY2VJcDogc3RyaW5nLCB0aW1lb3V0TXMgPSAzMDAwKTogUHJvbWlzZTwoKCkgPT4gdm9pZCkgfCBudWxsPiB7XG5cdGNvbnN0IHBlbmRpbmcgPSBfY29ubW9uUGVuZGluZy5nZXQoZGV2aWNlSXApXG5cdGlmIChwZW5kaW5nKSByZXR1cm4gcGVuZGluZ1xuXG5cdGNvbnN0IHByb21pc2UgPSBfZG9Db25Nb25TZXNzaW9uKGRldmljZUlwLCB0aW1lb3V0TXMpLmZpbmFsbHkoKCkgPT4ge1xuXHRcdF9jb25tb25QZW5kaW5nLmRlbGV0ZShkZXZpY2VJcClcblx0fSlcblx0X2Nvbm1vblBlbmRpbmcuc2V0KGRldmljZUlwLCBwcm9taXNlKVxuXHRyZXR1cm4gcHJvbWlzZVxufVxuXG5hc3luYyBmdW5jdGlvbiBfZG9Db25Nb25TZXNzaW9uKGRldmljZUlwOiBzdHJpbmcsIHRpbWVvdXRNczogbnVtYmVyKTogUHJvbWlzZTwoKCkgPT4gdm9pZCkgfCBudWxsPiB7XG5cdHJldHVybiBuZXcgUHJvbWlzZTwoKCkgPT4gdm9pZCkgfCBudWxsPigocmVzb2x2ZSkgPT4ge1xuXHRcdGxldCBzZXR0bGVkID0gZmFsc2Vcblx0XHRsZXQga2VlcGFsaXZlVGltZXI6IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGwgPSBudWxsXG5cblx0XHRjb25zdCBjbG9zZVNlc3Npb24gPSAoc29jazogZGdyYW0uU29ja2V0KSA9PiB7XG5cdFx0XHRpZiAoa2VlcGFsaXZlVGltZXIpIHtcblx0XHRcdFx0Y2xlYXJJbnRlcnZhbChrZWVwYWxpdmVUaW1lcilcblx0XHRcdFx0a2VlcGFsaXZlVGltZXIgPSBudWxsXG5cdFx0XHR9XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRzb2NrLmNsb3NlKClcblx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdH1cblx0XHRcdGxvZ2dlci5kZWJ1ZyhgQ29uTW9uIHNlc3Npb24gY2xvc2VkIGZvciAke2RldmljZUlwfWApXG5cdFx0fVxuXG5cdFx0Y29uc3QgZmFpbCA9IChzb2NrOiBkZ3JhbS5Tb2NrZXQpID0+IHtcblx0XHRcdGlmIChzZXR0bGVkKSByZXR1cm5cblx0XHRcdHNldHRsZWQgPSB0cnVlXG5cdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRjbG9zZVNlc3Npb24oc29jaylcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgQ29uTW9uIHNlc3Npb24gbm90IGVzdGFibGlzaGVkIGZvciAke2RldmljZUlwfWApXG5cdFx0XHRyZXNvbHZlKG51bGwpXG5cdFx0fVxuXG5cdFx0Y29uc3Qgc29jayA9IGRncmFtLmNyZWF0ZVNvY2tldCh7IHR5cGU6ICd1ZHA0JywgcmV1c2VBZGRyOiB0cnVlIH0pXG5cdFx0Y29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IGZhaWwoc29jayksIHRpbWVvdXRNcylcblxuXHRcdHNvY2sub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLndhcm4oYENvbk1vbiBzb2NrZXQgZXJyb3IgZm9yICR7ZGV2aWNlSXB9OiAke2Vyci5tZXNzYWdlfWApXG5cdFx0XHRmYWlsKHNvY2spXG5cdFx0fSlcblxuXHRcdHNvY2sub24oJ21lc3NhZ2UnLCAobXNnOiBCdWZmZXIpID0+IHtcblx0XHRcdC8vIERldmljZSBBQ0s6IHR5cGUgYnl0ZSAweDIwIGF0IG9mZnNldCAzXG5cdFx0XHRpZiAoIXNldHRsZWQgJiYgbXNnLmxlbmd0aCA+PSA0ICYmIG1zZ1swXSA9PT0gMHgxMiAmJiBtc2dbM10gPT09IDB4MjApIHtcblx0XHRcdFx0c2V0dGxlZCA9IHRydWVcblx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgQ29uTW9uIHNlc3Npb24gZXN0YWJsaXNoZWQgd2l0aCAke2RldmljZUlwfWApXG5cblx0XHRcdFx0bGV0IGtlZXBhbGl2ZVNlcSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDB4ZmZmZSkgKyAxXG5cdFx0XHRcdGNvbnN0IHNlbmRLZWVwYWxpdmUgPSAoKSA9PiB7XG5cdFx0XHRcdFx0Y29uc3QgcGt0ID0gQnVmZmVyLmFsbG9jKDIwLCAwKVxuXHRcdFx0XHRcdHBrdFswXSA9IDB4MTJcblx0XHRcdFx0XHRwa3RbM10gPSAweDRlXG5cdFx0XHRcdFx0cGt0LndyaXRlVUludDE2QkUoa2VlcGFsaXZlU2VxKysgJiAweGZmZmYsIDQpXG5cdFx0XHRcdFx0cGt0WzZdID0gMHgzMFxuXHRcdFx0XHRcdHBrdFs3XSA9IDB4MTBcblx0XHRcdFx0XHRzb2NrLnNlbmQocGt0LCA4ODAwLCBkZXZpY2VJcCwgKCkgPT4ge1xuXHRcdFx0XHRcdFx0LyogZmlyZSBhbmQgZm9yZ2V0ICovXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0fVxuXHRcdFx0XHRrZWVwYWxpdmVUaW1lciA9IHNldEludGVydmFsKHNlbmRLZWVwYWxpdmUsIDEwMDApXG5cdFx0XHRcdHJlc29sdmUoKCkgPT4gY2xvc2VTZXNzaW9uKHNvY2spKVxuXHRcdFx0fVxuXHRcdH0pXG5cblx0XHRjb25zdCBkb0luaXQgPSBhc3luYyAoKSA9PiB7XG5cdFx0XHRsZXQgbG9jYWxJcDogc3RyaW5nXG5cdFx0XHRsZXQgbG9jYWxNYWM6IG51bWJlcltdXG5cdFx0XHR0cnkge1xuXHRcdFx0XHRsb2NhbElwID0gYXdhaXQgZ2V0TG9jYWxBZGRyZXNzRm9yRGVzdGluYXRpb24oZGV2aWNlSXApXG5cdFx0XHRcdGxvY2FsTWFjID0gYXdhaXQgZ2V0TWFjRm9yRGVzdGluYXRpb24oZGV2aWNlSXApXG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBDb25Nb246IGNvdWxkIG5vdCBnZXQgbG9jYWwgbmV0d29yayBpbmZvIGZvciAke2RldmljZUlwfTogJHtlfWApXG5cdFx0XHRcdGZhaWwoc29jaylcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cblx0XHRcdHNvY2suYmluZCh7IHBvcnQ6IDg4MDAsIGFkZHJlc3M6IGxvY2FsSXAgfSwgKCkgPT4ge1xuXHRcdFx0XHRjb25zdCBzZXEgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAweGZmZmUpICsgMVxuXHRcdFx0XHRjb25zdCBwa3QgPSBCdWZmZXIuYWxsb2MoMjAsIDApXG5cdFx0XHRcdHBrdFswXSA9IDB4MTJcblx0XHRcdFx0cGt0WzNdID0gMHgxNFxuXHRcdFx0XHRwa3Qud3JpdGVVSW50MTZCRShzZXEsIDQpXG5cdFx0XHRcdHBrdFs2XSA9IDB4MTBcblx0XHRcdFx0cGt0WzddID0gMHgwMVxuXHRcdFx0XHRsb2NhbE1hYy5mb3JFYWNoKChiLCBpKSA9PiB7XG5cdFx0XHRcdFx0cGt0WzEyICsgaV0gPSBiXG5cdFx0XHRcdH0pXG5cdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgQ29uTW9uIFRYIHRvICR7ZGV2aWNlSXB9OiAke3BrdC50b1N0cmluZygnaGV4Jyl9YClcblx0XHRcdFx0c29jay5zZW5kKHBrdCwgODgwMCwgZGV2aWNlSXAsIChlcnIpID0+IHtcblx0XHRcdFx0XHRpZiAoZXJyKSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIud2FybihgQ29uTW9uIHNlbmQgZmFpbGVkIGZvciAke2RldmljZUlwfTogJHtlcnIubWVzc2FnZX1gKVxuXHRcdFx0XHRcdFx0ZmFpbChzb2NrKVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSlcblx0XHRcdH0pXG5cdFx0fVxuXG5cdFx0ZG9Jbml0KCkuY2F0Y2goKGUpID0+IHtcblx0XHRcdGxvZ2dlci53YXJuKGBDb25Nb24gaW5pdCBmYWlsZWQgZm9yICR7ZGV2aWNlSXB9OiAke2V9YClcblx0XHRcdGZhaWwoc29jaylcblx0XHR9KVxuXHR9KVxufVxuIiwgImltcG9ydCB7XG5cdEluc3RhbmNlVHlwZXMsXG5cdEluc3RhbmNlQmFzZSxcblx0SW5zdGFuY2VTdGF0dXMsXG5cdFNvbWVDb21wYW5pb25Db25maWdGaWVsZCxcblx0Y3JlYXRlTW9kdWxlTG9nZ2VyLFxufSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHsgR2V0Q29uZmlnRmllbGRzLCByZXNvbHZlSG9zdCwgcmVzb2x2ZU1vZGVsLCBnZXREZXZpY2VTY2hlbWEsIHR5cGUgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zLCBVcGRhdGVWYXJpYWJsZVZhbHVlcyB9IGZyb20gJy4vdmFyaWFibGVzLmpzJ1xuaW1wb3J0IHsgVXBncmFkZVNjcmlwdHMgfSBmcm9tICcuL3VwZ3JhZGVzLmpzJ1xuaW1wb3J0IHsgVXBkYXRlQWN0aW9ucyB9IGZyb20gJy4vYWN0aW9ucy5qcydcbmltcG9ydCB7IFVwZGF0ZUZlZWRiYWNrcyB9IGZyb20gJy4vZmVlZGJhY2tzLmpzJ1xuaW1wb3J0IHsgU3RDb250cm9sbGVyIH0gZnJvbSAnLi9zdGNvbnRyb2xsZXIuanMnXG5pbXBvcnQgdHlwZSB7IERldmljZUluZm8gfSBmcm9tICcuL3R5cGVzLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ01vZHVsZUluc3RhbmNlJylcblxuZXhwb3J0IHR5cGUgTW9kdWxlVHlwZXMgPSBJbnN0YW5jZVR5cGVzICYge1xuXHRjb25maWc6IE1vZHVsZUNvbmZpZ1xufVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNb2R1bGVJbnN0YW5jZSBleHRlbmRzIEluc3RhbmNlQmFzZTxNb2R1bGVUeXBlcz4ge1xuXHRjb25maWchOiBNb2R1bGVDb25maWcgLy8gU2V0dXAgaW4gaW5pdCgpXG5cdHN0Q29udHJvbGxlciE6IFN0Q29udHJvbGxlclxuXG5cdC8qKiBDYWNoZWQgZGlzY292ZXJ5IHJlc3VsdHMgXHUyMDE0IHBhc3NlZCBpbnRvIGdldENvbmZpZ0ZpZWxkcygpIHNvIHRoZSBVSVxuXHQgKiAgY2FuIHNob3cgdGhlIGRpc2NvdmVyZWQgZGV2aWNlIGRyb3Bkb3duIG9uIHN1YnNlcXVlbnQgY29uZmlnIG9wZW5zLiAqL1xuXHRwcml2YXRlIGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10gPSBbXVxuXG5cdC8qKiBDdXJyZW50bHkgYWN0aXZlIG1vZGVsIFx1MjAxNCByZXNvbHZlZCBvbmNlIGluIHN5bmNNb2RlbCgpIGFuZCBjYWNoZWQgaGVyZVxuXHQgKiAgc28gVXBkYXRlQWN0aW9ucywgVXBkYXRlRmVlZGJhY2tzIGV0Yy4gZG9uJ3QgZWFjaCBjYWxsIHJlc29sdmVNb2RlbCBpbmRlcGVuZGVudGx5LiAqL1xuXHRhY3RpdmVNb2RlbDogc3RyaW5nID0gJydcblxuXHRjb25zdHJ1Y3RvcihpbnRlcm5hbDogdW5rbm93bikge1xuXHRcdHN1cGVyKGludGVybmFsKVxuXHR9XG5cblx0YXN5bmMgaW5pdChjb25maWc6IE1vZHVsZUNvbmZpZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRoaXMuY29uZmlnID0gY29uZmlnXG5cdFx0aWYgKCF0aGlzLnN0Q29udHJvbGxlcikge1xuXHRcdFx0dGhpcy5zdENvbnRyb2xsZXIgPSBuZXcgU3RDb250cm9sbGVyKClcblx0XHR9XG5cdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuQ29ubmVjdGluZywgJ0Rpc2NvdmVyaW5nIGRldmljZXMuLi4nKVxuXG5cdFx0Ly8gV2lyZSBmZWVkYmFjayBjYWxsYmFjayBzbyBzdENvbnRyb2xsZXIgY2FuIHRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlc1xuXHRcdHRoaXMuc3RDb250cm9sbGVyLnNldEZlZWRiYWNrQ2FsbGJhY2soKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4ge1xuXHRcdFx0dGhpcy5jaGVja0ZlZWRiYWNrcyhmZWVkYmFja0lkKVxuXHRcdH0pXG5cblx0XHQvLyBTdGFydCBkaXNjb3ZlcnkgaW4gdGhlIGJhY2tncm91bmQgXHUyMDE0IGFsbCBtb2RlbCByZXNvbHV0aW9uLCBzY2hlbWEgc3luYyxcblx0XHQvLyBhbmQgVUkgdXBkYXRlcyBoYXBwZW4gaW5zaWRlIHJ1bkRpc2NvdmVyeSgpIG9uY2UgdGhlIGRldmljZSBsaXN0IGlzIGtub3duLlxuXHRcdHRoaXMucnVuRGlzY292ZXJ5KCkuY2F0Y2goKGUpID0+IHtcblx0XHRcdGxvZ2dlci5lcnJvcihgRGlzY292ZXJ5IGZhaWxlZDogJHtlfWApXG5cdFx0fSlcblx0fVxuXG5cdC8qKlxuXHQgKiBSdW4gZGV2aWNlIGRpc2NvdmVyeSwgdGhlbiByZXNvbHZlIHRoZSBtb2RlbCBhbmQgdXBkYXRlIGFsbCBVSS5cblx0ICogLSBJZiBkaXNjb3ZlcnkgZmluZHMgZGV2aWNlcywgcmVzb2x2ZU1vZGVsIHBpY2tzIGZyb20gdGhvc2UuXG5cdCAqIC0gT25seSBpZiB0aGUgbGlzdCBpcyBlbXB0eSBkbyB3ZSBmYWxsIGJhY2sgdG8gdGhlIG1hbnVhbCBjb25maWcgc2VsZWN0aW9uLlxuXHQgKiBBbGwgYWN0aW9ucy9mZWVkYmFja3MvdmFyaWFibGVzIGFyZSBidWlsdCBhZnRlciB0aGUgbW9kZWwgaXMga25vd24uXG5cdCAqL1xuXHRwcml2YXRlIGFzeW5jIHJ1bkRpc2NvdmVyeSgpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHRsb2dnZXIuaW5mbygnU3RhcnRpbmcgZGV2aWNlIGRpc2NvdmVyeS4uLicpXG5cblx0XHR0aGlzLmRpc2NvdmVyZWREZXZpY2VzID0gYXdhaXQgdGhpcy5zdENvbnRyb2xsZXIuZGlzY292ZXJEZXZpY2VzKClcblxuXHRcdC8vIERldGVybWluZSBlZmZlY3RpdmUgbW9kZWwgXHUyMDE0IGZyb20gZGlzY292ZXJlZCBkZXZpY2VzIGZpcnN0LCBtYW51YWwgY29uZmlnIG9ubHkgYXMgZmFsbGJhY2tcblx0XHRsZXQgZWZmZWN0aXZlTW9kZWw6IHN0cmluZ1xuXHRcdGlmICh0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmxlbmd0aCA9PT0gMCkge1xuXHRcdFx0aWYgKHRoaXMuY29uZmlnLmRldmljZU1hYykge1xuXHRcdFx0XHRsb2dnZXIud2FybihgU2F2ZWQgZGV2aWNlIE1BQyBcIiR7dGhpcy5jb25maWcuZGV2aWNlTWFjfVwiIG5vdCBmb3VuZCBkdXJpbmcgZGlzY292ZXJ5IFx1MjAxNCBzdG9wcGluZ2ApXG5cdFx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLkNvbm5lY3Rpb25GYWlsdXJlLCBgWyR7dGhpcy5jb25maWcuZGV2aWNlTWFjfV0gbm90IGZvdW5kYClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0XHRjb25zdCBtYW51YWxNb2RlbCA9IHRoaXMuY29uZmlnLmFjdGl2ZU1vZGVsXG5cdFx0XHRpZiAoIXRoaXMuY29uZmlnLmhvc3QgfHwgIW1hbnVhbE1vZGVsKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKCdObyBkZXZpY2VzIGRpc2NvdmVyZWQgYW5kIG5vIG1hbnVhbCBJUC9tb2RlbCBjb25maWd1cmVkJylcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0XHRsb2dnZXIuaW5mbygnTm8gZGV2aWNlcyBkaXNjb3ZlcmVkIFx1MjAxNCB3aWxsIHByb2JlIG1hbnVhbCBJUCBkdXJpbmcgYXV0aG9yaXphdGlvbicpXG5cdFx0XHRlZmZlY3RpdmVNb2RlbCA9IG1hbnVhbE1vZGVsXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ2dlci5pbmZvKGBEaXNjb3ZlcmVkICR7dGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5sZW5ndGh9IGRldmljZShzKTpgKVxuXHRcdFx0Zm9yIChjb25zdCBkIG9mIHRoaXMuZGlzY292ZXJlZERldmljZXMpIHtcblx0XHRcdFx0bG9nZ2VyLmluZm8oYCAgLSBNb2RlbCAke2QubW9kZWx9ICR7ZC5tYW51ZmFjdHVyZXIgPz8gJyd9IEAgJHtkLmlwfWApXG5cdFx0XHR9XG5cblx0XHRcdC8vIEF1dGhvcml6ZSBhbGwgZGlzY292ZXJlZCBkZXZpY2VzIHNvIGZpcm13YXJlIHJlcXVlc3RzIGNhbiBwcm9jZWVkLlxuXHRcdFx0Ly8gdmVyaWZ5QXV0aG9yaXphdGlvbiAoY2FsbGVkIGJlbG93KSB3aWxsIHJldm9rZSBhbnkgdGhhdCBkb24ndCBtYXRjaFxuXHRcdFx0Ly8gdGhlIGN1cnJlbnQgY29uZmlnIHNlbGVjdGlvbi5cblx0XHRcdGZvciAoY29uc3QgZGV2aWNlIG9mIHRoaXMuZGlzY292ZXJlZERldmljZXMpIHtcblx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuYXV0aG9yaXplRGV2aWNlKGRldmljZS5pcClcblx0XHRcdH1cblxuXHRcdFx0Ly8gUmVxdWVzdCBmaXJtd2FyZSB2ZXJzaW9uIGZyb20gZWFjaCBkaXNjb3ZlcmVkIGRldmljZVxuXHRcdFx0Zm9yIChjb25zdCBkZXZpY2Ugb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGNvbnN0IGZpcm13YXJlID0gYXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucmVxdWVzdEZpcm13YXJlVmVyc2lvbihkZXZpY2UuaXApXG5cdFx0XHRcdFx0ZGV2aWNlLmZpcm13YXJlTWFpbiA9IGZpcm13YXJlXG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYCAgLSAke2RldmljZS5pcH06IEZpcm13YXJlICR7ZmlybXdhcmV9LCBEYW50ZSAke2RldmljZS5kYW50ZUZpcm13YXJlfWApXG5cdFx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0XHRsb2dnZXIud2FybihgICAtICR7ZGV2aWNlLmlwfTogRmFpbGVkIHRvIGdldCBmaXJtd2FyZTogJHtlfWApXG5cdFx0XHRcdFx0ZGV2aWNlLmZpcm13YXJlTWFpbiA9ICdVbmtub3duJ1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdGVmZmVjdGl2ZU1vZGVsID0gcmVzb2x2ZU1vZGVsKHRoaXMuY29uZmlnLCB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXG5cdFx0XHRpZiAoIWVmZmVjdGl2ZU1vZGVsICYmIHRoaXMuY29uZmlnLmRldmljZU1hYykge1xuXHRcdFx0XHRsb2dnZXIud2FybihgU2F2ZWQgZGV2aWNlIE1BQyBcIiR7dGhpcy5jb25maWcuZGV2aWNlTWFjfVwiIG5vdCBmb3VuZCBhbW9uZyBkaXNjb3ZlcmVkIGRldmljZXMgXHUyMDE0IHN0b3BwaW5nYClcblx0XHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuQ29ubmVjdGlvbkZhaWx1cmUsIGBbJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XSBub3QgZm91bmRgKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBTeW5jIG1vZGVsIHNjaGVtYSB0byBjb250cm9sbGVyXG5cdFx0dGhpcy5zeW5jTW9kZWwoZWZmZWN0aXZlTW9kZWwpXG5cblx0XHQvLyBWZXJpZnkgdGhhdCB0aGUgY3VycmVudGx5IGNvbmZpZ3VyZWQgaG9zdCttb2RlbCBpcyB2YWxpZCBub3cgdGhhdFxuXHRcdC8vIGRpc2NvdmVyeSByZXN1bHRzIGFyZSBrbm93bi4gVGhpcyBpcyB0aGUgc2FtZSBjaGVjayBjb25maWdVcGRhdGVkIHVzZXMuXG5cdFx0Y29uc3QgdGFyZ2V0SG9zdCA9IHRoaXMuaG9zdFxuXHRcdGF3YWl0IHRoaXMudmVyaWZ5QXV0aG9yaXphdGlvbignJywgdGFyZ2V0SG9zdClcblxuXHRcdC8vIEJ1aWxkIGFsbCBVSSBub3cgdGhhdCBtb2RlbCBhbmQgYXV0aG9yaXphdGlvbiBzdGF0ZSBhcmUga25vd25cblx0XHR0aGlzLnVwZGF0ZUFjdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlRmVlZGJhY2tzKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVWYWx1ZXMoKVxuXG5cdFx0bG9nZ2VyLmluZm8oJ0RldmljZSBkaXNjb3ZlcnkgY29tcGxldGUnKVxuXHR9XG5cblx0Ly8gV2hlbiBtb2R1bGUgZ2V0cyBkZWxldGVkXG5cdGFzeW5jIGRlc3Ryb3koKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dGhpcy5zdENvbnRyb2xsZXI/LmNsb3NlKClcblx0XHRsb2dnZXIuZGVidWcoJ2Rlc3Ryb3knKVxuXHR9XG5cblx0YXN5bmMgY29uZmlnVXBkYXRlZChjb25maWc6IE1vZHVsZUNvbmZpZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdGNvbnN0IHByZXZpb3VzSG9zdCA9IHRoaXMuaG9zdFxuXHRcdHRoaXMuY29uZmlnID0gY29uZmlnXG5cdFx0Y29uc3QgZWZmZWN0aXZlTW9kZWwgPSByZXNvbHZlTW9kZWwoY29uZmlnLCB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHRcdHRoaXMuc3luY01vZGVsKGVmZmVjdGl2ZU1vZGVsKVxuXG5cdFx0Ly8gQ2xlYXIgdmFyaWFibGVzIGltbWVkaWF0ZWx5IFx1MjAxNCB0aGUgbmV3IHNlbGVjdGlvbiBpc24ndCBhdXRob3JpemVkIHlldC5cblx0XHQvLyBUaGV5J2xsIGJlIHJlcG9wdWxhdGVkIGJlbG93IG9uY2UgdmVyaWZ5QXV0aG9yaXphdGlvbiBjb21wbGV0ZXMuXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZVZhbHVlcygpXG5cblx0XHRjb25zdCBuZXdIb3N0ID0gdGhpcy5ob3N0XG5cblx0XHQvLyBSZS12ZXJpZnkgYXV0aG9yaXphdGlvbiBvbiBldmVyeSBjb25maWcgY2hhbmdlIChtb2RlbCBvciBJUCkuXG5cdFx0Ly8gVGhpcyBoYW5kbGVzIHN3aXRjaGluZyBmcm9tIGEgdmFsaWQgZGV2aWNlIHRvIGFuIGludmFsaWQgb25lIGFuZCBiYWNrLlxuXHRcdGF3YWl0IHRoaXMudmVyaWZ5QXV0aG9yaXphdGlvbihwcmV2aW91c0hvc3QsIG5ld0hvc3QpXG5cblx0XHQvLyBSZWJ1aWxkIFVJIGFmdGVyIGF1dGhvcml6YXRpb24gc3RhdGUgaXMgc2V0dGxlZFxuXHRcdHRoaXMudXBkYXRlQWN0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVGZWVkYmFja3MoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZVZhbHVlcygpXG5cdH1cblxuXHQvKipcblx0ICogUmUtZXZhbHVhdGVzIHdoZXRoZXIgdGhlIGN1cnJlbnQgY29uZmlnIGlzIGF1dGhvcml6ZWQgdG8gc2VuZCBjb21tYW5kcy5cblx0ICpcblx0ICogQXV0byBtb2RlIChkZXZpY2VNYWMgc2V0KTpcblx0ICogICAtIEZpbmQgdGhlIGRpc2NvdmVyZWQgZGV2aWNlIHdpdGggbWF0Y2hpbmcgTUFDIFx1MjE5MiBnZXQgaXRzIGN1cnJlbnQgSVBcblx0ICogICAtIFJldm9rZSB0aGUgcHJldmlvdXMgSVAsIGF1dGhvcml6ZSB0aGUgbmV3IElQXG5cdCAqICAgLSBJZiBNQUMgbm90IGZvdW5kIGluIGRpc2NvdmVyeSwgcmV2b2tlIGFuZCBibG9ja1xuXHQgKlxuXHQgKiBNYW51YWwgbW9kZSAoZGV2aWNlTWFjIGVtcHR5KTpcblx0ICogICAtIENoZWNrIGRpc2NvdmVyZWQgbGlzdCBieSBJUCttb2RlbCBtYXRjaCwgb3IgcHJvYmUgZGlyZWN0bHlcblx0ICovXG5cdHByaXZhdGUgYXN5bmMgdmVyaWZ5QXV0aG9yaXphdGlvbihwcmV2aW91c0hvc3Q6IHN0cmluZywgbmV3SG9zdDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0aWYgKCFuZXdIb3N0KSB7XG5cdFx0XHRpZiAocHJldmlvdXNIb3N0KSB0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY29uZmlnLmRldmljZU1hYykge1xuXHRcdFx0Ly8gQXV0byBtb2RlIFx1MjAxNCBtYXRjaCBieSBNQUMsIHVzZSB3aGF0ZXZlciBJUCBkaXNjb3ZlcnkgZm91bmQgaXQgYXRcblx0XHRcdGNvbnN0IGRldmljZSA9IHRoaXMuZGlzY292ZXJlZERldmljZXMuZmluZCgoZCkgPT4gZC5tYWMgPT09IHRoaXMuY29uZmlnLmRldmljZU1hYylcblx0XHRcdGlmICghZGV2aWNlKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBEZXZpY2UgTUFDIFwiJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XCIgbm90IGZvdW5kIGluIGN1cnJlbnQgZGlzY292ZXJ5IFx1MjAxNCBub3QgYXV0aG9yaXppbmdgKVxuXHRcdFx0XHRpZiAocHJldmlvdXNIb3N0KSB0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0aWYgKHByZXZpb3VzSG9zdCAmJiBwcmV2aW91c0hvc3QgIT09IG5ld0hvc3QpIHtcblx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHRcdH1cblx0XHRcdGNvbnN0IHdhc0F1dGhvcml6ZWQgPSB0aGlzLnN0Q29udHJvbGxlci5pc0RldmljZUF1dGhvcml6ZWQobmV3SG9zdClcblx0XHRcdGlmICghd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5hdXRob3JpemVEZXZpY2UobmV3SG9zdClcblx0XHRcdH1cblx0XHRcdGlmIChuZXdIb3N0ICE9PSBwcmV2aW91c0hvc3QgfHwgIXdhc0F1dGhvcml6ZWQpIHtcblx0XHRcdFx0YXdhaXQgdGhpcy5mZXRjaFNldHRpbmdzQW5kRW5zdXJlU2NoZW1hKGRldmljZS5tb2RlbCwgbmV3SG9zdClcblx0XHRcdH1cblx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLk9rLCBgTW9kZWwgJHtkZXZpY2UubW9kZWx9IEAgJHtuZXdIb3N0fWApXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBNYW51YWwgbW9kZSBcdTIwMTQgY29uZmlnLmhvc3QgKyBjb25maWcuYWN0aXZlTW9kZWwgbXVzdCBtYXRjaFxuXHRcdGNvbnN0IG1hbnVhbE1vZGVsID0gU3RyaW5nKHRoaXMuY29uZmlnLmFjdGl2ZU1vZGVsID8/ICcnKVxuXHRcdGNvbnN0IGRpc2NvdmVyZWRBdElwID0gdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLmlwID09PSBuZXdIb3N0KVxuXG5cdFx0aWYgKGRpc2NvdmVyZWRBdElwKSB7XG5cdFx0XHRpZiAoZGlzY292ZXJlZEF0SXAubW9kZWwgPT09IG1hbnVhbE1vZGVsKSB7XG5cdFx0XHRcdGlmIChwcmV2aW91c0hvc3QgJiYgcHJldmlvdXNIb3N0ICE9PSBuZXdIb3N0KSB0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdFx0XHRjb25zdCB3YXNBdXRob3JpemVkID0gdGhpcy5zdENvbnRyb2xsZXIuaXNEZXZpY2VBdXRob3JpemVkKG5ld0hvc3QpXG5cdFx0XHRcdGlmICghd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShuZXdIb3N0KVxuXHRcdFx0XHR9XG5cdFx0XHRcdGlmIChuZXdIb3N0ICE9PSBwcmV2aW91c0hvc3QgfHwgIXdhc0F1dGhvcml6ZWQpIHtcblx0XHRcdFx0XHRhd2FpdCB0aGlzLmZldGNoU2V0dGluZ3NBbmRFbnN1cmVTY2hlbWEobWFudWFsTW9kZWwsIG5ld0hvc3QpXG5cdFx0XHRcdH1cblx0XHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuT2ssIGBNb2RlbCAke21hbnVhbE1vZGVsfSBAICR7bmV3SG9zdH1gKVxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0bG9nZ2VyLmVycm9yKFxuXHRcdFx0XHRcdGBEZXZpY2Ugc2VsZWN0ZWQgKE1vZGVsICR7bWFudWFsTW9kZWx9KSBkb2VzIG5vdCBtYXRjaCBkZXRlY3RlZCBkZXZpY2UgKE1vZGVsICR7ZGlzY292ZXJlZEF0SXAubW9kZWx9KSBhdCAke25ld0hvc3R9IFx1MjAxNCBjb21tYW5kcyBibG9ja2VkYCxcblx0XHRcdFx0KVxuXHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UobmV3SG9zdClcblx0XHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoXG5cdFx0XHRcdFx0SW5zdGFuY2VTdGF0dXMuQ29ubmVjdGlvbkZhaWx1cmUsXG5cdFx0XHRcdFx0YE1vZGVsIG1pc21hdGNoOiBleHBlY3RlZCAke21hbnVhbE1vZGVsfSwgZ290ICR7ZGlzY292ZXJlZEF0SXAubW9kZWx9YCxcblx0XHRcdFx0KVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Ly8gSVAgbm90IGluIGRpc2NvdmVyZWQgbGlzdCBcdTIwMTQgcHJvYmUgaXQgZGlyZWN0bHkgdmlhIERhbnRlXG5cdFx0bG9nZ2VyLmluZm8oYCR7bmV3SG9zdH0gbm90IGluIGRpc2NvdmVyZWQgbGlzdCBcdTIwMTQgcHJvYmluZ2ApXG5cdFx0aWYgKHByZXZpb3VzSG9zdCAmJiBwcmV2aW91c0hvc3QgIT09IG5ld0hvc3QpIHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0dGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKG5ld0hvc3QpXG5cblx0XHRjb25zdCBwcm9iZWQgPSBhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5wcm9iZURldmljZShuZXdIb3N0KVxuXHRcdGlmICghcHJvYmVkKSB7XG5cdFx0XHRsb2dnZXIuZXJyb3IoYE5vIGRldmljZSByZXNwb25kZWQgYXQgJHtuZXdIb3N0fSBcdTIwMTQgY29tbWFuZHMgYmxvY2tlZGApXG5cdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5Vbmtub3duV2FybmluZywgYERldmljZSBvZmZsaW5lOiAke25ld0hvc3R9YClcblx0XHR9IGVsc2UgaWYgKHByb2JlZC5tb2RlbCAhPT0gbWFudWFsTW9kZWwpIHtcblx0XHRcdGxvZ2dlci5lcnJvcihcblx0XHRcdFx0YERldmljZSBzZWxlY3RlZCAoTW9kZWwgJHttYW51YWxNb2RlbH0pIGRvZXMgbm90IG1hdGNoIGRldGVjdGVkIGRldmljZSAoTW9kZWwgJHtwcm9iZWQubW9kZWx9KSBhdCAke25ld0hvc3R9IFx1MjAxNCBjb21tYW5kcyBibG9ja2VkYCxcblx0XHRcdClcblx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKFxuXHRcdFx0XHRJbnN0YW5jZVN0YXR1cy5Db25uZWN0aW9uRmFpbHVyZSxcblx0XHRcdFx0YE1vZGVsIG1pc21hdGNoOiBleHBlY3RlZCAke21hbnVhbE1vZGVsfSwgZ290ICR7cHJvYmVkLm1vZGVsfWAsXG5cdFx0XHQpXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ2dlci5pbmZvKGBWZXJpZmllZCBNb2RlbCAke3Byb2JlZC5tb2RlbH0gYXQgJHtuZXdIb3N0fWApXG5cdFx0XHR0aGlzLnN0Q29udHJvbGxlci5hdXRob3JpemVEZXZpY2UobmV3SG9zdClcblx0XHRcdGF3YWl0IHRoaXMuZmV0Y2hTZXR0aW5nc0FuZEVuc3VyZVNjaGVtYShtYW51YWxNb2RlbCwgbmV3SG9zdClcblx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLk9rLCBgTW9kZWwgJHtwcm9iZWQubW9kZWx9IEAgJHtuZXdIb3N0fWApXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIEZldGNoZXMgYWxsIHNldHRpbmdzIGZyb20gdGhlIGRldmljZS4gSWYgbm8gc2NoZW1hIGV4aXN0cyBmb3IgdGhlIG1vZGVsLFxuXHQgKiBjcmVhdGVzIG9uZSBmcm9tIHRoZSByZXNwb25zZSBhbmQgcmVsb2FkcyB0aGUgc2NoZW1hIGNhY2hlLlxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyBmZXRjaFNldHRpbmdzQW5kRW5zdXJlU2NoZW1hKG1vZGVsOiBzdHJpbmcsIGlwOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0cnkge1xuXHRcdFx0YXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucmVxdWVzdEFsbFNldHRpbmdzKGlwKVxuXG5cdFx0XHRpZiAoIWdldERldmljZVNjaGVtYShtb2RlbCkpIHtcblx0XHRcdFx0Ly8gTm8gc2NoZW1hIGV4aXN0cyBcdTIwMTQgZG8gTk9UIGF1dG8tY3JlYXRlIG9uZSBoZXJlLlxuXHRcdFx0XHQvLyBUaGUgdXNlciBtdXN0IHJ1biBcIkdMT0JBTDogR2V0IEFsbCBTZXR0aW5nc1wiIHRvIGNyZWF0ZSBpdC5cblx0XHRcdFx0bG9nZ2VyLndhcm4oYE5vIHNjaGVtYSBmb3VuZCBmb3IgTW9kZWwgJHttb2RlbH0gXHUyMDE0IHJ1biBcIkdMT0JBTDogR2V0IEFsbCBTZXR0aW5nc1wiIHRvIGNyZWF0ZSBvbmVgKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIGZldGNoIHNldHRpbmdzIGZyb20gJHtpcH06ICR7ZX1gKVxuXHRcdH1cblx0fVxuXG5cdC8qKiBMb2FkcyB0aGUgZGV2aWNlIEpTT04gZm9yIHRoZSBnaXZlbiBtb2RlbCwgY2FjaGVzIGl0IGFzIGFjdGl2ZU1vZGVsLCBhbmQgcHVzaGVzIGl0IHRvIHRoZSBjb250cm9sbGVyLiAqL1xuXHRwcml2YXRlIHN5bmNNb2RlbChtb2RlbDogc3RyaW5nKTogdm9pZCB7XG5cdFx0dGhpcy5hY3RpdmVNb2RlbCA9IG1vZGVsXG5cdFx0Y29uc3Qgc2NoZW1hID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRcdGlmICghc2NoZW1hKSB7XG5cdFx0XHRsb2dnZXIud2FybihgTW9kZWwgXCIke21vZGVsfVwiIG5vdCBmb3VuZCBpbiBkZXZpY2Ugc2NoZW1hc2ApXG5cdFx0XHR0aGlzLnN0Q29udHJvbGxlci5zZXRNb2RlbChtb2RlbCwgW10pXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRjb25zdCBhY3Rpb25zID0gQXJyYXkuaXNBcnJheShzY2hlbWEuY21kU2NoZW1hKSA/IHNjaGVtYS5jbWRTY2hlbWEgOiBbXVxuXG5cdFx0dGhpcy5zdENvbnRyb2xsZXIuc2V0TW9kZWwobW9kZWwsIGFjdGlvbnMpXG5cdFx0aWYgKGFjdGlvbnMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRsb2dnZXIud2FybihgTm8gYWN0aW9ucyBmb3VuZCBmb3IgbW9kZWwgXCIke21vZGVsfVwiIFx1MjAxNCBzZXR0aW5ncyBkZWNvZGluZyB3aWxsIHVzZSByYXcgSURzYClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBMb2FkZWQgJHthY3Rpb25zLmxlbmd0aH0gYWN0aW9ucyBmb3IgbW9kZWwgXCIke21vZGVsfVwiYClcblx0XHR9XG5cdH1cblxuXHRnZXRDb25maWdGaWVsZHMoKTogU29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkW10ge1xuXHRcdHJldHVybiBHZXRDb25maWdGaWVsZHModGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0fVxuXG5cdC8qKiBSZXR1cm5zIHRoZSBlZmZlY3RpdmUgaG9zdCBJUCwgcmVzb2x2ZWQgZnJvbSBNQUNcdTIxOTJJUCB2aWEgZGlzY292ZXJlZERldmljZXMgKGF1dG8pIG9yIGNvbmZpZy5ob3N0IChtYW51YWwpLiAqL1xuXHRnZXQgaG9zdCgpOiBzdHJpbmcge1xuXHRcdHJldHVybiByZXNvbHZlSG9zdCh0aGlzLmNvbmZpZywgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0fVxuXG5cdC8qKiBSZXR1cm5zIGRpc2NvdmVyZWQgZGV2aWNlcyBmb3IgdXNlIGluIGFjdGlvbnMvY29uZmlnICovXG5cdGdldCBkZXZpY2VzKCk6IERldmljZUluZm9bXSB7XG5cdFx0cmV0dXJuIHRoaXMuZGlzY292ZXJlZERldmljZXNcblx0fVxuXG5cdHVwZGF0ZUFjdGlvbnMoKTogdm9pZCB7XG5cdFx0VXBkYXRlQWN0aW9ucyh0aGlzKVxuXHR9XG5cblx0dXBkYXRlRmVlZGJhY2tzKCk6IHZvaWQge1xuXHRcdFVwZGF0ZUZlZWRiYWNrcyh0aGlzKVxuXHR9XG5cblx0dXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpOiB2b2lkIHtcblx0XHRVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVWYXJpYWJsZVZhbHVlcygpOiB2b2lkIHtcblx0XHRVcGRhdGVWYXJpYWJsZVZhbHVlcyh0aGlzKVxuXHR9XG59XG5cbmV4cG9ydCB7IFVwZ3JhZGVTY3JpcHRzIH1cbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7O0FBa0JBLElBQU0scUJBQWtDLENBQUMsUUFBUSxPQUFPLFlBQVc7QUFFbEUsVUFBUSxJQUFJLElBQUksTUFBTSxZQUFXLENBQUUsSUFBSSxTQUFTLEtBQUssTUFBTSxNQUFNLEVBQUUsSUFBSSxPQUFPLEVBQUU7QUFDakY7QUFFQSxTQUFTLFVBQVUsUUFBNEIsT0FBaUIsU0FBZTtBQUM5RSxRQUFNLE9BQU8sT0FBTyxPQUFPLHFCQUFxQixhQUFhLE9BQU8sbUJBQW1CO0FBQ3ZGLE9BQUssUUFBUSxPQUFPLE9BQU87QUFDNUI7QUFPTSxTQUFVLG1CQUFtQixRQUFlO0FBQ2pELFNBQU87SUFDTixPQUFPLENBQUMsWUFBb0IsVUFBVSxRQUFRLFNBQVMsT0FBTztJQUM5RCxNQUFNLENBQUMsWUFBb0IsVUFBVSxRQUFRLFFBQVEsT0FBTztJQUM1RCxNQUFNLENBQUMsWUFBb0IsVUFBVSxRQUFRLFFBQVEsT0FBTztJQUM1RCxPQUFPLENBQUMsWUFBb0IsVUFBVSxRQUFRLFNBQVMsT0FBTzs7QUFFaEU7OztBQ1RNLFNBQVUsWUFBWSxNQUFXO0FBRXZDO0FBeUJNLFNBQVUsV0FBVyxHQUFXLEdBQVcsR0FBVyxHQUFVO0FBQ3JFLE1BQUksZUFBd0IsSUFBSSxRQUFTLE1BQVEsSUFBSSxRQUFTLElBQU0sSUFBSTtBQUN4RSxNQUFJLEtBQUssS0FBSyxLQUFLLElBQUksR0FBRztBQUN6QixtQkFBZSxXQUFZLEtBQUssTUFBTSxPQUFPLElBQUksRUFBRTtFQUNwRDtBQUNBLFNBQU87QUFDUjs7O0FDL0RBLFNBQVMsb0JBQW9CO0FBMkV2QixJQUFPLHNCQUFQLGNBQW1DLGFBQW1DO0VBQ2xFO0VBQ0E7RUFFVCxJQUFXLFdBQVE7QUFDbEIsV0FBTyxLQUFLLFlBQVk7RUFDekI7RUFDQSxJQUFXLGFBQVU7QUFDcEIsV0FBTyxLQUFLLFlBQVk7RUFDekI7RUFFQSxJQUFZLGFBQVU7QUFDckIsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVcsVUFBVTtBQUNuRCxhQUFPLEtBQUs7SUFDYixPQUFPO0FBQ04sYUFBTztJQUNSO0VBQ0Q7RUFFQSxTQUF1RTtFQUV2RSxZQUFZLFNBQXlDLFNBQStCO0FBQ25GLFVBQUs7QUFFTCxTQUFLLFdBQVc7QUFDaEIsU0FBSyxXQUFXLEVBQUUsR0FBRyxRQUFPO0VBQzdCO0VBRUEsS0FBSyxNQUFjLFVBQW1CLFVBQXFCO0FBQzFELFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXO0FBQVUsWUFBTSxJQUFJLE1BQU0seUJBQXlCO0FBQzdGLFlBQVEsS0FBSyxRQUFRO01BQ3BCLEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSxvQ0FBb0M7TUFDckQsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLHlCQUF5QjtNQUMxQyxLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0sbUJBQW1CO01BQ3BDLEtBQUs7QUFDSjtNQUNEO0FBQ0Msb0JBQVksS0FBSyxNQUFNO0FBQ3ZCLGNBQU0sSUFBSSxNQUFNLHNCQUFzQjtJQUN4QztBQUVBLFNBQUssU0FBUztBQUVkLFFBQUk7QUFBVSxXQUFLLEdBQUcsYUFBYSxRQUFRO0FBRTNDLFNBQUssU0FDSCxvQkFBb0I7TUFDcEIsUUFBUSxLQUFLLFNBQVM7TUFDdEIsWUFBWTs7S0FFWixFQUNBLEtBQ0EsQ0FBQyxhQUFZO0FBQ1osV0FBSyxTQUFTLEVBQUUsWUFBWSxNQUFNLFNBQVE7QUFDMUMsV0FBSyxTQUFTLHdCQUF3QixJQUFJLFVBQVUsSUFBSTtBQUN4RCxXQUFLLEtBQUssV0FBVztJQUN0QixHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssU0FBUztBQUNkLFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBRUEsTUFBTSxVQUFxQjtBQUMxQixRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVyxVQUFVO0lBRXBELE9BQU87QUFDTixjQUFRLEtBQUssUUFBUTtRQUNwQixLQUFLO0FBQ0osZ0JBQU0sSUFBSSxNQUFNLG9DQUFvQztRQUNyRCxLQUFLO1FBQ0wsS0FBSztRQUNMLEtBQUs7QUFDSixnQkFBTSxJQUFJLE1BQU0sb0JBQW9CO1FBQ3JDO0FBQ0Msc0JBQVksS0FBSyxNQUFNO0FBQ3ZCLGdCQUFNLElBQUksTUFBTSxzQkFBc0I7TUFDeEM7SUFDRDtBQUVBLFVBQU0sV0FBVyxLQUFLLE9BQU87QUFDN0IsU0FBSyxTQUFTO0FBRWQsUUFBSTtBQUFVLFdBQUssR0FBRyxTQUFTLFFBQVE7QUFFdkMsU0FBSyxTQUNILHFCQUFxQjtNQUNyQjtLQUNBLEVBQ0EsS0FDQSxNQUFLO0FBQ0osV0FBSyxTQUFTLHdCQUF3QixPQUFPLFFBQVE7QUFDckQsV0FBSyxLQUFLLE9BQU87SUFDbEIsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLFNBQVMsd0JBQXdCLE9BQU8sUUFBUTtBQUNyRCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQVdBLEtBQ0MsY0FDQSxjQUNBLGlCQUNBLGdCQUNBLFNBQ0EsVUFBcUI7QUFFckIsUUFBSSxPQUFPLGlCQUFpQjtBQUFVLFlBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUN6RSxRQUFJLE9BQU8sb0JBQW9CLFVBQVU7QUFDeEMsVUFBSSxPQUFPLG1CQUFtQixZQUFZLE9BQU8sWUFBWTtBQUFVLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUMxRyxVQUFJLGFBQWEsVUFBYSxPQUFPLGFBQWE7QUFBWSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFFakcsWUFBTSxTQUFTLEtBQUssZUFBZSxjQUFjLGNBQWMsZUFBZTtBQUM5RSxXQUFLLFdBQVcsUUFBUSxnQkFBZ0IsU0FBUyxRQUFRO0lBQzFELFdBQVcsT0FBTyxvQkFBb0IsVUFBVTtBQUMvQyxVQUFJLG1CQUFtQixVQUFhLE9BQU8sbUJBQW1CO0FBQVksY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBRTdHLFlBQU0sU0FBUyxLQUFLLGVBQWUsY0FBYyxHQUFHLE1BQVM7QUFDN0QsV0FBSyxXQUFXLFFBQVEsY0FBYyxpQkFBaUIsY0FBYztJQUN0RSxPQUFPO0FBQ04sWUFBTSxJQUFJLE1BQU0sbUJBQW1CO0lBQ3BDO0VBQ0Q7RUFFQSxlQUNDLGNBQ0EsUUFDQSxRQUEwQjtBQUUxQixRQUFJO0FBQ0osUUFBSSxPQUFPLGlCQUFpQixVQUFVO0FBQ3JDLGVBQVMsT0FBTyxLQUFLLGNBQWMsT0FBTztJQUMzQyxXQUFXLE9BQU8sU0FBUyxZQUFZLEdBQUc7QUFDekMsZUFBUztJQUNWLFdBQVcsTUFBTSxRQUFRLFlBQVksR0FBRztBQUV2QyxhQUFPLE9BQU8sS0FBSyxZQUFZO0lBQ2hDLE9BQU87QUFDTixlQUFTLE9BQU8sS0FBSyxhQUFhLFFBQVEsYUFBYSxZQUFZLGFBQWEsVUFBVTtJQUMzRjtBQUVBLFdBQU8sT0FBTyxTQUFTLFFBQVEsV0FBVyxTQUFZLFNBQVMsU0FBUyxNQUFTO0VBQ2xGO0VBRUEsV0FBVyxRQUFnQixNQUFjLFNBQWlCLFVBQXFCO0FBQzlFLFFBQUksQ0FBQyxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVc7QUFBVSxZQUFNLElBQUksTUFBTSxvQkFBb0I7QUFFekYsU0FBSyxTQUNILG9CQUFvQjtNQUNwQixVQUFVLEtBQUssT0FBTztNQUN0QixTQUFTO01BRVQ7TUFDQTtLQUNBLEVBQ0EsS0FDQSxNQUFLO0FBQ0osaUJBQVU7SUFDWCxHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBRUEscUJBQXFCLFNBQStCO0FBQ25ELFFBQUk7QUFDSCxXQUFLLEtBQUssV0FBVyxRQUFRLFNBQVMsUUFBUSxNQUFNO0lBQ3JELFNBQVMsSUFBSTtJQUViO0VBQ0Q7RUFDQSxtQkFBbUIsT0FBWTtBQUM5QixTQUFLLFNBQVM7QUFFZCxVQUFNLGFBQWEsS0FBSztBQUN4QixRQUFJO0FBQVksV0FBSyxTQUFTLHdCQUF3QixPQUFPLFdBQVcsUUFBUTtBQUVoRixRQUFJO0FBQ0gsV0FBSyxLQUFLLFNBQVMsS0FBSztJQUN6QixTQUFTLElBQUk7SUFFYjtFQUNEOzs7O0FDOVBLLFNBQVUsa0JBQW1ELEtBQVk7QUFDOUUsUUFBTSxPQUFPO0FBQ2IsU0FBTyxDQUFDLENBQUMsUUFBUSxPQUFPLFNBQVMsWUFBWSxPQUFPLEtBQUssT0FBTyxZQUFZLEtBQUssdUJBQXVCO0FBQ3pHOzs7QUM2Qk0sSUFBZ0IsZUFBaEIsTUFBNEI7RUFDeEI7RUFDQTtFQUVBO0VBRVQsSUFBVyxLQUFFO0FBQ1osV0FBTyxLQUFLLFNBQVM7RUFDdEI7RUFFQSxJQUFXLGtCQUFlO0FBQ3pCLFdBQU8sS0FBSztFQUNiOzs7OztFQU1BLElBQVcsUUFBSztBQUNmLFdBQU8sS0FBSyxTQUFTO0VBQ3RCOzs7O0VBS0EsWUFBWSxVQUFpQjtBQUM1QixRQUFJLENBQUMsa0JBQTZCLFFBQVEsS0FBSyxDQUFDLFNBQVM7QUFDeEQsWUFBTSxJQUFJLE1BQ1QsbUdBQW1HO0FBR3JHLFNBQUssV0FBVztBQUVoQixTQUFLLFVBQVUsbUJBQWtCO0FBRWpDLFNBQUssd0JBQXdCLEtBQUssc0JBQXNCLEtBQUssSUFBSTtBQUVqRSxTQUFLLFdBQVc7TUFDZiwyQkFBMkI7TUFDM0Isd0JBQXdCOztBQUd6QixTQUFLLElBQUksU0FBUyxjQUFjO0VBQ2pDO0VBK0JBLFdBQVcsV0FBNEMsWUFBaUM7QUFDdkYsU0FBSyxTQUFTLFdBQVcsV0FBVyxVQUFVO0VBQy9DOzs7OztFQXVCQSxxQkFBcUIsU0FBeUQ7QUFDN0UsU0FBSyxTQUFTLHFCQUFxQixPQUFPO0VBQzNDOzs7OztFQU1BLHVCQUF1QixXQUErRDtBQUNyRixTQUFLLFNBQVMsdUJBQXVCLFNBQVM7RUFDL0M7Ozs7OztFQU9BLHFCQUNDLFdBQ0EsU0FBOEM7QUFFOUMsU0FBSyxTQUFTLHFCQUFxQixXQUFXLE9BQU87RUFDdEQ7Ozs7O0VBTUEsdUJBQXVCLFdBQStEO0FBQ3JGLFFBQUksTUFBTSxRQUFRLFNBQVM7QUFBRyxZQUFNLElBQUksTUFBTSx3REFBd0Q7QUFFdEcsU0FBSyxTQUFTLHVCQUF1QixTQUFTO0VBQy9DOzs7OztFQU1BLGtCQUFrQixRQUF1QztBQUN4RCxTQUFLLFNBQVMsa0JBQWtCLE1BQU07RUFDdkM7Ozs7OztFQU9BLGlCQUFtQyxZQUFhO0FBQy9DLFdBQU8sS0FBSyxTQUFTLGlCQUFpQixVQUFVO0VBQ2pEOzs7O0VBS0Esb0JBQWlCO0FBQ2hCLFNBQUssU0FBUyxrQkFBaUI7RUFDaEM7Ozs7Ozs7RUFRQSxlQUNDLGlCQUNHLGVBQW1EO0FBRXRELFNBQUssU0FBUyxlQUFlLENBQUMsY0FBYyxHQUFHLGFBQWEsQ0FBQztFQUM5RDs7Ozs7RUFNQSxzQkFBc0IsYUFBcUI7QUFDMUMsU0FBSyxTQUFTLG1CQUFtQixXQUFXO0VBQzdDOzs7Ozs7RUFPQSxvQkFBb0IsV0FBbUI7QUFDdEMsU0FBSyxTQUFTLGlCQUFpQixTQUFTO0VBQ3pDOzs7Ozs7RUFNQSxzQkFBc0IsV0FBbUI7QUFDeEMsU0FBSyxTQUFTLG1CQUFtQixTQUFTO0VBQzNDOzs7Ozs7RUFPQSx3QkFBd0IsYUFBcUI7QUFDNUMsU0FBSyxTQUFTLHFCQUFxQixXQUFXO0VBQy9DOzs7Ozs7RUFPQSxhQUFhLFFBQWlDLGNBQXFCO0FBQ2xFLFNBQUssU0FBUyxhQUFhLFFBQVEsWUFBWTtFQUNoRDs7Ozs7Ozs7RUFTQSxRQUFRLE1BQWMsTUFBY0EsT0FBYyxNQUFzQjtBQUN2RSxTQUFLLFNBQVMsUUFBUSxNQUFNLE1BQU1BLE9BQU0sSUFBSTtFQUM3Qzs7Ozs7Ozs7Ozs7RUFZQSxhQUFhLFFBQXdCLFNBQXVCO0FBQzNELFNBQUssU0FBUyxhQUFhLFFBQVEsV0FBVyxJQUFJO0VBQ25EOzs7Ozs7RUFPQSxJQUFJLE9BQWlCLFNBQWU7QUFDbkMsWUFBUSxPQUFPO01BQ2QsS0FBSztBQUNKLGFBQUssUUFBUSxNQUFNLE9BQU87QUFDMUI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxNQUFNLE9BQU87QUFDMUI7TUFDRDtBQUNDLG9CQUFZLEtBQUs7QUFDakIsYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtJQUNGO0VBQ0Q7RUFZQSxzQkFDQyxlQUNBLFVBQXlDO0FBRXpDLFVBQU0sVUFBa0MsT0FBTyxrQkFBa0IsV0FBVyxFQUFFLE1BQU0sY0FBYSxJQUFLO0FBRXRHLFVBQU0sU0FBUyxJQUFJLG9CQUFvQixLQUFLLFVBQVUsT0FBTztBQUM3RCxRQUFJO0FBQVUsYUFBTyxHQUFHLFdBQVcsUUFBUTtBQUUzQyxXQUFPO0VBQ1I7Ozs7QUMvVUQsSUFBWTtDQUFaLFNBQVlDLGlCQUFjO0FBQ3pCLEVBQUFBLGdCQUFBLElBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLFlBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGNBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLG1CQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxXQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxjQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxnQkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsdUJBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLHlCQUFBLElBQUE7QUFDRCxHQVZZLG1CQUFBLGlCQUFjLENBQUEsRUFBQTtBQWFwQixJQUFXO0NBQWpCLFNBQWlCQyxRQUFLO0FBRVIsRUFBQUEsT0FBQSxLQUFLO0FBQ0wsRUFBQUEsT0FBQSxXQUNaO0FBQ1ksRUFBQUEsT0FBQSxVQUFVO0FBQ1YsRUFBQUEsT0FBQSxPQUNaO0FBQ1ksRUFBQUEsT0FBQSxjQUFjO0FBQ2QsRUFBQUEsT0FBQSxVQUFVO0FBQ1YsRUFBQUEsT0FBQSxRQUFRO0FBQ1IsRUFBQUEsT0FBQSxlQUFlO0FBQ2YsRUFBQUEsT0FBQSxlQUFlO0FBQ2YsRUFBQUEsT0FBQSxTQUFTO0FBQ1QsRUFBQUEsT0FBQSxnQkFBZ0I7QUFDaEIsRUFBQUEsT0FBQSxZQUFZO0FBQ1osRUFBQUEsT0FBQSxXQUNaO0FBQ0YsR0FsQmlCLFVBQUEsUUFBSyxDQUFBLEVBQUE7OztBQ2pCdEIsT0FBTyxRQUFRO0FBQ2YsT0FBTyxVQUFVO0FBSWpCLElBQU0sU0FBUyxtQkFBbUIsUUFBUTtBQXlCMUMsU0FBUyx1QkFBb0I7QUFDNUIsUUFBTSxjQUFjLEtBQUssS0FBSyxZQUFZLFNBQVMsWUFBWTtBQUMvRCxRQUFNLGVBQWUsS0FBSyxLQUFLLFlBQVksU0FBUyxXQUFXO0FBRy9ELE1BQUksR0FBRyxXQUFXLFdBQVcsR0FBRztBQUMvQixXQUFPLE1BQU0seUJBQXlCLFdBQVcsRUFBRTtBQUNuRCxXQUFPO0VBQ1I7QUFHQSxNQUFJLEdBQUcsV0FBVyxZQUFZLEdBQUc7QUFDaEMsV0FBTyxLQUFLLHFEQUFxRCxZQUFZLEVBQUU7QUFDL0UsV0FBTztFQUNSO0FBR0EsUUFBTSxXQUFXOztNQUEwQyxXQUFXO01BQVMsWUFBWTs7QUFDM0YsU0FBTyxNQUFNLFFBQVE7QUFDckIsUUFBTSxJQUFJLE1BQU0sUUFBUTtBQUN6QjtBQUdBLElBQU0sZ0JBQWdCLHFCQUFvQjtBQUcxQyxJQUFJLHFCQUFpRDtBQU0vQyxTQUFVLG1CQUFnQjtBQUMvQixTQUFPO0FBQ1I7QUFNQSxTQUFTLG9CQUFpQjtBQUN6QixRQUFNLFVBQStCLENBQUE7QUFDckMsTUFBSTtBQUNILFVBQU0sUUFBUSxHQUFHLFlBQVksYUFBYSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsU0FBUyxPQUFPLENBQUM7QUFFN0UsZUFBVyxLQUFLLE9BQU87QUFDdEIsWUFBTSxXQUFXLEtBQUssS0FBSyxlQUFlLENBQUM7QUFDM0MsWUFBTSxPQUFPLEtBQUssTUFBTSxHQUFHLGFBQWEsVUFBVSxNQUFNLENBQUM7QUFDekQsVUFBSSxNQUFNLE9BQU87QUFDaEIsZ0JBQVEsT0FBTyxLQUFLLEtBQUssQ0FBQyxJQUFJO01BQy9CO0lBQ0Q7QUFFQSxXQUFPLE1BQU0sVUFBVSxPQUFPLEtBQUssT0FBTyxFQUFFLE1BQU0sNEJBQTRCO0VBQy9FLFNBQVMsR0FBRztBQUNYLFdBQU8sTUFBTSxrQ0FBa0MsQ0FBQyxFQUFFO0VBQ25EO0FBQ0EsU0FBTztBQUNSO0FBTU0sU0FBVSxtQkFBZ0I7QUFDL0IsTUFBSSxDQUFDLG9CQUFvQjtBQUN4Qix5QkFBcUIsa0JBQWlCO0VBQ3ZDO0FBQ0EsU0FBTztBQUNSO0FBTU0sU0FBVSxnQkFBZ0IsT0FBYTtBQUM1QyxRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFNBQU8sUUFBUSxLQUFLO0FBQ3JCO0FBTU0sU0FBVSxzQkFBbUI7QUFDbEMsU0FBTyxLQUFLLHVDQUF1QztBQUNuRCx1QkFBcUIsa0JBQWlCO0FBQ3ZDO0FBS0EsU0FBUyxzQkFBbUI7QUFDM0IsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxTQUFPLE9BQU8sS0FBSyxPQUFPLEVBQUUsS0FBSTtBQUNqQztBQUVNLFNBQVUsZ0JBQWdCLG9CQUFrQyxDQUFBLEdBQUU7QUFDbkUsUUFBTSxTQUFTLG9CQUFtQjtBQUlsQyxRQUFNLGdCQUFnQjtJQUNyQixFQUFFLElBQUksSUFBSSxPQUFPLGtDQUFpQztJQUNsRCxHQUFHLGtCQUFrQixJQUFJLENBQUMsT0FBTztNQUNoQyxJQUFJLEVBQUUsT0FBTztNQUNiLE9BQU8sU0FBUyxFQUFFLEtBQUssS0FBSyxFQUFFLEdBQUcsT0FBTyxFQUFFLEVBQUU7TUFDM0M7O0FBR0gsU0FBTzs7O0lBR047TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUztNQUNULFNBQVM7TUFDVCxTQUFTOzs7SUFJVjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTO01BQ1QsT0FBTyxNQUFNO01BQ2IscUJBQXFCO01BQ3JCLFNBQVM7OztJQUlWO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVMsT0FBTyxDQUFDLEtBQUs7TUFDdEIsU0FBUyxPQUFPLElBQUksQ0FBQyxXQUFXO1FBQy9CLElBQUk7UUFDSixPQUFPLFNBQVMsS0FBSztRQUNwQjtNQUNGLHFCQUFxQjtNQUNyQixTQUFTOzs7SUFJVjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTO01BQ1QsU0FBUzs7O0FBR1o7QUFPTSxTQUFVLFlBQVksUUFBc0IsbUJBQStCO0FBQ2hGLE1BQUksT0FBTyxXQUFXO0FBQ3JCLFVBQU0sU0FBUyxrQkFBa0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLE9BQU8sU0FBUztBQUN2RSxXQUFPLFFBQVEsTUFBTTtFQUN0QjtBQUNBLFNBQU8sT0FBTyxPQUFPLFFBQVEsRUFBRTtBQUNoQztBQU9NLFNBQVUsYUFBYSxRQUFzQixtQkFBK0I7QUFDakYsTUFBSSxPQUFPLFdBQVc7QUFDckIsVUFBTSxTQUFTLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsT0FBTyxTQUFTO0FBQ3ZFLFdBQU8sTUFBTSw0QkFBNEIsT0FBTyxTQUFTLG9CQUFvQixRQUFRLFNBQVMsTUFBTSxFQUFFO0FBQ3RHLFdBQU8sUUFBUSxTQUFTO0VBQ3pCO0FBQ0EsU0FBTyxNQUFNLDJDQUEyQyxPQUFPLFdBQVcsR0FBRztBQUM3RSxTQUFPLE9BQU8sT0FBTyxlQUFlLEVBQUU7QUFDdkM7OztBQ3BOTSxTQUFVLDBCQUEwQixNQUFvQjtBQUM3RCxPQUFLLHVCQUF1QjtJQUMzQixPQUFPLEVBQUUsTUFBTSxzQkFBcUI7SUFDcEMsV0FBVyxFQUFFLE1BQU0sdUNBQXNDO0lBQ3pELGNBQWMsRUFBRSxNQUFNLHNCQUFxQjtJQUMzQyxVQUFVLEVBQUUsTUFBTSwwQkFBeUI7SUFDM0MsU0FBUyxFQUFFLE1BQU0sZ0NBQStCO0lBQ2hELEtBQUssRUFBRSxNQUFNLHFCQUFvQjtJQUNqQyxJQUFJLEVBQUUsTUFBTSxvQkFBbUI7R0FDL0I7QUFDRjtBQUVBLElBQU0sb0JBQW9CO0VBQ3pCLE9BQU87RUFDUCxXQUFXO0VBQ1gsY0FBYztFQUNkLFVBQVU7RUFDVixTQUFTO0VBQ1QsS0FBSztFQUNMLElBQUk7O0FBUUMsU0FBVSxxQkFBcUIsTUFBb0I7QUFDeEQsUUFBTSxjQUFjLEtBQUs7QUFHekIsTUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLGFBQWEsbUJBQW1CLFdBQVcsR0FBRztBQUN2RSxTQUFLLGtCQUFrQixpQkFBaUI7QUFDeEM7RUFDRDtBQUVBLFFBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFdBQVc7QUFDNUQsTUFBSSxRQUFRO0FBQ1gsU0FBSyxrQkFBa0I7TUFDdEIsT0FBTyxPQUFPLFNBQVM7TUFDdkIsV0FBVyxPQUFPLGFBQWE7TUFDL0IsY0FBYyxPQUFPLGdCQUFnQjtNQUNyQyxVQUFVLE9BQU8sZ0JBQWdCO01BQ2pDLFNBQVMsT0FBTyxpQkFBaUI7TUFDakMsS0FBSyxPQUFPLE9BQU87TUFDbkIsSUFBSSxPQUFPO0tBQ1g7RUFDRixPQUFPO0FBR04sU0FBSyxrQkFBa0I7TUFDdEIsR0FBRztNQUNILElBQUk7S0FDSjtFQUNGO0FBQ0Q7OztBQzFETyxJQUFNLGlCQUErRDs7Ozs7Ozs7Ozs7Ozs7O0FDU3JFLElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sY0FBYztBQUNwQixJQUFNLGNBQWM7QUFDcEIsSUFBTSxjQUFjO0FBQ3BCLElBQU0sZ0JBQWdCO0FBQ3RCLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sYUFBYTtBQUNuQixJQUFNLHVCQUF1QjtBQUM3QixJQUFNLG9CQUFvQjtBQUMxQixJQUFNLGVBQWU7QUFDckIsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxjQUFjO0FBR3JCLFNBQVUsZUFBZSxPQUFhO0FBQzNDLFVBQVEsT0FBTztJQUNkLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUjtBQUNDLGFBQU8sU0FBUyxNQUFNLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUM7RUFDckQ7QUFDRDtBQVFNLFNBQVUsY0FDZixPQUNBLE9BQ0EsV0FDQSxPQUF1QjtBQUV2QixRQUFNLE1BQU0sT0FBTyxVQUFVLFdBQVcsTUFBTSxTQUFTLEVBQUUsSUFBSTtBQUM3RCxRQUFNLEtBQUssT0FBTyxjQUFjLFdBQVcsVUFBVSxTQUFTLEVBQUUsSUFBSTtBQUVwRSxNQUFJLFVBQVUsUUFBVztBQUN4QixVQUFNLEtBQUssT0FBTyxVQUFVLFdBQVcsTUFBTSxTQUFTLEVBQUUsSUFBSTtBQUM1RCxXQUFPLEdBQUcsS0FBSyxJQUFJLEdBQUcsSUFBSSxFQUFFLElBQUksRUFBRTtFQUNuQztBQUVBLFNBQU8sR0FBRyxLQUFLLElBQUksR0FBRyxJQUFJLEVBQUU7QUFDN0I7QUFTTSxTQUFVLE1BQU0sT0FBZSxZQUFZLEdBQUM7QUFDakQsU0FBTyxLQUFLLE1BQU0sU0FBUyxFQUFFLEVBQUUsU0FBUyxXQUFXLEdBQUcsQ0FBQztBQUN4RDtBQU9NLFNBQVUsV0FBVyxPQUF3QjtBQUNsRCxTQUFPLEtBQUssTUFBTSxLQUFLLEtBQUssRUFDMUIsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRSxDQUFDO0FBQ1g7QUFTTSxTQUFVLGVBQWUsR0FBVyxHQUFXLEdBQVM7QUFDN0QsU0FBTyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUMsRUFDakIsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRSxFQUNQLFlBQVcsQ0FBRTtBQUNoQjtBQVFNLFNBQVUsZUFBZSxJQUFVO0FBQ3hDLFFBQU0sQ0FBQyxPQUFPLFVBQVUsS0FBSyxJQUFJLEdBQUcsTUFBTSxHQUFHO0FBQzdDLFNBQU87SUFDTjtJQUNBLE9BQU8sU0FBUyxVQUFVLEVBQUU7SUFDNUIsUUFBUSxTQUFTLE9BQU8sRUFBRTs7QUFFNUI7QUFVTSxTQUFVLGNBQWMsUUFBZ0IsUUFBYztBQUMzRCxRQUFNLEtBQUssU0FBUyxPQUFPLFFBQVEsT0FBTyxFQUFFLEdBQUcsRUFBRTtBQUNqRCxRQUFNLEtBQUssU0FBUyxPQUFPLFFBQVEsT0FBTyxFQUFFLEdBQUcsRUFBRTtBQUNqRCxNQUFJLE9BQU8sTUFBTSxFQUFFLEtBQUssT0FBTyxNQUFNLEVBQUU7QUFBRyxXQUFPO0FBQ2pELFNBQU8sS0FBSyxJQUFJLEtBQUssRUFBRTtBQUN4QjtBQVNNLFNBQVUscUJBQ2YsWUFBK0I7QUFFL0IsUUFBTSxhQUFrRSxDQUFBO0FBQ3hFLGFBQVcsQ0FBQyxPQUFPLElBQUksS0FBSyxPQUFPLFFBQVEsVUFBVSxHQUFHO0FBQ3ZELGVBQVcsS0FBSyxJQUFJO01BQ25CLE9BQU8sS0FBSztNQUNaLFdBQVcsTUFBTSxRQUFRLEtBQUssU0FBUyxJQUFJLEtBQUssWUFBWSxDQUFBOztFQUU5RDtBQUNBLFNBQU87QUFDUjtBQVlNLFNBQVUscUJBQ2YsU0FDQSxPQUNBLE9BQ0EsV0FBaUI7QUFFakIsUUFBTSxTQUFTLFFBQVEsS0FBSztBQUM1QixNQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sUUFBUSxPQUFPLFNBQVM7QUFBRyxXQUFPO0FBR3hELE1BQUksU0FBUyxPQUFPLFVBQVUsS0FBSyxDQUFDLE1BQVcsRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFHdkYsTUFBSSxDQUFDLFFBQVE7QUFDWixhQUFTLE9BQU8sVUFBVSxLQUFLLENBQUMsTUFBVTtBQUN6QyxVQUFJLEVBQUUsV0FBVztBQUFPLGVBQU87QUFDL0IsWUFBTSxjQUFjLEVBQUUsU0FBUyxLQUFLLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUNwRSxVQUFJLENBQUMsYUFBYTtBQUFTLGVBQU87QUFFbEMsWUFBTSxTQUFTLFlBQVksRUFBRTtBQUM3QixhQUFPLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sTUFBTTtJQUM1RCxDQUFDO0VBQ0Y7QUFFQSxTQUFPO0FBQ1I7OztBQzVMQSxTQUFTLFlBQVksR0FBTTtBQUMxQixRQUFNLE9BQU87SUFDWixNQUFNLEVBQUU7SUFDUixJQUFJLEVBQUU7SUFDTixPQUFPLEVBQUU7SUFDVCxTQUFTLEVBQUU7SUFDWCxTQUFTLEVBQUU7O0FBR1osVUFBUSxFQUFFLE1BQU07SUFDZixLQUFLO0FBQ0osYUFBTyxFQUFFLEdBQUcsTUFBTSxTQUFTLEVBQUUsV0FBVyxDQUFBLEVBQUU7SUFFM0MsS0FBSztBQUNKLGFBQU87UUFDTixHQUFHO1FBQ0gsS0FBSyxFQUFFO1FBQ1AsS0FBSyxFQUFFO1FBQ1AsTUFBTSxFQUFFLFFBQVE7UUFDaEIsT0FBTzs7SUFHVCxLQUFLO0FBQ0osYUFBTyxFQUFFLEdBQUcsTUFBTSxTQUFTLEVBQUUsV0FBVyxNQUFLO0lBRTlDLEtBQUs7QUFDSixhQUFPLEVBQUUsR0FBRyxNQUFNLE9BQU8sRUFBRSxTQUFTLEdBQUU7SUFFdkMsS0FBSztJQUNMLEtBQUs7SUFDTDtBQUNDLGFBQU87RUFDVDtBQUNEO0FBTU0sU0FBVSxlQUFZO0FBQzNCLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsUUFBTSxVQUFzQyxDQUFBO0FBRTVDLGFBQVcsQ0FBQyxPQUFPLE1BQU0sS0FBSyxPQUFPLFFBQVEsT0FBTyxHQUFHO0FBQ3RELFVBQU0sWUFBWSxPQUFPO0FBQ3pCLFFBQUksQ0FBQyxNQUFNLFFBQVEsU0FBUztBQUFHO0FBRS9CLGVBQVcsS0FBSyxXQUFXO0FBRTFCLFVBQUksRUFBRSxhQUFhO0FBQU07QUFFekIsWUFBTSxXQUFXLGNBQWMsT0FBTyxFQUFFLFFBQVEsRUFBRSxFQUFFO0FBR3BELFlBQU0sbUJBQW1CLEVBQUUsV0FBVyxDQUFBLEdBQUksSUFBSSxXQUFXO0FBQ3pELFlBQU0sVUFBVSxFQUFFLFVBQVUsU0FBWSxnQkFBZ0IsT0FBTyxDQUFDLE1BQVcsRUFBRSxPQUFPLE9BQU8sSUFBSTtBQUUvRixZQUFNLFNBQW9DO1FBQ3pDLE1BQU0sU0FBUyxLQUFLLEtBQUssRUFBRSxJQUFJO1FBQy9CO1FBQ0EsVUFBVSxZQUFXO1FBRXJCOztBQUdELGNBQVEsUUFBUSxJQUFJO0lBQ3JCO0VBQ0Q7QUFFQSxTQUFPO0FBQ1I7QUFXQSxTQUFTLGtCQUFrQixTQUFZO0FBQ3RDLFFBQU0sV0FBVyxRQUFRLFNBQVMsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE9BQU87QUFDbkUsTUFBSSxDQUFDO0FBQVUsV0FBTztBQUN0QixNQUFJLFNBQVMsU0FBUztBQUFZLFdBQU87QUFDekMsTUFBSSxTQUFTLFNBQVMsY0FBYyxDQUFDLE1BQU0sUUFBUSxTQUFTLE9BQU87QUFBRyxXQUFPO0FBQzdFLE1BQUksU0FBUyxRQUFRLFdBQVc7QUFBRyxXQUFPO0FBQzFDLFFBQU0sU0FBUyxTQUFTLFFBQVEsSUFBSSxDQUFDLE1BQVcsT0FBTyxFQUFFLEtBQUssRUFBRSxZQUFXLENBQUU7QUFDN0UsU0FBTyxPQUFPLFNBQVMsS0FBSyxLQUFLLE9BQU8sU0FBUyxJQUFJO0FBQ3REO0FBRU0sU0FBVSxpQkFBYztBQUM3QixRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFFBQU0sWUFBMEMsQ0FBQTtBQUVoRCxhQUFXLENBQUMsT0FBTyxNQUFNLEtBQUssT0FBTyxRQUFRLE9BQU8sR0FBRztBQUN0RCxVQUFNLFlBQVksT0FBTztBQUN6QixRQUFJLENBQUMsTUFBTSxRQUFRLFNBQVM7QUFBRztBQUUvQixlQUFXLFdBQVcsV0FBVztBQUVoQyxVQUFJLFFBQVEsY0FBYztBQUFNO0FBRWhDLFlBQU0saUJBQWlCLGNBQWMsT0FBTyxRQUFRLFFBQVEsUUFBUSxFQUFFO0FBR3RFLFVBQUksUUFBUSxVQUFVLFFBQVc7QUFDaEMsY0FBTSxnQkFBZ0IsUUFBUSxXQUFXLENBQUEsR0FDdkMsSUFBSSxXQUFXLEVBQ2YsT0FBTyxDQUFDLFFBQWEsSUFBSSxPQUFPLFdBQVcsSUFBSSxPQUFPLE9BQU87QUFFL0Qsa0JBQVUsY0FBYyxJQUFJO1VBQzNCLE1BQU07VUFDTixNQUFNLFNBQVMsS0FBSyxLQUFLLFFBQVEsSUFBSTtVQUNyQyxjQUFjO1lBQ2IsU0FBUyxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBQzdCLE9BQU8sV0FBVyxHQUFHLEdBQUcsQ0FBQzs7VUFFMUIsU0FBUztVQUNULFVBQVUsTUFBSztBQUVkLG1CQUFPO1VBQ1I7O0FBRUQ7TUFDRDtBQUdBLFlBQU0sY0FBYyxRQUFRLFdBQVcsQ0FBQSxHQUFJLElBQUksV0FBVztBQUcxRCxZQUFNLGVBQWUsV0FBVyxPQUFPLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUl2RSxZQUFNLGlCQUFpQixRQUFRLFNBQVMsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLFdBQVcsRUFBRSxTQUFTLGFBQWE7QUFDckcsVUFBSSxDQUFDLGdCQUFnQjtBQUNwQixxQkFBYSxLQUFLO1VBQ2pCLE1BQU07VUFDTixJQUFJO1VBQ0osT0FBTztVQUNQLFNBQVM7VUFDVCxTQUFTO1NBQ1Q7TUFDRjtBQUdBLFlBQU0sZ0JBQXFCO1FBQzFCLE1BQU07UUFDTixNQUFNLFNBQVMsS0FBSyxLQUFLLFFBQVEsSUFBSTtRQUNyQyxTQUFTO1FBQ1QsVUFBVSxNQUFLO0FBRWQsaUJBQU87UUFDUjs7QUFHRCxnQkFBVSxjQUFjLElBQUk7QUFHNUIsVUFBSSxrQkFBa0IsT0FBTyxHQUFHO0FBQy9CLGNBQU0saUJBQWlCLEdBQUcsY0FBYztBQUd4QyxjQUFNLGNBQWMsV0FBVyxPQUFPLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUV0RSxjQUFNLGVBQW9CO1VBQ3pCLE1BQU07VUFDTixNQUFNLFNBQVMsS0FBSyxLQUFLLFFBQVEsSUFBSTtVQUNyQyxjQUFjO1lBQ2IsU0FBUyxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBQzdCLE9BQU8sV0FBVyxHQUFHLEdBQUcsQ0FBQzs7VUFFMUIsU0FBUztVQUNULFVBQVUsTUFBSztBQUVkLG1CQUFPO1VBQ1I7O0FBR0Qsa0JBQVUsY0FBYyxJQUFJO01BQzdCO0lBQ0Q7RUFDRDtBQUVBLFNBQU87QUFDUjs7O0FDeE1BLE9BQU9DLFdBQVU7OztBQ0xqQixPQUFPQyxTQUFRO0FBZ0JmLElBQU1DLFVBQVMsbUJBQW1CLGdCQUFnQjtBQTJDbEQsU0FBUyxVQUFVLE9BQWE7QUFDL0IsUUFBTSxTQUFTLG9CQUFJLElBQUc7QUFDdEIsTUFBSTtBQUNILFVBQU0sT0FBTyxnQkFBZ0IsS0FBSztBQUNsQyxRQUFJLENBQUM7QUFBTSxhQUFPO0FBQ2xCLGVBQVcsVUFBVSxLQUFLLGFBQWEsQ0FBQSxHQUFJO0FBQzFDLFlBQU0saUJBQWlCLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBd0IsSUFBSSxTQUFTLGFBQWE7QUFDL0YsVUFBSSxnQkFBZ0I7QUFDbkIsZUFBTyxJQUFJLE9BQU8sRUFBRTtBQUNwQixjQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUF3QixJQUFJLE9BQU8sT0FBTztBQUNwRixZQUFJLGFBQWEsU0FBUztBQUN6QixxQkFBVyxVQUFVLFlBQVksU0FBUztBQUN6QyxnQkFBSSxPQUFPLE9BQU8sT0FBTyxVQUFVO0FBQ2xDLHFCQUFPLElBQUksT0FBTyxLQUFLLE9BQU8sRUFBRTtZQUNqQztVQUNEO1FBQ0Q7TUFDRDtJQUNEO0VBQ0QsU0FBUyxNQUFNO0VBRWY7QUFDQSxTQUFPO0FBQ1I7QUFNQSxTQUFTLHNCQUFzQixLQUFXO0FBQ3pDLFFBQU0sV0FBVyxJQUFJLFFBQVEsT0FBTyxLQUFLLFVBQVUsQ0FBQztBQUNwRCxNQUFJLFdBQVc7QUFBRyxVQUFNLElBQUksTUFBTSxpQ0FBaUM7QUFFbkUsUUFBTSxlQUFlLFdBQVc7QUFDaEMsTUFBSSxJQUFJLFlBQVksTUFBTSxJQUFNO0FBQy9CLFVBQU0sSUFBSSxNQUFNLHVDQUF1QyxJQUFJLFlBQVksRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFO0VBQ3hGO0FBRUEsU0FBTztBQUNSO0FBTUEsU0FBUyw4QkFBOEIsS0FBYSxPQUFhO0FBQ2hFLFFBQU0sTUFBTSxzQkFBc0IsR0FBRztBQUNyQyxRQUFNLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSTtBQUM3QixNQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQU0sSUFBSSxNQUFNLDRCQUE0QjtFQUM3QztBQUdBLE1BQUksSUFBSSxVQUFVLHVCQUF1QixNQUFNLElBQUksTUFBTTtBQUN6RCxRQUFNLE1BQU0sSUFBSSxTQUFTO0FBQ3pCLFFBQU0sTUFBdUIsQ0FBQTtBQUU3QixRQUFNLFNBQVMsVUFBVSxLQUFLO0FBSTlCLFFBQU0sb0JBQW9CLENBQUMsYUFBYSxpQkFBaUIsV0FBVztBQUtwRSxRQUFNLG1CQUFtQixDQUFDLFdBQVc7QUFFckMsU0FBTyxJQUFJLElBQUksS0FBSztBQUNuQixVQUFNLFNBQVMsSUFBSSxDQUFDO0FBQ3BCLFVBQU0sZUFBZSxJQUFJLElBQUksQ0FBQztBQUU5QixVQUFNLGFBQWEsSUFBSSxJQUFJO0FBQzNCLFFBQUksYUFBYTtBQUFLO0FBRXRCLFVBQU0sV0FBVyxrQkFBa0IsU0FBUyxZQUFZO0FBQ3hELFVBQU0sYUFBYSxpQkFBaUIsU0FBUyxZQUFZO0FBRXpELFFBQUk7QUFDSixRQUFJO0FBQ0osUUFBSTtBQUVKLFFBQUksWUFBWTtBQVFmLGNBQVEsSUFBSSxJQUFJLENBQUM7QUFDakIsWUFBTSxXQUFXLElBQUksU0FBUyxJQUFJLEdBQUcsVUFBVTtBQUUvQyxZQUFNLFNBQVMsZ0JBQWdCLEtBQUs7QUFDcEMsWUFBTSxpQkFBaUIsUUFBUSxhQUFhLENBQUEsR0FDMUMsT0FBTyxDQUFDLE9BQWlCLEVBQUUsV0FBVyxlQUFlLEVBQUUsV0FBVyxvQkFBb0IsRUFBRSxVQUFVLE1BQVMsRUFDM0csS0FBSyxDQUFDLEdBQWEsTUFBZ0IsRUFBRSxLQUFLLEVBQUUsRUFBRTtBQUVoRCxlQUFTLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0FBQ3pDLGNBQU0sUUFBUSxjQUFjLENBQUM7QUFDN0IsWUFBSSxPQUFPO0FBQ1YsY0FBSSxLQUFLLEVBQUUsUUFBUSxNQUFNLFFBQVEsSUFBSSxNQUFNLElBQUksT0FBTyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBQyxDQUFFO1FBQ2xGO01BRUQ7QUFDQSxVQUFJO0FBQ0o7SUFDRCxXQUFXLFVBQVU7QUFFcEIsY0FBUSxJQUFJLElBQUksQ0FBQztBQUNqQixnQkFBVSxJQUFJLElBQUksQ0FBQztBQUNuQixVQUFJLElBQUk7SUFDVCxPQUFPO0FBRU4sZ0JBQVUsSUFBSSxJQUFJLENBQUM7QUFDbkIsVUFBSSxJQUFJO0lBQ1Q7QUFFQSxVQUFNLE9BQU8sSUFBSTtBQUNqQixVQUFNLFNBQVM7QUFFZixXQUFPLElBQUksSUFBSSxNQUFNO0FBQ3BCLFlBQU0sS0FBSyxJQUFJLENBQUM7QUFDaEIsVUFBSTtBQUdKLFVBQUksT0FBTyxJQUFJLEVBQUUsS0FBSyxJQUFJLElBQUksTUFBTTtBQUNuQyxxQkFBYSxDQUFDLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBQ2hELGFBQUs7TUFDTixPQUFPO0FBQ04scUJBQWEsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBQ3hCLGFBQUs7TUFDTjtBQUVBLFlBQU0sVUFBeUI7UUFDOUIsUUFBUTtRQUNSO1FBQ0E7O0FBRUQsVUFBSSxVQUFVLFFBQVc7QUFDeEIsZ0JBQVEsUUFBUTtNQUNqQjtBQUNBLFVBQUksS0FBSyxPQUFPO0lBQ2pCO0FBUUEsUUFBSSxNQUFNLFVBQVUsYUFBYSxJQUFJLEdBQUc7QUFDdkMsVUFBSSxNQUFNLFdBQVcsSUFBSSxJQUFJLElBQUk7QUFDakMsVUFBSSxRQUFRO0FBQ1osYUFBTyxNQUFNLFlBQVk7QUFDeEIsY0FBTSxVQUF5QixFQUFFLFFBQVEsY0FBYyxJQUFJLFNBQVMsWUFBWSxDQUFDLElBQUksS0FBSyxDQUFDLEVBQUM7QUFDNUYsWUFBSSxVQUFVO0FBQVcsa0JBQVEsUUFBUTtBQUN6QyxZQUFJLEtBQUssT0FBTztNQUNqQjtJQUNEO0FBRUEsUUFBSTtFQUNMO0FBRUEsU0FBTztBQUNSO0FBV00sU0FBVSxzQkFBc0IsT0FBZSxLQUFXO0FBQy9ELFFBQU0sTUFBTSxzQkFBc0IsR0FBRztBQUNyQyxRQUFNLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSTtBQUM3QixNQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQU0sSUFBSSxNQUFNLGlDQUFpQyxNQUFNLFNBQVMsRUFBRSxDQUFDLEdBQUc7RUFDdkU7QUFDQSxTQUFPLDhCQUE4QixLQUFLLEtBQUs7QUFDaEQ7QUFNTSxTQUFVLG9CQUFvQixTQUF3QixTQUFtQjtBQUU5RSxNQUFJLFNBQVMsUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsUUFBUSxVQUFVLEVBQUUsT0FBTyxRQUFRLEVBQUU7QUFLbkYsTUFBSSxDQUFDLFFBQVE7QUFDWixVQUFNLGFBQWEsUUFBUSxLQUFLLENBQUMsTUFBSztBQUNyQyxVQUFJLEVBQUUsV0FBVyxRQUFRO0FBQVEsZUFBTztBQUV4QyxZQUFNLGNBQWMsRUFBRSxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQy9ELFVBQUksQ0FBQyxhQUFhO0FBQVMsZUFBTztBQUVsQyxZQUFNLGdCQUFnQixRQUFRLEtBQUssRUFBRTtBQUNyQyxhQUFPLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sYUFBYTtJQUM5RCxDQUFDO0FBQ0QsUUFBSSxZQUFZO0FBQ2YsZUFBUztJQUNWO0VBQ0Q7QUFFQSxRQUFNLFNBQVMsTUFBTSxRQUFRLE1BQU07QUFDbkMsUUFBTSxRQUFRLE1BQU0sUUFBUSxFQUFFO0FBQzlCLFFBQU0sU0FBUyxXQUFXLFFBQVEsVUFBVTtBQUM1QyxRQUFNLFNBQ0wsUUFBUSxXQUFXLFdBQVcsSUFDM0IsZUFBZSxRQUFRLFdBQVcsQ0FBQyxHQUFHLFFBQVEsV0FBVyxDQUFDLEdBQUcsUUFBUSxXQUFXLENBQUMsQ0FBQyxJQUNsRixRQUFRLFdBQVcsV0FBVyxJQUM3QixRQUFRLFdBQVcsQ0FBQyxJQUNwQixRQUFRLFdBQVcsS0FBSyxHQUFHO0FBR2hDLFFBQU0sV0FBVyxRQUFRLFVBQVUsU0FBWSxPQUFPLFFBQVEsS0FBSyxLQUFLO0FBQ3hFLFFBQU0sU0FBUyxPQUFPLE1BQU0sR0FBRyxRQUFRLE9BQU8sS0FBSyxRQUFRLE1BQU07QUFHakUsTUFBSSxRQUFRO0FBQ1gsUUFBSSxPQUFPLE9BQU87QUFHbEIsUUFBSSxRQUFRLFVBQVUsUUFBVztBQUNoQyxhQUFPLEdBQUcsSUFBSSxNQUFNLFFBQVEsUUFBUSxDQUFDO0lBQ3RDLE9BRUs7QUFDSixZQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQ3BFLFVBQUksYUFBYSxTQUFTO0FBQ3pCLGNBQU0sZ0JBQWdCLFFBQVEsS0FBSyxPQUFPO0FBQzFDLGNBQU0sY0FBYyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLGFBQWE7QUFDMUUsWUFBSSxhQUFhO0FBQ2hCLGlCQUFPLEdBQUcsSUFBSSxJQUFJLFlBQVksS0FBSztRQUNwQztNQUNEO0lBQ0Q7QUFHQSxVQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBRXBFLFVBQU0sYUFBYyxPQUFlO0FBQ25DLFFBQUksZUFBZSxVQUFhLGdCQUFnQixRQUFXO0FBQzFELGFBQU8sR0FBRyxNQUFNLE1BQU0sSUFBSSxLQUFLLFVBQVU7SUFDMUM7QUFDQSxRQUFJLGFBQWEsV0FBVyxRQUFRLFdBQVcsV0FBVyxHQUFHO0FBQzVELFlBQU0sU0FBUyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsV0FBVyxDQUFDLENBQUM7QUFDN0UsVUFBSSxRQUFRO0FBQ1gsZUFBTyxHQUFHLE1BQU0sTUFBTSxJQUFJLEtBQUssT0FBTyxLQUFLLEtBQUssTUFBTTtNQUN2RDtJQUNEO0FBQ0EsV0FBTyxHQUFHLE1BQU0sTUFBTSxJQUFJLEtBQUssTUFBTTtFQUN0QztBQUdBLFNBQU8sR0FBRyxNQUFNO0FBQ2pCO0FBV00sU0FBVSxpQ0FDZixPQUNBLEtBQVc7QUFFWCxRQUFNLFdBQVcsOEJBQThCLEtBQUssS0FBSztBQUN6RCxTQUFPLEVBQUUsVUFBVSxtQkFBbUIsS0FBSTtBQUMzQztBQUVNLFNBQVUsNEJBQTRCLE9BQWUsS0FBVztBQUNyRSxTQUFPLDhCQUE4QixLQUFLLEtBQUs7QUFDaEQ7QUFNQSxTQUFTLG1CQUFtQixZQUFvQjtBQUMvQyxNQUFJLFdBQVcsV0FBVyxHQUFHO0FBQzVCLFdBQU8sRUFBRSxJQUFJLFNBQVMsT0FBTyxTQUFTLE1BQU0sVUFBVSxTQUFTLFdBQVcsQ0FBQyxFQUFDO0VBQzdFO0FBRUEsTUFBSSxXQUFXLFdBQVcsR0FBRztBQUM1QixVQUFNLENBQUMsR0FBRyxHQUFHLENBQUMsSUFBSTtBQUNsQixXQUFPO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxNQUFNO01BQ04sU0FBUyxlQUFlLEdBQUcsR0FBRyxDQUFDOztFQUVqQztBQUVBLFNBQU8sRUFBRSxJQUFJLFNBQVMsT0FBTyxTQUFTLE1BQU0sT0FBTyxTQUFTLENBQUMsR0FBRyxVQUFVLEVBQUM7QUFDNUU7QUFNTSxTQUFVLDRCQUNmLFdBQ0EsUUFDQSxXQUFzQztBQUV0QyxRQUFNLE1BQU0sZ0JBQWdCLFNBQVM7QUFHckMsTUFBSSxDQUFDLElBQUksV0FBVztBQUNuQixRQUFJLFlBQVksQ0FBQTtFQUNqQjtBQUdBLFFBQU0sYUFBYSxPQUFPLE9BQU8sU0FBUyxFQUN4QyxPQUFPLENBQUMsTUFBTSxFQUFFLFVBQVUsVUFBVSxLQUFLLEVBQ3pDLEtBQUssQ0FBQyxHQUFHLE1BQU0sY0FBYyxVQUFVLE9BQU8sRUFBRSxLQUFLLElBQUksY0FBYyxVQUFVLE9BQU8sRUFBRSxLQUFLLENBQUM7QUFFbEcsRUFBQUEsUUFBTyxLQUFLLG1CQUFtQixVQUFVLEtBQUssRUFBRTtBQUNoRCxFQUFBQSxRQUFPLE1BQU0sNkJBQTZCLFdBQVcsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsS0FBSyxJQUFJLENBQUMsRUFBRTtBQUtyRixRQUFNLG1CQUFtQixvQkFBSSxJQUFHO0FBQ2hDLGFBQVcsS0FBSyxZQUFZO0FBQzNCLGVBQVcsYUFBYSxFQUFFLGFBQWEsQ0FBQSxHQUFJO0FBQzFDLFlBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE9BQU87QUFDckUsVUFBSSxDQUFDLFVBQVU7QUFBUztBQUN4QixZQUFNLFNBQVMsVUFBVTtBQUN6QixZQUFNLFFBQVEsVUFBVTtBQUN4QixZQUFNLE1BQU0sR0FBRyxLQUFLLElBQUksTUFBTTtBQUM5QixVQUFJLGlCQUFpQixJQUFJLEdBQUc7QUFBRztBQUUvQixZQUFNLGdCQUFnQixPQUNwQixPQUFPLENBQUMsTUFBTSxFQUFFLFdBQVcsU0FBUyxFQUFFLEtBQUssTUFBTSxFQUNqRCxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssTUFBTSxFQUN4QixLQUFLLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQztBQUV0QixVQUFJLFNBQVM7QUFDYixpQkFBVyxPQUFPLGVBQWU7QUFDaEMsWUFBSSxRQUFRLFNBQVM7QUFBRyxtQkFBUztpQkFDeEIsTUFBTSxTQUFTO0FBQUc7TUFDNUI7QUFDQSxVQUFJLFNBQVMsR0FBRztBQUNmLHlCQUFpQixJQUFJLEtBQUssTUFBTTtBQUNoQyxRQUFBQSxRQUFPLE1BQU0sZ0NBQWdDLE1BQU0sS0FBSyxDQUFDLFlBQVksTUFBTSxNQUFNLENBQUMsb0JBQWUsTUFBTSxFQUFFO01BQzFHO0lBQ0Q7RUFDRDtBQUlBLFFBQU0sWUFBWSxvQkFBSSxJQUFHO0FBQ3pCLGFBQVcsRUFBRSxRQUFRLElBQUksTUFBSyxLQUFNLFFBQVE7QUFDM0MsUUFBSSxVQUFVO0FBQVc7QUFDekIsVUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLEVBQUU7QUFDM0IsUUFBSSxDQUFDLFVBQVUsSUFBSSxHQUFHO0FBQUcsZ0JBQVUsSUFBSSxLQUFLLG9CQUFJLElBQUcsQ0FBRTtBQUNyRCxjQUFVLElBQUksR0FBRyxFQUFHLElBQUksS0FBSztFQUM5QjtBQU1BLGFBQVcsRUFBRSxRQUFRLElBQUksT0FBTyxXQUFVLEtBQU0sUUFBUTtBQUV2RCxVQUFNLGdCQUFnQixJQUFJLFVBQVUsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUU7QUFDbEYsUUFBSSxlQUFlO0FBQ2xCLFlBQU0sTUFBTSxjQUFjLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDL0QsVUFBSTtBQUFLLFlBQUksVUFBVSxtQkFBbUIsVUFBVSxFQUFFO0FBR3RELFlBQU0sa0JBQWtCLFVBQVUsSUFBSSxHQUFHLE1BQU0sSUFBSSxFQUFFLEVBQUU7QUFDdkQsVUFBSSxtQkFBbUIsZ0JBQWdCLE9BQU8sR0FBRztBQUNoRCxjQUFNLFdBQVcsS0FBSyxJQUFJLEdBQUcsZUFBZTtBQUM1QyxjQUFNLGlCQUFpQixjQUFjLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDMUUsWUFBSSxhQUFhLEtBQUssY0FBYyxVQUFVLFVBQWEsQ0FBQyxnQkFBZ0I7QUFDM0Usd0JBQWMsUUFBUTtBQUN0QixVQUFBQSxRQUFPLEtBQUssNkNBQTZDLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsRUFBRTtRQUN6RjtNQUNEO0FBQ0E7SUFDRDtBQUtBLFVBQU0sWUFBWSxJQUFJLFVBQVUsS0FBSyxDQUFDLE1BQUs7QUFDMUMsVUFBSSxFQUFFLFdBQVc7QUFBUSxlQUFPO0FBQ2hDLFlBQU0sV0FBVyxFQUFFLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDeEQsVUFBSSxDQUFDLFVBQVU7QUFBUyxlQUFPO0FBQy9CLFVBQUksTUFBTSxFQUFFO0FBQUksZUFBTztBQUN2QixZQUFNLFNBQVMsS0FBSyxFQUFFO0FBRXRCLGFBQU8sV0FBVyxLQUFLLENBQUMsTUFBSztBQUM1QixjQUFNLFdBQVcsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxFQUFFLEVBQUU7QUFDOUUsY0FBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUNoRSxlQUFPLFVBQVUsU0FBUyxLQUFLLENBQUMsT0FBWSxHQUFHLE9BQU8sTUFBTTtNQUM3RCxDQUFDO0lBQ0YsQ0FBQztBQUNELFFBQUksV0FBVztBQUNkLFlBQU0sU0FBUyxLQUFLLFVBQVU7QUFDOUIsWUFBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUNoRSxVQUFJLFVBQVUsV0FBVyxDQUFDLFNBQVMsUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sTUFBTSxHQUFHO0FBQzdFLFlBQUksUUFBUSxXQUFXLFNBQVMsQ0FBQztBQUNqQyxtQkFBVyxLQUFLLFlBQVk7QUFDM0IsZ0JBQU0sV0FBVyxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLFVBQVUsRUFBRTtBQUN0RixnQkFBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUNoRSxnQkFBTSxZQUFZLFVBQVUsU0FBUyxLQUFLLENBQUMsT0FBWSxHQUFHLE9BQU8sTUFBTTtBQUN2RSxjQUFJLFdBQVc7QUFDZCxvQkFBUSxVQUFVO0FBQ2xCO1VBQ0Q7UUFDRDtBQUNBLGlCQUFTLFFBQVEsS0FBSyxFQUFFLElBQUksUUFBUSxNQUFLLENBQUU7QUFDM0MsUUFBQUEsUUFBTyxLQUNOLGlCQUFpQixNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLHVCQUF1QixNQUFNLFVBQVUsRUFBRSxDQUFDLGNBQWMsTUFBTSxNQUFNLEtBQUssSUFBSTtNQUU3SDtBQUNBO0lBQ0Q7QUFHQSxRQUFJO0FBRUosZUFBVyxLQUFLLFlBQVk7QUFDM0IsWUFBTSxRQUFRLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRTtBQUN6RSxVQUFJLE9BQU87QUFDVixpQkFBUyxnQkFBZ0IsS0FBSztBQUU5QixjQUFNLFdBQVcsTUFBTSxLQUFLLFFBQVEscUNBQXFDLEVBQUUsRUFBRSxLQUFJO0FBQ2pGLGVBQU8sT0FBTyxHQUFHLFFBQVEseUJBQXlCLEVBQUUsS0FBSztBQUN6RCxRQUFBQSxRQUFPLEtBQUssbUJBQW1CLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsZUFBZSxFQUFFLEtBQUssVUFBVTtBQUM1RjtNQUNEO0lBQ0Q7QUFJQSxRQUFJLENBQUMsUUFBUTtBQUNaLFVBQUksY0FBYztBQUNsQixpQkFBVyxLQUFLLFlBQVk7QUFDM0IsY0FBTSxZQUFZLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBVTtBQUM5QyxjQUFJLEVBQUUsV0FBVztBQUFRLG1CQUFPO0FBQ2hDLGdCQUFNLFdBQVcsRUFBRSxTQUFTLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxPQUFPO0FBQzdELGNBQUksQ0FBQyxVQUFVO0FBQVMsbUJBQU87QUFDL0IsY0FBSSxNQUFNLEVBQUU7QUFBSSxtQkFBTztBQUN2QixnQkFBTSxTQUFTLEtBQUssRUFBRTtBQUN0QixnQkFBTSxTQUFTLGlCQUFpQixJQUFJLEdBQUcsTUFBTSxJQUFJLEVBQUUsRUFBRSxFQUFFLEtBQUs7QUFDNUQsaUJBQU8sVUFBVTtRQUNsQixDQUFDO0FBQ0QsWUFBSSxXQUFXO0FBQ2Qsd0JBQWM7QUFDZCxVQUFBQSxRQUFPLE1BQ04sVUFBVSxNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLDRDQUE0QyxNQUFNLFVBQVUsRUFBRSxDQUFDLDZCQUF3QjtBQUUvSDtRQUNEO01BQ0Q7QUFDQSxVQUFJO0FBQWE7SUFDbEI7QUFHQSxRQUFJLENBQUMsUUFBUTtBQUNaLGVBQVM7UUFDUjtRQUNBO1FBQ0EsTUFBTSxlQUFlLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLEVBQUUsWUFBVyxDQUFFO1FBQ2hFLFNBQVMsQ0FBQyxtQkFBbUIsVUFBVSxDQUFDOztBQUV6QyxVQUFJLFVBQVU7QUFBVyxlQUFPLFFBQVE7QUFDeEMsTUFBQUEsUUFBTyxLQUFLLDBCQUEwQixNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLEVBQUU7SUFDdEUsT0FBTztBQUlOLGFBQU8sVUFBVSxPQUFPLFNBQVMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU8sS0FBSyxDQUFBO0FBQ3BFLGFBQU8sT0FBTztBQUVkLFlBQU0sa0JBQWtCLFVBQVUsSUFBSSxHQUFHLE1BQU0sSUFBSSxFQUFFLEVBQUU7QUFDdkQsVUFBSSxtQkFBbUIsZ0JBQWdCLE9BQU8sR0FBRztBQUNoRCxjQUFNLFdBQVcsS0FBSyxJQUFJLEdBQUcsZUFBZTtBQUM1QyxZQUFJLGFBQWEsR0FBRztBQUVuQixpQkFBTyxRQUFRO1FBQ2hCLE9BQU87QUFFTixnQkFBTSxlQUFlLE1BQU0sS0FBSyxFQUFFLFFBQVEsV0FBVyxFQUFDLEdBQUksQ0FBQyxHQUFHLE9BQU87WUFDcEUsSUFBSTtZQUNKLE9BQU8sV0FBVyxJQUFJLENBQUM7WUFDdEI7QUFDRixpQkFBTyxRQUFRLFFBQVE7WUFDdEIsSUFBSTtZQUNKLE9BQU87WUFDUCxNQUFNO1lBQ04sU0FBUztZQUNULFNBQVM7V0FDVDtRQUNGO01BQ0Q7QUFNQSxZQUFNLGtCQUFrQixtQkFBbUIsVUFBVSxFQUFFO0FBQ3ZELFlBQU0sV0FBVyxPQUFPLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDN0QsVUFBSSxVQUFVO0FBQ2IsWUFBSSxTQUFTLFdBQVcsTUFBTSxRQUFRLFNBQVMsT0FBTyxHQUFHO0FBQ3hELGdCQUFNLFlBQVksU0FBUyxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxlQUFlO0FBQzVFLGNBQUksQ0FBQyxXQUFXO0FBQ2YsWUFBQUEsUUFBTyxLQUNOLCtCQUErQixNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLGlDQUFpQyxlQUFlLHNDQUFpQztBQUc5SSxxQkFBUyxPQUFPO0FBQ2hCLG1CQUFRLFNBQWlCO1VBQzFCO1FBQ0Q7QUFDQSxpQkFBUyxVQUFVO01BQ3BCO0lBQ0Q7QUFFQSxRQUFJLFVBQVUsS0FBSyxNQUFNO0VBQzFCO0FBU0EsYUFBVyxFQUFFLFFBQVEsR0FBRSxLQUFNLFFBQVE7QUFDcEMsVUFBTSxrQkFBa0IsSUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxFQUFFO0FBQ3BGLFFBQUk7QUFBaUI7QUFHckIsVUFBTSxZQUFZLElBQUksVUFBVSxLQUFLLENBQUMsTUFBSztBQUMxQyxVQUFJLEVBQUUsV0FBVztBQUFRLGVBQU87QUFDaEMsWUFBTUMsWUFBVyxFQUFFLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDeEQsYUFBTyxDQUFDLENBQUNBLFdBQVUsV0FBVyxLQUFLLEVBQUU7SUFDdEMsQ0FBQztBQUNELFFBQUksQ0FBQztBQUFXO0FBRWhCLFVBQU0sU0FBUyxLQUFLLFVBQVU7QUFDOUIsVUFBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUNoRSxRQUFJLENBQUMsVUFBVSxXQUFXLFNBQVMsUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sTUFBTTtBQUFHO0FBSTlFLFVBQU0sZUFBZSxXQUFXLEtBQUssQ0FBQyxNQUFLO0FBQzFDLFlBQU0sV0FBVyxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLFVBQVUsRUFBRTtBQUN0RixZQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLGFBQU8sVUFBVSxTQUFTLEtBQUssQ0FBQyxPQUFZLEdBQUcsT0FBTyxNQUFNO0lBQzdELENBQUM7QUFDRCxVQUFNLGtCQUFrQixTQUFTLFFBQVEsSUFBSSxDQUFDLE1BQVcsRUFBRSxFQUFZLEVBQUUsS0FBSyxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUM7QUFDN0YsVUFBTSxlQUFlLGdCQUFnQixTQUFTLEtBQUssV0FBVyxnQkFBZ0IsZ0JBQWdCLFNBQVMsQ0FBQyxJQUFJO0FBRTVHLFFBQUksQ0FBQyxnQkFBZ0IsQ0FBQztBQUFjO0FBR3BDLFFBQUksUUFBUSxXQUFXLFNBQVMsQ0FBQztBQUNqQyxlQUFXLEtBQUssWUFBWTtBQUMzQixZQUFNLFdBQVcsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxVQUFVLEVBQUU7QUFDdEYsWUFBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUNoRSxZQUFNLFlBQVksVUFBVSxTQUFTLEtBQUssQ0FBQyxPQUFZLEdBQUcsT0FBTyxNQUFNO0FBQ3ZFLFVBQUksV0FBVztBQUNkLGdCQUFRLFVBQVU7QUFDbEI7TUFDRDtJQUNEO0FBRUEsYUFBUyxRQUFRLEtBQUssRUFBRSxJQUFJLFFBQVEsTUFBSyxDQUFFO0FBQzNDLElBQUFELFFBQU8sS0FDTix5QkFBeUIsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyx1QkFBdUIsTUFBTSxVQUFVLEVBQUUsQ0FBQyxjQUFjLE1BQU0sTUFBTSxLQUFLLElBQUk7RUFFckk7QUFFQSxTQUFPO0FBQ1I7QUFNTSxTQUFVLG9CQUFvQixVQUFrQixTQUFvQjtBQUN6RSxNQUFJO0FBRUgsVUFBTSxhQUFrQixFQUFFLE9BQU8sUUFBUSxNQUFLO0FBRzlDLFFBQUksZUFBZSxTQUFTO0FBQzNCLGlCQUFXLFlBQVksUUFBUTtJQUNoQztBQUdBLFFBQUksZUFBZSxTQUFTO0FBQzNCLGlCQUFXLFlBQVksUUFBUSxVQUFVLElBQUksQ0FBQyxVQUFjO0FBRTNELGNBQU0sZUFBb0IsQ0FBQTtBQUMxQixZQUFJLFlBQVk7QUFBTyx1QkFBYSxTQUFTLE1BQU07QUFDbkQsWUFBSSxRQUFRO0FBQU8sdUJBQWEsS0FBSyxNQUFNO0FBQzNDLFlBQUksV0FBVztBQUFPLHVCQUFhLFFBQVEsTUFBTTtBQUNqRCxZQUFJLFVBQVU7QUFBTyx1QkFBYSxPQUFPLE1BQU07QUFDL0MsWUFBSSxXQUFXO0FBQU8sdUJBQWEsUUFBUSxNQUFNO0FBQ2pELFlBQUksYUFBYTtBQUFPLHVCQUFhLFVBQVUsTUFBTTtBQUVyRCxtQkFBVyxPQUFPLE9BQU8sS0FBSyxLQUFLLEdBQUc7QUFDckMsY0FBSSxFQUFFLE9BQU87QUFBZSx5QkFBYSxHQUFHLElBQUksTUFBTSxHQUFHO1FBQzFEO0FBQ0EsZUFBTztNQUNSLENBQUM7SUFDRjtBQUVBLGVBQVcsT0FBTyxPQUFPLEtBQUssT0FBTyxHQUFHO0FBQ3ZDLFVBQUksRUFBRSxPQUFPLGFBQWE7QUFDekIsbUJBQVcsR0FBRyxJQUFLLFFBQWdCLEdBQUc7TUFDdkM7SUFDRDtBQUdBLFFBQUksT0FBTyxLQUFLLFVBQVUsWUFBWSxNQUFNLENBQUM7QUFLN0MsV0FBTyxLQUFLLFFBQVEsMERBQTBELDZCQUE2QjtBQUUzRyxJQUFBRSxJQUFHLGNBQWMsVUFBVSxPQUFPLE1BQU0sTUFBTTtFQUMvQyxTQUFTLEdBQUc7QUFDWCxJQUFBRixRQUFPLE1BQU0scUJBQXFCLENBQUMsRUFBRTtFQUN0QztBQUNEOzs7QUR2ckJBLElBQU1HLFVBQVMsbUJBQW1CLFNBQVM7QUFFckMsU0FBVSxjQUFjLE1BQW9CO0FBQ2pELFFBQU0sYUFBYSxpQkFBZ0I7QUFDbkMsUUFBTSxhQUFhLGFBQVk7QUFDL0IsUUFBTSxVQUFVLHFCQUFxQixVQUFVO0FBQy9DLFFBQU0sZUFBb0IsQ0FBQTtBQUUxQixRQUFNLGNBQWMsS0FBSztBQU16QixNQUFJLEtBQUssT0FBTyxTQUFTO0FBQ3hCLGlCQUFhLHVCQUF1QixJQUFJO01BQ3ZDLE1BQU07TUFDTixhQUFhO01BQ2IsU0FBUyxDQUFBO01BQ1QsVUFBVSxZQUFXO0FBQ3BCLGNBQU0sUUFBUTtBQUNkLGNBQU0sS0FBSyxLQUFLO0FBRWhCLGNBQU0sTUFBTSxNQUFNLEtBQUssYUFBYSxtQkFBbUIsRUFBRTtBQUV6RCxZQUFJLFlBQVksZ0JBQWdCLEtBQUs7QUFFckMsY0FBTSxFQUFFLFVBQVUsT0FBTSxJQUFLLGlDQUFpQyxPQUFPLEdBQUc7QUFDeEUsUUFBQUEsUUFBTyxNQUFNLGlCQUFpQixLQUFLLFVBQVUsTUFBTSxDQUFDLEVBQUU7QUFFdEQsWUFBSSxDQUFDLFdBQVc7QUFDZixVQUFBQSxRQUFPLEtBQUssU0FBUyxLQUFLLHVEQUFrRDtBQUM1RSxzQkFBWTtZQUNYO1lBQ0EsV0FBVyxDQUFBOztRQUViO0FBRUEsY0FBTSxVQUFVLDRCQUE0QixXQUFXLFFBQVEsT0FBTztBQUN0RSxRQUFBQSxRQUFPLE1BQU0scUJBQXFCLEtBQUssVUFBVSxTQUFTLE1BQU0sQ0FBQyxDQUFDLEVBQUU7QUFFcEUsY0FBTUMsaUJBQWdCLGlCQUFnQjtBQUN0QyxjQUFNLGFBQWFDLE1BQUssS0FBS0QsZ0JBQWUsUUFBUSxLQUFLLE9BQU87QUFDaEUsNEJBQW9CLFlBQVksT0FBTztBQUV2Qyw0QkFBbUI7QUFFbkIsUUFBQUQsUUFBTyxLQUFLLFNBQVMsS0FBSyx3Q0FBd0M7TUFDbkU7O0VBRUY7QUFNQSxhQUFXLENBQUMsVUFBVSxNQUFNLEtBQUssT0FBTyxRQUFRLFVBQVUsR0FBRztBQUM1RCxVQUFNLEVBQUUsT0FBTyxPQUFPLE9BQU0sSUFBSyxlQUFlLFFBQVE7QUFHeEQsUUFBSSxVQUFVO0FBQWE7QUFLM0IsVUFBTSxZQUFZLFdBQVcsS0FBSztBQUNsQyxVQUFNLFlBQVksV0FBVyxXQUFXLEtBQUssQ0FBQyxNQUFXLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxNQUFNO0FBRTlGLGlCQUFhLFFBQVEsSUFBSTtNQUN4QixHQUFHO01BQ0gsVUFBVSxPQUFPLFVBQWM7QUFDOUIsY0FBTSxLQUFLLEtBQUs7QUFDaEIsY0FBTSxRQUFRLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBWSxNQUFNLFFBQVEsT0FBTyxJQUFJLFdBQVc7QUFDekYsY0FBTSxRQUFRLFdBQVcsVUFBVSxTQUFZLFVBQVUsUUFBUSxNQUFNLFFBQVEsT0FBTztBQUN0RixjQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU8sS0FBSztBQUN4QyxjQUFNLFlBQVksU0FBUztBQUUzQixjQUFNLEtBQUssYUFBYSxhQUFhLE9BQU8sT0FBTyxXQUFXLE9BQU8sRUFBRTtNQUN4RTtNQUNBLEdBQUksV0FBVyxVQUFVLFVBQWE7UUFDckMsT0FBTyxDQUFDLFVBQWM7QUFDckIsZ0JBQU0sS0FBSyxLQUFLO0FBQ2hCLGdCQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU8sS0FBSztBQUN4QyxnQkFBTSxZQUFZLFNBQVM7QUFDM0IsZ0JBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVksTUFBTSxRQUFRLE9BQU8sSUFBSSxXQUFXO0FBRXpGLGdCQUFNLFVBQVUsS0FBSyxhQUFhLGdCQUFnQixJQUFJLE9BQU8sV0FBVyxLQUFLO0FBQzdFLGNBQUksWUFBWTtBQUFXLG1CQUFPO0FBRWxDLGlCQUFPLEVBQUUsR0FBRyxNQUFNLFNBQVMsT0FBTyxRQUFPO1FBQzFDOzs7RUFHSDtBQUtBLFFBQU0sZUFBZSxRQUFRLFdBQVc7QUFDeEMsTUFBSSxjQUFjO0FBQ2pCLFVBQU0sbUJBQW1CLGFBQWEsYUFBYSxDQUFBLEdBQUksS0FBSyxDQUFDLE1BQVcsRUFBRSxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBRS9GLFFBQUksaUJBQWlCO0FBQ3BCLFlBQU0sV0FBVyxHQUFHLFdBQVc7QUFFL0IsbUJBQWEsUUFBUSxJQUFJO1FBQ3hCLE1BQU0sU0FBUyxXQUFXO1FBQzFCLFNBQVMsQ0FBQTtRQUNULFVBQVUsWUFBVztBQUNwQixnQkFBTSxLQUFLLEtBQUs7QUFDaEIsVUFBQUEsUUFBTyxLQUFLLHlCQUFvQixXQUFXLE1BQU0sRUFBRSxFQUFFO0FBQ3JELGdCQUFNLEtBQUssYUFBYSxjQUFjLEVBQUU7QUFDeEMsZ0JBQU0sS0FBSyxhQUFhLG1CQUFtQixFQUFFLEVBQUUsTUFBTSxDQUFDLFFBQU87QUFDNUQsWUFBQUEsUUFBTyxLQUFLLDZDQUE2QyxHQUFHLEVBQUU7VUFDL0QsQ0FBQztRQUNGOztJQUVGO0VBQ0Q7QUFFQSxPQUFLLHFCQUFxQixZQUFZO0FBQ3ZDOzs7QUUxSEEsU0FBUyxpQkFDUixTQUNBLE9BQ0EsT0FDQSxXQUNBLE9BQWE7QUFFYixRQUFNLFVBQVUscUJBQXFCLFNBQVMsT0FBTyxPQUFPLFNBQVM7QUFDckUsTUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLFFBQVEsUUFBUSxPQUFPO0FBQUcsV0FBTztBQUd4RCxRQUFNLGNBQWMsUUFBUSxRQUFRLEtBQUssQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBQ3pFLE1BQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxRQUFRLFlBQVksT0FBTztBQUFHLFdBQU87QUFHaEUsUUFBTSxTQUFTLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sS0FBSztBQUNsRSxTQUFPLFFBQVEsU0FBUztBQUN6QjtBQU1NLFNBQVUsZ0JBQWdCLE1BQW9CO0FBQ25ELFFBQU0sYUFBYSxpQkFBZ0I7QUFDbkMsUUFBTSxlQUFlLGVBQWM7QUFDbkMsUUFBTSxVQUFVLHFCQUFxQixVQUFVO0FBQy9DLFFBQU0saUJBQXNCLENBQUE7QUFHNUIsUUFBTSxjQUFjLEtBQUs7QUFNekIsYUFBVyxDQUFDLFlBQVksUUFBUSxLQUFLLE9BQU8sUUFBUSxZQUFZLEdBQUc7QUFFbEUsVUFBTSxVQUFVLFdBQVcsU0FBUyxPQUFPLElBQUksV0FBVyxNQUFNLEdBQUcsRUFBRSxJQUFJO0FBQ3pFLFVBQU0sRUFBRSxPQUFPLE9BQU8sT0FBTSxJQUFLLGVBQWUsT0FBTztBQUd2RCxRQUFJLFVBQVU7QUFBYTtBQUczQixtQkFBZSxVQUFVLElBQUk7TUFDNUIsR0FBRztNQUNILFVBQVUsQ0FBQyxrQkFBc0I7QUFDaEMsY0FBTSxLQUFLLEtBQUs7QUFDaEIsY0FBTSxRQUFRLGNBQWMsUUFBUSxPQUFPLEtBQUs7QUFDaEQsY0FBTSxZQUFZLFNBQVM7QUFHM0IsWUFBSSxRQUFRLGNBQWMsUUFBUSxPQUFPO0FBQ3pDLFlBQUksVUFBVSxRQUFXO0FBQ3hCLGdCQUFNLGVBQWUscUJBQXFCLFNBQVMsT0FBTyxPQUFPLFNBQVM7QUFDMUUsY0FBSSxjQUFjLFVBQVUsUUFBVztBQUN0QyxvQkFBUSxhQUFhO1VBQ3RCO1FBQ0Q7QUFHQSxZQUFJLFVBQVUsUUFBVztBQUN4QixnQkFBTSxZQUFZLFdBQVcsS0FBSyxHQUFHLFdBQVcsS0FBSyxDQUFDLE1BQVcsRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFDekcsY0FBSSxXQUFXLFVBQVUsUUFBVztBQUNuQyxvQkFBUSxVQUFVO1VBQ25CO1FBQ0Q7QUFFQSxjQUFNLFVBQVUsS0FBSyxhQUFhLGdCQUFnQixJQUFJLE9BQU8sV0FBVyxLQUFLO0FBTTdFLFlBQUksV0FBVyxTQUFTLE9BQU8sR0FBRztBQUNqQyxpQkFBTyxZQUFZLFVBQWEsWUFBWTtRQUM3QztBQUdBLGNBQU0sWUFBWSxjQUFjLFFBQVEsV0FBVyxLQUFLO0FBRXhELFlBQUksYUFBYSxZQUFZLFFBQVc7QUFDdkMsZ0JBQU0sUUFBUSxpQkFBaUIsU0FBUyxPQUFPLE9BQU8sV0FBVyxPQUFPO0FBR3hFLGNBQUksT0FBTyxVQUFVLFVBQVU7QUFDOUIsbUJBQU8sVUFBVSxJQUFJLFNBQVM7VUFDL0I7QUFDQSxpQkFBTztRQUNSO0FBR0EsZUFBTyxXQUFXO01BQ25COztFQUVGO0FBRUEsT0FBSyx1QkFBdUIsY0FBYztBQUMzQzs7O0FDM0dBLE9BQU9HLFlBQVc7QUFDbEIsT0FBT0MsU0FBUTs7O0FDRGYsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sUUFBUTtBQUlmLElBQU1DLFVBQVMsbUJBQW1CLE9BQU87QUFLekMsSUFBTSx5QkFBeUI7QUFFeEIsSUFBTSwwQkFBMEI7QUFDdkMsSUFBTSxxQkFBcUIsTUFBTztBQUVsQyxTQUFTLHdCQUFxQjtBQUM3QixRQUFNLE1BQU0sT0FBTyxNQUFNLElBQUksQ0FBQztBQUM5QixRQUFNLE1BQU0sS0FBSyxNQUFNLEtBQUssT0FBTSxJQUFLLEtBQU07QUFFN0MsTUFBSSxjQUFjLE9BQVEsQ0FBQztBQUMzQixNQUFJLGNBQWMsd0JBQXdCLENBQUM7QUFDM0MsTUFBSSxjQUFjLEtBQUssQ0FBQztBQUV4QixRQUFNLE1BQU0saUJBQWdCO0FBQzVCLE1BQUksS0FBSyxLQUFLLENBQUM7QUFFZixTQUFPLEtBQUssWUFBWSxPQUFPLEVBQUUsS0FBSyxLQUFLLEVBQUU7QUFDN0MsTUFBSSxjQUFjLE1BQVEsRUFBRTtBQUM1QixNQUFJLGNBQWMsS0FBUSxFQUFFO0FBQzVCLE1BQUksY0FBYyxLQUFZLEVBQUU7QUFFaEMsU0FBTztBQUNSO0FBR0EsU0FBUyxtQkFBZ0I7QUFDeEIsTUFBSTtBQUNILFVBQU0sU0FBUyxHQUFHLGtCQUFpQjtBQUNuQyxlQUFXLFFBQVEsT0FBTyxLQUFLLE1BQU0sR0FBRztBQUN2QyxpQkFBVyxRQUFRLE9BQU8sSUFBSSxLQUFLLENBQUEsR0FBSTtBQUN0QyxZQUFJLENBQUMsS0FBSyxZQUFZLEtBQUssV0FBVyxVQUFVLEtBQUssT0FBTyxLQUFLLFFBQVEscUJBQXFCO0FBQzdGLGlCQUFPLE9BQU8sS0FBSyxLQUFLLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQWMsU0FBUyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBQzNFO01BQ0Q7SUFDRDtFQUNELFFBQVE7RUFFUjtBQUNBLFNBQU8sT0FBTyxNQUFNLEdBQUcsQ0FBQztBQUN6QjtBQUVNLFNBQVUsdUJBQXVCLEtBQWEsT0FBYTtBQUNoRSxNQUFJLElBQUksU0FBUztBQUFvQixXQUFPO0FBQzVDLE1BQUksSUFBSSxhQUFhLENBQUMsTUFBTTtBQUFRLFdBQU87QUFDM0MsTUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQXlCLFdBQU87QUFDNUQsTUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFLEVBQUUsU0FBUyxPQUFPLE1BQU07QUFBWSxXQUFPO0FBRWxFLFFBQU0sVUFBVSxDQUFDLFFBQWdCLFFBQ2hDLElBQ0UsU0FBUyxRQUFRLFNBQVMsR0FBRyxFQUM3QixTQUFTLE9BQU8sRUFDaEIsTUFBTSxJQUFJLEVBQUUsQ0FBQyxFQUNiLEtBQUk7QUFFUCxRQUFNLFFBQVEsSUFBSSxTQUFTLEdBQUcsRUFBRTtBQUNoQyxRQUFNLFdBQVcsQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQztBQUM1RSxRQUFNLE1BQU0sU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFBRSxLQUFLLEdBQUc7QUFFekUsUUFBTSxPQUFPLFFBQVEsSUFBTSxFQUFFO0FBQzdCLFFBQU0sZUFBZSxRQUFRLElBQU0sRUFBRTtBQUNyQyxRQUFNLFdBQVcsUUFBUSxLQUFNLEVBQUU7QUFDakMsUUFBTSxnQkFBZ0IsR0FBRyxJQUFJLEVBQUksQ0FBQyxJQUFJLElBQUksRUFBSSxDQUFDO0FBRS9DLE1BQUksQ0FBQztBQUFVLFdBQU87QUFJdEIsUUFBTSxRQUFRLFNBQ1osUUFBUSxjQUFjLEVBQUUsRUFDeEIsS0FBSSxFQUNKLE1BQU0sS0FBSyxFQUFFLENBQUM7QUFFaEIsU0FBTztJQUNOLElBQUk7SUFDSjtJQUNBO0lBQ0E7SUFDQSxXQUFXOztJQUNYO0lBQ0E7O0FBRUY7QUFPQSxlQUFzQixxQkFBcUIsUUFBYztBQUN4RCxTQUFPLElBQUksUUFBa0IsQ0FBQyxTQUFTLFdBQVU7QUFDaEQsVUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBRXJDLFFBQUksS0FBSyxTQUFTLENBQUMsUUFBTztBQUN6QixVQUFJLE1BQUs7QUFDVCxhQUFPLElBQUksTUFBTSxJQUFJLFdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQztJQUM3QyxDQUFDO0FBRUQsUUFBSSxRQUFRLEdBQUcsUUFBUSxNQUFLO0FBQzNCLFVBQUk7QUFDSCxjQUFNLE9BQU8sSUFBSSxRQUFPO0FBQ3hCLGNBQU0sWUFBWSxLQUFLO0FBQ3ZCLFlBQUksTUFBSztBQUVULGNBQU0sU0FBUyxHQUFHLGtCQUFpQjtBQUNuQyxtQkFBVyxRQUFRLE9BQU8sS0FBSyxNQUFNLEdBQUc7QUFDdkMscUJBQVcsU0FBUyxPQUFPLElBQUksS0FBSyxDQUFBLEdBQUk7QUFDdkMsZ0JBQ0MsTUFBTSxXQUFXLFVBQ2pCLE1BQU0sWUFBWSxhQUNsQixNQUFNLE9BQ04sTUFBTSxRQUFRLHFCQUNiO0FBQ0QscUJBQU8sUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sU0FBUyxHQUFHLEVBQUUsSUFBSSxHQUFJLENBQUM7WUFDdkU7VUFDRDtRQUNEO0FBQ0EsZUFBTyxJQUFJLE1BQU0sd0NBQXdDLFNBQVMsRUFBRSxDQUFDO01BQ3RFLFNBQVMsSUFBSTtBQUNaLGVBQU8sSUFBSSxNQUFNLE9BQU8sRUFBRSxDQUFDLENBQUM7TUFDN0I7SUFDRCxDQUFDO0VBQ0YsQ0FBQztBQUNGO0FBTUEsZUFBc0IsOEJBQThCLFFBQWM7QUFDakUsU0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFVBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUVyQyxRQUFJLFdBQVc7QUFDZixRQUFJLEtBQUssU0FBUyxDQUFDLFFBQU87QUFDekIsVUFBSSxDQUFDLFVBQVU7QUFDZCxtQkFBVztBQUNYLFlBQUksTUFBSztBQUNULGVBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO01BQzdDO0lBQ0QsQ0FBQztBQUdELFFBQUksUUFBUSxHQUFHLFFBQVEsTUFBSztBQUMzQixVQUFJO0FBQ0gsY0FBTSxPQUFPLElBQUksUUFBTztBQUN4QixjQUFNLFlBQVksS0FBSztBQUN2QixZQUFJLENBQUMsVUFBVTtBQUNkLHFCQUFXO0FBQ1gsY0FBSSxNQUFLO0FBQ1Qsa0JBQVEsU0FBUztRQUNsQjtNQUNELFNBQVMsSUFBSTtBQUNaLFlBQUksQ0FBQyxVQUFVO0FBQ2QscUJBQVc7QUFDWCxjQUFJLE1BQUs7QUFDVCxpQkFBTyxJQUFJLE1BQU0sT0FBTyxFQUFFLENBQUMsQ0FBQztRQUM3QjtNQUNEO0lBQ0QsQ0FBQztFQUNGLENBQUM7QUFDRjtBQVdBLGVBQXNCLGdCQUNyQixVQUNBLGtCQUNBLFlBQVksS0FBSTtBQUVoQixRQUFNLHVCQUF1QjtBQUM3QixRQUFNLHNCQUFzQjtBQUM1QixRQUFNLGVBQWU7QUFFckIsUUFBTSxhQUFhLG9CQUFJLElBQUc7QUFFMUIsU0FBTyxJQUFJLFFBQWMsQ0FBQyxZQUFXO0FBQ3BDLFVBQU0saUJBQWlCLE1BQU0sYUFBYSxFQUFFLE1BQU0sUUFBUSxXQUFXLEtBQUksQ0FBRTtBQUMzRSxVQUFNLG1CQUE2QixDQUFBO0FBRW5DLFVBQU0sVUFBVSxNQUFLO0FBQ3BCLGlCQUFXLFNBQVMsa0JBQWtCO0FBQ3JDLFlBQUk7QUFDSCx5QkFBZSxlQUFlLHNCQUFzQixLQUFLO1FBQzFELFFBQVE7UUFFUjtNQUNEO0FBQ0EsVUFBSTtBQUNILHVCQUFlLE1BQUs7TUFDckIsUUFBUTtNQUVSO0FBQ0EsY0FBTztJQUNSO0FBRUEsVUFBTSxRQUFRLFdBQVcsU0FBUyxTQUFTO0FBQzNDLFVBQU0sUUFBTztBQUViLG1CQUFlLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDbEMsTUFBQUEsUUFBTyxLQUFLLDBCQUEwQixJQUFJLE9BQU8sRUFBRTtJQUNwRCxDQUFDO0FBRUQsbUJBQWUsR0FBRyxXQUFXLENBQUMsS0FBSyxVQUFTO0FBQzNDLFlBQU0sUUFBUSxNQUFNO0FBRXBCLFVBQUksSUFBSSxTQUFTO0FBQUk7QUFDckIsVUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQVE7QUFDcEMsVUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFLEVBQUUsU0FBUyxPQUFPLE1BQU07QUFBWTtBQUUzRCxVQUFJLFdBQVcsSUFBSSxLQUFLO0FBQUc7QUFDM0IsaUJBQVcsSUFBSSxLQUFLO0FBQ3BCLE1BQUFBLFFBQU8sTUFBTSxpQkFBaUIsS0FBSywrQkFBMEI7QUFLN0QsWUFBTSxZQUFZLFlBQVc7QUFDNUIsY0FBTSxpQkFBaUIsS0FBSztBQUM1QixjQUFNLFFBQVEsc0JBQXFCO0FBQ25DLGlCQUFTLEtBQUssT0FBTyxjQUFjLE9BQU8sQ0FBQyxRQUFPO0FBQ2pELGNBQUk7QUFBSyxZQUFBQSxRQUFPLEtBQUssb0JBQW9CLEtBQUssWUFBWSxJQUFJLE9BQU8sRUFBRTtRQUN4RSxDQUFDO01BQ0Y7QUFDQSxnQkFBUyxFQUFHLE1BQU0sQ0FBQyxRQUFRQSxRQUFPLEtBQUssdUJBQXVCLEdBQUcsRUFBRSxDQUFDO0lBQ3JFLENBQUM7QUFFRCxtQkFBZSxLQUFLLHFCQUFxQixNQUFLO0FBSzdDLFlBQU0sU0FBUyxHQUFHLGtCQUFpQjtBQUNuQyxpQkFBVyxTQUFTLE9BQU8sT0FBTyxNQUFNLEdBQUc7QUFDMUMsbUJBQVcsUUFBUSxTQUFTLENBQUEsR0FBSTtBQUMvQixjQUFJLEtBQUssV0FBVyxVQUFVLENBQUMsS0FBSyxVQUFVO0FBQzdDLGdCQUFJO0FBQ0gsNkJBQWUsY0FBYyxzQkFBc0IsS0FBSyxPQUFPO0FBQy9ELCtCQUFpQixLQUFLLEtBQUssT0FBTztZQUNuQyxRQUFRO1lBRVI7VUFDRDtRQUNEO01BQ0Q7QUFDQSxVQUFJLGlCQUFpQixXQUFXLEdBQUc7QUFDbEMsUUFBQUEsUUFBTyxLQUFLLDBEQUEwRDtNQUN2RSxPQUFPO0FBQ04sUUFBQUEsUUFBTyxNQUFNLG9DQUFvQyxvQkFBb0IsSUFBSSxtQkFBbUIsRUFBRTtNQUMvRjtJQUNELENBQUM7RUFDRixDQUFDO0FBQ0Y7QUFlQSxlQUFzQixZQUNyQixVQUNBLGtCQUNBLGdCQUNBLGtCQUNBLElBQ0EsWUFBWSxLQUFJO0FBRWhCLFNBQU8sSUFBSSxRQUEyQixDQUFDLFlBQVc7QUFDakQsVUFBTSxNQUFNLFdBQVcsRUFBRTtBQUN6QixRQUFJLFdBQVc7QUFFZixVQUFNLFNBQVMsQ0FBQyxXQUE2QjtBQUM1QyxVQUFJO0FBQVU7QUFDZCxpQkFBVztBQUNYLHFCQUFlLEdBQUc7QUFDbEIsY0FBUSxNQUFNO0lBQ2Y7QUFFQSxxQkFBaUIsS0FBSyxDQUFDLFdBQXNCO0FBQzVDLFVBQUksT0FBTyxPQUFPO0FBQUksZUFBTyxNQUFNO0lBQ3BDLENBQUM7QUFFRCxVQUFNLFFBQVEsV0FBVyxNQUFNLE9BQU8sSUFBSSxHQUFHLFNBQVM7QUFDdEQsVUFBTSxRQUFPO0FBRWIsVUFBTSxNQUFNLFlBQVc7QUFDdEIsWUFBTSxpQkFBaUIsRUFBRTtBQUN6QixZQUFNLFFBQVEsc0JBQXFCO0FBQ25DLGVBQVMsS0FBSyxPQUFPLE1BQU0sSUFBSSxDQUFDLFFBQU87QUFDdEMsWUFBSSxLQUFLO0FBQ1IsVUFBQUEsUUFBTyxLQUFLLFlBQVksRUFBRSxZQUFZLElBQUksT0FBTyxFQUFFO0FBQ25ELHVCQUFhLEtBQUs7QUFDbEIsaUJBQU8sSUFBSTtRQUNaO01BQ0QsQ0FBQztJQUNGO0FBRUEsUUFBRyxFQUFHLE1BQU0sQ0FBQyxNQUFLO0FBQ2pCLE1BQUFBLFFBQU8sS0FBSyxnQ0FBZ0MsRUFBRSxLQUFLLENBQUMsRUFBRTtBQUN0RCxtQkFBYSxLQUFLO0FBQ2xCLGFBQU8sSUFBSTtJQUNaLENBQUM7RUFDRixDQUFDO0FBQ0Y7OztBQ3ZVQSxPQUFPQyxZQUFXO0FBSWxCLElBQU1DLFVBQVMsbUJBQW1CLFFBQVE7QUFHMUMsSUFBTSxpQkFBaUIsb0JBQUksSUFBRztBQU85QixlQUFzQixrQkFBa0IsVUFBa0IsWUFBWSxLQUFJO0FBQ3pFLFFBQU0sVUFBVSxlQUFlLElBQUksUUFBUTtBQUMzQyxNQUFJO0FBQVMsV0FBTztBQUVwQixRQUFNLFVBQVUsaUJBQWlCLFVBQVUsU0FBUyxFQUFFLFFBQVEsTUFBSztBQUNsRSxtQkFBZSxPQUFPLFFBQVE7RUFDL0IsQ0FBQztBQUNELGlCQUFlLElBQUksVUFBVSxPQUFPO0FBQ3BDLFNBQU87QUFDUjtBQUVBLGVBQWUsaUJBQWlCLFVBQWtCLFdBQWlCO0FBQ2xFLFNBQU8sSUFBSSxRQUE2QixDQUFDLFlBQVc7QUFDbkQsUUFBSSxVQUFVO0FBQ2QsUUFBSSxpQkFBd0Q7QUFFNUQsVUFBTSxlQUFlLENBQUNDLFVBQXNCO0FBQzNDLFVBQUksZ0JBQWdCO0FBQ25CLHNCQUFjLGNBQWM7QUFDNUIseUJBQWlCO01BQ2xCO0FBQ0EsVUFBSTtBQUNILFFBQUFBLE1BQUssTUFBSztNQUNYLFFBQVE7TUFFUjtBQUNBLE1BQUFELFFBQU8sTUFBTSw2QkFBNkIsUUFBUSxFQUFFO0lBQ3JEO0FBRUEsVUFBTSxPQUFPLENBQUNDLFVBQXNCO0FBQ25DLFVBQUk7QUFBUztBQUNiLGdCQUFVO0FBQ1YsbUJBQWEsS0FBSztBQUNsQixtQkFBYUEsS0FBSTtBQUNqQixNQUFBRCxRQUFPLE1BQU0sc0NBQXNDLFFBQVEsRUFBRTtBQUM3RCxjQUFRLElBQUk7SUFDYjtBQUVBLFVBQU0sT0FBT0UsT0FBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBQ2pFLFVBQU0sUUFBUSxXQUFXLE1BQU0sS0FBSyxJQUFJLEdBQUcsU0FBUztBQUVwRCxTQUFLLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDeEIsTUFBQUYsUUFBTyxLQUFLLDJCQUEyQixRQUFRLEtBQUssSUFBSSxPQUFPLEVBQUU7QUFDakUsV0FBSyxJQUFJO0lBQ1YsQ0FBQztBQUVELFNBQUssR0FBRyxXQUFXLENBQUMsUUFBZTtBQUVsQyxVQUFJLENBQUMsV0FBVyxJQUFJLFVBQVUsS0FBSyxJQUFJLENBQUMsTUFBTSxNQUFRLElBQUksQ0FBQyxNQUFNLElBQU07QUFDdEUsa0JBQVU7QUFDVixxQkFBYSxLQUFLO0FBQ2xCLFFBQUFBLFFBQU8sS0FBSyxtQ0FBbUMsUUFBUSxFQUFFO0FBRXpELFlBQUksZUFBZSxLQUFLLE1BQU0sS0FBSyxPQUFNLElBQUssS0FBTSxJQUFJO0FBQ3hELGNBQU0sZ0JBQWdCLE1BQUs7QUFDMUIsZ0JBQU0sTUFBTSxPQUFPLE1BQU0sSUFBSSxDQUFDO0FBQzlCLGNBQUksQ0FBQyxJQUFJO0FBQ1QsY0FBSSxDQUFDLElBQUk7QUFDVCxjQUFJLGNBQWMsaUJBQWlCLE9BQVEsQ0FBQztBQUM1QyxjQUFJLENBQUMsSUFBSTtBQUNULGNBQUksQ0FBQyxJQUFJO0FBQ1QsZUFBSyxLQUFLLEtBQUssTUFBTSxVQUFVLE1BQUs7VUFFcEMsQ0FBQztRQUNGO0FBQ0EseUJBQWlCLFlBQVksZUFBZSxHQUFJO0FBQ2hELGdCQUFRLE1BQU0sYUFBYSxJQUFJLENBQUM7TUFDakM7SUFDRCxDQUFDO0FBRUQsVUFBTSxTQUFTLFlBQVc7QUFDekIsVUFBSTtBQUNKLFVBQUk7QUFDSixVQUFJO0FBQ0gsa0JBQVUsTUFBTSw4QkFBOEIsUUFBUTtBQUN0RCxtQkFBVyxNQUFNLHFCQUFxQixRQUFRO01BQy9DLFNBQVMsR0FBRztBQUNYLFFBQUFBLFFBQU8sS0FBSyxnREFBZ0QsUUFBUSxLQUFLLENBQUMsRUFBRTtBQUM1RSxhQUFLLElBQUk7QUFDVDtNQUNEO0FBRUEsV0FBSyxLQUFLLEVBQUUsTUFBTSxNQUFNLFNBQVMsUUFBTyxHQUFJLE1BQUs7QUFDaEQsY0FBTSxNQUFNLEtBQUssTUFBTSxLQUFLLE9BQU0sSUFBSyxLQUFNLElBQUk7QUFDakQsY0FBTSxNQUFNLE9BQU8sTUFBTSxJQUFJLENBQUM7QUFDOUIsWUFBSSxDQUFDLElBQUk7QUFDVCxZQUFJLENBQUMsSUFBSTtBQUNULFlBQUksY0FBYyxLQUFLLENBQUM7QUFDeEIsWUFBSSxDQUFDLElBQUk7QUFDVCxZQUFJLENBQUMsSUFBSTtBQUNULGlCQUFTLFFBQVEsQ0FBQyxHQUFHLE1BQUs7QUFDekIsY0FBSSxLQUFLLENBQUMsSUFBSTtRQUNmLENBQUM7QUFDRCxRQUFBQSxRQUFPLE1BQU0sZ0JBQWdCLFFBQVEsS0FBSyxJQUFJLFNBQVMsS0FBSyxDQUFDLEVBQUU7QUFDL0QsYUFBSyxLQUFLLEtBQUssTUFBTSxVQUFVLENBQUMsUUFBTztBQUN0QyxjQUFJLEtBQUs7QUFDUixZQUFBQSxRQUFPLEtBQUssMEJBQTBCLFFBQVEsS0FBSyxJQUFJLE9BQU8sRUFBRTtBQUNoRSxpQkFBSyxJQUFJO1VBQ1Y7UUFDRCxDQUFDO01BQ0YsQ0FBQztJQUNGO0FBRUEsV0FBTSxFQUFHLE1BQU0sQ0FBQyxNQUFLO0FBQ3BCLE1BQUFBLFFBQU8sS0FBSywwQkFBMEIsUUFBUSxLQUFLLENBQUMsRUFBRTtBQUN0RCxXQUFLLElBQUk7SUFDVixDQUFDO0VBQ0YsQ0FBQztBQUNGOzs7QUZuRkEsSUFBTUcsVUFBUyxtQkFBbUIsY0FBYztBQUUxQyxJQUFPLGVBQVAsTUFBTyxjQUFZO0VBQ1AsY0FBc0I7RUFDdEIsaUJBQWlCO0VBQ2pCLFNBQVM7RUFFbEI7RUFDQTs7RUFDQSxnQkFBcUM7O0VBQ3JDLGtCQUErQixvQkFBSSxJQUFHOztFQUN0QyxjQUdKLG9CQUFJLElBQUc7RUFDSCxtQkFBZ0Msb0JBQUksSUFBRzs7O0VBR3ZDLFlBQTJCLFFBQVEsUUFBTzs7RUFHMUMsc0JBQXNCOztFQUd0Qjs7RUFHQSxRQUFnQjtFQUNoQixVQUFzQixDQUFBOzs7Ozs7O0VBUXRCLGNBQWdELG9CQUFJLElBQUc7Ozs7Ozs7RUFRdkQsZ0JBQTZCLG9CQUFJLElBQUc7O0VBR3BDLHFCQUFnRSxvQkFBSSxJQUFHOztFQUd2RTs7RUFHQSxXQUFrQyxvQkFBSSxJQUFHOzs7RUFJekMscUJBQWtDLG9CQUFJLElBQUc7O0VBR3pDLGtCQUEyQyxvQkFBSSxJQUFHO0VBRTFELGNBQUE7QUFDQyxJQUFBQSxRQUFPLEtBQUssMEJBQTBCO0FBSXRDLFNBQUssV0FBV0MsT0FBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBQ3BFLFNBQUssVUFBVSxJQUFJLFFBQWMsQ0FBQyxZQUFXO0FBQzVDLFdBQUssU0FBUyxLQUFLLEdBQUcsTUFBSztBQUMxQixRQUFBRCxRQUFPLE1BQU0sMkJBQTRCLEtBQUssU0FBUyxRQUFPLEVBQXdCLElBQUksRUFBRTtBQUM1RixnQkFBTztNQUNSLENBQUM7SUFDRixDQUFDO0FBQ0QsU0FBSyxTQUFTLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDakMsTUFBQUEsUUFBTyxNQUFNLG9CQUFvQixHQUFHLEVBQUU7SUFDdkMsQ0FBQztBQUdELFNBQUssV0FBV0MsT0FBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBRXBFLFNBQUssU0FBUyxHQUFHLGFBQWEsTUFBSztBQUNsQyxZQUFNLE9BQU8sS0FBSyxTQUFTLFFBQU87QUFDbEMsTUFBQUQsUUFBTyxNQUFNLDBCQUEwQixLQUFLLFVBQVUsSUFBSSxDQUFDLEVBQUU7QUFDN0QsVUFBSTtBQUNILGFBQUssU0FBUyxxQkFBcUIsSUFBSTtNQUN4QyxTQUFTLElBQUk7TUFFYjtJQUNELENBQUM7QUFFRCxTQUFLLFNBQVMsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNqQyxNQUFBQSxRQUFPLE1BQU0sb0JBQW9CLEdBQUcsRUFBRTtJQUN2QyxDQUFDO0FBRUQsU0FBSyxTQUFTLEdBQUcsV0FBVyxDQUFDLEtBQUssVUFBUztBQUMxQyxVQUFJO0FBQ0gsYUFBSyxlQUFlLEtBQUssTUFBTSxPQUFPO01BQ3ZDLFNBQVMsSUFBSTtBQUNaLFFBQUFBLFFBQU8sTUFBTSxvQ0FBb0MsRUFBRSxFQUFFO01BQ3REO0lBQ0QsQ0FBQztBQU1ELFNBQUssU0FBUyxLQUFLLEVBQUUsU0FBUyxXQUFXLE1BQU0sS0FBSyxPQUFNLEdBQUksTUFBSztBQUNsRSxNQUFBQSxRQUFPLE1BQU0sOEJBQThCLEtBQUssTUFBTSxFQUFFO0FBQ3hELFlBQU0sU0FBU0UsSUFBRyxrQkFBaUI7QUFDbkMsaUJBQVcsU0FBUyxPQUFPLE9BQU8sTUFBTSxHQUFHO0FBQzFDLG1CQUFXLFFBQVEsU0FBUyxDQUFBLEdBQUk7QUFDL0IsY0FBSSxLQUFLLFdBQVcsVUFBVSxDQUFDLEtBQUssWUFBWSxDQUFDLEtBQUssaUJBQWlCLElBQUksS0FBSyxPQUFPLEdBQUc7QUFDekYsZ0JBQUk7QUFDSCxtQkFBSyxTQUFTLGNBQWMsS0FBSyxnQkFBZ0IsS0FBSyxPQUFPO0FBQzdELG1CQUFLLGlCQUFpQixJQUFJLEtBQUssT0FBTztBQUN0QyxjQUFBRixRQUFPLE1BQU0sd0JBQXdCLEtBQUssY0FBYyxPQUFPLEtBQUssT0FBTyxFQUFFO1lBQzlFLFNBQVMsSUFBSTtBQUNaLGNBQUFBLFFBQU8sS0FBSyxtQ0FBbUMsS0FBSyxPQUFPLEtBQUssT0FBTyxFQUFFLENBQUMsRUFBRTtZQUM3RTtVQUNEO1FBQ0Q7TUFDRDtJQUNELENBQUM7QUFLRCxTQUFLLGdCQUFnQkMsT0FBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBQ3pFLFNBQUssY0FBYyxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ3RDLE1BQUFELFFBQU8sTUFBTSwwQkFBMEIsSUFBSSxPQUFPLEVBQUU7SUFDckQsQ0FBQztBQUNELFNBQUssY0FBYyxHQUFHLFdBQVcsQ0FBQyxLQUFhLFVBQTJCO0FBQ3pFLFVBQUksSUFBSSxTQUFTO0FBQUk7QUFDckIsVUFBSSxJQUFJLENBQUMsTUFBTSxPQUFRLElBQUksQ0FBQyxNQUFNO0FBQU07QUFDeEMsWUFBTSxNQUFNLElBQUksU0FBUyxJQUFJLEVBQUU7QUFDL0IsVUFBSSxJQUFJLFNBQVMsT0FBTyxNQUFNO0FBQVk7QUFDMUMsWUFBTSxZQUFZLElBQUksU0FBUyxFQUFFO0FBQ2pDLFVBQUksVUFBVSxTQUFTLEtBQUssVUFBVSxDQUFDLE1BQU07QUFBTTtBQUNuRCxZQUFNLFlBQVksVUFBVSxDQUFDO0FBQzdCLFlBQU0sY0FBYyxZQUFZLFNBQVU7QUFDMUMsWUFBTSxnQkFBZ0IsWUFBWTtBQUNsQyxVQUFJLFlBQVk7QUFDZixjQUFNLE1BQU0sR0FBRyxNQUFNLE9BQU8sSUFBSSxhQUFhO0FBQzdDLGNBQU0sb0JBQW9CLENBQUMsS0FBSyxnQkFBZ0IsSUFBSSxHQUFHO0FBQ3ZELGFBQUssZ0JBQWdCLElBQUksR0FBRztBQUM1QixRQUFBQSxRQUFPLE1BQ04sdUJBQXVCLE1BQU0sT0FBTyxRQUFRLE1BQU0sYUFBYSxDQUFDLE1BQzlELG9CQUFvQiw0QkFBNEIsMkJBQTJCO0FBRzlFLG1CQUFXLE1BQU0sS0FBSyxnQkFBZ0IsT0FBTyxHQUFHLEdBQUcsR0FBRztNQUN2RDtJQUNELENBQUM7QUFDRCxTQUFLLGNBQWMsS0FBSyxFQUFFLFNBQVMsS0FBSyxnQkFBZ0IsTUFBTSxLQUFLLE9BQU0sR0FBSSxNQUFLO0FBQ2pGLE1BQUFBLFFBQU8sTUFBTSw0QkFBNEIsS0FBSyxjQUFjLElBQUksS0FBSyxNQUFNLEVBQUU7SUFDOUUsQ0FBQztFQUNGO0VBRU8sUUFBSztBQUVYLGVBQVcsV0FBVyxLQUFLLGdCQUFnQixPQUFNLEdBQUk7QUFDcEQsVUFBSTtBQUNILGdCQUFPO01BQ1IsUUFBUTtNQUVSO0lBQ0Q7QUFDQSxTQUFLLGdCQUFnQixNQUFLO0FBQzFCLFFBQUk7QUFDSCxpQkFBVyxhQUFhLE1BQU0sS0FBSyxLQUFLLGdCQUFnQixHQUFHO0FBQzFELFlBQUk7QUFDSCxlQUFLLFNBQVMsZUFBZSxLQUFLLGdCQUFnQixTQUFTO1FBQzVELFFBQVE7UUFFUjtNQUNEO0lBQ0QsUUFBUTtJQUVSO0FBQ0EsUUFBSTtBQUNILFdBQUssZUFBZSxNQUFLO0FBQ3pCLFdBQUssZ0JBQWdCO0lBQ3RCLFFBQVE7SUFFUjtBQUNBLFFBQUk7QUFDSCxXQUFLLFNBQVMsTUFBSztJQUNwQixRQUFRO0lBRVI7QUFDQSxRQUFJO0FBQ0gsV0FBSyxTQUFTLE1BQUs7SUFDcEIsUUFBUTtJQUVSO0VBQ0Q7Ozs7O0VBTU8sU0FBUyxPQUFlLFNBQW1CO0FBQ2pELFNBQUssUUFBUTtBQUNiLFNBQUssVUFBVTtFQUNoQjs7Ozs7RUFNTyxvQkFBb0IsVUFBc0M7QUFDaEUsU0FBSyxtQkFBbUI7RUFDekI7O0VBR08sbUJBQW1CLElBQVU7QUFDbkMsV0FBTyxLQUFLLGNBQWMsSUFBSSxFQUFFO0VBQ2pDOztFQUdPLGdCQUFnQixJQUFVO0FBQ2hDLFNBQUssY0FBYyxJQUFJLEVBQUU7QUFDekIsSUFBQUEsUUFBTyxNQUFNLHdCQUF3QixFQUFFLEVBQUU7RUFDMUM7O0VBR08sYUFBYSxJQUFVO0FBQzdCLFNBQUssY0FBYyxPQUFPLEVBQUU7QUFDNUIsU0FBSyxZQUFZLE9BQU8sRUFBRTtBQUMxQixTQUFLLFNBQVMsT0FBTyxFQUFFO0FBQ3ZCLFNBQUssbUJBQW1CLE9BQU8sRUFBRTtBQUNqQyxTQUFLLGdCQUFnQixJQUFJLEVBQUUsSUFBRztBQUM5QixTQUFLLGdCQUFnQixPQUFPLEVBQUU7QUFDOUIsSUFBQUEsUUFBTyxNQUFNLHFCQUFxQixFQUFFLEVBQUU7RUFDdkM7Ozs7OztFQU9PLE1BQU0sWUFBWSxVQUFnQjtBQUN4QyxRQUFJLEtBQUssbUJBQW1CLElBQUksUUFBUTtBQUFHLGFBQU87QUFDbEQsVUFBTSxTQUFTLGdCQUFnQixLQUFLLEtBQUs7QUFDekMsUUFBSSxDQUFDLFFBQVEsV0FBVztBQUV2QixXQUFLLG1CQUFtQixJQUFJLFFBQVE7QUFDcEMsYUFBTztJQUNSO0FBQ0EsVUFBTSxVQUFVLE1BQU0sa0JBQWtCLFFBQVE7QUFDaEQsVUFBTSxVQUFVLFlBQVk7QUFHNUIsU0FBSyxtQkFBbUIsSUFBSSxRQUFRO0FBQ3BDLFFBQUksU0FBUztBQUNaLFdBQUssZ0JBQWdCLElBQUksVUFBVSxPQUFPO0lBQzNDO0FBQ0EsV0FBTztFQUNSOzs7Ozs7O0VBUU8sTUFBTSxZQUFZLElBQVksWUFBWSxLQUFJO0FBQ3BELFVBQU0sS0FBSztBQUNYLFdBQU8sWUFDTixLQUFLLFVBQ0wsQ0FBQyxLQUFLLE9BQU8sS0FBSyxtQkFBbUIsSUFBSSxLQUFLLEVBQUUsR0FDaEQsQ0FBQyxRQUFRLEtBQUssbUJBQW1CLE9BQU8sR0FBRyxHQUMzQyxPQUFPLFdBQVcsS0FBSyxvQkFBb0IsTUFBTSxHQUNqRCxJQUNBLFNBQVM7RUFFWDs7Ozs7RUFNTyxNQUFNLG1CQUFtQixVQUFnQjtBQUMvQyxJQUFBQSxRQUFPLEtBQUssZ0NBQWdDLFFBQVEsRUFBRTtBQUN0RCxVQUFNLFdBQVcsTUFBTSxLQUFLLGFBQWEsc0JBQXNCLFFBQVcsUUFBVyxRQUFXLFVBQVUsS0FBSztBQUUvRyxXQUFPO0VBQ1I7Ozs7Ozs7RUFRTyxNQUFNLGdCQUFnQixZQUFZLEtBQUk7QUFDNUMsVUFBTSxnQkFBZ0I7QUFDdEIsVUFBTSxlQUE2QixDQUFBO0FBRW5DLFNBQUssbUJBQW1CLElBQUksZUFBZSxDQUFDLFdBQXNCO0FBQ2pFLFVBQUksQ0FBQyxhQUFhLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLEVBQUUsR0FBRztBQUNsRCxxQkFBYSxLQUFLLE1BQU07TUFDekI7SUFDRCxDQUFDO0FBRUQsUUFBSTtBQUNILFlBQU0sS0FBSztBQUNYLFlBQU0sZ0JBQWdCLEtBQUssVUFBVSxPQUFPLFdBQVcsS0FBSyxvQkFBb0IsTUFBTSxHQUFHLFNBQVM7QUFDbEcsYUFBTztJQUNSO0FBQ0MsV0FBSyxtQkFBbUIsT0FBTyxhQUFhO0lBQzdDO0VBQ0Q7Ozs7O0VBTU8sTUFBTSx1QkFBdUIsVUFBZ0I7QUFDbkQsSUFBQUEsUUFBTyxLQUFLLG9DQUFvQyxRQUFRLEVBQUU7QUFDMUQsVUFBTSxXQUFXLE1BQU0sS0FBSyxhQUFhLGtCQUFrQixRQUFXLFFBQVcsUUFBVyxVQUFVLEtBQUs7QUFJM0csVUFBTSxZQUFZO0FBRWxCLFFBQUksU0FBUyxTQUFTLFlBQVksR0FBRztBQUNwQyxNQUFBQSxRQUFPLEtBQUssZ0NBQWdDLFNBQVMsTUFBTSxRQUFRO0FBQ25FLGFBQU87SUFDUjtBQUdBLFVBQU0sUUFBUSxTQUFTLFlBQVksQ0FBQztBQUNwQyxVQUFNLFFBQVEsU0FBUyxZQUFZLENBQUM7QUFFcEMsVUFBTSxXQUNMLFFBQVEsS0FDTCxNQUFNLFNBQVEsRUFBRyxTQUFTLEdBQUcsR0FBRyxJQUNoQyxNQUFNLFNBQVE7QUFFbEIsVUFBTSxXQUFXLEdBQUcsS0FBSyxJQUFJLFFBQVE7QUFFckMsSUFBQUEsUUFBTyxNQUFNLHFCQUFxQixRQUFRLEVBQUU7QUFDNUMsV0FBTztFQUNSOzs7OztFQU1RLE1BQU0sb0JBQW9CLFFBQWM7QUFDL0MsUUFBSTtBQUNILFlBQU0sWUFBWSxNQUFNLDhCQUE4QixNQUFNO0FBQzVELFVBQUksQ0FBQyxXQUFXO0FBQ2YsUUFBQUEsUUFBTyxLQUFLLHFEQUFxRCxNQUFNLEVBQUU7QUFDekU7TUFDRDtBQUVBLFVBQUksS0FBSyxpQkFBaUIsSUFBSSxTQUFTLEdBQUc7QUFFekM7TUFDRDtBQUVBLFVBQUk7QUFDSCxhQUFLLFNBQVMsY0FBYyxLQUFLLGdCQUFnQixTQUFTO0FBQzFELGFBQUssaUJBQWlCLElBQUksU0FBUztBQUNuQyxRQUFBQSxRQUFPLEtBQUssb0JBQW9CLEtBQUssY0FBYyxPQUFPLFNBQVMsRUFBRTtNQUN0RSxTQUFTLElBQUk7QUFDWixRQUFBQSxRQUFPLEtBQUssK0JBQStCLFNBQVMsS0FBSyxPQUFPLEVBQUUsQ0FBQyxFQUFFO01BQ3RFO0lBQ0QsU0FBUyxJQUFJO0FBQ1osTUFBQUEsUUFBTyxLQUFLLCtCQUErQixFQUFFLEVBQUU7SUFDaEQ7RUFDRDtFQUVPLE1BQU0sYUFDWixPQUNBLE9BQ0EsV0FDQSxPQUNBLFFBQ0EsU0FBUyxNQUFJO0FBRWIsU0FBSztBQUNMLFdBQU8sSUFBSSxRQUFnQixDQUFDLFNBQVMsV0FBVTtBQUM5QyxXQUFLLFlBQVksS0FBSyxVQUFVLEtBQUssWUFDcEMsS0FBSyxjQUFjLE9BQU8sT0FBTyxXQUFXLE9BQU8sUUFBUSxNQUFNLEVBQy9ELEtBQUssQ0FBQyxRQUFPO0FBQ2IsYUFBSztBQUdMLFlBQUksS0FBSyx3QkFBd0IsS0FBSyxVQUFVLFFBQVc7QUFDMUQsZUFBSyxtQkFBbUIsTUFBTSxFQUFFLE1BQU0sQ0FBQyxRQUFPO0FBQzdDLFlBQUFBLFFBQU8sS0FBSyw2Q0FBNkMsR0FBRyxFQUFFO1VBQy9ELENBQUM7UUFDRjtBQUNBLGdCQUFRLEdBQUc7TUFDWixDQUFDLEVBQ0EsTUFBTSxDQUFDLFFBQU87QUFDZCxhQUFLO0FBQ0wsZUFBTyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sT0FBTyxHQUFHLENBQUMsQ0FBQztNQUMzRCxDQUFDLENBQUM7SUFFTCxDQUFDO0VBQ0Y7RUFFUSxNQUFNLGNBQ2IsT0FDQSxPQUNBLFdBQ0EsT0FDQSxRQUNBLFNBQVMsTUFBSTtBQUViLFVBQU0sWUFBWTtBQUVsQixVQUFNLFlBQXNCLENBQUE7QUFDNUIsUUFBSSxjQUFjO0FBQVcsZ0JBQVUsS0FBSyxZQUFZLEdBQUk7QUFDNUQsUUFBSSxVQUFVO0FBQVcsZ0JBQVUsS0FBSyxHQUFHLGNBQWEsZ0JBQWdCLEtBQUssQ0FBQztBQUU5RSxVQUFNLGNBQXdCLENBQUMsSUFBTSxRQUFRLEdBQUk7QUFFakQsUUFBSSxVQUFVLGVBQWUsVUFBVSxVQUFhLGNBQWMsVUFBYSxVQUFVLFFBQVc7QUFJbkcsVUFBSSxDQUFDLEtBQUssWUFBWSxJQUFJLE1BQU07QUFBRyxhQUFLLFlBQVksSUFBSSxRQUFRLG9CQUFJLElBQUcsQ0FBRTtBQUN6RSxZQUFNLFVBQVUsS0FBSyxZQUFZLElBQUksTUFBTTtBQUMzQyxZQUFNLGVBQWU7QUFDckIsWUFBTSxZQUFzQixDQUFBO0FBQzVCLGVBQVMsSUFBSSxHQUFHLElBQUksY0FBYyxLQUFLO0FBQ3RDLGNBQU0sV0FBVyxjQUFjLEtBQUssT0FBTyxhQUFhLEdBQUcsS0FBSztBQUNoRSxjQUFNLE1BQU0sTUFBTSxZQUFZLE9BQU8sS0FBSyxJQUFLLFFBQVEsSUFBSSxRQUFRLEtBQUs7QUFDeEUsa0JBQVUsS0FBSyxHQUFHO0FBQ2xCLGdCQUFRLElBQUksVUFBVSxHQUFHO01BQzFCO0FBQ0Esa0JBQVksS0FBSyxRQUFRLEtBQU0sR0FBRyxTQUFTO0lBQzVDLE9BQU87QUFDTixVQUFJLFVBQVU7QUFBVyxvQkFBWSxLQUFLLFFBQVEsR0FBSTtBQUN0RCxVQUFJO0FBQVEsb0JBQVksS0FBSyxVQUFVLE1BQU07QUFDN0MsVUFBSSxVQUFVLFNBQVM7QUFBRyxvQkFBWSxLQUFLLEdBQUcsU0FBUztJQUN4RDtBQUVBLFVBQU0sTUFBTSxjQUFhLFVBQVUsV0FBVztBQUM5QyxVQUFNLGlCQUFpQixPQUFPLEtBQUssQ0FBQyxHQUFHLGFBQWEsR0FBRyxDQUFDO0FBR3hELFFBQUksY0FBYyxVQUFhLFVBQVUsUUFBVztBQUNuRCxZQUFNLGFBQWEsY0FBYSxnQkFBZ0IsS0FBSztBQUNyRCxZQUFNLFVBQXlCO1FBQzlCLFFBQVE7UUFDUixJQUFJO1FBQ0o7UUFDQTs7QUFFRCxNQUFBQSxRQUFPLEtBQUssTUFBTSxNQUFNLE1BQU0sb0JBQW9CLFNBQVMsS0FBSyxPQUFPLENBQUMsRUFBRTtJQUMzRSxPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLE1BQU0sTUFBTSxNQUFNLGVBQWUsS0FBSyxDQUFDLEVBQUU7SUFDdEQ7QUFJQSxRQUFJLENBQUMsS0FBSyxjQUFjLElBQUksTUFBTSxHQUFHO0FBQ3BDLE1BQUFBLFFBQU8sTUFBTSxxREFBZ0QsTUFBTSxLQUFLLGVBQWUsU0FBUyxLQUFLLENBQUMsRUFBRTtBQUN4RyxZQUFNLElBQUksTUFBTSxhQUFhLE1BQU0saUZBQTRFO0lBQ2hIO0FBS0EsUUFBSSxDQUFDLEtBQUssbUJBQW1CLElBQUksTUFBTSxHQUFHO0FBQ3pDLFlBQU0sS0FBSyxZQUFZLE1BQU07SUFFOUI7QUFHQSxVQUFNLEtBQUssb0JBQW9CLE1BQU07QUFFckMsVUFBTSxXQUFXLEtBQUssZUFBZTtBQUNyQyxVQUFNLFNBQVMsTUFBTSxLQUFLLFlBQVksVUFBVSxNQUFNO0FBQ3RELFVBQU0sU0FBUyxPQUFPLE9BQU8sQ0FBQyxRQUFRLGNBQWMsQ0FBQztBQUVyRCxJQUFBQSxRQUFPLE1BQU0scUJBQXFCLE1BQU0sS0FBSyxPQUFPLFNBQVMsS0FBSyxDQUFDLEVBQUU7QUFFckUsVUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLEtBQUs7QUFFOUIsV0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFlBQU0sUUFBUSxXQUFXLE1BQUs7QUFDN0IsYUFBSyxZQUFZLE9BQU8sR0FBRztBQUMzQixlQUFPLElBQUksTUFBTSxzQ0FBc0MsS0FBSyxLQUFLLE9BQU8sTUFBTSxPQUFPLENBQUM7TUFDdkYsR0FBRyxTQUFTO0FBRVosV0FBSyxZQUFZLElBQUksS0FBSztRQUN6QixTQUFTLENBQUMsUUFBTztBQUNoQix1QkFBYSxLQUFLO0FBQ2xCLGtCQUFRLEdBQUc7UUFDWjtRQUNBLFFBQVEsQ0FBQyxRQUFPO0FBQ2YsdUJBQWEsS0FBSztBQUNsQixpQkFBTyxHQUFHO1FBQ1g7UUFDQTtPQUNBO0FBRUQsV0FBSyxTQUFTLEtBQUssUUFBUSxLQUFLLGFBQWEsUUFBUSxDQUFDLFFBQU87QUFDNUQsWUFBSSxLQUFLO0FBQ1IsZUFBSyxZQUFZLE9BQU8sR0FBRztBQUMzQix1QkFBYSxLQUFLO0FBQ2xCLGlCQUFPLElBQUksTUFBTSxJQUFJLFdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQztRQUM3QztNQUNELENBQUM7SUFDRixDQUFDO0VBQ0Y7RUFFUSxlQUFlLEtBQWEsT0FBYTtBQUNoRCxRQUFJLElBQUksU0FBUztBQUFHO0FBQ3BCLFFBQUksSUFBSSxDQUFDLE1BQU0sT0FBUSxJQUFJLENBQUMsTUFBTTtBQUFNO0FBRXhDLFVBQU0sVUFBVSxJQUFJLGFBQWEsQ0FBQztBQUtsQyxRQUFJLFlBQVksMkJBQTJCLEtBQUssbUJBQW1CLE9BQU8sR0FBRztBQUM1RSxZQUFNLFNBQVMsdUJBQXVCLEtBQUssS0FBSztBQUNoRCxVQUFJLFFBQVE7QUFDWCxRQUFBQSxRQUFPLE1BQ04sNEJBQTRCLEtBQUssZUFDbkIsT0FBTyxJQUFJLGFBQ2QsT0FBTyxLQUFLLGlCQUNSLE9BQU8sU0FBUyxvQkFDYixPQUFPLFlBQVksR0FBRztBQUl6QyxZQUFJLE9BQU8sU0FBUyxZQUFZO0FBQy9CLHFCQUFXLE1BQU0sS0FBSyxtQkFBbUIsT0FBTSxHQUFJO0FBQ2xELGdCQUFJO0FBQ0gsaUJBQUcsTUFBTTtZQUNWLFFBQVE7WUFFUjtVQUNEO1FBQ0QsT0FBTztBQUNOLFVBQUFBLFFBQU8sTUFBTSxzREFBc0QsT0FBTyxJQUFJLE9BQU8sS0FBSyxFQUFFO1FBQzdGO01BQ0Q7QUFDQTtJQUNEO0FBRUEsUUFBSSxJQUFJLFNBQVM7QUFBSTtBQUdyQixVQUFNLE1BQU0sSUFBSSxTQUFTLElBQUksRUFBRTtBQUMvQixRQUFJLElBQUksU0FBUyxPQUFPLE1BQU07QUFBWTtBQU0xQyxRQUFJLENBQUMsS0FBSyxjQUFjLElBQUksS0FBSyxHQUFHO0FBQ25DLE1BQUFBLFFBQU8sTUFBTSxxREFBcUQsS0FBSyxFQUFFO0FBQ3pFO0lBQ0Q7QUFJQSxVQUFNLFlBQVksSUFBSSxTQUFTLEVBQUU7QUFDakMsUUFBSSxVQUFVLFNBQVM7QUFBRztBQUMxQixRQUFJLFVBQVUsQ0FBQyxNQUFNO0FBQU07QUFHM0IsVUFBTSxZQUFZLFVBQVUsQ0FBQztBQUM3QixVQUFNLGNBQWMsWUFBWSxTQUFVO0FBQzFDLFVBQU0sZ0JBQWdCLFlBQVk7QUFNbEMsUUFBSSxZQUFZO0FBQ2YsWUFBTSxNQUFNLEdBQUcsS0FBSyxJQUFJLGFBQWE7QUFDckMsWUFBTSxVQUFVLEtBQUssWUFBWSxJQUFJLEdBQUc7QUFDeEMsVUFBSSxTQUFTO0FBQ1osYUFBSyxZQUFZLE9BQU8sR0FBRztBQUMzQixjQUFNLGVBQWUsS0FBSyxnQkFBZ0IsSUFBSSxHQUFHO0FBQ2pELFFBQUFBLFFBQU8sTUFDTix1QkFBdUIsS0FBSyxRQUFRLE1BQU0sYUFBYSxDQUFDLFFBQVEsZUFBZSxjQUFjLFNBQVMsRUFBRTtBQUV6RyxZQUFJLGtCQUFrQixzQkFBc0I7QUFDM0MsVUFBQUEsUUFBTyxNQUFNLHdCQUF3QixLQUFLLEtBQUssSUFBSSxTQUFTLEtBQUssQ0FBQyxFQUFFO1FBQ3JFO0FBQ0EsYUFBSyxhQUFhLE9BQU8sZUFBZSxLQUFLLFNBQVM7QUFDdEQsZ0JBQVEsUUFBUSxHQUFHO01BQ3BCLFdBQVcsa0JBQWtCLG1CQUFtQjtBQUUvQyxhQUFLLGFBQWEsT0FBTyxlQUFlLEtBQUssU0FBUztNQUN2RDtJQUVELE9BQU87QUFFTixXQUFLLGFBQWEsT0FBTyxlQUFlLEtBQUssU0FBUztJQUN2RDtFQUNEOzs7Ozs7Ozs7Ozs7RUFhUSxhQUFhLE9BQWUsT0FBZSxLQUFhLFdBQWlCO0FBQ2hGLFVBQU0sVUFBVSxlQUFlLEtBQUs7QUFDcEMsVUFBTSxPQUFPLFVBQVUsU0FBUyxHQUFHLFVBQVUsU0FBUyxDQUFDO0FBR3ZELFVBQU0sWUFBWSxVQUFVLENBQUM7QUFDN0IsVUFBTSxNQUFNLFVBQVUsVUFBVSxTQUFTLENBQUM7QUFDMUMsVUFBTSxnQkFBZ0IsUUFBUSxNQUFNLFNBQVMsQ0FBQyxTQUFTLEtBQUssU0FBUyxLQUFLLENBQUMsUUFBUSxNQUFNLEdBQUcsQ0FBQztBQUs3RixRQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQUksQ0FBQyxLQUFLLE9BQU87QUFDaEIsUUFBQUEsUUFBTyxLQUFLLE1BQU0sS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLEVBQUU7QUFDekQ7TUFDRDtBQUNBLFVBQUk7QUFDSCxjQUFNLFdBQ0wsVUFBVSxvQkFDUCxzQkFBc0IsS0FBSyxPQUFPLEdBQUcsSUFDckMsNEJBQTRCLEtBQUssT0FBTyxHQUFHO0FBRS9DLGNBQU0sWUFBWSxLQUFLLFlBQVksSUFBSSxLQUFLLEtBQUssb0JBQUksSUFBRztBQUN4RCxjQUFNLFdBQVcsSUFBSSxJQUFvQixTQUFTO0FBRWxELG1CQUFXLEtBQUssVUFBVTtBQUN6QixnQkFBTSxXQUFXLGNBQWMsS0FBSyxPQUFPLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLO0FBRWxFLGdCQUFNLFdBQ0wsRUFBRSxXQUFXLFdBQVcsSUFDcEIsRUFBRSxXQUFXLENBQUMsS0FBSyxLQUFPLEVBQUUsV0FBVyxDQUFDLEtBQUssSUFBSyxFQUFFLFdBQVcsQ0FBQyxJQUNoRSxFQUFFLFdBQVcsQ0FBQyxLQUFLO0FBQ3hCLGdCQUFNLFlBQVksVUFBVSxJQUFJLFFBQVE7QUFDeEMsZ0JBQU0sVUFBVSxjQUFjLFVBQWEsY0FBYztBQUV6RCxtQkFBUyxJQUFJLFVBQVUsUUFBUTtBQUUvQixnQkFBTSxZQUFZLG9CQUFvQixHQUFHLEtBQUssT0FBTztBQUNyRCxjQUFJLFNBQVM7QUFDWixZQUFBQSxRQUFPLEtBQUssTUFBTSxLQUFLLE1BQU0sU0FBUyxFQUFFO0FBRXhDLGdCQUFJLEtBQUssa0JBQWtCO0FBQzFCLGtCQUFJLFNBQVMsRUFBRTtBQUNmLG9CQUFNLGFBQWEsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFLO0FBQzFDLG9CQUFJLEVBQUUsV0FBVyxFQUFFO0FBQVEseUJBQU87QUFDbEMsb0JBQUksRUFBRSxPQUFPLEVBQUU7QUFBSSx5QkFBTztBQUMxQixzQkFBTSxjQUFjLEVBQUUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUMzRCxvQkFBSSxDQUFDLGFBQWE7QUFBUyx5QkFBTztBQUNsQyxzQkFBTSxTQUFTLEVBQUUsS0FBSyxFQUFFO0FBQ3hCLHVCQUFPLFNBQVMsS0FBSyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE1BQU07Y0FDckUsQ0FBQztBQUNELGtCQUFJO0FBQVkseUJBQVMsV0FBVztBQUNwQyxvQkFBTSxrQkFBa0IsY0FBYyxLQUFLLE9BQU8sRUFBRSxRQUFRLE1BQU07QUFDbEUsbUJBQUssaUJBQWlCLGVBQWU7QUFDckMsbUJBQUssaUJBQWlCLGtCQUFrQixPQUFPO1lBQ2hELE9BQU87QUFDTixjQUFBQSxRQUFPLEtBQUssZ0VBQTJELFFBQVEsRUFBRTtZQUNsRjtVQUNELE9BQU87QUFDTixZQUFBQSxRQUFPLE1BQU0sTUFBTSxLQUFLLE1BQU0sU0FBUyxFQUFFO1VBQzFDO1FBQ0Q7QUFDQSxhQUFLLFlBQVksSUFBSSxPQUFPLFFBQVE7TUFDckMsU0FBUyxHQUFHO0FBQ1gsUUFBQUEsUUFBTyxLQUFLLE1BQU0sS0FBSyxNQUFNLE9BQU8sb0JBQW9CLENBQUMsTUFBTSxhQUFhLEVBQUU7TUFDL0U7QUFDQTtJQUNEO0FBR0EsVUFBTSxVQUFVLEtBQUssYUFBYSxPQUFPLElBQUk7QUFFN0MsVUFBTSxRQUFRLFVBQVUsY0FBY0EsUUFBTyxNQUFNLEtBQUtBLE9BQU0sSUFBSUEsUUFBTyxLQUFLLEtBQUtBLE9BQU07QUFDekYsUUFBSSxTQUFTO0FBQ1osWUFBTSxNQUFNLEtBQUssTUFBTSxPQUFPLE1BQU0sYUFBYSxNQUFNLE9BQU8sRUFBRTtJQUNqRSxPQUFPO0FBQ04sWUFBTSxNQUFNLEtBQUssTUFBTSxPQUFPLE1BQU0sYUFBYSxFQUFFO0lBQ3BEO0VBQ0Q7Ozs7O0VBTVEsYUFBYSxPQUFlLE1BQVk7QUFDL0MsUUFBSSxLQUFLLFdBQVc7QUFBRyxhQUFPO0FBRzlCLFFBQUksS0FBSyxXQUFXLEdBQUc7QUFDdEIsVUFBSSxLQUFLLENBQUMsTUFBTSxHQUFNO0FBQ3JCLGVBQU87TUFDUixPQUFPO0FBQ04sZUFBTyxTQUFTLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQztNQUMvQjtJQUNEO0FBRUEsWUFBUSxPQUFPOzs7TUFHZCxLQUFLLGFBQWE7QUFDakIsY0FBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixjQUFNLE9BQU8sTUFBTSxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUMsRUFDdEMsSUFBSSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFDakUsS0FBSyxHQUFHO0FBQ1YsZUFBTyxNQUFNLEtBQUssSUFBSSxJQUFJO01BQzNCOzs7OztNQU1BLEtBQUssY0FBYztBQUNsQixZQUFJLEtBQUssV0FBVyxHQUFHO0FBQ3RCLGlCQUFPLEtBQUssQ0FBQyxNQUFNLElBQU8sV0FBVyxXQUFXLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQztRQUMvRDtBQUNBLFlBQUksS0FBSyxVQUFVLEdBQUc7QUFDckIsZ0JBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsZ0JBQU0sWUFBWSxLQUFLLENBQUM7QUFDeEIsZ0JBQU0sYUFBYSxLQUFLLFNBQVMsQ0FBQztBQUNsQyxnQkFBTSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUNoRixnQkFBTSxjQUFjLFFBQVEsUUFBUSxXQUFXLE1BQU0sU0FBUyxDQUFDO0FBQy9ELGdCQUFNLFVBQVUsUUFBUSxVQUFVLENBQUMsR0FBRztBQUN0QyxnQkFBTSxXQUFXLFdBQVcsV0FBVyxJQUFJLFdBQVcsQ0FBQyxJQUFJO0FBQzNELGdCQUFNLGNBQ0wsV0FBVyxhQUFhLFNBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7QUFDckYsZ0JBQU0sV0FBVyxjQUFjLEdBQUcsV0FBVyxLQUFLLE1BQU0sUUFBUyxDQUFDLE1BQU0sV0FBVyxNQUFNLEtBQUssVUFBVSxDQUFDO0FBQ3pHLGdCQUFNLFNBQVMsSUFBSSxNQUFNLEtBQUssQ0FBQyxJQUFJLE1BQU0sU0FBUyxDQUFDLEtBQUssV0FBVyxNQUFNLEtBQUssVUFBVSxDQUFDLENBQUM7QUFDMUYsaUJBQU8sV0FBVyxLQUFLLE1BQU0sV0FBVyxLQUFLLFFBQVEsSUFBSSxNQUFNO1FBQ2hFO0FBQ0EsZUFBTyxRQUFRLEtBQUssU0FBUyxLQUFLLENBQUM7TUFDcEM7O01BR0EsS0FBSyxpQkFBaUI7QUFFckIsWUFBSSxLQUFLLFVBQVUsR0FBRztBQUNyQixnQkFBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixnQkFBTSxZQUFZLEtBQUssQ0FBQztBQUN4QixnQkFBTSxhQUFhLEtBQUssU0FBUyxDQUFDO0FBQ2xDLGdCQUFNLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxTQUFTO0FBQ2hGLGdCQUFNLGNBQWMsUUFBUSxRQUFRLFdBQVcsTUFBTSxTQUFTLENBQUM7QUFDL0QsZ0JBQU0sV0FBVyxXQUFXLFdBQVcsSUFBSSxXQUFXLENBQUMsSUFBSTtBQUMzRCxnQkFBTSxVQUFVLFFBQVEsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTyxHQUFHO0FBQ2hFLGdCQUFNLGNBQ0wsV0FBVyxhQUFhLFNBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7QUFDckYsZ0JBQU0sV0FBVyxlQUFlLEtBQUssV0FBVyxTQUFTLEtBQUssQ0FBQztBQUMvRCxpQkFBTyxXQUFXLEtBQUssTUFBTSxXQUFXLEtBQUssUUFBUTtRQUN0RDtBQUNBLGVBQU87TUFDUjs7TUFHQSxLQUFLO01BQ0wsS0FBSyxhQUFhO0FBQ2pCLFlBQUksS0FBSyxTQUFTO0FBQUcsaUJBQU87QUFDNUIsY0FBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixjQUFNLFlBQVksS0FBSyxDQUFDO0FBQ3hCLGNBQU0sUUFBUSxLQUFLLFNBQVMsQ0FBQztBQUM3QixlQUFPLE1BQU0sS0FBSyxZQUFZLE1BQU0sU0FBUyxDQUFDLFVBQVUsTUFBTSxTQUFTLEtBQUssQ0FBQztNQUM5RTtNQUVBO0FBQ0MsZUFBTztJQUNUO0VBQ0Q7RUFFUSxPQUFPLGdCQUFnQixPQUFjO0FBQzVDLFFBQUksT0FBTyxVQUFVO0FBQVcsYUFBTyxDQUFDLFFBQVEsSUFBSSxDQUFDO0FBQ3JELFFBQUksTUFBTSxRQUFRLEtBQUs7QUFBRyxhQUFPLE1BQU0sSUFBSSxDQUFDLE1BQU0sT0FBTyxDQUFDLElBQUksR0FBSTtBQUNsRSxRQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzlCLFVBQUksUUFBUTtBQUFNLGVBQU8sQ0FBRSxTQUFTLEtBQU0sS0FBTyxTQUFTLElBQUssS0FBTSxRQUFRLEdBQUk7QUFDakYsYUFBTyxDQUFDLFFBQVEsR0FBSTtJQUNyQjtBQUNBLFVBQU0sSUFBSSxNQUFNLDRDQUE0QyxLQUFLLEVBQUU7RUFDcEU7RUFFUSxNQUFNLFlBQVksVUFBa0IsUUFBYztBQUN6RCxRQUFJLE1BQU0sS0FBSyxTQUFTLElBQUksTUFBTTtBQUNsQyxRQUFJLENBQUMsS0FBSztBQUNULFlBQU0sTUFBTSxxQkFBcUIsTUFBTTtBQUN2QyxXQUFLLFNBQVMsSUFBSSxRQUFRLEdBQUc7SUFDOUI7QUFFQSxXQUFPLE9BQU8sT0FBTztNQUNwQixPQUFPLEtBQUssQ0FBQyxLQUFNLEtBQU0sR0FBTSxXQUFXLEtBQU0sR0FBTSxLQUFNLEdBQU0sR0FBTSxHQUFHLEtBQUssR0FBTSxDQUFJLENBQUM7TUFDM0YsT0FBTyxLQUFLLFlBQVksTUFBTTtLQUM5QjtFQUNGO0VBRVEsT0FBTyxVQUFVLE1BQWM7QUFDdEMsUUFBSSxNQUFNO0FBQ1YsZUFBVyxLQUFLLE1BQU07QUFDckIsYUFBTztBQUNQLGVBQVMsSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0FBQzNCLGVBQU8sTUFBTSxTQUFVLEtBQU0sT0FBTyxJQUFLLE9BQVEsTUFBUSxPQUFPLElBQUs7TUFDdEU7SUFDRDtBQUNBLFdBQU87RUFDUjs7Ozs7Ozs7OztFQVdPLGdCQUFnQixJQUFZLE9BQWUsV0FBbUIsT0FBYztBQUNsRixVQUFNLE1BQU0sY0FBYyxLQUFLLE9BQU8sT0FBTyxXQUFXLEtBQUs7QUFDN0QsV0FBTyxLQUFLLFlBQVksSUFBSSxFQUFFLEdBQUcsSUFBSSxHQUFHO0VBQ3pDO0VBRU8sTUFBTSxZQUFZLFFBQWM7QUFDdEMsV0FBTyxLQUFLLGFBQWEsa0JBQWtCLFFBQVcsR0FBTSxRQUFXLFFBQVEsS0FBSztFQUNyRjtFQUVPLE1BQU0sY0FBYyxRQUFjO0FBQ3hDLFdBQU8sS0FBSyxhQUFhLHFCQUFxQixRQUFXLFFBQVcsUUFBVyxRQUFRLEtBQUs7RUFDN0Y7Ozs7QUc5MUJELElBQU1HLFVBQVMsbUJBQW1CLGdCQUFnQjtBQU1sRCxJQUFxQixpQkFBckIsY0FBNEMsYUFBeUI7RUFDcEU7O0VBQ0E7OztFQUlRLG9CQUFrQyxDQUFBOzs7RUFJMUMsY0FBc0I7RUFFdEIsWUFBWSxVQUFpQjtBQUM1QixVQUFNLFFBQVE7RUFDZjtFQUVBLE1BQU0sS0FBSyxRQUFvQjtBQUM5QixTQUFLLFNBQVM7QUFDZCxRQUFJLENBQUMsS0FBSyxjQUFjO0FBQ3ZCLFdBQUssZUFBZSxJQUFJLGFBQVk7SUFDckM7QUFDQSxTQUFLLGFBQWEsZUFBZSxZQUFZLHdCQUF3QjtBQUdyRSxTQUFLLGFBQWEsb0JBQW9CLENBQUMsZUFBc0I7QUFDNUQsV0FBSyxlQUFlLFVBQVU7SUFDL0IsQ0FBQztBQUlELFNBQUssYUFBWSxFQUFHLE1BQU0sQ0FBQyxNQUFLO0FBQy9CLE1BQUFBLFFBQU8sTUFBTSxxQkFBcUIsQ0FBQyxFQUFFO0lBQ3RDLENBQUM7RUFDRjs7Ozs7OztFQVFRLE1BQU0sZUFBWTtBQUN6QixJQUFBQSxRQUFPLEtBQUssOEJBQThCO0FBRTFDLFNBQUssb0JBQW9CLE1BQU0sS0FBSyxhQUFhLGdCQUFlO0FBR2hFLFFBQUk7QUFDSixRQUFJLEtBQUssa0JBQWtCLFdBQVcsR0FBRztBQUN4QyxVQUFJLEtBQUssT0FBTyxXQUFXO0FBQzFCLFFBQUFBLFFBQU8sS0FBSyxxQkFBcUIsS0FBSyxPQUFPLFNBQVMsOENBQXlDO0FBQy9GLGFBQUssYUFBYSxlQUFlLG1CQUFtQixJQUFJLEtBQUssT0FBTyxTQUFTLGFBQWE7QUFDMUY7TUFDRDtBQUNBLFlBQU0sY0FBYyxLQUFLLE9BQU87QUFDaEMsVUFBSSxDQUFDLEtBQUssT0FBTyxRQUFRLENBQUMsYUFBYTtBQUN0QyxRQUFBQSxRQUFPLEtBQUsseURBQXlEO0FBQ3JFO01BQ0Q7QUFDQSxNQUFBQSxRQUFPLEtBQUssd0VBQW1FO0FBQy9FLHVCQUFpQjtJQUNsQixPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLGNBQWMsS0FBSyxrQkFBa0IsTUFBTSxhQUFhO0FBQ3BFLGlCQUFXLEtBQUssS0FBSyxtQkFBbUI7QUFDdkMsUUFBQUEsUUFBTyxLQUFLLGFBQWEsRUFBRSxLQUFLLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFO01BQ3JFO0FBS0EsaUJBQVcsVUFBVSxLQUFLLG1CQUFtQjtBQUM1QyxhQUFLLGFBQWEsZ0JBQWdCLE9BQU8sRUFBRTtNQUM1QztBQUdBLGlCQUFXLFVBQVUsS0FBSyxtQkFBbUI7QUFDNUMsWUFBSTtBQUNILGdCQUFNLFdBQVcsTUFBTSxLQUFLLGFBQWEsdUJBQXVCLE9BQU8sRUFBRTtBQUN6RSxpQkFBTyxlQUFlO0FBQ3RCLFVBQUFBLFFBQU8sS0FBSyxPQUFPLE9BQU8sRUFBRSxjQUFjLFFBQVEsV0FBVyxPQUFPLGFBQWEsRUFBRTtRQUNwRixTQUFTLEdBQUc7QUFDWCxVQUFBQSxRQUFPLEtBQUssT0FBTyxPQUFPLEVBQUUsNkJBQTZCLENBQUMsRUFBRTtBQUM1RCxpQkFBTyxlQUFlO1FBQ3ZCO01BQ0Q7QUFFQSx1QkFBaUIsYUFBYSxLQUFLLFFBQVEsS0FBSyxpQkFBaUI7QUFFakUsVUFBSSxDQUFDLGtCQUFrQixLQUFLLE9BQU8sV0FBVztBQUM3QyxRQUFBQSxRQUFPLEtBQUsscUJBQXFCLEtBQUssT0FBTyxTQUFTLHNEQUFpRDtBQUN2RyxhQUFLLGFBQWEsZUFBZSxtQkFBbUIsSUFBSSxLQUFLLE9BQU8sU0FBUyxhQUFhO0FBQzFGO01BQ0Q7SUFDRDtBQUdBLFNBQUssVUFBVSxjQUFjO0FBSTdCLFVBQU0sYUFBYSxLQUFLO0FBQ3hCLFVBQU0sS0FBSyxvQkFBb0IsSUFBSSxVQUFVO0FBRzdDLFNBQUssY0FBYTtBQUNsQixTQUFLLGdCQUFlO0FBQ3BCLFNBQUssMEJBQXlCO0FBQzlCLFNBQUsscUJBQW9CO0FBRXpCLElBQUFBLFFBQU8sS0FBSywyQkFBMkI7RUFDeEM7O0VBR0EsTUFBTSxVQUFPO0FBQ1osU0FBSyxjQUFjLE1BQUs7QUFDeEIsSUFBQUEsUUFBTyxNQUFNLFNBQVM7RUFDdkI7RUFFQSxNQUFNLGNBQWMsUUFBb0I7QUFDdkMsVUFBTSxlQUFlLEtBQUs7QUFDMUIsU0FBSyxTQUFTO0FBQ2QsVUFBTSxpQkFBaUIsYUFBYSxRQUFRLEtBQUssaUJBQWlCO0FBQ2xFLFNBQUssVUFBVSxjQUFjO0FBSTdCLFNBQUsscUJBQW9CO0FBRXpCLFVBQU0sVUFBVSxLQUFLO0FBSXJCLFVBQU0sS0FBSyxvQkFBb0IsY0FBYyxPQUFPO0FBR3BELFNBQUssY0FBYTtBQUNsQixTQUFLLGdCQUFlO0FBQ3BCLFNBQUssMEJBQXlCO0FBQzlCLFNBQUsscUJBQW9CO0VBQzFCOzs7Ozs7Ozs7Ozs7RUFhUSxNQUFNLG9CQUFvQixjQUFzQixTQUFlO0FBQ3RFLFFBQUksQ0FBQyxTQUFTO0FBQ2IsVUFBSTtBQUFjLGFBQUssYUFBYSxhQUFhLFlBQVk7QUFDN0Q7SUFDRDtBQUVBLFFBQUksS0FBSyxPQUFPLFdBQVc7QUFFMUIsWUFBTSxTQUFTLEtBQUssa0JBQWtCLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxLQUFLLE9BQU8sU0FBUztBQUNqRixVQUFJLENBQUMsUUFBUTtBQUNaLFFBQUFBLFFBQU8sS0FBSyxlQUFlLEtBQUssT0FBTyxTQUFTLHlEQUFvRDtBQUNwRyxZQUFJO0FBQWMsZUFBSyxhQUFhLGFBQWEsWUFBWTtBQUM3RDtNQUNEO0FBRUEsVUFBSSxnQkFBZ0IsaUJBQWlCLFNBQVM7QUFDN0MsYUFBSyxhQUFhLGFBQWEsWUFBWTtNQUM1QztBQUNBLFlBQU0sZ0JBQWdCLEtBQUssYUFBYSxtQkFBbUIsT0FBTztBQUNsRSxVQUFJLENBQUMsZUFBZTtBQUNuQixhQUFLLGFBQWEsZ0JBQWdCLE9BQU87TUFDMUM7QUFDQSxVQUFJLFlBQVksZ0JBQWdCLENBQUMsZUFBZTtBQUMvQyxjQUFNLEtBQUssNkJBQTZCLE9BQU8sT0FBTyxPQUFPO01BQzlEO0FBQ0EsV0FBSyxhQUFhLGVBQWUsSUFBSSxTQUFTLE9BQU8sS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUN6RTtJQUNEO0FBR0EsVUFBTSxjQUFjLE9BQU8sS0FBSyxPQUFPLGVBQWUsRUFBRTtBQUN4RCxVQUFNLGlCQUFpQixLQUFLLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUUxRSxRQUFJLGdCQUFnQjtBQUNuQixVQUFJLGVBQWUsVUFBVSxhQUFhO0FBQ3pDLFlBQUksZ0JBQWdCLGlCQUFpQjtBQUFTLGVBQUssYUFBYSxhQUFhLFlBQVk7QUFDekYsY0FBTSxnQkFBZ0IsS0FBSyxhQUFhLG1CQUFtQixPQUFPO0FBQ2xFLFlBQUksQ0FBQyxlQUFlO0FBQ25CLGVBQUssYUFBYSxnQkFBZ0IsT0FBTztRQUMxQztBQUNBLFlBQUksWUFBWSxnQkFBZ0IsQ0FBQyxlQUFlO0FBQy9DLGdCQUFNLEtBQUssNkJBQTZCLGFBQWEsT0FBTztRQUM3RDtBQUNBLGFBQUssYUFBYSxlQUFlLElBQUksU0FBUyxXQUFXLE1BQU0sT0FBTyxFQUFFO01BQ3pFLE9BQU87QUFDTixRQUFBQSxRQUFPLE1BQ04sMEJBQTBCLFdBQVcsMkNBQTJDLGVBQWUsS0FBSyxRQUFRLE9BQU8sMEJBQXFCO0FBRXpJLGFBQUssYUFBYSxhQUFhLE9BQU87QUFDdEMsYUFBSyxhQUNKLGVBQWUsbUJBQ2YsNEJBQTRCLFdBQVcsU0FBUyxlQUFlLEtBQUssRUFBRTtNQUV4RTtBQUNBO0lBQ0Q7QUFHQSxJQUFBQSxRQUFPLEtBQUssR0FBRyxPQUFPLHdDQUFtQztBQUN6RCxRQUFJLGdCQUFnQixpQkFBaUI7QUFBUyxXQUFLLGFBQWEsYUFBYSxZQUFZO0FBQ3pGLFNBQUssYUFBYSxhQUFhLE9BQU87QUFFdEMsVUFBTSxTQUFTLE1BQU0sS0FBSyxhQUFhLFlBQVksT0FBTztBQUMxRCxRQUFJLENBQUMsUUFBUTtBQUNaLE1BQUFBLFFBQU8sTUFBTSwwQkFBMEIsT0FBTywwQkFBcUI7QUFDbkUsV0FBSyxhQUFhLGVBQWUsZ0JBQWdCLG1CQUFtQixPQUFPLEVBQUU7SUFDOUUsV0FBVyxPQUFPLFVBQVUsYUFBYTtBQUN4QyxNQUFBQSxRQUFPLE1BQ04sMEJBQTBCLFdBQVcsMkNBQTJDLE9BQU8sS0FBSyxRQUFRLE9BQU8sMEJBQXFCO0FBRWpJLFdBQUssYUFDSixlQUFlLG1CQUNmLDRCQUE0QixXQUFXLFNBQVMsT0FBTyxLQUFLLEVBQUU7SUFFaEUsT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSyxrQkFBa0IsT0FBTyxLQUFLLE9BQU8sT0FBTyxFQUFFO0FBQzFELFdBQUssYUFBYSxnQkFBZ0IsT0FBTztBQUN6QyxZQUFNLEtBQUssNkJBQTZCLGFBQWEsT0FBTztBQUM1RCxXQUFLLGFBQWEsZUFBZSxJQUFJLFNBQVMsT0FBTyxLQUFLLE1BQU0sT0FBTyxFQUFFO0lBQzFFO0VBQ0Q7Ozs7O0VBTVEsTUFBTSw2QkFBNkIsT0FBZSxJQUFVO0FBQ25FLFFBQUk7QUFDSCxZQUFNLEtBQUssYUFBYSxtQkFBbUIsRUFBRTtBQUU3QyxVQUFJLENBQUMsZ0JBQWdCLEtBQUssR0FBRztBQUc1QixRQUFBQSxRQUFPLEtBQUssNkJBQTZCLEtBQUssc0RBQWlEO0FBQy9GO01BQ0Q7SUFDRCxTQUFTLEdBQUc7QUFDWCxNQUFBQSxRQUFPLEtBQUssaUNBQWlDLEVBQUUsS0FBSyxDQUFDLEVBQUU7SUFDeEQ7RUFDRDs7RUFHUSxVQUFVLE9BQWE7QUFDOUIsU0FBSyxjQUFjO0FBQ25CLFVBQU0sU0FBUyxnQkFBZ0IsS0FBSztBQUNwQyxRQUFJLENBQUMsUUFBUTtBQUNaLE1BQUFBLFFBQU8sS0FBSyxVQUFVLEtBQUssK0JBQStCO0FBQzFELFdBQUssYUFBYSxTQUFTLE9BQU8sQ0FBQSxDQUFFO0FBQ3BDO0lBQ0Q7QUFFQSxVQUFNLFVBQVUsTUFBTSxRQUFRLE9BQU8sU0FBUyxJQUFJLE9BQU8sWUFBWSxDQUFBO0FBRXJFLFNBQUssYUFBYSxTQUFTLE9BQU8sT0FBTztBQUN6QyxRQUFJLFFBQVEsV0FBVyxHQUFHO0FBQ3pCLE1BQUFBLFFBQU8sS0FBSywrQkFBK0IsS0FBSyw2Q0FBd0M7SUFDekYsT0FBTztBQUNOLE1BQUFBLFFBQU8sTUFBTSxVQUFVLFFBQVEsTUFBTSx1QkFBdUIsS0FBSyxHQUFHO0lBQ3JFO0VBQ0Q7RUFFQSxrQkFBZTtBQUNkLFdBQU8sZ0JBQWdCLEtBQUssaUJBQWlCO0VBQzlDOztFQUdBLElBQUksT0FBSTtBQUNQLFdBQU8sWUFBWSxLQUFLLFFBQVEsS0FBSyxpQkFBaUI7RUFDdkQ7O0VBR0EsSUFBSSxVQUFPO0FBQ1YsV0FBTyxLQUFLO0VBQ2I7RUFFQSxnQkFBYTtBQUNaLGtCQUFjLElBQUk7RUFDbkI7RUFFQSxrQkFBZTtBQUNkLG9CQUFnQixJQUFJO0VBQ3JCO0VBRUEsNEJBQXlCO0FBQ3hCLDhCQUEwQixJQUFJO0VBQy9CO0VBRUEsdUJBQW9CO0FBQ25CLHlCQUFxQixJQUFJO0VBQzFCOzsiLAogICJuYW1lcyI6IFsicGF0aCIsICJJbnN0YW5jZVN0YXR1cyIsICJSZWdleCIsICJwYXRoIiwgImZzIiwgImxvZ2dlciIsICJpZEFkZE9wdCIsICJmcyIsICJsb2dnZXIiLCAiZGV2aWNlc0ZvbGRlciIsICJwYXRoIiwgImRncmFtIiwgIm9zIiwgImxvZ2dlciIsICJkZ3JhbSIsICJsb2dnZXIiLCAic29jayIsICJkZ3JhbSIsICJsb2dnZXIiLCAiZGdyYW0iLCAib3MiLCAibG9nZ2VyIl0KfQo=
