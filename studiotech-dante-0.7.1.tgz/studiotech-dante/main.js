import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}
function combineRgb(r, g, b, a) {
  let colorNumber = (r & 255) << 16 | (g & 255) << 8 | b & 255;
  if (a && a >= 0 && a < 1) {
    colorNumber += 16777216 * Math.round(255 * (1 - a));
  }
  return colorNumber;
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path3, args) {
    this.#context.oscSend(host, port, path3, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/config.js
import fs from "fs";
import path from "path";
var logger = createModuleLogger("Config");
function resolveDevicesFolder() {
  const primaryPath = path.join(import.meta.dirname, "../devices");
  const fallbackPath = path.join(import.meta.dirname, "./devices");
  if (fs.existsSync(primaryPath)) {
    logger.debug(`Using devices folder: ${primaryPath}`);
    return primaryPath;
  }
  if (fs.existsSync(fallbackPath)) {
    logger.warn(`Primary devices folder not found, using fallback: ${fallbackPath}`);
    return fallbackPath;
  }
  const errorMsg = `Devices folder not found!
Tried:
  - ${primaryPath}
  - ${fallbackPath}
Module cannot continue without device schemas.`;
  logger.error(errorMsg);
  throw new Error(errorMsg);
}
var devicesFolder = resolveDevicesFolder();
var deviceSchemasCache = null;
function getDevicesFolder() {
  return devicesFolder;
}
function loadDeviceSchemas() {
  const schemas = {};
  try {
    const files = fs.readdirSync(devicesFolder).filter((f) => f.endsWith(".json"));
    for (const f of files) {
      const fullPath = path.join(devicesFolder, f);
      const json = JSON.parse(fs.readFileSync(fullPath, "utf8"));
      if (json?.model) {
        schemas[String(json.model)] = json;
      }
    }
    logger.debug(`Loaded ${Object.keys(schemas).length} device schemas into cache`);
  } catch (e) {
    logger.error(`Failed to load device schemas: ${e}`);
  }
  return schemas;
}
function getDeviceSchemas() {
  if (!deviceSchemasCache) {
    deviceSchemasCache = loadDeviceSchemas();
  }
  return deviceSchemasCache;
}
function getDeviceSchema(model) {
  const schemas = getDeviceSchemas();
  return schemas[model];
}
function reloadDeviceSchemas() {
  logger.info("Reloading device schemas from disk...");
  deviceSchemasCache = loadDeviceSchemas();
}
function loadAvailableModels() {
  const schemas = getDeviceSchemas();
  return Object.keys(schemas).sort();
}
function GetConfigFields(discoveredDevices = []) {
  const models = loadAvailableModels();
  const deviceChoices = [
    { id: "", label: "Manual (enter IP + model below)" },
    ...discoveredDevices.map((d) => ({
      id: d.mac ?? "",
      label: `Model ${d.model} [${d.mac}] @ ${d.ip}`
    }))
  ];
  return [
    // ── Device selection dropdown ────────────────────────────────────────
    // Stores the MAC so re-discovery with a changed IP still matches.
    {
      type: "dropdown",
      id: "deviceMac",
      label: "Device",
      width: 8,
      default: "",
      choices: deviceChoices,
      tooltip: "Select an auto-discovered Studio Technologies device, or choose Manual to enter an IP address."
    },
    // ── Manual IP entry — only visible in manual mode ────────────────────
    {
      type: "textinput",
      id: "host",
      label: "Target IP",
      width: 8,
      default: "",
      regex: Regex.IP,
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Enter the IP address of the device manually."
    },
    // ── Manual model selector — only visible in manual mode ──────────────
    {
      type: "dropdown",
      id: "activeModel",
      label: "Active Device Model",
      width: 8,
      default: models[0] ?? "",
      choices: models.map((model) => ({
        id: model,
        label: `Model ${model}`
      })),
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Select which Studio Technologies model is active for actions and feedbacks."
    },
    // ── Dev Mode ─────────────────────────────────────────────────────────
    {
      type: "checkbox",
      id: "devMode",
      label: "Dev Mode",
      width: 12,
      default: false,
      tooltip: "Enable to allow parsing of ST Devices not currently supported"
    }
  ];
}
function resolveHost(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    return device?.ip ?? "";
  }
  return String(config.host ?? "");
}
function resolveModel(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    logger.debug(`resolveModel: deviceMac="${config.deviceMac}", found device: ${device?.model ?? "none"}`);
    return device?.model ?? "";
  }
  logger.debug(`resolveModel: manual mode, activeModel="${config.activeModel}"`);
  return String(config.activeModel ?? "");
}

// dist/variables.js
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions({
    model: { name: "Device Model Number" },
    modelName: { name: "Device Model Name (Full Description)" },
    manufacturer: { name: "Device Manufacturer" },
    firmware: { name: "Device Firmware Version" },
    danteFW: { name: "Dante Module Firmware Version" },
    mac: { name: "Device MAC Address" },
    ip: { name: "Device IP Address" }
  });
}
var CLEARED_VARIABLES = {
  model: "",
  modelName: "",
  manufacturer: "",
  firmware: "",
  danteFW: "",
  mac: "",
  ip: ""
};
function UpdateVariableValues(self) {
  const currentHost = self.host;
  if (!currentHost || !self.stController.isDeviceAuthorized(currentHost)) {
    self.setVariableValues(CLEARED_VARIABLES);
    return;
  }
  const device = self.devices.find((d) => d.ip === currentHost);
  if (device) {
    self.setVariableValues({
      model: device.model || "",
      modelName: device.modelName || "",
      manufacturer: device.manufacturer || "",
      firmware: device.firmwareMain || "",
      danteFW: device.danteFirmware || "",
      mac: device.mac || "",
      ip: device.ip
    });
  } else {
    self.setVariableValues({
      ...CLEARED_VARIABLES,
      ip: currentHost
    });
  }
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  // function (context, props) {
  // 	return {
  // 		updatedConfig: null,
  // 		updatedActions: [],
  // 		updatedFeedbacks: [],
  // 	}
  // },
];

// dist/types.js
var CMD_GET_FIRMWARE = 0;
var CMD_MIC_PRE = 2;
var CMD_BUS_GET = 3;
var CMD_BUS_SET = 4;
var CMD_HEADPHONE = 5;
var CMD_BUTTON_MODE = 7;
var CMD_SYSTEM = 9;
var CMD_GET_ALL_SETTINGS = 10;
var CMD_SETTINGS_PUSH = 11;
var CMD_DEV_SPEC = 13;
var CMD_RESET_DEVICE = 14;
var CMD_GLOBAL_MIC_KILL = 16;
var CMD_MIC_PRE_BUS = 18;
var CMD_CHANNEL = 20;
function getCommandName(cmdId) {
  switch (cmdId) {
    case CMD_GET_FIRMWARE:
      return "Get Firmware Version";
    case CMD_MIC_PRE:
      return "Mic Preamp";
    case CMD_BUS_GET:
      return "Heartbeat";
    case CMD_BUS_SET:
      return "Set Bus Setting";
    case CMD_HEADPHONE:
      return "Headphone Control";
    case CMD_BUTTON_MODE:
      return "Button Mode";
    case CMD_SYSTEM:
      return "System Command";
    case CMD_GET_ALL_SETTINGS:
      return "Request All Settings";
    case CMD_SETTINGS_PUSH:
      return "Settings Push";
    case CMD_MIC_PRE_BUS:
      return "Mic/Pre Bus";
    case CMD_DEV_SPEC:
      return "Device Setting";
    case CMD_CHANNEL:
      return "Channel Setting";
    case CMD_RESET_DEVICE:
      return "Reset Device";
    case CMD_GLOBAL_MIC_KILL:
      return "Global Mic Kill";
    default:
      return `cmd_0x${cmdId.toString(16).padStart(2, "0")}`;
  }
}
function makeSettingId(model, cmdId, settingId, busCh) {
  const cmd = typeof cmdId === "number" ? cmdId.toString(16) : cmdId;
  const id = typeof settingId === "number" ? settingId.toString(16) : settingId;
  if (busCh !== void 0) {
    const ch = typeof busCh === "number" ? busCh.toString(16) : busCh;
    return `${model}_${cmd}_${ch}_${id}`;
  }
  return `${model}_${cmd}_${id}`;
}
function toHex(value, padLength = 2) {
  return `0x${value.toString(16).padStart(padLength, "0")}`;
}
function bytesToHex(bytes) {
  return `0x${Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}
function formatRgbColor(r, g, b) {
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}
function parseSettingId(id) {
  const [model, cmdIdStr, idStr] = id.split("_");
  return {
    model,
    cmdId: parseInt(cmdIdStr, 16),
    baseId: parseInt(idStr, 16)
  };
}
function modelDistance(modelA, modelB) {
  const na = parseInt(modelA.replace(/\D/g, ""), 10);
  const nb = parseInt(modelB.replace(/\D/g, ""), 10);
  if (Number.isNaN(na) || Number.isNaN(nb))
    return Infinity;
  return Math.abs(na - nb);
}
function getNormalizedSchemas(schemasRaw) {
  const normalized = {};
  for (const [model, json] of Object.entries(schemasRaw)) {
    normalized[model] = {
      model: json.model,
      cmdSchema: Array.isArray(json.cmdSchema) ? json.cmdSchema : []
    };
  }
  return normalized;
}
function findActionForSetting(schemas, model, cmdId, settingId) {
  const schema = schemas[model];
  if (!schema || !Array.isArray(schema.cmdSchema))
    return void 0;
  let action = schema.cmdSchema.find((s) => s.cmd_id === cmdId && s.id === settingId);
  if (!action) {
    action = schema.cmdSchema.find((s) => {
      if (s.cmd_id !== cmdId)
        return false;
      const idAddOption = s.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const offset = settingId - s.id;
      return idAddOption.choices.some((c) => c.id === offset);
    });
  }
  return action;
}

// dist/build-commands.js
function buildOption(o) {
  const base = {
    type: o.type,
    id: o.id,
    label: o.label,
    default: o.default,
    tooltip: o.tooltip
  };
  switch (o.type) {
    case "dropdown":
      return { ...base, choices: o.choices ?? [] };
    case "number":
      return {
        ...base,
        min: o.min,
        max: o.max,
        step: o.step ?? 1,
        range: true
      };
    case "checkbox":
      return { ...base, default: o.default ?? false };
    case "static-text":
      return { ...base, value: o.value ?? "" };
    case "textinput":
    case "colorpicker":
    default:
      return base;
  }
}
function buildActions() {
  const schemas = getDeviceSchemas();
  const actions = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const a of cmdSchema) {
      if (a.readonly === true)
        continue;
      const actionId = makeSettingId(model, a.cmd_id, a.id);
      const options = (a.options ?? []).map(buildOption);
      const action = {
        name: `[Model${model}] ${a.name}`,
        options,
        callback: async () => {
        }
      };
      actions[actionId] = action;
    }
  }
  return actions;
}
function isBooleanDropdown(setting) {
  const valueOpt = setting.options?.find((o) => o.id === "value");
  if (!valueOpt)
    return false;
  if (valueOpt.type === "checkbox")
    return true;
  if (valueOpt.type !== "dropdown" || !Array.isArray(valueOpt.choices))
    return false;
  if (valueOpt.choices.length !== 2)
    return false;
  const labels = valueOpt.choices.map((c) => String(c.label).toLowerCase());
  return labels.includes("off") && labels.includes("on");
}
function buildFeedbacks() {
  const schemas = getDeviceSchemas();
  const feedbacks = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const setting of cmdSchema) {
      if (setting.writeonly === true)
        continue;
      const baseFeedbackId = makeSettingId(model, setting.cmd_id, setting.id);
      const allOptions = (setting.options ?? []).map(buildOption);
      const valueOptions = allOptions.filter((opt) => opt.id !== "value");
      const isColorSetting = setting.options?.some((o) => o.id === "value" && o.type === "colorpicker");
      if (!isColorSetting) {
        valueOptions.push({
          type: "checkbox",
          id: "showLabel",
          label: "Use Label for Value",
          default: false,
          tooltip: "Return the label text instead of the numeric value"
        });
      }
      const valueFeedback = {
        type: "value",
        name: `[Model${model}] ${setting.name}`,
        options: valueOptions,
        callback: () => {
          return 0;
        }
      };
      feedbacks[baseFeedbackId] = valueFeedback;
      if (isBooleanDropdown(setting)) {
        const boolFeedbackId = `${baseFeedbackId}_bool`;
        const boolOptions = allOptions.filter((opt) => opt.id !== "value");
        const boolFeedback = {
          type: "boolean",
          name: `[Model${model}] ${setting.name} \u2014 Is On`,
          defaultStyle: {
            bgcolor: combineRgb(0, 200, 0),
            color: combineRgb(0, 0, 0)
          },
          options: boolOptions,
          callback: () => {
            return false;
          }
        };
        feedbacks[boolFeedbackId] = boolFeedback;
      }
    }
  }
  return feedbacks;
}

// dist/actions.js
import path2 from "path";

// dist/settingsParser.js
import fs2 from "fs";
var logger2 = createModuleLogger("SettingsParser");
function getRgbIds(model) {
  const rgbIds = /* @__PURE__ */ new Set();
  try {
    const json = getDeviceSchema(model);
    if (!json)
      return rgbIds;
    for (const action of json.cmdSchema || []) {
      const hasColorpicker = action.options?.some((opt) => opt.type === "colorpicker");
      if (hasColorpicker) {
        rgbIds.add(action.id);
        const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
        if (idAddOption?.choices) {
          for (const choice of idAddOption.choices) {
            if (typeof choice.id === "number") {
              rgbIds.add(action.id + choice.id);
            }
          }
        }
      }
    }
  } catch (_err) {
  }
  return rgbIds;
}
function extractStPayloadIndex(buf) {
  const sigIndex = buf.indexOf(Buffer.from("Studio-T"));
  if (sigIndex < 0)
    throw new Error("No Studio-T signature in packet");
  const payloadIndex = sigIndex + 8;
  if (buf[payloadIndex] !== 90) {
    throw new Error(`Expected 0x5A after Studio-T, found ${buf[payloadIndex].toString(16)}`);
  }
  return payloadIndex;
}
function parseGetAllSettings_sectioned(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  let p = cmdId === CMD_GET_ALL_SETTINGS ? idx + 3 : idx + 2;
  const end = buf.length - 1;
  const out = [];
  const rgbIds = getRgbIds(model);
  const commandsWithBusCh = [CMD_BUS_SET, CMD_MIC_PRE_BUS, CMD_CHANNEL];
  const commandsRawValue = [CMD_MIC_PRE];
  while (p + 2 < end) {
    const cmdLen = buf[p];
    const sectionCmdId = buf[p + 1];
    const sectionEnd = p + 1 + cmdLen;
    if (sectionEnd > end)
      break;
    const hasBusCh = commandsWithBusCh.includes(sectionCmdId);
    const isRawValue = commandsRawValue.includes(sectionCmdId);
    let busCh;
    let dataLen;
    let q;
    if (isRawValue) {
      busCh = buf[p + 2];
      const rawBytes = buf.subarray(p + 3, sectionEnd);
      const schema = getDeviceSchema(model);
      const micPreEntries = (schema?.cmdSchema ?? []).filter((a) => (a.cmd_id === CMD_MIC_PRE || a.cmd_id === CMD_MIC_PRE_BUS) && a.busCh !== void 0).sort((a, b) => a.id - b.id);
      for (let i = 0; i < rawBytes.length; i++) {
        const entry = micPreEntries[i];
        if (entry) {
          out.push({ cmd_id: entry.cmd_id, id: entry.id, busCh, valueBytes: [rawBytes[i]] });
        }
      }
      p = sectionEnd;
      continue;
    } else if (hasBusCh) {
      busCh = buf[p + 2];
      dataLen = buf[p + 3];
      q = p + 4;
    } else {
      dataLen = buf[p + 2];
      q = p + 3;
    }
    const qEnd = q + dataLen;
    const qStart = q;
    while (q + 1 < qEnd) {
      const id = buf[q];
      let valueBytes;
      if (rgbIds.has(id) && q + 3 < qEnd) {
        valueBytes = [buf[q + 1], buf[q + 2], buf[q + 3]];
        q += 4;
      } else {
        valueBytes = [buf[q + 1]];
        q += 2;
      }
      const setting = {
        cmd_id: sectionCmdId,
        id,
        valueBytes
      };
      if (busCh !== void 0) {
        setting.busCh = busCh;
      }
      out.push(setting);
    }
    if (q === qStart && sectionEnd > p + 3) {
      let pos = hasBusCh ? p + 3 : p + 2;
      let posId = 0;
      while (pos < sectionEnd) {
        const setting = { cmd_id: sectionCmdId, id: posId++, valueBytes: [buf[pos++]] };
        if (busCh !== void 0)
          setting.busCh = busCh;
        out.push(setting);
      }
    }
    p = sectionEnd;
  }
  return out;
}
function parseSettingsResponse(model, buf) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error(`Not a settings block (cmdId=0x${cmdId.toString(16)})`);
  }
  return parseGetAllSettings_sectioned(buf, model);
}
function formatParsedSetting(setting, actions) {
  let action = actions.find((a) => a.cmd_id === setting.cmd_id && a.id === setting.id);
  if (!action) {
    const baseAction = actions.find((a) => {
      if (a.cmd_id !== setting.cmd_id)
        return false;
      const idAddOption = a.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const channelOffset = setting.id - a.id;
      return idAddOption.choices.some((c) => c.id === channelOffset);
    });
    if (baseAction) {
      action = baseAction;
    }
  }
  const cmdHex = toHex(setting.cmd_id);
  const idHex = toHex(setting.id);
  const valHex = bytesToHex(setting.valueBytes);
  const valDec = setting.valueBytes.length === 3 ? formatRgbColor(setting.valueBytes[0], setting.valueBytes[1], setting.valueBytes[2]) : setting.valueBytes.length === 1 ? setting.valueBytes[0] : setting.valueBytes.join(",");
  const busChStr = setting.busCh !== void 0 ? ` ch:${setting.busCh}` : "";
  const prefix = `cmd:${cmdHex}${busChStr} id:${idHex} val:${valHex}`;
  if (action) {
    let name = action.name;
    if (setting.busCh !== void 0) {
      name = `${name} Ch${setting.busCh + 1}`;
    } else {
      const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
      if (idAddOption?.choices) {
        const channelOffset = setting.id - action.id;
        const idAddChoice = idAddOption.choices.find((c) => c.id === channelOffset);
        if (idAddChoice) {
          name = `${name} ${idAddChoice.label}`;
        }
      }
    }
    const valueOption = action.options?.find((opt) => opt.id === "value");
    if (valueOption?.choices && setting.valueBytes.length === 1) {
      const choice = valueOption.choices.find((c) => c.id === setting.valueBytes[0]);
      if (choice) {
        return `${prefix} | ${name}: ${choice.label} (${valDec})`;
      }
    }
    return `${prefix} | ${name}: ${valDec}`;
  }
  return `${prefix} | Unknown Setting`;
}
function parseGetAllSettingsWithDetection(model, buf) {
  const settings = parseGetAllSettings_sectioned(buf, model);
  return { settings, detectedSectioned: null };
}
function parseGetAllSettingsForModel(model, buf) {
  return parseGetAllSettings_sectioned(buf, model);
}
function valueBytesToOption(valueBytes) {
  if (valueBytes.length === 1) {
    return { id: "value", label: "Value", type: "number", default: valueBytes[0] };
  }
  if (valueBytes.length === 3) {
    const [r, g, b] = valueBytes;
    return {
      id: "value",
      label: "Color",
      type: "colorpicker",
      default: formatRgbColor(r, g, b)
    };
  }
  return { id: "value", label: "Value", type: "raw", default: [...valueBytes] };
}
function updateModelJsonFromSettings(modelJson, parsed, allModels) {
  const out = structuredClone(modelJson);
  if (!out.cmdSchema) {
    out.cmdSchema = [];
  }
  const candidates = Object.values(allModels).filter((m) => m.model !== modelJson.model).sort((a, b) => modelDistance(modelJson.model, a.model) - modelDistance(modelJson.model, b.model));
  logger2.info(`Updating model: ${modelJson.model}`);
  logger2.debug(`Candidates for inference: ${candidates.map((c) => c.model).join(", ")}`);
  const idAddDeferRanges = /* @__PURE__ */ new Map();
  for (const c of candidates) {
    for (const baseEntry of c.cmdSchema ?? []) {
      const idAddOpt = baseEntry.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        continue;
      const baseId = baseEntry.id;
      const cmdId = baseEntry.cmd_id;
      const key = `${cmdId}_${baseId}`;
      if (idAddDeferRanges.has(key))
        continue;
      const parsedOffsets = parsed.filter((p) => p.cmd_id === cmdId && p.id > baseId).map((p) => p.id - baseId).sort((a, b) => a - b);
      let maxSeq = 0;
      for (const off of parsedOffsets) {
        if (off === maxSeq + 1)
          maxSeq = off;
        else if (off > maxSeq + 1)
          break;
      }
      if (maxSeq > 0) {
        idAddDeferRanges.set(key, maxSeq);
        logger2.debug(`idAdd defer range for cmd_id=${toHex(cmdId)} base_id=${toHex(baseId)}: offsets 1\u2013${maxSeq}`);
      }
    }
  }
  const busChSeen = /* @__PURE__ */ new Map();
  for (const { cmd_id, id, busCh } of parsed) {
    if (busCh === void 0)
      continue;
    const key = `${cmd_id}_${id}`;
    if (!busChSeen.has(key))
      busChSeen.set(key, /* @__PURE__ */ new Set());
    busChSeen.get(key).add(busCh);
  }
  for (const { cmd_id, id, busCh, valueBytes } of parsed) {
    const existingExact = out.cmdSchema.find((a) => a.cmd_id === cmd_id && a.id === id);
    if (existingExact) {
      const opt = existingExact.options?.find((o) => o.id === "value");
      if (opt)
        opt.default = valueBytesToOption(valueBytes).default;
      const seenBusChValues = busChSeen.get(`${cmd_id}_${id}`);
      if (seenBusChValues && seenBusChValues.size > 0) {
        const maxBusCh = Math.max(...seenBusChValues);
        const hasBusChOption = existingExact.options?.some((o) => o.id === "busCh");
        if (maxBusCh === 0 && existingExact.busCh === void 0 && !hasBusChOption) {
          existingExact.busCh = 0;
          logger2.info(`Synced busCh=0 onto existing entry cmd_id=${toHex(cmd_id)} id=${toHex(id)}`);
        }
      }
      continue;
    }
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt = a.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        return false;
      if (id <= a.id)
        return false;
      const offset = id - a.id;
      return candidates.some((c) => {
        const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === a.id);
        const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
        return refIdAdd?.choices?.some((ch) => ch.id === offset);
      });
    });
    if (idAddBase) {
      const offset = id - idAddBase.id;
      const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
      if (idAddOpt?.choices && !idAddOpt.choices.some((c) => c.id === offset)) {
        let label = `Channel ${offset + 1}`;
        for (const c of candidates) {
          const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
          const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
          const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
          if (refChoice) {
            label = refChoice.label;
            break;
          }
        }
        idAddOpt.choices.push({ id: offset, label });
        logger2.info(`Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
      }
      continue;
    }
    let action;
    for (const c of candidates) {
      const match = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === id);
      if (match) {
        action = structuredClone(match);
        const baseName = match.name.replace(/\s*\(inferred from Model [^)]+\)/g, "").trim();
        action.name = `${baseName} (inferred from Model ${c.model})`;
        logger2.info(`Inferred cmd_id=${toHex(cmd_id)} id=${toHex(id)} from Model ${c.model} (exact)`);
        break;
      }
    }
    if (!action) {
      let shouldDefer = false;
      for (const c of candidates) {
        const baseEntry = c.cmdSchema?.find((a) => {
          if (a.cmd_id !== cmd_id)
            return false;
          const idAddOpt = a.options?.find((o) => o.id === "idAdd");
          if (!idAddOpt?.choices)
            return false;
          if (id <= a.id)
            return false;
          const offset = id - a.id;
          const maxSeq = idAddDeferRanges.get(`${cmd_id}_${a.id}`) ?? 0;
          return offset <= maxSeq;
        });
        if (baseEntry) {
          shouldDefer = true;
          logger2.debug(`cmd_id=${toHex(cmd_id)} id=${toHex(id)} is an idAdd offset of candidate base id=${toHex(baseEntry.id)} \u2014 deferring to pass 2`);
          break;
        }
      }
      if (shouldDefer)
        continue;
    }
    if (!action) {
      action = {
        cmd_id,
        id,
        name: `Unknown cmd:${toHex(cmd_id)} id:${toHex(id).toUpperCase()}`,
        options: [valueBytesToOption(valueBytes)]
      };
      if (busCh !== void 0)
        action.busCh = busCh;
      logger2.warn(`Could not infer cmd_id=${toHex(cmd_id)} id=${toHex(id)}`);
    } else {
      action.options = action.options?.filter((o) => o.id !== "busCh") ?? [];
      delete action.busCh;
      const seenBusChValues = busChSeen.get(`${cmd_id}_${id}`);
      if (seenBusChValues && seenBusChValues.size > 0) {
        const maxBusCh = Math.max(...seenBusChValues);
        if (maxBusCh === 0) {
          action.busCh = 0;
        } else {
          const busChChoices = Array.from({ length: maxBusCh + 1 }, (_, i) => ({
            id: i,
            label: `Channel ${i + 1}`
          }));
          action.options.unshift({
            id: "busCh",
            label: "Channel",
            type: "dropdown",
            choices: busChChoices,
            default: 0
          });
        }
      }
      const observedDefault = valueBytesToOption(valueBytes).default;
      const valueOpt = action.options?.find((o) => o.id === "value");
      if (valueOpt) {
        if (valueOpt.choices && Array.isArray(valueOpt.choices)) {
          const inChoices = valueOpt.choices.some((c) => c.id === observedDefault);
          if (!inChoices) {
            logger2.warn(`Inferred choices for cmd_id=${toHex(cmd_id)} id=${toHex(id)} don't contain observed value ${observedDefault} \u2014 discarding inherited choices`);
            valueOpt.type = "number";
            delete valueOpt.choices;
          }
        }
        valueOpt.default = observedDefault;
      }
    }
    out.cmdSchema.push(action);
  }
  for (const { cmd_id, id } of parsed) {
    const alreadyTopLevel = out.cmdSchema.some((a) => a.cmd_id === cmd_id && a.id === id);
    if (alreadyTopLevel)
      continue;
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt2 = a.options?.find((o) => o.id === "idAdd");
      return !!idAddOpt2?.choices && id > a.id;
    });
    if (!idAddBase)
      continue;
    const offset = id - idAddBase.id;
    const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
    if (!idAddOpt?.choices || idAddOpt.choices.some((c) => c.id === offset))
      continue;
    const refHasOffset = candidates.some((c) => {
      const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      return refIdAdd?.choices?.some((ch) => ch.id === offset);
    });
    const existingOffsets = idAddOpt.choices.map((c) => c.id).sort((a, b) => a - b);
    const isSequential = existingOffsets.length > 0 && offset === existingOffsets[existingOffsets.length - 1] + 1;
    if (!refHasOffset && !isSequential)
      continue;
    let label = `Channel ${offset + 1}`;
    for (const c of candidates) {
      const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
      if (refChoice) {
        label = refChoice.label;
        break;
      }
    }
    idAddOpt.choices.push({ id: offset, label });
    logger2.info(`Pass 2: Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
  }
  return out;
}
function saveModelJsonPretty(filePath, jsonObj) {
  try {
    const orderedObj = { model: jsonObj.model };
    if ("useConMon" in jsonObj) {
      orderedObj.useConMon = jsonObj.useConMon;
    }
    if ("cmdSchema" in jsonObj) {
      orderedObj.cmdSchema = jsonObj.cmdSchema.map((entry) => {
        const orderedEntry = {};
        if ("cmd_id" in entry)
          orderedEntry.cmd_id = entry.cmd_id;
        if ("id" in entry)
          orderedEntry.id = entry.id;
        if ("busCh" in entry)
          orderedEntry.busCh = entry.busCh;
        if ("name" in entry)
          orderedEntry.name = entry.name;
        if ("options" in entry)
          orderedEntry.options = entry.options;
        for (const key of Object.keys(entry)) {
          if (!(key in orderedEntry))
            orderedEntry[key] = entry[key];
        }
        return orderedEntry;
      });
    }
    for (const key of Object.keys(jsonObj)) {
      if (!(key in orderedObj)) {
        orderedObj[key] = jsonObj[key];
      }
    }
    let json = JSON.stringify(orderedObj, null, 2);
    json = json.replace(/\{\n\s+"id":\s*(\d+),\n\s+"label":\s*"([^"]*)"\n\s+\}/g, '{ "id": $1, "label": "$2" }');
    fs2.writeFileSync(filePath, json + "\n", "utf8");
  } catch (e) {
    logger2.error(`File Write Error: ${e}`);
  }
}

// dist/actions.js
var logger3 = createModuleLogger("Actions");
function UpdateActions(self) {
  const schemasRaw = getDeviceSchemas();
  const rawActions = buildActions();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredActions = {};
  const activeModel = self.activeModel;
  if (self.config.devMode) {
    wiredActions["global_getAllSettings"] = {
      name: "GLOBAL: Get All Settings",
      description: "Use this to create a schema for a new device",
      options: [],
      callback: async () => {
        const model = activeModel;
        const ip = self.host;
        const buf = await self.stController.requestAllSettings(ip);
        let modelJson = getDeviceSchema(model);
        const { settings: parsed } = parseGetAllSettingsWithDetection(model, buf);
        logger3.debug(`parsed reply: ${JSON.stringify(parsed)}`);
        if (!modelJson) {
          logger3.info(`Model ${model} has no schema \u2014 creating new JSON from settings`);
          modelJson = {
            model,
            cmdSchema: []
          };
        }
        const updated = updateModelJsonFromSettings(modelJson, parsed, schemas);
        logger3.debug(`new Actions json: ${JSON.stringify(updated, null, 2)}`);
        const devicesFolder2 = getDevicesFolder();
        const schemaPath = path2.join(devicesFolder2, `Model${model}.json`);
        saveModelJsonPretty(schemaPath, updated);
        reloadDeviceSchemas();
        logger3.info(`Model ${model} JSON auto-updated from getAllSettings`);
      }
    };
  }
  for (const [actionId, action] of Object.entries(rawActions)) {
    const { model, cmdId, baseId } = parseSettingId(actionId);
    if (model !== activeModel)
      continue;
    const schema = schemas[model];
    const rawAction = schema?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === baseId);
    wiredActions[actionId] = {
      ...action,
      callback: async (event) => {
        const ip = self.host;
        const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
        const value = event.options["value"];
        const idAdd = event.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        await self.stController.sendAwaitAck(cmdId, busCh, settingId, value, ip);
      },
      learn: (event) => {
        const ip = self.host;
        const idAdd = event.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
        const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
        if (current === void 0)
          return void 0;
        return { ...event.options, value: current };
      }
    };
  }
  const activeSchema = schemas[activeModel];
  if (activeSchema) {
    const supportsMicKill = (activeSchema.cmdSchema ?? []).some((a) => a.name.includes("Kill"));
    if (supportsMicKill) {
      const actionId = `${activeModel}_micKill`;
      wiredActions[actionId] = {
        name: `[Model${activeModel}] Mic Kill`,
        options: [],
        callback: async () => {
          const ip = self.host;
          logger3.info(`Mic Kill \u2192 Model ${activeModel} @ ${ip}`);
          await self.stController.globalMicKill(ip);
          await self.stController.requestAllSettings(ip).catch((err) => {
            logger3.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
      };
    }
  }
  self.setActionDefinitions(wiredActions);
}

// dist/feedbacks.js
function getLabelForValue(schemas, model, cmdId, settingId, value) {
  const setting = findActionForSetting(schemas, model, cmdId, settingId);
  if (!setting || !Array.isArray(setting.options))
    return value;
  const valueOption = setting.options.find((opt) => opt.id === "value");
  if (!valueOption || !Array.isArray(valueOption.choices))
    return value;
  const choice = valueOption.choices.find((c) => c.id === value);
  return choice?.label ?? value;
}
function UpdateFeedbacks(self) {
  const schemasRaw = getDeviceSchemas();
  const rawFeedbacks = buildFeedbacks();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredFeedbacks = {};
  const activeModel = self.activeModel;
  for (const [feedbackId, feedback] of Object.entries(rawFeedbacks)) {
    const parseId = feedbackId.endsWith("_bool") ? feedbackId.slice(0, -5) : feedbackId;
    const { model, cmdId, baseId } = parseSettingId(parseId);
    if (model !== activeModel)
      continue;
    wiredFeedbacks[feedbackId] = {
      ...feedback,
      callback: (feedbackEvent) => {
        const ip = self.host;
        const idAdd = feedbackEvent.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        let busCh = feedbackEvent.options["busCh"];
        if (busCh === void 0) {
          const schemaAction = findActionForSetting(schemas, model, cmdId, settingId);
          if (schemaAction?.busCh !== void 0) {
            busCh = schemaAction.busCh;
          }
        }
        if (busCh === void 0) {
          const rawAction = schemasRaw[model]?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === settingId);
          if (rawAction?.busCh !== void 0) {
            busCh = rawAction.busCh;
          }
        }
        const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
        if (feedbackId.endsWith("_bool")) {
          return current !== void 0 && current !== 0;
        }
        const showLabel = feedbackEvent.options["showLabel"] ?? false;
        if (showLabel && current !== void 0) {
          const label = getLabelForValue(schemas, model, cmdId, settingId, current);
          if (typeof label === "number") {
            return label !== 0 ? "true" : "false";
          }
          return label;
        }
        return current ?? 0;
      }
    };
  }
  self.setFeedbackDefinitions(wiredFeedbacks);
}

// dist/stcontroller.js
import dgram3 from "dgram";
import os2 from "os";

// dist/dante.js
import dgram from "dgram";
import os from "os";
var logger4 = createModuleLogger("Dante");
var DANTE_MSG_INFO_REQUEST = 32;
var DANTE_MSG_INFO_RESPONSE = 368;
var DANTE_INFO_MIN_LEN = 204 + 64;
function buildDanteInfoRequest() {
  const buf = Buffer.alloc(32, 0);
  const seq = Math.floor(Math.random() * 65535);
  buf.writeUInt16BE(65535, 0);
  buf.writeUInt16BE(DANTE_MSG_INFO_REQUEST, 2);
  buf.writeUInt16BE(seq, 4);
  const mac = getFirstLocalMac();
  mac.copy(buf, 8);
  Buffer.from("Audinate", "ascii").copy(buf, 16);
  buf.writeUInt16BE(1849, 24);
  buf.writeUInt16BE(193, 26);
  buf.writeUInt32BE(1e6, 28);
  return buf;
}
function getFirstLocalMac() {
  try {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const addr of ifaces[name] ?? []) {
        if (!addr.internal && addr.family === "IPv4" && addr.mac && addr.mac !== "00:00:00:00:00:00") {
          return Buffer.from(addr.mac.split(":").map((h) => parseInt(h, 16)));
        }
      }
    }
  } catch {
  }
  return Buffer.alloc(6, 0);
}
function parseDanteInfoResponse(msg, srcIp) {
  if (msg.length < DANTE_INFO_MIN_LEN)
    return null;
  if (msg.readUInt16BE(0) !== 65535)
    return null;
  if (msg.readUInt16BE(2) !== DANTE_MSG_INFO_RESPONSE)
    return null;
  if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
    return null;
  const readStr = (offset, len) => msg.subarray(offset, offset + len).toString("ascii").split("\0")[0].trim();
  const eui64 = msg.subarray(8, 16);
  const macBytes = [eui64[0], eui64[1], eui64[2], eui64[5], eui64[6], eui64[7]];
  const mac = macBytes.map((b) => b.toString(16).padStart(2, "0")).join(":");
  const name = readStr(32, 31);
  const manufacturer = readStr(76, 64);
  const modelRaw = readStr(204, 64);
  const danteFirmware = `${msg[24]}.${msg[25]}`;
  if (!modelRaw)
    return null;
  const model = modelRaw.replace(/^Model\s+/i, "").trim().split(/\s+/)[0];
  return {
    ip: srcIp,
    name,
    manufacturer,
    model,
    modelName: modelRaw,
    // Full model description
    mac,
    danteFirmware
  };
}
async function getMacForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    tmp.once("error", (err) => {
      tmp.close();
      reject(new Error(err.message ?? String(err)));
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        tmp.close();
        const ifaces = os.networkInterfaces();
        for (const name of Object.keys(ifaces)) {
          for (const iface of ifaces[name] ?? []) {
            if (iface.family === "IPv4" && iface.address === localAddr && iface.mac && iface.mac !== "00:00:00:00:00:00") {
              return resolve(iface.mac.split(":").map((b) => parseInt(b, 16) & 255));
            }
          }
        }
        reject(new Error(`No interface found for local address ${localAddr}`));
      } catch (_e) {
        reject(new Error(String(_e)));
      }
    });
  });
}
async function getLocalAddressForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    let resolved = false;
    tmp.once("error", (err) => {
      if (!resolved) {
        resolved = true;
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      }
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        if (!resolved) {
          resolved = true;
          tmp.close();
          resolve(localAddr);
        }
      } catch (_e) {
        if (!resolved) {
          resolved = true;
          tmp.close();
          reject(new Error(String(_e)));
        }
      }
    });
  });
}
async function discoverDevices(txSocket, ensureMembership, timeoutMs = 5e3) {
  const DANTE_ANNOUNCE_GROUP = "224.0.0.233";
  const DANTE_ANNOUNCE_PORT = 8708;
  const DEFAULT_PORT = 8700;
  const queriedIps = /* @__PURE__ */ new Set();
  return new Promise((resolve) => {
    const announceSocket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const joinedInterfaces = [];
    const cleanup = () => {
      for (const iface of joinedInterfaces) {
        try {
          announceSocket.dropMembership(DANTE_ANNOUNCE_GROUP, iface);
        } catch {
        }
      }
      try {
        announceSocket.close();
      } catch {
      }
      resolve();
    };
    const timer = setTimeout(cleanup, timeoutMs);
    timer.unref?.();
    announceSocket.on("error", (err) => {
      logger4.warn(`Announce socket error: ${err.message}`);
    });
    announceSocket.on("message", (msg, rinfo) => {
      const srcIp = rinfo.address;
      if (msg.length < 24)
        return;
      if (msg.readUInt16BE(0) !== 65534)
        return;
      if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
        return;
      if (queriedIps.has(srcIp))
        return;
      queriedIps.add(srcIp);
      logger4.debug(`Announce from ${srcIp} \u2014 sending unicast query`);
      const sendQuery = async () => {
        await ensureMembership(srcIp);
        const query = buildDanteInfoRequest();
        txSocket.send(query, DEFAULT_PORT, srcIp, (err) => {
          if (err)
            logger4.warn(`Unicast query to ${srcIp} failed: ${err.message}`);
        });
      };
      sendQuery().catch((err) => logger4.warn(`Query setup failed: ${err}`));
    });
    announceSocket.bind(DANTE_ANNOUNCE_PORT, () => {
      const ifaces = os.networkInterfaces();
      for (const addrs of Object.values(ifaces)) {
        for (const addr of addrs ?? []) {
          if (addr.family === "IPv4" && !addr.internal) {
            try {
              announceSocket.addMembership(DANTE_ANNOUNCE_GROUP, addr.address);
              joinedInterfaces.push(addr.address);
            } catch {
            }
          }
        }
      }
      if (joinedInterfaces.length === 0) {
        logger4.warn(`Could not join announce multicast group on any interface`);
      } else {
        logger4.debug(`Listening for Dante announces on ${DANTE_ANNOUNCE_GROUP}:${DANTE_ANNOUNCE_PORT}`);
      }
    });
  });
}
async function probeDevice(txSocket, registerListener, removeListener, ensureMembership, ip, timeoutMs = 3e3) {
  return new Promise((resolve) => {
    const key = `__probe_${ip}__`;
    let resolved = false;
    const finish = (result) => {
      if (resolved)
        return;
      resolved = true;
      removeListener(key);
      resolve(result);
    };
    registerListener(key, (device) => {
      if (device.ip === ip)
        finish(device);
    });
    const timer = setTimeout(() => finish(null), timeoutMs);
    timer.unref?.();
    const run = async () => {
      await ensureMembership(ip);
      const query = buildDanteInfoRequest();
      txSocket.send(query, 8700, ip, (err) => {
        if (err) {
          logger4.warn(`Probe to ${ip} failed: ${err.message}`);
          clearTimeout(timer);
          finish(null);
        }
      });
    };
    run().catch((e) => {
      logger4.warn(`probeDevice setup failed for ${ip}: ${e}`);
      clearTimeout(timer);
      finish(null);
    });
  });
}

// dist/conmon.js
import dgram2 from "dgram";
var logger5 = createModuleLogger("ConMon");
var _conmonPending = /* @__PURE__ */ new Map();
async function openConMonSession(deviceIp, timeoutMs = 3e3) {
  const pending = _conmonPending.get(deviceIp);
  if (pending)
    return pending;
  const promise = _doConMonSession(deviceIp, timeoutMs).finally(() => {
    _conmonPending.delete(deviceIp);
  });
  _conmonPending.set(deviceIp, promise);
  return promise;
}
async function _doConMonSession(deviceIp, timeoutMs) {
  return new Promise((resolve) => {
    let settled = false;
    let keepaliveTimer = null;
    const closeSession = (sock2) => {
      if (keepaliveTimer) {
        clearInterval(keepaliveTimer);
        keepaliveTimer = null;
      }
      try {
        sock2.close();
      } catch {
      }
      logger5.debug(`ConMon session closed for ${deviceIp}`);
    };
    const fail = (sock2) => {
      if (settled)
        return;
      settled = true;
      clearTimeout(timer);
      closeSession(sock2);
      logger5.debug(`ConMon session not established for ${deviceIp}`);
      resolve(null);
    };
    const sock = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    const timer = setTimeout(() => fail(sock), timeoutMs);
    sock.on("error", (err) => {
      logger5.warn(`ConMon socket error for ${deviceIp}: ${err.message}`);
      fail(sock);
    });
    sock.on("message", (msg) => {
      if (!settled && msg.length >= 4 && msg[0] === 18 && msg[3] === 32) {
        settled = true;
        clearTimeout(timer);
        logger5.info(`ConMon session established with ${deviceIp}`);
        let keepaliveSeq = Math.floor(Math.random() * 65534) + 1;
        const sendKeepalive = () => {
          const pkt = Buffer.alloc(20, 0);
          pkt[0] = 18;
          pkt[3] = 78;
          pkt.writeUInt16BE(keepaliveSeq++ & 65535, 4);
          pkt[6] = 48;
          pkt[7] = 16;
          sock.send(pkt, 8800, deviceIp, () => {
          });
        };
        keepaliveTimer = setInterval(sendKeepalive, 1e3);
        resolve(() => closeSession(sock));
      }
    });
    const doInit = async () => {
      let localIp;
      let localMac;
      try {
        localIp = await getLocalAddressForDestination(deviceIp);
        localMac = await getMacForDestination(deviceIp);
      } catch (e) {
        logger5.warn(`ConMon: could not get local network info for ${deviceIp}: ${e}`);
        fail(sock);
        return;
      }
      sock.bind({ port: 8800, address: localIp }, () => {
        const seq = Math.floor(Math.random() * 65534) + 1;
        const pkt = Buffer.alloc(20, 0);
        pkt[0] = 18;
        pkt[3] = 20;
        pkt.writeUInt16BE(seq, 4);
        pkt[6] = 16;
        pkt[7] = 1;
        localMac.forEach((b, i) => {
          pkt[12 + i] = b;
        });
        logger5.debug(`ConMon TX to ${deviceIp}: ${pkt.toString("hex")}`);
        sock.send(pkt, 8800, deviceIp, (err) => {
          if (err) {
            logger5.warn(`ConMon send failed for ${deviceIp}: ${err.message}`);
            fail(sock);
          }
        });
      });
    };
    doInit().catch((e) => {
      logger5.warn(`ConMon init failed for ${deviceIp}: ${e}`);
      fail(sock);
    });
  });
}

// dist/stcontroller.js
var logger6 = createModuleLogger("StController");
var StController = class _StController {
  defaultPort = 8700;
  multicastGroup = "224.0.0.231";
  rxPort = 8702;
  txSocket;
  rxSocket;
  // for receiving responses (8702)
  rxMcastSocket = null;
  // diagnostic: tracks which responses arrive via multicast
  mcastDeliveries = /* @__PURE__ */ new Set();
  // keys seen on multicast socket this cycle
  pendingAcks = /* @__PURE__ */ new Map();
  joinedInterfaces = /* @__PURE__ */ new Set();
  // local IPs we've joined multicast on
  /** Serializes outgoing commands so each waits for ACK before the next is sent */
  sendQueue = Promise.resolve();
  /** Tracks how many commands are queued/in-flight, to defer requestAllSettings */
  pendingCommandCount = 0;
  /** Resolves once txSocket is bound and ready to send */
  txReady;
  /** Active device model and action definitions for settings decoding */
  model = "";
  actions = [];
  /**
   * Known state of every setting per device IP.
   * Keyed by IP → Map of "${cmdId}/${settingId}" → current value byte.
   * Populated on connect via requestAllSettings(), updated on every CMD_SETTINGS_PUSH (0x0b).
   * Used to diff incoming pushes (changed = info, unchanged = debug) and for feedbacks.
   */
  deviceState = /* @__PURE__ */ new Map();
  /**
   * IPs that have been verified against the configured model and are allowed
   * to receive Studio-T commands. Populated by authorizeDevice() after a
   * successful probeDevice() model match, or after multicast discovery.
   * _sendAwaitAck() rejects any destIp not in this set.
   */
  authorizedIps = /* @__PURE__ */ new Set();
  /** Callbacks registered for Dante 0x0170 device info responses — keyed by usage */
  discoveryListeners = /* @__PURE__ */ new Map();
  /** Callback to trigger feedback updates when state changes */
  feedbackCallback;
  /** Cache of local interface MAC bytes per destination IP, to avoid repeated OS lookups */
  macCache = /* @__PURE__ */ new Map();
  /** Tracks session readiness per IP — set for devices that established ConMon, and also
   *  for devices that don't require ConMon (useConMon not set), so the check is only done once. */
  sessionEstablished = /* @__PURE__ */ new Set();
  /** Cleanup functions returned by openConMonSession() — call to stop keepalives and close the socket */
  _conmonCleanups = /* @__PURE__ */ new Map();
  constructor() {
    logger6.info("StController initialized");
    this.txSocket = dgram3.createSocket({ type: "udp4", reuseAddr: true });
    this.txReady = new Promise((resolve) => {
      this.txSocket.bind(0, () => {
        logger6.debug(`TX socket bound to port ${this.txSocket.address().port}`);
        resolve();
      });
    });
    this.txSocket.on("error", (err) => {
      logger6.error(`TX socket error: ${err}`);
    });
    this.rxSocket = dgram3.createSocket({ type: "udp4", reuseAddr: true });
    this.rxSocket.on("listening", () => {
      const addr = this.rxSocket.address();
      logger6.debug(`RX socket listening on ${JSON.stringify(addr)}`);
      try {
        this.rxSocket.setMulticastLoopback(true);
      } catch (_e) {
      }
    });
    this.rxSocket.on("error", (err) => {
      logger6.error(`RX socket error: ${err}`);
    });
    this.rxSocket.on("message", (msg, rinfo) => {
      try {
        this.handleIncoming(msg, rinfo.address);
      } catch (_e) {
        logger6.error(`Error handling incoming message: ${_e}`);
      }
    });
    this.rxSocket.bind({ address: "0.0.0.0", port: this.rxPort }, () => {
      logger6.debug(`RX socket bound to 0.0.0.0:${this.rxPort}`);
      const ifaces = os2.networkInterfaces();
      for (const addrs of Object.values(ifaces)) {
        for (const addr of addrs ?? []) {
          if (addr.family === "IPv4" && !addr.internal && !this.joinedInterfaces.has(addr.address)) {
            try {
              this.rxSocket.addMembership(this.multicastGroup, addr.address);
              this.joinedInterfaces.add(addr.address);
              logger6.debug(`Pre-joined multicast ${this.multicastGroup} on ${addr.address}`);
            } catch (_e) {
              logger6.warn(`Could not pre-join multicast on ${addr.address}: ${String(_e)}`);
            }
          }
        }
      }
    });
    this.rxMcastSocket = dgram3.createSocket({ type: "udp4", reuseAddr: true });
    this.rxMcastSocket.on("error", (err) => {
      logger6.debug(`RX mcast socket error: ${err.message}`);
    });
    this.rxMcastSocket.on("message", (msg, rinfo) => {
      if (msg.length < 25)
        return;
      if (msg[0] !== 255 || msg[1] !== 255)
        return;
      const sig = msg.subarray(16, 24);
      if (sig.toString("ascii") !== "Studio-T")
        return;
      const stPayload = msg.subarray(24);
      if (stPayload.length < 2 || stPayload[0] !== 90)
        return;
      const respCmdId = stPayload[1];
      const isResponse = (respCmdId & 128) !== 0;
      const originalCmdId = respCmdId & 127;
      if (isResponse) {
        const key = `${rinfo.address}:${originalCmdId}`;
        const wasUnicastAlready = !this.mcastDeliveries.has(key);
        this.mcastDeliveries.add(key);
        logger6.debug(`Multicast delivery: ${rinfo.address} cmd:${toHex(originalCmdId)}` + (wasUnicastAlready ? " (unicast also pending)" : " (multicast only so far)"));
        setTimeout(() => this.mcastDeliveries.delete(key), 500);
      }
    });
    this.rxMcastSocket.bind({ address: this.multicastGroup, port: this.rxPort }, () => {
      logger6.debug(`RX mcast socket bound to ${this.multicastGroup}:${this.rxPort}`);
    });
  }
  close() {
    for (const cleanup of this._conmonCleanups.values()) {
      try {
        cleanup();
      } catch {
      }
    }
    this._conmonCleanups.clear();
    try {
      for (const localAddr of Array.from(this.joinedInterfaces)) {
        try {
          this.rxSocket.dropMembership(this.multicastGroup, localAddr);
        } catch {
        }
      }
    } catch {
    }
    try {
      this.rxMcastSocket?.close();
      this.rxMcastSocket = null;
    } catch {
    }
    try {
      this.rxSocket.close();
    } catch {
    }
    try {
      this.txSocket.close();
    } catch {
    }
  }
  /**
   * Provide the active device model and action definitions so incoming messages
   * can be decoded into human-readable names. Call from main.ts after config load.
   */
  setModel(model, actions) {
    this.model = model;
    this.actions = actions;
  }
  /**
   * Set callback to trigger when device state changes (for feedbacks).
   * Call from main.ts to wire up checkFeedbacks.
   */
  setFeedbackCallback(callback) {
    this.feedbackCallback = callback;
  }
  /** Returns true if the device at the given IP has been authorized to receive commands. */
  isDeviceAuthorized(ip) {
    return this.authorizedIps.has(ip);
  }
  /** Mark an IP as verified and allowed to receive Studio-T commands. */
  authorizeDevice(ip) {
    this.authorizedIps.add(ip);
    logger6.debug(`Authorized device at ${ip}`);
  }
  /** Remove authorization for an IP (e.g. on config change or model mismatch). */
  revokeDevice(ip) {
    this.authorizedIps.delete(ip);
    this.deviceState.delete(ip);
    this.macCache.delete(ip);
    this.sessionEstablished.delete(ip);
    this._conmonCleanups.get(ip)?.();
    this._conmonCleanups.delete(ip);
    logger6.debug(`Revoked device at ${ip}`);
  }
  /**
   * Opens a Dante ConMon session for the device if "useConMon": true is set in its
   * device JSON. Caches the result so the handshake only runs once per IP.
   * Delegates to conmon.ts. Devices without useConMon are marked as ready immediately.
   */
  async openSession(deviceIp) {
    if (this.sessionEstablished.has(deviceIp))
      return true;
    const schema = getDeviceSchema(this.model);
    if (!schema?.useConMon) {
      this.sessionEstablished.add(deviceIp);
      return true;
    }
    const cleanup = await openConMonSession(deviceIp);
    const success = cleanup !== null;
    this.sessionEstablished.add(deviceIp);
    if (success) {
      this._conmonCleanups.set(deviceIp, cleanup);
    }
    return success;
  }
  /**
   * Sends a unicast Dante info request to a specific IP and waits for the
   * device info response. Returns the DeviceInfo if the device responds within
   * timeoutMs, or null if no response. Used to verify a manually configured IP.
   * Does NOT require authorization — this is how authorization is established.
   */
  async probeDevice(ip, timeoutMs = 3e3) {
    await this.txReady;
    return probeDevice(this.txSocket, (key, cb) => this.discoveryListeners.set(key, cb), (key) => this.discoveryListeners.delete(key), async (destIp) => this.ensureMembershipFor(destIp), ip, timeoutMs);
  }
  /**
   * Send a CMD_GET_ALL_SETTINGS (0x0a) request to the device and store the response
   * in deviceState. Returns the raw response buffer for parsing.
   */
  async requestAllSettings(deviceIp) {
    logger6.info(`Requesting all settings from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_ALL_SETTINGS, void 0, void 0, void 0, deviceIp, false);
    return response;
  }
  /**
   * Discovers Studio Technologies Dante devices on the local network.
   *
   * Listens for Dante announces on 224.0.0.233:8708, sends unicast info requests
   * to each discovered IP, and collects 0x0170 responses via the rxSocket.
   */
  async discoverDevices(timeoutMs = 5e3) {
    const DISCOVERY_KEY = "__discovery__";
    const foundDevices = [];
    this.discoveryListeners.set(DISCOVERY_KEY, (device) => {
      if (!foundDevices.some((d) => d.ip === device.ip)) {
        foundDevices.push(device);
      }
    });
    try {
      await this.txReady;
      await discoverDevices(this.txSocket, async (destIp) => this.ensureMembershipFor(destIp), timeoutMs);
      return foundDevices;
    } finally {
      this.discoveryListeners.delete(DISCOVERY_KEY);
    }
  }
  /**
   * Requests device firmware version via Studio-T protocol (CMD_GET_FIRMWARE).
   * Returns the firmware version string (e.g., "3.01", "2.2", "1.05").
   */
  async requestFirmwareVersion(deviceIp) {
    logger6.info(`Requesting firmware version from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_FIRMWARE, void 0, void 0, void 0, deviceIp, false);
    const dataStart = 26;
    if (response.length < dataStart + 3) {
      logger6.warn(`Firmware response too short: ${response.length} bytes`);
      return "Unknown";
    }
    const major = response[dataStart + 1];
    const minor = response[dataStart + 2];
    const minorStr = minor < 10 ? minor.toString().padStart(2, "0") : minor.toString();
    const firmware = `${major}.${minorStr}`;
    logger6.debug(`Firmware version: ${firmware}`);
    return firmware;
  }
  /**
   * Joins the multicast response group on the interface that routes to destIp.
   * Only joins the specific interface used to reach the device, and only once per interface.
   */
  async ensureMembershipFor(destIp) {
    try {
      const localAddr = await getLocalAddressForDestination(destIp);
      if (!localAddr) {
        logger6.warn(`Could not determine local address for destination ${destIp}`);
        return;
      }
      if (this.joinedInterfaces.has(localAddr)) {
        return;
      }
      try {
        this.rxSocket.addMembership(this.multicastGroup, localAddr);
        this.joinedInterfaces.add(localAddr);
        logger6.info(`Joined multicast ${this.multicastGroup} on ${localAddr}`);
      } catch (_e) {
        logger6.warn(`Failed to join multicast on ${localAddr}: ${String(_e)}`);
      }
    } catch (_e) {
      logger6.warn(`ensureMembershipFor failed: ${_e}`);
    }
  }
  async sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    this.pendingCommandCount++;
    return new Promise((resolve, reject) => {
      this.sendQueue = this.sendQueue.then(async () => this._sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen).then((buf) => {
        this.pendingCommandCount--;
        if (this.pendingCommandCount === 0 && value !== void 0) {
          this.requestAllSettings(destIp).catch((err) => {
            logger6.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
        resolve(buf);
      }).catch((err) => {
        this.pendingCommandCount--;
        reject(err instanceof Error ? err : new Error(String(err)));
      }));
    });
  }
  async _sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    const timeoutMs = 2e3;
    const dataBlock = [];
    if (settingId !== void 0)
      dataBlock.push(settingId & 255);
    if (value !== void 0)
      dataBlock.push(..._StController.buildValueBytes(value));
    const payloadBody = [90, cmdId & 255];
    if (cmdId === CMD_MIC_PRE && busCh !== void 0 && settingId !== void 0 && value !== void 0) {
      if (!this.deviceState.has(destIp))
        this.deviceState.set(destIp, /* @__PURE__ */ new Map());
      const ipState = this.deviceState.get(destIp);
      const numPositions = 3;
      const positions = [];
      for (let i = 0; i < numPositions; i++) {
        const stateKey = makeSettingId(this.model, CMD_MIC_PRE, i, busCh);
        const val = i === settingId ? Number(value) : ipState.get(stateKey) ?? 0;
        positions.push(val);
        ipState.set(stateKey, val);
      }
      payloadBody.push(busCh & 255, ...positions);
    } else {
      if (busCh !== void 0)
        payloadBody.push(busCh & 255);
      if (addLen)
        payloadBody.push(dataBlock.length);
      if (dataBlock.length > 0)
        payloadBody.push(...dataBlock);
    }
    const crc = _StController.crc8DvbS2(payloadBody);
    const payloadWithCrc = Buffer.from([...payloadBody, crc]);
    if (settingId !== void 0 && value !== void 0) {
      const valueBytes = _StController.buildValueBytes(value);
      const setting = {
        cmd_id: cmdId,
        id: settingId,
        busCh,
        valueBytes
      };
      logger6.info(`TX ${destIp} | ${formatParsedSetting(setting, this.actions)}`);
    } else {
      logger6.info(`TX ${destIp} | ${getCommandName(cmdId)}`);
    }
    if (!this.authorizedIps.has(destIp)) {
      logger6.debug(`Packet (not sent \u2014 device not authorized) to ${destIp}: ${payloadWithCrc.toString("hex")}`);
      throw new Error(`Device at ${destIp} is not authorized \u2014 verify the IP and model match before sending commands`);
    }
    if (!this.sessionEstablished.has(destIp)) {
      await this.openSession(destIp);
    }
    await this.ensureMembershipFor(destIp);
    const totalLen = 24 + payloadWithCrc.length;
    const header = await this.buildHeader(totalLen, destIp);
    const packet = Buffer.concat([header, payloadWithCrc]);
    logger6.debug(`Sending packet to ${destIp}: ${packet.toString("hex")}`);
    const key = `${destIp}:${cmdId}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingAcks.delete(key);
        reject(new Error(`Timeout waiting for ACK from Model ${this.model} at ${destIp}:8700`));
      }, timeoutMs);
      this.pendingAcks.set(key, {
        resolve: (buf) => {
          clearTimeout(timer);
          resolve(buf);
        },
        reject: (err) => {
          clearTimeout(timer);
          reject(err);
        },
        timer
      });
      this.txSocket.send(packet, this.defaultPort, destIp, (err) => {
        if (err) {
          this.pendingAcks.delete(key);
          clearTimeout(timer);
          reject(new Error(err.message ?? String(err)));
        }
      });
    });
  }
  handleIncoming(msg, srcIp) {
    if (msg.length < 4)
      return;
    if (msg[0] !== 255 || msg[1] !== 255)
      return;
    const msgType = msg.readUInt16BE(2);
    if (msgType === DANTE_MSG_INFO_RESPONSE && this.discoveryListeners.size > 0) {
      const device = parseDanteInfoResponse(msg, srcIp);
      if (device) {
        logger6.debug(`Dante info response from ${srcIp}: DeviceID="${device.name}", Model="${device.model}", ModelName="${device.modelName}", Manufacturer="${device.manufacturer}"`);
        if (device.name === "Studio-T") {
          for (const cb of this.discoveryListeners.values()) {
            try {
              cb(device);
            } catch {
            }
          }
        } else {
          logger6.debug(`Ignoring non-Studio Technologies device: DeviceID="${device.name}" @ ${srcIp}`);
        }
      }
      return;
    }
    if (msg.length < 25)
      return;
    const sig = msg.subarray(16, 24);
    if (sig.toString("ascii") !== "Studio-T")
      return;
    if (!this.authorizedIps.has(srcIp)) {
      logger6.debug(`Ignoring Studio-T packet from unauthorized device ${srcIp}`);
      return;
    }
    const stPayload = msg.subarray(24);
    if (stPayload.length < 2)
      return;
    if (stPayload[0] !== 90)
      return;
    const respCmdId = stPayload[1];
    const isResponse = (respCmdId & 128) !== 0;
    const originalCmdId = respCmdId & 127;
    if (isResponse) {
      const key = `${srcIp}:${originalCmdId}`;
      const pending = this.pendingAcks.get(key);
      if (pending) {
        this.pendingAcks.delete(key);
        const viaMulticast = this.mcastDeliveries.has(key);
        logger6.debug(`RX delivery method: ${srcIp} cmd:${toHex(originalCmdId)} via ${viaMulticast ? "multicast" : "unicast"}`);
        if (originalCmdId === CMD_GET_ALL_SETTINGS) {
          logger6.debug(`Received packet from ${srcIp}: ${msg.toString("hex")}`);
        }
        this.logStPayload(srcIp, originalCmdId, msg, stPayload);
        pending.resolve(msg);
      } else if (originalCmdId === CMD_SETTINGS_PUSH) {
        this.logStPayload(srcIp, originalCmdId, msg, stPayload);
      }
    } else {
      this.logStPayload(srcIp, originalCmdId, msg, stPayload);
    }
  }
  /**
   * Decodes and logs a Studio-T response payload.
   * Receives both the full msg (for parsers that need the Studio-T header)
   * and stPayload (msg.subarray(24), for direct byte access).
   *
   * stPayload layout:
   *   [0]      0x5a  magic
   *   [1]      cmdId | 0x80
   *   [2..-2]  data bytes
   *   [-1]     CRC-8/DVB-S2
   */
  logStPayload(srcIp, cmdId, msg, stPayload) {
    const cmdName = getCommandName(cmdId);
    const data = stPayload.subarray(2, stPayload.length - 1);
    const respCmdId = stPayload[1];
    const crc = stPayload[stPayload.length - 1];
    const fullStructure = `[cmd:${toHex(respCmdId)} data:${data.toString("hex")} crc:${toHex(crc)}]`;
    if (cmdId === CMD_GET_ALL_SETTINGS || cmdId === CMD_SETTINGS_PUSH) {
      if (!this.model) {
        logger6.info(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
        return;
      }
      try {
        const settings = cmdId === CMD_SETTINGS_PUSH ? parseSettingsResponse(this.model, msg) : parseGetAllSettingsForModel(this.model, msg);
        const prevState = this.deviceState.get(srcIp) ?? /* @__PURE__ */ new Map();
        const newState = new Map(prevState);
        for (const s of settings) {
          const stateKey = makeSettingId(this.model, s.cmd_id, s.id, s.busCh);
          const newValue = s.valueBytes.length === 3 ? s.valueBytes[0] << 16 | s.valueBytes[1] << 8 | s.valueBytes[2] : s.valueBytes[0] ?? 0;
          const prevValue = prevState.get(stateKey);
          const changed = prevValue === void 0 || prevValue !== newValue;
          newState.set(stateKey, newValue);
          const formatted = formatParsedSetting(s, this.actions);
          if (changed) {
            logger6.info(`RX ${srcIp} | ${formatted}`);
            if (this.feedbackCallback) {
              let baseId = s.id;
              const baseAction = this.actions.find((a) => {
                if (a.cmd_id !== s.cmd_id)
                  return false;
                if (a.id === s.id)
                  return true;
                const idAddOption = a.options?.find((o) => o.id === "idAdd");
                if (!idAddOption?.choices)
                  return false;
                const offset = s.id - a.id;
                return offset > 0 && idAddOption.choices.some((c) => c.id === offset);
              });
              if (baseAction)
                baseId = baseAction.id;
              const baseFeedbackKey = makeSettingId(this.model, s.cmd_id, baseId);
              this.feedbackCallback(baseFeedbackKey);
              this.feedbackCallback(baseFeedbackKey + "_bool");
            } else {
              logger6.warn(`feedbackCallback not set \u2014 skipping feedback update for ${stateKey}`);
            }
          } else {
            logger6.debug(`RX ${srcIp} | ${formatted}`);
          }
        }
        this.deviceState.set(srcIp, newState);
      } catch (e) {
        logger6.warn(`RX ${srcIp} | ${cmdName} | parse failed: ${e} | ${fullStructure}`);
      }
      return;
    }
    const decoded = this.decodeStData(cmdId, data);
    const logFn = cmdId === CMD_BUS_GET ? logger6.debug.bind(logger6) : logger6.info.bind(logger6);
    if (decoded) {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure} | ${decoded}`);
    } else {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
    }
  }
  /**
   * Attempts to decode the data bytes of a Studio-T response into a
   * human-readable string. Returns null to fall back to raw hex.
   */
  decodeStData(cmdId, data) {
    if (data.length === 0)
      return "ACK";
    if (data.length === 1) {
      if (data[0] === 0) {
        return "ACK ok";
      } else {
        return `ERROR ${toHex(data[0])}`;
      }
    }
    switch (cmdId) {
      // ── CMD_MIC_PRE (0x02): raw preamp echo — positional bytes, no setting IDs ──
      // Device echoes [busCh][val0][val1]... confirming the applied values.
      case CMD_MIC_PRE: {
        const busCh = data[0];
        const vals = Array.from(data.subarray(1)).map((b, i) => `[${i}]=0x${b.toString(16).padStart(2, "0")}(${b})`).join(" ");
        return `ch=${busCh} ${vals}`;
      }
      // ── CMD_DEV_SPEC (0x0d): single-byte ACK or echo of applied setting ──
      // Device sends two CMD_DEV_SPEC packets in response to a set:
      //   1. ACK:  [status]               (1 byte, 0x00 = ok)
      //   2. Echo: [busCh] [settingId] [value...]  (confirming what was applied)
      case CMD_DEV_SPEC: {
        if (data.length === 1) {
          return data[0] === 0 ? "ACK ok" : `ACK err=${toHex(data[0])}`;
        }
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const choices = action?.options?.[0]?.choices;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ? `${choiceLabel} (${toHex(valueNum)})` : bytesToHex(Array.from(valueBytes));
          const rawTag = `[${toHex(cmdId)}/${toHex(settingId)}]=${bytesToHex(Array.from(valueBytes))}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr} ${rawTag}`;
        }
        return `raw: ${data.toString("hex")}`;
      }
      // ── CMD_MIC_PRE_BUS (0x12): Multi-byte echo responses ─────────────
      case CMD_MIC_PRE_BUS: {
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choices = action?.options?.find((o) => o.id === "value")?.choices;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ?? `0x${valueBytes.toString("hex")}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr}`;
        }
        return null;
      }
      // ── Bus-scoped get/set ────────────────────────────────────────────
      case CMD_BUS_GET:
      case CMD_BUS_SET: {
        if (data.length < 2)
          return null;
        const busCh = data[0];
        const settingId = data[1];
        const value = data.subarray(2);
        return `ch=${busCh} setting=${toHex(settingId)} value=${value.toString("hex")}`;
      }
      default:
        return null;
    }
  }
  static buildValueBytes(value) {
    if (typeof value === "boolean")
      return [value ? 1 : 0];
    if (Array.isArray(value))
      return value.map((v) => Number(v) & 255);
    if (typeof value === "number") {
      if (value > 255)
        return [value >> 16 & 255, value >> 8 & 255, value & 255];
      return [value & 255];
    }
    throw new Error(`Unsupported value type for STcontroller: ${value}`);
  }
  async buildHeader(totalLen, destIp) {
    let mac = this.macCache.get(destIp);
    if (!mac) {
      mac = await getMacForDestination(destIp);
      this.macCache.set(destIp, mac);
    }
    return Buffer.concat([
      Buffer.from([255, 255, 0, totalLen & 255, 7, 225, 0, 0, ...mac, 0, 0]),
      Buffer.from("Studio-T", "utf8")
    ]);
  }
  static crc8DvbS2(data) {
    let crc = 0;
    for (const b of data) {
      crc ^= b;
      for (let i = 0; i < 8; i++) {
        crc = (crc & 128) !== 0 ? (crc << 1 ^ 213) & 255 : crc << 1 & 255;
      }
    }
    return crc;
  }
  /**
   * Returns the current known value for a setting on a device, or undefined if unknown.
   * Use for feedbacks — value is updated on every CMD_SETTINGS_PUSH (0x0b) from the device.
   *
   * @param ip        Device IP address
   * @param cmdId     Command ID (e.g. CMD_DEV_SPEC)
   * @param settingId Setting ID (e.g. 0x02 for Control Source)
   * @param busCh     Optional bus/channel ID for multi-channel commands
   */
  getSettingValue(ip, cmdId, settingId, busCh) {
    const key = makeSettingId(this.model, cmdId, settingId, busCh);
    return this.deviceState.get(ip)?.get(key);
  }
  async resetDevice(destIp) {
    return this.sendAwaitAck(CMD_RESET_DEVICE, void 0, 0, void 0, destIp, false);
  }
  async globalMicKill(destIp) {
    return this.sendAwaitAck(CMD_GLOBAL_MIC_KILL, void 0, void 0, void 0, destIp, false);
  }
};

// dist/main.js
var logger7 = createModuleLogger("ModuleInstance");
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  stController;
  /** Cached discovery results — passed into getConfigFields() so the UI
   *  can show the discovered device dropdown on subsequent config opens. */
  discoveredDevices = [];
  /** Currently active model — resolved once in syncModel() and cached here
   *  so UpdateActions, UpdateFeedbacks etc. don't each call resolveModel independently. */
  activeModel = "";
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    if (!this.stController) {
      this.stController = new StController();
    }
    this.updateStatus(InstanceStatus.Connecting, "Discovering devices...");
    this.stController.setFeedbackCallback((feedbackId) => {
      this.checkFeedbacks(feedbackId);
    });
    this.runDiscovery().catch((e) => {
      logger7.error(`Discovery failed: ${e}`);
    });
  }
  /**
   * Run device discovery, then resolve the model and update all UI.
   * - If discovery finds devices, resolveModel picks from those.
   * - Only if the list is empty do we fall back to the manual config selection.
   * All actions/feedbacks/variables are built after the model is known.
   */
  async runDiscovery() {
    logger7.info("Starting device discovery...");
    this.discoveredDevices = await this.stController.discoverDevices();
    let effectiveModel;
    if (this.discoveredDevices.length === 0) {
      if (this.config.deviceMac) {
        logger7.warn(`Saved device MAC "${this.config.deviceMac}" not found during discovery \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `[${this.config.deviceMac}] not found`);
        return;
      }
      const manualModel = this.config.activeModel;
      if (!this.config.host || !manualModel) {
        logger7.warn("No devices discovered and no manual IP/model configured");
        return;
      }
      logger7.info("No devices discovered \u2014 will probe manual IP during authorization");
      effectiveModel = manualModel;
    } else {
      logger7.info(`Discovered ${this.discoveredDevices.length} device(s):`);
      for (const d of this.discoveredDevices) {
        logger7.info(`  - Model ${d.model} ${d.manufacturer ?? ""} @ ${d.ip}`);
      }
      for (const device of this.discoveredDevices) {
        this.stController.authorizeDevice(device.ip);
      }
      for (const device of this.discoveredDevices) {
        try {
          const firmware = await this.stController.requestFirmwareVersion(device.ip);
          device.firmwareMain = firmware;
          logger7.info(`  - ${device.ip}: Firmware ${firmware}, Dante ${device.danteFirmware}`);
        } catch (e) {
          logger7.warn(`  - ${device.ip}: Failed to get firmware: ${e}`);
          device.firmwareMain = "Unknown";
        }
      }
      effectiveModel = resolveModel(this.config, this.discoveredDevices);
      if (!effectiveModel && this.config.deviceMac) {
        logger7.warn(`Saved device MAC "${this.config.deviceMac}" not found among discovered devices \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `[${this.config.deviceMac}] not found`);
        return;
      }
    }
    this.syncModel(effectiveModel);
    const targetHost = this.host;
    await this.verifyAuthorization("", targetHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
    logger7.info("Device discovery complete");
  }
  // When module gets deleted
  async destroy() {
    this.stController?.close();
    logger7.debug("destroy");
  }
  async configUpdated(config) {
    const previousHost = this.host;
    this.config = config;
    const effectiveModel = resolveModel(config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.updateVariableValues();
    const newHost = this.host;
    await this.verifyAuthorization(previousHost, newHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
  }
  /**
   * Re-evaluates whether the current config is authorized to send commands.
   *
   * Auto mode (deviceMac set):
   *   - Find the discovered device with matching MAC → get its current IP
   *   - Revoke the previous IP, authorize the new IP
   *   - If MAC not found in discovery, revoke and block
   *
   * Manual mode (deviceMac empty):
   *   - Check discovered list by IP+model match, or probe directly
   */
  async verifyAuthorization(previousHost, newHost) {
    if (!newHost) {
      if (previousHost)
        this.stController.revokeDevice(previousHost);
      return;
    }
    if (this.config.deviceMac) {
      const device = this.discoveredDevices.find((d) => d.mac === this.config.deviceMac);
      if (!device) {
        logger7.warn(`Device MAC "${this.config.deviceMac}" not found in current discovery \u2014 not authorizing`);
        if (previousHost)
          this.stController.revokeDevice(previousHost);
        return;
      }
      if (previousHost && previousHost !== newHost) {
        this.stController.revokeDevice(previousHost);
      }
      const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
      if (!wasAuthorized) {
        this.stController.authorizeDevice(newHost);
      }
      if (newHost !== previousHost || !wasAuthorized) {
        await this.fetchSettingsAndEnsureSchema(device.model, newHost);
      }
      this.updateStatus(InstanceStatus.Ok, `Model ${device.model} @ ${newHost}`);
      return;
    }
    const manualModel = String(this.config.activeModel ?? "");
    const discoveredAtIp = this.discoveredDevices.find((d) => d.ip === newHost);
    if (discoveredAtIp) {
      if (discoveredAtIp.model === manualModel) {
        if (previousHost && previousHost !== newHost)
          this.stController.revokeDevice(previousHost);
        const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
        if (!wasAuthorized) {
          this.stController.authorizeDevice(newHost);
        }
        if (newHost !== previousHost || !wasAuthorized) {
          await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
        }
        this.updateStatus(InstanceStatus.Ok, `Model ${manualModel} @ ${newHost}`);
      } else {
        logger7.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${discoveredAtIp.model}) at ${newHost} \u2014 commands blocked`);
        this.stController.revokeDevice(newHost);
        this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${discoveredAtIp.model}`);
      }
      return;
    }
    logger7.info(`${newHost} not in discovered list \u2014 probing`);
    if (previousHost && previousHost !== newHost)
      this.stController.revokeDevice(previousHost);
    this.stController.revokeDevice(newHost);
    const probed = await this.stController.probeDevice(newHost);
    if (!probed) {
      logger7.error(`No device responded at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.UnknownWarning, `Device offline: ${newHost}`);
    } else if (probed.model !== manualModel) {
      logger7.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${probed.model}) at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${probed.model}`);
    } else {
      logger7.info(`Verified Model ${probed.model} at ${newHost}`);
      this.stController.authorizeDevice(newHost);
      await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
      this.updateStatus(InstanceStatus.Ok, `Model ${probed.model} @ ${newHost}`);
    }
  }
  /**
   * Fetches all settings from the device. If no schema exists for the model,
   * creates one from the response and reloads the schema cache.
   */
  async fetchSettingsAndEnsureSchema(model, ip) {
    try {
      await this.stController.requestAllSettings(ip);
      if (!getDeviceSchema(model)) {
        logger7.warn(`No schema found for Model ${model} \u2014 run "GLOBAL: Get All Settings" to create one`);
        return;
      }
    } catch (e) {
      logger7.warn(`Failed to fetch settings from ${ip}: ${e}`);
    }
  }
  /** Loads the device JSON for the given model, caches it as activeModel, and pushes it to the controller. */
  syncModel(model) {
    this.activeModel = model;
    const schema = getDeviceSchema(model);
    if (!schema) {
      logger7.warn(`Model "${model}" not found in device schemas`);
      this.stController.setModel(model, []);
      return;
    }
    const actions = Array.isArray(schema.cmdSchema) ? schema.cmdSchema : [];
    this.stController.setModel(model, actions);
    if (actions.length === 0) {
      logger7.warn(`No actions found for model "${model}" \u2014 settings decoding will use raw IDs`);
    } else {
      logger7.debug(`Loaded ${actions.length} actions for model "${model}", sectioned=${schema.sectioned}`);
    }
  }
  getConfigFields() {
    return GetConfigFields(this.discoveredDevices);
  }
  /** Returns the effective host IP, resolved from MAC→IP via discoveredDevices (auto) or config.host (manual). */
  get host() {
    return resolveHost(this.config, this.discoveredDevices);
  }
  /** Returns discovered devices for use in actions/config */
  get devices() {
    return this.discoveredDevices;
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  updateVariableValues() {
    UpdateVariableValues(this);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2xvZ2dpbmcudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL3V0aWwudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvc2hhcmVkLXVkcC1zb2NrZXQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2hvc3QtYXBpL2NvbnRleHQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvYmFzZS50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9lbnVtcy50cyIsICIuLi8uLi9zcmMvY29uZmlnLnRzIiwgIi4uLy4uL3NyYy92YXJpYWJsZXMudHMiLCAiLi4vLi4vc3JjL3VwZ3JhZGVzLnRzIiwgIi4uLy4uL3NyYy90eXBlcy50cyIsICIuLi8uLi9zcmMvYnVpbGQtY29tbWFuZHMudHMiLCAiLi4vLi4vc3JjL2FjdGlvbnMudHMiLCAiLi4vLi4vc3JjL3NldHRpbmdzUGFyc2VyLnRzIiwgIi4uLy4uL3NyYy9mZWVkYmFja3MudHMiLCAiLi4vLi4vc3JjL3N0Y29udHJvbGxlci50cyIsICIuLi8uLi9zcmMvZGFudGUudHMiLCAiLi4vLi4vc3JjL2Nvbm1vbi50cyIsICIuLi8uLi9zcmMvbWFpbi50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFtudWxsLCBudWxsLCBudWxsLCBudWxsLCBudWxsLCBudWxsLCAiaW1wb3J0IGZzIGZyb20gJ2ZzJ1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCdcbmltcG9ydCB7IFJlZ2V4LCB0eXBlIFNvbWVDb21wYW5pb25Db25maWdGaWVsZCwgdHlwZSBKc29uT2JqZWN0LCBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHR5cGUgeyBEZXZpY2VJbmZvIH0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdDb25maWcnKVxuXG5leHBvcnQgdHlwZSBNb2R1bGVDb25maWcgPSBKc29uT2JqZWN0ICYge1xuXHQvKiogTUFDIG9mIHRoZSBzZWxlY3RlZCBkaXNjb3ZlcmVkIGRldmljZSAoZS5nLiBcIjAwOjFkOmMxOjliOmE2OmNkXCIpLCBvciAnJyBmb3IgbWFudWFsIG1vZGUgKi9cblx0ZGV2aWNlTWFjOiBzdHJpbmdcblx0LyoqIE1hbnVhbCBJUCBhZGRyZXNzIFx1MjAxNCBvbmx5IHVzZWQgd2hlbiBkZXZpY2VNYWMgaXMgJycgKi9cblx0aG9zdDogc3RyaW5nXG5cdC8qKiBNYW51YWwgbW9kZWwgc2VsZWN0aW9uIFx1MjAxNCBvbmx5IHVzZWQgd2hlbiBkZXZpY2VNYWMgaXMgJycgKi9cblx0YWN0aXZlTW9kZWw6IHN0cmluZ1xuXHQvKiogRW5hYmxlIHBhcnNpbmcgb2YgdW5zdXBwb3J0ZWQgU1QgZGV2aWNlcyAqL1xuXHRkZXZNb2RlOiBib29sZWFuXG59XG5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbi8vIENFTlRSQUxJWkVEIERFVklDRSBTQ0hFTUEgQ0FDSEVcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbi8vIEFsbCBkZXZpY2UgSlNPTiBmaWxlcyBhcmUgbG9hZGVkIG9uY2UgaW50byBtZW1vcnkgaGVyZS4gT3RoZXIgbW9kdWxlcyBzaG91bGRcbi8vIHVzZSBnZXREZXZpY2VzRm9sZGVyKCksIGdldERldmljZVNjaGVtYXMoKSwgYW5kIGdldERldmljZVNjaGVtYSgpIGluc3RlYWQgb2Zcbi8vIHJlYWRpbmcgZmlsZXMgZGlyZWN0bHkuIENhbGwgcmVsb2FkRGV2aWNlU2NoZW1hcygpIGFmdGVyIHdyaXRpbmcgdG8gYSBmaWxlLlxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuXG4vKipcbiAqIERldGVybWluZXMgdGhlIGNvcnJlY3QgZGV2aWNlcyBmb2xkZXIgcGF0aCB3aXRoIGZhbGxiYWNrIHN1cHBvcnQuXG4gKiBDaGVja3MgcHJpbWFyeSBwYXRoIGZpcnN0LCB0aGVuIGZhbGxiYWNrLCB0aGVuIHRocm93cyBlcnJvciBpZiBuZWl0aGVyIGV4aXN0cy5cbiAqL1xuZnVuY3Rpb24gcmVzb2x2ZURldmljZXNGb2xkZXIoKTogc3RyaW5nIHtcblx0Y29uc3QgcHJpbWFyeVBhdGggPSBwYXRoLmpvaW4oaW1wb3J0Lm1ldGEuZGlybmFtZSwgJy4uL2RldmljZXMnKVxuXHRjb25zdCBmYWxsYmFja1BhdGggPSBwYXRoLmpvaW4oaW1wb3J0Lm1ldGEuZGlybmFtZSwgJy4vZGV2aWNlcycpXG5cblx0Ly8gQ2hlY2sgcHJpbWFyeSBwYXRoXG5cdGlmIChmcy5leGlzdHNTeW5jKHByaW1hcnlQYXRoKSkge1xuXHRcdGxvZ2dlci5kZWJ1ZyhgVXNpbmcgZGV2aWNlcyBmb2xkZXI6ICR7cHJpbWFyeVBhdGh9YClcblx0XHRyZXR1cm4gcHJpbWFyeVBhdGhcblx0fVxuXG5cdC8vIENoZWNrIGZhbGxiYWNrIHBhdGhcblx0aWYgKGZzLmV4aXN0c1N5bmMoZmFsbGJhY2tQYXRoKSkge1xuXHRcdGxvZ2dlci53YXJuKGBQcmltYXJ5IGRldmljZXMgZm9sZGVyIG5vdCBmb3VuZCwgdXNpbmcgZmFsbGJhY2s6ICR7ZmFsbGJhY2tQYXRofWApXG5cdFx0cmV0dXJuIGZhbGxiYWNrUGF0aFxuXHR9XG5cblx0Ly8gTmVpdGhlciBwYXRoIGV4aXN0cyAtIGZhdGFsIGVycm9yXG5cdGNvbnN0IGVycm9yTXNnID0gYERldmljZXMgZm9sZGVyIG5vdCBmb3VuZCFcXG5UcmllZDpcXG4gIC0gJHtwcmltYXJ5UGF0aH1cXG4gIC0gJHtmYWxsYmFja1BhdGh9XFxuTW9kdWxlIGNhbm5vdCBjb250aW51ZSB3aXRob3V0IGRldmljZSBzY2hlbWFzLmBcblx0bG9nZ2VyLmVycm9yKGVycm9yTXNnKVxuXHR0aHJvdyBuZXcgRXJyb3IoZXJyb3JNc2cpXG59XG5cbi8vIFJlc29sdmUgdGhlIGRldmljZXMgZm9sZGVyIHBhdGggKHdpdGggZXhpc3RlbmNlIGNoZWNrIGFuZCBmYWxsYmFjaylcbmNvbnN0IGRldmljZXNGb2xkZXIgPSByZXNvbHZlRGV2aWNlc0ZvbGRlcigpXG5cbi8vIEluLW1lbW9yeSBjYWNoZSBvZiBhbGwgZGV2aWNlIHNjaGVtYXMsIGtleWVkIGJ5IG1vZGVsIG51bWJlclxubGV0IGRldmljZVNjaGVtYXNDYWNoZTogUmVjb3JkPHN0cmluZywgYW55PiB8IG51bGwgPSBudWxsXG5cbi8qKlxuICogUmV0dXJucyB0aGUgYWJzb2x1dGUgcGF0aCB0byB0aGUgZGV2aWNlcyBmb2xkZXIuXG4gKiBVc2UgdGhpcyBpbnN0ZWFkIG9mIHJlZGVmaW5pbmcgdGhlIHBhdGggaW4gZXZlcnkgZmlsZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldERldmljZXNGb2xkZXIoKTogc3RyaW5nIHtcblx0cmV0dXJuIGRldmljZXNGb2xkZXJcbn1cblxuLyoqXG4gKiBMb2FkcyBhbGwgZGV2aWNlIEpTT04gZmlsZXMgZnJvbSB0aGUgZGV2aWNlcyBmb2xkZXIgaW50byBtZW1vcnkuXG4gKiBUaGlzIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBvbmNlIGF0IGluaXRpYWxpemF0aW9uLCBvciBhZnRlciBhIGZpbGUgaXMgd3JpdHRlbi5cbiAqL1xuZnVuY3Rpb24gbG9hZERldmljZVNjaGVtYXMoKTogUmVjb3JkPHN0cmluZywgYW55PiB7XG5cdGNvbnN0IHNjaGVtYXM6IFJlY29yZDxzdHJpbmcsIGFueT4gPSB7fVxuXHR0cnkge1xuXHRcdGNvbnN0IGZpbGVzID0gZnMucmVhZGRpclN5bmMoZGV2aWNlc0ZvbGRlcikuZmlsdGVyKChmKSA9PiBmLmVuZHNXaXRoKCcuanNvbicpKVxuXG5cdFx0Zm9yIChjb25zdCBmIG9mIGZpbGVzKSB7XG5cdFx0XHRjb25zdCBmdWxsUGF0aCA9IHBhdGguam9pbihkZXZpY2VzRm9sZGVyLCBmKVxuXHRcdFx0Y29uc3QganNvbiA9IEpTT04ucGFyc2UoZnMucmVhZEZpbGVTeW5jKGZ1bGxQYXRoLCAndXRmOCcpKVxuXHRcdFx0aWYgKGpzb24/Lm1vZGVsKSB7XG5cdFx0XHRcdHNjaGVtYXNbU3RyaW5nKGpzb24ubW9kZWwpXSA9IGpzb25cblx0XHRcdH1cblx0XHR9XG5cblx0XHRsb2dnZXIuZGVidWcoYExvYWRlZCAke09iamVjdC5rZXlzKHNjaGVtYXMpLmxlbmd0aH0gZGV2aWNlIHNjaGVtYXMgaW50byBjYWNoZWApXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRsb2dnZXIuZXJyb3IoYEZhaWxlZCB0byBsb2FkIGRldmljZSBzY2hlbWFzOiAke2V9YClcblx0fVxuXHRyZXR1cm4gc2NoZW1hc1xufVxuXG4vKipcbiAqIFJldHVybnMgYWxsIGRldmljZSBzY2hlbWFzIGZyb20gdGhlIGNhY2hlLlxuICogSW5pdGlhbGl6ZXMgdGhlIGNhY2hlIG9uIGZpcnN0IGNhbGwuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREZXZpY2VTY2hlbWFzKCk6IFJlY29yZDxzdHJpbmcsIGFueT4ge1xuXHRpZiAoIWRldmljZVNjaGVtYXNDYWNoZSkge1xuXHRcdGRldmljZVNjaGVtYXNDYWNoZSA9IGxvYWREZXZpY2VTY2hlbWFzKClcblx0fVxuXHRyZXR1cm4gZGV2aWNlU2NoZW1hc0NhY2hlXG59XG5cbi8qKlxuICogUmV0dXJucyBhIHNwZWNpZmljIGRldmljZSBzY2hlbWEgYnkgbW9kZWwgbnVtYmVyLlxuICogUmV0dXJucyB1bmRlZmluZWQgaWYgdGhlIG1vZGVsIGRvZXNuJ3QgZXhpc3QuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREZXZpY2VTY2hlbWEobW9kZWw6IHN0cmluZyk6IGFueSB7XG5cdGNvbnN0IHNjaGVtYXMgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0cmV0dXJuIHNjaGVtYXNbbW9kZWxdXG59XG5cbi8qKlxuICogUmVsb2FkcyBhbGwgZGV2aWNlIHNjaGVtYXMgZnJvbSBkaXNrLlxuICogQ2FsbCB0aGlzIGFmdGVyIHdyaXRpbmcgdG8gYSBkZXZpY2UgSlNPTiBmaWxlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVsb2FkRGV2aWNlU2NoZW1hcygpOiB2b2lkIHtcblx0bG9nZ2VyLmluZm8oJ1JlbG9hZGluZyBkZXZpY2Ugc2NoZW1hcyBmcm9tIGRpc2suLi4nKVxuXHRkZXZpY2VTY2hlbWFzQ2FjaGUgPSBsb2FkRGV2aWNlU2NoZW1hcygpXG59XG5cbi8qKlxuICogUmV0dXJucyBhIGxpc3Qgb2YgYXZhaWxhYmxlIG1vZGVsIG51bWJlcnMsIHNvcnRlZC5cbiAqL1xuZnVuY3Rpb24gbG9hZEF2YWlsYWJsZU1vZGVscygpOiBzdHJpbmdbXSB7XG5cdGNvbnN0IHNjaGVtYXMgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0cmV0dXJuIE9iamVjdC5rZXlzKHNjaGVtYXMpLnNvcnQoKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gR2V0Q29uZmlnRmllbGRzKGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10gPSBbXSk6IFNvbWVDb21wYW5pb25Db25maWdGaWVsZFtdIHtcblx0Y29uc3QgbW9kZWxzID0gbG9hZEF2YWlsYWJsZU1vZGVscygpXG5cblx0Ly8gRHJvcGRvd24gaWQgaXMgdGhlIGRldmljZSBNQUMgXHUyMDE0IHN0YWJsZSBhY3Jvc3MgSVAgY2hhbmdlcy5cblx0Ly8gRW1wdHkgaWQgPSBNYW51YWwgbW9kZS5cblx0Y29uc3QgZGV2aWNlQ2hvaWNlcyA9IFtcblx0XHR7IGlkOiAnJywgbGFiZWw6ICdNYW51YWwgKGVudGVyIElQICsgbW9kZWwgYmVsb3cpJyB9LFxuXHRcdC4uLmRpc2NvdmVyZWREZXZpY2VzLm1hcCgoZCkgPT4gKHtcblx0XHRcdGlkOiBkLm1hYyA/PyAnJyxcblx0XHRcdGxhYmVsOiBgTW9kZWwgJHtkLm1vZGVsfSBbJHtkLm1hY31dIEAgJHtkLmlwfWAsXG5cdFx0fSkpLFxuXHRdXG5cblx0cmV0dXJuIFtcblx0XHQvLyBcdTI1MDBcdTI1MDAgRGV2aWNlIHNlbGVjdGlvbiBkcm9wZG93biBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBTdG9yZXMgdGhlIE1BQyBzbyByZS1kaXNjb3Zlcnkgd2l0aCBhIGNoYW5nZWQgSVAgc3RpbGwgbWF0Y2hlcy5cblx0XHR7XG5cdFx0XHR0eXBlOiAnZHJvcGRvd24nLFxuXHRcdFx0aWQ6ICdkZXZpY2VNYWMnLFxuXHRcdFx0bGFiZWw6ICdEZXZpY2UnLFxuXHRcdFx0d2lkdGg6IDgsXG5cdFx0XHRkZWZhdWx0OiAnJyxcblx0XHRcdGNob2ljZXM6IGRldmljZUNob2ljZXMsXG5cdFx0XHR0b29sdGlwOiAnU2VsZWN0IGFuIGF1dG8tZGlzY292ZXJlZCBTdHVkaW8gVGVjaG5vbG9naWVzIGRldmljZSwgb3IgY2hvb3NlIE1hbnVhbCB0byBlbnRlciBhbiBJUCBhZGRyZXNzLicsXG5cdFx0fSxcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBNYW51YWwgSVAgZW50cnkgXHUyMDE0IG9ubHkgdmlzaWJsZSBpbiBtYW51YWwgbW9kZSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHR7XG5cdFx0XHR0eXBlOiAndGV4dGlucHV0Jyxcblx0XHRcdGlkOiAnaG9zdCcsXG5cdFx0XHRsYWJlbDogJ1RhcmdldCBJUCcsXG5cdFx0XHR3aWR0aDogOCxcblx0XHRcdGRlZmF1bHQ6ICcnLFxuXHRcdFx0cmVnZXg6IFJlZ2V4LklQLFxuXHRcdFx0aXNWaXNpYmxlRXhwcmVzc2lvbjogYCEkKG9wdGlvbnM6ZGV2aWNlTWFjKWAsXG5cdFx0XHR0b29sdGlwOiAnRW50ZXIgdGhlIElQIGFkZHJlc3Mgb2YgdGhlIGRldmljZSBtYW51YWxseS4nLFxuXHRcdH0sXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgTWFudWFsIG1vZGVsIHNlbGVjdG9yIFx1MjAxNCBvbmx5IHZpc2libGUgaW4gbWFudWFsIG1vZGUgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdGlkOiAnYWN0aXZlTW9kZWwnLFxuXHRcdFx0bGFiZWw6ICdBY3RpdmUgRGV2aWNlIE1vZGVsJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogbW9kZWxzWzBdID8/ICcnLFxuXHRcdFx0Y2hvaWNlczogbW9kZWxzLm1hcCgobW9kZWwpID0+ICh7XG5cdFx0XHRcdGlkOiBtb2RlbCxcblx0XHRcdFx0bGFiZWw6IGBNb2RlbCAke21vZGVsfWAsXG5cdFx0XHR9KSksXG5cdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiBgISQob3B0aW9uczpkZXZpY2VNYWMpYCxcblx0XHRcdHRvb2x0aXA6ICdTZWxlY3Qgd2hpY2ggU3R1ZGlvIFRlY2hub2xvZ2llcyBtb2RlbCBpcyBhY3RpdmUgZm9yIGFjdGlvbnMgYW5kIGZlZWRiYWNrcy4nLFxuXHRcdH0sXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgRGV2IE1vZGUgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2NoZWNrYm94Jyxcblx0XHRcdGlkOiAnZGV2TW9kZScsXG5cdFx0XHRsYWJlbDogJ0RldiBNb2RlJyxcblx0XHRcdHdpZHRoOiAxMixcblx0XHRcdGRlZmF1bHQ6IGZhbHNlLFxuXHRcdFx0dG9vbHRpcDogJ0VuYWJsZSB0byBhbGxvdyBwYXJzaW5nIG9mIFNUIERldmljZXMgbm90IGN1cnJlbnRseSBzdXBwb3J0ZWQnLFxuXHRcdH0sXG5cdF1cbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBlZmZlY3RpdmUgaG9zdCBJUC5cbiAqIEF1dG8gbW9kZSAoZGV2aWNlTWFjIHNldCk6IGZpbmRzIHRoZSBjdXJyZW50IElQIG9mIHRoZSBkaXNjb3ZlcmVkIGRldmljZSB3aXRoIHRoYXQgTUFDLlxuICogTWFudWFsIG1vZGUgKGRldmljZU1hYyBlbXB0eSk6IHJldHVybnMgdGhlIG1hbnVhbGx5IGVudGVyZWQgaG9zdCBJUC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVIb3N0KGNvbmZpZzogTW9kdWxlQ29uZmlnLCBkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdKTogc3RyaW5nIHtcblx0aWYgKGNvbmZpZy5kZXZpY2VNYWMpIHtcblx0XHRjb25zdCBkZXZpY2UgPSBkaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLm1hYyA9PT0gY29uZmlnLmRldmljZU1hYylcblx0XHRyZXR1cm4gZGV2aWNlPy5pcCA/PyAnJ1xuXHR9XG5cdHJldHVybiBTdHJpbmcoY29uZmlnLmhvc3QgPz8gJycpXG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgZWZmZWN0aXZlIG1vZGVsLlxuICogQXV0byBtb2RlOiB1c2VzIHRoZSBtb2RlbCBmcm9tIHRoZSBkaXNjb3ZlcmVkIGRldmljZSBtYXRjaGluZyB0aGUgc3RvcmVkIE1BQy5cbiAqIE1hbnVhbCBtb2RlOiB1c2VzIHRoZSBtYW51YWxseSBzZWxlY3RlZCBhY3RpdmVNb2RlbC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVNb2RlbChjb25maWc6IE1vZHVsZUNvbmZpZywgZGlzY292ZXJlZERldmljZXM6IERldmljZUluZm9bXSk6IHN0cmluZyB7XG5cdGlmIChjb25maWcuZGV2aWNlTWFjKSB7XG5cdFx0Y29uc3QgZGV2aWNlID0gZGlzY292ZXJlZERldmljZXMuZmluZCgoZCkgPT4gZC5tYWMgPT09IGNvbmZpZy5kZXZpY2VNYWMpXG5cdFx0bG9nZ2VyLmRlYnVnKGByZXNvbHZlTW9kZWw6IGRldmljZU1hYz1cIiR7Y29uZmlnLmRldmljZU1hY31cIiwgZm91bmQgZGV2aWNlOiAke2RldmljZT8ubW9kZWwgPz8gJ25vbmUnfWApXG5cdFx0cmV0dXJuIGRldmljZT8ubW9kZWwgPz8gJydcblx0fVxuXHRsb2dnZXIuZGVidWcoYHJlc29sdmVNb2RlbDogbWFudWFsIG1vZGUsIGFjdGl2ZU1vZGVsPVwiJHtjb25maWcuYWN0aXZlTW9kZWx9XCJgKVxuXHRyZXR1cm4gU3RyaW5nKGNvbmZpZy5hY3RpdmVNb2RlbCA/PyAnJylcbn1cbiIsICJpbXBvcnQgdHlwZSBNb2R1bGVJbnN0YW5jZSBmcm9tICcuL21haW4uanMnXG5cbi8qKlxuICogRGVmaW5lIENvbXBhbmlvbiB2YXJpYWJsZXMgZm9yIHRoaXMgbW9kdWxlLlxuICogVmFyaWFibGVzIGNhbiBiZSB1c2VkIHRvIGRpc3BsYXkgZHluYW1pYyBzdGF0ZSBpbiBidXR0b24gbGFiZWxzLCB0cmlnZ2VycywgZXRjLlxuICovXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRzZWxmLnNldFZhcmlhYmxlRGVmaW5pdGlvbnMoe1xuXHRcdG1vZGVsOiB7IG5hbWU6ICdEZXZpY2UgTW9kZWwgTnVtYmVyJyB9LFxuXHRcdG1vZGVsTmFtZTogeyBuYW1lOiAnRGV2aWNlIE1vZGVsIE5hbWUgKEZ1bGwgRGVzY3JpcHRpb24pJyB9LFxuXHRcdG1hbnVmYWN0dXJlcjogeyBuYW1lOiAnRGV2aWNlIE1hbnVmYWN0dXJlcicgfSxcblx0XHRmaXJtd2FyZTogeyBuYW1lOiAnRGV2aWNlIEZpcm13YXJlIFZlcnNpb24nIH0sXG5cdFx0ZGFudGVGVzogeyBuYW1lOiAnRGFudGUgTW9kdWxlIEZpcm13YXJlIFZlcnNpb24nIH0sXG5cdFx0bWFjOiB7IG5hbWU6ICdEZXZpY2UgTUFDIEFkZHJlc3MnIH0sXG5cdFx0aXA6IHsgbmFtZTogJ0RldmljZSBJUCBBZGRyZXNzJyB9LFxuXHR9KVxufVxuXG5jb25zdCBDTEVBUkVEX1ZBUklBQkxFUyA9IHtcblx0bW9kZWw6ICcnLFxuXHRtb2RlbE5hbWU6ICcnLFxuXHRtYW51ZmFjdHVyZXI6ICcnLFxuXHRmaXJtd2FyZTogJycsXG5cdGRhbnRlRlc6ICcnLFxuXHRtYWM6ICcnLFxuXHRpcDogJycsXG59XG5cbi8qKlxuICogVXBkYXRlIHZhcmlhYmxlIHZhbHVlcyBmcm9tIGRpc2NvdmVyZWQgZGV2aWNlIGluZm9ybWF0aW9uLlxuICogT25seSBwb3B1bGF0ZXMgdmFyaWFibGVzIHdoZW4gdGhlIGN1cnJlbnQgaG9zdCBpcyBhdXRob3JpemVkLlxuICogQ2xlYXJzIGFsbCB2YXJpYWJsZXMgaWYgdGhlIGRldmljZSBpcyBub3QgYXV0aG9yaXplZCBvciBub3QgZm91bmQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVWYXJpYWJsZVZhbHVlcyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRjb25zdCBjdXJyZW50SG9zdCA9IHNlbGYuaG9zdFxuXG5cdC8vIENsZWFyIHZhcmlhYmxlcyBpZiBubyBob3N0IGNvbmZpZ3VyZWQgb3IgZGV2aWNlIGlzIG5vdCBhdXRob3JpemVkXG5cdGlmICghY3VycmVudEhvc3QgfHwgIXNlbGYuc3RDb250cm9sbGVyLmlzRGV2aWNlQXV0aG9yaXplZChjdXJyZW50SG9zdCkpIHtcblx0XHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKENMRUFSRURfVkFSSUFCTEVTKVxuXHRcdHJldHVyblxuXHR9XG5cblx0Y29uc3QgZGV2aWNlID0gc2VsZi5kZXZpY2VzLmZpbmQoKGQpID0+IGQuaXAgPT09IGN1cnJlbnRIb3N0KVxuXHRpZiAoZGV2aWNlKSB7XG5cdFx0c2VsZi5zZXRWYXJpYWJsZVZhbHVlcyh7XG5cdFx0XHRtb2RlbDogZGV2aWNlLm1vZGVsIHx8ICcnLFxuXHRcdFx0bW9kZWxOYW1lOiBkZXZpY2UubW9kZWxOYW1lIHx8ICcnLFxuXHRcdFx0bWFudWZhY3R1cmVyOiBkZXZpY2UubWFudWZhY3R1cmVyIHx8ICcnLFxuXHRcdFx0ZmlybXdhcmU6IGRldmljZS5maXJtd2FyZU1haW4gfHwgJycsXG5cdFx0XHRkYW50ZUZXOiBkZXZpY2UuZGFudGVGaXJtd2FyZSB8fCAnJyxcblx0XHRcdG1hYzogZGV2aWNlLm1hYyB8fCAnJyxcblx0XHRcdGlwOiBkZXZpY2UuaXAsXG5cdFx0fSlcblx0fSBlbHNlIHtcblx0XHQvLyBBdXRob3JpemVkIGJ1dCBub3QgaW4gZGlzY292ZXJlZCBsaXN0IChtYW51YWwgSVAgdGhhdCBwcm9iZWQgc3VjY2Vzc2Z1bGx5KVxuXHRcdC8vIFdlIGtub3cgaXQncyB0aGUgcmlnaHQgZGV2aWNlIGJ1dCBkb24ndCBoYXZlIGZ1bGwgaW5mbyB5ZXRcblx0XHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKHtcblx0XHRcdC4uLkNMRUFSRURfVkFSSUFCTEVTLFxuXHRcdFx0aXA6IGN1cnJlbnRIb3N0LFxuXHRcdH0pXG5cdH1cbn1cbiIsICJpbXBvcnQgdHlwZSB7IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVTY3JpcHQgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHR5cGUgeyBNb2R1bGVDb25maWcgfSBmcm9tICcuL2NvbmZpZy5qcydcblxuZXhwb3J0IGNvbnN0IFVwZ3JhZGVTY3JpcHRzOiBDb21wYW5pb25TdGF0aWNVcGdyYWRlU2NyaXB0PE1vZHVsZUNvbmZpZz5bXSA9IFtcblx0Lypcblx0ICogUGxhY2UgeW91ciB1cGdyYWRlIHNjcmlwdHMgaGVyZVxuXHQgKiBSZW1lbWJlciB0aGF0IG9uY2UgaXQgaGFzIGJlZW4gYWRkZWQgaXQgY2Fubm90IGJlIHJlbW92ZWQhXG5cdCAqL1xuXHQvLyBmdW5jdGlvbiAoY29udGV4dCwgcHJvcHMpIHtcblx0Ly8gXHRyZXR1cm4ge1xuXHQvLyBcdFx0dXBkYXRlZENvbmZpZzogbnVsbCxcblx0Ly8gXHRcdHVwZGF0ZWRBY3Rpb25zOiBbXSxcblx0Ly8gXHRcdHVwZGF0ZWRGZWVkYmFja3M6IFtdLFxuXHQvLyBcdH1cblx0Ly8gfSxcbl1cbiIsICJleHBvcnQgdHlwZSBEZXZpY2VJbmZvID0ge1xuXHRtb2RlbDogc3RyaW5nIC8vIE1vZGVsIG51bWJlciAoZS5nLiwgXCIzNzRBXCIpXG5cdG1vZGVsTmFtZT86IHN0cmluZyAvLyBGdWxsIG1vZGVsIGRlc2NyaXB0aW9uIChlLmcuLCBcIk1vZGVsIDM3NEEgSW50ZXJjb20gQmVsdHBhY2tcIilcblx0aXA6IHN0cmluZ1xuXHRuYW1lPzogc3RyaW5nIC8vIERhbnRlIGRldmljZSBuYW1lICh1c2VyLWNvbmZpZ3VyYWJsZSBsYWJlbCwgZS5nLiBcIlNULU0zNzRBLUJlbHRwYWNrXCIpXG5cdG1hbnVmYWN0dXJlcj86IHN0cmluZyAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGZpcm13YXJlTWFpbj86IHN0cmluZyAvLyBEZXZpY2UgZmlybXdhcmUgdmVyc2lvbiBmcm9tIERhbnRlIGRpc2NvdmVyeSAoZS5nLiwgXCI0LjkuMFwiKVxuXHRkYW50ZUZpcm13YXJlPzogc3RyaW5nIC8vIERhbnRlIG1vZHVsZSBmaXJtd2FyZSB2ZXJzaW9uXG5cdG1hYz86IHN0cmluZ1xufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgQ29tbWFuZCBJRCBDb25zdGFudHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgY29uc3QgQ01EX0dFVF9GSVJNV0FSRSA9IDB4MDAgLy8gUmVxdWVzdCBkZXZpY2UgZmlybXdhcmUgdmVyc2lvblxuZXhwb3J0IGNvbnN0IENNRF9NSUNfUFJFID0gMHgwMiAvLyBNaWMgcHJlYW1wIHJhdyBzZXQgKGdhaW4sIHBoYW50b20pIFx1MjAxNCBwb3NpdGlvbmFsIGJ5dGVzLCBubyBzZXR0aW5nIElEc1xuZXhwb3J0IGNvbnN0IENNRF9CVVNfR0VUID0gMHgwMyAvLyBIZWFydGJlYXQgLyBrZWVwYWxpdmUgcGluZ1xuZXhwb3J0IGNvbnN0IENNRF9CVVNfU0VUID0gMHgwNCAvLyBTZXQgc2V0dGluZyBvbiBzcGVjaWZpYyBidXMvY2hhbm5lbFxuZXhwb3J0IGNvbnN0IENNRF9IRUFEUEhPTkUgPSAweDA1IC8vIEhlYWRwaG9uZSBjb250cm9sc1xuZXhwb3J0IGNvbnN0IENNRF9CVVRUT05fTU9ERSA9IDB4MDcgLy8gQnV0dG9uIG1vZGUgY29uZmlndXJhdGlvblxuZXhwb3J0IGNvbnN0IENNRF9TWVNURU0gPSAweDA5IC8vIFN5c3RlbS1sZXZlbCBjb21tYW5kc1xuZXhwb3J0IGNvbnN0IENNRF9HRVRfQUxMX1NFVFRJTkdTID0gMHgwYSAvLyBSZXF1ZXN0IGFsbCBjdXJyZW50IHNldHRpbmdzIGZyb20gZGV2aWNlXG5leHBvcnQgY29uc3QgQ01EX1NFVFRJTkdTX1BVU0ggPSAweDBiIC8vIFVuc29saWNpdGVkIHNldHRpbmdzIHVwZGF0ZSBmcm9tIGRldmljZVxuZXhwb3J0IGNvbnN0IENNRF9ERVZfU1BFQyA9IDB4MGQgLy8gRGV2aWNlLXNwZWNpZmljIHNldHRpbmcgZ2V0L3NldCB3aXRoIEFDS1xuZXhwb3J0IGNvbnN0IENNRF9SRVNFVF9ERVZJQ0UgPSAweDBlIC8vIEZhY3RvcnkgcmVzZXQgY29tbWFuZFxuZXhwb3J0IGNvbnN0IENNRF9HTE9CQUxfTUlDX0tJTEwgPSAweDEwIC8vIEVtZXJnZW5jeSBtaWMga2lsbCAoYWxsIGNoYW5uZWxzKVxuZXhwb3J0IGNvbnN0IENNRF9NSUNfUFJFX0JVUyA9IDB4MTIgLy8gTWljL3ByZWFtcCBzZXR0aW5ncyBwZXIgYnVzIChnYWluLCBwaGFudG9tLCBldGMpXG5leHBvcnQgY29uc3QgQ01EX0NIQU5ORUwgPSAweDE0IC8vIENoYW5uZWwtc3BlY2lmaWMgY29udHJvbHNcblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIENvbW1hbmQgTmFtZSBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q29tbWFuZE5hbWUoY21kSWQ6IG51bWJlcik6IHN0cmluZyB7XG5cdHN3aXRjaCAoY21kSWQpIHtcblx0XHRjYXNlIENNRF9HRVRfRklSTVdBUkU6XG5cdFx0XHRyZXR1cm4gJ0dldCBGaXJtd2FyZSBWZXJzaW9uJ1xuXHRcdGNhc2UgQ01EX01JQ19QUkU6XG5cdFx0XHRyZXR1cm4gJ01pYyBQcmVhbXAnXG5cdFx0Y2FzZSBDTURfQlVTX0dFVDpcblx0XHRcdHJldHVybiAnSGVhcnRiZWF0J1xuXHRcdGNhc2UgQ01EX0JVU19TRVQ6XG5cdFx0XHRyZXR1cm4gJ1NldCBCdXMgU2V0dGluZydcblx0XHRjYXNlIENNRF9IRUFEUEhPTkU6XG5cdFx0XHRyZXR1cm4gJ0hlYWRwaG9uZSBDb250cm9sJ1xuXHRcdGNhc2UgQ01EX0JVVFRPTl9NT0RFOlxuXHRcdFx0cmV0dXJuICdCdXR0b24gTW9kZSdcblx0XHRjYXNlIENNRF9TWVNURU06XG5cdFx0XHRyZXR1cm4gJ1N5c3RlbSBDb21tYW5kJ1xuXHRcdGNhc2UgQ01EX0dFVF9BTExfU0VUVElOR1M6XG5cdFx0XHRyZXR1cm4gJ1JlcXVlc3QgQWxsIFNldHRpbmdzJ1xuXHRcdGNhc2UgQ01EX1NFVFRJTkdTX1BVU0g6XG5cdFx0XHRyZXR1cm4gJ1NldHRpbmdzIFB1c2gnXG5cdFx0Y2FzZSBDTURfTUlDX1BSRV9CVVM6XG5cdFx0XHRyZXR1cm4gJ01pYy9QcmUgQnVzJ1xuXHRcdGNhc2UgQ01EX0RFVl9TUEVDOlxuXHRcdFx0cmV0dXJuICdEZXZpY2UgU2V0dGluZydcblx0XHRjYXNlIENNRF9DSEFOTkVMOlxuXHRcdFx0cmV0dXJuICdDaGFubmVsIFNldHRpbmcnXG5cdFx0Y2FzZSBDTURfUkVTRVRfREVWSUNFOlxuXHRcdFx0cmV0dXJuICdSZXNldCBEZXZpY2UnXG5cdFx0Y2FzZSBDTURfR0xPQkFMX01JQ19LSUxMOlxuXHRcdFx0cmV0dXJuICdHbG9iYWwgTWljIEtpbGwnXG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBgY21kXzB4JHtjbWRJZC50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX1gXG5cdH1cbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIElEIEdlbmVyYXRpb24gSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDcmVhdGVzIGEgY29uc2lzdGVudCBJRCBmb3IgYWN0aW9ucywgZmVlZGJhY2tzLCBhbmQgc3RhdGUga2V5cy5cbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2J1c0NofV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2ggKGUuZy4sIFwiNTMwNF8xNF8wXzBcIilcbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGhvdXQgYnVzQ2ggKGUuZy4sIFwiNTMwNF8xMl9kXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtYWtlU2V0dGluZ0lkKFxuXHRtb2RlbDogc3RyaW5nLFxuXHRjbWRJZDogbnVtYmVyIHwgc3RyaW5nLFxuXHRzZXR0aW5nSWQ6IG51bWJlciB8IHN0cmluZyxcblx0YnVzQ2g/OiBudW1iZXIgfCBzdHJpbmcsXG4pOiBzdHJpbmcge1xuXHRjb25zdCBjbWQgPSB0eXBlb2YgY21kSWQgPT09ICdudW1iZXInID8gY21kSWQudG9TdHJpbmcoMTYpIDogY21kSWRcblx0Y29uc3QgaWQgPSB0eXBlb2Ygc2V0dGluZ0lkID09PSAnbnVtYmVyJyA/IHNldHRpbmdJZC50b1N0cmluZygxNikgOiBzZXR0aW5nSWRcblxuXHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdGNvbnN0IGNoID0gdHlwZW9mIGJ1c0NoID09PSAnbnVtYmVyJyA/IGJ1c0NoLnRvU3RyaW5nKDE2KSA6IGJ1c0NoXG5cdFx0cmV0dXJuIGAke21vZGVsfV8ke2NtZH1fJHtjaH1fJHtpZH1gXG5cdH1cblxuXHRyZXR1cm4gYCR7bW9kZWx9XyR7Y21kfV8ke2lkfWBcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIEhleCBGb3JtYXR0aW5nIEhlbHBlcnMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENvbnZlcnRzIGEgbnVtYmVyIHRvIGEgaGV4IHN0cmluZyB3aXRoIDB4IHByZWZpeCBhbmQgcGFkZGluZy5cbiAqIEBwYXJhbSB2YWx1ZSAtIFRoZSBudW1iZXIgdG8gY29udmVydFxuICogQHBhcmFtIHBhZExlbmd0aCAtIE51bWJlciBvZiBoZXggZGlnaXRzIHRvIHBhZCB0byAoZGVmYXVsdDogMilcbiAqIEByZXR1cm5zIEZvcm1hdHRlZCBoZXggc3RyaW5nIChlLmcuLCBcIjB4MGRcIiwgXCIweGZmXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0hleCh2YWx1ZTogbnVtYmVyLCBwYWRMZW5ndGggPSAyKTogc3RyaW5nIHtcblx0cmV0dXJuIGAweCR7dmFsdWUudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KHBhZExlbmd0aCwgJzAnKX1gXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gYXJyYXkgb2YgYnl0ZXMgdG8gYSBoZXggc3RyaW5nIHdpdGggMHggcHJlZml4LlxuICogQHBhcmFtIGJ5dGVzIC0gQXJyYXkgb2YgYnl0ZXMgb3IgQnVmZmVyXG4gKiBAcmV0dXJucyBGb3JtYXR0ZWQgaGV4IHN0cmluZyAoZS5nLiwgXCIweDBhZmYxMlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gYnl0ZXNUb0hleChieXRlczogbnVtYmVyW10gfCBCdWZmZXIpOiBzdHJpbmcge1xuXHRyZXR1cm4gYDB4JHtBcnJheS5mcm9tKGJ5dGVzKVxuXHRcdC5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXG5cdFx0LmpvaW4oJycpfWBcbn1cblxuLyoqXG4gKiBGb3JtYXRzIFJHQiBjb2xvciBieXRlcyBhcyBhIENTUyBoZXggY29sb3Igc3RyaW5nLlxuICogQHBhcmFtIHIgLSBSZWQgY29tcG9uZW50ICgwLTI1NSlcbiAqIEBwYXJhbSBnIC0gR3JlZW4gY29tcG9uZW50ICgwLTI1NSlcbiAqIEBwYXJhbSBiIC0gQmx1ZSBjb21wb25lbnQgKDAtMjU1KVxuICogQHJldHVybnMgQ1NTIGhleCBjb2xvciBzdHJpbmcgKGUuZy4sIFwiI0ZGMDBBQlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0UmdiQ29sb3IocjogbnVtYmVyLCBnOiBudW1iZXIsIGI6IG51bWJlcik6IHN0cmluZyB7XG5cdHJldHVybiBgIyR7W3IsIGcsIGJdXG5cdFx0Lm1hcCgodikgPT4gdi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcblx0XHQuam9pbignJylcblx0XHQudG9VcHBlckNhc2UoKX1gXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBJRCBQYXJzaW5nIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogUGFyc2VzIGEgc2V0dGluZyBJRCBzdHJpbmcgaW50byBpdHMgY29tcG9uZW50cy5cbiAqIEBwYXJhbSBpZCAtIFNldHRpbmcgSUQgc3RyaW5nIChlLmcuLCBcIjM5MV9kXzBcIiBvciBcIjUzMDRfMTRfMF8xXCIpXG4gKiBAcmV0dXJucyBQYXJzZWQgY29tcG9uZW50cyB3aXRoIGhleCBzdHJpbmdzIGNvbnZlcnRlZCB0byBudW1iZXJzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVNldHRpbmdJZChpZDogc3RyaW5nKTogeyBtb2RlbDogc3RyaW5nOyBjbWRJZDogbnVtYmVyOyBiYXNlSWQ6IG51bWJlciB9IHtcblx0Y29uc3QgW21vZGVsLCBjbWRJZFN0ciwgaWRTdHJdID0gaWQuc3BsaXQoJ18nKVxuXHRyZXR1cm4ge1xuXHRcdG1vZGVsLFxuXHRcdGNtZElkOiBwYXJzZUludChjbWRJZFN0ciwgMTYpLFxuXHRcdGJhc2VJZDogcGFyc2VJbnQoaWRTdHIsIDE2KSxcblx0fVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgTW9kZWwgRGlzdGFuY2UgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDYWxjdWxhdGVzIG51bWVyaWMgZGlzdGFuY2UgYmV0d2VlbiB0d28gbW9kZWwgbnVtYmVycy5cbiAqIFVzZWQgZm9yIGZpbmRpbmcgc2ltaWxhciBtb2RlbHMgZm9yIHNldHRpbmcgaW5mZXJlbmNlLlxuICogQHBhcmFtIG1vZGVsQSAtIEZpcnN0IG1vZGVsIG51bWJlciAoZS5nLiwgXCIzOTFcIilcbiAqIEBwYXJhbSBtb2RlbEIgLSBTZWNvbmQgbW9kZWwgbnVtYmVyIChlLmcuLCBcIjM5MlwiKVxuICogQHJldHVybnMgTnVtZXJpYyBkaXN0YW5jZSBiZXR3ZWVuIG1vZGVscywgb3IgSW5maW5pdHkgaWYgZWl0aGVyIGlzIG5vbi1udW1lcmljXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtb2RlbERpc3RhbmNlKG1vZGVsQTogc3RyaW5nLCBtb2RlbEI6IHN0cmluZyk6IG51bWJlciB7XG5cdGNvbnN0IG5hID0gcGFyc2VJbnQobW9kZWxBLnJlcGxhY2UoL1xcRC9nLCAnJyksIDEwKVxuXHRjb25zdCBuYiA9IHBhcnNlSW50KG1vZGVsQi5yZXBsYWNlKC9cXEQvZywgJycpLCAxMClcblx0aWYgKE51bWJlci5pc05hTihuYSkgfHwgTnVtYmVyLmlzTmFOKG5iKSkgcmV0dXJuIEluZmluaXR5XG5cdHJldHVybiBNYXRoLmFicyhuYSAtIG5iKVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU2NoZW1hIE5vcm1hbGl6YXRpb24gSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBOb3JtYWxpemVzIGRldmljZSBzY2hlbWFzIHRvIGVuc3VyZSBjbWRTY2hlbWEgaXMgYWx3YXlzIGFuIGFycmF5LlxuICogVGhpcyBoZWxwZXIgZWxpbWluYXRlcyBkdXBsaWNhdGUgc2NoZW1hIHRyYW5zZm9ybWF0aW9uIGNvZGUuXG4gKiBAcGFyYW0gc2NoZW1hc1JhdyAtIFJhdyBzY2hlbWFzIGZyb20gZ2V0RGV2aWNlU2NoZW1hcygpXG4gKiBAcmV0dXJucyBOb3JtYWxpemVkIHNjaGVtYXMgd2l0aCBndWFyYW50ZWVkIGNtZFNjaGVtYSBhcnJheXNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldE5vcm1hbGl6ZWRTY2hlbWFzKFxuXHRzY2hlbWFzUmF3OiBSZWNvcmQ8c3RyaW5nLCBhbnk+LFxuKTogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+IHtcblx0Y29uc3Qgbm9ybWFsaXplZDogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+ID0ge31cblx0Zm9yIChjb25zdCBbbW9kZWwsIGpzb25dIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYXNSYXcpKSB7XG5cdFx0bm9ybWFsaXplZFttb2RlbF0gPSB7XG5cdFx0XHRtb2RlbDoganNvbi5tb2RlbCxcblx0XHRcdGNtZFNjaGVtYTogQXJyYXkuaXNBcnJheShqc29uLmNtZFNjaGVtYSkgPyBqc29uLmNtZFNjaGVtYSA6IFtdLFxuXHRcdH1cblx0fVxuXHRyZXR1cm4gbm9ybWFsaXplZFxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgQWN0aW9uIExvb2t1cCBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIEZpbmRzIGFuIGFjdGlvbi9zZXR0aW5nIGluIHRoZSBzY2hlbWEsIHN1cHBvcnRpbmcgYm90aCBleGFjdCBtYXRjaGVzIGFuZCBpZEFkZCBvZmZzZXRzLlxuICogVGhpcyBoZWxwZXIgZWxpbWluYXRlcyBkdXBsaWNhdGUgYWN0aW9uIGxvb2t1cCBsb2dpYyBhY3Jvc3MgbXVsdGlwbGUgZmlsZXMuXG4gKiBAcGFyYW0gc2NoZW1hcyAtIE5vcm1hbGl6ZWQgZGV2aWNlIHNjaGVtYXNcbiAqIEBwYXJhbSBtb2RlbCAtIERldmljZSBtb2RlbCAoZS5nLiwgXCIzOTFcIilcbiAqIEBwYXJhbSBjbWRJZCAtIENvbW1hbmQgSURcbiAqIEBwYXJhbSBzZXR0aW5nSWQgLSBTZXR0aW5nIElEIChtYXkgaW5jbHVkZSBpZEFkZCBvZmZzZXQpXG4gKiBAcmV0dXJucyBNYXRjaGluZyBhY3Rpb24vc2V0dGluZyBvciB1bmRlZmluZWRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZpbmRBY3Rpb25Gb3JTZXR0aW5nKFxuXHRzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4sXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIsXG5cdHNldHRpbmdJZDogbnVtYmVyLFxuKTogYW55IHtcblx0Y29uc3Qgc2NoZW1hID0gc2NoZW1hc1ttb2RlbF1cblx0aWYgKCFzY2hlbWEgfHwgIUFycmF5LmlzQXJyYXkoc2NoZW1hLmNtZFNjaGVtYSkpIHJldHVybiB1bmRlZmluZWRcblxuXHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0bGV0IGFjdGlvbiA9IHNjaGVtYS5jbWRTY2hlbWEuZmluZCgoczogYW55KSA9PiBzLmNtZF9pZCA9PT0gY21kSWQgJiYgcy5pZCA9PT0gc2V0dGluZ0lkKVxuXG5cdC8vIElmIG5vIGV4YWN0IG1hdGNoLCB0cnkgdG8gZmluZCBiYXNlIGFjdGlvbiB3aXRoIGlkQWRkXG5cdGlmICghYWN0aW9uKSB7XG5cdFx0YWN0aW9uID0gc2NoZW1hLmNtZFNjaGVtYS5maW5kKChzOiBhbnkpID0+IHtcblx0XHRcdGlmIChzLmNtZF9pZCAhPT0gY21kSWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBzLm9wdGlvbnM/LmZpbmQoKG9wdDogYW55KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoIWlkQWRkT3B0aW9uPy5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdC8vIENoZWNrIGlmIHNldHRpbmdJZCBtYXRjaGVzIGJhc2UgKyBhbnkgaWRBZGQgb2Zmc2V0XG5cdFx0XHRjb25zdCBvZmZzZXQgPSBzZXR0aW5nSWQgLSBzLmlkXG5cdFx0XHRyZXR1cm4gaWRBZGRPcHRpb24uY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9mZnNldClcblx0XHR9KVxuXHR9XG5cblx0cmV0dXJuIGFjdGlvblxufVxuIiwgIi8qKlxuICogYnVpbGQtY29tbWFuZHMudHNcbiAqIC0gVXNlcyBjZW50cmFsaXplZCBkZXZpY2Ugc2NoZW1hIGNhY2hlIGZyb20gY29uZmlnLnRzXG4gKiAtIFByb2R1Y2VzIENvbXBhbmlvbiBhY3Rpb24gZGVmaW5pdGlvbnMgYW5kIGZlZWRiYWNrc1xuICovXG5cbmltcG9ydCB7XG5cdENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zLFxuXHRDb21wYW5pb25BY3Rpb25EZWZpbml0aW9uLFxuXHRDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zLFxuXHRjb21iaW5lUmdiLFxufSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHsgbWFrZVNldHRpbmdJZCB9IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQgeyBnZXREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0gT3B0aW9uIEJ1aWxkZXIgLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuZnVuY3Rpb24gYnVpbGRPcHRpb24obzogYW55KTogYW55IHtcblx0Y29uc3QgYmFzZSA9IHtcblx0XHR0eXBlOiBvLnR5cGUsXG5cdFx0aWQ6IG8uaWQsXG5cdFx0bGFiZWw6IG8ubGFiZWwsXG5cdFx0ZGVmYXVsdDogby5kZWZhdWx0LFxuXHRcdHRvb2x0aXA6IG8udG9vbHRpcCxcblx0fVxuXG5cdHN3aXRjaCAoby50eXBlKSB7XG5cdFx0Y2FzZSAnZHJvcGRvd24nOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgY2hvaWNlczogby5jaG9pY2VzID8/IFtdIH1cblxuXHRcdGNhc2UgJ251bWJlcic6XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHQuLi5iYXNlLFxuXHRcdFx0XHRtaW46IG8ubWluLFxuXHRcdFx0XHRtYXg6IG8ubWF4LFxuXHRcdFx0XHRzdGVwOiBvLnN0ZXAgPz8gMSxcblx0XHRcdFx0cmFuZ2U6IHRydWUsXG5cdFx0XHR9XG5cblx0XHRjYXNlICdjaGVja2JveCc6XG5cdFx0XHRyZXR1cm4geyAuLi5iYXNlLCBkZWZhdWx0OiBvLmRlZmF1bHQgPz8gZmFsc2UgfVxuXG5cdFx0Y2FzZSAnc3RhdGljLXRleHQnOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgdmFsdWU6IG8udmFsdWUgPz8gJycgfVxuXG5cdFx0Y2FzZSAndGV4dGlucHV0Jzpcblx0XHRjYXNlICdjb2xvcnBpY2tlcic6XG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBiYXNlXG5cdH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBBY3Rpb25zIC0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRBY3Rpb25zKCk6IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCBhY3Rpb25zOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyA9IHt9XG5cblx0Zm9yIChjb25zdCBbbW9kZWwsIHNjaGVtYV0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hcykpIHtcblx0XHRjb25zdCBjbWRTY2hlbWEgPSBzY2hlbWEuY21kU2NoZW1hXG5cdFx0aWYgKCFBcnJheS5pc0FycmF5KGNtZFNjaGVtYSkpIGNvbnRpbnVlXG5cblx0XHRmb3IgKGNvbnN0IGEgb2YgY21kU2NoZW1hKSB7XG5cdFx0XHQvLyBTa2lwIHJlYWQtb25seSBlbnRyaWVzIFx1MjAxNCB0aGV5IGFyZSBmZWVkYmFjay1vbmx5IChpbmRpY2F0b3JzLCBzdGF0dXMpXG5cdFx0XHRpZiAoYS5yZWFkb25seSA9PT0gdHJ1ZSkgY29udGludWVcblxuXHRcdFx0Y29uc3QgYWN0aW9uSWQgPSBtYWtlU2V0dGluZ0lkKG1vZGVsLCBhLmNtZF9pZCwgYS5pZClcblxuXHRcdFx0Y29uc3Qgb3B0aW9ucyA9IChhLm9wdGlvbnMgPz8gW10pLm1hcChidWlsZE9wdGlvbilcblxuXHRcdFx0Y29uc3QgYWN0aW9uOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9uID0ge1xuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHttb2RlbH1dICR7YS5uYW1lfWAsXG5cdFx0XHRcdG9wdGlvbnMsXG5cdFx0XHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdFx0Lyogd2lyZWQgbGF0ZXIgaW4gVXBkYXRlQWN0aW9ucyAqL1xuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXG5cdFx0XHRhY3Rpb25zW2FjdGlvbklkXSA9IGFjdGlvblxuXHRcdH1cblx0fVxuXG5cdHJldHVybiBhY3Rpb25zXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0gRmVlZGJhY2tzIC0tLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuLyoqXG4gKiBSZXR1cm5zIHRydWUgaWYgdGhlIHNldHRpbmcncyB2YWx1ZSBvcHRpb24gcmVwcmVzZW50cyBhIGJvb2xlYW4gKG9uL29mZikgY2hvaWNlOlxuICogLSB0eXBlICdjaGVja2JveCcsIE9SXG4gKiAtIGEgMi1jaG9pY2UgZHJvcGRvd24gd2hlcmUgb25lIGxhYmVsIGlzIFwib2ZmXCIgYW5kIHRoZSBvdGhlciBpcyBcIm9uXCJcbiAqL1xuZnVuY3Rpb24gaXNCb29sZWFuRHJvcGRvd24oc2V0dGluZzogYW55KTogYm9vbGVhbiB7XG5cdGNvbnN0IHZhbHVlT3B0ID0gc2V0dGluZy5vcHRpb25zPy5maW5kKChvOiBhbnkpID0+IG8uaWQgPT09ICd2YWx1ZScpXG5cdGlmICghdmFsdWVPcHQpIHJldHVybiBmYWxzZVxuXHRpZiAodmFsdWVPcHQudHlwZSA9PT0gJ2NoZWNrYm94JykgcmV0dXJuIHRydWVcblx0aWYgKHZhbHVlT3B0LnR5cGUgIT09ICdkcm9wZG93bicgfHwgIUFycmF5LmlzQXJyYXkodmFsdWVPcHQuY2hvaWNlcykpIHJldHVybiBmYWxzZVxuXHRpZiAodmFsdWVPcHQuY2hvaWNlcy5sZW5ndGggIT09IDIpIHJldHVybiBmYWxzZVxuXHRjb25zdCBsYWJlbHMgPSB2YWx1ZU9wdC5jaG9pY2VzLm1hcCgoYzogYW55KSA9PiBTdHJpbmcoYy5sYWJlbCkudG9Mb3dlckNhc2UoKSlcblx0cmV0dXJuIGxhYmVscy5pbmNsdWRlcygnb2ZmJykgJiYgbGFiZWxzLmluY2x1ZGVzKCdvbicpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBidWlsZEZlZWRiYWNrcygpOiBDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCBmZWVkYmFja3M6IENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbnMgPSB7fVxuXG5cdGZvciAoY29uc3QgW21vZGVsLCBzY2hlbWFdIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYXMpKSB7XG5cdFx0Y29uc3QgY21kU2NoZW1hID0gc2NoZW1hLmNtZFNjaGVtYVxuXHRcdGlmICghQXJyYXkuaXNBcnJheShjbWRTY2hlbWEpKSBjb250aW51ZVxuXG5cdFx0Zm9yIChjb25zdCBzZXR0aW5nIG9mIGNtZFNjaGVtYSkge1xuXHRcdFx0Ly8gU2tpcCB3cml0ZS1vbmx5IGVudHJpZXMgXHUyMDE0IHRoZXkgYXJlIGFjdGlvbi1vbmx5IChkZXZpY2UgbmV2ZXIgcmVwb3J0cyB2YWx1ZSBiYWNrKVxuXHRcdFx0aWYgKHNldHRpbmcud3JpdGVvbmx5ID09PSB0cnVlKSBjb250aW51ZVxuXG5cdFx0XHRjb25zdCBiYXNlRmVlZGJhY2tJZCA9IG1ha2VTZXR0aW5nSWQobW9kZWwsIHNldHRpbmcuY21kX2lkLCBzZXR0aW5nLmlkKVxuXG5cdFx0XHQvLyBCdWlsZCBvcHRpb25zXG5cdFx0XHRjb25zdCBhbGxPcHRpb25zID0gKHNldHRpbmcub3B0aW9ucyA/PyBbXSkubWFwKGJ1aWxkT3B0aW9uKVxuXG5cdFx0XHQvLyBGaWx0ZXIgb3V0ICd2YWx1ZScgb3B0aW9uIGZvciB2YWx1ZSBmZWVkYmFjayAoa2VlcCBvbmx5IGJ1c0NoL2lkQWRkKVxuXHRcdFx0Y29uc3QgdmFsdWVPcHRpb25zID0gYWxsT3B0aW9ucy5maWx0ZXIoKG9wdDogYW55KSA9PiBvcHQuaWQgIT09ICd2YWx1ZScpXG5cblx0XHRcdC8vIEFkZCBhIGNoZWNrYm94IG9wdGlvbiB0byByZXR1cm4gbGFiZWwgaW5zdGVhZCBvZiB2YWx1ZVxuXHRcdFx0Ly8gKG5vdCBhcHBsaWNhYmxlIGZvciBjb2xvcnBpY2tlciBzZXR0aW5ncyBcdTIwMTQgdGhleSBoYXZlIG5vIGRpc2NyZXRlIGNob2ljZXMpXG5cdFx0XHRjb25zdCBpc0NvbG9yU2V0dGluZyA9IHNldHRpbmcub3B0aW9ucz8uc29tZSgobzogYW55KSA9PiBvLmlkID09PSAndmFsdWUnICYmIG8udHlwZSA9PT0gJ2NvbG9ycGlja2VyJylcblx0XHRcdGlmICghaXNDb2xvclNldHRpbmcpIHtcblx0XHRcdFx0dmFsdWVPcHRpb25zLnB1c2goe1xuXHRcdFx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRcdFx0aWQ6ICdzaG93TGFiZWwnLFxuXHRcdFx0XHRcdGxhYmVsOiAnVXNlIExhYmVsIGZvciBWYWx1ZScsXG5cdFx0XHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0XHRcdFx0dG9vbHRpcDogJ1JldHVybiB0aGUgbGFiZWwgdGV4dCBpbnN0ZWFkIG9mIHRoZSBudW1lcmljIHZhbHVlJyxcblx0XHRcdFx0fSlcblx0XHRcdH1cblxuXHRcdFx0Ly8gVmFsdWUgZmVlZGJhY2sgZm9yIGFsbCBzZXR0aW5ncyAoYXBwZWFycyBpbiBWYXJpYWJsZXMgbGlzdClcblx0XHRcdGNvbnN0IHZhbHVlRmVlZGJhY2s6IGFueSA9IHtcblx0XHRcdFx0dHlwZTogJ3ZhbHVlJyxcblx0XHRcdFx0bmFtZTogYFtNb2RlbCR7bW9kZWx9XSAke3NldHRpbmcubmFtZX1gLFxuXHRcdFx0XHRvcHRpb25zOiB2YWx1ZU9wdGlvbnMsXG5cdFx0XHRcdGNhbGxiYWNrOiAoKSA9PiB7XG5cdFx0XHRcdFx0Lyogd2lyZWQgbGF0ZXIgaW4gVXBkYXRlRmVlZGJhY2tzICovXG5cdFx0XHRcdFx0cmV0dXJuIDBcblx0XHRcdFx0fSxcblx0XHRcdH1cblxuXHRcdFx0ZmVlZGJhY2tzW2Jhc2VGZWVkYmFja0lkXSA9IHZhbHVlRmVlZGJhY2tcblxuXHRcdFx0Ly8gQm9vbGVhbiBmZWVkYmFjayBmb3IgT2ZmL09uIGRyb3Bkb3ducyBcdTIwMTQgYWRkaXRpb25hbCBmZWVkYmFjayBmb3IgYnV0dG9uIGNvbG9yaW5nXG5cdFx0XHRpZiAoaXNCb29sZWFuRHJvcGRvd24oc2V0dGluZykpIHtcblx0XHRcdFx0Y29uc3QgYm9vbEZlZWRiYWNrSWQgPSBgJHtiYXNlRmVlZGJhY2tJZH1fYm9vbGBcblxuXHRcdFx0XHQvLyBPcHRpb25zIHdpdGhvdXQgJ3ZhbHVlJyAoYnVzQ2gvaWRBZGQgc2VsZWN0b3JzIG9ubHksIGlmIHByZXNlbnQpXG5cdFx0XHRcdGNvbnN0IGJvb2xPcHRpb25zID0gYWxsT3B0aW9ucy5maWx0ZXIoKG9wdDogYW55KSA9PiBvcHQuaWQgIT09ICd2YWx1ZScpXG5cblx0XHRcdFx0Y29uc3QgYm9vbEZlZWRiYWNrOiBhbnkgPSB7XG5cdFx0XHRcdFx0dHlwZTogJ2Jvb2xlYW4nLFxuXHRcdFx0XHRcdG5hbWU6IGBbTW9kZWwke21vZGVsfV0gJHtzZXR0aW5nLm5hbWV9IFx1MjAxNCBJcyBPbmAsXG5cdFx0XHRcdFx0ZGVmYXVsdFN0eWxlOiB7XG5cdFx0XHRcdFx0XHRiZ2NvbG9yOiBjb21iaW5lUmdiKDAsIDIwMCwgMCksXG5cdFx0XHRcdFx0XHRjb2xvcjogY29tYmluZVJnYigwLCAwLCAwKSxcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdG9wdGlvbnM6IGJvb2xPcHRpb25zLFxuXHRcdFx0XHRcdGNhbGxiYWNrOiAoKSA9PiB7XG5cdFx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVGZWVkYmFja3MgKi9cblx0XHRcdFx0XHRcdHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdH1cblxuXHRcdFx0XHRmZWVkYmFja3NbYm9vbEZlZWRiYWNrSWRdID0gYm9vbEZlZWRiYWNrXG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIGZlZWRiYWNrc1xufVxuIiwgImltcG9ydCBNb2R1bGVJbnN0YW5jZSBmcm9tICcuL21haW4uanMnXG5pbXBvcnQgeyBidWlsZEFjdGlvbnMgfSBmcm9tICcuL2J1aWxkLWNvbW1hbmRzLmpzJ1xuaW1wb3J0IHsgZ2V0RGV2aWNlc0ZvbGRlciwgZ2V0RGV2aWNlU2NoZW1hLCBnZXREZXZpY2VTY2hlbWFzLCByZWxvYWREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBwYXJzZVNldHRpbmdJZCwgZ2V0Tm9ybWFsaXplZFNjaGVtYXMgfSBmcm9tICcuL3R5cGVzLmpzJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5cbmltcG9ydCB7IHBhcnNlR2V0QWxsU2V0dGluZ3NXaXRoRGV0ZWN0aW9uLCBzYXZlTW9kZWxKc29uUHJldHR5LCB1cGRhdGVNb2RlbEpzb25Gcm9tU2V0dGluZ3MgfSBmcm9tICcuL3NldHRpbmdzUGFyc2VyLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ0FjdGlvbnMnKVxuXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlQWN0aW9ucyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRjb25zdCBzY2hlbWFzUmF3ID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdGNvbnN0IHJhd0FjdGlvbnMgPSBidWlsZEFjdGlvbnMoKVxuXHRjb25zdCBzY2hlbWFzID0gZ2V0Tm9ybWFsaXplZFNjaGVtYXMoc2NoZW1hc1Jhdylcblx0Y29uc3Qgd2lyZWRBY3Rpb25zOiBhbnkgPSB7fVxuXG5cdGNvbnN0IGFjdGl2ZU1vZGVsID0gc2VsZi5hY3RpdmVNb2RlbFxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgR0xPQkFMOiBHRVQgQUxMIFNFVFRJTkdTIChBVVRPIEpTT04gVVBEQVRFKSBcdTIwMTQgRGV2IE1vZGUgb25seVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHRpZiAoc2VsZi5jb25maWcuZGV2TW9kZSkge1xuXHRcdHdpcmVkQWN0aW9uc1snZ2xvYmFsX2dldEFsbFNldHRpbmdzJ10gPSB7XG5cdFx0XHRuYW1lOiAnR0xPQkFMOiBHZXQgQWxsIFNldHRpbmdzJyxcblx0XHRcdGRlc2NyaXB0aW9uOiAnVXNlIHRoaXMgdG8gY3JlYXRlIGEgc2NoZW1hIGZvciBhIG5ldyBkZXZpY2UnLFxuXHRcdFx0b3B0aW9uczogW10sXG5cdFx0XHRjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRjb25zdCBtb2RlbCA9IGFjdGl2ZU1vZGVsXG5cdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cblx0XHRcdFx0Y29uc3QgYnVmID0gYXdhaXQgc2VsZi5zdENvbnRyb2xsZXIucmVxdWVzdEFsbFNldHRpbmdzKGlwKVxuXG5cdFx0XHRcdGxldCBtb2RlbEpzb24gPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cblx0XHRcdFx0Y29uc3QgeyBzZXR0aW5nczogcGFyc2VkIH0gPSBwYXJzZUdldEFsbFNldHRpbmdzV2l0aERldGVjdGlvbihtb2RlbCwgYnVmKVxuXHRcdFx0XHRsb2dnZXIuZGVidWcoYHBhcnNlZCByZXBseTogJHtKU09OLnN0cmluZ2lmeShwYXJzZWQpfWApXG5cblx0XHRcdFx0aWYgKCFtb2RlbEpzb24pIHtcblx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgTW9kZWwgJHttb2RlbH0gaGFzIG5vIHNjaGVtYSBcdTIwMTQgY3JlYXRpbmcgbmV3IEpTT04gZnJvbSBzZXR0aW5nc2ApXG5cdFx0XHRcdFx0bW9kZWxKc29uID0ge1xuXHRcdFx0XHRcdFx0bW9kZWwsXG5cdFx0XHRcdFx0XHRjbWRTY2hlbWE6IFtdLFxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXG5cdFx0XHRcdGNvbnN0IHVwZGF0ZWQgPSB1cGRhdGVNb2RlbEpzb25Gcm9tU2V0dGluZ3MobW9kZWxKc29uLCBwYXJzZWQsIHNjaGVtYXMpXG5cdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgbmV3IEFjdGlvbnMganNvbjogJHtKU09OLnN0cmluZ2lmeSh1cGRhdGVkLCBudWxsLCAyKX1gKVxuXG5cdFx0XHRcdGNvbnN0IGRldmljZXNGb2xkZXIgPSBnZXREZXZpY2VzRm9sZGVyKClcblx0XHRcdFx0Y29uc3Qgc2NoZW1hUGF0aCA9IHBhdGguam9pbihkZXZpY2VzRm9sZGVyLCBgTW9kZWwke21vZGVsfS5qc29uYClcblx0XHRcdFx0c2F2ZU1vZGVsSnNvblByZXR0eShzY2hlbWFQYXRoLCB1cGRhdGVkKVxuXG5cdFx0XHRcdHJlbG9hZERldmljZVNjaGVtYXMoKVxuXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBNb2RlbCAke21vZGVsfSBKU09OIGF1dG8tdXBkYXRlZCBmcm9tIGdldEFsbFNldHRpbmdzYClcblx0XHRcdH0sXG5cdFx0fVxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBCVUlMRCBQRVItU0VUVElORyBBQ1RJT05TIChGSUxURVJFRCBCWSBBQ1RJVkUgTU9ERUwpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdGZvciAoY29uc3QgW2FjdGlvbklkLCBhY3Rpb25dIG9mIE9iamVjdC5lbnRyaWVzKHJhd0FjdGlvbnMpKSB7XG5cdFx0Y29uc3QgeyBtb2RlbCwgY21kSWQsIGJhc2VJZCB9ID0gcGFyc2VTZXR0aW5nSWQoYWN0aW9uSWQpXG5cblx0XHQvLyBPbmx5IGluY2x1ZGUgYWN0aW9ucyBmb3IgdGhlIGN1cnJlbnRseSBhY3RpdmUgbW9kZWxcblx0XHRpZiAobW9kZWwgIT09IGFjdGl2ZU1vZGVsKSBjb250aW51ZVxuXG5cdFx0Ly8gR2V0IHRoZSByYXcgYWN0aW9uIHNjaGVtYSB0byBhY2Nlc3MgZml4ZWQgYnVzQ2ggdmFsdWVcblx0XHRjb25zdCBzY2hlbWEgPSBzY2hlbWFzW21vZGVsXVxuXHRcdGNvbnN0IHJhd0FjdGlvbiA9IHNjaGVtYT8uY21kU2NoZW1hPy5maW5kKChhOiBhbnkpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBiYXNlSWQpXG5cblx0XHR3aXJlZEFjdGlvbnNbYWN0aW9uSWRdID0ge1xuXHRcdFx0Li4uYWN0aW9uLFxuXHRcdFx0Y2FsbGJhY2s6IGFzeW5jIChldmVudDogYW55KSA9PiB7XG5cdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZXZlbnQub3B0aW9uc1snYnVzQ2gnXSAhPT0gdW5kZWZpbmVkID8gZXZlbnQub3B0aW9uc1snYnVzQ2gnXSA6IHJhd0FjdGlvbj8uYnVzQ2hcblx0XHRcdFx0Y29uc3QgdmFsdWUgPSBldmVudC5vcHRpb25zWyd2YWx1ZSddXG5cdFx0XHRcdGNvbnN0IGlkQWRkID0gZXZlbnQub3B0aW9uc1snaWRBZGQnXSA/PyAwXG5cdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGJhc2VJZCArIGlkQWRkXG5cblx0XHRcdFx0YXdhaXQgc2VsZi5zdENvbnRyb2xsZXIuc2VuZEF3YWl0QWNrKGNtZElkLCBidXNDaCwgc2V0dGluZ0lkLCB2YWx1ZSwgaXApXG5cdFx0XHR9LFxuXHRcdFx0bGVhcm46IChldmVudDogYW55KSA9PiB7XG5cdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdGNvbnN0IGlkQWRkID0gZXZlbnQub3B0aW9uc1snaWRBZGQnXSA/PyAwXG5cdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGJhc2VJZCArIGlkQWRkXG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZXZlbnQub3B0aW9uc1snYnVzQ2gnXSAhPT0gdW5kZWZpbmVkID8gZXZlbnQub3B0aW9uc1snYnVzQ2gnXSA6IHJhd0FjdGlvbj8uYnVzQ2hcblxuXHRcdFx0XHRjb25zdCBjdXJyZW50ID0gc2VsZi5zdENvbnRyb2xsZXIuZ2V0U2V0dGluZ1ZhbHVlKGlwLCBjbWRJZCwgc2V0dGluZ0lkLCBidXNDaClcblx0XHRcdFx0aWYgKGN1cnJlbnQgPT09IHVuZGVmaW5lZCkgcmV0dXJuIHVuZGVmaW5lZFxuXG5cdFx0XHRcdHJldHVybiB7IC4uLmV2ZW50Lm9wdGlvbnMsIHZhbHVlOiBjdXJyZW50IH1cblx0XHRcdH0sXG5cdFx0fVxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBNSUMgS0lMTCAoT05MWSBJRiBBQ1RJVkUgTU9ERUwgU1VQUE9SVFMgSVQpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHRjb25zdCBhY3RpdmVTY2hlbWEgPSBzY2hlbWFzW2FjdGl2ZU1vZGVsXVxuXHRpZiAoYWN0aXZlU2NoZW1hKSB7XG5cdFx0Y29uc3Qgc3VwcG9ydHNNaWNLaWxsID0gKGFjdGl2ZVNjaGVtYS5jbWRTY2hlbWEgPz8gW10pLnNvbWUoKGE6IGFueSkgPT4gYS5uYW1lLmluY2x1ZGVzKCdLaWxsJykpXG5cblx0XHRpZiAoc3VwcG9ydHNNaWNLaWxsKSB7XG5cdFx0XHRjb25zdCBhY3Rpb25JZCA9IGAke2FjdGl2ZU1vZGVsfV9taWNLaWxsYFxuXG5cdFx0XHR3aXJlZEFjdGlvbnNbYWN0aW9uSWRdID0ge1xuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHthY3RpdmVNb2RlbH1dIE1pYyBLaWxsYCxcblx0XHRcdFx0b3B0aW9uczogW10sXG5cdFx0XHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3Rcblx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgTWljIEtpbGwgXHUyMTkyIE1vZGVsICR7YWN0aXZlTW9kZWx9IEAgJHtpcH1gKVxuXHRcdFx0XHRcdGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLmdsb2JhbE1pY0tpbGwoaXApXG5cdFx0XHRcdFx0YXdhaXQgc2VsZi5zdENvbnRyb2xsZXIucmVxdWVzdEFsbFNldHRpbmdzKGlwKS5jYXRjaCgoZXJyKSA9PiB7XG5cdFx0XHRcdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIHJlZnJlc2ggc2V0dGluZ3MgYWZ0ZXIgY29tbWFuZDogJHtlcnJ9YClcblx0XHRcdFx0XHR9KVxuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdHNlbGYuc2V0QWN0aW9uRGVmaW5pdGlvbnMod2lyZWRBY3Rpb25zKVxufVxuIiwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCB7IGdldERldmljZVNjaGVtYSB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7XG5cdENNRF9NSUNfUFJFLFxuXHRDTURfQlVTX1NFVCxcblx0Q01EX0NIQU5ORUwsXG5cdENNRF9HRVRfQUxMX1NFVFRJTkdTLFxuXHRDTURfTUlDX1BSRV9CVVMsXG5cdENNRF9TRVRUSU5HU19QVVNILFxuXHR0b0hleCxcblx0Ynl0ZXNUb0hleCxcblx0Zm9ybWF0UmdiQ29sb3IsXG5cdG1vZGVsRGlzdGFuY2UsXG59IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignU2V0dGluZ3NQYXJzZXInKVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBUWVBFU1xuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgdHlwZSBQYXJzZWRTZXR0aW5nID0ge1xuXHRjbWRfaWQ6IG51bWJlclxuXHRpZDogbnVtYmVyXG5cdGJ1c0NoPzogbnVtYmVyIC8vIE9wdGlvbmFsOiBvbmx5IHByZXNlbnQgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2ggKDB4MDQsIDB4MTIsIDB4MTQpXG5cdHZhbHVlQnl0ZXM6IG51bWJlcltdXG59XG5cbmV4cG9ydCB0eXBlIFN0QWN0aW9uT3B0aW9uID0ge1xuXHRpZD86IHN0cmluZ1xuXHRsYWJlbDogc3RyaW5nXG5cdHR5cGU6IHN0cmluZ1xuXHRkZWZhdWx0OiB1bmtub3duXG5cdHRvb2x0aXA/OiBzdHJpbmdcblx0Y2hvaWNlcz86IEFycmF5PHsgaWQ6IG51bWJlcjsgbGFiZWw6IHN0cmluZyB9PlxufVxuXG5leHBvcnQgdHlwZSBTdEFjdGlvbiA9IHtcblx0Y21kX2lkOiBudW1iZXJcblx0aWQ6IG51bWJlclxuXHRuYW1lOiBzdHJpbmdcblx0b3B0aW9uczogU3RBY3Rpb25PcHRpb25bXVxuXHRidXNDaD86IG51bWJlciAvLyBGaXhlZCBjaGFubmVsIHZhbHVlIGZvciBhY3Rpb25zIHRoYXQgZG9uJ3QgaGF2ZSBhIGNoYW5uZWwgb3B0aW9uXG5cdHJlYWRvbmx5PzogYm9vbGVhbiAvLyBJZiB0cnVlLCBlbnRyeSBpcyBmZWVkYmFjay1vbmx5IFx1MjAxNCBubyBhY3Rpb24gd2lsbCBiZSBjcmVhdGVkXG5cdHdyaXRlb25seT86IGJvb2xlYW4gLy8gSWYgdHJ1ZSwgZW50cnkgaXMgYWN0aW9uLW9ubHkgXHUyMDE0IG5vIGZlZWRiYWNrIHdpbGwgYmUgY3JlYXRlZCAoZGV2aWNlIG5ldmVyIHJlcG9ydHMgdGhpcyB2YWx1ZSBiYWNrKVxufVxuXG5leHBvcnQgdHlwZSBTdE1vZGVsSnNvbiA9IHtcblx0bW9kZWw6IHN0cmluZ1xuXHR1c2VDb25Nb24/OiBib29sZWFuXG5cdGNtZFNjaGVtYTogU3RBY3Rpb25bXVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBGT1JNQVQgSEVMUEVSU1xuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBnZXRSZ2JJZHMobW9kZWw6IHN0cmluZyk6IFNldDxudW1iZXI+IHtcblx0Y29uc3QgcmdiSWRzID0gbmV3IFNldDxudW1iZXI+KClcblx0dHJ5IHtcblx0XHRjb25zdCBqc29uID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRcdGlmICghanNvbikgcmV0dXJuIHJnYklkc1xuXHRcdGZvciAoY29uc3QgYWN0aW9uIG9mIGpzb24uY21kU2NoZW1hIHx8IFtdKSB7XG5cdFx0XHRjb25zdCBoYXNDb2xvcnBpY2tlciA9IGFjdGlvbi5vcHRpb25zPy5zb21lKChvcHQ6IFN0QWN0aW9uT3B0aW9uKSA9PiBvcHQudHlwZSA9PT0gJ2NvbG9ycGlja2VyJylcblx0XHRcdGlmIChoYXNDb2xvcnBpY2tlcikge1xuXHRcdFx0XHRyZ2JJZHMuYWRkKGFjdGlvbi5pZClcblx0XHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgob3B0OiBTdEFjdGlvbk9wdGlvbikgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRpZiAoaWRBZGRPcHRpb24/LmNob2ljZXMpIHtcblx0XHRcdFx0XHRmb3IgKGNvbnN0IGNob2ljZSBvZiBpZEFkZE9wdGlvbi5jaG9pY2VzKSB7XG5cdFx0XHRcdFx0XHRpZiAodHlwZW9mIGNob2ljZS5pZCA9PT0gJ251bWJlcicpIHtcblx0XHRcdFx0XHRcdFx0cmdiSWRzLmFkZChhY3Rpb24uaWQgKyBjaG9pY2UuaWQpXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHR9IGNhdGNoIChfZXJyKSB7XG5cdFx0Ly8gcmV0dXJuIGVtcHR5IHNldCBvbiBlcnJvclxuXHR9XG5cdHJldHVybiByZ2JJZHNcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgRklORCBUSEUgUkVBTCA1QSBQQVlMT0FEIElOREVYXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIGV4dHJhY3RTdFBheWxvYWRJbmRleChidWY6IEJ1ZmZlcik6IG51bWJlciB7XG5cdGNvbnN0IHNpZ0luZGV4ID0gYnVmLmluZGV4T2YoQnVmZmVyLmZyb20oJ1N0dWRpby1UJykpXG5cdGlmIChzaWdJbmRleCA8IDApIHRocm93IG5ldyBFcnJvcignTm8gU3R1ZGlvLVQgc2lnbmF0dXJlIGluIHBhY2tldCcpXG5cblx0Y29uc3QgcGF5bG9hZEluZGV4ID0gc2lnSW5kZXggKyA4XG5cdGlmIChidWZbcGF5bG9hZEluZGV4XSAhPT0gMHg1YSkge1xuXHRcdHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgMHg1QSBhZnRlciBTdHVkaW8tVCwgZm91bmQgJHtidWZbcGF5bG9hZEluZGV4XS50b1N0cmluZygxNil9YClcblx0fVxuXG5cdHJldHVybiBwYXlsb2FkSW5kZXhcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgU0VDVElPTkVEIFBBUlNFUlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWY6IEJ1ZmZlciwgbW9kZWw6IHN0cmluZyk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcignTm90IGEgZ2V0QWxsU2V0dGluZ3MgcmVwbHknKVxuXHR9XG5cblx0Ly8gQ01EX0dFVF9BTExfU0VUVElOR1MgaGFzIGEgdG90YWwtbGVuZ3RoIGJ5dGUgYXQgaWR4KzIgYmVmb3JlIHRoZSBzZWN0aW9uczsgQ01EX1NFVFRJTkdTX1BVU0ggZG9lcyBub3QuXG5cdGxldCBwID0gY21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTID8gaWR4ICsgMyA6IGlkeCArIDJcblx0Y29uc3QgZW5kID0gYnVmLmxlbmd0aCAtIDFcblx0Y29uc3Qgb3V0OiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXG5cdGNvbnN0IHJnYklkcyA9IGdldFJnYklkcyhtb2RlbClcblxuXHQvLyBDb21tYW5kIElEcyB0aGF0IGluY2x1ZGUgYSBidXNDaCBieXRlIGluIHRoZWlyIHNlY3Rpb24gc3RydWN0dXJlLFxuXHQvLyBmb2xsb3dlZCBieSBhIGRhdGFMZW4gYnl0ZSBhbmQgdGhlbiBpZDp2YWwgcGFpcnMuXG5cdGNvbnN0IGNvbW1hbmRzV2l0aEJ1c0NoID0gW0NNRF9CVVNfU0VULCBDTURfTUlDX1BSRV9CVVMsIENNRF9DSEFOTkVMXVxuXG5cdC8vIENvbW1hbmQgSURzIHRoYXQgaW5jbHVkZSBhIGJ1c0NoIGJ5dGUgYnV0IHN0b3JlIHJhdyBwb3NpdGlvbmFsIHZhbHVlIGJ5dGVzXG5cdC8vIHJhdGhlciB0aGFuIGlkOnZhbCBwYWlycyAobm8gZGF0YUxlbiBieXRlLCBubyBzZXR0aW5nIElEcykuXG5cdC8vIEZvcm1hdDogW2NtZExlbl0gW2NtZElkXSBbYnVzQ2hdIFt2YWwwXSBbdmFsMV0gLi4uXG5cdGNvbnN0IGNvbW1hbmRzUmF3VmFsdWUgPSBbQ01EX01JQ19QUkVdIC8vIGNtZD0weDAyXG5cblx0d2hpbGUgKHAgKyAyIDwgZW5kKSB7XG5cdFx0Y29uc3QgY21kTGVuID0gYnVmW3BdXG5cdFx0Y29uc3Qgc2VjdGlvbkNtZElkID0gYnVmW3AgKyAxXVxuXG5cdFx0Y29uc3Qgc2VjdGlvbkVuZCA9IHAgKyAxICsgY21kTGVuXG5cdFx0aWYgKHNlY3Rpb25FbmQgPiBlbmQpIGJyZWFrXG5cblx0XHRjb25zdCBoYXNCdXNDaCA9IGNvbW1hbmRzV2l0aEJ1c0NoLmluY2x1ZGVzKHNlY3Rpb25DbWRJZClcblx0XHRjb25zdCBpc1Jhd1ZhbHVlID0gY29tbWFuZHNSYXdWYWx1ZS5pbmNsdWRlcyhzZWN0aW9uQ21kSWQpXG5cblx0XHRsZXQgYnVzQ2g6IG51bWJlciB8IHVuZGVmaW5lZFxuXHRcdGxldCBkYXRhTGVuOiBudW1iZXJcblx0XHRsZXQgcTogbnVtYmVyXG5cblx0XHRpZiAoaXNSYXdWYWx1ZSkge1xuXHRcdFx0Ly8gU3RydWN0dXJlOiBbY21kTGVuXSBbY21kSWRdIFtidXNDaF0gW3ZhbDBdIFt2YWwxXSAuLi5cblx0XHRcdC8vIEJ1aWxkIHBvc2l0aW9uYWwgbWFwIGZyb20gc2NoZW1hOiBmaW5kIGFsbCBlbnRyaWVzIGZvciBDTURfTUlDX1BSRSAoMHgwMikgb3Jcblx0XHRcdC8vIENNRF9NSUNfUFJFX0JVUyAoMHgxMikgd2l0aCBhIGZpeGVkIGJ1c0NoLCBzb3J0ZWQgYnkgaWQgXHUyMDE0IGVhY2ggYmVjb21lcyBvbmVcblx0XHRcdC8vIHBvc2l0aW9uYWwgc2xvdC4gVGhpcyBtYWtlcyB0aGUgcmVtYXAgc2NoZW1hLWRyaXZlbjpcblx0XHRcdC8vICAgMjE0ICAoY21kX2lkPTIsICBpZD0wLzEpIFx1MjE5MiBwb3MwXHUyMTkyKDIsMCksICBwb3MxXHUyMTkyKDIsMSlcblx0XHRcdC8vICAgMjE0QSAoY21kX2lkPTE4LCBpZD0xLzIpIFx1MjE5MiBwb3MwXHUyMTkyKDE4LDEpLCBwb3MxXHUyMTkyKDE4LDIpXG5cdFx0XHQvLyBQb3NpdGlvbnMgd2l0aCBubyBzY2hlbWEgZW50cnkgYXJlIGRyb3BwZWQgKGUuZy4gdW5rbm93biAzcmQgYnl0ZSkuXG5cdFx0XHRidXNDaCA9IGJ1ZltwICsgMl1cblx0XHRcdGNvbnN0IHJhd0J5dGVzID0gYnVmLnN1YmFycmF5KHAgKyAzLCBzZWN0aW9uRW5kKVxuXG5cdFx0XHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdFx0XHRjb25zdCBtaWNQcmVFbnRyaWVzID0gKHNjaGVtYT8uY21kU2NoZW1hID8/IFtdKVxuXHRcdFx0XHQuZmlsdGVyKChhOiBTdEFjdGlvbikgPT4gKGEuY21kX2lkID09PSBDTURfTUlDX1BSRSB8fCBhLmNtZF9pZCA9PT0gQ01EX01JQ19QUkVfQlVTKSAmJiBhLmJ1c0NoICE9PSB1bmRlZmluZWQpXG5cdFx0XHRcdC5zb3J0KChhOiBTdEFjdGlvbiwgYjogU3RBY3Rpb24pID0+IGEuaWQgLSBiLmlkKVxuXG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IHJhd0J5dGVzLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRcdGNvbnN0IGVudHJ5ID0gbWljUHJlRW50cmllc1tpXVxuXHRcdFx0XHRpZiAoZW50cnkpIHtcblx0XHRcdFx0XHRvdXQucHVzaCh7IGNtZF9pZDogZW50cnkuY21kX2lkLCBpZDogZW50cnkuaWQsIGJ1c0NoLCB2YWx1ZUJ5dGVzOiBbcmF3Qnl0ZXNbaV1dIH0pXG5cdFx0XHRcdH1cblx0XHRcdFx0Ly8gbm8gZW50cnkgPSB1bmtub3duIHBvc2l0aW9uYWwgYnl0ZSwgZHJvcCBpdFxuXHRcdFx0fVxuXHRcdFx0cCA9IHNlY3Rpb25FbmRcblx0XHRcdGNvbnRpbnVlXG5cdFx0fSBlbHNlIGlmIChoYXNCdXNDaCkge1xuXHRcdFx0Ly8gU3RydWN0dXJlOiBbY21kTGVuXSBbY21kSWRdIFtidXNDaF0gW2RhdGFMZW5dIFtpZDp2YWwgcGFpcnNdXG5cdFx0XHRidXNDaCA9IGJ1ZltwICsgMl1cblx0XHRcdGRhdGFMZW4gPSBidWZbcCArIDNdXG5cdFx0XHRxID0gcCArIDRcblx0XHR9IGVsc2Uge1xuXHRcdFx0Ly8gU3RydWN0dXJlOiBbY21kTGVuXSBbY21kSWRdIFtkYXRhTGVuXSBbaWQ6dmFsIHBhaXJzXVxuXHRcdFx0ZGF0YUxlbiA9IGJ1ZltwICsgMl1cblx0XHRcdHEgPSBwICsgM1xuXHRcdH1cblxuXHRcdGNvbnN0IHFFbmQgPSBxICsgZGF0YUxlblxuXHRcdGNvbnN0IHFTdGFydCA9IHFcblxuXHRcdHdoaWxlIChxICsgMSA8IHFFbmQpIHtcblx0XHRcdGNvbnN0IGlkID0gYnVmW3FdXG5cdFx0XHRsZXQgdmFsdWVCeXRlczogbnVtYmVyW11cblxuXHRcdFx0Ly8gQ2hlY2sgaWYgdGhpcyBJRCBpcyBhbiBSR0IgY29sb3JwaWNrZXIgKG5lZWRzIDMgYnl0ZXMpXG5cdFx0XHRpZiAocmdiSWRzLmhhcyhpZCkgJiYgcSArIDMgPCBxRW5kKSB7XG5cdFx0XHRcdHZhbHVlQnl0ZXMgPSBbYnVmW3EgKyAxXSwgYnVmW3EgKyAyXSwgYnVmW3EgKyAzXV1cblx0XHRcdFx0cSArPSA0XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHR2YWx1ZUJ5dGVzID0gW2J1ZltxICsgMV1dXG5cdFx0XHRcdHEgKz0gMlxuXHRcdFx0fVxuXG5cdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0ge1xuXHRcdFx0XHRjbWRfaWQ6IHNlY3Rpb25DbWRJZCxcblx0XHRcdFx0aWQsXG5cdFx0XHRcdHZhbHVlQnl0ZXMsXG5cdFx0XHR9XG5cdFx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRzZXR0aW5nLmJ1c0NoID0gYnVzQ2hcblx0XHRcdH1cblx0XHRcdG91dC5wdXNoKHNldHRpbmcpXG5cdFx0fVxuXG5cdFx0Ly8gUG9zaXRpb25hbCBmYWxsYmFjazogaWYgdGhlIGJ5dGUgd2UgcmVhZCBhcyBkYXRhTGVuIHdhcyAweDAwIGJ1dCB0aGUgc2VjdGlvblxuXHRcdC8vIHN0aWxsIGNvbnRhaW5zIGRhdGEgYnl0ZXMsIHRoaXMgc2VjdGlvbiBsaWtlbHkgdXNlcyBhIG5vLWRhdGFMZW4gZm9ybWF0IHdoZXJlXG5cdFx0Ly8gZWFjaCBieXRlIGFmdGVyIGNtZElkIGlzIGEgcmF3IHZhbHVlIGF0IGEgZml4ZWQgcG9zaXRpb24gKHBvc2l0aW9uID0gaWQpLlxuXHRcdC8vIFJlLXBhcnNlIGZyb20gcCsyIChyaWdodCBhZnRlciBjbWRJZCksIHRyZWF0aW5nIHRoZSBcImRhdGFMZW5cIiBieXRlIGFzIGlkPTAuXG5cdFx0Ly8gT25seSBmaXJlIGlmIG5vIGJ5dGVzIHdlcmUgY29uc3VtZWQgYnkgdGhlIG1haW4gbG9vcCAocSA9PT0gcVN0YXJ0KSwgdG8gYXZvaWRcblx0XHQvLyByZS1wYXJzaW5nIGJ5dGVzIHRoYXQgd2VyZSBhbHJlYWR5IHN1Y2Nlc3NmdWxseSBwYXJzZWQuXG5cdFx0aWYgKHEgPT09IHFTdGFydCAmJiBzZWN0aW9uRW5kID4gcCArIDMpIHtcblx0XHRcdGxldCBwb3MgPSBoYXNCdXNDaCA/IHAgKyAzIDogcCArIDIgLy8gc2tpcCBjbWRJZCAoYW5kIGJ1c0NoIGlmIHByZXNlbnQpXG5cdFx0XHRsZXQgcG9zSWQgPSAwXG5cdFx0XHR3aGlsZSAocG9zIDwgc2VjdGlvbkVuZCkge1xuXHRcdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0geyBjbWRfaWQ6IHNlY3Rpb25DbWRJZCwgaWQ6IHBvc0lkKyssIHZhbHVlQnl0ZXM6IFtidWZbcG9zKytdXSB9XG5cdFx0XHRcdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSBzZXR0aW5nLmJ1c0NoID0gYnVzQ2hcblx0XHRcdFx0b3V0LnB1c2goc2V0dGluZylcblx0XHRcdH1cblx0XHR9XG5cblx0XHRwID0gc2VjdGlvbkVuZFxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBHRU5FUklDIFNFVFRJTkdTIFJFU1BPTlNFIFBBUlNFUiAoMHgwYSBnZXQtYWxsICsgMHgwYiB1bnNvbGljaXRlZCBwdXNoKVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIFBhcnNlcyBhbnkgZnVsbCBzZXR0aW5ncyBibG9jayByZWdhcmRsZXNzIG9mIHdoZXRoZXIgdGhlIGNtZElkIGlzIDB4MGFcbiAqIChyZXNwb25zZSB0byBHZXQgQWxsIFNldHRpbmdzKSBvciAweDBiICh1bnNvbGljaXRlZCBwdXNoIGFmdGVyIGEgc2V0KS5cbiAqIEJvdGggdXNlIHRoZSBzYW1lIHNlY3Rpb25lZCBvciBmbGF0IGJsb2NrIGxheW91dC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlU2V0dGluZ3NSZXNwb25zZShtb2RlbDogc3RyaW5nLCBidWY6IEJ1ZmZlcik6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcihgTm90IGEgc2V0dGluZ3MgYmxvY2sgKGNtZElkPTB4JHtjbWRJZC50b1N0cmluZygxNil9KWApXG5cdH1cblx0cmV0dXJuIHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpXG59XG5cbi8qKlxuICogRm9ybWF0cyBhIHNpbmdsZSBwYXJzZWQgc2V0dGluZyBpbnRvIGEgaHVtYW4tcmVhZGFibGUgc3RyaW5nIHVzaW5nIGFjdGlvblxuICogZGVmaW5pdGlvbnMgZnJvbSB0aGUgZGV2aWNlIEpTT04uIEZhbGxzIGJhY2sgdG8gaGV4IElEcyB3aGVuIHVua25vd24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRQYXJzZWRTZXR0aW5nKHNldHRpbmc6IFBhcnNlZFNldHRpbmcsIGFjdGlvbnM6IFN0QWN0aW9uW10pOiBzdHJpbmcge1xuXHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0bGV0IGFjdGlvbiA9IGFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IHNldHRpbmcuY21kX2lkICYmIGEuaWQgPT09IHNldHRpbmcuaWQpXG5cblx0Ly8gSWYgbm8gZXhhY3QgbWF0Y2ggYW5kIGlkID4gYmFzZSBpZCwgdHJ5IHRvIGZpbmQgYWN0aW9uIHdpdGggaWRBZGQgb3B0aW9uXG5cdC8vIFRoaXMgaGFuZGxlcyBjYXNlcyBsaWtlIENNRF9IRUFEUEhPTkUgKDB4MDUsIGUuZy4gUGhvbmVzIFJvdXRpbmcpIGFuZFxuXHQvLyBDTURfQlVUVE9OX01PREUgKDB4MDcsIGUuZy4gQnV0dG9ucykgd2hlcmUgaWQgMC0zIHJlcHJlc2VudHMgY2hhbm5lbHMgMS00XG5cdGlmICghYWN0aW9uKSB7XG5cdFx0Y29uc3QgYmFzZUFjdGlvbiA9IGFjdGlvbnMuZmluZCgoYSkgPT4ge1xuXHRcdFx0aWYgKGEuY21kX2lkICE9PSBzZXR0aW5nLmNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiB0aGlzIGFjdGlvbiBoYXMgYW4gaWRBZGQgb3B0aW9uIChpbmRpY2F0aW5nIGNoYW5uZWwgc2VsZWN0aW9uKVxuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdGlvbj8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiB0aGUgc2V0dGluZy5pZCBvZmZzZXQgbWF0Y2hlcyBvbmUgb2YgdGhlIGlkQWRkIGNob2ljZSBJRHNcblx0XHRcdGNvbnN0IGNoYW5uZWxPZmZzZXQgPSBzZXR0aW5nLmlkIC0gYS5pZFxuXHRcdFx0cmV0dXJuIGlkQWRkT3B0aW9uLmNob2ljZXMuc29tZSgoYykgPT4gYy5pZCA9PT0gY2hhbm5lbE9mZnNldClcblx0XHR9KVxuXHRcdGlmIChiYXNlQWN0aW9uKSB7XG5cdFx0XHRhY3Rpb24gPSBiYXNlQWN0aW9uXG5cdFx0fVxuXHR9XG5cblx0Y29uc3QgY21kSGV4ID0gdG9IZXgoc2V0dGluZy5jbWRfaWQpXG5cdGNvbnN0IGlkSGV4ID0gdG9IZXgoc2V0dGluZy5pZClcblx0Y29uc3QgdmFsSGV4ID0gYnl0ZXNUb0hleChzZXR0aW5nLnZhbHVlQnl0ZXMpXG5cdGNvbnN0IHZhbERlYyA9XG5cdFx0c2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gM1xuXHRcdFx0PyBmb3JtYXRSZ2JDb2xvcihzZXR0aW5nLnZhbHVlQnl0ZXNbMF0sIHNldHRpbmcudmFsdWVCeXRlc1sxXSwgc2V0dGluZy52YWx1ZUJ5dGVzWzJdKVxuXHRcdFx0OiBzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAxXG5cdFx0XHRcdD8gc2V0dGluZy52YWx1ZUJ5dGVzWzBdXG5cdFx0XHRcdDogc2V0dGluZy52YWx1ZUJ5dGVzLmpvaW4oJywnKVxuXG5cdC8vIEJ1aWxkIHRoZSBwcmVmaXg6IGNtZDoweDEyIGNoOjAgaWQ6MHgwMSB2YWw6MHgxNCAoY2ggb25seSBmb3IgY29tbWFuZHMgd2l0aCBidXNDaClcblx0Y29uc3QgYnVzQ2hTdHIgPSBzZXR0aW5nLmJ1c0NoICE9PSB1bmRlZmluZWQgPyBgIGNoOiR7c2V0dGluZy5idXNDaH1gIDogJydcblx0Y29uc3QgcHJlZml4ID0gYGNtZDoke2NtZEhleH0ke2J1c0NoU3RyfSBpZDoke2lkSGV4fSB2YWw6JHt2YWxIZXh9YFxuXG5cdC8vIElmIHdlIGhhdmUgYW4gYWN0aW9uIHdpdGggYSBuYW1lIGFuZCBjaG9pY2UgbGFiZWwsIHVzZSBpdFxuXHRpZiAoYWN0aW9uKSB7XG5cdFx0bGV0IG5hbWUgPSBhY3Rpb24ubmFtZVxuXG5cdFx0Ly8gSWYgc2V0dGluZyBoYXMgYnVzQ2gsIGFkZCBjaGFubmVsIGluZm8gdG8gbmFtZVxuXHRcdGlmIChzZXR0aW5nLmJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdG5hbWUgPSBgJHtuYW1lfSBDaCR7c2V0dGluZy5idXNDaCArIDF9YFxuXHRcdH1cblx0XHQvLyBPdGhlcndpc2UsIGlmIHRoaXMgYWN0aW9uIGhhcyBpZEFkZCwgaW5jbHVkZSB0aGUgaWRBZGQgbGFiZWxcblx0XHRlbHNlIHtcblx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKGlkQWRkT3B0aW9uPy5jaG9pY2VzKSB7XG5cdFx0XHRcdGNvbnN0IGNoYW5uZWxPZmZzZXQgPSBzZXR0aW5nLmlkIC0gYWN0aW9uLmlkXG5cdFx0XHRcdGNvbnN0IGlkQWRkQ2hvaWNlID0gaWRBZGRPcHRpb24uY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSBjaGFubmVsT2Zmc2V0KVxuXHRcdFx0XHRpZiAoaWRBZGRDaG9pY2UpIHtcblx0XHRcdFx0XHRuYW1lID0gYCR7bmFtZX0gJHtpZEFkZENob2ljZS5sYWJlbH1gXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBMb29rIGZvciB0aGUgdmFsdWUgb3B0aW9uIChub3QgYnVzQ2ggb3IgaWRBZGQpXG5cdFx0Y29uc3QgdmFsdWVPcHRpb24gPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgob3B0KSA9PiBvcHQuaWQgPT09ICd2YWx1ZScpXG5cdFx0aWYgKHZhbHVlT3B0aW9uPy5jaG9pY2VzICYmIHNldHRpbmcudmFsdWVCeXRlcy5sZW5ndGggPT09IDEpIHtcblx0XHRcdGNvbnN0IGNob2ljZSA9IHZhbHVlT3B0aW9uLmNob2ljZXMuZmluZCgoYykgPT4gYy5pZCA9PT0gc2V0dGluZy52YWx1ZUJ5dGVzWzBdKVxuXHRcdFx0aWYgKGNob2ljZSkge1xuXHRcdFx0XHRyZXR1cm4gYCR7cHJlZml4fSB8ICR7bmFtZX06ICR7Y2hvaWNlLmxhYmVsfSAoJHt2YWxEZWN9KWBcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIGAke3ByZWZpeH0gfCAke25hbWV9OiAke3ZhbERlY31gXG5cdH1cblxuXHQvLyBObyBhY3Rpb24gZm91bmQgLSBqdXN0IHNob3cgdGhlIHJhdyB2YWx1ZXNcblx0cmV0dXJuIGAke3ByZWZpeH0gfCBVbmtub3duIFNldHRpbmdgXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFBBUlNFUiBESVNQQVRDSCBXSVRIIEFVVE8tREVURUNUSU9OXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbi8qKlxuICogUGFyc2VzIGdldEFsbFNldHRpbmdzIHJlc3BvbnNlIHdpdGggYXV0b21hdGljIGZvcm1hdCBkZXRlY3Rpb24uXG4gKlxuICogQHJldHVybnMge3NldHRpbmdzOiBQYXJzZWRTZXR0aW5nW10sIGRldGVjdGVkU2VjdGlvbmVkOiBib29sZWFuIHwgbnVsbH1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3NXaXRoRGV0ZWN0aW9uKFxuXHRtb2RlbDogc3RyaW5nLFxuXHRidWY6IEJ1ZmZlcixcbik6IHsgc2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXTsgZGV0ZWN0ZWRTZWN0aW9uZWQ6IG51bGwgfSB7XG5cdGNvbnN0IHNldHRpbmdzID0gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbClcblx0cmV0dXJuIHsgc2V0dGluZ3MsIGRldGVjdGVkU2VjdGlvbmVkOiBudWxsIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbChtb2RlbDogc3RyaW5nLCBidWY6IEJ1ZmZlcik6IFBhcnNlZFNldHRpbmdbXSB7XG5cdHJldHVybiBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWYsIG1vZGVsKVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBWQUxVRSBcdTIxOTIgT1BUSU9OXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIHZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzOiBudW1iZXJbXSk6IFN0QWN0aW9uT3B0aW9uIHtcblx0aWYgKHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxKSB7XG5cdFx0cmV0dXJuIHsgaWQ6ICd2YWx1ZScsIGxhYmVsOiAnVmFsdWUnLCB0eXBlOiAnbnVtYmVyJywgZGVmYXVsdDogdmFsdWVCeXRlc1swXSB9XG5cdH1cblxuXHRpZiAodmFsdWVCeXRlcy5sZW5ndGggPT09IDMpIHtcblx0XHRjb25zdCBbciwgZywgYl0gPSB2YWx1ZUJ5dGVzXG5cdFx0cmV0dXJuIHtcblx0XHRcdGlkOiAndmFsdWUnLFxuXHRcdFx0bGFiZWw6ICdDb2xvcicsXG5cdFx0XHR0eXBlOiAnY29sb3JwaWNrZXInLFxuXHRcdFx0ZGVmYXVsdDogZm9ybWF0UmdiQ29sb3IociwgZywgYiksXG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIHsgaWQ6ICd2YWx1ZScsIGxhYmVsOiAnVmFsdWUnLCB0eXBlOiAncmF3JywgZGVmYXVsdDogWy4uLnZhbHVlQnl0ZXNdIH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgU01BUlQgSlNPTiBVUERBVEVcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZU1vZGVsSnNvbkZyb21TZXR0aW5ncyhcblx0bW9kZWxKc29uOiBTdE1vZGVsSnNvbixcblx0cGFyc2VkOiBQYXJzZWRTZXR0aW5nW10sXG5cdGFsbE1vZGVsczogUmVjb3JkPHN0cmluZywgU3RNb2RlbEpzb24+LFxuKTogU3RNb2RlbEpzb24ge1xuXHRjb25zdCBvdXQgPSBzdHJ1Y3R1cmVkQ2xvbmUobW9kZWxKc29uKVxuXG5cdC8vIEVuc3VyZSBjbWRTY2hlbWEgYXJyYXkgZXhpc3RzXG5cdGlmICghb3V0LmNtZFNjaGVtYSkge1xuXHRcdG91dC5jbWRTY2hlbWEgPSBbXVxuXHR9XG5cblx0Ly8gU29ydCBvdGhlciBtb2RlbHMgYnkgbnVtZXJpYyBkaXN0YW5jZSB0byBjdXJyZW50IG1vZGVsXG5cdGNvbnN0IGNhbmRpZGF0ZXMgPSBPYmplY3QudmFsdWVzKGFsbE1vZGVscylcblx0XHQuZmlsdGVyKChtKSA9PiBtLm1vZGVsICE9PSBtb2RlbEpzb24ubW9kZWwpIC8vIGV4Y2x1ZGUgc2VsZlxuXHRcdC5zb3J0KChhLCBiKSA9PiBtb2RlbERpc3RhbmNlKG1vZGVsSnNvbi5tb2RlbCwgYS5tb2RlbCkgLSBtb2RlbERpc3RhbmNlKG1vZGVsSnNvbi5tb2RlbCwgYi5tb2RlbCkpXG5cblx0bG9nZ2VyLmluZm8oYFVwZGF0aW5nIG1vZGVsOiAke21vZGVsSnNvbi5tb2RlbH1gKVxuXHRsb2dnZXIuZGVidWcoYENhbmRpZGF0ZXMgZm9yIGluZmVyZW5jZTogJHtjYW5kaWRhdGVzLm1hcCgoYykgPT4gYy5tb2RlbCkuam9pbignLCAnKX1gKVxuXG5cdC8vIFByZS1zY2FuOiBmb3IgZWFjaCBjYW5kaWRhdGUgaWRBZGQgYmFzZSBlbnRyeSwgZmluZCB0aGUgbWF4aW11bSBzZXF1ZW50aWFsXG5cdC8vIG9mZnNldCB0aGUgcGFja2V0IGNvbnRhaW5zIChldmVuIGJleW9uZCB3aGF0IHRoZSByZWZlcmVuY2UgbW9kZWwga25vd3MpLlxuXHQvLyBLZXk6IGAke2NtZF9pZH1fJHtiYXNlX2lkfWAsIHZhbHVlOiBtYXggc2VxdWVudGlhbCBvZmZzZXQgc2VlbiBpbiBwYXJzZWQgZGF0YS5cblx0Y29uc3QgaWRBZGREZWZlclJhbmdlcyA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KClcblx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRmb3IgKGNvbnN0IGJhc2VFbnRyeSBvZiBjLmNtZFNjaGVtYSA/PyBbXSkge1xuXHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBiYXNlRW50cnkub3B0aW9ucz8uZmluZCgobzogYW55KSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdD8uY2hvaWNlcykgY29udGludWVcblx0XHRcdGNvbnN0IGJhc2VJZCA9IGJhc2VFbnRyeS5pZFxuXHRcdFx0Y29uc3QgY21kSWQgPSBiYXNlRW50cnkuY21kX2lkXG5cdFx0XHRjb25zdCBrZXkgPSBgJHtjbWRJZH1fJHtiYXNlSWR9YFxuXHRcdFx0aWYgKGlkQWRkRGVmZXJSYW5nZXMuaGFzKGtleSkpIGNvbnRpbnVlXG5cdFx0XHQvLyBGaW5kIHRoZSBtYXggc2VxdWVudGlhbCBvZmZzZXQgcHJlc2VudCBpbiB0aGUgcGFyc2VkIHBhY2tldCBmb3IgdGhpcyBiYXNlXG5cdFx0XHRjb25zdCBwYXJzZWRPZmZzZXRzID0gcGFyc2VkXG5cdFx0XHRcdC5maWx0ZXIoKHApID0+IHAuY21kX2lkID09PSBjbWRJZCAmJiBwLmlkID4gYmFzZUlkKVxuXHRcdFx0XHQubWFwKChwKSA9PiBwLmlkIC0gYmFzZUlkKVxuXHRcdFx0XHQuc29ydCgoYSwgYikgPT4gYSAtIGIpXG5cdFx0XHQvLyBXYWxrIGZyb20gMSB1cHdhcmQgXHUyMDE0IHN0b3AgYXQgZmlyc3QgZ2FwXG5cdFx0XHRsZXQgbWF4U2VxID0gMFxuXHRcdFx0Zm9yIChjb25zdCBvZmYgb2YgcGFyc2VkT2Zmc2V0cykge1xuXHRcdFx0XHRpZiAob2ZmID09PSBtYXhTZXEgKyAxKSBtYXhTZXEgPSBvZmZcblx0XHRcdFx0ZWxzZSBpZiAob2ZmID4gbWF4U2VxICsgMSkgYnJlYWtcblx0XHRcdH1cblx0XHRcdGlmIChtYXhTZXEgPiAwKSB7XG5cdFx0XHRcdGlkQWRkRGVmZXJSYW5nZXMuc2V0KGtleSwgbWF4U2VxKVxuXHRcdFx0XHRsb2dnZXIuZGVidWcoYGlkQWRkIGRlZmVyIHJhbmdlIGZvciBjbWRfaWQ9JHt0b0hleChjbWRJZCl9IGJhc2VfaWQ9JHt0b0hleChiYXNlSWQpfTogb2Zmc2V0cyAxXHUyMDEzJHttYXhTZXF9YClcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHQvLyBQcmUtY29tcHV0ZSB0aGUgc2V0IG9mIGFsbCBidXNDaCB2YWx1ZXMgc2VlbiBwZXIgKGNtZF9pZCwgaWQpIHBhaXIgYWNyb3NzIHRoZSBmdWxsXG5cdC8vIHBhcnNlZCByZXNwb25zZSBcdTIwMTQgdXNlZCBsYXRlciB0byBkZWNpZGUgZml4ZWQgdnMuIHNlbGVjdGFibGUgYnVzQ2guXG5cdGNvbnN0IGJ1c0NoU2VlbiA9IG5ldyBNYXA8c3RyaW5nLCBTZXQ8bnVtYmVyPj4oKVxuXHRmb3IgKGNvbnN0IHsgY21kX2lkLCBpZCwgYnVzQ2ggfSBvZiBwYXJzZWQpIHtcblx0XHRpZiAoYnVzQ2ggPT09IHVuZGVmaW5lZCkgY29udGludWVcblx0XHRjb25zdCBrZXkgPSBgJHtjbWRfaWR9XyR7aWR9YFxuXHRcdGlmICghYnVzQ2hTZWVuLmhhcyhrZXkpKSBidXNDaFNlZW4uc2V0KGtleSwgbmV3IFNldCgpKVxuXHRcdGJ1c0NoU2Vlbi5nZXQoa2V5KSEuYWRkKGJ1c0NoKVxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBQQVNTIDE6IHJlc29sdmUgZWFjaCBwYXJzZWQgZW50cnkgXHUyMDE0IGV4YWN0IG1hdGNoLCBpbmZlcnJlZCxcblx0Ly8gaWRBZGQtZm9sZCAob2Zmc2V0IGludG8gYW4gYWxyZWFkeS1hZGRlZCBiYXNlIGVudHJ5KSwgb3IgdW5rbm93blxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdGZvciAoY29uc3QgeyBjbWRfaWQsIGlkLCBidXNDaCwgdmFsdWVCeXRlcyB9IG9mIHBhcnNlZCkge1xuXHRcdC8vIDFhLiBFeGFjdCBtYXRjaCBhbHJlYWR5IGluIG91dHB1dCBzY2hlbWEgXHUyMDE0IHJlZnJlc2ggdGhlIGRlZmF1bHQgYW5kIHN5bmMgYnVzQ2hcblx0XHRjb25zdCBleGlzdGluZ0V4YWN0ID0gb3V0LmNtZFNjaGVtYS5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXHRcdGlmIChleGlzdGluZ0V4YWN0KSB7XG5cdFx0XHRjb25zdCBvcHQgPSBleGlzdGluZ0V4YWN0Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICd2YWx1ZScpXG5cdFx0XHRpZiAob3B0KSBvcHQuZGVmYXVsdCA9IHZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzKS5kZWZhdWx0XG5cblx0XHRcdC8vIFN5bmMgYnVzQ2ggZnJvbSBwYWNrZXQgZGF0YSBpZiB0aGUgZXhpc3RpbmcgZW50cnkgaXMgbWlzc2luZyBpdFxuXHRcdFx0Y29uc3Qgc2VlbkJ1c0NoVmFsdWVzID0gYnVzQ2hTZWVuLmdldChgJHtjbWRfaWR9XyR7aWR9YClcblx0XHRcdGlmIChzZWVuQnVzQ2hWYWx1ZXMgJiYgc2VlbkJ1c0NoVmFsdWVzLnNpemUgPiAwKSB7XG5cdFx0XHRcdGNvbnN0IG1heEJ1c0NoID0gTWF0aC5tYXgoLi4uc2VlbkJ1c0NoVmFsdWVzKVxuXHRcdFx0XHRjb25zdCBoYXNCdXNDaE9wdGlvbiA9IGV4aXN0aW5nRXhhY3Qub3B0aW9ucz8uc29tZSgobykgPT4gby5pZCA9PT0gJ2J1c0NoJylcblx0XHRcdFx0aWYgKG1heEJ1c0NoID09PSAwICYmIGV4aXN0aW5nRXhhY3QuYnVzQ2ggPT09IHVuZGVmaW5lZCAmJiAhaGFzQnVzQ2hPcHRpb24pIHtcblx0XHRcdFx0XHRleGlzdGluZ0V4YWN0LmJ1c0NoID0gMFxuXHRcdFx0XHRcdGxvZ2dlci5pbmZvKGBTeW5jZWQgYnVzQ2g9MCBvbnRvIGV4aXN0aW5nIGVudHJ5IGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfWApXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGNvbnRpbnVlXG5cdFx0fVxuXG5cdFx0Ly8gMWIuIENoZWNrIGlmIHRoaXMgaWQgZm9sZHMgaW50byBhbiBhbHJlYWR5LWFkZGVkIGJhc2UgZW50cnkgdmlhIGlkQWRkLlxuXHRcdC8vICAgICBHYXRlOiB0aGUgb2Zmc2V0IG11c3QgYWN0dWFsbHkgZXhpc3QgaW4gdGhlIHJlZmVyZW5jZSBtb2RlbCdzIGlkQWRkIGNob2ljZXNcblx0XHQvLyAgICAgdG8gYXZvaWQgc3dhbGxvd2luZyB1bnJlbGF0ZWQgc2FtZS1jbWRfaWQgZW50cmllcyAoZS5nLiBTaWRldG9uZSBhdCBpZD0yMSkuXG5cdFx0Y29uc3QgaWRBZGRCYXNlID0gb3V0LmNtZFNjaGVtYS5maW5kKChhKSA9PiB7XG5cdFx0XHRpZiAoYS5jbWRfaWQgIT09IGNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBpZEFkZE9wdCA9IGEub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmICghaWRBZGRPcHQ/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0aWYgKGlkIDw9IGEuaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3Qgb2Zmc2V0ID0gaWQgLSBhLmlkXG5cdFx0XHQvLyBPbmx5IGZvbGQgaWYgYSByZWZlcmVuY2UgbW9kZWwgZXhwbGljaXRseSBsaXN0cyB0aGlzIG9mZnNldCBpbiBpdHMgaWRBZGQgY2hvaWNlc1xuXHRcdFx0cmV0dXJuIGNhbmRpZGF0ZXMuc29tZSgoYykgPT4ge1xuXHRcdFx0XHRjb25zdCByZWZFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChyKSA9PiByLmNtZF9pZCA9PT0gY21kX2lkICYmIHIuaWQgPT09IGEuaWQpXG5cdFx0XHRcdGNvbnN0IHJlZklkQWRkID0gcmVmRW50cnk/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdHJldHVybiByZWZJZEFkZD8uY2hvaWNlcz8uc29tZSgoY2g6IGFueSkgPT4gY2guaWQgPT09IG9mZnNldClcblx0XHRcdH0pXG5cdFx0fSlcblx0XHRpZiAoaWRBZGRCYXNlKSB7XG5cdFx0XHRjb25zdCBvZmZzZXQgPSBpZCAtIGlkQWRkQmFzZS5pZFxuXHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBpZEFkZEJhc2Uub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmIChpZEFkZE9wdD8uY2hvaWNlcyAmJiAhaWRBZGRPcHQuY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9mZnNldCkpIHtcblx0XHRcdFx0bGV0IGxhYmVsID0gYENoYW5uZWwgJHtvZmZzZXQgKyAxfWBcblx0XHRcdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdFx0XHRjb25zdCByZWZFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkQWRkQmFzZS5pZClcblx0XHRcdFx0XHRjb25zdCByZWZJZEFkZCA9IHJlZkVudHJ5Py5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRcdGNvbnN0IHJlZkNob2ljZSA9IHJlZklkQWRkPy5jaG9pY2VzPy5maW5kKChjaDogYW55KSA9PiBjaC5pZCA9PT0gb2Zmc2V0KVxuXHRcdFx0XHRcdGlmIChyZWZDaG9pY2UpIHtcblx0XHRcdFx0XHRcdGxhYmVsID0gcmVmQ2hvaWNlLmxhYmVsXG5cdFx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRpZEFkZE9wdC5jaG9pY2VzLnB1c2goeyBpZDogb2Zmc2V0LCBsYWJlbCB9KVxuXHRcdFx0XHRsb2dnZXIuaW5mbyhcblx0XHRcdFx0XHRgRm9sZGVkIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfSBpbnRvIGlkQWRkIGJhc2UgaWQ9JHt0b0hleChpZEFkZEJhc2UuaWQpfSBhcyBvZmZzZXQgJHtvZmZzZXR9IChcIiR7bGFiZWx9XCIpYCxcblx0XHRcdFx0KVxuXHRcdFx0fVxuXHRcdFx0Y29udGludWVcblx0XHR9XG5cblx0XHQvLyAxYy4gTm8gZXhhY3QgbWF0Y2ggXHUyMDE0IHRyeSBpbmZlcmVuY2UgZnJvbSBjYW5kaWRhdGUgbW9kZWxzXG5cdFx0bGV0IGFjdGlvbjogU3RBY3Rpb24gfCB1bmRlZmluZWRcblxuXHRcdGZvciAoY29uc3QgYyBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0XHRjb25zdCBtYXRjaCA9IGMuY21kU2NoZW1hPy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXHRcdFx0aWYgKG1hdGNoKSB7XG5cdFx0XHRcdGFjdGlvbiA9IHN0cnVjdHVyZWRDbG9uZShtYXRjaClcblx0XHRcdFx0Ly8gU3RyaXAgYW55IGV4aXN0aW5nIFwiKGluZmVycmVkIGZyb20gTW9kZWwgWClcIiBzdWZmaXhlcyBiZWZvcmUgYWRkaW5nIG91ciBvd25cblx0XHRcdFx0Y29uc3QgYmFzZU5hbWUgPSBtYXRjaC5uYW1lLnJlcGxhY2UoL1xccypcXChpbmZlcnJlZCBmcm9tIE1vZGVsIFteKV0rXFwpL2csICcnKS50cmltKClcblx0XHRcdFx0YWN0aW9uLm5hbWUgPSBgJHtiYXNlTmFtZX0gKGluZmVycmVkIGZyb20gTW9kZWwgJHtjLm1vZGVsfSlgXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBJbmZlcnJlZCBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gZnJvbSBNb2RlbCAke2MubW9kZWx9IChleGFjdClgKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIENoZWNrIGlmIHRoaXMgaWQgc2hvdWxkIGJlIGRlZmVycmVkIHRvIHBhc3MgMiBcdTIwMTRcblx0XHQvLyBpdCdzIGEgc2VxdWVudGlhbCBpZEFkZCBvZmZzZXQgb2YgYSBrbm93biBjYW5kaWRhdGUgYmFzZSBlbnRyeS5cblx0XHRpZiAoIWFjdGlvbikge1xuXHRcdFx0bGV0IHNob3VsZERlZmVyID0gZmFsc2Vcblx0XHRcdGZvciAoY29uc3QgYyBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0XHRcdGNvbnN0IGJhc2VFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChhOiBhbnkpID0+IHtcblx0XHRcdFx0XHRpZiAoYS5jbWRfaWQgIT09IGNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBhLm9wdGlvbnM/LmZpbmQoKG86IGFueSkgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0XHRpZiAoIWlkQWRkT3B0Py5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRpZiAoaWQgPD0gYS5pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0Y29uc3Qgb2Zmc2V0ID0gaWQgLSBhLmlkXG5cdFx0XHRcdFx0Y29uc3QgbWF4U2VxID0gaWRBZGREZWZlclJhbmdlcy5nZXQoYCR7Y21kX2lkfV8ke2EuaWR9YCkgPz8gMFxuXHRcdFx0XHRcdHJldHVybiBvZmZzZXQgPD0gbWF4U2VxXG5cdFx0XHRcdH0pXG5cdFx0XHRcdGlmIChiYXNlRW50cnkpIHtcblx0XHRcdFx0XHRzaG91bGREZWZlciA9IHRydWVcblx0XHRcdFx0XHRsb2dnZXIuZGVidWcoXG5cdFx0XHRcdFx0XHRgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9IGlzIGFuIGlkQWRkIG9mZnNldCBvZiBjYW5kaWRhdGUgYmFzZSBpZD0ke3RvSGV4KGJhc2VFbnRyeS5pZCl9IFx1MjAxNCBkZWZlcnJpbmcgdG8gcGFzcyAyYCxcblx0XHRcdFx0XHQpXG5cdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKHNob3VsZERlZmVyKSBjb250aW51ZVxuXHRcdH1cblxuXHRcdC8vIEZhbGxiYWNrOiB1bmtub3duIHNldHRpbmdcblx0XHRpZiAoIWFjdGlvbikge1xuXHRcdFx0YWN0aW9uID0ge1xuXHRcdFx0XHRjbWRfaWQsXG5cdFx0XHRcdGlkLFxuXHRcdFx0XHRuYW1lOiBgVW5rbm93biBjbWQ6JHt0b0hleChjbWRfaWQpfSBpZDoke3RvSGV4KGlkKS50b1VwcGVyQ2FzZSgpfWAsXG5cdFx0XHRcdG9wdGlvbnM6IFt2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlcyldLFxuXHRcdFx0fVxuXHRcdFx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIGFjdGlvbi5idXNDaCA9IGJ1c0NoXG5cdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IGluZmVyIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfWApXG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBGaXggMTogYnVzQ2ggaGFuZGxpbmcgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHQvLyBTdHJpcCBhbnkgaW5oZXJpdGVkIGJ1c0NoIG9wdGlvbiBmcm9tIHRoZSBjYW5kaWRhdGUgXHUyMDE0IHdlJ2xsIHJlLWRlcml2ZVxuXHRcdFx0Ly8gaXQgZnJvbSB3aGF0IHRoZSBwYWNrZXQgYWN0dWFsbHkgcmVwb3J0ZWQgZm9yIHRoaXMgZGV2aWNlLlxuXHRcdFx0YWN0aW9uLm9wdGlvbnMgPSBhY3Rpb24ub3B0aW9ucz8uZmlsdGVyKChvKSA9PiBvLmlkICE9PSAnYnVzQ2gnKSA/PyBbXVxuXHRcdFx0ZGVsZXRlIGFjdGlvbi5idXNDaFxuXG5cdFx0XHRjb25zdCBzZWVuQnVzQ2hWYWx1ZXMgPSBidXNDaFNlZW4uZ2V0KGAke2NtZF9pZH1fJHtpZH1gKVxuXHRcdFx0aWYgKHNlZW5CdXNDaFZhbHVlcyAmJiBzZWVuQnVzQ2hWYWx1ZXMuc2l6ZSA+IDApIHtcblx0XHRcdFx0Y29uc3QgbWF4QnVzQ2ggPSBNYXRoLm1heCguLi5zZWVuQnVzQ2hWYWx1ZXMpXG5cdFx0XHRcdGlmIChtYXhCdXNDaCA9PT0gMCkge1xuXHRcdFx0XHRcdC8vIE9ubHkgZXZlciBzYXcgYnVzQ2g9MCBcdTIxOTIgZml4ZWQgcHJvcGVydHksIG5vdCBhbiBvcHRpb25cblx0XHRcdFx0XHRhY3Rpb24uYnVzQ2ggPSAwXG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0Ly8gTXVsdGlwbGUgY2hhbm5lbHMgb2JzZXJ2ZWQgXHUyMTkyIHNlbGVjdGFibGUgb3B0aW9uXG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2hDaG9pY2VzID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogbWF4QnVzQ2ggKyAxIH0sIChfLCBpKSA9PiAoe1xuXHRcdFx0XHRcdFx0aWQ6IGksXG5cdFx0XHRcdFx0XHRsYWJlbDogYENoYW5uZWwgJHtpICsgMX1gLFxuXHRcdFx0XHRcdH0pKVxuXHRcdFx0XHRcdGFjdGlvbi5vcHRpb25zLnVuc2hpZnQoe1xuXHRcdFx0XHRcdFx0aWQ6ICdidXNDaCcsXG5cdFx0XHRcdFx0XHRsYWJlbDogJ0NoYW5uZWwnLFxuXHRcdFx0XHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdFx0XHRcdGNob2ljZXM6IGJ1c0NoQ2hvaWNlcyxcblx0XHRcdFx0XHRcdGRlZmF1bHQ6IDAsXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgRml4IDI6IGRlZmF1bHQgbXVzdCBleGlzdCBpbiBjaG9pY2VzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdFx0Ly8gU2V0IHRoZSBkZWZhdWx0IHRvIHRoZSBvYnNlcnZlZCB2YWx1ZS4gSWYgdGhhdCB2YWx1ZSBpc24ndCBpbiB0aGVcblx0XHRcdC8vIGluaGVyaXRlZCBjaG9pY2VzIGxpc3QsIHRoZSBjaG9pY2VzIGFyZSBmcm9tIGEgc3RydWN0dXJhbGx5IGRpZmZlcmVudFxuXHRcdFx0Ly8gbW9kZWwgYW5kIGNhbid0IGJlIHRydXN0ZWQgXHUyMDE0IGRpc2NhcmQgdGhlbSBhbmQgZmFsbCBiYWNrIHRvIGEgcGxhaW4gbnVtYmVyLlxuXHRcdFx0Y29uc3Qgb2JzZXJ2ZWREZWZhdWx0ID0gdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXMpLmRlZmF1bHRcblx0XHRcdGNvbnN0IHZhbHVlT3B0ID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICd2YWx1ZScpXG5cdFx0XHRpZiAodmFsdWVPcHQpIHtcblx0XHRcdFx0aWYgKHZhbHVlT3B0LmNob2ljZXMgJiYgQXJyYXkuaXNBcnJheSh2YWx1ZU9wdC5jaG9pY2VzKSkge1xuXHRcdFx0XHRcdGNvbnN0IGluQ2hvaWNlcyA9IHZhbHVlT3B0LmNob2ljZXMuc29tZSgoYzogYW55KSA9PiBjLmlkID09PSBvYnNlcnZlZERlZmF1bHQpXG5cdFx0XHRcdFx0aWYgKCFpbkNob2ljZXMpIHtcblx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKFxuXHRcdFx0XHRcdFx0XHRgSW5mZXJyZWQgY2hvaWNlcyBmb3IgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9IGRvbid0IGNvbnRhaW4gb2JzZXJ2ZWQgdmFsdWUgJHtvYnNlcnZlZERlZmF1bHR9IFx1MjAxNCBkaXNjYXJkaW5nIGluaGVyaXRlZCBjaG9pY2VzYCxcblx0XHRcdFx0XHRcdClcblx0XHRcdFx0XHRcdC8vIEtlZXAgbGFiZWwvdG9vbHRpcCBidXQgZHJvcCBjaG9pY2VzLCBzd2l0Y2ggdG8gcGxhaW4gbnVtYmVyXG5cdFx0XHRcdFx0XHR2YWx1ZU9wdC50eXBlID0gJ251bWJlcidcblx0XHRcdFx0XHRcdGRlbGV0ZSAodmFsdWVPcHQgYXMgYW55KS5jaG9pY2VzXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdHZhbHVlT3B0LmRlZmF1bHQgPSBvYnNlcnZlZERlZmF1bHRcblx0XHRcdH1cblx0XHR9XG5cblx0XHRvdXQuY21kU2NoZW1hLnB1c2goYWN0aW9uKVxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBQQVNTIDI6IGZvbGQgYW55IGRlZmVycmVkIGlkQWRkIG9mZnNldHMgd2hvc2UgYmFzZSBlbnRyeVxuXHQvLyBpcyBub3cgcHJlc2VudCBpbiB0aGUgb3V0cHV0IHNjaGVtYS5cblx0Ly8gR2F0ZTogdGhlIG9mZnNldCBtdXN0IGVpdGhlciBleGlzdCBpbiBhIHJlZmVyZW5jZSBtb2RlbCdzIGNob2ljZXMsXG5cdC8vIE9SIHRoZSBiYXNlIGVudHJ5IGl0c2VsZiB3YXMgaW5mZXJyZWQgKGhhcyBpZEFkZCkgYW5kIHRoZSBvZmZzZXRcblx0Ly8gY29udGludWVzIHNlcXVlbnRpYWxseSBiZXlvbmQgdGhlIHJlZmVyZW5jZSBtb2RlbCdzIGtub3duIHJhbmdlLlxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdGZvciAoY29uc3QgeyBjbWRfaWQsIGlkIH0gb2YgcGFyc2VkKSB7XG5cdFx0Y29uc3QgYWxyZWFkeVRvcExldmVsID0gb3V0LmNtZFNjaGVtYS5zb21lKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXHRcdGlmIChhbHJlYWR5VG9wTGV2ZWwpIGNvbnRpbnVlXG5cblx0XHQvLyBGaW5kIGEgYmFzZSBlbnRyeSBpbiB0aGUgb3V0cHV0IHRoYXQgaGFzIGlkQWRkIGFuZCB3aG9zZSBpZCA8IHRoaXMgaWRcblx0XHRjb25zdCBpZEFkZEJhc2UgPSBvdXQuY21kU2NoZW1hLmZpbmQoKGEpID0+IHtcblx0XHRcdGlmIChhLmNtZF9pZCAhPT0gY21kX2lkKSByZXR1cm4gZmFsc2Vcblx0XHRcdGNvbnN0IGlkQWRkT3B0ID0gYS5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0cmV0dXJuICEhaWRBZGRPcHQ/LmNob2ljZXMgJiYgaWQgPiBhLmlkXG5cdFx0fSlcblx0XHRpZiAoIWlkQWRkQmFzZSkgY29udGludWVcblxuXHRcdGNvbnN0IG9mZnNldCA9IGlkIC0gaWRBZGRCYXNlLmlkXG5cdFx0Y29uc3QgaWRBZGRPcHQgPSBpZEFkZEJhc2Uub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRpZiAoIWlkQWRkT3B0Py5jaG9pY2VzIHx8IGlkQWRkT3B0LmNob2ljZXMuc29tZSgoYzogYW55KSA9PiBjLmlkID09PSBvZmZzZXQpKSBjb250aW51ZVxuXG5cdFx0Ly8gQWNjZXB0IHRoZSBmb2xkIGlmOiBhIHJlZmVyZW5jZSBtb2RlbCBleHBsaWNpdGx5IGhhcyB0aGlzIG9mZnNldCxcblx0XHQvLyBPUiB0aGUgb2Zmc2V0cyBhcmUgc3RyaWN0bHkgc2VxdWVudGlhbCBmcm9tIDAgKGRldmljZSBoYXMgbW9yZSBjaGFubmVscyB0aGFuIHJlZmVyZW5jZSlcblx0XHRjb25zdCByZWZIYXNPZmZzZXQgPSBjYW5kaWRhdGVzLnNvbWUoKGMpID0+IHtcblx0XHRcdGNvbnN0IHJlZkVudHJ5ID0gYy5jbWRTY2hlbWE/LmZpbmQoKHIpID0+IHIuY21kX2lkID09PSBjbWRfaWQgJiYgci5pZCA9PT0gaWRBZGRCYXNlLmlkKVxuXHRcdFx0Y29uc3QgcmVmSWRBZGQgPSByZWZFbnRyeT8ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdHJldHVybiByZWZJZEFkZD8uY2hvaWNlcz8uc29tZSgoY2g6IGFueSkgPT4gY2guaWQgPT09IG9mZnNldClcblx0XHR9KVxuXHRcdGNvbnN0IGV4aXN0aW5nT2Zmc2V0cyA9IGlkQWRkT3B0LmNob2ljZXMubWFwKChjOiBhbnkpID0+IGMuaWQgYXMgbnVtYmVyKS5zb3J0KChhLCBiKSA9PiBhIC0gYilcblx0XHRjb25zdCBpc1NlcXVlbnRpYWwgPSBleGlzdGluZ09mZnNldHMubGVuZ3RoID4gMCAmJiBvZmZzZXQgPT09IGV4aXN0aW5nT2Zmc2V0c1tleGlzdGluZ09mZnNldHMubGVuZ3RoIC0gMV0gKyAxXG5cblx0XHRpZiAoIXJlZkhhc09mZnNldCAmJiAhaXNTZXF1ZW50aWFsKSBjb250aW51ZVxuXG5cdFx0Ly8gSW5oZXJpdCBsYWJlbCBmcm9tIHJlZmVyZW5jZSBtb2RlbCBpZiBhdmFpbGFibGUsIG90aGVyd2lzZSBnZW5lcmF0ZSBvbmVcblx0XHRsZXQgbGFiZWwgPSBgQ2hhbm5lbCAke29mZnNldCArIDF9YFxuXHRcdGZvciAoY29uc3QgYyBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0XHRjb25zdCByZWZFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkQWRkQmFzZS5pZClcblx0XHRcdGNvbnN0IHJlZklkQWRkID0gcmVmRW50cnk/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRjb25zdCByZWZDaG9pY2UgPSByZWZJZEFkZD8uY2hvaWNlcz8uZmluZCgoY2g6IGFueSkgPT4gY2guaWQgPT09IG9mZnNldClcblx0XHRcdGlmIChyZWZDaG9pY2UpIHtcblx0XHRcdFx0bGFiZWwgPSByZWZDaG9pY2UubGFiZWxcblx0XHRcdFx0YnJlYWtcblx0XHRcdH1cblx0XHR9XG5cblx0XHRpZEFkZE9wdC5jaG9pY2VzLnB1c2goeyBpZDogb2Zmc2V0LCBsYWJlbCB9KVxuXHRcdGxvZ2dlci5pbmZvKFxuXHRcdFx0YFBhc3MgMjogRm9sZGVkIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfSBpbnRvIGlkQWRkIGJhc2UgaWQ9JHt0b0hleChpZEFkZEJhc2UuaWQpfSBhcyBvZmZzZXQgJHtvZmZzZXR9IChcIiR7bGFiZWx9XCIpYCxcblx0XHQpXG5cdH1cblxuXHRyZXR1cm4gb3V0XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFNBVkVcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IGZ1bmN0aW9uIHNhdmVNb2RlbEpzb25QcmV0dHkoZmlsZVBhdGg6IHN0cmluZywganNvbk9iajogU3RNb2RlbEpzb24pOiB2b2lkIHtcblx0dHJ5IHtcblx0XHQvLyBFbnN1cmUgcHJvcGVyIGtleSBvcmRlcmluZzogbW9kZWwsIHVzZUNvbk1vbiAoaWYgcHJlc2VudCksIGNtZFNjaGVtYVxuXHRcdGNvbnN0IG9yZGVyZWRPYmo6IGFueSA9IHsgbW9kZWw6IGpzb25PYmoubW9kZWwgfVxuXG5cdFx0Ly8gQWRkIHVzZUNvbk1vbiBrZXkgaWYgcHJlc2VudCAocmlnaHQgYWZ0ZXIgbW9kZWwpXG5cdFx0aWYgKCd1c2VDb25Nb24nIGluIGpzb25PYmopIHtcblx0XHRcdG9yZGVyZWRPYmoudXNlQ29uTW9uID0ganNvbk9iai51c2VDb25Nb25cblx0XHR9XG5cblx0XHQvLyBBZGQgb3RoZXIga2V5cyBpbiBvcmRlclxuXHRcdGlmICgnY21kU2NoZW1hJyBpbiBqc29uT2JqKSB7XG5cdFx0XHRvcmRlcmVkT2JqLmNtZFNjaGVtYSA9IGpzb25PYmouY21kU2NoZW1hLm1hcCgoZW50cnk6IGFueSkgPT4ge1xuXHRcdFx0XHQvLyBFbmZvcmNlIGtleSBvcmRlciB3aXRoaW4gZWFjaCBzY2hlbWEgZW50cnk6IGNtZF9pZCwgaWQsIGJ1c0NoLCBuYW1lLCBvcHRpb25zXG5cdFx0XHRcdGNvbnN0IG9yZGVyZWRFbnRyeTogYW55ID0ge31cblx0XHRcdFx0aWYgKCdjbWRfaWQnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkuY21kX2lkID0gZW50cnkuY21kX2lkXG5cdFx0XHRcdGlmICgnaWQnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkuaWQgPSBlbnRyeS5pZFxuXHRcdFx0XHRpZiAoJ2J1c0NoJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5LmJ1c0NoID0gZW50cnkuYnVzQ2hcblx0XHRcdFx0aWYgKCduYW1lJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5Lm5hbWUgPSBlbnRyeS5uYW1lXG5cdFx0XHRcdGlmICgnb3B0aW9ucycgaW4gZW50cnkpIG9yZGVyZWRFbnRyeS5vcHRpb25zID0gZW50cnkub3B0aW9uc1xuXHRcdFx0XHQvLyBDb3B5IGFueSByZW1haW5pbmcga2V5c1xuXHRcdFx0XHRmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhlbnRyeSkpIHtcblx0XHRcdFx0XHRpZiAoIShrZXkgaW4gb3JkZXJlZEVudHJ5KSkgb3JkZXJlZEVudHJ5W2tleV0gPSBlbnRyeVtrZXldXG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIG9yZGVyZWRFbnRyeVxuXHRcdFx0fSlcblx0XHR9XG5cdFx0Ly8gQ29weSBhbnkgb3RoZXIga2V5cyB0aGF0IG1pZ2h0IGV4aXN0XG5cdFx0Zm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMoanNvbk9iaikpIHtcblx0XHRcdGlmICghKGtleSBpbiBvcmRlcmVkT2JqKSkge1xuXHRcdFx0XHRvcmRlcmVkT2JqW2tleV0gPSAoanNvbk9iaiBhcyBhbnkpW2tleV1cblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBDdXN0b20gZm9ybWF0dGVyOiBrZWVwIGNob2ljZSBvYmplY3RzIGNvbXBhY3Qgb24gb25lIGxpbmVcblx0XHRsZXQganNvbiA9IEpTT04uc3RyaW5naWZ5KG9yZGVyZWRPYmosIG51bGwsIDIpXG5cblx0XHQvLyBSZXBsYWNlIGV4cGFuZGVkIGNob2ljZSBvYmplY3RzIHdpdGggY29tcGFjdCBzaW5nbGUtbGluZSBmb3JtYXRcblx0XHQvLyBNYXRjaGVzOiB7XFxuICAgICAgICAgICAgXCJpZFwiOiBYLFxcbiAgICAgICAgICAgIFwibGFiZWxcIjogXCJZXCJcXG4gICAgICAgICAgfVxuXHRcdC8vIFJlcGxhY2VzIHdpdGg6IHsgXCJpZFwiOiBYLCBcImxhYmVsXCI6IFwiWVwiIH1cblx0XHRqc29uID0ganNvbi5yZXBsYWNlKC9cXHtcXG5cXHMrXCJpZFwiOlxccyooXFxkKyksXFxuXFxzK1wibGFiZWxcIjpcXHMqXCIoW15cIl0qKVwiXFxuXFxzK1xcfS9nLCAneyBcImlkXCI6ICQxLCBcImxhYmVsXCI6IFwiJDJcIiB9JylcblxuXHRcdGZzLndyaXRlRmlsZVN5bmMoZmlsZVBhdGgsIGpzb24gKyAnXFxuJywgJ3V0ZjgnKVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0bG9nZ2VyLmVycm9yKGBGaWxlIFdyaXRlIEVycm9yOiAke2V9YClcblx0fVxufVxuIiwgImltcG9ydCBNb2R1bGVJbnN0YW5jZSBmcm9tICcuL21haW4uanMnXG5pbXBvcnQgeyBidWlsZEZlZWRiYWNrcyB9IGZyb20gJy4vYnVpbGQtY29tbWFuZHMuanMnXG5pbXBvcnQgeyBnZXREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBwYXJzZVNldHRpbmdJZCwgZ2V0Tm9ybWFsaXplZFNjaGVtYXMsIGZpbmRBY3Rpb25Gb3JTZXR0aW5nIH0gZnJvbSAnLi90eXBlcy5qcydcblxuLyoqXG4gKiBIZWxwZXIgZnVuY3Rpb24gdG8gZ2V0IGxhYmVsIGZyb20gY2hvaWNlcyBiYXNlZCBvbiB2YWx1ZVxuICovXG5mdW5jdGlvbiBnZXRMYWJlbEZvclZhbHVlKFxuXHRzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4sXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIsXG5cdHNldHRpbmdJZDogbnVtYmVyLFxuXHR2YWx1ZTogbnVtYmVyLFxuKTogc3RyaW5nIHwgbnVtYmVyIHtcblx0Y29uc3Qgc2V0dGluZyA9IGZpbmRBY3Rpb25Gb3JTZXR0aW5nKHNjaGVtYXMsIG1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkKVxuXHRpZiAoIXNldHRpbmcgfHwgIUFycmF5LmlzQXJyYXkoc2V0dGluZy5vcHRpb25zKSkgcmV0dXJuIHZhbHVlXG5cblx0Ly8gRmluZCB0aGUgJ3ZhbHVlJyBvcHRpb24gd2hpY2ggY29udGFpbnMgdGhlIGNob2ljZXNcblx0Y29uc3QgdmFsdWVPcHRpb24gPSBzZXR0aW5nLm9wdGlvbnMuZmluZCgob3B0OiBhbnkpID0+IG9wdC5pZCA9PT0gJ3ZhbHVlJylcblx0aWYgKCF2YWx1ZU9wdGlvbiB8fCAhQXJyYXkuaXNBcnJheSh2YWx1ZU9wdGlvbi5jaG9pY2VzKSkgcmV0dXJuIHZhbHVlXG5cblx0Ly8gRmluZCB0aGUgY2hvaWNlIHdpdGggbWF0Y2hpbmcgaWRcblx0Y29uc3QgY2hvaWNlID0gdmFsdWVPcHRpb24uY2hvaWNlcy5maW5kKChjOiBhbnkpID0+IGMuaWQgPT09IHZhbHVlKVxuXHRyZXR1cm4gY2hvaWNlPy5sYWJlbCA/PyB2YWx1ZVxufVxuXG4vKipcbiAqIEJ1aWxkIGFuZCB3aXJlIENvbXBhbmlvbiBmZWVkYmFjayBkZWZpbml0aW9uc1xuICogUGF0dGVybiBtYXRjaGVzIGFjdGlvbnMudHMgLSBmaWx0ZXJzIGJ5IGFjdGl2ZSBtb2RlbCBhbmQgd2lyZXMgY2FsbGJhY2tzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVGZWVkYmFja3Moc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3Qgc2NoZW1hc1JhdyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCByYXdGZWVkYmFja3MgPSBidWlsZEZlZWRiYWNrcygpXG5cdGNvbnN0IHNjaGVtYXMgPSBnZXROb3JtYWxpemVkU2NoZW1hcyhzY2hlbWFzUmF3KVxuXHRjb25zdCB3aXJlZEZlZWRiYWNrczogYW55ID0ge31cblxuXHQvLyBHZXQgdGhlIGFjdGl2ZSBtb2RlbCBmcm9tIHRoZSBjYWNoZWQgdmFsdWUgc2V0IGJ5IHN5bmNNb2RlbCgpXG5cdGNvbnN0IGFjdGl2ZU1vZGVsID0gc2VsZi5hY3RpdmVNb2RlbFxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgQlVJTEQgUEVSLVNFVFRJTkcgRkVFREJBQ0tTIChGSUxURVJFRCBCWSBBQ1RJVkUgTU9ERUwpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdGZvciAoY29uc3QgW2ZlZWRiYWNrSWQsIGZlZWRiYWNrXSBvZiBPYmplY3QuZW50cmllcyhyYXdGZWVkYmFja3MpKSB7XG5cdFx0Ly8gU3RyaXAgX2Jvb2wgc3VmZml4IGJlZm9yZSBwYXJzaW5nIHNvIHRoZSBtb2RlbC9jbWRJZC9iYXNlSWQgYXJlIGV4dHJhY3RlZCBjb3JyZWN0bHlcblx0XHRjb25zdCBwYXJzZUlkID0gZmVlZGJhY2tJZC5lbmRzV2l0aCgnX2Jvb2wnKSA/IGZlZWRiYWNrSWQuc2xpY2UoMCwgLTUpIDogZmVlZGJhY2tJZFxuXHRcdGNvbnN0IHsgbW9kZWwsIGNtZElkLCBiYXNlSWQgfSA9IHBhcnNlU2V0dGluZ0lkKHBhcnNlSWQpXG5cblx0XHQvLyBPbmx5IGluY2x1ZGUgZmVlZGJhY2tzIGZvciB0aGUgY3VycmVudGx5IGFjdGl2ZSBtb2RlbFxuXHRcdGlmIChtb2RlbCAhPT0gYWN0aXZlTW9kZWwpIGNvbnRpbnVlXG5cblx0XHQvLyBWQUxVRSBGRUVEQkFDSzogUmV0dXJucyBjdXJyZW50IHZhbHVlIGZvciBsb2NhbCB2YXJpYWJsZVxuXHRcdHdpcmVkRmVlZGJhY2tzW2ZlZWRiYWNrSWRdID0ge1xuXHRcdFx0Li4uZmVlZGJhY2ssXG5cdFx0XHRjYWxsYmFjazogKGZlZWRiYWNrRXZlbnQ6IGFueSkgPT4ge1xuXHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXHRcdFx0XHRjb25zdCBpZEFkZCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snaWRBZGQnXSA/PyAwXG5cdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGJhc2VJZCArIGlkQWRkXG5cblx0XHRcdFx0Ly8gYnVzQ2ggZnJvbSBvcHRpb25zIHRha2VzIHByaW9yaXR5OyBmYWxsIGJhY2sgdG8gZml4ZWQgYnVzQ2ggaW4gc2NoZW1hXG5cdFx0XHRcdGxldCBidXNDaCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snYnVzQ2gnXVxuXHRcdFx0XHRpZiAoYnVzQ2ggPT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdGNvbnN0IHNjaGVtYUFjdGlvbiA9IGZpbmRBY3Rpb25Gb3JTZXR0aW5nKHNjaGVtYXMsIG1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkKVxuXHRcdFx0XHRcdGlmIChzY2hlbWFBY3Rpb24/LmJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRcdGJ1c0NoID0gc2NoZW1hQWN0aW9uLmJ1c0NoXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdC8vIExhc3QgcmVzb3J0OiBsb29rIHVwIGZpeGVkIGJ1c0NoIGRpcmVjdGx5IGZyb20gdGhlIHJhdyBkZXZpY2Ugc2NoZW1hLFxuXHRcdFx0XHQvLyBpbiBjYXNlIGdldE5vcm1hbGl6ZWRTY2hlbWFzKCkgc3RyaXBwZWQgdGhlIHByb3BlcnR5IChlLmcuIE1pYyBFbGVjdHJldCBQb3dlcikuXG5cdFx0XHRcdGlmIChidXNDaCA9PT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0Y29uc3QgcmF3QWN0aW9uID0gc2NoZW1hc1Jhd1ttb2RlbF0/LmNtZFNjaGVtYT8uZmluZCgoYTogYW55KSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gc2V0dGluZ0lkKVxuXHRcdFx0XHRcdGlmIChyYXdBY3Rpb24/LmJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRcdGJ1c0NoID0gcmF3QWN0aW9uLmJ1c0NoXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cblx0XHRcdFx0Y29uc3QgY3VycmVudCA9IHNlbGYuc3RDb250cm9sbGVyLmdldFNldHRpbmdWYWx1ZShpcCwgY21kSWQsIHNldHRpbmdJZCwgYnVzQ2gpXG5cblx0XHRcdFx0Ly8gQm9vbGVhbiBmZWVkYmFja3M6IGFueSBub24temVybyB2YWx1ZSA9IGFjdGl2ZSAodHJ1ZSksIHplcm8gPSBpbmFjdGl2ZSAoZmFsc2UpLlxuXHRcdFx0XHQvLyBUaGlzIHdvcmtzIGZvciBhbGwgT24vT2ZmIHNldHRpbmdzIHJlZ2FyZGxlc3Mgb2Ygd2hhdCB0aGUgXCJPblwiIElEIHZhbHVlIGlzXG5cdFx0XHRcdC8vIGluIHRoZSBzY2hlbWEgKGUuZy4gTWljIEVsZWN0cmV0IFBvd2VyIHVzZXMgNSBmb3IgT24sIG5vdCAxKS5cblx0XHRcdFx0Ly8gUmV0dXJucyBhIHJlYWwgYm9vbGVhbiBcdTIwMTQgdXNlZCBmb3IgYnV0dG9uIGNvbG9yaW5nIG9ubHksIG5vdCB2YXJpYWJsZXMuXG5cdFx0XHRcdGlmIChmZWVkYmFja0lkLmVuZHNXaXRoKCdfYm9vbCcpKSB7XG5cdFx0XHRcdFx0cmV0dXJuIGN1cnJlbnQgIT09IHVuZGVmaW5lZCAmJiBjdXJyZW50ICE9PSAwXG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBDaGVjayBpZiB1c2VyIHdhbnRzIGxhYmVsIGluc3RlYWQgb2YgbnVtZXJpYyB2YWx1ZVxuXHRcdFx0XHRjb25zdCBzaG93TGFiZWwgPSBmZWVkYmFja0V2ZW50Lm9wdGlvbnNbJ3Nob3dMYWJlbCddID8/IGZhbHNlXG5cblx0XHRcdFx0aWYgKHNob3dMYWJlbCAmJiBjdXJyZW50ICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRjb25zdCBsYWJlbCA9IGdldExhYmVsRm9yVmFsdWUoc2NoZW1hcywgbW9kZWwsIGNtZElkLCBzZXR0aW5nSWQsIGN1cnJlbnQpXG5cdFx0XHRcdFx0Ly8gSWYgbm8gY2hvaWNlIGxhYmVsIHdhcyBmb3VuZCAocmV0dXJuZWQgYSBudW1iZXIpLCB0aGUgc2V0dGluZyBoYXMgbm9cblx0XHRcdFx0XHQvLyBkaXNjcmV0ZSBjaG9pY2VzIFx1MjAxNCB0cmVhdCBpdCBhcyBib29sZWFuIGFuZCBzaG93IHRydWUvZmFsc2UuXG5cdFx0XHRcdFx0aWYgKHR5cGVvZiBsYWJlbCA9PT0gJ251bWJlcicpIHtcblx0XHRcdFx0XHRcdHJldHVybiBsYWJlbCAhPT0gMCA/ICd0cnVlJyA6ICdmYWxzZSdcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0cmV0dXJuIGxhYmVsXG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBSZXR1cm4gbnVtZXJpYyB2YWx1ZSBkaXJlY3RseSBmb3IgbG9jYWwgdmFyaWFibGUgKHR5cGU6ICd2YWx1ZScpXG5cdFx0XHRcdHJldHVybiBjdXJyZW50ID8/IDBcblx0XHRcdH0sXG5cdFx0fVxuXHR9XG5cblx0c2VsZi5zZXRGZWVkYmFja0RlZmluaXRpb25zKHdpcmVkRmVlZGJhY2tzKVxufVxuIiwgImltcG9ydCBkZ3JhbSBmcm9tICdkZ3JhbSdcbmltcG9ydCBvcyBmcm9tICdvcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQge1xuXHRDTURfQlVTX0dFVCxcblx0Q01EX0JVU19TRVQsXG5cdENNRF9ERVZfU1BFQyxcblx0Q01EX0dFVF9BTExfU0VUVElOR1MsXG5cdENNRF9HRVRfRklSTVdBUkUsXG5cdENNRF9HTE9CQUxfTUlDX0tJTEwsXG5cdENNRF9NSUNfUFJFLFxuXHRDTURfTUlDX1BSRV9CVVMsXG5cdENNRF9SRVNFVF9ERVZJQ0UsXG5cdENNRF9TRVRUSU5HU19QVVNILFxuXHRnZXRDb21tYW5kTmFtZSxcblx0bWFrZVNldHRpbmdJZCxcblx0dG9IZXgsXG5cdGJ5dGVzVG9IZXgsXG5cdHR5cGUgRGV2aWNlSW5mbyxcbn0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7XG5cdHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbCxcblx0cGFyc2VTZXR0aW5nc1Jlc3BvbnNlLFxuXHRmb3JtYXRQYXJzZWRTZXR0aW5nLFxuXHR0eXBlIFN0QWN0aW9uLFxuXHR0eXBlIFBhcnNlZFNldHRpbmcsXG59IGZyb20gJy4vc2V0dGluZ3NQYXJzZXIuanMnXG5pbXBvcnQgeyBnZXREZXZpY2VTY2hlbWEgfSBmcm9tICcuL2NvbmZpZy5qcydcblxuaW1wb3J0IHtcblx0REFOVEVfTVNHX0lORk9fUkVTUE9OU0UsXG5cdHBhcnNlRGFudGVJbmZvUmVzcG9uc2UsXG5cdGRpc2NvdmVyRGV2aWNlcyxcblx0cHJvYmVEZXZpY2UgYXMgZGFudGVQcm9iZURldmljZSxcblx0Z2V0TWFjRm9yRGVzdGluYXRpb24sXG5cdGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uLFxufSBmcm9tICcuL2RhbnRlLmpzJ1xuaW1wb3J0IHsgb3BlbkNvbk1vblNlc3Npb24gfSBmcm9tICcuL2Nvbm1vbi5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdTdENvbnRyb2xsZXInKVxuXG5leHBvcnQgY2xhc3MgU3RDb250cm9sbGVyIHtcblx0cHJpdmF0ZSByZWFkb25seSBkZWZhdWx0UG9ydDogbnVtYmVyID0gODcwMFxuXHRwcml2YXRlIHJlYWRvbmx5IG11bHRpY2FzdEdyb3VwID0gJzIyNC4wLjAuMjMxJ1xuXHRwcml2YXRlIHJlYWRvbmx5IHJ4UG9ydCA9IDg3MDJcblxuXHRwcml2YXRlIHR4U29ja2V0OiBkZ3JhbS5Tb2NrZXRcblx0cHJpdmF0ZSByeFNvY2tldDogZGdyYW0uU29ja2V0IC8vIGZvciByZWNlaXZpbmcgcmVzcG9uc2VzICg4NzAyKVxuXHRwcml2YXRlIHJ4TWNhc3RTb2NrZXQ6IGRncmFtLlNvY2tldCB8IG51bGwgPSBudWxsIC8vIGRpYWdub3N0aWM6IHRyYWNrcyB3aGljaCByZXNwb25zZXMgYXJyaXZlIHZpYSBtdWx0aWNhc3Rcblx0cHJpdmF0ZSBtY2FzdERlbGl2ZXJpZXM6IFNldDxzdHJpbmc+ID0gbmV3IFNldCgpIC8vIGtleXMgc2VlbiBvbiBtdWx0aWNhc3Qgc29ja2V0IHRoaXMgY3ljbGVcblx0cHJpdmF0ZSBwZW5kaW5nQWNrczogTWFwPFxuXHRcdHN0cmluZyxcblx0XHR7IHJlc29sdmU6IChidWY6IEJ1ZmZlcikgPT4gdm9pZDsgcmVqZWN0OiAoZTogRXJyb3IpID0+IHZvaWQ7IHRpbWVyOiBOb2RlSlMuVGltZW91dCB9XG5cdD4gPSBuZXcgTWFwKClcblx0cHJpdmF0ZSBqb2luZWRJbnRlcmZhY2VzOiBTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKSAvLyBsb2NhbCBJUHMgd2UndmUgam9pbmVkIG11bHRpY2FzdCBvblxuXG5cdC8qKiBTZXJpYWxpemVzIG91dGdvaW5nIGNvbW1hbmRzIHNvIGVhY2ggd2FpdHMgZm9yIEFDSyBiZWZvcmUgdGhlIG5leHQgaXMgc2VudCAqL1xuXHRwcml2YXRlIHNlbmRRdWV1ZTogUHJvbWlzZTx2b2lkPiA9IFByb21pc2UucmVzb2x2ZSgpXG5cblx0LyoqIFRyYWNrcyBob3cgbWFueSBjb21tYW5kcyBhcmUgcXVldWVkL2luLWZsaWdodCwgdG8gZGVmZXIgcmVxdWVzdEFsbFNldHRpbmdzICovXG5cdHByaXZhdGUgcGVuZGluZ0NvbW1hbmRDb3VudCA9IDBcblxuXHQvKiogUmVzb2x2ZXMgb25jZSB0eFNvY2tldCBpcyBib3VuZCBhbmQgcmVhZHkgdG8gc2VuZCAqL1xuXHRwcml2YXRlIHR4UmVhZHk6IFByb21pc2U8dm9pZD5cblxuXHQvKiogQWN0aXZlIGRldmljZSBtb2RlbCBhbmQgYWN0aW9uIGRlZmluaXRpb25zIGZvciBzZXR0aW5ncyBkZWNvZGluZyAqL1xuXHRwcml2YXRlIG1vZGVsOiBzdHJpbmcgPSAnJ1xuXHRwcml2YXRlIGFjdGlvbnM6IFN0QWN0aW9uW10gPSBbXVxuXG5cdC8qKlxuXHQgKiBLbm93biBzdGF0ZSBvZiBldmVyeSBzZXR0aW5nIHBlciBkZXZpY2UgSVAuXG5cdCAqIEtleWVkIGJ5IElQIFx1MjE5MiBNYXAgb2YgXCIke2NtZElkfS8ke3NldHRpbmdJZH1cIiBcdTIxOTIgY3VycmVudCB2YWx1ZSBieXRlLlxuXHQgKiBQb3B1bGF0ZWQgb24gY29ubmVjdCB2aWEgcmVxdWVzdEFsbFNldHRpbmdzKCksIHVwZGF0ZWQgb24gZXZlcnkgQ01EX1NFVFRJTkdTX1BVU0ggKDB4MGIpLlxuXHQgKiBVc2VkIHRvIGRpZmYgaW5jb21pbmcgcHVzaGVzIChjaGFuZ2VkID0gaW5mbywgdW5jaGFuZ2VkID0gZGVidWcpIGFuZCBmb3IgZmVlZGJhY2tzLlxuXHQgKi9cblx0cHJpdmF0ZSBkZXZpY2VTdGF0ZTogTWFwPHN0cmluZywgTWFwPHN0cmluZywgbnVtYmVyPj4gPSBuZXcgTWFwKClcblxuXHQvKipcblx0ICogSVBzIHRoYXQgaGF2ZSBiZWVuIHZlcmlmaWVkIGFnYWluc3QgdGhlIGNvbmZpZ3VyZWQgbW9kZWwgYW5kIGFyZSBhbGxvd2VkXG5cdCAqIHRvIHJlY2VpdmUgU3R1ZGlvLVQgY29tbWFuZHMuIFBvcHVsYXRlZCBieSBhdXRob3JpemVEZXZpY2UoKSBhZnRlciBhXG5cdCAqIHN1Y2Nlc3NmdWwgcHJvYmVEZXZpY2UoKSBtb2RlbCBtYXRjaCwgb3IgYWZ0ZXIgbXVsdGljYXN0IGRpc2NvdmVyeS5cblx0ICogX3NlbmRBd2FpdEFjaygpIHJlamVjdHMgYW55IGRlc3RJcCBub3QgaW4gdGhpcyBzZXQuXG5cdCAqL1xuXHRwcml2YXRlIGF1dGhvcml6ZWRJcHM6IFNldDxzdHJpbmc+ID0gbmV3IFNldCgpXG5cblx0LyoqIENhbGxiYWNrcyByZWdpc3RlcmVkIGZvciBEYW50ZSAweDAxNzAgZGV2aWNlIGluZm8gcmVzcG9uc2VzIFx1MjAxNCBrZXllZCBieSB1c2FnZSAqL1xuXHRwcml2YXRlIGRpc2NvdmVyeUxpc3RlbmVyczogTWFwPHN0cmluZywgKGRldmljZTogRGV2aWNlSW5mbykgPT4gdm9pZD4gPSBuZXcgTWFwKClcblxuXHQvKiogQ2FsbGJhY2sgdG8gdHJpZ2dlciBmZWVkYmFjayB1cGRhdGVzIHdoZW4gc3RhdGUgY2hhbmdlcyAqL1xuXHRwcml2YXRlIGZlZWRiYWNrQ2FsbGJhY2s/OiAoZmVlZGJhY2tJZDogc3RyaW5nKSA9PiB2b2lkXG5cblx0LyoqIENhY2hlIG9mIGxvY2FsIGludGVyZmFjZSBNQUMgYnl0ZXMgcGVyIGRlc3RpbmF0aW9uIElQLCB0byBhdm9pZCByZXBlYXRlZCBPUyBsb29rdXBzICovXG5cdHByaXZhdGUgbWFjQ2FjaGU6IE1hcDxzdHJpbmcsIG51bWJlcltdPiA9IG5ldyBNYXAoKVxuXG5cdC8qKiBUcmFja3Mgc2Vzc2lvbiByZWFkaW5lc3MgcGVyIElQIFx1MjAxNCBzZXQgZm9yIGRldmljZXMgdGhhdCBlc3RhYmxpc2hlZCBDb25Nb24sIGFuZCBhbHNvXG5cdCAqICBmb3IgZGV2aWNlcyB0aGF0IGRvbid0IHJlcXVpcmUgQ29uTW9uICh1c2VDb25Nb24gbm90IHNldCksIHNvIHRoZSBjaGVjayBpcyBvbmx5IGRvbmUgb25jZS4gKi9cblx0cHJpdmF0ZSBzZXNzaW9uRXN0YWJsaXNoZWQ6IFNldDxzdHJpbmc+ID0gbmV3IFNldCgpXG5cblx0LyoqIENsZWFudXAgZnVuY3Rpb25zIHJldHVybmVkIGJ5IG9wZW5Db25Nb25TZXNzaW9uKCkgXHUyMDE0IGNhbGwgdG8gc3RvcCBrZWVwYWxpdmVzIGFuZCBjbG9zZSB0aGUgc29ja2V0ICovXG5cdHByaXZhdGUgX2Nvbm1vbkNsZWFudXBzOiBNYXA8c3RyaW5nLCAoKSA9PiB2b2lkPiA9IG5ldyBNYXAoKVxuXG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdGxvZ2dlci5pbmZvKCdTdENvbnRyb2xsZXIgaW5pdGlhbGl6ZWQnKVxuXG5cdFx0Ly8gU2VuZCBzb2NrZXQgXHUyMDE0IGJpbmQgdG8gZXBoZW1lcmFsIHBvcnQuIFJlc3BvbnNlcyBhbHdheXMgZ28gdG8gcnhTb2NrZXQgb25cblx0XHQvLyBwb3J0IDg3MDIgKERhbnRlIGhhcmRjb2RlcyB0aGUgcmVzcG9uc2UgZGVzdGluYXRpb24gcG9ydCB0byA4NzAyKS5cblx0XHR0aGlzLnR4U29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblx0XHR0aGlzLnR4UmVhZHkgPSBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuXHRcdFx0dGhpcy50eFNvY2tldC5iaW5kKDAsICgpID0+IHtcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBUWCBzb2NrZXQgYm91bmQgdG8gcG9ydCAkeyh0aGlzLnR4U29ja2V0LmFkZHJlc3MoKSBhcyB7IHBvcnQ6IG51bWJlciB9KS5wb3J0fWApXG5cdFx0XHRcdHJlc29sdmUoKVxuXHRcdFx0fSlcblx0XHR9KVxuXHRcdHRoaXMudHhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBUWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdC8vIFJlY2VpdmUgc29ja2V0IC0gYmluZCB0byBhbGwgYWRkcmVzc2VzIHNvIGtlcm5lbCBjYW4gZGVsaXZlciBtdWx0aWNhc3QgcGFja2V0c1xuXHRcdHRoaXMucnhTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXG5cdFx0dGhpcy5yeFNvY2tldC5vbignbGlzdGVuaW5nJywgKCkgPT4ge1xuXHRcdFx0Y29uc3QgYWRkciA9IHRoaXMucnhTb2NrZXQuYWRkcmVzcygpXG5cdFx0XHRsb2dnZXIuZGVidWcoYFJYIHNvY2tldCBsaXN0ZW5pbmcgb24gJHtKU09OLnN0cmluZ2lmeShhZGRyKX1gKVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5yeFNvY2tldC5zZXRNdWx0aWNhc3RMb29wYmFjayh0cnVlKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBSWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ21lc3NhZ2UnLCAobXNnLCByaW5mbykgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5oYW5kbGVJbmNvbWluZyhtc2csIHJpbmZvLmFkZHJlc3MpXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRsb2dnZXIuZXJyb3IoYEVycm9yIGhhbmRsaW5nIGluY29taW5nIG1lc3NhZ2U6ICR7X2V9YClcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0Ly8gQmluZCB0byB3aWxkY2FyZCBzbyBrZXJuZWwgY2FuIGRlbGl2ZXIgbXVsdGljYXN0IHBhY2tldHMgZm9yIGpvaW5lZCBpbnRlcmZhY2VzLlxuXHRcdC8vIEFmdGVyIGJpbmRpbmcsIGVhZ2VybHkgam9pbiAyMjQuMC4wLjIzMSBvbiBldmVyeSBub24tbG9vcGJhY2sgSVB2NCBpbnRlcmZhY2Ugc29cblx0XHQvLyB0aGF0IHVuc29saWNpdGVkIENNRF9TRVRUSU5HU19QVVNIICgweDBiKSBwYWNrZXRzIGFyZSBub3QgbWlzc2VkIGJlZm9yZSB0aGVcblx0XHQvLyBmaXJzdCBvdXRnb2luZyBjb21tYW5kIHRyaWdnZXJzIHRoZSBsYXp5IGVuc3VyZU1lbWJlcnNoaXBGb3IoKSBqb2luLlxuXHRcdHRoaXMucnhTb2NrZXQuYmluZCh7IGFkZHJlc3M6ICcwLjAuMC4wJywgcG9ydDogdGhpcy5yeFBvcnQgfSwgKCkgPT4ge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCBzb2NrZXQgYm91bmQgdG8gMC4wLjAuMDoke3RoaXMucnhQb3J0fWApXG5cdFx0XHRjb25zdCBpZmFjZXMgPSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpIGFzIFJlY29yZDxzdHJpbmcsIGltcG9ydCgnb3MnKS5OZXR3b3JrSW50ZXJmYWNlSW5mb1tdPlxuXHRcdFx0Zm9yIChjb25zdCBhZGRycyBvZiBPYmplY3QudmFsdWVzKGlmYWNlcykpIHtcblx0XHRcdFx0Zm9yIChjb25zdCBhZGRyIG9mIGFkZHJzID8/IFtdKSB7XG5cdFx0XHRcdFx0aWYgKGFkZHIuZmFtaWx5ID09PSAnSVB2NCcgJiYgIWFkZHIuaW50ZXJuYWwgJiYgIXRoaXMuam9pbmVkSW50ZXJmYWNlcy5oYXMoYWRkci5hZGRyZXNzKSkge1xuXHRcdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdFx0dGhpcy5yeFNvY2tldC5hZGRNZW1iZXJzaGlwKHRoaXMubXVsdGljYXN0R3JvdXAsIGFkZHIuYWRkcmVzcylcblx0XHRcdFx0XHRcdFx0dGhpcy5qb2luZWRJbnRlcmZhY2VzLmFkZChhZGRyLmFkZHJlc3MpXG5cdFx0XHRcdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgUHJlLWpvaW5lZCBtdWx0aWNhc3QgJHt0aGlzLm11bHRpY2FzdEdyb3VwfSBvbiAke2FkZHIuYWRkcmVzc31gKVxuXHRcdFx0XHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oYENvdWxkIG5vdCBwcmUtam9pbiBtdWx0aWNhc3Qgb24gJHthZGRyLmFkZHJlc3N9OiAke1N0cmluZyhfZSl9YClcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0Ly8gRGlhZ25vc3RpYyBtdWx0aWNhc3Qgc29ja2V0IFx1MjAxNCBib3VuZCB0byB0aGUgbXVsdGljYXN0IGdyb3VwIGFkZHJlc3Mgc28gb25seVxuXHRcdC8vIG11bHRpY2FzdC1kZWxpdmVyZWQgcGFja2V0cyBhcnJpdmUgaGVyZS4gQW55IFN0dWRpby1UIHJlc3BvbnNlIHNlZW4gb24gdGhpc1xuXHRcdC8vIHNvY2tldCB3YXMgc2VudCB0byAyMjQuMC4wLjIzMTsgcmVzcG9uc2VzIHNlZW4gb25seSBvbiByeFNvY2tldCBhcmUgdW5pY2FzdC5cblx0XHR0aGlzLnJ4TWNhc3RTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXHRcdHRoaXMucnhNY2FzdFNvY2tldC5vbignZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHRsb2dnZXIuZGVidWcoYFJYIG1jYXN0IHNvY2tldCBlcnJvcjogJHtlcnIubWVzc2FnZX1gKVxuXHRcdH0pXG5cdFx0dGhpcy5yeE1jYXN0U29ja2V0Lm9uKCdtZXNzYWdlJywgKG1zZzogQnVmZmVyLCByaW5mbzogZGdyYW0uUmVtb3RlSW5mbykgPT4ge1xuXHRcdFx0aWYgKG1zZy5sZW5ndGggPCAyNSkgcmV0dXJuXG5cdFx0XHRpZiAobXNnWzBdICE9PSAweGZmIHx8IG1zZ1sxXSAhPT0gMHhmZikgcmV0dXJuXG5cdFx0XHRjb25zdCBzaWcgPSBtc2cuc3ViYXJyYXkoMTYsIDI0KVxuXHRcdFx0aWYgKHNpZy50b1N0cmluZygnYXNjaWknKSAhPT0gJ1N0dWRpby1UJykgcmV0dXJuXG5cdFx0XHRjb25zdCBzdFBheWxvYWQgPSBtc2cuc3ViYXJyYXkoMjQpXG5cdFx0XHRpZiAoc3RQYXlsb2FkLmxlbmd0aCA8IDIgfHwgc3RQYXlsb2FkWzBdICE9PSAweDVhKSByZXR1cm5cblx0XHRcdGNvbnN0IHJlc3BDbWRJZCA9IHN0UGF5bG9hZFsxXVxuXHRcdFx0Y29uc3QgaXNSZXNwb25zZSA9IChyZXNwQ21kSWQgJiAweDgwKSAhPT0gMFxuXHRcdFx0Y29uc3Qgb3JpZ2luYWxDbWRJZCA9IHJlc3BDbWRJZCAmIDB4N2Zcblx0XHRcdGlmIChpc1Jlc3BvbnNlKSB7XG5cdFx0XHRcdGNvbnN0IGtleSA9IGAke3JpbmZvLmFkZHJlc3N9OiR7b3JpZ2luYWxDbWRJZH1gXG5cdFx0XHRcdGNvbnN0IHdhc1VuaWNhc3RBbHJlYWR5ID0gIXRoaXMubWNhc3REZWxpdmVyaWVzLmhhcyhrZXkpXG5cdFx0XHRcdHRoaXMubWNhc3REZWxpdmVyaWVzLmFkZChrZXkpXG5cdFx0XHRcdGxvZ2dlci5kZWJ1Zyhcblx0XHRcdFx0XHRgTXVsdGljYXN0IGRlbGl2ZXJ5OiAke3JpbmZvLmFkZHJlc3N9IGNtZDoke3RvSGV4KG9yaWdpbmFsQ21kSWQpfWAgK1xuXHRcdFx0XHRcdFx0KHdhc1VuaWNhc3RBbHJlYWR5ID8gJyAodW5pY2FzdCBhbHNvIHBlbmRpbmcpJyA6ICcgKG11bHRpY2FzdCBvbmx5IHNvIGZhciknKSxcblx0XHRcdFx0KVxuXHRcdFx0XHQvLyBDbGVhbiB1cCB0aGUga2V5IGFmdGVyIGEgc2hvcnQgZGVsYXkgc28gd2UgZG9uJ3QgYWNjdW11bGF0ZSBzdGFsZSBlbnRyaWVzXG5cdFx0XHRcdHNldFRpbWVvdXQoKCkgPT4gdGhpcy5tY2FzdERlbGl2ZXJpZXMuZGVsZXRlKGtleSksIDUwMClcblx0XHRcdH1cblx0XHR9KVxuXHRcdHRoaXMucnhNY2FzdFNvY2tldC5iaW5kKHsgYWRkcmVzczogdGhpcy5tdWx0aWNhc3RHcm91cCwgcG9ydDogdGhpcy5yeFBvcnQgfSwgKCkgPT4ge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCBtY2FzdCBzb2NrZXQgYm91bmQgdG8gJHt0aGlzLm11bHRpY2FzdEdyb3VwfToke3RoaXMucnhQb3J0fWApXG5cdFx0fSlcblx0fVxuXG5cdHB1YmxpYyBjbG9zZSgpOiB2b2lkIHtcblx0XHQvLyBTdG9wIGFsbCBDb25Nb24ga2VlcGFsaXZlcyBhbmQgY2xvc2UgdGhlaXIgc29ja2V0cyBiZWZvcmUgY2xvc2luZyB0aGUgbWFpbiBzb2NrZXRzXG5cdFx0Zm9yIChjb25zdCBjbGVhbnVwIG9mIHRoaXMuX2Nvbm1vbkNsZWFudXBzLnZhbHVlcygpKSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjbGVhbnVwKClcblx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdH1cblx0XHR9XG5cdFx0dGhpcy5fY29ubW9uQ2xlYW51cHMuY2xlYXIoKVxuXHRcdHRyeSB7XG5cdFx0XHRmb3IgKGNvbnN0IGxvY2FsQWRkciBvZiBBcnJheS5mcm9tKHRoaXMuam9pbmVkSW50ZXJmYWNlcykpIHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHR0aGlzLnJ4U29ja2V0LmRyb3BNZW1iZXJzaGlwKHRoaXMubXVsdGljYXN0R3JvdXAsIGxvY2FsQWRkcilcblx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9IGNhdGNoIHtcblx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdH1cblx0XHR0cnkge1xuXHRcdFx0dGhpcy5yeE1jYXN0U29ja2V0Py5jbG9zZSgpXG5cdFx0XHR0aGlzLnJ4TWNhc3RTb2NrZXQgPSBudWxsXG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdFx0dHJ5IHtcblx0XHRcdHRoaXMucnhTb2NrZXQuY2xvc2UoKVxuXHRcdH0gY2F0Y2gge1xuXHRcdFx0LyogaWdub3JlICovXG5cdFx0fVxuXHRcdHRyeSB7XG5cdFx0XHR0aGlzLnR4U29ja2V0LmNsb3NlKClcblx0XHR9IGNhdGNoIHtcblx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBQcm92aWRlIHRoZSBhY3RpdmUgZGV2aWNlIG1vZGVsIGFuZCBhY3Rpb24gZGVmaW5pdGlvbnMgc28gaW5jb21pbmcgbWVzc2FnZXNcblx0ICogY2FuIGJlIGRlY29kZWQgaW50byBodW1hbi1yZWFkYWJsZSBuYW1lcy4gQ2FsbCBmcm9tIG1haW4udHMgYWZ0ZXIgY29uZmlnIGxvYWQuXG5cdCAqL1xuXHRwdWJsaWMgc2V0TW9kZWwobW9kZWw6IHN0cmluZywgYWN0aW9uczogU3RBY3Rpb25bXSk6IHZvaWQge1xuXHRcdHRoaXMubW9kZWwgPSBtb2RlbFxuXHRcdHRoaXMuYWN0aW9ucyA9IGFjdGlvbnNcblx0fVxuXG5cdC8qKlxuXHQgKiBTZXQgY2FsbGJhY2sgdG8gdHJpZ2dlciB3aGVuIGRldmljZSBzdGF0ZSBjaGFuZ2VzIChmb3IgZmVlZGJhY2tzKS5cblx0ICogQ2FsbCBmcm9tIG1haW4udHMgdG8gd2lyZSB1cCBjaGVja0ZlZWRiYWNrcy5cblx0ICovXG5cdHB1YmxpYyBzZXRGZWVkYmFja0NhbGxiYWNrKGNhbGxiYWNrOiAoZmVlZGJhY2tJZDogc3RyaW5nKSA9PiB2b2lkKTogdm9pZCB7XG5cdFx0dGhpcy5mZWVkYmFja0NhbGxiYWNrID0gY2FsbGJhY2tcblx0fVxuXG5cdC8qKiBSZXR1cm5zIHRydWUgaWYgdGhlIGRldmljZSBhdCB0aGUgZ2l2ZW4gSVAgaGFzIGJlZW4gYXV0aG9yaXplZCB0byByZWNlaXZlIGNvbW1hbmRzLiAqL1xuXHRwdWJsaWMgaXNEZXZpY2VBdXRob3JpemVkKGlwOiBzdHJpbmcpOiBib29sZWFuIHtcblx0XHRyZXR1cm4gdGhpcy5hdXRob3JpemVkSXBzLmhhcyhpcClcblx0fVxuXG5cdC8qKiBNYXJrIGFuIElQIGFzIHZlcmlmaWVkIGFuZCBhbGxvd2VkIHRvIHJlY2VpdmUgU3R1ZGlvLVQgY29tbWFuZHMuICovXG5cdHB1YmxpYyBhdXRob3JpemVEZXZpY2UoaXA6IHN0cmluZyk6IHZvaWQge1xuXHRcdHRoaXMuYXV0aG9yaXplZElwcy5hZGQoaXApXG5cdFx0bG9nZ2VyLmRlYnVnKGBBdXRob3JpemVkIGRldmljZSBhdCAke2lwfWApXG5cdH1cblxuXHQvKiogUmVtb3ZlIGF1dGhvcml6YXRpb24gZm9yIGFuIElQIChlLmcuIG9uIGNvbmZpZyBjaGFuZ2Ugb3IgbW9kZWwgbWlzbWF0Y2gpLiAqL1xuXHRwdWJsaWMgcmV2b2tlRGV2aWNlKGlwOiBzdHJpbmcpOiB2b2lkIHtcblx0XHR0aGlzLmF1dGhvcml6ZWRJcHMuZGVsZXRlKGlwKVxuXHRcdHRoaXMuZGV2aWNlU3RhdGUuZGVsZXRlKGlwKVxuXHRcdHRoaXMubWFjQ2FjaGUuZGVsZXRlKGlwKVxuXHRcdHRoaXMuc2Vzc2lvbkVzdGFibGlzaGVkLmRlbGV0ZShpcClcblx0XHR0aGlzLl9jb25tb25DbGVhbnVwcy5nZXQoaXApPy4oKVxuXHRcdHRoaXMuX2Nvbm1vbkNsZWFudXBzLmRlbGV0ZShpcClcblx0XHRsb2dnZXIuZGVidWcoYFJldm9rZWQgZGV2aWNlIGF0ICR7aXB9YClcblx0fVxuXG5cdC8qKlxuXHQgKiBPcGVucyBhIERhbnRlIENvbk1vbiBzZXNzaW9uIGZvciB0aGUgZGV2aWNlIGlmIFwidXNlQ29uTW9uXCI6IHRydWUgaXMgc2V0IGluIGl0c1xuXHQgKiBkZXZpY2UgSlNPTi4gQ2FjaGVzIHRoZSByZXN1bHQgc28gdGhlIGhhbmRzaGFrZSBvbmx5IHJ1bnMgb25jZSBwZXIgSVAuXG5cdCAqIERlbGVnYXRlcyB0byBjb25tb24udHMuIERldmljZXMgd2l0aG91dCB1c2VDb25Nb24gYXJlIG1hcmtlZCBhcyByZWFkeSBpbW1lZGlhdGVseS5cblx0ICovXG5cdHB1YmxpYyBhc3luYyBvcGVuU2Vzc2lvbihkZXZpY2VJcDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XG5cdFx0aWYgKHRoaXMuc2Vzc2lvbkVzdGFibGlzaGVkLmhhcyhkZXZpY2VJcCkpIHJldHVybiB0cnVlXG5cdFx0Y29uc3Qgc2NoZW1hID0gZ2V0RGV2aWNlU2NoZW1hKHRoaXMubW9kZWwpXG5cdFx0aWYgKCFzY2hlbWE/LnVzZUNvbk1vbikge1xuXHRcdFx0Ly8gRGV2aWNlIGRvZXMgbm90IHJlcXVpcmUgQ29uTW9uIFx1MjAxNCBza2lwIHNpbGVudGx5XG5cdFx0XHR0aGlzLnNlc3Npb25Fc3RhYmxpc2hlZC5hZGQoZGV2aWNlSXApXG5cdFx0XHRyZXR1cm4gdHJ1ZVxuXHRcdH1cblx0XHRjb25zdCBjbGVhbnVwID0gYXdhaXQgb3BlbkNvbk1vblNlc3Npb24oZGV2aWNlSXApXG5cdFx0Y29uc3Qgc3VjY2VzcyA9IGNsZWFudXAgIT09IG51bGxcblx0XHQvLyBNYXJrIGFzIGF0dGVtcHRlZCByZWdhcmRsZXNzIG9mIG91dGNvbWUgXHUyMDE0IHJldHJ5aW5nIGltbWVkaWF0ZWx5IHdvdWxkIGhpdCB0aGVcblx0XHQvLyBzYW1lIGJpbmQgZXJyb3IgKEVBRERSSU5VU0UpLiBEZXZpY2VzIHRoYXQgZG9uJ3QgbmVlZCBDb25Nb24gd29yayBmaW5lIHdpdGhvdXQgaXQuXG5cdFx0dGhpcy5zZXNzaW9uRXN0YWJsaXNoZWQuYWRkKGRldmljZUlwKVxuXHRcdGlmIChzdWNjZXNzKSB7XG5cdFx0XHR0aGlzLl9jb25tb25DbGVhbnVwcy5zZXQoZGV2aWNlSXAsIGNsZWFudXApXG5cdFx0fVxuXHRcdHJldHVybiBzdWNjZXNzXG5cdH1cblxuXHQvKipcblx0ICogU2VuZHMgYSB1bmljYXN0IERhbnRlIGluZm8gcmVxdWVzdCB0byBhIHNwZWNpZmljIElQIGFuZCB3YWl0cyBmb3IgdGhlXG5cdCAqIGRldmljZSBpbmZvIHJlc3BvbnNlLiBSZXR1cm5zIHRoZSBEZXZpY2VJbmZvIGlmIHRoZSBkZXZpY2UgcmVzcG9uZHMgd2l0aGluXG5cdCAqIHRpbWVvdXRNcywgb3IgbnVsbCBpZiBubyByZXNwb25zZS4gVXNlZCB0byB2ZXJpZnkgYSBtYW51YWxseSBjb25maWd1cmVkIElQLlxuXHQgKiBEb2VzIE5PVCByZXF1aXJlIGF1dGhvcml6YXRpb24gXHUyMDE0IHRoaXMgaXMgaG93IGF1dGhvcml6YXRpb24gaXMgZXN0YWJsaXNoZWQuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgcHJvYmVEZXZpY2UoaXA6IHN0cmluZywgdGltZW91dE1zID0gMzAwMCk6IFByb21pc2U8RGV2aWNlSW5mbyB8IG51bGw+IHtcblx0XHRhd2FpdCB0aGlzLnR4UmVhZHlcblx0XHRyZXR1cm4gZGFudGVQcm9iZURldmljZShcblx0XHRcdHRoaXMudHhTb2NrZXQsXG5cdFx0XHQoa2V5LCBjYikgPT4gdGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuc2V0KGtleSwgY2IpLFxuXHRcdFx0KGtleSkgPT4gdGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuZGVsZXRlKGtleSksXG5cdFx0XHRhc3luYyAoZGVzdElwKSA9PiB0aGlzLmVuc3VyZU1lbWJlcnNoaXBGb3IoZGVzdElwKSxcblx0XHRcdGlwLFxuXHRcdFx0dGltZW91dE1zLFxuXHRcdClcblx0fVxuXG5cdC8qKlxuXHQgKiBTZW5kIGEgQ01EX0dFVF9BTExfU0VUVElOR1MgKDB4MGEpIHJlcXVlc3QgdG8gdGhlIGRldmljZSBhbmQgc3RvcmUgdGhlIHJlc3BvbnNlXG5cdCAqIGluIGRldmljZVN0YXRlLiBSZXR1cm5zIHRoZSByYXcgcmVzcG9uc2UgYnVmZmVyIGZvciBwYXJzaW5nLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIHJlcXVlc3RBbGxTZXR0aW5ncyhkZXZpY2VJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRsb2dnZXIuaW5mbyhgUmVxdWVzdGluZyBhbGwgc2V0dGluZ3MgZnJvbSAke2RldmljZUlwfWApXG5cdFx0Y29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLnNlbmRBd2FpdEFjayhDTURfR0VUX0FMTF9TRVRUSU5HUywgdW5kZWZpbmVkLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgZGV2aWNlSXAsIGZhbHNlKVxuXHRcdC8vIGRldmljZVN0YXRlIGlzIHBvcHVsYXRlZCBieSBsb2dTdFBheWxvYWQgd2hlbiB0aGUgQ01EX0dFVF9BTExfU0VUVElOR1MgcmVzcG9uc2UgYXJyaXZlc1xuXHRcdHJldHVybiByZXNwb25zZVxuXHR9XG5cblx0LyoqXG5cdCAqIERpc2NvdmVycyBTdHVkaW8gVGVjaG5vbG9naWVzIERhbnRlIGRldmljZXMgb24gdGhlIGxvY2FsIG5ldHdvcmsuXG5cdCAqXG5cdCAqIExpc3RlbnMgZm9yIERhbnRlIGFubm91bmNlcyBvbiAyMjQuMC4wLjIzMzo4NzA4LCBzZW5kcyB1bmljYXN0IGluZm8gcmVxdWVzdHNcblx0ICogdG8gZWFjaCBkaXNjb3ZlcmVkIElQLCBhbmQgY29sbGVjdHMgMHgwMTcwIHJlc3BvbnNlcyB2aWEgdGhlIHJ4U29ja2V0LlxuXHQgKi9cblx0cHVibGljIGFzeW5jIGRpc2NvdmVyRGV2aWNlcyh0aW1lb3V0TXMgPSA1MDAwKTogUHJvbWlzZTxEZXZpY2VJbmZvW10+IHtcblx0XHRjb25zdCBESVNDT1ZFUllfS0VZID0gJ19fZGlzY292ZXJ5X18nXG5cdFx0Y29uc3QgZm91bmREZXZpY2VzOiBEZXZpY2VJbmZvW10gPSBbXVxuXG5cdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuc2V0KERJU0NPVkVSWV9LRVksIChkZXZpY2U6IERldmljZUluZm8pID0+IHtcblx0XHRcdGlmICghZm91bmREZXZpY2VzLnNvbWUoKGQpID0+IGQuaXAgPT09IGRldmljZS5pcCkpIHtcblx0XHRcdFx0Zm91bmREZXZpY2VzLnB1c2goZGV2aWNlKVxuXHRcdFx0fVxuXHRcdH0pXG5cblx0XHR0cnkge1xuXHRcdFx0YXdhaXQgdGhpcy50eFJlYWR5XG5cdFx0XHRhd2FpdCBkaXNjb3ZlckRldmljZXModGhpcy50eFNvY2tldCwgYXN5bmMgKGRlc3RJcCkgPT4gdGhpcy5lbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcCksIHRpbWVvdXRNcylcblx0XHRcdHJldHVybiBmb3VuZERldmljZXNcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuZGVsZXRlKERJU0NPVkVSWV9LRVkpXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIFJlcXVlc3RzIGRldmljZSBmaXJtd2FyZSB2ZXJzaW9uIHZpYSBTdHVkaW8tVCBwcm90b2NvbCAoQ01EX0dFVF9GSVJNV0FSRSkuXG5cdCAqIFJldHVybnMgdGhlIGZpcm13YXJlIHZlcnNpb24gc3RyaW5nIChlLmcuLCBcIjMuMDFcIiwgXCIyLjJcIiwgXCIxLjA1XCIpLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIHJlcXVlc3RGaXJtd2FyZVZlcnNpb24oZGV2aWNlSXA6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG5cdFx0bG9nZ2VyLmluZm8oYFJlcXVlc3RpbmcgZmlybXdhcmUgdmVyc2lvbiBmcm9tICR7ZGV2aWNlSXB9YClcblx0XHRjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuc2VuZEF3YWl0QWNrKENNRF9HRVRfRklSTVdBUkUsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIGRldmljZUlwLCBmYWxzZSlcblxuXHRcdC8vIFJlc3BvbnNlIHN0cnVjdHVyZTogW2hlYWRlcl0gMHg1YSAweDgwIFtmaXJtd2FyZV9kYXRhXSBDUkNcblx0XHQvLyBGaXJtd2FyZSBkYXRhIHN0YXJ0cyBhdCBieXRlIDI2ICgyNC1ieXRlIGhlYWRlciArIDB4NWEgKyAweDgwKVxuXHRcdGNvbnN0IGRhdGFTdGFydCA9IDI2XG5cblx0XHRpZiAocmVzcG9uc2UubGVuZ3RoIDwgZGF0YVN0YXJ0ICsgMykge1xuXHRcdFx0bG9nZ2VyLndhcm4oYEZpcm13YXJlIHJlc3BvbnNlIHRvbyBzaG9ydDogJHtyZXNwb25zZS5sZW5ndGh9IGJ5dGVzYClcblx0XHRcdHJldHVybiAnVW5rbm93bidcblx0XHR9XG5cblx0XHQvLyBGaXJtd2FyZSBmb3JtYXQ6IFt1bmtub3duX2J5dGUsIG1ham9yLCBtaW5vcl1cblx0XHRjb25zdCBtYWpvciA9IHJlc3BvbnNlW2RhdGFTdGFydCArIDFdXG5cdFx0Y29uc3QgbWlub3IgPSByZXNwb25zZVtkYXRhU3RhcnQgKyAyXVxuXG5cdFx0Y29uc3QgbWlub3JTdHIgPVxuXHRcdFx0bWlub3IgPCAxMFxuXHRcdFx0XHQ/IG1pbm9yLnRvU3RyaW5nKCkucGFkU3RhcnQoMiwgJzAnKSAvLyBlLmcuIDEgXHUyMTkyIFwiMDFcIiwgNSBcdTIxOTIgXCIwNVwiXG5cdFx0XHRcdDogbWlub3IudG9TdHJpbmcoKSAvLyBlLmcuIDEwIFx1MjE5MiBcIjEwXCJcblxuXHRcdGNvbnN0IGZpcm13YXJlID0gYCR7bWFqb3J9LiR7bWlub3JTdHJ9YFxuXG5cdFx0bG9nZ2VyLmRlYnVnKGBGaXJtd2FyZSB2ZXJzaW9uOiAke2Zpcm13YXJlfWApXG5cdFx0cmV0dXJuIGZpcm13YXJlXG5cdH1cblxuXHQvKipcblx0ICogSm9pbnMgdGhlIG11bHRpY2FzdCByZXNwb25zZSBncm91cCBvbiB0aGUgaW50ZXJmYWNlIHRoYXQgcm91dGVzIHRvIGRlc3RJcC5cblx0ICogT25seSBqb2lucyB0aGUgc3BlY2lmaWMgaW50ZXJmYWNlIHVzZWQgdG8gcmVhY2ggdGhlIGRldmljZSwgYW5kIG9ubHkgb25jZSBwZXIgaW50ZXJmYWNlLlxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyBlbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IGxvY2FsQWRkciA9IGF3YWl0IGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uKGRlc3RJcClcblx0XHRcdGlmICghbG9jYWxBZGRyKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3QgZGV0ZXJtaW5lIGxvY2FsIGFkZHJlc3MgZm9yIGRlc3RpbmF0aW9uICR7ZGVzdElwfWApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHRpZiAodGhpcy5qb2luZWRJbnRlcmZhY2VzLmhhcyhsb2NhbEFkZHIpKSB7XG5cdFx0XHRcdC8vIGFscmVhZHkgam9pbmVkXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHR0cnkge1xuXHRcdFx0XHR0aGlzLnJ4U29ja2V0LmFkZE1lbWJlcnNoaXAodGhpcy5tdWx0aWNhc3RHcm91cCwgbG9jYWxBZGRyKVxuXHRcdFx0XHR0aGlzLmpvaW5lZEludGVyZmFjZXMuYWRkKGxvY2FsQWRkcilcblx0XHRcdFx0bG9nZ2VyLmluZm8oYEpvaW5lZCBtdWx0aWNhc3QgJHt0aGlzLm11bHRpY2FzdEdyb3VwfSBvbiAke2xvY2FsQWRkcn1gKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYEZhaWxlZCB0byBqb2luIG11bHRpY2FzdCBvbiAke2xvY2FsQWRkcn06ICR7U3RyaW5nKF9lKX1gKVxuXHRcdFx0fVxuXHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRsb2dnZXIud2FybihgZW5zdXJlTWVtYmVyc2hpcEZvciBmYWlsZWQ6ICR7X2V9YClcblx0XHR9XG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgc2VuZEF3YWl0QWNrKFxuXHRcdGNtZElkOiBudW1iZXIsXG5cdFx0YnVzQ2g6IG51bWJlciB8IHVuZGVmaW5lZCxcblx0XHRzZXR0aW5nSWQ6IG51bWJlciB8IHVuZGVmaW5lZCxcblx0XHR2YWx1ZTogdW5rbm93bixcblx0XHRkZXN0SXA6IHN0cmluZyxcblx0XHRhZGRMZW4gPSB0cnVlLFxuXHQpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudCsrXG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlPEJ1ZmZlcj4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdFx0dGhpcy5zZW5kUXVldWUgPSB0aGlzLnNlbmRRdWV1ZS50aGVuKGFzeW5jICgpID0+XG5cdFx0XHRcdHRoaXMuX3NlbmRBd2FpdEFjayhjbWRJZCwgYnVzQ2gsIHNldHRpbmdJZCwgdmFsdWUsIGRlc3RJcCwgYWRkTGVuKVxuXHRcdFx0XHRcdC50aGVuKChidWYpID0+IHtcblx0XHRcdFx0XHRcdHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudC0tXG5cdFx0XHRcdFx0XHQvLyBPbmx5IHRyaWdnZXIgcmVxdWVzdEFsbFNldHRpbmdzIGFmdGVyIGEgd3JpdGUgKFNFVCkgY29tbWFuZCwgbm90IGEgcmVhZC9wb2xsLlxuXHRcdFx0XHRcdFx0Ly8gQSB3cml0ZSBhbHdheXMgaGFzIGEgdmFsdWU7IHJlYWRzIChHRVQsIEJVU19HRVQpIG5ldmVyIGRvLlxuXHRcdFx0XHRcdFx0aWYgKHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudCA9PT0gMCAmJiB2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0XHRcdHRoaXMucmVxdWVzdEFsbFNldHRpbmdzKGRlc3RJcCkuY2F0Y2goKGVycikgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gcmVmcmVzaCBzZXR0aW5ncyBhZnRlciBjb21tYW5kOiAke2Vycn1gKVxuXHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0cmVzb2x2ZShidWYpXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0XHQuY2F0Y2goKGVycikgPT4ge1xuXHRcdFx0XHRcdFx0dGhpcy5wZW5kaW5nQ29tbWFuZENvdW50LS1cblx0XHRcdFx0XHRcdHJlamVjdChlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyciA6IG5ldyBFcnJvcihTdHJpbmcoZXJyKSkpXG5cdFx0XHRcdFx0fSksXG5cdFx0XHQpXG5cdFx0fSlcblx0fVxuXG5cdHByaXZhdGUgYXN5bmMgX3NlbmRBd2FpdEFjayhcblx0XHRjbWRJZDogbnVtYmVyLFxuXHRcdGJ1c0NoOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0c2V0dGluZ0lkOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0dmFsdWU6IHVua25vd24sXG5cdFx0ZGVzdElwOiBzdHJpbmcsXG5cdFx0YWRkTGVuID0gdHJ1ZSxcblx0KTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRjb25zdCB0aW1lb3V0TXMgPSAyMDAwXG5cblx0XHRjb25zdCBkYXRhQmxvY2s6IG51bWJlcltdID0gW11cblx0XHRpZiAoc2V0dGluZ0lkICE9PSB1bmRlZmluZWQpIGRhdGFCbG9jay5wdXNoKHNldHRpbmdJZCAmIDB4ZmYpXG5cdFx0aWYgKHZhbHVlICE9PSB1bmRlZmluZWQpIGRhdGFCbG9jay5wdXNoKC4uLlN0Q29udHJvbGxlci5idWlsZFZhbHVlQnl0ZXModmFsdWUpKVxuXG5cdFx0Y29uc3QgcGF5bG9hZEJvZHk6IG51bWJlcltdID0gWzB4NWEsIGNtZElkICYgMHhmZl1cblxuXHRcdGlmIChjbWRJZCA9PT0gQ01EX01JQ19QUkUgJiYgYnVzQ2ggIT09IHVuZGVmaW5lZCAmJiBzZXR0aW5nSWQgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHQvLyBQb3NpdGlvbmFsIGZvcm1hdDogWzB4NWFdIFsweDAyXSBbYnVzQ2hdIFt2YWwwXSBbdmFsMV0gW3ZhbDJdIC4uLlxuXHRcdFx0Ly8gUmVhZCBhbGwgcG9zaXRpb25zIGZyb20gZGV2aWNlU3RhdGUsIG92ZXJyaWRlIHRoZSB0YXJnZXQgcG9zaXRpb24gd2l0aCBuZXcgdmFsdWUuXG5cdFx0XHQvLyBBbHNvIHVwZGF0ZSBkZXZpY2VTdGF0ZSBvcHRpbWlzdGljYWxseSBzbyBjb25zZWN1dGl2ZSBDTURfTUlDX1BSRSBjb21tYW5kcyBjaGFpbiBjb3JyZWN0bHkuXG5cdFx0XHRpZiAoIXRoaXMuZGV2aWNlU3RhdGUuaGFzKGRlc3RJcCkpIHRoaXMuZGV2aWNlU3RhdGUuc2V0KGRlc3RJcCwgbmV3IE1hcCgpKVxuXHRcdFx0Y29uc3QgaXBTdGF0ZSA9IHRoaXMuZGV2aWNlU3RhdGUuZ2V0KGRlc3RJcCkhXG5cdFx0XHRjb25zdCBudW1Qb3NpdGlvbnMgPSAzIC8vIGdhaW4sIGVsZWN0cmV0L3BoYW50b20sIHVua25vd25cblx0XHRcdGNvbnN0IHBvc2l0aW9uczogbnVtYmVyW10gPSBbXVxuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBudW1Qb3NpdGlvbnM7IGkrKykge1xuXHRcdFx0XHRjb25zdCBzdGF0ZUtleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgQ01EX01JQ19QUkUsIGksIGJ1c0NoKVxuXHRcdFx0XHRjb25zdCB2YWwgPSBpID09PSBzZXR0aW5nSWQgPyBOdW1iZXIodmFsdWUpIDogKGlwU3RhdGUuZ2V0KHN0YXRlS2V5KSA/PyAwKVxuXHRcdFx0XHRwb3NpdGlvbnMucHVzaCh2YWwpXG5cdFx0XHRcdGlwU3RhdGUuc2V0KHN0YXRlS2V5LCB2YWwpIC8vIG9wdGltaXN0aWMgdXBkYXRlXG5cdFx0XHR9XG5cdFx0XHRwYXlsb2FkQm9keS5wdXNoKGJ1c0NoICYgMHhmZiwgLi4ucG9zaXRpb25zKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkgcGF5bG9hZEJvZHkucHVzaChidXNDaCAmIDB4ZmYpXG5cdFx0XHRpZiAoYWRkTGVuKSBwYXlsb2FkQm9keS5wdXNoKGRhdGFCbG9jay5sZW5ndGgpXG5cdFx0XHRpZiAoZGF0YUJsb2NrLmxlbmd0aCA+IDApIHBheWxvYWRCb2R5LnB1c2goLi4uZGF0YUJsb2NrKVxuXHRcdH1cblxuXHRcdGNvbnN0IGNyYyA9IFN0Q29udHJvbGxlci5jcmM4RHZiUzIocGF5bG9hZEJvZHkpXG5cdFx0Y29uc3QgcGF5bG9hZFdpdGhDcmMgPSBCdWZmZXIuZnJvbShbLi4ucGF5bG9hZEJvZHksIGNyY10pXG5cblx0XHQvLyBIdW1hbi1yZWFkYWJsZSBpbmZvIGxvZyBmb3IgdGhlIG91dGdvaW5nIGNvbW1hbmRcblx0XHRpZiAoc2V0dGluZ0lkICE9PSB1bmRlZmluZWQgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IFN0Q29udHJvbGxlci5idWlsZFZhbHVlQnl0ZXModmFsdWUpXG5cdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0ge1xuXHRcdFx0XHRjbWRfaWQ6IGNtZElkLFxuXHRcdFx0XHRpZDogc2V0dGluZ0lkLFxuXHRcdFx0XHRidXNDaCxcblx0XHRcdFx0dmFsdWVCeXRlcyxcblx0XHRcdH1cblx0XHRcdGxvZ2dlci5pbmZvKGBUWCAke2Rlc3RJcH0gfCAke2Zvcm1hdFBhcnNlZFNldHRpbmcoc2V0dGluZywgdGhpcy5hY3Rpb25zKX1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgVFggJHtkZXN0SXB9IHwgJHtnZXRDb21tYW5kTmFtZShjbWRJZCl9YClcblx0XHR9XG5cblx0XHQvLyBSZWplY3QgY29tbWFuZHMgdG8gdW52ZXJpZmllZCBkZXZpY2VzIFx1MjAxNCBsb2cgdGhlIHdvdWxkLWJlIHBhY2tldCBmaXJzdCBhdCBkZWJ1Z1xuXHRcdC8vIHNvIHRoZSBieXRlcyBhcmUgdmlzaWJsZSBldmVuIHdoZW4gdGhlIGRldmljZSBpcyBvZmZsaW5lLlxuXHRcdGlmICghdGhpcy5hdXRob3JpemVkSXBzLmhhcyhkZXN0SXApKSB7XG5cdFx0XHRsb2dnZXIuZGVidWcoYFBhY2tldCAobm90IHNlbnQgXHUyMDE0IGRldmljZSBub3QgYXV0aG9yaXplZCkgdG8gJHtkZXN0SXB9OiAke3BheWxvYWRXaXRoQ3JjLnRvU3RyaW5nKCdoZXgnKX1gKVxuXHRcdFx0dGhyb3cgbmV3IEVycm9yKGBEZXZpY2UgYXQgJHtkZXN0SXB9IGlzIG5vdCBhdXRob3JpemVkIFx1MjAxNCB2ZXJpZnkgdGhlIElQIGFuZCBtb2RlbCBtYXRjaCBiZWZvcmUgc2VuZGluZyBjb21tYW5kc2ApXG5cdFx0fVxuXG5cdFx0Ly8gSWYgXCJ1c2VDb25Nb25cIiBpcyBzZXQgaW4gdGhlIGRldmljZSBKU09OLCBlbnN1cmUgdGhlIERhbnRlIENvbk1vbiBzZXNzaW9uXG5cdFx0Ly8gKHBvcnQgODgwMCkgaXMgb3BlbiBiZWZvcmUgc2VuZGluZy4gb3BlblNlc3Npb24oKSBjYWNoZXMgdGhlIHJlc3VsdCBcdTIwMTQgdGhlXG5cdFx0Ly8gaGFuZHNoYWtlIG9ubHkgcnVucyBvbmNlIHBlciBJUC4gTm9uLXVzZUNvbk1vbiBkZXZpY2VzIGFyZSBtYXJrZWQgcmVhZHkgaW1tZWRpYXRlbHkuXG5cdFx0aWYgKCF0aGlzLnNlc3Npb25Fc3RhYmxpc2hlZC5oYXMoZGVzdElwKSkge1xuXHRcdFx0YXdhaXQgdGhpcy5vcGVuU2Vzc2lvbihkZXN0SXApXG5cdFx0XHQvLyBTZXNzaW9uIGZhaWx1cmUgaXMgbm9uLWZhdGFsIFx1MjAxNCBtYW55IGRldmljZXMgcmVzcG9uZCB0byBTdHVkaW8tVCByZWdhcmRsZXNzLlxuXHRcdH1cblxuXHRcdC8vIEVuc3VyZSB3ZSBhcmUgbGlzdGVuaW5nIGZvciByZXBsaWVzIG9uIHRoZSBpbnRlcmZhY2UgdGhhdCB3aWxsIHJlY2VpdmUgdGhlbVxuXHRcdGF3YWl0IHRoaXMuZW5zdXJlTWVtYmVyc2hpcEZvcihkZXN0SXApXG5cblx0XHRjb25zdCB0b3RhbExlbiA9IDI0ICsgcGF5bG9hZFdpdGhDcmMubGVuZ3RoXG5cdFx0Y29uc3QgaGVhZGVyID0gYXdhaXQgdGhpcy5idWlsZEhlYWRlcih0b3RhbExlbiwgZGVzdElwKVxuXHRcdGNvbnN0IHBhY2tldCA9IEJ1ZmZlci5jb25jYXQoW2hlYWRlciwgcGF5bG9hZFdpdGhDcmNdKVxuXG5cdFx0bG9nZ2VyLmRlYnVnKGBTZW5kaW5nIHBhY2tldCB0byAke2Rlc3RJcH06ICR7cGFja2V0LnRvU3RyaW5nKCdoZXgnKX1gKVxuXG5cdFx0Y29uc3Qga2V5ID0gYCR7ZGVzdElwfToke2NtZElkfWBcblxuXHRcdHJldHVybiBuZXcgUHJvbWlzZTxCdWZmZXI+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHRcdHRoaXMucGVuZGluZ0Fja3MuZGVsZXRlKGtleSlcblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihgVGltZW91dCB3YWl0aW5nIGZvciBBQ0sgZnJvbSBNb2RlbCAke3RoaXMubW9kZWx9IGF0ICR7ZGVzdElwfTo4NzAwYCkpXG5cdFx0XHR9LCB0aW1lb3V0TXMpXG5cblx0XHRcdHRoaXMucGVuZGluZ0Fja3Muc2V0KGtleSwge1xuXHRcdFx0XHRyZXNvbHZlOiAoYnVmKSA9PiB7XG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdHJlc29sdmUoYnVmKVxuXHRcdFx0XHR9LFxuXHRcdFx0XHRyZWplY3Q6IChlcnIpID0+IHtcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0cmVqZWN0KGVycilcblx0XHRcdFx0fSxcblx0XHRcdFx0dGltZXIsXG5cdFx0XHR9KVxuXG5cdFx0XHR0aGlzLnR4U29ja2V0LnNlbmQocGFja2V0LCB0aGlzLmRlZmF1bHRQb3J0LCBkZXN0SXAsIChlcnIpID0+IHtcblx0XHRcdFx0aWYgKGVycikge1xuXHRcdFx0XHRcdHRoaXMucGVuZGluZ0Fja3MuZGVsZXRlKGtleSlcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0XHRcdH1cblx0XHRcdH0pXG5cdFx0fSlcblx0fVxuXG5cdHByaXZhdGUgaGFuZGxlSW5jb21pbmcobXNnOiBCdWZmZXIsIHNyY0lwOiBzdHJpbmcpIHtcblx0XHRpZiAobXNnLmxlbmd0aCA8IDQpIHJldHVyblxuXHRcdGlmIChtc2dbMF0gIT09IDB4ZmYgfHwgbXNnWzFdICE9PSAweGZmKSByZXR1cm5cblxuXHRcdGNvbnN0IG1zZ1R5cGUgPSBtc2cucmVhZFVJbnQxNkJFKDIpXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgRGFudGUgZGV2aWNlIGluZm8gcmVzcG9uc2UgKDB4MDE3MCkgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gVGhlc2UgaGF2ZSBcIkF1ZGluYXRlXCIgYXQgb2Zmc2V0IDE2LCBub3QgXCJTdHVkaW8tVFwiIFx1MjAxNCBoYW5kbGUgYmVmb3JlXG5cdFx0Ly8gdGhlIFN0dWRpby1UIHNpZ25hdHVyZSBjaGVjayBiZWxvdy5cblx0XHRpZiAobXNnVHlwZSA9PT0gREFOVEVfTVNHX0lORk9fUkVTUE9OU0UgJiYgdGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuc2l6ZSA+IDApIHtcblx0XHRcdGNvbnN0IGRldmljZSA9IHBhcnNlRGFudGVJbmZvUmVzcG9uc2UobXNnLCBzcmNJcClcblx0XHRcdGlmIChkZXZpY2UpIHtcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKFxuXHRcdFx0XHRcdGBEYW50ZSBpbmZvIHJlc3BvbnNlIGZyb20gJHtzcmNJcH06IGAgK1xuXHRcdFx0XHRcdFx0YERldmljZUlEPVwiJHtkZXZpY2UubmFtZX1cIiwgYCArXG5cdFx0XHRcdFx0XHRgTW9kZWw9XCIke2RldmljZS5tb2RlbH1cIiwgYCArXG5cdFx0XHRcdFx0XHRgTW9kZWxOYW1lPVwiJHtkZXZpY2UubW9kZWxOYW1lfVwiLCBgICtcblx0XHRcdFx0XHRcdGBNYW51ZmFjdHVyZXI9XCIke2RldmljZS5tYW51ZmFjdHVyZXJ9XCJgLFxuXHRcdFx0XHQpXG5cblx0XHRcdFx0Ly8gT25seSBhY2NlcHQgU3R1ZGlvIFRlY2hub2xvZ2llcyBkZXZpY2VzIChpZGVudGlmaWVkIGJ5IERldmljZUlEIFwiU3R1ZGlvLVRcIilcblx0XHRcdFx0aWYgKGRldmljZS5uYW1lID09PSAnU3R1ZGlvLVQnKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBjYiBvZiB0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy52YWx1ZXMoKSkge1xuXHRcdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdFx0Y2IoZGV2aWNlKVxuXHRcdFx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRsb2dnZXIuZGVidWcoYElnbm9yaW5nIG5vbi1TdHVkaW8gVGVjaG5vbG9naWVzIGRldmljZTogRGV2aWNlSUQ9XCIke2RldmljZS5uYW1lfVwiIEAgJHtzcmNJcH1gKVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRpZiAobXNnLmxlbmd0aCA8IDI1KSByZXR1cm5cblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBTdHVkaW8tVCBjb250cm9sIHByb3RvY29sIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdGNvbnN0IHNpZyA9IG1zZy5zdWJhcnJheSgxNiwgMjQpXG5cdFx0aWYgKHNpZy50b1N0cmluZygnYXNjaWknKSAhPT0gJ1N0dWRpby1UJykgcmV0dXJuXG5cblx0XHQvLyBJZ25vcmUgU3R1ZGlvLVQgcGFja2V0cyBmcm9tIGRldmljZXMgd2UgaGF2ZW4ndCBhdXRob3JpemVkLlxuXHRcdC8vIFRoaXMgcHJldmVudHMgY3Jvc3MtY29udGFtaW5hdGlvbiB3aGVuIG11bHRpcGxlIGRldmljZXMgKG9yIG11bHRpcGxlXG5cdFx0Ly8gQ29tcGFuaW9uIGluc3RhbmNlcykgYXJlIG9uIHRoZSBzYW1lIG5ldHdvcmsgXHUyMDE0IGFsbCBzaGFyZSB0aGUgbXVsdGljYXN0XG5cdFx0Ly8gZ3JvdXAgMjI0LjAuMC4yMzE6ODcwMiBhbmQgd2lsbCByZWNlaXZlIGVhY2ggb3RoZXIncyBBQ0tzIGFuZCBwdXNoZXMuXG5cdFx0aWYgKCF0aGlzLmF1dGhvcml6ZWRJcHMuaGFzKHNyY0lwKSkge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBJZ25vcmluZyBTdHVkaW8tVCBwYWNrZXQgZnJvbSB1bmF1dGhvcml6ZWQgZGV2aWNlICR7c3JjSXB9YClcblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdC8vIFBheWxvYWQgc3RhcnRzIGF0IG9mZnNldCAyNFxuXHRcdC8vIExheW91dDogWzB4NWFdIFtjbWRJZHwweDgwXSBbZGF0YS4uLl0gW2NyY11cblx0XHRjb25zdCBzdFBheWxvYWQgPSBtc2cuc3ViYXJyYXkoMjQpXG5cdFx0aWYgKHN0UGF5bG9hZC5sZW5ndGggPCAyKSByZXR1cm5cblx0XHRpZiAoc3RQYXlsb2FkWzBdICE9PSAweDVhKSByZXR1cm5cblxuXHRcdC8vIERldmljZSByZXBsaWVzIHdpdGggY21kIHwgMHg4MFxuXHRcdGNvbnN0IHJlc3BDbWRJZCA9IHN0UGF5bG9hZFsxXVxuXHRcdGNvbnN0IGlzUmVzcG9uc2UgPSAocmVzcENtZElkICYgMHg4MCkgIT09IDBcblx0XHRjb25zdCBvcmlnaW5hbENtZElkID0gcmVzcENtZElkICYgMHg3ZiAvLyBzdHJpcCB0aGUgcmVzcG9uc2UgZmxhZ1xuXG5cdFx0Ly8gUmVzcG9uc2VzIGFyZSBkZWxpdmVyZWQgdG8gYm90aCB1bmljYXN0IGFuZCBtdWx0aWNhc3QgMjI0LjAuMC4yMzE6ODcwMi5cblx0XHQvLyBXaXRoIHR3byBqb2luZWQgaW50ZXJmYWNlcyB0aGUgcnhTb2NrZXQgcmVjZWl2ZXMgZWFjaCByZXNwb25zZSB0d2ljZS5cblx0XHQvLyBHYXRlIGxvZ2dpbmcgYW5kIEFDSyByZXNvbHV0aW9uIG9uIHRoZSBmaXJzdCBkZWxpdmVyeSAocGVuZGluZyBBQ0sgcHJlc2VudCkuXG5cdFx0Ly8gQ01EX1NFVFRJTkdTX1BVU0ggKDB4MGIpIGlzIHVuc29saWNpdGVkIFx1MjAxNCBhbHdheXMgbG9nIGl0LlxuXHRcdGlmIChpc1Jlc3BvbnNlKSB7XG5cdFx0XHRjb25zdCBrZXkgPSBgJHtzcmNJcH06JHtvcmlnaW5hbENtZElkfWBcblx0XHRcdGNvbnN0IHBlbmRpbmcgPSB0aGlzLnBlbmRpbmdBY2tzLmdldChrZXkpXG5cdFx0XHRpZiAocGVuZGluZykge1xuXHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdGNvbnN0IHZpYU11bHRpY2FzdCA9IHRoaXMubWNhc3REZWxpdmVyaWVzLmhhcyhrZXkpXG5cdFx0XHRcdGxvZ2dlci5kZWJ1Zyhcblx0XHRcdFx0XHRgUlggZGVsaXZlcnkgbWV0aG9kOiAke3NyY0lwfSBjbWQ6JHt0b0hleChvcmlnaW5hbENtZElkKX0gdmlhICR7dmlhTXVsdGljYXN0ID8gJ211bHRpY2FzdCcgOiAndW5pY2FzdCd9YCxcblx0XHRcdFx0KVxuXHRcdFx0XHRpZiAob3JpZ2luYWxDbWRJZCA9PT0gQ01EX0dFVF9BTExfU0VUVElOR1MpIHtcblx0XHRcdFx0XHRsb2dnZXIuZGVidWcoYFJlY2VpdmVkIHBhY2tldCBmcm9tICR7c3JjSXB9OiAke21zZy50b1N0cmluZygnaGV4Jyl9YClcblx0XHRcdFx0fVxuXHRcdFx0XHR0aGlzLmxvZ1N0UGF5bG9hZChzcmNJcCwgb3JpZ2luYWxDbWRJZCwgbXNnLCBzdFBheWxvYWQpXG5cdFx0XHRcdHBlbmRpbmcucmVzb2x2ZShtc2cpXG5cdFx0XHR9IGVsc2UgaWYgKG9yaWdpbmFsQ21kSWQgPT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0XHRcdC8vIFVuc29saWNpdGVkIHB1c2ggXHUyMDE0IGFsd2F5cyBsb2dcblx0XHRcdFx0dGhpcy5sb2dTdFBheWxvYWQoc3JjSXAsIG9yaWdpbmFsQ21kSWQsIG1zZywgc3RQYXlsb2FkKVxuXHRcdFx0fVxuXHRcdFx0Ly8gZWxzZTogZHVwbGljYXRlIG11bHRpY2FzdCBkZWxpdmVyeSBcdTIwMTQgc3VwcHJlc3Ncblx0XHR9IGVsc2Uge1xuXHRcdFx0Ly8gT3V0Z29pbmcgY29tbWFuZCBlY2hvIG9yIHVuc29saWNpdGVkIHJlcXVlc3QgZnJvbSBkZXZpY2Vcblx0XHRcdHRoaXMubG9nU3RQYXlsb2FkKHNyY0lwLCBvcmlnaW5hbENtZElkLCBtc2csIHN0UGF5bG9hZClcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogRGVjb2RlcyBhbmQgbG9ncyBhIFN0dWRpby1UIHJlc3BvbnNlIHBheWxvYWQuXG5cdCAqIFJlY2VpdmVzIGJvdGggdGhlIGZ1bGwgbXNnIChmb3IgcGFyc2VycyB0aGF0IG5lZWQgdGhlIFN0dWRpby1UIGhlYWRlcilcblx0ICogYW5kIHN0UGF5bG9hZCAobXNnLnN1YmFycmF5KDI0KSwgZm9yIGRpcmVjdCBieXRlIGFjY2VzcykuXG5cdCAqXG5cdCAqIHN0UGF5bG9hZCBsYXlvdXQ6XG5cdCAqICAgWzBdICAgICAgMHg1YSAgbWFnaWNcblx0ICogICBbMV0gICAgICBjbWRJZCB8IDB4ODBcblx0ICogICBbMi4uLTJdICBkYXRhIGJ5dGVzXG5cdCAqICAgWy0xXSAgICAgQ1JDLTgvRFZCLVMyXG5cdCAqL1xuXHRwcml2YXRlIGxvZ1N0UGF5bG9hZChzcmNJcDogc3RyaW5nLCBjbWRJZDogbnVtYmVyLCBtc2c6IEJ1ZmZlciwgc3RQYXlsb2FkOiBCdWZmZXIpOiB2b2lkIHtcblx0XHRjb25zdCBjbWROYW1lID0gZ2V0Q29tbWFuZE5hbWUoY21kSWQpXG5cdFx0Y29uc3QgZGF0YSA9IHN0UGF5bG9hZC5zdWJhcnJheSgyLCBzdFBheWxvYWQubGVuZ3RoIC0gMSkgLy8gc3RyaXAgbWFnaWMrY21kSWQgaGVhZGVyIGFuZCBDUkNcblxuXHRcdC8vIFBheWxvYWQgc3RydWN0dXJlOiBbY21kOjB4OGRdIFtkYXRhIGJ5dGVzLi4uXSBbY3JjXVxuXHRcdGNvbnN0IHJlc3BDbWRJZCA9IHN0UGF5bG9hZFsxXVxuXHRcdGNvbnN0IGNyYyA9IHN0UGF5bG9hZFtzdFBheWxvYWQubGVuZ3RoIC0gMV1cblx0XHRjb25zdCBmdWxsU3RydWN0dXJlID0gYFtjbWQ6JHt0b0hleChyZXNwQ21kSWQpfSBkYXRhOiR7ZGF0YS50b1N0cmluZygnaGV4Jyl9IGNyYzoke3RvSGV4KGNyYyl9XWBcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfR0VUX0FMTF9TRVRUSU5HUyAoMHgwYSkgYW5kIENNRF9TRVRUSU5HU19QVVNIICgweDBiKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBQYXJzZSBhbGwgc2V0dGluZ3MsIGRpZmYgYWdhaW5zdCBkZXZpY2VTdGF0ZSwgbG9nIGNoYW5nZWQgYXQgaW5mbyAvIHVuY2hhbmdlZCBhdCBkZWJ1Zyxcblx0XHQvLyB0aGVuIHVwZGF0ZSBkZXZpY2VTdGF0ZS4gQ01EX0dFVF9BTExfU0VUVElOR1MgYWxzbyBzZXJ2ZXMgYXMgdGhlIGluaXRpYWwgc3RhdGUgcG9wdWxhdGlvbiBvbiBjb25uZWN0LlxuXHRcdGlmIChjbWRJZCA9PT0gQ01EX0dFVF9BTExfU0VUVElOR1MgfHwgY21kSWQgPT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0XHRpZiAoIXRoaXMubW9kZWwpIHtcblx0XHRcdFx0bG9nZ2VyLmluZm8oYFJYICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8ICR7ZnVsbFN0cnVjdHVyZX1gKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IHNldHRpbmdzID1cblx0XHRcdFx0XHRjbWRJZCA9PT0gQ01EX1NFVFRJTkdTX1BVU0hcblx0XHRcdFx0XHRcdD8gcGFyc2VTZXR0aW5nc1Jlc3BvbnNlKHRoaXMubW9kZWwsIG1zZylcblx0XHRcdFx0XHRcdDogcGFyc2VHZXRBbGxTZXR0aW5nc0Zvck1vZGVsKHRoaXMubW9kZWwsIG1zZylcblxuXHRcdFx0XHRjb25zdCBwcmV2U3RhdGUgPSB0aGlzLmRldmljZVN0YXRlLmdldChzcmNJcCkgPz8gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4oKVxuXHRcdFx0XHRjb25zdCBuZXdTdGF0ZSA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KHByZXZTdGF0ZSkgLy8gY29weSBcdTIwMTQgdXBkYXRlIGluIHBsYWNlXG5cblx0XHRcdFx0Zm9yIChjb25zdCBzIG9mIHNldHRpbmdzKSB7XG5cdFx0XHRcdFx0Y29uc3Qgc3RhdGVLZXkgPSBtYWtlU2V0dGluZ0lkKHRoaXMubW9kZWwsIHMuY21kX2lkLCBzLmlkLCBzLmJ1c0NoKVxuXHRcdFx0XHRcdC8vIEZvciBSR0IgY29sb3JzICgzIGJ5dGVzKSwgcGFjayBpbnRvIHNpbmdsZSBudW1iZXI6IChSIDw8IDE2KSB8IChHIDw8IDgpIHwgQlxuXHRcdFx0XHRcdGNvbnN0IG5ld1ZhbHVlID1cblx0XHRcdFx0XHRcdHMudmFsdWVCeXRlcy5sZW5ndGggPT09IDNcblx0XHRcdFx0XHRcdFx0PyAocy52YWx1ZUJ5dGVzWzBdIDw8IDE2KSB8IChzLnZhbHVlQnl0ZXNbMV0gPDwgOCkgfCBzLnZhbHVlQnl0ZXNbMl1cblx0XHRcdFx0XHRcdFx0OiAocy52YWx1ZUJ5dGVzWzBdID8/IDApXG5cdFx0XHRcdFx0Y29uc3QgcHJldlZhbHVlID0gcHJldlN0YXRlLmdldChzdGF0ZUtleSlcblx0XHRcdFx0XHRjb25zdCBjaGFuZ2VkID0gcHJldlZhbHVlID09PSB1bmRlZmluZWQgfHwgcHJldlZhbHVlICE9PSBuZXdWYWx1ZVxuXG5cdFx0XHRcdFx0bmV3U3RhdGUuc2V0KHN0YXRlS2V5LCBuZXdWYWx1ZSlcblxuXHRcdFx0XHRcdGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdFBhcnNlZFNldHRpbmcocywgdGhpcy5hY3Rpb25zKVxuXHRcdFx0XHRcdGlmIChjaGFuZ2VkKSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgUlggJHtzcmNJcH0gfCAke2Zvcm1hdHRlZH1gKVxuXHRcdFx0XHRcdFx0Ly8gVHJpZ2dlciBmZWVkYmFjayB1cGRhdGUgXHUyMDE0IHVzZSBiYXNlIGtleSB3aXRob3V0IGJ1c0NoIHNvIGl0IG1hdGNoZXMgdGhlIGZlZWRiYWNrIGRlZmluaXRpb24gSURcblx0XHRcdFx0XHRcdGlmICh0aGlzLmZlZWRiYWNrQ2FsbGJhY2spIHtcblx0XHRcdFx0XHRcdFx0bGV0IGJhc2VJZCA9IHMuaWRcblx0XHRcdFx0XHRcdFx0Y29uc3QgYmFzZUFjdGlvbiA9IHRoaXMuYWN0aW9ucy5maW5kKChhKSA9PiB7XG5cdFx0XHRcdFx0XHRcdFx0aWYgKGEuY21kX2lkICE9PSBzLmNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0XHRcdFx0aWYgKGEuaWQgPT09IHMuaWQpIHJldHVybiB0cnVlXG5cdFx0XHRcdFx0XHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhLm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdFx0XHRcdFx0aWYgKCFpZEFkZE9wdGlvbj8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0XHRcdFx0Y29uc3Qgb2Zmc2V0ID0gcy5pZCAtIGEuaWRcblx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gb2Zmc2V0ID4gMCAmJiBpZEFkZE9wdGlvbi5jaG9pY2VzLnNvbWUoKGMpID0+IGMuaWQgPT09IG9mZnNldClcblx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdFx0aWYgKGJhc2VBY3Rpb24pIGJhc2VJZCA9IGJhc2VBY3Rpb24uaWRcblx0XHRcdFx0XHRcdFx0Y29uc3QgYmFzZUZlZWRiYWNrS2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBzLmNtZF9pZCwgYmFzZUlkKVxuXHRcdFx0XHRcdFx0XHR0aGlzLmZlZWRiYWNrQ2FsbGJhY2soYmFzZUZlZWRiYWNrS2V5KVxuXHRcdFx0XHRcdFx0XHR0aGlzLmZlZWRiYWNrQ2FsbGJhY2soYmFzZUZlZWRiYWNrS2V5ICsgJ19ib29sJylcblx0XHRcdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKGBmZWVkYmFja0NhbGxiYWNrIG5vdCBzZXQgXHUyMDE0IHNraXBwaW5nIGZlZWRiYWNrIHVwZGF0ZSBmb3IgJHtzdGF0ZUtleX1gKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIuZGVidWcoYFJYICR7c3JjSXB9IHwgJHtmb3JtYXR0ZWR9YClcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0dGhpcy5kZXZpY2VTdGF0ZS5zZXQoc3JjSXAsIG5ld1N0YXRlKVxuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRsb2dnZXIud2FybihgUlggJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgcGFyc2UgZmFpbGVkOiAke2V9IHwgJHtmdWxsU3RydWN0dXJlfWApXG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQWxsIG90aGVyIGNvbW1hbmRzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdGNvbnN0IGRlY29kZWQgPSB0aGlzLmRlY29kZVN0RGF0YShjbWRJZCwgZGF0YSlcblx0XHQvLyBDTURfQlVTX0dFVCAoa2VlcGFsaXZlKSBpcyBoaWdoLWZyZXF1ZW5jeSBub2lzZSBcdTIwMTQgbG9nIGF0IGRlYnVnIG9ubHlcblx0XHRjb25zdCBsb2dGbiA9IGNtZElkID09PSBDTURfQlVTX0dFVCA/IGxvZ2dlci5kZWJ1Zy5iaW5kKGxvZ2dlcikgOiBsb2dnZXIuaW5mby5iaW5kKGxvZ2dlcilcblx0XHRpZiAoZGVjb2RlZCkge1xuXHRcdFx0bG9nRm4oYFJYICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8ICR7ZnVsbFN0cnVjdHVyZX0gfCAke2RlY29kZWR9YClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nRm4oYFJYICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8ICR7ZnVsbFN0cnVjdHVyZX1gKVxuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBBdHRlbXB0cyB0byBkZWNvZGUgdGhlIGRhdGEgYnl0ZXMgb2YgYSBTdHVkaW8tVCByZXNwb25zZSBpbnRvIGFcblx0ICogaHVtYW4tcmVhZGFibGUgc3RyaW5nLiBSZXR1cm5zIG51bGwgdG8gZmFsbCBiYWNrIHRvIHJhdyBoZXguXG5cdCAqL1xuXHRwcml2YXRlIGRlY29kZVN0RGF0YShjbWRJZDogbnVtYmVyLCBkYXRhOiBCdWZmZXIpOiBzdHJpbmcgfCBudWxsIHtcblx0XHRpZiAoZGF0YS5sZW5ndGggPT09IDApIHJldHVybiAnQUNLJ1xuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIENoZWNrIGZvciBzaW5nbGUtYnl0ZSByZXNwb25zZXMgKEFDSyBvciBlcnJvcikgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0aWYgKGRhdGEubGVuZ3RoID09PSAxKSB7XG5cdFx0XHRpZiAoZGF0YVswXSA9PT0gMHgwMCkge1xuXHRcdFx0XHRyZXR1cm4gJ0FDSyBvaydcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdHJldHVybiBgRVJST1IgJHt0b0hleChkYXRhWzBdKX1gXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0c3dpdGNoIChjbWRJZCkge1xuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9NSUNfUFJFICgweDAyKTogcmF3IHByZWFtcCBlY2hvIFx1MjAxNCBwb3NpdGlvbmFsIGJ5dGVzLCBubyBzZXR0aW5nIElEcyBcdTI1MDBcdTI1MDBcblx0XHRcdC8vIERldmljZSBlY2hvZXMgW2J1c0NoXVt2YWwwXVt2YWwxXS4uLiBjb25maXJtaW5nIHRoZSBhcHBsaWVkIHZhbHVlcy5cblx0XHRcdGNhc2UgQ01EX01JQ19QUkU6IHtcblx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBkYXRhWzBdXG5cdFx0XHRcdGNvbnN0IHZhbHMgPSBBcnJheS5mcm9tKGRhdGEuc3ViYXJyYXkoMSkpXG5cdFx0XHRcdFx0Lm1hcCgoYiwgaSkgPT4gYFske2l9XT0weCR7Yi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX0oJHtifSlgKVxuXHRcdFx0XHRcdC5qb2luKCcgJylcblx0XHRcdFx0cmV0dXJuIGBjaD0ke2J1c0NofSAke3ZhbHN9YFxuXHRcdFx0fVxuXG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX0RFVl9TUEVDICgweDBkKTogc2luZ2xlLWJ5dGUgQUNLIG9yIGVjaG8gb2YgYXBwbGllZCBzZXR0aW5nIFx1MjUwMFx1MjUwMFxuXHRcdFx0Ly8gRGV2aWNlIHNlbmRzIHR3byBDTURfREVWX1NQRUMgcGFja2V0cyBpbiByZXNwb25zZSB0byBhIHNldDpcblx0XHRcdC8vICAgMS4gQUNLOiAgW3N0YXR1c10gICAgICAgICAgICAgICAoMSBieXRlLCAweDAwID0gb2spXG5cdFx0XHQvLyAgIDIuIEVjaG86IFtidXNDaF0gW3NldHRpbmdJZF0gW3ZhbHVlLi4uXSAgKGNvbmZpcm1pbmcgd2hhdCB3YXMgYXBwbGllZClcblx0XHRcdGNhc2UgQ01EX0RFVl9TUEVDOiB7XG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0XHRcdHJldHVybiBkYXRhWzBdID09PSAweDAwID8gJ0FDSyBvaycgOiBgQUNLIGVycj0ke3RvSGV4KGRhdGFbMF0pfWBcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPj0gMykge1xuXHRcdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGRhdGFbMV1cblx0XHRcdFx0XHRjb25zdCB2YWx1ZUJ5dGVzID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRcdGNvbnN0IGFjdGlvbiA9IHRoaXMuYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gc2V0dGluZ0lkKVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdOYW1lID0gYWN0aW9uPy5uYW1lID8/IGBzZXR0aW5nPSR7dG9IZXgoc2V0dGluZ0lkKX1gXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlcyA9IGFjdGlvbj8ub3B0aW9ucz8uWzBdPy5jaG9pY2VzXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVOdW0gPSB2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSA/IHZhbHVlQnl0ZXNbMF0gOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VMYWJlbCA9XG5cdFx0XHRcdFx0XHRjaG9pY2VzICYmIHZhbHVlTnVtICE9PSB1bmRlZmluZWQgPyBjaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IHZhbHVlTnVtKT8ubGFiZWwgOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCB2YWx1ZVN0ciA9IGNob2ljZUxhYmVsID8gYCR7Y2hvaWNlTGFiZWx9ICgke3RvSGV4KHZhbHVlTnVtISl9KWAgOiBieXRlc1RvSGV4KEFycmF5LmZyb20odmFsdWVCeXRlcykpXG5cdFx0XHRcdFx0Y29uc3QgcmF3VGFnID0gYFske3RvSGV4KGNtZElkKX0vJHt0b0hleChzZXR0aW5nSWQpfV09JHtieXRlc1RvSGV4KEFycmF5LmZyb20odmFsdWVCeXRlcykpfWBcblx0XHRcdFx0XHRyZXR1cm4gYGVjaG8gY2g9JHtidXNDaH0gfCAke3NldHRpbmdOYW1lfTogJHt2YWx1ZVN0cn0gJHtyYXdUYWd9YFxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBgcmF3OiAke2RhdGEudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9NSUNfUFJFX0JVUyAoMHgxMik6IE11bHRpLWJ5dGUgZWNobyByZXNwb25zZXMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHRjYXNlIENNRF9NSUNfUFJFX0JVUzoge1xuXHRcdFx0XHQvLyBBbHJlYWR5IGhhbmRsZWQgc2luZ2xlLWJ5dGUgYWJvdmUsIHNvIG11bHRpLWJ5dGUgbXVzdCBiZSBlY2hvXG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA+PSAzKSB7XG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBkYXRhWzBdXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gZGF0YVsxXVxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlQnl0ZXMgPSBkYXRhLnN1YmFycmF5KDIpXG5cdFx0XHRcdFx0Y29uc3QgYWN0aW9uID0gdGhpcy5hY3Rpb25zLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBzZXR0aW5nSWQpXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ05hbWUgPSBhY3Rpb24/Lm5hbWUgPz8gYHNldHRpbmc9JHt0b0hleChzZXR0aW5nSWQpfWBcblx0XHRcdFx0XHRjb25zdCB2YWx1ZU51bSA9IHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxID8gdmFsdWVCeXRlc1swXSA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IGNob2ljZXMgPSBhY3Rpb24/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICd2YWx1ZScpPy5jaG9pY2VzXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlTGFiZWwgPVxuXHRcdFx0XHRcdFx0Y2hvaWNlcyAmJiB2YWx1ZU51bSAhPT0gdW5kZWZpbmVkID8gY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSB2YWx1ZU51bSk/LmxhYmVsIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVTdHIgPSBjaG9pY2VMYWJlbCA/PyBgMHgke3ZhbHVlQnl0ZXMudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdFx0XHRyZXR1cm4gYGVjaG8gY2g9JHtidXNDaH0gfCAke3NldHRpbmdOYW1lfTogJHt2YWx1ZVN0cn1gXG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIG51bGxcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIEJ1cy1zY29wZWQgZ2V0L3NldCBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRcdGNhc2UgQ01EX0JVU19HRVQ6XG5cdFx0XHRjYXNlIENNRF9CVVNfU0VUOiB7XG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA8IDIpIHJldHVybiBudWxsXG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBkYXRhWzFdXG5cdFx0XHRcdGNvbnN0IHZhbHVlID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRyZXR1cm4gYGNoPSR7YnVzQ2h9IHNldHRpbmc9JHt0b0hleChzZXR0aW5nSWQpfSB2YWx1ZT0ke3ZhbHVlLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHR9XG5cblx0XHRcdGRlZmF1bHQ6XG5cdFx0XHRcdHJldHVybiBudWxsIC8vIGZhbGwgdGhyb3VnaCB0byByYXcgaGV4XG5cdFx0fVxuXHR9XG5cblx0cHJpdmF0ZSBzdGF0aWMgYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlOiB1bmtub3duKTogbnVtYmVyW10ge1xuXHRcdGlmICh0eXBlb2YgdmFsdWUgPT09ICdib29sZWFuJykgcmV0dXJuIFt2YWx1ZSA/IDEgOiAwXVxuXHRcdGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkgcmV0dXJuIHZhbHVlLm1hcCgodikgPT4gTnVtYmVyKHYpICYgMHhmZilcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykge1xuXHRcdFx0aWYgKHZhbHVlID4gMHhmZikgcmV0dXJuIFsodmFsdWUgPj4gMTYpICYgMHhmZiwgKHZhbHVlID4+IDgpICYgMHhmZiwgdmFsdWUgJiAweGZmXVxuXHRcdFx0cmV0dXJuIFt2YWx1ZSAmIDB4ZmZdXG5cdFx0fVxuXHRcdHRocm93IG5ldyBFcnJvcihgVW5zdXBwb3J0ZWQgdmFsdWUgdHlwZSBmb3IgU1Rjb250cm9sbGVyOiAke3ZhbHVlfWApXG5cdH1cblxuXHRwcml2YXRlIGFzeW5jIGJ1aWxkSGVhZGVyKHRvdGFsTGVuOiBudW1iZXIsIGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRsZXQgbWFjID0gdGhpcy5tYWNDYWNoZS5nZXQoZGVzdElwKVxuXHRcdGlmICghbWFjKSB7XG5cdFx0XHRtYWMgPSBhd2FpdCBnZXRNYWNGb3JEZXN0aW5hdGlvbihkZXN0SXApXG5cdFx0XHR0aGlzLm1hY0NhY2hlLnNldChkZXN0SXAsIG1hYylcblx0XHR9XG5cblx0XHRyZXR1cm4gQnVmZmVyLmNvbmNhdChbXG5cdFx0XHRCdWZmZXIuZnJvbShbMHhmZiwgMHhmZiwgMHgwMCwgdG90YWxMZW4gJiAweGZmLCAweDA3LCAweGUxLCAweDAwLCAweDAwLCAuLi5tYWMsIDB4MDAsIDB4MDBdKSxcblx0XHRcdEJ1ZmZlci5mcm9tKCdTdHVkaW8tVCcsICd1dGY4JyksXG5cdFx0XSlcblx0fVxuXG5cdHByaXZhdGUgc3RhdGljIGNyYzhEdmJTMihkYXRhOiBudW1iZXJbXSk6IG51bWJlciB7XG5cdFx0bGV0IGNyYyA9IDBcblx0XHRmb3IgKGNvbnN0IGIgb2YgZGF0YSkge1xuXHRcdFx0Y3JjIF49IGJcblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgODsgaSsrKSB7XG5cdFx0XHRcdGNyYyA9IChjcmMgJiAweDgwKSAhPT0gMCA/ICgoY3JjIDw8IDEpIF4gMHhkNSkgJiAweGZmIDogKGNyYyA8PCAxKSAmIDB4ZmZcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIGNyY1xuXHR9XG5cblx0LyoqXG5cdCAqIFJldHVybnMgdGhlIGN1cnJlbnQga25vd24gdmFsdWUgZm9yIGEgc2V0dGluZyBvbiBhIGRldmljZSwgb3IgdW5kZWZpbmVkIGlmIHVua25vd24uXG5cdCAqIFVzZSBmb3IgZmVlZGJhY2tzIFx1MjAxNCB2YWx1ZSBpcyB1cGRhdGVkIG9uIGV2ZXJ5IENNRF9TRVRUSU5HU19QVVNIICgweDBiKSBmcm9tIHRoZSBkZXZpY2UuXG5cdCAqXG5cdCAqIEBwYXJhbSBpcCAgICAgICAgRGV2aWNlIElQIGFkZHJlc3Ncblx0ICogQHBhcmFtIGNtZElkICAgICBDb21tYW5kIElEIChlLmcuIENNRF9ERVZfU1BFQylcblx0ICogQHBhcmFtIHNldHRpbmdJZCBTZXR0aW5nIElEIChlLmcuIDB4MDIgZm9yIENvbnRyb2wgU291cmNlKVxuXHQgKiBAcGFyYW0gYnVzQ2ggICAgIE9wdGlvbmFsIGJ1cy9jaGFubmVsIElEIGZvciBtdWx0aS1jaGFubmVsIGNvbW1hbmRzXG5cdCAqL1xuXHRwdWJsaWMgZ2V0U2V0dGluZ1ZhbHVlKGlwOiBzdHJpbmcsIGNtZElkOiBudW1iZXIsIHNldHRpbmdJZDogbnVtYmVyLCBidXNDaD86IG51bWJlcik6IG51bWJlciB8IHVuZGVmaW5lZCB7XG5cdFx0Y29uc3Qga2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkLCBidXNDaClcblx0XHRyZXR1cm4gdGhpcy5kZXZpY2VTdGF0ZS5nZXQoaXApPy5nZXQoa2V5KVxuXHR9XG5cblx0cHVibGljIGFzeW5jIHJlc2V0RGV2aWNlKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRyZXR1cm4gdGhpcy5zZW5kQXdhaXRBY2soQ01EX1JFU0VUX0RFVklDRSwgdW5kZWZpbmVkLCAweDAwLCB1bmRlZmluZWQsIGRlc3RJcCwgZmFsc2UpXG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgZ2xvYmFsTWljS2lsbChkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0cmV0dXJuIHRoaXMuc2VuZEF3YWl0QWNrKENNRF9HTE9CQUxfTUlDX0tJTEwsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIGRlc3RJcCwgZmFsc2UpXG5cdH1cbn1cbiIsICJpbXBvcnQgZGdyYW0gZnJvbSAnZGdyYW0nXG5pbXBvcnQgb3MgZnJvbSAnb3MnXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHR5cGUgeyBEZXZpY2VJbmZvIH0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdEYW50ZScpXG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBEYW50ZSBkaXNjb3ZlcnkgY29uc3RhbnRzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG4vKiogRGFudGUgZGV2aWNlIGluZm8gcmVxdWVzdCBtZXNzYWdlIHR5cGUgKHNlbnQgdG8gcG9ydCA4NzAwKSAqL1xuY29uc3QgREFOVEVfTVNHX0lORk9fUkVRVUVTVCA9IDB4MDAyMFxuLyoqIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlIG1lc3NhZ2UgdHlwZSAocmVjZWl2ZWQgb24gcG9ydCA4NzAyKSAqL1xuZXhwb3J0IGNvbnN0IERBTlRFX01TR19JTkZPX1JFU1BPTlNFID0gMHgwMTcwXG5jb25zdCBEQU5URV9JTkZPX01JTl9MRU4gPSAweGNjICsgNjQgLy8gMjY4IGJ5dGVzIFx1MjAxNCBuZWVkIGZ1bGwgbW9kZWwgZmllbGRcblxuZnVuY3Rpb24gYnVpbGREYW50ZUluZm9SZXF1ZXN0KCk6IEJ1ZmZlciB7XG5cdGNvbnN0IGJ1ZiA9IEJ1ZmZlci5hbGxvYygzMiwgMClcblx0Y29uc3Qgc2VxID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMHhmZmZmKVxuXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKDB4ZmZmZiwgMClcblx0YnVmLndyaXRlVUludDE2QkUoREFOVEVfTVNHX0lORk9fUkVRVUVTVCwgMilcblx0YnVmLndyaXRlVUludDE2QkUoc2VxLCA0KVxuXG5cdGNvbnN0IG1hYyA9IGdldEZpcnN0TG9jYWxNYWMoKVxuXHRtYWMuY29weShidWYsIDgpXG5cblx0QnVmZmVyLmZyb20oJ0F1ZGluYXRlJywgJ2FzY2lpJykuY29weShidWYsIDE2KVxuXHRidWYud3JpdGVVSW50MTZCRSgweDA3MzksIDI0KVxuXHRidWYud3JpdGVVSW50MTZCRSgweDAwYzEsIDI2KVxuXHRidWYud3JpdGVVSW50MzJCRSgweDAwMGY0MjQwLCAyOClcblxuXHRyZXR1cm4gYnVmXG59XG5cbi8qKiBSZXR1cm5zIHRoZSBmaXJzdCBub24tbG9vcGJhY2sgTUFDIGFzIGEgNi1ieXRlIEJ1ZmZlciwgb3IgemVyb3MuICovXG5mdW5jdGlvbiBnZXRGaXJzdExvY2FsTWFjKCk6IEJ1ZmZlciB7XG5cdHRyeSB7XG5cdFx0Y29uc3QgaWZhY2VzID0gb3MubmV0d29ya0ludGVyZmFjZXMoKVxuXHRcdGZvciAoY29uc3QgbmFtZSBvZiBPYmplY3Qua2V5cyhpZmFjZXMpKSB7XG5cdFx0XHRmb3IgKGNvbnN0IGFkZHIgb2YgaWZhY2VzW25hbWVdID8/IFtdKSB7XG5cdFx0XHRcdGlmICghYWRkci5pbnRlcm5hbCAmJiBhZGRyLmZhbWlseSA9PT0gJ0lQdjQnICYmIGFkZHIubWFjICYmIGFkZHIubWFjICE9PSAnMDA6MDA6MDA6MDA6MDA6MDAnKSB7XG5cdFx0XHRcdFx0cmV0dXJuIEJ1ZmZlci5mcm9tKGFkZHIubWFjLnNwbGl0KCc6JykubWFwKChoOiBzdHJpbmcpID0+IHBhcnNlSW50KGgsIDE2KSkpXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH0gY2F0Y2gge1xuXHRcdC8qIGlnbm9yZSAqL1xuXHR9XG5cdHJldHVybiBCdWZmZXIuYWxsb2MoNiwgMClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlRGFudGVJbmZvUmVzcG9uc2UobXNnOiBCdWZmZXIsIHNyY0lwOiBzdHJpbmcpOiBEZXZpY2VJbmZvIHwgbnVsbCB7XG5cdGlmIChtc2cubGVuZ3RoIDwgREFOVEVfSU5GT19NSU5fTEVOKSByZXR1cm4gbnVsbFxuXHRpZiAobXNnLnJlYWRVSW50MTZCRSgwKSAhPT0gMHhmZmZmKSByZXR1cm4gbnVsbFxuXHRpZiAobXNnLnJlYWRVSW50MTZCRSgyKSAhPT0gREFOVEVfTVNHX0lORk9fUkVTUE9OU0UpIHJldHVybiBudWxsXG5cdGlmIChtc2cuc3ViYXJyYXkoMTYsIDI0KS50b1N0cmluZygnYXNjaWknKSAhPT0gJ0F1ZGluYXRlJykgcmV0dXJuIG51bGxcblxuXHRjb25zdCByZWFkU3RyID0gKG9mZnNldDogbnVtYmVyLCBsZW46IG51bWJlcik6IHN0cmluZyA9PlxuXHRcdG1zZ1xuXHRcdFx0LnN1YmFycmF5KG9mZnNldCwgb2Zmc2V0ICsgbGVuKVxuXHRcdFx0LnRvU3RyaW5nKCdhc2NpaScpXG5cdFx0XHQuc3BsaXQoJ1xcMCcpWzBdXG5cdFx0XHQudHJpbSgpXG5cblx0Y29uc3QgZXVpNjQgPSBtc2cuc3ViYXJyYXkoOCwgMTYpXG5cdGNvbnN0IG1hY0J5dGVzID0gW2V1aTY0WzBdLCBldWk2NFsxXSwgZXVpNjRbMl0sIGV1aTY0WzVdLCBldWk2NFs2XSwgZXVpNjRbN11dXG5cdGNvbnN0IG1hYyA9IG1hY0J5dGVzLm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSkuam9pbignOicpXG5cblx0Y29uc3QgbmFtZSA9IHJlYWRTdHIoMHgyMCwgMzEpIC8vIERhbnRlIGRldmljZSBsYWJlbCAoY2FuIGJlIHVwIHRvIDMxIGNoYXJzIHBlciBEYW50ZSBzcGVjKVxuXHRjb25zdCBtYW51ZmFjdHVyZXIgPSByZWFkU3RyKDB4NGMsIDY0KSAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGNvbnN0IG1vZGVsUmF3ID0gcmVhZFN0cigweGNjLCA2NClcblx0Y29uc3QgZGFudGVGaXJtd2FyZSA9IGAke21zZ1sweDE4XX0uJHttc2dbMHgxOV19YFxuXG5cdGlmICghbW9kZWxSYXcpIHJldHVybiBudWxsXG5cblx0Ly8gRXh0cmFjdCBqdXN0IHRoZSBtb2RlbCBudW1iZXIvY29kZSAoZS5nLiBcIk1vZGVsIDM5MSBBbGVydGluZyBVbml0XCIgXHUyMTkyIFwiMzkxXCIpXG5cdC8vIFN0cmlwIFwiTW9kZWwgXCIgcHJlZml4LCB0aGVuIHRha2Ugb25seSB0aGUgZmlyc3Qgd29yZCAodGhlIG1vZGVsIG51bWJlcilcblx0Y29uc3QgbW9kZWwgPSBtb2RlbFJhd1xuXHRcdC5yZXBsYWNlKC9eTW9kZWxcXHMrL2ksICcnKVxuXHRcdC50cmltKClcblx0XHQuc3BsaXQoL1xccysvKVswXVxuXG5cdHJldHVybiB7XG5cdFx0aXA6IHNyY0lwLFxuXHRcdG5hbWUsXG5cdFx0bWFudWZhY3R1cmVyLFxuXHRcdG1vZGVsLFxuXHRcdG1vZGVsTmFtZTogbW9kZWxSYXcsIC8vIEZ1bGwgbW9kZWwgZGVzY3JpcHRpb25cblx0XHRtYWMsXG5cdFx0ZGFudGVGaXJtd2FyZSxcblx0fVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIE1BQyBhZGRyZXNzIGJ5dGVzIG9mIHRoZSBsb2NhbCBpbnRlcmZhY2UgdXNlZCB0byByb3V0ZSB0byBkZXN0SXAuXG4gKiBVc2VzIGEgdGVtcG9yYXJ5IFVEUCBjb25uZWN0IHRvIGxldCB0aGUgT1Mgc2VsZWN0IHRoZSBvdXRnb2luZyBpbnRlcmZhY2UsXG4gKiB0aGVuIGZpbmRzIHRoZSBtYXRjaGluZyBNQUMgZnJvbSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFjRm9yRGVzdGluYXRpb24oZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPG51bWJlcltdPiB7XG5cdHJldHVybiBuZXcgUHJvbWlzZTxudW1iZXJbXT4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGNvbnN0IHRtcCA9IGRncmFtLmNyZWF0ZVNvY2tldCgndWRwNCcpXG5cblx0XHR0bXAub25jZSgnZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0fSlcblxuXHRcdHRtcC5jb25uZWN0KDksIGRlc3RJcCwgKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3QgYWRkciA9IHRtcC5hZGRyZXNzKCkgYXMgeyBhZGRyZXNzOiBzdHJpbmcgfVxuXHRcdFx0XHRjb25zdCBsb2NhbEFkZHIgPSBhZGRyLmFkZHJlc3Ncblx0XHRcdFx0dG1wLmNsb3NlKClcblxuXHRcdFx0XHRjb25zdCBpZmFjZXMgPSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpXG5cdFx0XHRcdGZvciAoY29uc3QgbmFtZSBvZiBPYmplY3Qua2V5cyhpZmFjZXMpKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBpZmFjZSBvZiBpZmFjZXNbbmFtZV0gPz8gW10pIHtcblx0XHRcdFx0XHRcdGlmIChcblx0XHRcdFx0XHRcdFx0aWZhY2UuZmFtaWx5ID09PSAnSVB2NCcgJiZcblx0XHRcdFx0XHRcdFx0aWZhY2UuYWRkcmVzcyA9PT0gbG9jYWxBZGRyICYmXG5cdFx0XHRcdFx0XHRcdGlmYWNlLm1hYyAmJlxuXHRcdFx0XHRcdFx0XHRpZmFjZS5tYWMgIT09ICcwMDowMDowMDowMDowMDowMCdcblx0XHRcdFx0XHRcdCkge1xuXHRcdFx0XHRcdFx0XHRyZXR1cm4gcmVzb2x2ZShpZmFjZS5tYWMuc3BsaXQoJzonKS5tYXAoKGIpID0+IHBhcnNlSW50KGIsIDE2KSAmIDB4ZmYpKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGBObyBpbnRlcmZhY2UgZm91bmQgZm9yIGxvY2FsIGFkZHJlc3MgJHtsb2NhbEFkZHJ9YCkpXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKFN0cmluZyhfZSkpKVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0pXG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgbG9jYWwgSVAgYWRkcmVzcyB1c2VkIGJ5IHRoZSBPUyB0byByb3V0ZSB0byBkZXN0SXAuXG4gKiBVc2VzIGEgdGVtcG9yYXJ5IFVEUCBzb2NrZXQgY29ubmVjdCB0byBsZXQgdGhlIE9TIHNlbGVjdCB0aGUgb3V0Z29pbmcgaW50ZXJmYWNlLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TG9jYWxBZGRyZXNzRm9yRGVzdGluYXRpb24oZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuXHRyZXR1cm4gbmV3IFByb21pc2U8c3RyaW5nPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0Y29uc3QgdG1wID0gZGdyYW0uY3JlYXRlU29ja2V0KCd1ZHA0JylcblxuXHRcdGxldCByZXNvbHZlZCA9IGZhbHNlXG5cdFx0dG1wLm9uY2UoJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0aWYgKCFyZXNvbHZlZCkge1xuXHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdC8vIFVzZSBhbiBhcmJpdHJhcnkgcG9ydCBmb3IgY29ubmVjdDsgd2Ugb25seSBuZWVkIHRoZSBrZXJuZWwgdG8gYXNzaWduIGEgbG9jYWwgYWRkcmVzcy5cblx0XHR0bXAuY29ubmVjdCg5LCBkZXN0SXAsICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IGFkZHIgPSB0bXAuYWRkcmVzcygpIGFzIHsgYWRkcmVzczogc3RyaW5nIH1cblx0XHRcdFx0Y29uc3QgbG9jYWxBZGRyID0gYWRkci5hZGRyZXNzXG5cdFx0XHRcdGlmICghcmVzb2x2ZWQpIHtcblx0XHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0XHRcdHJlc29sdmUobG9jYWxBZGRyKVxuXHRcdFx0XHR9XG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRpZiAoIXJlc29sdmVkKSB7XG5cdFx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0XHRyZWplY3QobmV3IEVycm9yKFN0cmluZyhfZSkpKVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSlcblx0fSlcbn1cblxuLyoqXG4gKiBMaXN0ZW5zIGZvciBEYW50ZSBkZXZpY2UgYW5ub3VuY2VzIG9uIHRoZSBsb2NhbCBuZXR3b3JrIGFuZCBzZW5kcyB1bmljYXN0XG4gKiBpbmZvIHJlcXVlc3RzIHRvIGVhY2ggZGlzY292ZXJlZCBJUC4gUmVzcG9uc2VzIGFycml2ZSBvbiB0aGUgY2FsbGVyJ3MgcnhTb2NrZXRcbiAqIHZpYSBoYW5kbGVJbmNvbWluZygpIFx1MjE5MiBkaXNjb3ZlcnlMaXN0ZW5lcnMuXG4gKlxuICogQHBhcmFtIHR4U29ja2V0IC0gVGhlIHNvY2tldCB0byB1c2UgZm9yIHNlbmRpbmcgZGlzY292ZXJ5IHJlcXVlc3RzXG4gKiBAcGFyYW0gZW5zdXJlTWVtYmVyc2hpcCAtIENhbGxiYWNrIHRvIGVuc3VyZSBtdWx0aWNhc3QgbWVtYmVyc2hpcCBiZWZvcmUgcXVlcnlpbmdcbiAqIEBwYXJhbSB0aW1lb3V0TXMgLSBIb3cgbG9uZyB0byBsaXN0ZW4gZm9yIGFubm91bmNlcyBiZWZvcmUgcmVzb2x2aW5nXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkaXNjb3ZlckRldmljZXMoXG5cdHR4U29ja2V0OiBkZ3JhbS5Tb2NrZXQsXG5cdGVuc3VyZU1lbWJlcnNoaXA6IChkZXN0SXA6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPixcblx0dGltZW91dE1zID0gNTAwMCxcbik6IFByb21pc2U8dm9pZD4ge1xuXHRjb25zdCBEQU5URV9BTk5PVU5DRV9HUk9VUCA9ICcyMjQuMC4wLjIzMydcblx0Y29uc3QgREFOVEVfQU5OT1VOQ0VfUE9SVCA9IDg3MDhcblx0Y29uc3QgREVGQVVMVF9QT1JUID0gODcwMFxuXG5cdGNvbnN0IHF1ZXJpZWRJcHMgPSBuZXcgU2V0PHN0cmluZz4oKVxuXG5cdHJldHVybiBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuXHRcdGNvbnN0IGFubm91bmNlU29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblx0XHRjb25zdCBqb2luZWRJbnRlcmZhY2VzOiBzdHJpbmdbXSA9IFtdXG5cblx0XHRjb25zdCBjbGVhbnVwID0gKCkgPT4ge1xuXHRcdFx0Zm9yIChjb25zdCBpZmFjZSBvZiBqb2luZWRJbnRlcmZhY2VzKSB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuZHJvcE1lbWJlcnNoaXAoREFOVEVfQU5OT1VOQ0VfR1JPVVAsIGlmYWNlKVxuXHRcdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuY2xvc2UoKVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdFx0cmVzb2x2ZSgpXG5cdFx0fVxuXG5cdFx0Y29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KGNsZWFudXAsIHRpbWVvdXRNcylcblx0XHR0aW1lci51bnJlZj8uKClcblxuXHRcdGFubm91bmNlU29ja2V0Lm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGxvZ2dlci53YXJuKGBBbm5vdW5jZSBzb2NrZXQgZXJyb3I6ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHR9KVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQub24oJ21lc3NhZ2UnLCAobXNnLCByaW5mbykgPT4ge1xuXHRcdFx0Y29uc3Qgc3JjSXAgPSByaW5mby5hZGRyZXNzXG5cdFx0XHQvLyBWYWxpZGF0ZSBpdCdzIGEgRGFudGUgYW5ub3VuY2UgKG1hZ2ljIDB4ZmZmZSArIFwiQXVkaW5hdGVcIiBhdCBvZmZzZXQgMTYpXG5cdFx0XHRpZiAobXNnLmxlbmd0aCA8IDI0KSByZXR1cm5cblx0XHRcdGlmIChtc2cucmVhZFVJbnQxNkJFKDApICE9PSAweGZmZmUpIHJldHVyblxuXHRcdFx0aWYgKG1zZy5zdWJhcnJheSgxNiwgMjQpLnRvU3RyaW5nKCdhc2NpaScpICE9PSAnQXVkaW5hdGUnKSByZXR1cm5cblxuXHRcdFx0aWYgKHF1ZXJpZWRJcHMuaGFzKHNyY0lwKSkgcmV0dXJuXG5cdFx0XHRxdWVyaWVkSXBzLmFkZChzcmNJcClcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgQW5ub3VuY2UgZnJvbSAke3NyY0lwfSBcdTIwMTQgc2VuZGluZyB1bmljYXN0IHF1ZXJ5YClcblxuXHRcdFx0Ly8gSm9pbiAyMjQuMC4wLjIzMSBvbiB0aGUgaW50ZXJmYWNlIHRoYXQgcm91dGVzIHRvIHRoaXMgZGV2aWNlIEJFRk9SRSBzZW5kaW5nXG5cdFx0XHQvLyB0aGUgcXVlcnkuIFRoZSBkZXZpY2UgbXVsdGljYXN0cyBpdHMgMHgwMTcwIHJlc3BvbnNlIHRvIDIyNC4wLjAuMjMxOjg3MDJcblx0XHRcdC8vIGluIGFkZGl0aW9uIHRvIHVuaWNhc3RpbmcgaXQgXHUyMDE0IHJ4U29ja2V0IG11c3QgYmUgYSBtZW1iZXIgdG8gcmVjZWl2ZSBpdC5cblx0XHRcdGNvbnN0IHNlbmRRdWVyeSA9IGFzeW5jICgpID0+IHtcblx0XHRcdFx0YXdhaXQgZW5zdXJlTWVtYmVyc2hpcChzcmNJcClcblx0XHRcdFx0Y29uc3QgcXVlcnkgPSBidWlsZERhbnRlSW5mb1JlcXVlc3QoKVxuXHRcdFx0XHR0eFNvY2tldC5zZW5kKHF1ZXJ5LCBERUZBVUxUX1BPUlQsIHNyY0lwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdFx0aWYgKGVycikgbG9nZ2VyLndhcm4oYFVuaWNhc3QgcXVlcnkgdG8gJHtzcmNJcH0gZmFpbGVkOiAke2Vyci5tZXNzYWdlfWApXG5cdFx0XHRcdH0pXG5cdFx0XHR9XG5cdFx0XHRzZW5kUXVlcnkoKS5jYXRjaCgoZXJyKSA9PiBsb2dnZXIud2FybihgUXVlcnkgc2V0dXAgZmFpbGVkOiAke2Vycn1gKSlcblx0XHR9KVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQuYmluZChEQU5URV9BTk5PVU5DRV9QT1JULCAoKSA9PiB7XG5cdFx0XHQvLyBKb2luIDIyNC4wLjAuMjMzIG9uIGV2ZXJ5IG5vbi1sb29wYmFjayBJUHY0IGludGVyZmFjZSBzbyB0aGF0IGFubm91bmNlc1xuXHRcdFx0Ly8gYXJlIHJlY2VpdmVkIHJlZ2FyZGxlc3Mgb2Ygd2hpY2ggaW50ZXJmYWNlIHRoZSBkZXZpY2UgaXMgb24uXG5cdFx0XHQvLyBPbiBXaW5kb3dzIHdpdGggbXVsdGlwbGUgaW50ZXJmYWNlcyAoZS5nLiBIeXBlci1WICsgTEFOKSwgdGhlIE9TIGRlZmF1bHRcblx0XHRcdC8vIG11bHRpY2FzdCBpbnRlcmZhY2UgbWF5IG5vdCBiZSB0aGUgb25lIGNvbm5lY3RlZCB0byB0aGUgRGFudGUgbmV0d29yay5cblx0XHRcdGNvbnN0IGlmYWNlcyA9IG9zLm5ldHdvcmtJbnRlcmZhY2VzKClcblx0XHRcdGZvciAoY29uc3QgYWRkcnMgb2YgT2JqZWN0LnZhbHVlcyhpZmFjZXMpKSB7XG5cdFx0XHRcdGZvciAoY29uc3QgYWRkciBvZiBhZGRycyA/PyBbXSkge1xuXHRcdFx0XHRcdGlmIChhZGRyLmZhbWlseSA9PT0gJ0lQdjQnICYmICFhZGRyLmludGVybmFsKSB7XG5cdFx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0XHRhbm5vdW5jZVNvY2tldC5hZGRNZW1iZXJzaGlwKERBTlRFX0FOTk9VTkNFX0dST1VQLCBhZGRyLmFkZHJlc3MpXG5cdFx0XHRcdFx0XHRcdGpvaW5lZEludGVyZmFjZXMucHVzaChhZGRyLmFkZHJlc3MpXG5cdFx0XHRcdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0XHRcdFx0LyogaWdub3JlIFx1MjAxNCBpbnRlcmZhY2UgbWF5IG5vdCBzdXBwb3J0IG11bHRpY2FzdCAqL1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKGpvaW5lZEludGVyZmFjZXMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3Qgam9pbiBhbm5vdW5jZSBtdWx0aWNhc3QgZ3JvdXAgb24gYW55IGludGVyZmFjZWApXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRsb2dnZXIuZGVidWcoYExpc3RlbmluZyBmb3IgRGFudGUgYW5ub3VuY2VzIG9uICR7REFOVEVfQU5OT1VOQ0VfR1JPVVB9OiR7REFOVEVfQU5OT1VOQ0VfUE9SVH1gKVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0pXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBEZXZpY2UgcHJvYmUgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbi8qKlxuICogU2VuZHMgYSB1bmljYXN0IERhbnRlIGluZm8gcmVxdWVzdCB0byBhIHNwZWNpZmljIElQIGFuZCB3YWl0cyBmb3IgdGhlIGRldmljZSBpbmZvXG4gKiByZXNwb25zZS4gVXNlZCB0byB2ZXJpZnkgYSBtYW51YWxseSBjb25maWd1cmVkIElQLlxuICpcbiAqIEBwYXJhbSB0eFNvY2tldCAgICAgICAgIEJvdW5kIHNvY2tldCB0byBzZW5kIHRoZSBxdWVyeSBmcm9tXG4gKiBAcGFyYW0gcmVnaXN0ZXJMaXN0ZW5lciBSZWdpc3RlciBhIGNhbGxiYWNrIChrZXllZCkgdG8gcmVjZWl2ZSBwYXJzZWQgRGV2aWNlSW5mbyByZXNwb25zZXNcbiAqIEBwYXJhbSByZW1vdmVMaXN0ZW5lciAgIFJlbW92ZSBhIHByZXZpb3VzbHkgcmVnaXN0ZXJlZCBsaXN0ZW5lciBieSBrZXlcbiAqIEBwYXJhbSBlbnN1cmVNZW1iZXJzaGlwIEVuc3VyZSBtdWx0aWNhc3QgbWVtYmVyc2hpcCBvbiB0aGUgb3V0Z29pbmcgaW50ZXJmYWNlXG4gKiBAcGFyYW0gaXAgICAgICAgICAgICAgICBUYXJnZXQgZGV2aWNlIElQXG4gKiBAcGFyYW0gdGltZW91dE1zICAgICAgICBUaW1lb3V0IGluIG1pbGxpc2Vjb25kc1xuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJvYmVEZXZpY2UoXG5cdHR4U29ja2V0OiBkZ3JhbS5Tb2NrZXQsXG5cdHJlZ2lzdGVyTGlzdGVuZXI6IChrZXk6IHN0cmluZywgY2I6IChkZXZpY2U6IERldmljZUluZm8pID0+IHZvaWQpID0+IHZvaWQsXG5cdHJlbW92ZUxpc3RlbmVyOiAoa2V5OiBzdHJpbmcpID0+IHZvaWQsXG5cdGVuc3VyZU1lbWJlcnNoaXA6IChpcDogc3RyaW5nKSA9PiBQcm9taXNlPHZvaWQ+LFxuXHRpcDogc3RyaW5nLFxuXHR0aW1lb3V0TXMgPSAzMDAwLFxuKTogUHJvbWlzZTxEZXZpY2VJbmZvIHwgbnVsbD4ge1xuXHRyZXR1cm4gbmV3IFByb21pc2U8RGV2aWNlSW5mbyB8IG51bGw+KChyZXNvbHZlKSA9PiB7XG5cdFx0Y29uc3Qga2V5ID0gYF9fcHJvYmVfJHtpcH1fX2Bcblx0XHRsZXQgcmVzb2x2ZWQgPSBmYWxzZVxuXG5cdFx0Y29uc3QgZmluaXNoID0gKHJlc3VsdDogRGV2aWNlSW5mbyB8IG51bGwpID0+IHtcblx0XHRcdGlmIChyZXNvbHZlZCkgcmV0dXJuXG5cdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdHJlbW92ZUxpc3RlbmVyKGtleSlcblx0XHRcdHJlc29sdmUocmVzdWx0KVxuXHRcdH1cblxuXHRcdHJlZ2lzdGVyTGlzdGVuZXIoa2V5LCAoZGV2aWNlOiBEZXZpY2VJbmZvKSA9PiB7XG5cdFx0XHRpZiAoZGV2aWNlLmlwID09PSBpcCkgZmluaXNoKGRldmljZSlcblx0XHR9KVxuXG5cdFx0Y29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IGZpbmlzaChudWxsKSwgdGltZW91dE1zKVxuXHRcdHRpbWVyLnVucmVmPy4oKVxuXG5cdFx0Y29uc3QgcnVuID0gYXN5bmMgKCkgPT4ge1xuXHRcdFx0YXdhaXQgZW5zdXJlTWVtYmVyc2hpcChpcClcblx0XHRcdGNvbnN0IHF1ZXJ5ID0gYnVpbGREYW50ZUluZm9SZXF1ZXN0KClcblx0XHRcdHR4U29ja2V0LnNlbmQocXVlcnksIDg3MDAsIGlwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdGlmIChlcnIpIHtcblx0XHRcdFx0XHRsb2dnZXIud2FybihgUHJvYmUgdG8gJHtpcH0gZmFpbGVkOiAke2Vyci5tZXNzYWdlfWApXG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdGZpbmlzaChudWxsKVxuXHRcdFx0XHR9XG5cdFx0XHR9KVxuXHRcdH1cblxuXHRcdHJ1bigpLmNhdGNoKChlKSA9PiB7XG5cdFx0XHRsb2dnZXIud2FybihgcHJvYmVEZXZpY2Ugc2V0dXAgZmFpbGVkIGZvciAke2lwfTogJHtlfWApXG5cdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRmaW5pc2gobnVsbClcblx0XHR9KVxuXHR9KVxufVxuIiwgImltcG9ydCBkZ3JhbSBmcm9tICdkZ3JhbSdcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBnZXRNYWNGb3JEZXN0aW5hdGlvbiwgZ2V0TG9jYWxBZGRyZXNzRm9yRGVzdGluYXRpb24gfSBmcm9tICcuL2RhbnRlLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ0Nvbk1vbicpXG5cbi8qKiBDb2FsZXNjZXMgY29uY3VycmVudCBvcGVuQ29uTW9uU2Vzc2lvbiBjYWxscyBwZXIgSVAgKi9cbmNvbnN0IF9jb25tb25QZW5kaW5nID0gbmV3IE1hcDxzdHJpbmcsIFByb21pc2U8KCgpID0+IHZvaWQpIHwgbnVsbD4+KClcblxuLyoqXG4gKiBPcGVucyBhIERhbnRlIENvbk1vbiBzZXNzaW9uIHdpdGggdGhlIGRldmljZSBvbiBwb3J0IDg4MDAuXG4gKiBPbmx5IG5lZWRlZCBmb3IgZGV2aWNlcyB3aXRoIFwidXNlQ29uTW9uXCI6IHRydWUgaW4gdGhlaXIgZGV2aWNlIEpTT04uXG4gKiBSZXR1cm5zIGEgY2xlYW51cCBmdW5jdGlvbiB0byBzdG9wIGtlZXBhbGl2ZXMgYW5kIGNsb3NlIHRoZSBzb2NrZXQsIG9yIG51bGwgb24gZmFpbHVyZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG9wZW5Db25Nb25TZXNzaW9uKGRldmljZUlwOiBzdHJpbmcsIHRpbWVvdXRNcyA9IDMwMDApOiBQcm9taXNlPCgoKSA9PiB2b2lkKSB8IG51bGw+IHtcblx0Y29uc3QgcGVuZGluZyA9IF9jb25tb25QZW5kaW5nLmdldChkZXZpY2VJcClcblx0aWYgKHBlbmRpbmcpIHJldHVybiBwZW5kaW5nXG5cblx0Y29uc3QgcHJvbWlzZSA9IF9kb0Nvbk1vblNlc3Npb24oZGV2aWNlSXAsIHRpbWVvdXRNcykuZmluYWxseSgoKSA9PiB7XG5cdFx0X2Nvbm1vblBlbmRpbmcuZGVsZXRlKGRldmljZUlwKVxuXHR9KVxuXHRfY29ubW9uUGVuZGluZy5zZXQoZGV2aWNlSXAsIHByb21pc2UpXG5cdHJldHVybiBwcm9taXNlXG59XG5cbmFzeW5jIGZ1bmN0aW9uIF9kb0Nvbk1vblNlc3Npb24oZGV2aWNlSXA6IHN0cmluZywgdGltZW91dE1zOiBudW1iZXIpOiBQcm9taXNlPCgoKSA9PiB2b2lkKSB8IG51bGw+IHtcblx0cmV0dXJuIG5ldyBQcm9taXNlPCgoKSA9PiB2b2lkKSB8IG51bGw+KChyZXNvbHZlKSA9PiB7XG5cdFx0bGV0IHNldHRsZWQgPSBmYWxzZVxuXHRcdGxldCBrZWVwYWxpdmVUaW1lcjogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGxcblxuXHRcdGNvbnN0IGNsb3NlU2Vzc2lvbiA9IChzb2NrOiBkZ3JhbS5Tb2NrZXQpID0+IHtcblx0XHRcdGlmIChrZWVwYWxpdmVUaW1lcikge1xuXHRcdFx0XHRjbGVhckludGVydmFsKGtlZXBhbGl2ZVRpbWVyKVxuXHRcdFx0XHRrZWVwYWxpdmVUaW1lciA9IG51bGxcblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdHNvY2suY2xvc2UoKVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBDb25Nb24gc2Vzc2lvbiBjbG9zZWQgZm9yICR7ZGV2aWNlSXB9YClcblx0XHR9XG5cblx0XHRjb25zdCBmYWlsID0gKHNvY2s6IGRncmFtLlNvY2tldCkgPT4ge1xuXHRcdFx0aWYgKHNldHRsZWQpIHJldHVyblxuXHRcdFx0c2V0dGxlZCA9IHRydWVcblx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdGNsb3NlU2Vzc2lvbihzb2NrKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBDb25Nb24gc2Vzc2lvbiBub3QgZXN0YWJsaXNoZWQgZm9yICR7ZGV2aWNlSXB9YClcblx0XHRcdHJlc29sdmUobnVsbClcblx0XHR9XG5cblx0XHRjb25zdCBzb2NrID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4gZmFpbChzb2NrKSwgdGltZW91dE1zKVxuXG5cdFx0c29jay5vbignZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHRsb2dnZXIud2FybihgQ29uTW9uIHNvY2tldCBlcnJvciBmb3IgJHtkZXZpY2VJcH06ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHRcdGZhaWwoc29jaylcblx0XHR9KVxuXG5cdFx0c29jay5vbignbWVzc2FnZScsIChtc2c6IEJ1ZmZlcikgPT4ge1xuXHRcdFx0Ly8gRGV2aWNlIEFDSzogdHlwZSBieXRlIDB4MjAgYXQgb2Zmc2V0IDNcblx0XHRcdGlmICghc2V0dGxlZCAmJiBtc2cubGVuZ3RoID49IDQgJiYgbXNnWzBdID09PSAweDEyICYmIG1zZ1szXSA9PT0gMHgyMCkge1xuXHRcdFx0XHRzZXR0bGVkID0gdHJ1ZVxuXHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBDb25Nb24gc2Vzc2lvbiBlc3RhYmxpc2hlZCB3aXRoICR7ZGV2aWNlSXB9YClcblxuXHRcdFx0XHRsZXQga2VlcGFsaXZlU2VxID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMHhmZmZlKSArIDFcblx0XHRcdFx0Y29uc3Qgc2VuZEtlZXBhbGl2ZSA9ICgpID0+IHtcblx0XHRcdFx0XHRjb25zdCBwa3QgPSBCdWZmZXIuYWxsb2MoMjAsIDApXG5cdFx0XHRcdFx0cGt0WzBdID0gMHgxMlxuXHRcdFx0XHRcdHBrdFszXSA9IDB4NGVcblx0XHRcdFx0XHRwa3Qud3JpdGVVSW50MTZCRShrZWVwYWxpdmVTZXErKyAmIDB4ZmZmZiwgNClcblx0XHRcdFx0XHRwa3RbNl0gPSAweDMwXG5cdFx0XHRcdFx0cGt0WzddID0gMHgxMFxuXHRcdFx0XHRcdHNvY2suc2VuZChwa3QsIDg4MDAsIGRldmljZUlwLCAoKSA9PiB7XG5cdFx0XHRcdFx0XHQvKiBmaXJlIGFuZCBmb3JnZXQgKi9cblx0XHRcdFx0XHR9KVxuXHRcdFx0XHR9XG5cdFx0XHRcdGtlZXBhbGl2ZVRpbWVyID0gc2V0SW50ZXJ2YWwoc2VuZEtlZXBhbGl2ZSwgMTAwMClcblx0XHRcdFx0cmVzb2x2ZSgoKSA9PiBjbG9zZVNlc3Npb24oc29jaykpXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdGNvbnN0IGRvSW5pdCA9IGFzeW5jICgpID0+IHtcblx0XHRcdGxldCBsb2NhbElwOiBzdHJpbmdcblx0XHRcdGxldCBsb2NhbE1hYzogbnVtYmVyW11cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGxvY2FsSXAgPSBhd2FpdCBnZXRMb2NhbEFkZHJlc3NGb3JEZXN0aW5hdGlvbihkZXZpY2VJcClcblx0XHRcdFx0bG9jYWxNYWMgPSBhd2FpdCBnZXRNYWNGb3JEZXN0aW5hdGlvbihkZXZpY2VJcClcblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYENvbk1vbjogY291bGQgbm90IGdldCBsb2NhbCBuZXR3b3JrIGluZm8gZm9yICR7ZGV2aWNlSXB9OiAke2V9YClcblx0XHRcdFx0ZmFpbChzb2NrKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0c29jay5iaW5kKHsgcG9ydDogODgwMCwgYWRkcmVzczogbG9jYWxJcCB9LCAoKSA9PiB7XG5cdFx0XHRcdGNvbnN0IHNlcSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDB4ZmZmZSkgKyAxXG5cdFx0XHRcdGNvbnN0IHBrdCA9IEJ1ZmZlci5hbGxvYygyMCwgMClcblx0XHRcdFx0cGt0WzBdID0gMHgxMlxuXHRcdFx0XHRwa3RbM10gPSAweDE0XG5cdFx0XHRcdHBrdC53cml0ZVVJbnQxNkJFKHNlcSwgNClcblx0XHRcdFx0cGt0WzZdID0gMHgxMFxuXHRcdFx0XHRwa3RbN10gPSAweDAxXG5cdFx0XHRcdGxvY2FsTWFjLmZvckVhY2goKGIsIGkpID0+IHtcblx0XHRcdFx0XHRwa3RbMTIgKyBpXSA9IGJcblx0XHRcdFx0fSlcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBDb25Nb24gVFggdG8gJHtkZXZpY2VJcH06ICR7cGt0LnRvU3RyaW5nKCdoZXgnKX1gKVxuXHRcdFx0XHRzb2NrLnNlbmQocGt0LCA4ODAwLCBkZXZpY2VJcCwgKGVycikgPT4ge1xuXHRcdFx0XHRcdGlmIChlcnIpIHtcblx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKGBDb25Nb24gc2VuZCBmYWlsZWQgZm9yICR7ZGV2aWNlSXB9OiAke2Vyci5tZXNzYWdlfWApXG5cdFx0XHRcdFx0XHRmYWlsKHNvY2spXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9KVxuXHRcdFx0fSlcblx0XHR9XG5cblx0XHRkb0luaXQoKS5jYXRjaCgoZSkgPT4ge1xuXHRcdFx0bG9nZ2VyLndhcm4oYENvbk1vbiBpbml0IGZhaWxlZCBmb3IgJHtkZXZpY2VJcH06ICR7ZX1gKVxuXHRcdFx0ZmFpbChzb2NrKVxuXHRcdH0pXG5cdH0pXG59XG4iLCAiaW1wb3J0IHtcblx0SW5zdGFuY2VUeXBlcyxcblx0SW5zdGFuY2VCYXNlLFxuXHRJbnN0YW5jZVN0YXR1cyxcblx0U29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkLFxuXHRjcmVhdGVNb2R1bGVMb2dnZXIsXG59IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBHZXRDb25maWdGaWVsZHMsIHJlc29sdmVIb3N0LCByZXNvbHZlTW9kZWwsIGdldERldmljZVNjaGVtYSwgdHlwZSBNb2R1bGVDb25maWcgfSBmcm9tICcuL2NvbmZpZy5qcydcbmltcG9ydCB7IFVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMsIFVwZGF0ZVZhcmlhYmxlVmFsdWVzIH0gZnJvbSAnLi92YXJpYWJsZXMuanMnXG5pbXBvcnQgeyBVcGdyYWRlU2NyaXB0cyB9IGZyb20gJy4vdXBncmFkZXMuanMnXG5pbXBvcnQgeyBVcGRhdGVBY3Rpb25zIH0gZnJvbSAnLi9hY3Rpb25zLmpzJ1xuaW1wb3J0IHsgVXBkYXRlRmVlZGJhY2tzIH0gZnJvbSAnLi9mZWVkYmFja3MuanMnXG5pbXBvcnQgeyBTdENvbnRyb2xsZXIgfSBmcm9tICcuL3N0Y29udHJvbGxlci5qcydcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignTW9kdWxlSW5zdGFuY2UnKVxuXG5leHBvcnQgdHlwZSBNb2R1bGVUeXBlcyA9IEluc3RhbmNlVHlwZXMgJiB7XG5cdGNvbmZpZzogTW9kdWxlQ29uZmlnXG59XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1vZHVsZUluc3RhbmNlIGV4dGVuZHMgSW5zdGFuY2VCYXNlPE1vZHVsZVR5cGVzPiB7XG5cdGNvbmZpZyE6IE1vZHVsZUNvbmZpZyAvLyBTZXR1cCBpbiBpbml0KClcblx0c3RDb250cm9sbGVyITogU3RDb250cm9sbGVyXG5cblx0LyoqIENhY2hlZCBkaXNjb3ZlcnkgcmVzdWx0cyBcdTIwMTQgcGFzc2VkIGludG8gZ2V0Q29uZmlnRmllbGRzKCkgc28gdGhlIFVJXG5cdCAqICBjYW4gc2hvdyB0aGUgZGlzY292ZXJlZCBkZXZpY2UgZHJvcGRvd24gb24gc3Vic2VxdWVudCBjb25maWcgb3BlbnMuICovXG5cdHByaXZhdGUgZGlzY292ZXJlZERldmljZXM6IERldmljZUluZm9bXSA9IFtdXG5cblx0LyoqIEN1cnJlbnRseSBhY3RpdmUgbW9kZWwgXHUyMDE0IHJlc29sdmVkIG9uY2UgaW4gc3luY01vZGVsKCkgYW5kIGNhY2hlZCBoZXJlXG5cdCAqICBzbyBVcGRhdGVBY3Rpb25zLCBVcGRhdGVGZWVkYmFja3MgZXRjLiBkb24ndCBlYWNoIGNhbGwgcmVzb2x2ZU1vZGVsIGluZGVwZW5kZW50bHkuICovXG5cdGFjdGl2ZU1vZGVsOiBzdHJpbmcgPSAnJ1xuXG5cdGNvbnN0cnVjdG9yKGludGVybmFsOiB1bmtub3duKSB7XG5cdFx0c3VwZXIoaW50ZXJuYWwpXG5cdH1cblxuXHRhc3luYyBpbml0KGNvbmZpZzogTW9kdWxlQ29uZmlnKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dGhpcy5jb25maWcgPSBjb25maWdcblx0XHRpZiAoIXRoaXMuc3RDb250cm9sbGVyKSB7XG5cdFx0XHR0aGlzLnN0Q29udHJvbGxlciA9IG5ldyBTdENvbnRyb2xsZXIoKVxuXHRcdH1cblx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5Db25uZWN0aW5nLCAnRGlzY292ZXJpbmcgZGV2aWNlcy4uLicpXG5cblx0XHQvLyBXaXJlIGZlZWRiYWNrIGNhbGxiYWNrIHNvIHN0Q29udHJvbGxlciBjYW4gdHJpZ2dlciBmZWVkYmFjayB1cGRhdGVzXG5cdFx0dGhpcy5zdENvbnRyb2xsZXIuc2V0RmVlZGJhY2tDYWxsYmFjaygoZmVlZGJhY2tJZDogc3RyaW5nKSA9PiB7XG5cdFx0XHR0aGlzLmNoZWNrRmVlZGJhY2tzKGZlZWRiYWNrSWQpXG5cdFx0fSlcblxuXHRcdC8vIFN0YXJ0IGRpc2NvdmVyeSBpbiB0aGUgYmFja2dyb3VuZCBcdTIwMTQgYWxsIG1vZGVsIHJlc29sdXRpb24sIHNjaGVtYSBzeW5jLFxuXHRcdC8vIGFuZCBVSSB1cGRhdGVzIGhhcHBlbiBpbnNpZGUgcnVuRGlzY292ZXJ5KCkgb25jZSB0aGUgZGV2aWNlIGxpc3QgaXMga25vd24uXG5cdFx0dGhpcy5ydW5EaXNjb3ZlcnkoKS5jYXRjaCgoZSkgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBEaXNjb3ZlcnkgZmFpbGVkOiAke2V9YClcblx0XHR9KVxuXHR9XG5cblx0LyoqXG5cdCAqIFJ1biBkZXZpY2UgZGlzY292ZXJ5LCB0aGVuIHJlc29sdmUgdGhlIG1vZGVsIGFuZCB1cGRhdGUgYWxsIFVJLlxuXHQgKiAtIElmIGRpc2NvdmVyeSBmaW5kcyBkZXZpY2VzLCByZXNvbHZlTW9kZWwgcGlja3MgZnJvbSB0aG9zZS5cblx0ICogLSBPbmx5IGlmIHRoZSBsaXN0IGlzIGVtcHR5IGRvIHdlIGZhbGwgYmFjayB0byB0aGUgbWFudWFsIGNvbmZpZyBzZWxlY3Rpb24uXG5cdCAqIEFsbCBhY3Rpb25zL2ZlZWRiYWNrcy92YXJpYWJsZXMgYXJlIGJ1aWx0IGFmdGVyIHRoZSBtb2RlbCBpcyBrbm93bi5cblx0ICovXG5cdHByaXZhdGUgYXN5bmMgcnVuRGlzY292ZXJ5KCk6IFByb21pc2U8dm9pZD4ge1xuXHRcdGxvZ2dlci5pbmZvKCdTdGFydGluZyBkZXZpY2UgZGlzY292ZXJ5Li4uJylcblxuXHRcdHRoaXMuZGlzY292ZXJlZERldmljZXMgPSBhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5kaXNjb3ZlckRldmljZXMoKVxuXG5cdFx0Ly8gRGV0ZXJtaW5lIGVmZmVjdGl2ZSBtb2RlbCBcdTIwMTQgZnJvbSBkaXNjb3ZlcmVkIGRldmljZXMgZmlyc3QsIG1hbnVhbCBjb25maWcgb25seSBhcyBmYWxsYmFja1xuXHRcdGxldCBlZmZlY3RpdmVNb2RlbDogc3RyaW5nXG5cdFx0aWYgKHRoaXMuZGlzY292ZXJlZERldmljZXMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRpZiAodGhpcy5jb25maWcuZGV2aWNlTWFjKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBTYXZlZCBkZXZpY2UgTUFDIFwiJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XCIgbm90IGZvdW5kIGR1cmluZyBkaXNjb3ZlcnkgXHUyMDE0IHN0b3BwaW5nYClcblx0XHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuQ29ubmVjdGlvbkZhaWx1cmUsIGBbJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XSBub3QgZm91bmRgKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHRcdGNvbnN0IG1hbnVhbE1vZGVsID0gdGhpcy5jb25maWcuYWN0aXZlTW9kZWxcblx0XHRcdGlmICghdGhpcy5jb25maWcuaG9zdCB8fCAhbWFudWFsTW9kZWwpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oJ05vIGRldmljZXMgZGlzY292ZXJlZCBhbmQgbm8gbWFudWFsIElQL21vZGVsIGNvbmZpZ3VyZWQnKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHRcdGxvZ2dlci5pbmZvKCdObyBkZXZpY2VzIGRpc2NvdmVyZWQgXHUyMDE0IHdpbGwgcHJvYmUgbWFudWFsIElQIGR1cmluZyBhdXRob3JpemF0aW9uJylcblx0XHRcdGVmZmVjdGl2ZU1vZGVsID0gbWFudWFsTW9kZWxcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYERpc2NvdmVyZWQgJHt0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmxlbmd0aH0gZGV2aWNlKHMpOmApXG5cdFx0XHRmb3IgKGNvbnN0IGQgb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHRsb2dnZXIuaW5mbyhgICAtIE1vZGVsICR7ZC5tb2RlbH0gJHtkLm1hbnVmYWN0dXJlciA/PyAnJ30gQCAke2QuaXB9YClcblx0XHRcdH1cblxuXHRcdFx0Ly8gQXV0aG9yaXplIGFsbCBkaXNjb3ZlcmVkIGRldmljZXMgc28gZmlybXdhcmUgcmVxdWVzdHMgY2FuIHByb2NlZWQuXG5cdFx0XHQvLyB2ZXJpZnlBdXRob3JpemF0aW9uIChjYWxsZWQgYmVsb3cpIHdpbGwgcmV2b2tlIGFueSB0aGF0IGRvbid0IG1hdGNoXG5cdFx0XHQvLyB0aGUgY3VycmVudCBjb25maWcgc2VsZWN0aW9uLlxuXHRcdFx0Zm9yIChjb25zdCBkZXZpY2Ugb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5hdXRob3JpemVEZXZpY2UoZGV2aWNlLmlwKVxuXHRcdFx0fVxuXG5cdFx0XHQvLyBSZXF1ZXN0IGZpcm13YXJlIHZlcnNpb24gZnJvbSBlYWNoIGRpc2NvdmVyZWQgZGV2aWNlXG5cdFx0XHRmb3IgKGNvbnN0IGRldmljZSBvZiB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKSB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0Y29uc3QgZmlybXdhcmUgPSBhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5yZXF1ZXN0RmlybXdhcmVWZXJzaW9uKGRldmljZS5pcClcblx0XHRcdFx0XHRkZXZpY2UuZmlybXdhcmVNYWluID0gZmlybXdhcmVcblx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgICAtICR7ZGV2aWNlLmlwfTogRmlybXdhcmUgJHtmaXJtd2FyZX0sIERhbnRlICR7ZGV2aWNlLmRhbnRlRmlybXdhcmV9YClcblx0XHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRcdGxvZ2dlci53YXJuKGAgIC0gJHtkZXZpY2UuaXB9OiBGYWlsZWQgdG8gZ2V0IGZpcm13YXJlOiAke2V9YClcblx0XHRcdFx0XHRkZXZpY2UuZmlybXdhcmVNYWluID0gJ1Vua25vd24nXG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0ZWZmZWN0aXZlTW9kZWwgPSByZXNvbHZlTW9kZWwodGhpcy5jb25maWcsIHRoaXMuZGlzY292ZXJlZERldmljZXMpXG5cblx0XHRcdGlmICghZWZmZWN0aXZlTW9kZWwgJiYgdGhpcy5jb25maWcuZGV2aWNlTWFjKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBTYXZlZCBkZXZpY2UgTUFDIFwiJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XCIgbm90IGZvdW5kIGFtb25nIGRpc2NvdmVyZWQgZGV2aWNlcyBcdTIwMTQgc3RvcHBpbmdgKVxuXHRcdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5Db25uZWN0aW9uRmFpbHVyZSwgYFske3RoaXMuY29uZmlnLmRldmljZU1hY31dIG5vdCBmb3VuZGApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIFN5bmMgbW9kZWwgc2NoZW1hIHRvIGNvbnRyb2xsZXJcblx0XHR0aGlzLnN5bmNNb2RlbChlZmZlY3RpdmVNb2RlbClcblxuXHRcdC8vIFZlcmlmeSB0aGF0IHRoZSBjdXJyZW50bHkgY29uZmlndXJlZCBob3N0K21vZGVsIGlzIHZhbGlkIG5vdyB0aGF0XG5cdFx0Ly8gZGlzY292ZXJ5IHJlc3VsdHMgYXJlIGtub3duLiBUaGlzIGlzIHRoZSBzYW1lIGNoZWNrIGNvbmZpZ1VwZGF0ZWQgdXNlcy5cblx0XHRjb25zdCB0YXJnZXRIb3N0ID0gdGhpcy5ob3N0XG5cdFx0YXdhaXQgdGhpcy52ZXJpZnlBdXRob3JpemF0aW9uKCcnLCB0YXJnZXRIb3N0KVxuXG5cdFx0Ly8gQnVpbGQgYWxsIFVJIG5vdyB0aGF0IG1vZGVsIGFuZCBhdXRob3JpemF0aW9uIHN0YXRlIGFyZSBrbm93blxuXHRcdHRoaXMudXBkYXRlQWN0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVGZWVkYmFja3MoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZVZhbHVlcygpXG5cblx0XHRsb2dnZXIuaW5mbygnRGV2aWNlIGRpc2NvdmVyeSBjb21wbGV0ZScpXG5cdH1cblxuXHQvLyBXaGVuIG1vZHVsZSBnZXRzIGRlbGV0ZWRcblx0YXN5bmMgZGVzdHJveSgpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0aGlzLnN0Q29udHJvbGxlcj8uY2xvc2UoKVxuXHRcdGxvZ2dlci5kZWJ1ZygnZGVzdHJveScpXG5cdH1cblxuXHRhc3luYyBjb25maWdVcGRhdGVkKGNvbmZpZzogTW9kdWxlQ29uZmlnKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0Y29uc3QgcHJldmlvdXNIb3N0ID0gdGhpcy5ob3N0XG5cdFx0dGhpcy5jb25maWcgPSBjb25maWdcblx0XHRjb25zdCBlZmZlY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbChjb25maWcsIHRoaXMuZGlzY292ZXJlZERldmljZXMpXG5cdFx0dGhpcy5zeW5jTW9kZWwoZWZmZWN0aXZlTW9kZWwpXG5cblx0XHQvLyBDbGVhciB2YXJpYWJsZXMgaW1tZWRpYXRlbHkgXHUyMDE0IHRoZSBuZXcgc2VsZWN0aW9uIGlzbid0IGF1dGhvcml6ZWQgeWV0LlxuXHRcdC8vIFRoZXknbGwgYmUgcmVwb3B1bGF0ZWQgYmVsb3cgb25jZSB2ZXJpZnlBdXRob3JpemF0aW9uIGNvbXBsZXRlcy5cblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlVmFsdWVzKClcblxuXHRcdGNvbnN0IG5ld0hvc3QgPSB0aGlzLmhvc3RcblxuXHRcdC8vIFJlLXZlcmlmeSBhdXRob3JpemF0aW9uIG9uIGV2ZXJ5IGNvbmZpZyBjaGFuZ2UgKG1vZGVsIG9yIElQKS5cblx0XHQvLyBUaGlzIGhhbmRsZXMgc3dpdGNoaW5nIGZyb20gYSB2YWxpZCBkZXZpY2UgdG8gYW4gaW52YWxpZCBvbmUgYW5kIGJhY2suXG5cdFx0YXdhaXQgdGhpcy52ZXJpZnlBdXRob3JpemF0aW9uKHByZXZpb3VzSG9zdCwgbmV3SG9zdClcblxuXHRcdC8vIFJlYnVpbGQgVUkgYWZ0ZXIgYXV0aG9yaXphdGlvbiBzdGF0ZSBpcyBzZXR0bGVkXG5cdFx0dGhpcy51cGRhdGVBY3Rpb25zKClcblx0XHR0aGlzLnVwZGF0ZUZlZWRiYWNrcygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlVmFsdWVzKClcblx0fVxuXG5cdC8qKlxuXHQgKiBSZS1ldmFsdWF0ZXMgd2hldGhlciB0aGUgY3VycmVudCBjb25maWcgaXMgYXV0aG9yaXplZCB0byBzZW5kIGNvbW1hbmRzLlxuXHQgKlxuXHQgKiBBdXRvIG1vZGUgKGRldmljZU1hYyBzZXQpOlxuXHQgKiAgIC0gRmluZCB0aGUgZGlzY292ZXJlZCBkZXZpY2Ugd2l0aCBtYXRjaGluZyBNQUMgXHUyMTkyIGdldCBpdHMgY3VycmVudCBJUFxuXHQgKiAgIC0gUmV2b2tlIHRoZSBwcmV2aW91cyBJUCwgYXV0aG9yaXplIHRoZSBuZXcgSVBcblx0ICogICAtIElmIE1BQyBub3QgZm91bmQgaW4gZGlzY292ZXJ5LCByZXZva2UgYW5kIGJsb2NrXG5cdCAqXG5cdCAqIE1hbnVhbCBtb2RlIChkZXZpY2VNYWMgZW1wdHkpOlxuXHQgKiAgIC0gQ2hlY2sgZGlzY292ZXJlZCBsaXN0IGJ5IElQK21vZGVsIG1hdGNoLCBvciBwcm9iZSBkaXJlY3RseVxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyB2ZXJpZnlBdXRob3JpemF0aW9uKHByZXZpb3VzSG9zdDogc3RyaW5nLCBuZXdIb3N0OiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHRpZiAoIW5ld0hvc3QpIHtcblx0XHRcdGlmIChwcmV2aW91c0hvc3QpIHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRpZiAodGhpcy5jb25maWcuZGV2aWNlTWFjKSB7XG5cdFx0XHQvLyBBdXRvIG1vZGUgXHUyMDE0IG1hdGNoIGJ5IE1BQywgdXNlIHdoYXRldmVyIElQIGRpc2NvdmVyeSBmb3VuZCBpdCBhdFxuXHRcdFx0Y29uc3QgZGV2aWNlID0gdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLm1hYyA9PT0gdGhpcy5jb25maWcuZGV2aWNlTWFjKVxuXHRcdFx0aWYgKCFkZXZpY2UpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYERldmljZSBNQUMgXCIke3RoaXMuY29uZmlnLmRldmljZU1hY31cIiBub3QgZm91bmQgaW4gY3VycmVudCBkaXNjb3ZlcnkgXHUyMDE0IG5vdCBhdXRob3JpemluZ2ApXG5cdFx0XHRcdGlmIChwcmV2aW91c0hvc3QpIHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHRpZiAocHJldmlvdXNIb3N0ICYmIHByZXZpb3VzSG9zdCAhPT0gbmV3SG9zdCkge1xuXHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdFx0fVxuXHRcdFx0Y29uc3Qgd2FzQXV0aG9yaXplZCA9IHRoaXMuc3RDb250cm9sbGVyLmlzRGV2aWNlQXV0aG9yaXplZChuZXdIb3N0KVxuXHRcdFx0aWYgKCF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShuZXdIb3N0KVxuXHRcdFx0fVxuXHRcdFx0aWYgKG5ld0hvc3QgIT09IHByZXZpb3VzSG9zdCB8fCAhd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHRhd2FpdCB0aGlzLmZldGNoU2V0dGluZ3NBbmRFbnN1cmVTY2hlbWEoZGV2aWNlLm1vZGVsLCBuZXdIb3N0KVxuXHRcdFx0fVxuXHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuT2ssIGBNb2RlbCAke2RldmljZS5tb2RlbH0gQCAke25ld0hvc3R9YClcblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdC8vIE1hbnVhbCBtb2RlIFx1MjAxNCBjb25maWcuaG9zdCArIGNvbmZpZy5hY3RpdmVNb2RlbCBtdXN0IG1hdGNoXG5cdFx0Y29uc3QgbWFudWFsTW9kZWwgPSBTdHJpbmcodGhpcy5jb25maWcuYWN0aXZlTW9kZWwgPz8gJycpXG5cdFx0Y29uc3QgZGlzY292ZXJlZEF0SXAgPSB0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmZpbmQoKGQpID0+IGQuaXAgPT09IG5ld0hvc3QpXG5cblx0XHRpZiAoZGlzY292ZXJlZEF0SXApIHtcblx0XHRcdGlmIChkaXNjb3ZlcmVkQXRJcC5tb2RlbCA9PT0gbWFudWFsTW9kZWwpIHtcblx0XHRcdFx0aWYgKHByZXZpb3VzSG9zdCAmJiBwcmV2aW91c0hvc3QgIT09IG5ld0hvc3QpIHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHRcdGNvbnN0IHdhc0F1dGhvcml6ZWQgPSB0aGlzLnN0Q29udHJvbGxlci5pc0RldmljZUF1dGhvcml6ZWQobmV3SG9zdClcblx0XHRcdFx0aWYgKCF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuYXV0aG9yaXplRGV2aWNlKG5ld0hvc3QpXG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKG5ld0hvc3QgIT09IHByZXZpb3VzSG9zdCB8fCAhd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHRcdGF3YWl0IHRoaXMuZmV0Y2hTZXR0aW5nc0FuZEVuc3VyZVNjaGVtYShtYW51YWxNb2RlbCwgbmV3SG9zdClcblx0XHRcdFx0fVxuXHRcdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5PaywgYE1vZGVsICR7bWFudWFsTW9kZWx9IEAgJHtuZXdIb3N0fWApXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRsb2dnZXIuZXJyb3IoXG5cdFx0XHRcdFx0YERldmljZSBzZWxlY3RlZCAoTW9kZWwgJHttYW51YWxNb2RlbH0pIGRvZXMgbm90IG1hdGNoIGRldGVjdGVkIGRldmljZSAoTW9kZWwgJHtkaXNjb3ZlcmVkQXRJcC5tb2RlbH0pIGF0ICR7bmV3SG9zdH0gXHUyMDE0IGNvbW1hbmRzIGJsb2NrZWRgLFxuXHRcdFx0XHQpXG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShuZXdIb3N0KVxuXHRcdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhcblx0XHRcdFx0XHRJbnN0YW5jZVN0YXR1cy5Db25uZWN0aW9uRmFpbHVyZSxcblx0XHRcdFx0XHRgTW9kZWwgbWlzbWF0Y2g6IGV4cGVjdGVkICR7bWFudWFsTW9kZWx9LCBnb3QgJHtkaXNjb3ZlcmVkQXRJcC5tb2RlbH1gLFxuXHRcdFx0XHQpXG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBJUCBub3QgaW4gZGlzY292ZXJlZCBsaXN0IFx1MjAxNCBwcm9iZSBpdCBkaXJlY3RseSB2aWEgRGFudGVcblx0XHRsb2dnZXIuaW5mbyhgJHtuZXdIb3N0fSBub3QgaW4gZGlzY292ZXJlZCBsaXN0IFx1MjAxNCBwcm9iaW5nYClcblx0XHRpZiAocHJldmlvdXNIb3N0ICYmIHByZXZpb3VzSG9zdCAhPT0gbmV3SG9zdCkgdGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHR0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UobmV3SG9zdClcblxuXHRcdGNvbnN0IHByb2JlZCA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnByb2JlRGV2aWNlKG5ld0hvc3QpXG5cdFx0aWYgKCFwcm9iZWQpIHtcblx0XHRcdGxvZ2dlci5lcnJvcihgTm8gZGV2aWNlIHJlc3BvbmRlZCBhdCAke25ld0hvc3R9IFx1MjAxNCBjb21tYW5kcyBibG9ja2VkYClcblx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLlVua25vd25XYXJuaW5nLCBgRGV2aWNlIG9mZmxpbmU6ICR7bmV3SG9zdH1gKVxuXHRcdH0gZWxzZSBpZiAocHJvYmVkLm1vZGVsICE9PSBtYW51YWxNb2RlbCkge1xuXHRcdFx0bG9nZ2VyLmVycm9yKFxuXHRcdFx0XHRgRGV2aWNlIHNlbGVjdGVkIChNb2RlbCAke21hbnVhbE1vZGVsfSkgZG9lcyBub3QgbWF0Y2ggZGV0ZWN0ZWQgZGV2aWNlIChNb2RlbCAke3Byb2JlZC5tb2RlbH0pIGF0ICR7bmV3SG9zdH0gXHUyMDE0IGNvbW1hbmRzIGJsb2NrZWRgLFxuXHRcdFx0KVxuXHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoXG5cdFx0XHRcdEluc3RhbmNlU3RhdHVzLkNvbm5lY3Rpb25GYWlsdXJlLFxuXHRcdFx0XHRgTW9kZWwgbWlzbWF0Y2g6IGV4cGVjdGVkICR7bWFudWFsTW9kZWx9LCBnb3QgJHtwcm9iZWQubW9kZWx9YCxcblx0XHRcdClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYFZlcmlmaWVkIE1vZGVsICR7cHJvYmVkLm1vZGVsfSBhdCAke25ld0hvc3R9YClcblx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShuZXdIb3N0KVxuXHRcdFx0YXdhaXQgdGhpcy5mZXRjaFNldHRpbmdzQW5kRW5zdXJlU2NoZW1hKG1hbnVhbE1vZGVsLCBuZXdIb3N0KVxuXHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuT2ssIGBNb2RlbCAke3Byb2JlZC5tb2RlbH0gQCAke25ld0hvc3R9YClcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogRmV0Y2hlcyBhbGwgc2V0dGluZ3MgZnJvbSB0aGUgZGV2aWNlLiBJZiBubyBzY2hlbWEgZXhpc3RzIGZvciB0aGUgbW9kZWwsXG5cdCAqIGNyZWF0ZXMgb25lIGZyb20gdGhlIHJlc3BvbnNlIGFuZCByZWxvYWRzIHRoZSBzY2hlbWEgY2FjaGUuXG5cdCAqL1xuXHRwcml2YXRlIGFzeW5jIGZldGNoU2V0dGluZ3NBbmRFbnN1cmVTY2hlbWEobW9kZWw6IHN0cmluZywgaXA6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRyeSB7XG5cdFx0XHRhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5yZXF1ZXN0QWxsU2V0dGluZ3MoaXApXG5cblx0XHRcdGlmICghZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKSkge1xuXHRcdFx0XHQvLyBObyBzY2hlbWEgZXhpc3RzIFx1MjAxNCBkbyBOT1QgYXV0by1jcmVhdGUgb25lIGhlcmUuXG5cdFx0XHRcdC8vIFRoZSB1c2VyIG11c3QgcnVuIFwiR0xPQkFMOiBHZXQgQWxsIFNldHRpbmdzXCIgdG8gY3JlYXRlIGl0LlxuXHRcdFx0XHRsb2dnZXIud2FybihgTm8gc2NoZW1hIGZvdW5kIGZvciBNb2RlbCAke21vZGVsfSBcdTIwMTQgcnVuIFwiR0xPQkFMOiBHZXQgQWxsIFNldHRpbmdzXCIgdG8gY3JlYXRlIG9uZWApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gZmV0Y2ggc2V0dGluZ3MgZnJvbSAke2lwfTogJHtlfWApXG5cdFx0fVxuXHR9XG5cblx0LyoqIExvYWRzIHRoZSBkZXZpY2UgSlNPTiBmb3IgdGhlIGdpdmVuIG1vZGVsLCBjYWNoZXMgaXQgYXMgYWN0aXZlTW9kZWwsIGFuZCBwdXNoZXMgaXQgdG8gdGhlIGNvbnRyb2xsZXIuICovXG5cdHByaXZhdGUgc3luY01vZGVsKG1vZGVsOiBzdHJpbmcpOiB2b2lkIHtcblx0XHR0aGlzLmFjdGl2ZU1vZGVsID0gbW9kZWxcblx0XHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdFx0aWYgKCFzY2hlbWEpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBNb2RlbCBcIiR7bW9kZWx9XCIgbm90IGZvdW5kIGluIGRldmljZSBzY2hlbWFzYClcblx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnNldE1vZGVsKG1vZGVsLCBbXSlcblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdGNvbnN0IGFjdGlvbnMgPSBBcnJheS5pc0FycmF5KHNjaGVtYS5jbWRTY2hlbWEpID8gc2NoZW1hLmNtZFNjaGVtYSA6IFtdXG5cblx0XHR0aGlzLnN0Q29udHJvbGxlci5zZXRNb2RlbChtb2RlbCwgYWN0aW9ucylcblx0XHRpZiAoYWN0aW9ucy5sZW5ndGggPT09IDApIHtcblx0XHRcdGxvZ2dlci53YXJuKGBObyBhY3Rpb25zIGZvdW5kIGZvciBtb2RlbCBcIiR7bW9kZWx9XCIgXHUyMDE0IHNldHRpbmdzIGRlY29kaW5nIHdpbGwgdXNlIHJhdyBJRHNgKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuZGVidWcoYExvYWRlZCAke2FjdGlvbnMubGVuZ3RofSBhY3Rpb25zIGZvciBtb2RlbCBcIiR7bW9kZWx9XCIsIHNlY3Rpb25lZD0ke3NjaGVtYS5zZWN0aW9uZWR9YClcblx0XHR9XG5cdH1cblxuXHRnZXRDb25maWdGaWVsZHMoKTogU29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkW10ge1xuXHRcdHJldHVybiBHZXRDb25maWdGaWVsZHModGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0fVxuXG5cdC8qKiBSZXR1cm5zIHRoZSBlZmZlY3RpdmUgaG9zdCBJUCwgcmVzb2x2ZWQgZnJvbSBNQUNcdTIxOTJJUCB2aWEgZGlzY292ZXJlZERldmljZXMgKGF1dG8pIG9yIGNvbmZpZy5ob3N0IChtYW51YWwpLiAqL1xuXHRnZXQgaG9zdCgpOiBzdHJpbmcge1xuXHRcdHJldHVybiByZXNvbHZlSG9zdCh0aGlzLmNvbmZpZywgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0fVxuXG5cdC8qKiBSZXR1cm5zIGRpc2NvdmVyZWQgZGV2aWNlcyBmb3IgdXNlIGluIGFjdGlvbnMvY29uZmlnICovXG5cdGdldCBkZXZpY2VzKCk6IERldmljZUluZm9bXSB7XG5cdFx0cmV0dXJuIHRoaXMuZGlzY292ZXJlZERldmljZXNcblx0fVxuXG5cdHVwZGF0ZUFjdGlvbnMoKTogdm9pZCB7XG5cdFx0VXBkYXRlQWN0aW9ucyh0aGlzKVxuXHR9XG5cblx0dXBkYXRlRmVlZGJhY2tzKCk6IHZvaWQge1xuXHRcdFVwZGF0ZUZlZWRiYWNrcyh0aGlzKVxuXHR9XG5cblx0dXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpOiB2b2lkIHtcblx0XHRVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVWYXJpYWJsZVZhbHVlcygpOiB2b2lkIHtcblx0XHRVcGRhdGVWYXJpYWJsZVZhbHVlcyh0aGlzKVxuXHR9XG59XG5cbmV4cG9ydCB7IFVwZ3JhZGVTY3JpcHRzIH1cbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7O0FBa0JBLElBQU0scUJBQWtDLENBQUMsUUFBUSxPQUFPLFlBQVc7QUFFbEUsVUFBUSxJQUFJLElBQUksTUFBTSxZQUFXLENBQUUsSUFBSSxTQUFTLEtBQUssTUFBTSxNQUFNLEVBQUUsSUFBSSxPQUFPLEVBQUU7QUFDakY7QUFFQSxTQUFTLFVBQVUsUUFBNEIsT0FBaUIsU0FBZTtBQUM5RSxRQUFNLE9BQU8sT0FBTyxPQUFPLHFCQUFxQixhQUFhLE9BQU8sbUJBQW1CO0FBQ3ZGLE9BQUssUUFBUSxPQUFPLE9BQU87QUFDNUI7QUFPTSxTQUFVLG1CQUFtQixRQUFlO0FBQ2pELFNBQU87SUFDTixPQUFPLENBQUMsWUFBb0IsVUFBVSxRQUFRLFNBQVMsT0FBTztJQUM5RCxNQUFNLENBQUMsWUFBb0IsVUFBVSxRQUFRLFFBQVEsT0FBTztJQUM1RCxNQUFNLENBQUMsWUFBb0IsVUFBVSxRQUFRLFFBQVEsT0FBTztJQUM1RCxPQUFPLENBQUMsWUFBb0IsVUFBVSxRQUFRLFNBQVMsT0FBTzs7QUFFaEU7OztBQ1RNLFNBQVUsWUFBWSxNQUFXO0FBRXZDO0FBeUJNLFNBQVUsV0FBVyxHQUFXLEdBQVcsR0FBVyxHQUFVO0FBQ3JFLE1BQUksZUFBd0IsSUFBSSxRQUFTLE1BQVEsSUFBSSxRQUFTLElBQU0sSUFBSTtBQUN4RSxNQUFJLEtBQUssS0FBSyxLQUFLLElBQUksR0FBRztBQUN6QixtQkFBZSxXQUFZLEtBQUssTUFBTSxPQUFPLElBQUksRUFBRTtFQUNwRDtBQUNBLFNBQU87QUFDUjs7O0FDL0RBLFNBQVMsb0JBQW9CO0FBMkV2QixJQUFPLHNCQUFQLGNBQW1DLGFBQW1DO0VBQ2xFO0VBQ0E7RUFFVCxJQUFXLFdBQVE7QUFDbEIsV0FBTyxLQUFLLFlBQVk7RUFDekI7RUFDQSxJQUFXLGFBQVU7QUFDcEIsV0FBTyxLQUFLLFlBQVk7RUFDekI7RUFFQSxJQUFZLGFBQVU7QUFDckIsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVcsVUFBVTtBQUNuRCxhQUFPLEtBQUs7SUFDYixPQUFPO0FBQ04sYUFBTztJQUNSO0VBQ0Q7RUFFQSxTQUF1RTtFQUV2RSxZQUFZLFNBQXlDLFNBQStCO0FBQ25GLFVBQUs7QUFFTCxTQUFLLFdBQVc7QUFDaEIsU0FBSyxXQUFXLEVBQUUsR0FBRyxRQUFPO0VBQzdCO0VBRUEsS0FBSyxNQUFjLFVBQW1CLFVBQXFCO0FBQzFELFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXO0FBQVUsWUFBTSxJQUFJLE1BQU0seUJBQXlCO0FBQzdGLFlBQVEsS0FBSyxRQUFRO01BQ3BCLEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSxvQ0FBb0M7TUFDckQsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLHlCQUF5QjtNQUMxQyxLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0sbUJBQW1CO01BQ3BDLEtBQUs7QUFDSjtNQUNEO0FBQ0Msb0JBQVksS0FBSyxNQUFNO0FBQ3ZCLGNBQU0sSUFBSSxNQUFNLHNCQUFzQjtJQUN4QztBQUVBLFNBQUssU0FBUztBQUVkLFFBQUk7QUFBVSxXQUFLLEdBQUcsYUFBYSxRQUFRO0FBRTNDLFNBQUssU0FDSCxvQkFBb0I7TUFDcEIsUUFBUSxLQUFLLFNBQVM7TUFDdEIsWUFBWTs7S0FFWixFQUNBLEtBQ0EsQ0FBQyxhQUFZO0FBQ1osV0FBSyxTQUFTLEVBQUUsWUFBWSxNQUFNLFNBQVE7QUFDMUMsV0FBSyxTQUFTLHdCQUF3QixJQUFJLFVBQVUsSUFBSTtBQUN4RCxXQUFLLEtBQUssV0FBVztJQUN0QixHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssU0FBUztBQUNkLFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBRUEsTUFBTSxVQUFxQjtBQUMxQixRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVyxVQUFVO0lBRXBELE9BQU87QUFDTixjQUFRLEtBQUssUUFBUTtRQUNwQixLQUFLO0FBQ0osZ0JBQU0sSUFBSSxNQUFNLG9DQUFvQztRQUNyRCxLQUFLO1FBQ0wsS0FBSztRQUNMLEtBQUs7QUFDSixnQkFBTSxJQUFJLE1BQU0sb0JBQW9CO1FBQ3JDO0FBQ0Msc0JBQVksS0FBSyxNQUFNO0FBQ3ZCLGdCQUFNLElBQUksTUFBTSxzQkFBc0I7TUFDeEM7SUFDRDtBQUVBLFVBQU0sV0FBVyxLQUFLLE9BQU87QUFDN0IsU0FBSyxTQUFTO0FBRWQsUUFBSTtBQUFVLFdBQUssR0FBRyxTQUFTLFFBQVE7QUFFdkMsU0FBSyxTQUNILHFCQUFxQjtNQUNyQjtLQUNBLEVBQ0EsS0FDQSxNQUFLO0FBQ0osV0FBSyxTQUFTLHdCQUF3QixPQUFPLFFBQVE7QUFDckQsV0FBSyxLQUFLLE9BQU87SUFDbEIsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLFNBQVMsd0JBQXdCLE9BQU8sUUFBUTtBQUNyRCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQVdBLEtBQ0MsY0FDQSxjQUNBLGlCQUNBLGdCQUNBLFNBQ0EsVUFBcUI7QUFFckIsUUFBSSxPQUFPLGlCQUFpQjtBQUFVLFlBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUN6RSxRQUFJLE9BQU8sb0JBQW9CLFVBQVU7QUFDeEMsVUFBSSxPQUFPLG1CQUFtQixZQUFZLE9BQU8sWUFBWTtBQUFVLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUMxRyxVQUFJLGFBQWEsVUFBYSxPQUFPLGFBQWE7QUFBWSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFFakcsWUFBTSxTQUFTLEtBQUssZUFBZSxjQUFjLGNBQWMsZUFBZTtBQUM5RSxXQUFLLFdBQVcsUUFBUSxnQkFBZ0IsU0FBUyxRQUFRO0lBQzFELFdBQVcsT0FBTyxvQkFBb0IsVUFBVTtBQUMvQyxVQUFJLG1CQUFtQixVQUFhLE9BQU8sbUJBQW1CO0FBQVksY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBRTdHLFlBQU0sU0FBUyxLQUFLLGVBQWUsY0FBYyxHQUFHLE1BQVM7QUFDN0QsV0FBSyxXQUFXLFFBQVEsY0FBYyxpQkFBaUIsY0FBYztJQUN0RSxPQUFPO0FBQ04sWUFBTSxJQUFJLE1BQU0sbUJBQW1CO0lBQ3BDO0VBQ0Q7RUFFQSxlQUNDLGNBQ0EsUUFDQSxRQUEwQjtBQUUxQixRQUFJO0FBQ0osUUFBSSxPQUFPLGlCQUFpQixVQUFVO0FBQ3JDLGVBQVMsT0FBTyxLQUFLLGNBQWMsT0FBTztJQUMzQyxXQUFXLE9BQU8sU0FBUyxZQUFZLEdBQUc7QUFDekMsZUFBUztJQUNWLFdBQVcsTUFBTSxRQUFRLFlBQVksR0FBRztBQUV2QyxhQUFPLE9BQU8sS0FBSyxZQUFZO0lBQ2hDLE9BQU87QUFDTixlQUFTLE9BQU8sS0FBSyxhQUFhLFFBQVEsYUFBYSxZQUFZLGFBQWEsVUFBVTtJQUMzRjtBQUVBLFdBQU8sT0FBTyxTQUFTLFFBQVEsV0FBVyxTQUFZLFNBQVMsU0FBUyxNQUFTO0VBQ2xGO0VBRUEsV0FBVyxRQUFnQixNQUFjLFNBQWlCLFVBQXFCO0FBQzlFLFFBQUksQ0FBQyxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVc7QUFBVSxZQUFNLElBQUksTUFBTSxvQkFBb0I7QUFFekYsU0FBSyxTQUNILG9CQUFvQjtNQUNwQixVQUFVLEtBQUssT0FBTztNQUN0QixTQUFTO01BRVQ7TUFDQTtLQUNBLEVBQ0EsS0FDQSxNQUFLO0FBQ0osaUJBQVU7SUFDWCxHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBRUEscUJBQXFCLFNBQStCO0FBQ25ELFFBQUk7QUFDSCxXQUFLLEtBQUssV0FBVyxRQUFRLFNBQVMsUUFBUSxNQUFNO0lBQ3JELFNBQVMsSUFBSTtJQUViO0VBQ0Q7RUFDQSxtQkFBbUIsT0FBWTtBQUM5QixTQUFLLFNBQVM7QUFFZCxVQUFNLGFBQWEsS0FBSztBQUN4QixRQUFJO0FBQVksV0FBSyxTQUFTLHdCQUF3QixPQUFPLFdBQVcsUUFBUTtBQUVoRixRQUFJO0FBQ0gsV0FBSyxLQUFLLFNBQVMsS0FBSztJQUN6QixTQUFTLElBQUk7SUFFYjtFQUNEOzs7O0FDOVBLLFNBQVUsa0JBQW1ELEtBQVk7QUFDOUUsUUFBTSxPQUFPO0FBQ2IsU0FBTyxDQUFDLENBQUMsUUFBUSxPQUFPLFNBQVMsWUFBWSxPQUFPLEtBQUssT0FBTyxZQUFZLEtBQUssdUJBQXVCO0FBQ3pHOzs7QUM2Qk0sSUFBZ0IsZUFBaEIsTUFBNEI7RUFDeEI7RUFDQTtFQUVBO0VBRVQsSUFBVyxLQUFFO0FBQ1osV0FBTyxLQUFLLFNBQVM7RUFDdEI7RUFFQSxJQUFXLGtCQUFlO0FBQ3pCLFdBQU8sS0FBSztFQUNiOzs7OztFQU1BLElBQVcsUUFBSztBQUNmLFdBQU8sS0FBSyxTQUFTO0VBQ3RCOzs7O0VBS0EsWUFBWSxVQUFpQjtBQUM1QixRQUFJLENBQUMsa0JBQTZCLFFBQVEsS0FBSyxDQUFDLFNBQVM7QUFDeEQsWUFBTSxJQUFJLE1BQ1QsbUdBQW1HO0FBR3JHLFNBQUssV0FBVztBQUVoQixTQUFLLFVBQVUsbUJBQWtCO0FBRWpDLFNBQUssd0JBQXdCLEtBQUssc0JBQXNCLEtBQUssSUFBSTtBQUVqRSxTQUFLLFdBQVc7TUFDZiwyQkFBMkI7TUFDM0Isd0JBQXdCOztBQUd6QixTQUFLLElBQUksU0FBUyxjQUFjO0VBQ2pDO0VBK0JBLFdBQVcsV0FBNEMsWUFBaUM7QUFDdkYsU0FBSyxTQUFTLFdBQVcsV0FBVyxVQUFVO0VBQy9DOzs7OztFQXVCQSxxQkFBcUIsU0FBeUQ7QUFDN0UsU0FBSyxTQUFTLHFCQUFxQixPQUFPO0VBQzNDOzs7OztFQU1BLHVCQUF1QixXQUErRDtBQUNyRixTQUFLLFNBQVMsdUJBQXVCLFNBQVM7RUFDL0M7Ozs7OztFQU9BLHFCQUNDLFdBQ0EsU0FBOEM7QUFFOUMsU0FBSyxTQUFTLHFCQUFxQixXQUFXLE9BQU87RUFDdEQ7Ozs7O0VBTUEsdUJBQXVCLFdBQStEO0FBQ3JGLFFBQUksTUFBTSxRQUFRLFNBQVM7QUFBRyxZQUFNLElBQUksTUFBTSx3REFBd0Q7QUFFdEcsU0FBSyxTQUFTLHVCQUF1QixTQUFTO0VBQy9DOzs7OztFQU1BLGtCQUFrQixRQUF1QztBQUN4RCxTQUFLLFNBQVMsa0JBQWtCLE1BQU07RUFDdkM7Ozs7OztFQU9BLGlCQUFtQyxZQUFhO0FBQy9DLFdBQU8sS0FBSyxTQUFTLGlCQUFpQixVQUFVO0VBQ2pEOzs7O0VBS0Esb0JBQWlCO0FBQ2hCLFNBQUssU0FBUyxrQkFBaUI7RUFDaEM7Ozs7Ozs7RUFRQSxlQUNDLGlCQUNHLGVBQW1EO0FBRXRELFNBQUssU0FBUyxlQUFlLENBQUMsY0FBYyxHQUFHLGFBQWEsQ0FBQztFQUM5RDs7Ozs7RUFNQSxzQkFBc0IsYUFBcUI7QUFDMUMsU0FBSyxTQUFTLG1CQUFtQixXQUFXO0VBQzdDOzs7Ozs7RUFPQSxvQkFBb0IsV0FBbUI7QUFDdEMsU0FBSyxTQUFTLGlCQUFpQixTQUFTO0VBQ3pDOzs7Ozs7RUFNQSxzQkFBc0IsV0FBbUI7QUFDeEMsU0FBSyxTQUFTLG1CQUFtQixTQUFTO0VBQzNDOzs7Ozs7RUFPQSx3QkFBd0IsYUFBcUI7QUFDNUMsU0FBSyxTQUFTLHFCQUFxQixXQUFXO0VBQy9DOzs7Ozs7RUFPQSxhQUFhLFFBQWlDLGNBQXFCO0FBQ2xFLFNBQUssU0FBUyxhQUFhLFFBQVEsWUFBWTtFQUNoRDs7Ozs7Ozs7RUFTQSxRQUFRLE1BQWMsTUFBY0EsT0FBYyxNQUFzQjtBQUN2RSxTQUFLLFNBQVMsUUFBUSxNQUFNLE1BQU1BLE9BQU0sSUFBSTtFQUM3Qzs7Ozs7Ozs7Ozs7RUFZQSxhQUFhLFFBQXdCLFNBQXVCO0FBQzNELFNBQUssU0FBUyxhQUFhLFFBQVEsV0FBVyxJQUFJO0VBQ25EOzs7Ozs7RUFPQSxJQUFJLE9BQWlCLFNBQWU7QUFDbkMsWUFBUSxPQUFPO01BQ2QsS0FBSztBQUNKLGFBQUssUUFBUSxNQUFNLE9BQU87QUFDMUI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxNQUFNLE9BQU87QUFDMUI7TUFDRDtBQUNDLG9CQUFZLEtBQUs7QUFDakIsYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtJQUNGO0VBQ0Q7RUFZQSxzQkFDQyxlQUNBLFVBQXlDO0FBRXpDLFVBQU0sVUFBa0MsT0FBTyxrQkFBa0IsV0FBVyxFQUFFLE1BQU0sY0FBYSxJQUFLO0FBRXRHLFVBQU0sU0FBUyxJQUFJLG9CQUFvQixLQUFLLFVBQVUsT0FBTztBQUM3RCxRQUFJO0FBQVUsYUFBTyxHQUFHLFdBQVcsUUFBUTtBQUUzQyxXQUFPO0VBQ1I7Ozs7QUMvVUQsSUFBWTtDQUFaLFNBQVlDLGlCQUFjO0FBQ3pCLEVBQUFBLGdCQUFBLElBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLFlBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGNBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLG1CQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxXQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxjQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxnQkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsdUJBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLHlCQUFBLElBQUE7QUFDRCxHQVZZLG1CQUFBLGlCQUFjLENBQUEsRUFBQTtBQWFwQixJQUFXO0NBQWpCLFNBQWlCQyxRQUFLO0FBRVIsRUFBQUEsT0FBQSxLQUFLO0FBQ0wsRUFBQUEsT0FBQSxXQUNaO0FBQ1ksRUFBQUEsT0FBQSxVQUFVO0FBQ1YsRUFBQUEsT0FBQSxPQUNaO0FBQ1ksRUFBQUEsT0FBQSxjQUFjO0FBQ2QsRUFBQUEsT0FBQSxVQUFVO0FBQ1YsRUFBQUEsT0FBQSxRQUFRO0FBQ1IsRUFBQUEsT0FBQSxlQUFlO0FBQ2YsRUFBQUEsT0FBQSxlQUFlO0FBQ2YsRUFBQUEsT0FBQSxTQUFTO0FBQ1QsRUFBQUEsT0FBQSxnQkFBZ0I7QUFDaEIsRUFBQUEsT0FBQSxZQUFZO0FBQ1osRUFBQUEsT0FBQSxXQUNaO0FBQ0YsR0FsQmlCLFVBQUEsUUFBSyxDQUFBLEVBQUE7OztBQ2pCdEIsT0FBTyxRQUFRO0FBQ2YsT0FBTyxVQUFVO0FBSWpCLElBQU0sU0FBUyxtQkFBbUIsUUFBUTtBQXlCMUMsU0FBUyx1QkFBb0I7QUFDNUIsUUFBTSxjQUFjLEtBQUssS0FBSyxZQUFZLFNBQVMsWUFBWTtBQUMvRCxRQUFNLGVBQWUsS0FBSyxLQUFLLFlBQVksU0FBUyxXQUFXO0FBRy9ELE1BQUksR0FBRyxXQUFXLFdBQVcsR0FBRztBQUMvQixXQUFPLE1BQU0seUJBQXlCLFdBQVcsRUFBRTtBQUNuRCxXQUFPO0VBQ1I7QUFHQSxNQUFJLEdBQUcsV0FBVyxZQUFZLEdBQUc7QUFDaEMsV0FBTyxLQUFLLHFEQUFxRCxZQUFZLEVBQUU7QUFDL0UsV0FBTztFQUNSO0FBR0EsUUFBTSxXQUFXOztNQUEwQyxXQUFXO01BQVMsWUFBWTs7QUFDM0YsU0FBTyxNQUFNLFFBQVE7QUFDckIsUUFBTSxJQUFJLE1BQU0sUUFBUTtBQUN6QjtBQUdBLElBQU0sZ0JBQWdCLHFCQUFvQjtBQUcxQyxJQUFJLHFCQUFpRDtBQU0vQyxTQUFVLG1CQUFnQjtBQUMvQixTQUFPO0FBQ1I7QUFNQSxTQUFTLG9CQUFpQjtBQUN6QixRQUFNLFVBQStCLENBQUE7QUFDckMsTUFBSTtBQUNILFVBQU0sUUFBUSxHQUFHLFlBQVksYUFBYSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsU0FBUyxPQUFPLENBQUM7QUFFN0UsZUFBVyxLQUFLLE9BQU87QUFDdEIsWUFBTSxXQUFXLEtBQUssS0FBSyxlQUFlLENBQUM7QUFDM0MsWUFBTSxPQUFPLEtBQUssTUFBTSxHQUFHLGFBQWEsVUFBVSxNQUFNLENBQUM7QUFDekQsVUFBSSxNQUFNLE9BQU87QUFDaEIsZ0JBQVEsT0FBTyxLQUFLLEtBQUssQ0FBQyxJQUFJO01BQy9CO0lBQ0Q7QUFFQSxXQUFPLE1BQU0sVUFBVSxPQUFPLEtBQUssT0FBTyxFQUFFLE1BQU0sNEJBQTRCO0VBQy9FLFNBQVMsR0FBRztBQUNYLFdBQU8sTUFBTSxrQ0FBa0MsQ0FBQyxFQUFFO0VBQ25EO0FBQ0EsU0FBTztBQUNSO0FBTU0sU0FBVSxtQkFBZ0I7QUFDL0IsTUFBSSxDQUFDLG9CQUFvQjtBQUN4Qix5QkFBcUIsa0JBQWlCO0VBQ3ZDO0FBQ0EsU0FBTztBQUNSO0FBTU0sU0FBVSxnQkFBZ0IsT0FBYTtBQUM1QyxRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFNBQU8sUUFBUSxLQUFLO0FBQ3JCO0FBTU0sU0FBVSxzQkFBbUI7QUFDbEMsU0FBTyxLQUFLLHVDQUF1QztBQUNuRCx1QkFBcUIsa0JBQWlCO0FBQ3ZDO0FBS0EsU0FBUyxzQkFBbUI7QUFDM0IsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxTQUFPLE9BQU8sS0FBSyxPQUFPLEVBQUUsS0FBSTtBQUNqQztBQUVNLFNBQVUsZ0JBQWdCLG9CQUFrQyxDQUFBLEdBQUU7QUFDbkUsUUFBTSxTQUFTLG9CQUFtQjtBQUlsQyxRQUFNLGdCQUFnQjtJQUNyQixFQUFFLElBQUksSUFBSSxPQUFPLGtDQUFpQztJQUNsRCxHQUFHLGtCQUFrQixJQUFJLENBQUMsT0FBTztNQUNoQyxJQUFJLEVBQUUsT0FBTztNQUNiLE9BQU8sU0FBUyxFQUFFLEtBQUssS0FBSyxFQUFFLEdBQUcsT0FBTyxFQUFFLEVBQUU7TUFDM0M7O0FBR0gsU0FBTzs7O0lBR047TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUztNQUNULFNBQVM7TUFDVCxTQUFTOzs7SUFJVjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTO01BQ1QsT0FBTyxNQUFNO01BQ2IscUJBQXFCO01BQ3JCLFNBQVM7OztJQUlWO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVMsT0FBTyxDQUFDLEtBQUs7TUFDdEIsU0FBUyxPQUFPLElBQUksQ0FBQyxXQUFXO1FBQy9CLElBQUk7UUFDSixPQUFPLFNBQVMsS0FBSztRQUNwQjtNQUNGLHFCQUFxQjtNQUNyQixTQUFTOzs7SUFJVjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTO01BQ1QsU0FBUzs7O0FBR1o7QUFPTSxTQUFVLFlBQVksUUFBc0IsbUJBQStCO0FBQ2hGLE1BQUksT0FBTyxXQUFXO0FBQ3JCLFVBQU0sU0FBUyxrQkFBa0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLE9BQU8sU0FBUztBQUN2RSxXQUFPLFFBQVEsTUFBTTtFQUN0QjtBQUNBLFNBQU8sT0FBTyxPQUFPLFFBQVEsRUFBRTtBQUNoQztBQU9NLFNBQVUsYUFBYSxRQUFzQixtQkFBK0I7QUFDakYsTUFBSSxPQUFPLFdBQVc7QUFDckIsVUFBTSxTQUFTLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsT0FBTyxTQUFTO0FBQ3ZFLFdBQU8sTUFBTSw0QkFBNEIsT0FBTyxTQUFTLG9CQUFvQixRQUFRLFNBQVMsTUFBTSxFQUFFO0FBQ3RHLFdBQU8sUUFBUSxTQUFTO0VBQ3pCO0FBQ0EsU0FBTyxNQUFNLDJDQUEyQyxPQUFPLFdBQVcsR0FBRztBQUM3RSxTQUFPLE9BQU8sT0FBTyxlQUFlLEVBQUU7QUFDdkM7OztBQ3BOTSxTQUFVLDBCQUEwQixNQUFvQjtBQUM3RCxPQUFLLHVCQUF1QjtJQUMzQixPQUFPLEVBQUUsTUFBTSxzQkFBcUI7SUFDcEMsV0FBVyxFQUFFLE1BQU0sdUNBQXNDO0lBQ3pELGNBQWMsRUFBRSxNQUFNLHNCQUFxQjtJQUMzQyxVQUFVLEVBQUUsTUFBTSwwQkFBeUI7SUFDM0MsU0FBUyxFQUFFLE1BQU0sZ0NBQStCO0lBQ2hELEtBQUssRUFBRSxNQUFNLHFCQUFvQjtJQUNqQyxJQUFJLEVBQUUsTUFBTSxvQkFBbUI7R0FDL0I7QUFDRjtBQUVBLElBQU0sb0JBQW9CO0VBQ3pCLE9BQU87RUFDUCxXQUFXO0VBQ1gsY0FBYztFQUNkLFVBQVU7RUFDVixTQUFTO0VBQ1QsS0FBSztFQUNMLElBQUk7O0FBUUMsU0FBVSxxQkFBcUIsTUFBb0I7QUFDeEQsUUFBTSxjQUFjLEtBQUs7QUFHekIsTUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLGFBQWEsbUJBQW1CLFdBQVcsR0FBRztBQUN2RSxTQUFLLGtCQUFrQixpQkFBaUI7QUFDeEM7RUFDRDtBQUVBLFFBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFdBQVc7QUFDNUQsTUFBSSxRQUFRO0FBQ1gsU0FBSyxrQkFBa0I7TUFDdEIsT0FBTyxPQUFPLFNBQVM7TUFDdkIsV0FBVyxPQUFPLGFBQWE7TUFDL0IsY0FBYyxPQUFPLGdCQUFnQjtNQUNyQyxVQUFVLE9BQU8sZ0JBQWdCO01BQ2pDLFNBQVMsT0FBTyxpQkFBaUI7TUFDakMsS0FBSyxPQUFPLE9BQU87TUFDbkIsSUFBSSxPQUFPO0tBQ1g7RUFDRixPQUFPO0FBR04sU0FBSyxrQkFBa0I7TUFDdEIsR0FBRztNQUNILElBQUk7S0FDSjtFQUNGO0FBQ0Q7OztBQzFETyxJQUFNLGlCQUErRDs7Ozs7Ozs7Ozs7Ozs7O0FDU3JFLElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sY0FBYztBQUNwQixJQUFNLGNBQWM7QUFDcEIsSUFBTSxjQUFjO0FBQ3BCLElBQU0sZ0JBQWdCO0FBQ3RCLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sYUFBYTtBQUNuQixJQUFNLHVCQUF1QjtBQUM3QixJQUFNLG9CQUFvQjtBQUMxQixJQUFNLGVBQWU7QUFDckIsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxjQUFjO0FBR3JCLFNBQVUsZUFBZSxPQUFhO0FBQzNDLFVBQVEsT0FBTztJQUNkLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUjtBQUNDLGFBQU8sU0FBUyxNQUFNLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUM7RUFDckQ7QUFDRDtBQVFNLFNBQVUsY0FDZixPQUNBLE9BQ0EsV0FDQSxPQUF1QjtBQUV2QixRQUFNLE1BQU0sT0FBTyxVQUFVLFdBQVcsTUFBTSxTQUFTLEVBQUUsSUFBSTtBQUM3RCxRQUFNLEtBQUssT0FBTyxjQUFjLFdBQVcsVUFBVSxTQUFTLEVBQUUsSUFBSTtBQUVwRSxNQUFJLFVBQVUsUUFBVztBQUN4QixVQUFNLEtBQUssT0FBTyxVQUFVLFdBQVcsTUFBTSxTQUFTLEVBQUUsSUFBSTtBQUM1RCxXQUFPLEdBQUcsS0FBSyxJQUFJLEdBQUcsSUFBSSxFQUFFLElBQUksRUFBRTtFQUNuQztBQUVBLFNBQU8sR0FBRyxLQUFLLElBQUksR0FBRyxJQUFJLEVBQUU7QUFDN0I7QUFTTSxTQUFVLE1BQU0sT0FBZSxZQUFZLEdBQUM7QUFDakQsU0FBTyxLQUFLLE1BQU0sU0FBUyxFQUFFLEVBQUUsU0FBUyxXQUFXLEdBQUcsQ0FBQztBQUN4RDtBQU9NLFNBQVUsV0FBVyxPQUF3QjtBQUNsRCxTQUFPLEtBQUssTUFBTSxLQUFLLEtBQUssRUFDMUIsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRSxDQUFDO0FBQ1g7QUFTTSxTQUFVLGVBQWUsR0FBVyxHQUFXLEdBQVM7QUFDN0QsU0FBTyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUMsRUFDakIsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRSxFQUNQLFlBQVcsQ0FBRTtBQUNoQjtBQVFNLFNBQVUsZUFBZSxJQUFVO0FBQ3hDLFFBQU0sQ0FBQyxPQUFPLFVBQVUsS0FBSyxJQUFJLEdBQUcsTUFBTSxHQUFHO0FBQzdDLFNBQU87SUFDTjtJQUNBLE9BQU8sU0FBUyxVQUFVLEVBQUU7SUFDNUIsUUFBUSxTQUFTLE9BQU8sRUFBRTs7QUFFNUI7QUFVTSxTQUFVLGNBQWMsUUFBZ0IsUUFBYztBQUMzRCxRQUFNLEtBQUssU0FBUyxPQUFPLFFBQVEsT0FBTyxFQUFFLEdBQUcsRUFBRTtBQUNqRCxRQUFNLEtBQUssU0FBUyxPQUFPLFFBQVEsT0FBTyxFQUFFLEdBQUcsRUFBRTtBQUNqRCxNQUFJLE9BQU8sTUFBTSxFQUFFLEtBQUssT0FBTyxNQUFNLEVBQUU7QUFBRyxXQUFPO0FBQ2pELFNBQU8sS0FBSyxJQUFJLEtBQUssRUFBRTtBQUN4QjtBQVNNLFNBQVUscUJBQ2YsWUFBK0I7QUFFL0IsUUFBTSxhQUFrRSxDQUFBO0FBQ3hFLGFBQVcsQ0FBQyxPQUFPLElBQUksS0FBSyxPQUFPLFFBQVEsVUFBVSxHQUFHO0FBQ3ZELGVBQVcsS0FBSyxJQUFJO01BQ25CLE9BQU8sS0FBSztNQUNaLFdBQVcsTUFBTSxRQUFRLEtBQUssU0FBUyxJQUFJLEtBQUssWUFBWSxDQUFBOztFQUU5RDtBQUNBLFNBQU87QUFDUjtBQVlNLFNBQVUscUJBQ2YsU0FDQSxPQUNBLE9BQ0EsV0FBaUI7QUFFakIsUUFBTSxTQUFTLFFBQVEsS0FBSztBQUM1QixNQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sUUFBUSxPQUFPLFNBQVM7QUFBRyxXQUFPO0FBR3hELE1BQUksU0FBUyxPQUFPLFVBQVUsS0FBSyxDQUFDLE1BQVcsRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFHdkYsTUFBSSxDQUFDLFFBQVE7QUFDWixhQUFTLE9BQU8sVUFBVSxLQUFLLENBQUMsTUFBVTtBQUN6QyxVQUFJLEVBQUUsV0FBVztBQUFPLGVBQU87QUFDL0IsWUFBTSxjQUFjLEVBQUUsU0FBUyxLQUFLLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUNwRSxVQUFJLENBQUMsYUFBYTtBQUFTLGVBQU87QUFFbEMsWUFBTSxTQUFTLFlBQVksRUFBRTtBQUM3QixhQUFPLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sTUFBTTtJQUM1RCxDQUFDO0VBQ0Y7QUFFQSxTQUFPO0FBQ1I7OztBQzVMQSxTQUFTLFlBQVksR0FBTTtBQUMxQixRQUFNLE9BQU87SUFDWixNQUFNLEVBQUU7SUFDUixJQUFJLEVBQUU7SUFDTixPQUFPLEVBQUU7SUFDVCxTQUFTLEVBQUU7SUFDWCxTQUFTLEVBQUU7O0FBR1osVUFBUSxFQUFFLE1BQU07SUFDZixLQUFLO0FBQ0osYUFBTyxFQUFFLEdBQUcsTUFBTSxTQUFTLEVBQUUsV0FBVyxDQUFBLEVBQUU7SUFFM0MsS0FBSztBQUNKLGFBQU87UUFDTixHQUFHO1FBQ0gsS0FBSyxFQUFFO1FBQ1AsS0FBSyxFQUFFO1FBQ1AsTUFBTSxFQUFFLFFBQVE7UUFDaEIsT0FBTzs7SUFHVCxLQUFLO0FBQ0osYUFBTyxFQUFFLEdBQUcsTUFBTSxTQUFTLEVBQUUsV0FBVyxNQUFLO0lBRTlDLEtBQUs7QUFDSixhQUFPLEVBQUUsR0FBRyxNQUFNLE9BQU8sRUFBRSxTQUFTLEdBQUU7SUFFdkMsS0FBSztJQUNMLEtBQUs7SUFDTDtBQUNDLGFBQU87RUFDVDtBQUNEO0FBTU0sU0FBVSxlQUFZO0FBQzNCLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsUUFBTSxVQUFzQyxDQUFBO0FBRTVDLGFBQVcsQ0FBQyxPQUFPLE1BQU0sS0FBSyxPQUFPLFFBQVEsT0FBTyxHQUFHO0FBQ3RELFVBQU0sWUFBWSxPQUFPO0FBQ3pCLFFBQUksQ0FBQyxNQUFNLFFBQVEsU0FBUztBQUFHO0FBRS9CLGVBQVcsS0FBSyxXQUFXO0FBRTFCLFVBQUksRUFBRSxhQUFhO0FBQU07QUFFekIsWUFBTSxXQUFXLGNBQWMsT0FBTyxFQUFFLFFBQVEsRUFBRSxFQUFFO0FBRXBELFlBQU0sV0FBVyxFQUFFLFdBQVcsQ0FBQSxHQUFJLElBQUksV0FBVztBQUVqRCxZQUFNLFNBQW9DO1FBQ3pDLE1BQU0sU0FBUyxLQUFLLEtBQUssRUFBRSxJQUFJO1FBQy9CO1FBQ0EsVUFBVSxZQUFXO1FBRXJCOztBQUdELGNBQVEsUUFBUSxJQUFJO0lBQ3JCO0VBQ0Q7QUFFQSxTQUFPO0FBQ1I7QUFXQSxTQUFTLGtCQUFrQixTQUFZO0FBQ3RDLFFBQU0sV0FBVyxRQUFRLFNBQVMsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE9BQU87QUFDbkUsTUFBSSxDQUFDO0FBQVUsV0FBTztBQUN0QixNQUFJLFNBQVMsU0FBUztBQUFZLFdBQU87QUFDekMsTUFBSSxTQUFTLFNBQVMsY0FBYyxDQUFDLE1BQU0sUUFBUSxTQUFTLE9BQU87QUFBRyxXQUFPO0FBQzdFLE1BQUksU0FBUyxRQUFRLFdBQVc7QUFBRyxXQUFPO0FBQzFDLFFBQU0sU0FBUyxTQUFTLFFBQVEsSUFBSSxDQUFDLE1BQVcsT0FBTyxFQUFFLEtBQUssRUFBRSxZQUFXLENBQUU7QUFDN0UsU0FBTyxPQUFPLFNBQVMsS0FBSyxLQUFLLE9BQU8sU0FBUyxJQUFJO0FBQ3REO0FBRU0sU0FBVSxpQkFBYztBQUM3QixRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFFBQU0sWUFBMEMsQ0FBQTtBQUVoRCxhQUFXLENBQUMsT0FBTyxNQUFNLEtBQUssT0FBTyxRQUFRLE9BQU8sR0FBRztBQUN0RCxVQUFNLFlBQVksT0FBTztBQUN6QixRQUFJLENBQUMsTUFBTSxRQUFRLFNBQVM7QUFBRztBQUUvQixlQUFXLFdBQVcsV0FBVztBQUVoQyxVQUFJLFFBQVEsY0FBYztBQUFNO0FBRWhDLFlBQU0saUJBQWlCLGNBQWMsT0FBTyxRQUFRLFFBQVEsUUFBUSxFQUFFO0FBR3RFLFlBQU0sY0FBYyxRQUFRLFdBQVcsQ0FBQSxHQUFJLElBQUksV0FBVztBQUcxRCxZQUFNLGVBQWUsV0FBVyxPQUFPLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUl2RSxZQUFNLGlCQUFpQixRQUFRLFNBQVMsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLFdBQVcsRUFBRSxTQUFTLGFBQWE7QUFDckcsVUFBSSxDQUFDLGdCQUFnQjtBQUNwQixxQkFBYSxLQUFLO1VBQ2pCLE1BQU07VUFDTixJQUFJO1VBQ0osT0FBTztVQUNQLFNBQVM7VUFDVCxTQUFTO1NBQ1Q7TUFDRjtBQUdBLFlBQU0sZ0JBQXFCO1FBQzFCLE1BQU07UUFDTixNQUFNLFNBQVMsS0FBSyxLQUFLLFFBQVEsSUFBSTtRQUNyQyxTQUFTO1FBQ1QsVUFBVSxNQUFLO0FBRWQsaUJBQU87UUFDUjs7QUFHRCxnQkFBVSxjQUFjLElBQUk7QUFHNUIsVUFBSSxrQkFBa0IsT0FBTyxHQUFHO0FBQy9CLGNBQU0saUJBQWlCLEdBQUcsY0FBYztBQUd4QyxjQUFNLGNBQWMsV0FBVyxPQUFPLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUV0RSxjQUFNLGVBQW9CO1VBQ3pCLE1BQU07VUFDTixNQUFNLFNBQVMsS0FBSyxLQUFLLFFBQVEsSUFBSTtVQUNyQyxjQUFjO1lBQ2IsU0FBUyxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBQzdCLE9BQU8sV0FBVyxHQUFHLEdBQUcsQ0FBQzs7VUFFMUIsU0FBUztVQUNULFVBQVUsTUFBSztBQUVkLG1CQUFPO1VBQ1I7O0FBR0Qsa0JBQVUsY0FBYyxJQUFJO01BQzdCO0lBQ0Q7RUFDRDtBQUVBLFNBQU87QUFDUjs7O0FDaExBLE9BQU9DLFdBQVU7OztBQ0xqQixPQUFPQyxTQUFRO0FBZ0JmLElBQU1DLFVBQVMsbUJBQW1CLGdCQUFnQjtBQTBDbEQsU0FBUyxVQUFVLE9BQWE7QUFDL0IsUUFBTSxTQUFTLG9CQUFJLElBQUc7QUFDdEIsTUFBSTtBQUNILFVBQU0sT0FBTyxnQkFBZ0IsS0FBSztBQUNsQyxRQUFJLENBQUM7QUFBTSxhQUFPO0FBQ2xCLGVBQVcsVUFBVSxLQUFLLGFBQWEsQ0FBQSxHQUFJO0FBQzFDLFlBQU0saUJBQWlCLE9BQU8sU0FBUyxLQUFLLENBQUMsUUFBd0IsSUFBSSxTQUFTLGFBQWE7QUFDL0YsVUFBSSxnQkFBZ0I7QUFDbkIsZUFBTyxJQUFJLE9BQU8sRUFBRTtBQUNwQixjQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUF3QixJQUFJLE9BQU8sT0FBTztBQUNwRixZQUFJLGFBQWEsU0FBUztBQUN6QixxQkFBVyxVQUFVLFlBQVksU0FBUztBQUN6QyxnQkFBSSxPQUFPLE9BQU8sT0FBTyxVQUFVO0FBQ2xDLHFCQUFPLElBQUksT0FBTyxLQUFLLE9BQU8sRUFBRTtZQUNqQztVQUNEO1FBQ0Q7TUFDRDtJQUNEO0VBQ0QsU0FBUyxNQUFNO0VBRWY7QUFDQSxTQUFPO0FBQ1I7QUFNQSxTQUFTLHNCQUFzQixLQUFXO0FBQ3pDLFFBQU0sV0FBVyxJQUFJLFFBQVEsT0FBTyxLQUFLLFVBQVUsQ0FBQztBQUNwRCxNQUFJLFdBQVc7QUFBRyxVQUFNLElBQUksTUFBTSxpQ0FBaUM7QUFFbkUsUUFBTSxlQUFlLFdBQVc7QUFDaEMsTUFBSSxJQUFJLFlBQVksTUFBTSxJQUFNO0FBQy9CLFVBQU0sSUFBSSxNQUFNLHVDQUF1QyxJQUFJLFlBQVksRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFO0VBQ3hGO0FBRUEsU0FBTztBQUNSO0FBTUEsU0FBUyw4QkFBOEIsS0FBYSxPQUFhO0FBQ2hFLFFBQU0sTUFBTSxzQkFBc0IsR0FBRztBQUNyQyxRQUFNLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSTtBQUM3QixNQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQU0sSUFBSSxNQUFNLDRCQUE0QjtFQUM3QztBQUdBLE1BQUksSUFBSSxVQUFVLHVCQUF1QixNQUFNLElBQUksTUFBTTtBQUN6RCxRQUFNLE1BQU0sSUFBSSxTQUFTO0FBQ3pCLFFBQU0sTUFBdUIsQ0FBQTtBQUU3QixRQUFNLFNBQVMsVUFBVSxLQUFLO0FBSTlCLFFBQU0sb0JBQW9CLENBQUMsYUFBYSxpQkFBaUIsV0FBVztBQUtwRSxRQUFNLG1CQUFtQixDQUFDLFdBQVc7QUFFckMsU0FBTyxJQUFJLElBQUksS0FBSztBQUNuQixVQUFNLFNBQVMsSUFBSSxDQUFDO0FBQ3BCLFVBQU0sZUFBZSxJQUFJLElBQUksQ0FBQztBQUU5QixVQUFNLGFBQWEsSUFBSSxJQUFJO0FBQzNCLFFBQUksYUFBYTtBQUFLO0FBRXRCLFVBQU0sV0FBVyxrQkFBa0IsU0FBUyxZQUFZO0FBQ3hELFVBQU0sYUFBYSxpQkFBaUIsU0FBUyxZQUFZO0FBRXpELFFBQUk7QUFDSixRQUFJO0FBQ0osUUFBSTtBQUVKLFFBQUksWUFBWTtBQVFmLGNBQVEsSUFBSSxJQUFJLENBQUM7QUFDakIsWUFBTSxXQUFXLElBQUksU0FBUyxJQUFJLEdBQUcsVUFBVTtBQUUvQyxZQUFNLFNBQVMsZ0JBQWdCLEtBQUs7QUFDcEMsWUFBTSxpQkFBaUIsUUFBUSxhQUFhLENBQUEsR0FDMUMsT0FBTyxDQUFDLE9BQWlCLEVBQUUsV0FBVyxlQUFlLEVBQUUsV0FBVyxvQkFBb0IsRUFBRSxVQUFVLE1BQVMsRUFDM0csS0FBSyxDQUFDLEdBQWEsTUFBZ0IsRUFBRSxLQUFLLEVBQUUsRUFBRTtBQUVoRCxlQUFTLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0FBQ3pDLGNBQU0sUUFBUSxjQUFjLENBQUM7QUFDN0IsWUFBSSxPQUFPO0FBQ1YsY0FBSSxLQUFLLEVBQUUsUUFBUSxNQUFNLFFBQVEsSUFBSSxNQUFNLElBQUksT0FBTyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBQyxDQUFFO1FBQ2xGO01BRUQ7QUFDQSxVQUFJO0FBQ0o7SUFDRCxXQUFXLFVBQVU7QUFFcEIsY0FBUSxJQUFJLElBQUksQ0FBQztBQUNqQixnQkFBVSxJQUFJLElBQUksQ0FBQztBQUNuQixVQUFJLElBQUk7SUFDVCxPQUFPO0FBRU4sZ0JBQVUsSUFBSSxJQUFJLENBQUM7QUFDbkIsVUFBSSxJQUFJO0lBQ1Q7QUFFQSxVQUFNLE9BQU8sSUFBSTtBQUNqQixVQUFNLFNBQVM7QUFFZixXQUFPLElBQUksSUFBSSxNQUFNO0FBQ3BCLFlBQU0sS0FBSyxJQUFJLENBQUM7QUFDaEIsVUFBSTtBQUdKLFVBQUksT0FBTyxJQUFJLEVBQUUsS0FBSyxJQUFJLElBQUksTUFBTTtBQUNuQyxxQkFBYSxDQUFDLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBQ2hELGFBQUs7TUFDTixPQUFPO0FBQ04scUJBQWEsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBQ3hCLGFBQUs7TUFDTjtBQUVBLFlBQU0sVUFBeUI7UUFDOUIsUUFBUTtRQUNSO1FBQ0E7O0FBRUQsVUFBSSxVQUFVLFFBQVc7QUFDeEIsZ0JBQVEsUUFBUTtNQUNqQjtBQUNBLFVBQUksS0FBSyxPQUFPO0lBQ2pCO0FBUUEsUUFBSSxNQUFNLFVBQVUsYUFBYSxJQUFJLEdBQUc7QUFDdkMsVUFBSSxNQUFNLFdBQVcsSUFBSSxJQUFJLElBQUk7QUFDakMsVUFBSSxRQUFRO0FBQ1osYUFBTyxNQUFNLFlBQVk7QUFDeEIsY0FBTSxVQUF5QixFQUFFLFFBQVEsY0FBYyxJQUFJLFNBQVMsWUFBWSxDQUFDLElBQUksS0FBSyxDQUFDLEVBQUM7QUFDNUYsWUFBSSxVQUFVO0FBQVcsa0JBQVEsUUFBUTtBQUN6QyxZQUFJLEtBQUssT0FBTztNQUNqQjtJQUNEO0FBRUEsUUFBSTtFQUNMO0FBRUEsU0FBTztBQUNSO0FBV00sU0FBVSxzQkFBc0IsT0FBZSxLQUFXO0FBQy9ELFFBQU0sTUFBTSxzQkFBc0IsR0FBRztBQUNyQyxRQUFNLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSTtBQUM3QixNQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQU0sSUFBSSxNQUFNLGlDQUFpQyxNQUFNLFNBQVMsRUFBRSxDQUFDLEdBQUc7RUFDdkU7QUFDQSxTQUFPLDhCQUE4QixLQUFLLEtBQUs7QUFDaEQ7QUFNTSxTQUFVLG9CQUFvQixTQUF3QixTQUFtQjtBQUU5RSxNQUFJLFNBQVMsUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsUUFBUSxVQUFVLEVBQUUsT0FBTyxRQUFRLEVBQUU7QUFLbkYsTUFBSSxDQUFDLFFBQVE7QUFDWixVQUFNLGFBQWEsUUFBUSxLQUFLLENBQUMsTUFBSztBQUNyQyxVQUFJLEVBQUUsV0FBVyxRQUFRO0FBQVEsZUFBTztBQUV4QyxZQUFNLGNBQWMsRUFBRSxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQy9ELFVBQUksQ0FBQyxhQUFhO0FBQVMsZUFBTztBQUVsQyxZQUFNLGdCQUFnQixRQUFRLEtBQUssRUFBRTtBQUNyQyxhQUFPLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sYUFBYTtJQUM5RCxDQUFDO0FBQ0QsUUFBSSxZQUFZO0FBQ2YsZUFBUztJQUNWO0VBQ0Q7QUFFQSxRQUFNLFNBQVMsTUFBTSxRQUFRLE1BQU07QUFDbkMsUUFBTSxRQUFRLE1BQU0sUUFBUSxFQUFFO0FBQzlCLFFBQU0sU0FBUyxXQUFXLFFBQVEsVUFBVTtBQUM1QyxRQUFNLFNBQ0wsUUFBUSxXQUFXLFdBQVcsSUFDM0IsZUFBZSxRQUFRLFdBQVcsQ0FBQyxHQUFHLFFBQVEsV0FBVyxDQUFDLEdBQUcsUUFBUSxXQUFXLENBQUMsQ0FBQyxJQUNsRixRQUFRLFdBQVcsV0FBVyxJQUM3QixRQUFRLFdBQVcsQ0FBQyxJQUNwQixRQUFRLFdBQVcsS0FBSyxHQUFHO0FBR2hDLFFBQU0sV0FBVyxRQUFRLFVBQVUsU0FBWSxPQUFPLFFBQVEsS0FBSyxLQUFLO0FBQ3hFLFFBQU0sU0FBUyxPQUFPLE1BQU0sR0FBRyxRQUFRLE9BQU8sS0FBSyxRQUFRLE1BQU07QUFHakUsTUFBSSxRQUFRO0FBQ1gsUUFBSSxPQUFPLE9BQU87QUFHbEIsUUFBSSxRQUFRLFVBQVUsUUFBVztBQUNoQyxhQUFPLEdBQUcsSUFBSSxNQUFNLFFBQVEsUUFBUSxDQUFDO0lBQ3RDLE9BRUs7QUFDSixZQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQ3BFLFVBQUksYUFBYSxTQUFTO0FBQ3pCLGNBQU0sZ0JBQWdCLFFBQVEsS0FBSyxPQUFPO0FBQzFDLGNBQU0sY0FBYyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLGFBQWE7QUFDMUUsWUFBSSxhQUFhO0FBQ2hCLGlCQUFPLEdBQUcsSUFBSSxJQUFJLFlBQVksS0FBSztRQUNwQztNQUNEO0lBQ0Q7QUFHQSxVQUFNLGNBQWMsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxPQUFPO0FBQ3BFLFFBQUksYUFBYSxXQUFXLFFBQVEsV0FBVyxXQUFXLEdBQUc7QUFDNUQsWUFBTSxTQUFTLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxXQUFXLENBQUMsQ0FBQztBQUM3RSxVQUFJLFFBQVE7QUFDWCxlQUFPLEdBQUcsTUFBTSxNQUFNLElBQUksS0FBSyxPQUFPLEtBQUssS0FBSyxNQUFNO01BQ3ZEO0lBQ0Q7QUFDQSxXQUFPLEdBQUcsTUFBTSxNQUFNLElBQUksS0FBSyxNQUFNO0VBQ3RDO0FBR0EsU0FBTyxHQUFHLE1BQU07QUFDakI7QUFXTSxTQUFVLGlDQUNmLE9BQ0EsS0FBVztBQUVYLFFBQU0sV0FBVyw4QkFBOEIsS0FBSyxLQUFLO0FBQ3pELFNBQU8sRUFBRSxVQUFVLG1CQUFtQixLQUFJO0FBQzNDO0FBRU0sU0FBVSw0QkFBNEIsT0FBZSxLQUFXO0FBQ3JFLFNBQU8sOEJBQThCLEtBQUssS0FBSztBQUNoRDtBQU1BLFNBQVMsbUJBQW1CLFlBQW9CO0FBQy9DLE1BQUksV0FBVyxXQUFXLEdBQUc7QUFDNUIsV0FBTyxFQUFFLElBQUksU0FBUyxPQUFPLFNBQVMsTUFBTSxVQUFVLFNBQVMsV0FBVyxDQUFDLEVBQUM7RUFDN0U7QUFFQSxNQUFJLFdBQVcsV0FBVyxHQUFHO0FBQzVCLFVBQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQyxJQUFJO0FBQ2xCLFdBQU87TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE1BQU07TUFDTixTQUFTLGVBQWUsR0FBRyxHQUFHLENBQUM7O0VBRWpDO0FBRUEsU0FBTyxFQUFFLElBQUksU0FBUyxPQUFPLFNBQVMsTUFBTSxPQUFPLFNBQVMsQ0FBQyxHQUFHLFVBQVUsRUFBQztBQUM1RTtBQU1NLFNBQVUsNEJBQ2YsV0FDQSxRQUNBLFdBQXNDO0FBRXRDLFFBQU0sTUFBTSxnQkFBZ0IsU0FBUztBQUdyQyxNQUFJLENBQUMsSUFBSSxXQUFXO0FBQ25CLFFBQUksWUFBWSxDQUFBO0VBQ2pCO0FBR0EsUUFBTSxhQUFhLE9BQU8sT0FBTyxTQUFTLEVBQ3hDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsVUFBVSxVQUFVLEtBQUssRUFDekMsS0FBSyxDQUFDLEdBQUcsTUFBTSxjQUFjLFVBQVUsT0FBTyxFQUFFLEtBQUssSUFBSSxjQUFjLFVBQVUsT0FBTyxFQUFFLEtBQUssQ0FBQztBQUVsRyxFQUFBQSxRQUFPLEtBQUssbUJBQW1CLFVBQVUsS0FBSyxFQUFFO0FBQ2hELEVBQUFBLFFBQU8sTUFBTSw2QkFBNkIsV0FBVyxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLElBQUksQ0FBQyxFQUFFO0FBS3JGLFFBQU0sbUJBQW1CLG9CQUFJLElBQUc7QUFDaEMsYUFBVyxLQUFLLFlBQVk7QUFDM0IsZUFBVyxhQUFhLEVBQUUsYUFBYSxDQUFBLEdBQUk7QUFDMUMsWUFBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sT0FBTztBQUNyRSxVQUFJLENBQUMsVUFBVTtBQUFTO0FBQ3hCLFlBQU0sU0FBUyxVQUFVO0FBQ3pCLFlBQU0sUUFBUSxVQUFVO0FBQ3hCLFlBQU0sTUFBTSxHQUFHLEtBQUssSUFBSSxNQUFNO0FBQzlCLFVBQUksaUJBQWlCLElBQUksR0FBRztBQUFHO0FBRS9CLFlBQU0sZ0JBQWdCLE9BQ3BCLE9BQU8sQ0FBQyxNQUFNLEVBQUUsV0FBVyxTQUFTLEVBQUUsS0FBSyxNQUFNLEVBQ2pELElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxNQUFNLEVBQ3hCLEtBQUssQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDO0FBRXRCLFVBQUksU0FBUztBQUNiLGlCQUFXLE9BQU8sZUFBZTtBQUNoQyxZQUFJLFFBQVEsU0FBUztBQUFHLG1CQUFTO2lCQUN4QixNQUFNLFNBQVM7QUFBRztNQUM1QjtBQUNBLFVBQUksU0FBUyxHQUFHO0FBQ2YseUJBQWlCLElBQUksS0FBSyxNQUFNO0FBQ2hDLFFBQUFBLFFBQU8sTUFBTSxnQ0FBZ0MsTUFBTSxLQUFLLENBQUMsWUFBWSxNQUFNLE1BQU0sQ0FBQyxvQkFBZSxNQUFNLEVBQUU7TUFDMUc7SUFDRDtFQUNEO0FBSUEsUUFBTSxZQUFZLG9CQUFJLElBQUc7QUFDekIsYUFBVyxFQUFFLFFBQVEsSUFBSSxNQUFLLEtBQU0sUUFBUTtBQUMzQyxRQUFJLFVBQVU7QUFBVztBQUN6QixVQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksRUFBRTtBQUMzQixRQUFJLENBQUMsVUFBVSxJQUFJLEdBQUc7QUFBRyxnQkFBVSxJQUFJLEtBQUssb0JBQUksSUFBRyxDQUFFO0FBQ3JELGNBQVUsSUFBSSxHQUFHLEVBQUcsSUFBSSxLQUFLO0VBQzlCO0FBTUEsYUFBVyxFQUFFLFFBQVEsSUFBSSxPQUFPLFdBQVUsS0FBTSxRQUFRO0FBRXZELFVBQU0sZ0JBQWdCLElBQUksVUFBVSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRTtBQUNsRixRQUFJLGVBQWU7QUFDbEIsWUFBTSxNQUFNLGNBQWMsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUMvRCxVQUFJO0FBQUssWUFBSSxVQUFVLG1CQUFtQixVQUFVLEVBQUU7QUFHdEQsWUFBTSxrQkFBa0IsVUFBVSxJQUFJLEdBQUcsTUFBTSxJQUFJLEVBQUUsRUFBRTtBQUN2RCxVQUFJLG1CQUFtQixnQkFBZ0IsT0FBTyxHQUFHO0FBQ2hELGNBQU0sV0FBVyxLQUFLLElBQUksR0FBRyxlQUFlO0FBQzVDLGNBQU0saUJBQWlCLGNBQWMsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUMxRSxZQUFJLGFBQWEsS0FBSyxjQUFjLFVBQVUsVUFBYSxDQUFDLGdCQUFnQjtBQUMzRSx3QkFBYyxRQUFRO0FBQ3RCLFVBQUFBLFFBQU8sS0FBSyw2Q0FBNkMsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxFQUFFO1FBQ3pGO01BQ0Q7QUFDQTtJQUNEO0FBS0EsVUFBTSxZQUFZLElBQUksVUFBVSxLQUFLLENBQUMsTUFBSztBQUMxQyxVQUFJLEVBQUUsV0FBVztBQUFRLGVBQU87QUFDaEMsWUFBTSxXQUFXLEVBQUUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUN4RCxVQUFJLENBQUMsVUFBVTtBQUFTLGVBQU87QUFDL0IsVUFBSSxNQUFNLEVBQUU7QUFBSSxlQUFPO0FBQ3ZCLFlBQU0sU0FBUyxLQUFLLEVBQUU7QUFFdEIsYUFBTyxXQUFXLEtBQUssQ0FBQyxNQUFLO0FBQzVCLGNBQU0sV0FBVyxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUUsRUFBRTtBQUM5RSxjQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLGVBQU8sVUFBVSxTQUFTLEtBQUssQ0FBQyxPQUFZLEdBQUcsT0FBTyxNQUFNO01BQzdELENBQUM7SUFDRixDQUFDO0FBQ0QsUUFBSSxXQUFXO0FBQ2QsWUFBTSxTQUFTLEtBQUssVUFBVTtBQUM5QixZQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLFVBQUksVUFBVSxXQUFXLENBQUMsU0FBUyxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxNQUFNLEdBQUc7QUFDN0UsWUFBSSxRQUFRLFdBQVcsU0FBUyxDQUFDO0FBQ2pDLG1CQUFXLEtBQUssWUFBWTtBQUMzQixnQkFBTSxXQUFXLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sVUFBVSxFQUFFO0FBQ3RGLGdCQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLGdCQUFNLFlBQVksVUFBVSxTQUFTLEtBQUssQ0FBQyxPQUFZLEdBQUcsT0FBTyxNQUFNO0FBQ3ZFLGNBQUksV0FBVztBQUNkLG9CQUFRLFVBQVU7QUFDbEI7VUFDRDtRQUNEO0FBQ0EsaUJBQVMsUUFBUSxLQUFLLEVBQUUsSUFBSSxRQUFRLE1BQUssQ0FBRTtBQUMzQyxRQUFBQSxRQUFPLEtBQ04saUJBQWlCLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsdUJBQXVCLE1BQU0sVUFBVSxFQUFFLENBQUMsY0FBYyxNQUFNLE1BQU0sS0FBSyxJQUFJO01BRTdIO0FBQ0E7SUFDRDtBQUdBLFFBQUk7QUFFSixlQUFXLEtBQUssWUFBWTtBQUMzQixZQUFNLFFBQVEsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxFQUFFO0FBQ3pFLFVBQUksT0FBTztBQUNWLGlCQUFTLGdCQUFnQixLQUFLO0FBRTlCLGNBQU0sV0FBVyxNQUFNLEtBQUssUUFBUSxxQ0FBcUMsRUFBRSxFQUFFLEtBQUk7QUFDakYsZUFBTyxPQUFPLEdBQUcsUUFBUSx5QkFBeUIsRUFBRSxLQUFLO0FBQ3pELFFBQUFBLFFBQU8sS0FBSyxtQkFBbUIsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxlQUFlLEVBQUUsS0FBSyxVQUFVO0FBQzVGO01BQ0Q7SUFDRDtBQUlBLFFBQUksQ0FBQyxRQUFRO0FBQ1osVUFBSSxjQUFjO0FBQ2xCLGlCQUFXLEtBQUssWUFBWTtBQUMzQixjQUFNLFlBQVksRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFVO0FBQzlDLGNBQUksRUFBRSxXQUFXO0FBQVEsbUJBQU87QUFDaEMsZ0JBQU0sV0FBVyxFQUFFLFNBQVMsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE9BQU87QUFDN0QsY0FBSSxDQUFDLFVBQVU7QUFBUyxtQkFBTztBQUMvQixjQUFJLE1BQU0sRUFBRTtBQUFJLG1CQUFPO0FBQ3ZCLGdCQUFNLFNBQVMsS0FBSyxFQUFFO0FBQ3RCLGdCQUFNLFNBQVMsaUJBQWlCLElBQUksR0FBRyxNQUFNLElBQUksRUFBRSxFQUFFLEVBQUUsS0FBSztBQUM1RCxpQkFBTyxVQUFVO1FBQ2xCLENBQUM7QUFDRCxZQUFJLFdBQVc7QUFDZCx3QkFBYztBQUNkLFVBQUFBLFFBQU8sTUFDTixVQUFVLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsNENBQTRDLE1BQU0sVUFBVSxFQUFFLENBQUMsNkJBQXdCO0FBRS9IO1FBQ0Q7TUFDRDtBQUNBLFVBQUk7QUFBYTtJQUNsQjtBQUdBLFFBQUksQ0FBQyxRQUFRO0FBQ1osZUFBUztRQUNSO1FBQ0E7UUFDQSxNQUFNLGVBQWUsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsRUFBRSxZQUFXLENBQUU7UUFDaEUsU0FBUyxDQUFDLG1CQUFtQixVQUFVLENBQUM7O0FBRXpDLFVBQUksVUFBVTtBQUFXLGVBQU8sUUFBUTtBQUN4QyxNQUFBQSxRQUFPLEtBQUssMEJBQTBCLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsRUFBRTtJQUN0RSxPQUFPO0FBSU4sYUFBTyxVQUFVLE9BQU8sU0FBUyxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTyxLQUFLLENBQUE7QUFDcEUsYUFBTyxPQUFPO0FBRWQsWUFBTSxrQkFBa0IsVUFBVSxJQUFJLEdBQUcsTUFBTSxJQUFJLEVBQUUsRUFBRTtBQUN2RCxVQUFJLG1CQUFtQixnQkFBZ0IsT0FBTyxHQUFHO0FBQ2hELGNBQU0sV0FBVyxLQUFLLElBQUksR0FBRyxlQUFlO0FBQzVDLFlBQUksYUFBYSxHQUFHO0FBRW5CLGlCQUFPLFFBQVE7UUFDaEIsT0FBTztBQUVOLGdCQUFNLGVBQWUsTUFBTSxLQUFLLEVBQUUsUUFBUSxXQUFXLEVBQUMsR0FBSSxDQUFDLEdBQUcsT0FBTztZQUNwRSxJQUFJO1lBQ0osT0FBTyxXQUFXLElBQUksQ0FBQztZQUN0QjtBQUNGLGlCQUFPLFFBQVEsUUFBUTtZQUN0QixJQUFJO1lBQ0osT0FBTztZQUNQLE1BQU07WUFDTixTQUFTO1lBQ1QsU0FBUztXQUNUO1FBQ0Y7TUFDRDtBQU1BLFlBQU0sa0JBQWtCLG1CQUFtQixVQUFVLEVBQUU7QUFDdkQsWUFBTSxXQUFXLE9BQU8sU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUM3RCxVQUFJLFVBQVU7QUFDYixZQUFJLFNBQVMsV0FBVyxNQUFNLFFBQVEsU0FBUyxPQUFPLEdBQUc7QUFDeEQsZ0JBQU0sWUFBWSxTQUFTLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLGVBQWU7QUFDNUUsY0FBSSxDQUFDLFdBQVc7QUFDZixZQUFBQSxRQUFPLEtBQ04sK0JBQStCLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsaUNBQWlDLGVBQWUsc0NBQWlDO0FBRzlJLHFCQUFTLE9BQU87QUFDaEIsbUJBQVEsU0FBaUI7VUFDMUI7UUFDRDtBQUNBLGlCQUFTLFVBQVU7TUFDcEI7SUFDRDtBQUVBLFFBQUksVUFBVSxLQUFLLE1BQU07RUFDMUI7QUFTQSxhQUFXLEVBQUUsUUFBUSxHQUFFLEtBQU0sUUFBUTtBQUNwQyxVQUFNLGtCQUFrQixJQUFJLFVBQVUsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUU7QUFDcEYsUUFBSTtBQUFpQjtBQUdyQixVQUFNLFlBQVksSUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFLO0FBQzFDLFVBQUksRUFBRSxXQUFXO0FBQVEsZUFBTztBQUNoQyxZQUFNQyxZQUFXLEVBQUUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUN4RCxhQUFPLENBQUMsQ0FBQ0EsV0FBVSxXQUFXLEtBQUssRUFBRTtJQUN0QyxDQUFDO0FBQ0QsUUFBSSxDQUFDO0FBQVc7QUFFaEIsVUFBTSxTQUFTLEtBQUssVUFBVTtBQUM5QixVQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLFFBQUksQ0FBQyxVQUFVLFdBQVcsU0FBUyxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxNQUFNO0FBQUc7QUFJOUUsVUFBTSxlQUFlLFdBQVcsS0FBSyxDQUFDLE1BQUs7QUFDMUMsWUFBTSxXQUFXLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sVUFBVSxFQUFFO0FBQ3RGLFlBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsYUFBTyxVQUFVLFNBQVMsS0FBSyxDQUFDLE9BQVksR0FBRyxPQUFPLE1BQU07SUFDN0QsQ0FBQztBQUNELFVBQU0sa0JBQWtCLFNBQVMsUUFBUSxJQUFJLENBQUMsTUFBVyxFQUFFLEVBQVksRUFBRSxLQUFLLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQztBQUM3RixVQUFNLGVBQWUsZ0JBQWdCLFNBQVMsS0FBSyxXQUFXLGdCQUFnQixnQkFBZ0IsU0FBUyxDQUFDLElBQUk7QUFFNUcsUUFBSSxDQUFDLGdCQUFnQixDQUFDO0FBQWM7QUFHcEMsUUFBSSxRQUFRLFdBQVcsU0FBUyxDQUFDO0FBQ2pDLGVBQVcsS0FBSyxZQUFZO0FBQzNCLFlBQU0sV0FBVyxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLFVBQVUsRUFBRTtBQUN0RixZQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLFlBQU0sWUFBWSxVQUFVLFNBQVMsS0FBSyxDQUFDLE9BQVksR0FBRyxPQUFPLE1BQU07QUFDdkUsVUFBSSxXQUFXO0FBQ2QsZ0JBQVEsVUFBVTtBQUNsQjtNQUNEO0lBQ0Q7QUFFQSxhQUFTLFFBQVEsS0FBSyxFQUFFLElBQUksUUFBUSxNQUFLLENBQUU7QUFDM0MsSUFBQUQsUUFBTyxLQUNOLHlCQUF5QixNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLHVCQUF1QixNQUFNLFVBQVUsRUFBRSxDQUFDLGNBQWMsTUFBTSxNQUFNLEtBQUssSUFBSTtFQUVySTtBQUVBLFNBQU87QUFDUjtBQU1NLFNBQVUsb0JBQW9CLFVBQWtCLFNBQW9CO0FBQ3pFLE1BQUk7QUFFSCxVQUFNLGFBQWtCLEVBQUUsT0FBTyxRQUFRLE1BQUs7QUFHOUMsUUFBSSxlQUFlLFNBQVM7QUFDM0IsaUJBQVcsWUFBWSxRQUFRO0lBQ2hDO0FBR0EsUUFBSSxlQUFlLFNBQVM7QUFDM0IsaUJBQVcsWUFBWSxRQUFRLFVBQVUsSUFBSSxDQUFDLFVBQWM7QUFFM0QsY0FBTSxlQUFvQixDQUFBO0FBQzFCLFlBQUksWUFBWTtBQUFPLHVCQUFhLFNBQVMsTUFBTTtBQUNuRCxZQUFJLFFBQVE7QUFBTyx1QkFBYSxLQUFLLE1BQU07QUFDM0MsWUFBSSxXQUFXO0FBQU8sdUJBQWEsUUFBUSxNQUFNO0FBQ2pELFlBQUksVUFBVTtBQUFPLHVCQUFhLE9BQU8sTUFBTTtBQUMvQyxZQUFJLGFBQWE7QUFBTyx1QkFBYSxVQUFVLE1BQU07QUFFckQsbUJBQVcsT0FBTyxPQUFPLEtBQUssS0FBSyxHQUFHO0FBQ3JDLGNBQUksRUFBRSxPQUFPO0FBQWUseUJBQWEsR0FBRyxJQUFJLE1BQU0sR0FBRztRQUMxRDtBQUNBLGVBQU87TUFDUixDQUFDO0lBQ0Y7QUFFQSxlQUFXLE9BQU8sT0FBTyxLQUFLLE9BQU8sR0FBRztBQUN2QyxVQUFJLEVBQUUsT0FBTyxhQUFhO0FBQ3pCLG1CQUFXLEdBQUcsSUFBSyxRQUFnQixHQUFHO01BQ3ZDO0lBQ0Q7QUFHQSxRQUFJLE9BQU8sS0FBSyxVQUFVLFlBQVksTUFBTSxDQUFDO0FBSzdDLFdBQU8sS0FBSyxRQUFRLDBEQUEwRCw2QkFBNkI7QUFFM0csSUFBQUUsSUFBRyxjQUFjLFVBQVUsT0FBTyxNQUFNLE1BQU07RUFDL0MsU0FBUyxHQUFHO0FBQ1gsSUFBQUYsUUFBTyxNQUFNLHFCQUFxQixDQUFDLEVBQUU7RUFDdEM7QUFDRDs7O0FEaHJCQSxJQUFNRyxVQUFTLG1CQUFtQixTQUFTO0FBRXJDLFNBQVUsY0FBYyxNQUFvQjtBQUNqRCxRQUFNLGFBQWEsaUJBQWdCO0FBQ25DLFFBQU0sYUFBYSxhQUFZO0FBQy9CLFFBQU0sVUFBVSxxQkFBcUIsVUFBVTtBQUMvQyxRQUFNLGVBQW9CLENBQUE7QUFFMUIsUUFBTSxjQUFjLEtBQUs7QUFNekIsTUFBSSxLQUFLLE9BQU8sU0FBUztBQUN4QixpQkFBYSx1QkFBdUIsSUFBSTtNQUN2QyxNQUFNO01BQ04sYUFBYTtNQUNiLFNBQVMsQ0FBQTtNQUNULFVBQVUsWUFBVztBQUNwQixjQUFNLFFBQVE7QUFDZCxjQUFNLEtBQUssS0FBSztBQUVoQixjQUFNLE1BQU0sTUFBTSxLQUFLLGFBQWEsbUJBQW1CLEVBQUU7QUFFekQsWUFBSSxZQUFZLGdCQUFnQixLQUFLO0FBRXJDLGNBQU0sRUFBRSxVQUFVLE9BQU0sSUFBSyxpQ0FBaUMsT0FBTyxHQUFHO0FBQ3hFLFFBQUFBLFFBQU8sTUFBTSxpQkFBaUIsS0FBSyxVQUFVLE1BQU0sQ0FBQyxFQUFFO0FBRXRELFlBQUksQ0FBQyxXQUFXO0FBQ2YsVUFBQUEsUUFBTyxLQUFLLFNBQVMsS0FBSyx1REFBa0Q7QUFDNUUsc0JBQVk7WUFDWDtZQUNBLFdBQVcsQ0FBQTs7UUFFYjtBQUVBLGNBQU0sVUFBVSw0QkFBNEIsV0FBVyxRQUFRLE9BQU87QUFDdEUsUUFBQUEsUUFBTyxNQUFNLHFCQUFxQixLQUFLLFVBQVUsU0FBUyxNQUFNLENBQUMsQ0FBQyxFQUFFO0FBRXBFLGNBQU1DLGlCQUFnQixpQkFBZ0I7QUFDdEMsY0FBTSxhQUFhQyxNQUFLLEtBQUtELGdCQUFlLFFBQVEsS0FBSyxPQUFPO0FBQ2hFLDRCQUFvQixZQUFZLE9BQU87QUFFdkMsNEJBQW1CO0FBRW5CLFFBQUFELFFBQU8sS0FBSyxTQUFTLEtBQUssd0NBQXdDO01BQ25FOztFQUVGO0FBTUEsYUFBVyxDQUFDLFVBQVUsTUFBTSxLQUFLLE9BQU8sUUFBUSxVQUFVLEdBQUc7QUFDNUQsVUFBTSxFQUFFLE9BQU8sT0FBTyxPQUFNLElBQUssZUFBZSxRQUFRO0FBR3hELFFBQUksVUFBVTtBQUFhO0FBRzNCLFVBQU0sU0FBUyxRQUFRLEtBQUs7QUFDNUIsVUFBTSxZQUFZLFFBQVEsV0FBVyxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sTUFBTTtBQUUzRixpQkFBYSxRQUFRLElBQUk7TUFDeEIsR0FBRztNQUNILFVBQVUsT0FBTyxVQUFjO0FBQzlCLGNBQU0sS0FBSyxLQUFLO0FBQ2hCLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVksTUFBTSxRQUFRLE9BQU8sSUFBSSxXQUFXO0FBQ3pGLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTztBQUNuQyxjQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU8sS0FBSztBQUN4QyxjQUFNLFlBQVksU0FBUztBQUUzQixjQUFNLEtBQUssYUFBYSxhQUFhLE9BQU8sT0FBTyxXQUFXLE9BQU8sRUFBRTtNQUN4RTtNQUNBLE9BQU8sQ0FBQyxVQUFjO0FBQ3JCLGNBQU0sS0FBSyxLQUFLO0FBQ2hCLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTyxLQUFLO0FBQ3hDLGNBQU0sWUFBWSxTQUFTO0FBQzNCLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVksTUFBTSxRQUFRLE9BQU8sSUFBSSxXQUFXO0FBRXpGLGNBQU0sVUFBVSxLQUFLLGFBQWEsZ0JBQWdCLElBQUksT0FBTyxXQUFXLEtBQUs7QUFDN0UsWUFBSSxZQUFZO0FBQVcsaUJBQU87QUFFbEMsZUFBTyxFQUFFLEdBQUcsTUFBTSxTQUFTLE9BQU8sUUFBTztNQUMxQzs7RUFFRjtBQUtBLFFBQU0sZUFBZSxRQUFRLFdBQVc7QUFDeEMsTUFBSSxjQUFjO0FBQ2pCLFVBQU0sbUJBQW1CLGFBQWEsYUFBYSxDQUFBLEdBQUksS0FBSyxDQUFDLE1BQVcsRUFBRSxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBRS9GLFFBQUksaUJBQWlCO0FBQ3BCLFlBQU0sV0FBVyxHQUFHLFdBQVc7QUFFL0IsbUJBQWEsUUFBUSxJQUFJO1FBQ3hCLE1BQU0sU0FBUyxXQUFXO1FBQzFCLFNBQVMsQ0FBQTtRQUNULFVBQVUsWUFBVztBQUNwQixnQkFBTSxLQUFLLEtBQUs7QUFDaEIsVUFBQUEsUUFBTyxLQUFLLHlCQUFvQixXQUFXLE1BQU0sRUFBRSxFQUFFO0FBQ3JELGdCQUFNLEtBQUssYUFBYSxjQUFjLEVBQUU7QUFDeEMsZ0JBQU0sS0FBSyxhQUFhLG1CQUFtQixFQUFFLEVBQUUsTUFBTSxDQUFDLFFBQU87QUFDNUQsWUFBQUEsUUFBTyxLQUFLLDZDQUE2QyxHQUFHLEVBQUU7VUFDL0QsQ0FBQztRQUNGOztJQUVGO0VBQ0Q7QUFFQSxPQUFLLHFCQUFxQixZQUFZO0FBQ3ZDOzs7QUV0SEEsU0FBUyxpQkFDUixTQUNBLE9BQ0EsT0FDQSxXQUNBLE9BQWE7QUFFYixRQUFNLFVBQVUscUJBQXFCLFNBQVMsT0FBTyxPQUFPLFNBQVM7QUFDckUsTUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLFFBQVEsUUFBUSxPQUFPO0FBQUcsV0FBTztBQUd4RCxRQUFNLGNBQWMsUUFBUSxRQUFRLEtBQUssQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBQ3pFLE1BQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxRQUFRLFlBQVksT0FBTztBQUFHLFdBQU87QUFHaEUsUUFBTSxTQUFTLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sS0FBSztBQUNsRSxTQUFPLFFBQVEsU0FBUztBQUN6QjtBQU1NLFNBQVUsZ0JBQWdCLE1BQW9CO0FBQ25ELFFBQU0sYUFBYSxpQkFBZ0I7QUFDbkMsUUFBTSxlQUFlLGVBQWM7QUFDbkMsUUFBTSxVQUFVLHFCQUFxQixVQUFVO0FBQy9DLFFBQU0saUJBQXNCLENBQUE7QUFHNUIsUUFBTSxjQUFjLEtBQUs7QUFNekIsYUFBVyxDQUFDLFlBQVksUUFBUSxLQUFLLE9BQU8sUUFBUSxZQUFZLEdBQUc7QUFFbEUsVUFBTSxVQUFVLFdBQVcsU0FBUyxPQUFPLElBQUksV0FBVyxNQUFNLEdBQUcsRUFBRSxJQUFJO0FBQ3pFLFVBQU0sRUFBRSxPQUFPLE9BQU8sT0FBTSxJQUFLLGVBQWUsT0FBTztBQUd2RCxRQUFJLFVBQVU7QUFBYTtBQUczQixtQkFBZSxVQUFVLElBQUk7TUFDNUIsR0FBRztNQUNILFVBQVUsQ0FBQyxrQkFBc0I7QUFDaEMsY0FBTSxLQUFLLEtBQUs7QUFDaEIsY0FBTSxRQUFRLGNBQWMsUUFBUSxPQUFPLEtBQUs7QUFDaEQsY0FBTSxZQUFZLFNBQVM7QUFHM0IsWUFBSSxRQUFRLGNBQWMsUUFBUSxPQUFPO0FBQ3pDLFlBQUksVUFBVSxRQUFXO0FBQ3hCLGdCQUFNLGVBQWUscUJBQXFCLFNBQVMsT0FBTyxPQUFPLFNBQVM7QUFDMUUsY0FBSSxjQUFjLFVBQVUsUUFBVztBQUN0QyxvQkFBUSxhQUFhO1VBQ3RCO1FBQ0Q7QUFHQSxZQUFJLFVBQVUsUUFBVztBQUN4QixnQkFBTSxZQUFZLFdBQVcsS0FBSyxHQUFHLFdBQVcsS0FBSyxDQUFDLE1BQVcsRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFDekcsY0FBSSxXQUFXLFVBQVUsUUFBVztBQUNuQyxvQkFBUSxVQUFVO1VBQ25CO1FBQ0Q7QUFFQSxjQUFNLFVBQVUsS0FBSyxhQUFhLGdCQUFnQixJQUFJLE9BQU8sV0FBVyxLQUFLO0FBTTdFLFlBQUksV0FBVyxTQUFTLE9BQU8sR0FBRztBQUNqQyxpQkFBTyxZQUFZLFVBQWEsWUFBWTtRQUM3QztBQUdBLGNBQU0sWUFBWSxjQUFjLFFBQVEsV0FBVyxLQUFLO0FBRXhELFlBQUksYUFBYSxZQUFZLFFBQVc7QUFDdkMsZ0JBQU0sUUFBUSxpQkFBaUIsU0FBUyxPQUFPLE9BQU8sV0FBVyxPQUFPO0FBR3hFLGNBQUksT0FBTyxVQUFVLFVBQVU7QUFDOUIsbUJBQU8sVUFBVSxJQUFJLFNBQVM7VUFDL0I7QUFDQSxpQkFBTztRQUNSO0FBR0EsZUFBTyxXQUFXO01BQ25COztFQUVGO0FBRUEsT0FBSyx1QkFBdUIsY0FBYztBQUMzQzs7O0FDM0dBLE9BQU9HLFlBQVc7QUFDbEIsT0FBT0MsU0FBUTs7O0FDRGYsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sUUFBUTtBQUlmLElBQU1DLFVBQVMsbUJBQW1CLE9BQU87QUFLekMsSUFBTSx5QkFBeUI7QUFFeEIsSUFBTSwwQkFBMEI7QUFDdkMsSUFBTSxxQkFBcUIsTUFBTztBQUVsQyxTQUFTLHdCQUFxQjtBQUM3QixRQUFNLE1BQU0sT0FBTyxNQUFNLElBQUksQ0FBQztBQUM5QixRQUFNLE1BQU0sS0FBSyxNQUFNLEtBQUssT0FBTSxJQUFLLEtBQU07QUFFN0MsTUFBSSxjQUFjLE9BQVEsQ0FBQztBQUMzQixNQUFJLGNBQWMsd0JBQXdCLENBQUM7QUFDM0MsTUFBSSxjQUFjLEtBQUssQ0FBQztBQUV4QixRQUFNLE1BQU0saUJBQWdCO0FBQzVCLE1BQUksS0FBSyxLQUFLLENBQUM7QUFFZixTQUFPLEtBQUssWUFBWSxPQUFPLEVBQUUsS0FBSyxLQUFLLEVBQUU7QUFDN0MsTUFBSSxjQUFjLE1BQVEsRUFBRTtBQUM1QixNQUFJLGNBQWMsS0FBUSxFQUFFO0FBQzVCLE1BQUksY0FBYyxLQUFZLEVBQUU7QUFFaEMsU0FBTztBQUNSO0FBR0EsU0FBUyxtQkFBZ0I7QUFDeEIsTUFBSTtBQUNILFVBQU0sU0FBUyxHQUFHLGtCQUFpQjtBQUNuQyxlQUFXLFFBQVEsT0FBTyxLQUFLLE1BQU0sR0FBRztBQUN2QyxpQkFBVyxRQUFRLE9BQU8sSUFBSSxLQUFLLENBQUEsR0FBSTtBQUN0QyxZQUFJLENBQUMsS0FBSyxZQUFZLEtBQUssV0FBVyxVQUFVLEtBQUssT0FBTyxLQUFLLFFBQVEscUJBQXFCO0FBQzdGLGlCQUFPLE9BQU8sS0FBSyxLQUFLLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQWMsU0FBUyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBQzNFO01BQ0Q7SUFDRDtFQUNELFFBQVE7RUFFUjtBQUNBLFNBQU8sT0FBTyxNQUFNLEdBQUcsQ0FBQztBQUN6QjtBQUVNLFNBQVUsdUJBQXVCLEtBQWEsT0FBYTtBQUNoRSxNQUFJLElBQUksU0FBUztBQUFvQixXQUFPO0FBQzVDLE1BQUksSUFBSSxhQUFhLENBQUMsTUFBTTtBQUFRLFdBQU87QUFDM0MsTUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQXlCLFdBQU87QUFDNUQsTUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFLEVBQUUsU0FBUyxPQUFPLE1BQU07QUFBWSxXQUFPO0FBRWxFLFFBQU0sVUFBVSxDQUFDLFFBQWdCLFFBQ2hDLElBQ0UsU0FBUyxRQUFRLFNBQVMsR0FBRyxFQUM3QixTQUFTLE9BQU8sRUFDaEIsTUFBTSxJQUFJLEVBQUUsQ0FBQyxFQUNiLEtBQUk7QUFFUCxRQUFNLFFBQVEsSUFBSSxTQUFTLEdBQUcsRUFBRTtBQUNoQyxRQUFNLFdBQVcsQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQztBQUM1RSxRQUFNLE1BQU0sU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFBRSxLQUFLLEdBQUc7QUFFekUsUUFBTSxPQUFPLFFBQVEsSUFBTSxFQUFFO0FBQzdCLFFBQU0sZUFBZSxRQUFRLElBQU0sRUFBRTtBQUNyQyxRQUFNLFdBQVcsUUFBUSxLQUFNLEVBQUU7QUFDakMsUUFBTSxnQkFBZ0IsR0FBRyxJQUFJLEVBQUksQ0FBQyxJQUFJLElBQUksRUFBSSxDQUFDO0FBRS9DLE1BQUksQ0FBQztBQUFVLFdBQU87QUFJdEIsUUFBTSxRQUFRLFNBQ1osUUFBUSxjQUFjLEVBQUUsRUFDeEIsS0FBSSxFQUNKLE1BQU0sS0FBSyxFQUFFLENBQUM7QUFFaEIsU0FBTztJQUNOLElBQUk7SUFDSjtJQUNBO0lBQ0E7SUFDQSxXQUFXOztJQUNYO0lBQ0E7O0FBRUY7QUFPQSxlQUFzQixxQkFBcUIsUUFBYztBQUN4RCxTQUFPLElBQUksUUFBa0IsQ0FBQyxTQUFTLFdBQVU7QUFDaEQsVUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBRXJDLFFBQUksS0FBSyxTQUFTLENBQUMsUUFBTztBQUN6QixVQUFJLE1BQUs7QUFDVCxhQUFPLElBQUksTUFBTSxJQUFJLFdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQztJQUM3QyxDQUFDO0FBRUQsUUFBSSxRQUFRLEdBQUcsUUFBUSxNQUFLO0FBQzNCLFVBQUk7QUFDSCxjQUFNLE9BQU8sSUFBSSxRQUFPO0FBQ3hCLGNBQU0sWUFBWSxLQUFLO0FBQ3ZCLFlBQUksTUFBSztBQUVULGNBQU0sU0FBUyxHQUFHLGtCQUFpQjtBQUNuQyxtQkFBVyxRQUFRLE9BQU8sS0FBSyxNQUFNLEdBQUc7QUFDdkMscUJBQVcsU0FBUyxPQUFPLElBQUksS0FBSyxDQUFBLEdBQUk7QUFDdkMsZ0JBQ0MsTUFBTSxXQUFXLFVBQ2pCLE1BQU0sWUFBWSxhQUNsQixNQUFNLE9BQ04sTUFBTSxRQUFRLHFCQUNiO0FBQ0QscUJBQU8sUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sU0FBUyxHQUFHLEVBQUUsSUFBSSxHQUFJLENBQUM7WUFDdkU7VUFDRDtRQUNEO0FBQ0EsZUFBTyxJQUFJLE1BQU0sd0NBQXdDLFNBQVMsRUFBRSxDQUFDO01BQ3RFLFNBQVMsSUFBSTtBQUNaLGVBQU8sSUFBSSxNQUFNLE9BQU8sRUFBRSxDQUFDLENBQUM7TUFDN0I7SUFDRCxDQUFDO0VBQ0YsQ0FBQztBQUNGO0FBTUEsZUFBc0IsOEJBQThCLFFBQWM7QUFDakUsU0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFVBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUVyQyxRQUFJLFdBQVc7QUFDZixRQUFJLEtBQUssU0FBUyxDQUFDLFFBQU87QUFDekIsVUFBSSxDQUFDLFVBQVU7QUFDZCxtQkFBVztBQUNYLFlBQUksTUFBSztBQUNULGVBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO01BQzdDO0lBQ0QsQ0FBQztBQUdELFFBQUksUUFBUSxHQUFHLFFBQVEsTUFBSztBQUMzQixVQUFJO0FBQ0gsY0FBTSxPQUFPLElBQUksUUFBTztBQUN4QixjQUFNLFlBQVksS0FBSztBQUN2QixZQUFJLENBQUMsVUFBVTtBQUNkLHFCQUFXO0FBQ1gsY0FBSSxNQUFLO0FBQ1Qsa0JBQVEsU0FBUztRQUNsQjtNQUNELFNBQVMsSUFBSTtBQUNaLFlBQUksQ0FBQyxVQUFVO0FBQ2QscUJBQVc7QUFDWCxjQUFJLE1BQUs7QUFDVCxpQkFBTyxJQUFJLE1BQU0sT0FBTyxFQUFFLENBQUMsQ0FBQztRQUM3QjtNQUNEO0lBQ0QsQ0FBQztFQUNGLENBQUM7QUFDRjtBQVdBLGVBQXNCLGdCQUNyQixVQUNBLGtCQUNBLFlBQVksS0FBSTtBQUVoQixRQUFNLHVCQUF1QjtBQUM3QixRQUFNLHNCQUFzQjtBQUM1QixRQUFNLGVBQWU7QUFFckIsUUFBTSxhQUFhLG9CQUFJLElBQUc7QUFFMUIsU0FBTyxJQUFJLFFBQWMsQ0FBQyxZQUFXO0FBQ3BDLFVBQU0saUJBQWlCLE1BQU0sYUFBYSxFQUFFLE1BQU0sUUFBUSxXQUFXLEtBQUksQ0FBRTtBQUMzRSxVQUFNLG1CQUE2QixDQUFBO0FBRW5DLFVBQU0sVUFBVSxNQUFLO0FBQ3BCLGlCQUFXLFNBQVMsa0JBQWtCO0FBQ3JDLFlBQUk7QUFDSCx5QkFBZSxlQUFlLHNCQUFzQixLQUFLO1FBQzFELFFBQVE7UUFFUjtNQUNEO0FBQ0EsVUFBSTtBQUNILHVCQUFlLE1BQUs7TUFDckIsUUFBUTtNQUVSO0FBQ0EsY0FBTztJQUNSO0FBRUEsVUFBTSxRQUFRLFdBQVcsU0FBUyxTQUFTO0FBQzNDLFVBQU0sUUFBTztBQUViLG1CQUFlLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDbEMsTUFBQUEsUUFBTyxLQUFLLDBCQUEwQixJQUFJLE9BQU8sRUFBRTtJQUNwRCxDQUFDO0FBRUQsbUJBQWUsR0FBRyxXQUFXLENBQUMsS0FBSyxVQUFTO0FBQzNDLFlBQU0sUUFBUSxNQUFNO0FBRXBCLFVBQUksSUFBSSxTQUFTO0FBQUk7QUFDckIsVUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQVE7QUFDcEMsVUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFLEVBQUUsU0FBUyxPQUFPLE1BQU07QUFBWTtBQUUzRCxVQUFJLFdBQVcsSUFBSSxLQUFLO0FBQUc7QUFDM0IsaUJBQVcsSUFBSSxLQUFLO0FBQ3BCLE1BQUFBLFFBQU8sTUFBTSxpQkFBaUIsS0FBSywrQkFBMEI7QUFLN0QsWUFBTSxZQUFZLFlBQVc7QUFDNUIsY0FBTSxpQkFBaUIsS0FBSztBQUM1QixjQUFNLFFBQVEsc0JBQXFCO0FBQ25DLGlCQUFTLEtBQUssT0FBTyxjQUFjLE9BQU8sQ0FBQyxRQUFPO0FBQ2pELGNBQUk7QUFBSyxZQUFBQSxRQUFPLEtBQUssb0JBQW9CLEtBQUssWUFBWSxJQUFJLE9BQU8sRUFBRTtRQUN4RSxDQUFDO01BQ0Y7QUFDQSxnQkFBUyxFQUFHLE1BQU0sQ0FBQyxRQUFRQSxRQUFPLEtBQUssdUJBQXVCLEdBQUcsRUFBRSxDQUFDO0lBQ3JFLENBQUM7QUFFRCxtQkFBZSxLQUFLLHFCQUFxQixNQUFLO0FBSzdDLFlBQU0sU0FBUyxHQUFHLGtCQUFpQjtBQUNuQyxpQkFBVyxTQUFTLE9BQU8sT0FBTyxNQUFNLEdBQUc7QUFDMUMsbUJBQVcsUUFBUSxTQUFTLENBQUEsR0FBSTtBQUMvQixjQUFJLEtBQUssV0FBVyxVQUFVLENBQUMsS0FBSyxVQUFVO0FBQzdDLGdCQUFJO0FBQ0gsNkJBQWUsY0FBYyxzQkFBc0IsS0FBSyxPQUFPO0FBQy9ELCtCQUFpQixLQUFLLEtBQUssT0FBTztZQUNuQyxRQUFRO1lBRVI7VUFDRDtRQUNEO01BQ0Q7QUFDQSxVQUFJLGlCQUFpQixXQUFXLEdBQUc7QUFDbEMsUUFBQUEsUUFBTyxLQUFLLDBEQUEwRDtNQUN2RSxPQUFPO0FBQ04sUUFBQUEsUUFBTyxNQUFNLG9DQUFvQyxvQkFBb0IsSUFBSSxtQkFBbUIsRUFBRTtNQUMvRjtJQUNELENBQUM7RUFDRixDQUFDO0FBQ0Y7QUFlQSxlQUFzQixZQUNyQixVQUNBLGtCQUNBLGdCQUNBLGtCQUNBLElBQ0EsWUFBWSxLQUFJO0FBRWhCLFNBQU8sSUFBSSxRQUEyQixDQUFDLFlBQVc7QUFDakQsVUFBTSxNQUFNLFdBQVcsRUFBRTtBQUN6QixRQUFJLFdBQVc7QUFFZixVQUFNLFNBQVMsQ0FBQyxXQUE2QjtBQUM1QyxVQUFJO0FBQVU7QUFDZCxpQkFBVztBQUNYLHFCQUFlLEdBQUc7QUFDbEIsY0FBUSxNQUFNO0lBQ2Y7QUFFQSxxQkFBaUIsS0FBSyxDQUFDLFdBQXNCO0FBQzVDLFVBQUksT0FBTyxPQUFPO0FBQUksZUFBTyxNQUFNO0lBQ3BDLENBQUM7QUFFRCxVQUFNLFFBQVEsV0FBVyxNQUFNLE9BQU8sSUFBSSxHQUFHLFNBQVM7QUFDdEQsVUFBTSxRQUFPO0FBRWIsVUFBTSxNQUFNLFlBQVc7QUFDdEIsWUFBTSxpQkFBaUIsRUFBRTtBQUN6QixZQUFNLFFBQVEsc0JBQXFCO0FBQ25DLGVBQVMsS0FBSyxPQUFPLE1BQU0sSUFBSSxDQUFDLFFBQU87QUFDdEMsWUFBSSxLQUFLO0FBQ1IsVUFBQUEsUUFBTyxLQUFLLFlBQVksRUFBRSxZQUFZLElBQUksT0FBTyxFQUFFO0FBQ25ELHVCQUFhLEtBQUs7QUFDbEIsaUJBQU8sSUFBSTtRQUNaO01BQ0QsQ0FBQztJQUNGO0FBRUEsUUFBRyxFQUFHLE1BQU0sQ0FBQyxNQUFLO0FBQ2pCLE1BQUFBLFFBQU8sS0FBSyxnQ0FBZ0MsRUFBRSxLQUFLLENBQUMsRUFBRTtBQUN0RCxtQkFBYSxLQUFLO0FBQ2xCLGFBQU8sSUFBSTtJQUNaLENBQUM7RUFDRixDQUFDO0FBQ0Y7OztBQ3ZVQSxPQUFPQyxZQUFXO0FBSWxCLElBQU1DLFVBQVMsbUJBQW1CLFFBQVE7QUFHMUMsSUFBTSxpQkFBaUIsb0JBQUksSUFBRztBQU85QixlQUFzQixrQkFBa0IsVUFBa0IsWUFBWSxLQUFJO0FBQ3pFLFFBQU0sVUFBVSxlQUFlLElBQUksUUFBUTtBQUMzQyxNQUFJO0FBQVMsV0FBTztBQUVwQixRQUFNLFVBQVUsaUJBQWlCLFVBQVUsU0FBUyxFQUFFLFFBQVEsTUFBSztBQUNsRSxtQkFBZSxPQUFPLFFBQVE7RUFDL0IsQ0FBQztBQUNELGlCQUFlLElBQUksVUFBVSxPQUFPO0FBQ3BDLFNBQU87QUFDUjtBQUVBLGVBQWUsaUJBQWlCLFVBQWtCLFdBQWlCO0FBQ2xFLFNBQU8sSUFBSSxRQUE2QixDQUFDLFlBQVc7QUFDbkQsUUFBSSxVQUFVO0FBQ2QsUUFBSSxpQkFBd0Q7QUFFNUQsVUFBTSxlQUFlLENBQUNDLFVBQXNCO0FBQzNDLFVBQUksZ0JBQWdCO0FBQ25CLHNCQUFjLGNBQWM7QUFDNUIseUJBQWlCO01BQ2xCO0FBQ0EsVUFBSTtBQUNILFFBQUFBLE1BQUssTUFBSztNQUNYLFFBQVE7TUFFUjtBQUNBLE1BQUFELFFBQU8sTUFBTSw2QkFBNkIsUUFBUSxFQUFFO0lBQ3JEO0FBRUEsVUFBTSxPQUFPLENBQUNDLFVBQXNCO0FBQ25DLFVBQUk7QUFBUztBQUNiLGdCQUFVO0FBQ1YsbUJBQWEsS0FBSztBQUNsQixtQkFBYUEsS0FBSTtBQUNqQixNQUFBRCxRQUFPLE1BQU0sc0NBQXNDLFFBQVEsRUFBRTtBQUM3RCxjQUFRLElBQUk7SUFDYjtBQUVBLFVBQU0sT0FBT0UsT0FBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBQ2pFLFVBQU0sUUFBUSxXQUFXLE1BQU0sS0FBSyxJQUFJLEdBQUcsU0FBUztBQUVwRCxTQUFLLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDeEIsTUFBQUYsUUFBTyxLQUFLLDJCQUEyQixRQUFRLEtBQUssSUFBSSxPQUFPLEVBQUU7QUFDakUsV0FBSyxJQUFJO0lBQ1YsQ0FBQztBQUVELFNBQUssR0FBRyxXQUFXLENBQUMsUUFBZTtBQUVsQyxVQUFJLENBQUMsV0FBVyxJQUFJLFVBQVUsS0FBSyxJQUFJLENBQUMsTUFBTSxNQUFRLElBQUksQ0FBQyxNQUFNLElBQU07QUFDdEUsa0JBQVU7QUFDVixxQkFBYSxLQUFLO0FBQ2xCLFFBQUFBLFFBQU8sS0FBSyxtQ0FBbUMsUUFBUSxFQUFFO0FBRXpELFlBQUksZUFBZSxLQUFLLE1BQU0sS0FBSyxPQUFNLElBQUssS0FBTSxJQUFJO0FBQ3hELGNBQU0sZ0JBQWdCLE1BQUs7QUFDMUIsZ0JBQU0sTUFBTSxPQUFPLE1BQU0sSUFBSSxDQUFDO0FBQzlCLGNBQUksQ0FBQyxJQUFJO0FBQ1QsY0FBSSxDQUFDLElBQUk7QUFDVCxjQUFJLGNBQWMsaUJBQWlCLE9BQVEsQ0FBQztBQUM1QyxjQUFJLENBQUMsSUFBSTtBQUNULGNBQUksQ0FBQyxJQUFJO0FBQ1QsZUFBSyxLQUFLLEtBQUssTUFBTSxVQUFVLE1BQUs7VUFFcEMsQ0FBQztRQUNGO0FBQ0EseUJBQWlCLFlBQVksZUFBZSxHQUFJO0FBQ2hELGdCQUFRLE1BQU0sYUFBYSxJQUFJLENBQUM7TUFDakM7SUFDRCxDQUFDO0FBRUQsVUFBTSxTQUFTLFlBQVc7QUFDekIsVUFBSTtBQUNKLFVBQUk7QUFDSixVQUFJO0FBQ0gsa0JBQVUsTUFBTSw4QkFBOEIsUUFBUTtBQUN0RCxtQkFBVyxNQUFNLHFCQUFxQixRQUFRO01BQy9DLFNBQVMsR0FBRztBQUNYLFFBQUFBLFFBQU8sS0FBSyxnREFBZ0QsUUFBUSxLQUFLLENBQUMsRUFBRTtBQUM1RSxhQUFLLElBQUk7QUFDVDtNQUNEO0FBRUEsV0FBSyxLQUFLLEVBQUUsTUFBTSxNQUFNLFNBQVMsUUFBTyxHQUFJLE1BQUs7QUFDaEQsY0FBTSxNQUFNLEtBQUssTUFBTSxLQUFLLE9BQU0sSUFBSyxLQUFNLElBQUk7QUFDakQsY0FBTSxNQUFNLE9BQU8sTUFBTSxJQUFJLENBQUM7QUFDOUIsWUFBSSxDQUFDLElBQUk7QUFDVCxZQUFJLENBQUMsSUFBSTtBQUNULFlBQUksY0FBYyxLQUFLLENBQUM7QUFDeEIsWUFBSSxDQUFDLElBQUk7QUFDVCxZQUFJLENBQUMsSUFBSTtBQUNULGlCQUFTLFFBQVEsQ0FBQyxHQUFHLE1BQUs7QUFDekIsY0FBSSxLQUFLLENBQUMsSUFBSTtRQUNmLENBQUM7QUFDRCxRQUFBQSxRQUFPLE1BQU0sZ0JBQWdCLFFBQVEsS0FBSyxJQUFJLFNBQVMsS0FBSyxDQUFDLEVBQUU7QUFDL0QsYUFBSyxLQUFLLEtBQUssTUFBTSxVQUFVLENBQUMsUUFBTztBQUN0QyxjQUFJLEtBQUs7QUFDUixZQUFBQSxRQUFPLEtBQUssMEJBQTBCLFFBQVEsS0FBSyxJQUFJLE9BQU8sRUFBRTtBQUNoRSxpQkFBSyxJQUFJO1VBQ1Y7UUFDRCxDQUFDO01BQ0YsQ0FBQztJQUNGO0FBRUEsV0FBTSxFQUFHLE1BQU0sQ0FBQyxNQUFLO0FBQ3BCLE1BQUFBLFFBQU8sS0FBSywwQkFBMEIsUUFBUSxLQUFLLENBQUMsRUFBRTtBQUN0RCxXQUFLLElBQUk7SUFDVixDQUFDO0VBQ0YsQ0FBQztBQUNGOzs7QUZuRkEsSUFBTUcsVUFBUyxtQkFBbUIsY0FBYztBQUUxQyxJQUFPLGVBQVAsTUFBTyxjQUFZO0VBQ1AsY0FBc0I7RUFDdEIsaUJBQWlCO0VBQ2pCLFNBQVM7RUFFbEI7RUFDQTs7RUFDQSxnQkFBcUM7O0VBQ3JDLGtCQUErQixvQkFBSSxJQUFHOztFQUN0QyxjQUdKLG9CQUFJLElBQUc7RUFDSCxtQkFBZ0Msb0JBQUksSUFBRzs7O0VBR3ZDLFlBQTJCLFFBQVEsUUFBTzs7RUFHMUMsc0JBQXNCOztFQUd0Qjs7RUFHQSxRQUFnQjtFQUNoQixVQUFzQixDQUFBOzs7Ozs7O0VBUXRCLGNBQWdELG9CQUFJLElBQUc7Ozs7Ozs7RUFRdkQsZ0JBQTZCLG9CQUFJLElBQUc7O0VBR3BDLHFCQUFnRSxvQkFBSSxJQUFHOztFQUd2RTs7RUFHQSxXQUFrQyxvQkFBSSxJQUFHOzs7RUFJekMscUJBQWtDLG9CQUFJLElBQUc7O0VBR3pDLGtCQUEyQyxvQkFBSSxJQUFHO0VBRTFELGNBQUE7QUFDQyxJQUFBQSxRQUFPLEtBQUssMEJBQTBCO0FBSXRDLFNBQUssV0FBV0MsT0FBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBQ3BFLFNBQUssVUFBVSxJQUFJLFFBQWMsQ0FBQyxZQUFXO0FBQzVDLFdBQUssU0FBUyxLQUFLLEdBQUcsTUFBSztBQUMxQixRQUFBRCxRQUFPLE1BQU0sMkJBQTRCLEtBQUssU0FBUyxRQUFPLEVBQXdCLElBQUksRUFBRTtBQUM1RixnQkFBTztNQUNSLENBQUM7SUFDRixDQUFDO0FBQ0QsU0FBSyxTQUFTLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDakMsTUFBQUEsUUFBTyxNQUFNLG9CQUFvQixHQUFHLEVBQUU7SUFDdkMsQ0FBQztBQUdELFNBQUssV0FBV0MsT0FBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBRXBFLFNBQUssU0FBUyxHQUFHLGFBQWEsTUFBSztBQUNsQyxZQUFNLE9BQU8sS0FBSyxTQUFTLFFBQU87QUFDbEMsTUFBQUQsUUFBTyxNQUFNLDBCQUEwQixLQUFLLFVBQVUsSUFBSSxDQUFDLEVBQUU7QUFDN0QsVUFBSTtBQUNILGFBQUssU0FBUyxxQkFBcUIsSUFBSTtNQUN4QyxTQUFTLElBQUk7TUFFYjtJQUNELENBQUM7QUFFRCxTQUFLLFNBQVMsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNqQyxNQUFBQSxRQUFPLE1BQU0sb0JBQW9CLEdBQUcsRUFBRTtJQUN2QyxDQUFDO0FBRUQsU0FBSyxTQUFTLEdBQUcsV0FBVyxDQUFDLEtBQUssVUFBUztBQUMxQyxVQUFJO0FBQ0gsYUFBSyxlQUFlLEtBQUssTUFBTSxPQUFPO01BQ3ZDLFNBQVMsSUFBSTtBQUNaLFFBQUFBLFFBQU8sTUFBTSxvQ0FBb0MsRUFBRSxFQUFFO01BQ3REO0lBQ0QsQ0FBQztBQU1ELFNBQUssU0FBUyxLQUFLLEVBQUUsU0FBUyxXQUFXLE1BQU0sS0FBSyxPQUFNLEdBQUksTUFBSztBQUNsRSxNQUFBQSxRQUFPLE1BQU0sOEJBQThCLEtBQUssTUFBTSxFQUFFO0FBQ3hELFlBQU0sU0FBU0UsSUFBRyxrQkFBaUI7QUFDbkMsaUJBQVcsU0FBUyxPQUFPLE9BQU8sTUFBTSxHQUFHO0FBQzFDLG1CQUFXLFFBQVEsU0FBUyxDQUFBLEdBQUk7QUFDL0IsY0FBSSxLQUFLLFdBQVcsVUFBVSxDQUFDLEtBQUssWUFBWSxDQUFDLEtBQUssaUJBQWlCLElBQUksS0FBSyxPQUFPLEdBQUc7QUFDekYsZ0JBQUk7QUFDSCxtQkFBSyxTQUFTLGNBQWMsS0FBSyxnQkFBZ0IsS0FBSyxPQUFPO0FBQzdELG1CQUFLLGlCQUFpQixJQUFJLEtBQUssT0FBTztBQUN0QyxjQUFBRixRQUFPLE1BQU0sd0JBQXdCLEtBQUssY0FBYyxPQUFPLEtBQUssT0FBTyxFQUFFO1lBQzlFLFNBQVMsSUFBSTtBQUNaLGNBQUFBLFFBQU8sS0FBSyxtQ0FBbUMsS0FBSyxPQUFPLEtBQUssT0FBTyxFQUFFLENBQUMsRUFBRTtZQUM3RTtVQUNEO1FBQ0Q7TUFDRDtJQUNELENBQUM7QUFLRCxTQUFLLGdCQUFnQkMsT0FBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBQ3pFLFNBQUssY0FBYyxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ3RDLE1BQUFELFFBQU8sTUFBTSwwQkFBMEIsSUFBSSxPQUFPLEVBQUU7SUFDckQsQ0FBQztBQUNELFNBQUssY0FBYyxHQUFHLFdBQVcsQ0FBQyxLQUFhLFVBQTJCO0FBQ3pFLFVBQUksSUFBSSxTQUFTO0FBQUk7QUFDckIsVUFBSSxJQUFJLENBQUMsTUFBTSxPQUFRLElBQUksQ0FBQyxNQUFNO0FBQU07QUFDeEMsWUFBTSxNQUFNLElBQUksU0FBUyxJQUFJLEVBQUU7QUFDL0IsVUFBSSxJQUFJLFNBQVMsT0FBTyxNQUFNO0FBQVk7QUFDMUMsWUFBTSxZQUFZLElBQUksU0FBUyxFQUFFO0FBQ2pDLFVBQUksVUFBVSxTQUFTLEtBQUssVUFBVSxDQUFDLE1BQU07QUFBTTtBQUNuRCxZQUFNLFlBQVksVUFBVSxDQUFDO0FBQzdCLFlBQU0sY0FBYyxZQUFZLFNBQVU7QUFDMUMsWUFBTSxnQkFBZ0IsWUFBWTtBQUNsQyxVQUFJLFlBQVk7QUFDZixjQUFNLE1BQU0sR0FBRyxNQUFNLE9BQU8sSUFBSSxhQUFhO0FBQzdDLGNBQU0sb0JBQW9CLENBQUMsS0FBSyxnQkFBZ0IsSUFBSSxHQUFHO0FBQ3ZELGFBQUssZ0JBQWdCLElBQUksR0FBRztBQUM1QixRQUFBQSxRQUFPLE1BQ04sdUJBQXVCLE1BQU0sT0FBTyxRQUFRLE1BQU0sYUFBYSxDQUFDLE1BQzlELG9CQUFvQiw0QkFBNEIsMkJBQTJCO0FBRzlFLG1CQUFXLE1BQU0sS0FBSyxnQkFBZ0IsT0FBTyxHQUFHLEdBQUcsR0FBRztNQUN2RDtJQUNELENBQUM7QUFDRCxTQUFLLGNBQWMsS0FBSyxFQUFFLFNBQVMsS0FBSyxnQkFBZ0IsTUFBTSxLQUFLLE9BQU0sR0FBSSxNQUFLO0FBQ2pGLE1BQUFBLFFBQU8sTUFBTSw0QkFBNEIsS0FBSyxjQUFjLElBQUksS0FBSyxNQUFNLEVBQUU7SUFDOUUsQ0FBQztFQUNGO0VBRU8sUUFBSztBQUVYLGVBQVcsV0FBVyxLQUFLLGdCQUFnQixPQUFNLEdBQUk7QUFDcEQsVUFBSTtBQUNILGdCQUFPO01BQ1IsUUFBUTtNQUVSO0lBQ0Q7QUFDQSxTQUFLLGdCQUFnQixNQUFLO0FBQzFCLFFBQUk7QUFDSCxpQkFBVyxhQUFhLE1BQU0sS0FBSyxLQUFLLGdCQUFnQixHQUFHO0FBQzFELFlBQUk7QUFDSCxlQUFLLFNBQVMsZUFBZSxLQUFLLGdCQUFnQixTQUFTO1FBQzVELFFBQVE7UUFFUjtNQUNEO0lBQ0QsUUFBUTtJQUVSO0FBQ0EsUUFBSTtBQUNILFdBQUssZUFBZSxNQUFLO0FBQ3pCLFdBQUssZ0JBQWdCO0lBQ3RCLFFBQVE7SUFFUjtBQUNBLFFBQUk7QUFDSCxXQUFLLFNBQVMsTUFBSztJQUNwQixRQUFRO0lBRVI7QUFDQSxRQUFJO0FBQ0gsV0FBSyxTQUFTLE1BQUs7SUFDcEIsUUFBUTtJQUVSO0VBQ0Q7Ozs7O0VBTU8sU0FBUyxPQUFlLFNBQW1CO0FBQ2pELFNBQUssUUFBUTtBQUNiLFNBQUssVUFBVTtFQUNoQjs7Ozs7RUFNTyxvQkFBb0IsVUFBc0M7QUFDaEUsU0FBSyxtQkFBbUI7RUFDekI7O0VBR08sbUJBQW1CLElBQVU7QUFDbkMsV0FBTyxLQUFLLGNBQWMsSUFBSSxFQUFFO0VBQ2pDOztFQUdPLGdCQUFnQixJQUFVO0FBQ2hDLFNBQUssY0FBYyxJQUFJLEVBQUU7QUFDekIsSUFBQUEsUUFBTyxNQUFNLHdCQUF3QixFQUFFLEVBQUU7RUFDMUM7O0VBR08sYUFBYSxJQUFVO0FBQzdCLFNBQUssY0FBYyxPQUFPLEVBQUU7QUFDNUIsU0FBSyxZQUFZLE9BQU8sRUFBRTtBQUMxQixTQUFLLFNBQVMsT0FBTyxFQUFFO0FBQ3ZCLFNBQUssbUJBQW1CLE9BQU8sRUFBRTtBQUNqQyxTQUFLLGdCQUFnQixJQUFJLEVBQUUsSUFBRztBQUM5QixTQUFLLGdCQUFnQixPQUFPLEVBQUU7QUFDOUIsSUFBQUEsUUFBTyxNQUFNLHFCQUFxQixFQUFFLEVBQUU7RUFDdkM7Ozs7OztFQU9PLE1BQU0sWUFBWSxVQUFnQjtBQUN4QyxRQUFJLEtBQUssbUJBQW1CLElBQUksUUFBUTtBQUFHLGFBQU87QUFDbEQsVUFBTSxTQUFTLGdCQUFnQixLQUFLLEtBQUs7QUFDekMsUUFBSSxDQUFDLFFBQVEsV0FBVztBQUV2QixXQUFLLG1CQUFtQixJQUFJLFFBQVE7QUFDcEMsYUFBTztJQUNSO0FBQ0EsVUFBTSxVQUFVLE1BQU0sa0JBQWtCLFFBQVE7QUFDaEQsVUFBTSxVQUFVLFlBQVk7QUFHNUIsU0FBSyxtQkFBbUIsSUFBSSxRQUFRO0FBQ3BDLFFBQUksU0FBUztBQUNaLFdBQUssZ0JBQWdCLElBQUksVUFBVSxPQUFPO0lBQzNDO0FBQ0EsV0FBTztFQUNSOzs7Ozs7O0VBUU8sTUFBTSxZQUFZLElBQVksWUFBWSxLQUFJO0FBQ3BELFVBQU0sS0FBSztBQUNYLFdBQU8sWUFDTixLQUFLLFVBQ0wsQ0FBQyxLQUFLLE9BQU8sS0FBSyxtQkFBbUIsSUFBSSxLQUFLLEVBQUUsR0FDaEQsQ0FBQyxRQUFRLEtBQUssbUJBQW1CLE9BQU8sR0FBRyxHQUMzQyxPQUFPLFdBQVcsS0FBSyxvQkFBb0IsTUFBTSxHQUNqRCxJQUNBLFNBQVM7RUFFWDs7Ozs7RUFNTyxNQUFNLG1CQUFtQixVQUFnQjtBQUMvQyxJQUFBQSxRQUFPLEtBQUssZ0NBQWdDLFFBQVEsRUFBRTtBQUN0RCxVQUFNLFdBQVcsTUFBTSxLQUFLLGFBQWEsc0JBQXNCLFFBQVcsUUFBVyxRQUFXLFVBQVUsS0FBSztBQUUvRyxXQUFPO0VBQ1I7Ozs7Ozs7RUFRTyxNQUFNLGdCQUFnQixZQUFZLEtBQUk7QUFDNUMsVUFBTSxnQkFBZ0I7QUFDdEIsVUFBTSxlQUE2QixDQUFBO0FBRW5DLFNBQUssbUJBQW1CLElBQUksZUFBZSxDQUFDLFdBQXNCO0FBQ2pFLFVBQUksQ0FBQyxhQUFhLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLEVBQUUsR0FBRztBQUNsRCxxQkFBYSxLQUFLLE1BQU07TUFDekI7SUFDRCxDQUFDO0FBRUQsUUFBSTtBQUNILFlBQU0sS0FBSztBQUNYLFlBQU0sZ0JBQWdCLEtBQUssVUFBVSxPQUFPLFdBQVcsS0FBSyxvQkFBb0IsTUFBTSxHQUFHLFNBQVM7QUFDbEcsYUFBTztJQUNSO0FBQ0MsV0FBSyxtQkFBbUIsT0FBTyxhQUFhO0lBQzdDO0VBQ0Q7Ozs7O0VBTU8sTUFBTSx1QkFBdUIsVUFBZ0I7QUFDbkQsSUFBQUEsUUFBTyxLQUFLLG9DQUFvQyxRQUFRLEVBQUU7QUFDMUQsVUFBTSxXQUFXLE1BQU0sS0FBSyxhQUFhLGtCQUFrQixRQUFXLFFBQVcsUUFBVyxVQUFVLEtBQUs7QUFJM0csVUFBTSxZQUFZO0FBRWxCLFFBQUksU0FBUyxTQUFTLFlBQVksR0FBRztBQUNwQyxNQUFBQSxRQUFPLEtBQUssZ0NBQWdDLFNBQVMsTUFBTSxRQUFRO0FBQ25FLGFBQU87SUFDUjtBQUdBLFVBQU0sUUFBUSxTQUFTLFlBQVksQ0FBQztBQUNwQyxVQUFNLFFBQVEsU0FBUyxZQUFZLENBQUM7QUFFcEMsVUFBTSxXQUNMLFFBQVEsS0FDTCxNQUFNLFNBQVEsRUFBRyxTQUFTLEdBQUcsR0FBRyxJQUNoQyxNQUFNLFNBQVE7QUFFbEIsVUFBTSxXQUFXLEdBQUcsS0FBSyxJQUFJLFFBQVE7QUFFckMsSUFBQUEsUUFBTyxNQUFNLHFCQUFxQixRQUFRLEVBQUU7QUFDNUMsV0FBTztFQUNSOzs7OztFQU1RLE1BQU0sb0JBQW9CLFFBQWM7QUFDL0MsUUFBSTtBQUNILFlBQU0sWUFBWSxNQUFNLDhCQUE4QixNQUFNO0FBQzVELFVBQUksQ0FBQyxXQUFXO0FBQ2YsUUFBQUEsUUFBTyxLQUFLLHFEQUFxRCxNQUFNLEVBQUU7QUFDekU7TUFDRDtBQUVBLFVBQUksS0FBSyxpQkFBaUIsSUFBSSxTQUFTLEdBQUc7QUFFekM7TUFDRDtBQUVBLFVBQUk7QUFDSCxhQUFLLFNBQVMsY0FBYyxLQUFLLGdCQUFnQixTQUFTO0FBQzFELGFBQUssaUJBQWlCLElBQUksU0FBUztBQUNuQyxRQUFBQSxRQUFPLEtBQUssb0JBQW9CLEtBQUssY0FBYyxPQUFPLFNBQVMsRUFBRTtNQUN0RSxTQUFTLElBQUk7QUFDWixRQUFBQSxRQUFPLEtBQUssK0JBQStCLFNBQVMsS0FBSyxPQUFPLEVBQUUsQ0FBQyxFQUFFO01BQ3RFO0lBQ0QsU0FBUyxJQUFJO0FBQ1osTUFBQUEsUUFBTyxLQUFLLCtCQUErQixFQUFFLEVBQUU7SUFDaEQ7RUFDRDtFQUVPLE1BQU0sYUFDWixPQUNBLE9BQ0EsV0FDQSxPQUNBLFFBQ0EsU0FBUyxNQUFJO0FBRWIsU0FBSztBQUNMLFdBQU8sSUFBSSxRQUFnQixDQUFDLFNBQVMsV0FBVTtBQUM5QyxXQUFLLFlBQVksS0FBSyxVQUFVLEtBQUssWUFDcEMsS0FBSyxjQUFjLE9BQU8sT0FBTyxXQUFXLE9BQU8sUUFBUSxNQUFNLEVBQy9ELEtBQUssQ0FBQyxRQUFPO0FBQ2IsYUFBSztBQUdMLFlBQUksS0FBSyx3QkFBd0IsS0FBSyxVQUFVLFFBQVc7QUFDMUQsZUFBSyxtQkFBbUIsTUFBTSxFQUFFLE1BQU0sQ0FBQyxRQUFPO0FBQzdDLFlBQUFBLFFBQU8sS0FBSyw2Q0FBNkMsR0FBRyxFQUFFO1VBQy9ELENBQUM7UUFDRjtBQUNBLGdCQUFRLEdBQUc7TUFDWixDQUFDLEVBQ0EsTUFBTSxDQUFDLFFBQU87QUFDZCxhQUFLO0FBQ0wsZUFBTyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sT0FBTyxHQUFHLENBQUMsQ0FBQztNQUMzRCxDQUFDLENBQUM7SUFFTCxDQUFDO0VBQ0Y7RUFFUSxNQUFNLGNBQ2IsT0FDQSxPQUNBLFdBQ0EsT0FDQSxRQUNBLFNBQVMsTUFBSTtBQUViLFVBQU0sWUFBWTtBQUVsQixVQUFNLFlBQXNCLENBQUE7QUFDNUIsUUFBSSxjQUFjO0FBQVcsZ0JBQVUsS0FBSyxZQUFZLEdBQUk7QUFDNUQsUUFBSSxVQUFVO0FBQVcsZ0JBQVUsS0FBSyxHQUFHLGNBQWEsZ0JBQWdCLEtBQUssQ0FBQztBQUU5RSxVQUFNLGNBQXdCLENBQUMsSUFBTSxRQUFRLEdBQUk7QUFFakQsUUFBSSxVQUFVLGVBQWUsVUFBVSxVQUFhLGNBQWMsVUFBYSxVQUFVLFFBQVc7QUFJbkcsVUFBSSxDQUFDLEtBQUssWUFBWSxJQUFJLE1BQU07QUFBRyxhQUFLLFlBQVksSUFBSSxRQUFRLG9CQUFJLElBQUcsQ0FBRTtBQUN6RSxZQUFNLFVBQVUsS0FBSyxZQUFZLElBQUksTUFBTTtBQUMzQyxZQUFNLGVBQWU7QUFDckIsWUFBTSxZQUFzQixDQUFBO0FBQzVCLGVBQVMsSUFBSSxHQUFHLElBQUksY0FBYyxLQUFLO0FBQ3RDLGNBQU0sV0FBVyxjQUFjLEtBQUssT0FBTyxhQUFhLEdBQUcsS0FBSztBQUNoRSxjQUFNLE1BQU0sTUFBTSxZQUFZLE9BQU8sS0FBSyxJQUFLLFFBQVEsSUFBSSxRQUFRLEtBQUs7QUFDeEUsa0JBQVUsS0FBSyxHQUFHO0FBQ2xCLGdCQUFRLElBQUksVUFBVSxHQUFHO01BQzFCO0FBQ0Esa0JBQVksS0FBSyxRQUFRLEtBQU0sR0FBRyxTQUFTO0lBQzVDLE9BQU87QUFDTixVQUFJLFVBQVU7QUFBVyxvQkFBWSxLQUFLLFFBQVEsR0FBSTtBQUN0RCxVQUFJO0FBQVEsb0JBQVksS0FBSyxVQUFVLE1BQU07QUFDN0MsVUFBSSxVQUFVLFNBQVM7QUFBRyxvQkFBWSxLQUFLLEdBQUcsU0FBUztJQUN4RDtBQUVBLFVBQU0sTUFBTSxjQUFhLFVBQVUsV0FBVztBQUM5QyxVQUFNLGlCQUFpQixPQUFPLEtBQUssQ0FBQyxHQUFHLGFBQWEsR0FBRyxDQUFDO0FBR3hELFFBQUksY0FBYyxVQUFhLFVBQVUsUUFBVztBQUNuRCxZQUFNLGFBQWEsY0FBYSxnQkFBZ0IsS0FBSztBQUNyRCxZQUFNLFVBQXlCO1FBQzlCLFFBQVE7UUFDUixJQUFJO1FBQ0o7UUFDQTs7QUFFRCxNQUFBQSxRQUFPLEtBQUssTUFBTSxNQUFNLE1BQU0sb0JBQW9CLFNBQVMsS0FBSyxPQUFPLENBQUMsRUFBRTtJQUMzRSxPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLE1BQU0sTUFBTSxNQUFNLGVBQWUsS0FBSyxDQUFDLEVBQUU7SUFDdEQ7QUFJQSxRQUFJLENBQUMsS0FBSyxjQUFjLElBQUksTUFBTSxHQUFHO0FBQ3BDLE1BQUFBLFFBQU8sTUFBTSxxREFBZ0QsTUFBTSxLQUFLLGVBQWUsU0FBUyxLQUFLLENBQUMsRUFBRTtBQUN4RyxZQUFNLElBQUksTUFBTSxhQUFhLE1BQU0saUZBQTRFO0lBQ2hIO0FBS0EsUUFBSSxDQUFDLEtBQUssbUJBQW1CLElBQUksTUFBTSxHQUFHO0FBQ3pDLFlBQU0sS0FBSyxZQUFZLE1BQU07SUFFOUI7QUFHQSxVQUFNLEtBQUssb0JBQW9CLE1BQU07QUFFckMsVUFBTSxXQUFXLEtBQUssZUFBZTtBQUNyQyxVQUFNLFNBQVMsTUFBTSxLQUFLLFlBQVksVUFBVSxNQUFNO0FBQ3RELFVBQU0sU0FBUyxPQUFPLE9BQU8sQ0FBQyxRQUFRLGNBQWMsQ0FBQztBQUVyRCxJQUFBQSxRQUFPLE1BQU0scUJBQXFCLE1BQU0sS0FBSyxPQUFPLFNBQVMsS0FBSyxDQUFDLEVBQUU7QUFFckUsVUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLEtBQUs7QUFFOUIsV0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFlBQU0sUUFBUSxXQUFXLE1BQUs7QUFDN0IsYUFBSyxZQUFZLE9BQU8sR0FBRztBQUMzQixlQUFPLElBQUksTUFBTSxzQ0FBc0MsS0FBSyxLQUFLLE9BQU8sTUFBTSxPQUFPLENBQUM7TUFDdkYsR0FBRyxTQUFTO0FBRVosV0FBSyxZQUFZLElBQUksS0FBSztRQUN6QixTQUFTLENBQUMsUUFBTztBQUNoQix1QkFBYSxLQUFLO0FBQ2xCLGtCQUFRLEdBQUc7UUFDWjtRQUNBLFFBQVEsQ0FBQyxRQUFPO0FBQ2YsdUJBQWEsS0FBSztBQUNsQixpQkFBTyxHQUFHO1FBQ1g7UUFDQTtPQUNBO0FBRUQsV0FBSyxTQUFTLEtBQUssUUFBUSxLQUFLLGFBQWEsUUFBUSxDQUFDLFFBQU87QUFDNUQsWUFBSSxLQUFLO0FBQ1IsZUFBSyxZQUFZLE9BQU8sR0FBRztBQUMzQix1QkFBYSxLQUFLO0FBQ2xCLGlCQUFPLElBQUksTUFBTSxJQUFJLFdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQztRQUM3QztNQUNELENBQUM7SUFDRixDQUFDO0VBQ0Y7RUFFUSxlQUFlLEtBQWEsT0FBYTtBQUNoRCxRQUFJLElBQUksU0FBUztBQUFHO0FBQ3BCLFFBQUksSUFBSSxDQUFDLE1BQU0sT0FBUSxJQUFJLENBQUMsTUFBTTtBQUFNO0FBRXhDLFVBQU0sVUFBVSxJQUFJLGFBQWEsQ0FBQztBQUtsQyxRQUFJLFlBQVksMkJBQTJCLEtBQUssbUJBQW1CLE9BQU8sR0FBRztBQUM1RSxZQUFNLFNBQVMsdUJBQXVCLEtBQUssS0FBSztBQUNoRCxVQUFJLFFBQVE7QUFDWCxRQUFBQSxRQUFPLE1BQ04sNEJBQTRCLEtBQUssZUFDbkIsT0FBTyxJQUFJLGFBQ2QsT0FBTyxLQUFLLGlCQUNSLE9BQU8sU0FBUyxvQkFDYixPQUFPLFlBQVksR0FBRztBQUl6QyxZQUFJLE9BQU8sU0FBUyxZQUFZO0FBQy9CLHFCQUFXLE1BQU0sS0FBSyxtQkFBbUIsT0FBTSxHQUFJO0FBQ2xELGdCQUFJO0FBQ0gsaUJBQUcsTUFBTTtZQUNWLFFBQVE7WUFFUjtVQUNEO1FBQ0QsT0FBTztBQUNOLFVBQUFBLFFBQU8sTUFBTSxzREFBc0QsT0FBTyxJQUFJLE9BQU8sS0FBSyxFQUFFO1FBQzdGO01BQ0Q7QUFDQTtJQUNEO0FBRUEsUUFBSSxJQUFJLFNBQVM7QUFBSTtBQUdyQixVQUFNLE1BQU0sSUFBSSxTQUFTLElBQUksRUFBRTtBQUMvQixRQUFJLElBQUksU0FBUyxPQUFPLE1BQU07QUFBWTtBQU0xQyxRQUFJLENBQUMsS0FBSyxjQUFjLElBQUksS0FBSyxHQUFHO0FBQ25DLE1BQUFBLFFBQU8sTUFBTSxxREFBcUQsS0FBSyxFQUFFO0FBQ3pFO0lBQ0Q7QUFJQSxVQUFNLFlBQVksSUFBSSxTQUFTLEVBQUU7QUFDakMsUUFBSSxVQUFVLFNBQVM7QUFBRztBQUMxQixRQUFJLFVBQVUsQ0FBQyxNQUFNO0FBQU07QUFHM0IsVUFBTSxZQUFZLFVBQVUsQ0FBQztBQUM3QixVQUFNLGNBQWMsWUFBWSxTQUFVO0FBQzFDLFVBQU0sZ0JBQWdCLFlBQVk7QUFNbEMsUUFBSSxZQUFZO0FBQ2YsWUFBTSxNQUFNLEdBQUcsS0FBSyxJQUFJLGFBQWE7QUFDckMsWUFBTSxVQUFVLEtBQUssWUFBWSxJQUFJLEdBQUc7QUFDeEMsVUFBSSxTQUFTO0FBQ1osYUFBSyxZQUFZLE9BQU8sR0FBRztBQUMzQixjQUFNLGVBQWUsS0FBSyxnQkFBZ0IsSUFBSSxHQUFHO0FBQ2pELFFBQUFBLFFBQU8sTUFDTix1QkFBdUIsS0FBSyxRQUFRLE1BQU0sYUFBYSxDQUFDLFFBQVEsZUFBZSxjQUFjLFNBQVMsRUFBRTtBQUV6RyxZQUFJLGtCQUFrQixzQkFBc0I7QUFDM0MsVUFBQUEsUUFBTyxNQUFNLHdCQUF3QixLQUFLLEtBQUssSUFBSSxTQUFTLEtBQUssQ0FBQyxFQUFFO1FBQ3JFO0FBQ0EsYUFBSyxhQUFhLE9BQU8sZUFBZSxLQUFLLFNBQVM7QUFDdEQsZ0JBQVEsUUFBUSxHQUFHO01BQ3BCLFdBQVcsa0JBQWtCLG1CQUFtQjtBQUUvQyxhQUFLLGFBQWEsT0FBTyxlQUFlLEtBQUssU0FBUztNQUN2RDtJQUVELE9BQU87QUFFTixXQUFLLGFBQWEsT0FBTyxlQUFlLEtBQUssU0FBUztJQUN2RDtFQUNEOzs7Ozs7Ozs7Ozs7RUFhUSxhQUFhLE9BQWUsT0FBZSxLQUFhLFdBQWlCO0FBQ2hGLFVBQU0sVUFBVSxlQUFlLEtBQUs7QUFDcEMsVUFBTSxPQUFPLFVBQVUsU0FBUyxHQUFHLFVBQVUsU0FBUyxDQUFDO0FBR3ZELFVBQU0sWUFBWSxVQUFVLENBQUM7QUFDN0IsVUFBTSxNQUFNLFVBQVUsVUFBVSxTQUFTLENBQUM7QUFDMUMsVUFBTSxnQkFBZ0IsUUFBUSxNQUFNLFNBQVMsQ0FBQyxTQUFTLEtBQUssU0FBUyxLQUFLLENBQUMsUUFBUSxNQUFNLEdBQUcsQ0FBQztBQUs3RixRQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQUksQ0FBQyxLQUFLLE9BQU87QUFDaEIsUUFBQUEsUUFBTyxLQUFLLE1BQU0sS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLEVBQUU7QUFDekQ7TUFDRDtBQUNBLFVBQUk7QUFDSCxjQUFNLFdBQ0wsVUFBVSxvQkFDUCxzQkFBc0IsS0FBSyxPQUFPLEdBQUcsSUFDckMsNEJBQTRCLEtBQUssT0FBTyxHQUFHO0FBRS9DLGNBQU0sWUFBWSxLQUFLLFlBQVksSUFBSSxLQUFLLEtBQUssb0JBQUksSUFBRztBQUN4RCxjQUFNLFdBQVcsSUFBSSxJQUFvQixTQUFTO0FBRWxELG1CQUFXLEtBQUssVUFBVTtBQUN6QixnQkFBTSxXQUFXLGNBQWMsS0FBSyxPQUFPLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLO0FBRWxFLGdCQUFNLFdBQ0wsRUFBRSxXQUFXLFdBQVcsSUFDcEIsRUFBRSxXQUFXLENBQUMsS0FBSyxLQUFPLEVBQUUsV0FBVyxDQUFDLEtBQUssSUFBSyxFQUFFLFdBQVcsQ0FBQyxJQUNoRSxFQUFFLFdBQVcsQ0FBQyxLQUFLO0FBQ3hCLGdCQUFNLFlBQVksVUFBVSxJQUFJLFFBQVE7QUFDeEMsZ0JBQU0sVUFBVSxjQUFjLFVBQWEsY0FBYztBQUV6RCxtQkFBUyxJQUFJLFVBQVUsUUFBUTtBQUUvQixnQkFBTSxZQUFZLG9CQUFvQixHQUFHLEtBQUssT0FBTztBQUNyRCxjQUFJLFNBQVM7QUFDWixZQUFBQSxRQUFPLEtBQUssTUFBTSxLQUFLLE1BQU0sU0FBUyxFQUFFO0FBRXhDLGdCQUFJLEtBQUssa0JBQWtCO0FBQzFCLGtCQUFJLFNBQVMsRUFBRTtBQUNmLG9CQUFNLGFBQWEsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFLO0FBQzFDLG9CQUFJLEVBQUUsV0FBVyxFQUFFO0FBQVEseUJBQU87QUFDbEMsb0JBQUksRUFBRSxPQUFPLEVBQUU7QUFBSSx5QkFBTztBQUMxQixzQkFBTSxjQUFjLEVBQUUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUMzRCxvQkFBSSxDQUFDLGFBQWE7QUFBUyx5QkFBTztBQUNsQyxzQkFBTSxTQUFTLEVBQUUsS0FBSyxFQUFFO0FBQ3hCLHVCQUFPLFNBQVMsS0FBSyxZQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE1BQU07Y0FDckUsQ0FBQztBQUNELGtCQUFJO0FBQVkseUJBQVMsV0FBVztBQUNwQyxvQkFBTSxrQkFBa0IsY0FBYyxLQUFLLE9BQU8sRUFBRSxRQUFRLE1BQU07QUFDbEUsbUJBQUssaUJBQWlCLGVBQWU7QUFDckMsbUJBQUssaUJBQWlCLGtCQUFrQixPQUFPO1lBQ2hELE9BQU87QUFDTixjQUFBQSxRQUFPLEtBQUssZ0VBQTJELFFBQVEsRUFBRTtZQUNsRjtVQUNELE9BQU87QUFDTixZQUFBQSxRQUFPLE1BQU0sTUFBTSxLQUFLLE1BQU0sU0FBUyxFQUFFO1VBQzFDO1FBQ0Q7QUFDQSxhQUFLLFlBQVksSUFBSSxPQUFPLFFBQVE7TUFDckMsU0FBUyxHQUFHO0FBQ1gsUUFBQUEsUUFBTyxLQUFLLE1BQU0sS0FBSyxNQUFNLE9BQU8sb0JBQW9CLENBQUMsTUFBTSxhQUFhLEVBQUU7TUFDL0U7QUFDQTtJQUNEO0FBR0EsVUFBTSxVQUFVLEtBQUssYUFBYSxPQUFPLElBQUk7QUFFN0MsVUFBTSxRQUFRLFVBQVUsY0FBY0EsUUFBTyxNQUFNLEtBQUtBLE9BQU0sSUFBSUEsUUFBTyxLQUFLLEtBQUtBLE9BQU07QUFDekYsUUFBSSxTQUFTO0FBQ1osWUFBTSxNQUFNLEtBQUssTUFBTSxPQUFPLE1BQU0sYUFBYSxNQUFNLE9BQU8sRUFBRTtJQUNqRSxPQUFPO0FBQ04sWUFBTSxNQUFNLEtBQUssTUFBTSxPQUFPLE1BQU0sYUFBYSxFQUFFO0lBQ3BEO0VBQ0Q7Ozs7O0VBTVEsYUFBYSxPQUFlLE1BQVk7QUFDL0MsUUFBSSxLQUFLLFdBQVc7QUFBRyxhQUFPO0FBRzlCLFFBQUksS0FBSyxXQUFXLEdBQUc7QUFDdEIsVUFBSSxLQUFLLENBQUMsTUFBTSxHQUFNO0FBQ3JCLGVBQU87TUFDUixPQUFPO0FBQ04sZUFBTyxTQUFTLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQztNQUMvQjtJQUNEO0FBRUEsWUFBUSxPQUFPOzs7TUFHZCxLQUFLLGFBQWE7QUFDakIsY0FBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixjQUFNLE9BQU8sTUFBTSxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUMsRUFDdEMsSUFBSSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFDakUsS0FBSyxHQUFHO0FBQ1YsZUFBTyxNQUFNLEtBQUssSUFBSSxJQUFJO01BQzNCOzs7OztNQU1BLEtBQUssY0FBYztBQUNsQixZQUFJLEtBQUssV0FBVyxHQUFHO0FBQ3RCLGlCQUFPLEtBQUssQ0FBQyxNQUFNLElBQU8sV0FBVyxXQUFXLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQztRQUMvRDtBQUNBLFlBQUksS0FBSyxVQUFVLEdBQUc7QUFDckIsZ0JBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsZ0JBQU0sWUFBWSxLQUFLLENBQUM7QUFDeEIsZ0JBQU0sYUFBYSxLQUFLLFNBQVMsQ0FBQztBQUNsQyxnQkFBTSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUNoRixnQkFBTSxjQUFjLFFBQVEsUUFBUSxXQUFXLE1BQU0sU0FBUyxDQUFDO0FBQy9ELGdCQUFNLFVBQVUsUUFBUSxVQUFVLENBQUMsR0FBRztBQUN0QyxnQkFBTSxXQUFXLFdBQVcsV0FBVyxJQUFJLFdBQVcsQ0FBQyxJQUFJO0FBQzNELGdCQUFNLGNBQ0wsV0FBVyxhQUFhLFNBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7QUFDckYsZ0JBQU0sV0FBVyxjQUFjLEdBQUcsV0FBVyxLQUFLLE1BQU0sUUFBUyxDQUFDLE1BQU0sV0FBVyxNQUFNLEtBQUssVUFBVSxDQUFDO0FBQ3pHLGdCQUFNLFNBQVMsSUFBSSxNQUFNLEtBQUssQ0FBQyxJQUFJLE1BQU0sU0FBUyxDQUFDLEtBQUssV0FBVyxNQUFNLEtBQUssVUFBVSxDQUFDLENBQUM7QUFDMUYsaUJBQU8sV0FBVyxLQUFLLE1BQU0sV0FBVyxLQUFLLFFBQVEsSUFBSSxNQUFNO1FBQ2hFO0FBQ0EsZUFBTyxRQUFRLEtBQUssU0FBUyxLQUFLLENBQUM7TUFDcEM7O01BR0EsS0FBSyxpQkFBaUI7QUFFckIsWUFBSSxLQUFLLFVBQVUsR0FBRztBQUNyQixnQkFBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixnQkFBTSxZQUFZLEtBQUssQ0FBQztBQUN4QixnQkFBTSxhQUFhLEtBQUssU0FBUyxDQUFDO0FBQ2xDLGdCQUFNLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxTQUFTLEVBQUUsT0FBTyxTQUFTO0FBQ2hGLGdCQUFNLGNBQWMsUUFBUSxRQUFRLFdBQVcsTUFBTSxTQUFTLENBQUM7QUFDL0QsZ0JBQU0sV0FBVyxXQUFXLFdBQVcsSUFBSSxXQUFXLENBQUMsSUFBSTtBQUMzRCxnQkFBTSxVQUFVLFFBQVEsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTyxHQUFHO0FBQ2hFLGdCQUFNLGNBQ0wsV0FBVyxhQUFhLFNBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7QUFDckYsZ0JBQU0sV0FBVyxlQUFlLEtBQUssV0FBVyxTQUFTLEtBQUssQ0FBQztBQUMvRCxpQkFBTyxXQUFXLEtBQUssTUFBTSxXQUFXLEtBQUssUUFBUTtRQUN0RDtBQUNBLGVBQU87TUFDUjs7TUFHQSxLQUFLO01BQ0wsS0FBSyxhQUFhO0FBQ2pCLFlBQUksS0FBSyxTQUFTO0FBQUcsaUJBQU87QUFDNUIsY0FBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixjQUFNLFlBQVksS0FBSyxDQUFDO0FBQ3hCLGNBQU0sUUFBUSxLQUFLLFNBQVMsQ0FBQztBQUM3QixlQUFPLE1BQU0sS0FBSyxZQUFZLE1BQU0sU0FBUyxDQUFDLFVBQVUsTUFBTSxTQUFTLEtBQUssQ0FBQztNQUM5RTtNQUVBO0FBQ0MsZUFBTztJQUNUO0VBQ0Q7RUFFUSxPQUFPLGdCQUFnQixPQUFjO0FBQzVDLFFBQUksT0FBTyxVQUFVO0FBQVcsYUFBTyxDQUFDLFFBQVEsSUFBSSxDQUFDO0FBQ3JELFFBQUksTUFBTSxRQUFRLEtBQUs7QUFBRyxhQUFPLE1BQU0sSUFBSSxDQUFDLE1BQU0sT0FBTyxDQUFDLElBQUksR0FBSTtBQUNsRSxRQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzlCLFVBQUksUUFBUTtBQUFNLGVBQU8sQ0FBRSxTQUFTLEtBQU0sS0FBTyxTQUFTLElBQUssS0FBTSxRQUFRLEdBQUk7QUFDakYsYUFBTyxDQUFDLFFBQVEsR0FBSTtJQUNyQjtBQUNBLFVBQU0sSUFBSSxNQUFNLDRDQUE0QyxLQUFLLEVBQUU7RUFDcEU7RUFFUSxNQUFNLFlBQVksVUFBa0IsUUFBYztBQUN6RCxRQUFJLE1BQU0sS0FBSyxTQUFTLElBQUksTUFBTTtBQUNsQyxRQUFJLENBQUMsS0FBSztBQUNULFlBQU0sTUFBTSxxQkFBcUIsTUFBTTtBQUN2QyxXQUFLLFNBQVMsSUFBSSxRQUFRLEdBQUc7SUFDOUI7QUFFQSxXQUFPLE9BQU8sT0FBTztNQUNwQixPQUFPLEtBQUssQ0FBQyxLQUFNLEtBQU0sR0FBTSxXQUFXLEtBQU0sR0FBTSxLQUFNLEdBQU0sR0FBTSxHQUFHLEtBQUssR0FBTSxDQUFJLENBQUM7TUFDM0YsT0FBTyxLQUFLLFlBQVksTUFBTTtLQUM5QjtFQUNGO0VBRVEsT0FBTyxVQUFVLE1BQWM7QUFDdEMsUUFBSSxNQUFNO0FBQ1YsZUFBVyxLQUFLLE1BQU07QUFDckIsYUFBTztBQUNQLGVBQVMsSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0FBQzNCLGVBQU8sTUFBTSxTQUFVLEtBQU0sT0FBTyxJQUFLLE9BQVEsTUFBUSxPQUFPLElBQUs7TUFDdEU7SUFDRDtBQUNBLFdBQU87RUFDUjs7Ozs7Ozs7OztFQVdPLGdCQUFnQixJQUFZLE9BQWUsV0FBbUIsT0FBYztBQUNsRixVQUFNLE1BQU0sY0FBYyxLQUFLLE9BQU8sT0FBTyxXQUFXLEtBQUs7QUFDN0QsV0FBTyxLQUFLLFlBQVksSUFBSSxFQUFFLEdBQUcsSUFBSSxHQUFHO0VBQ3pDO0VBRU8sTUFBTSxZQUFZLFFBQWM7QUFDdEMsV0FBTyxLQUFLLGFBQWEsa0JBQWtCLFFBQVcsR0FBTSxRQUFXLFFBQVEsS0FBSztFQUNyRjtFQUVPLE1BQU0sY0FBYyxRQUFjO0FBQ3hDLFdBQU8sS0FBSyxhQUFhLHFCQUFxQixRQUFXLFFBQVcsUUFBVyxRQUFRLEtBQUs7RUFDN0Y7Ozs7QUc5MUJELElBQU1HLFVBQVMsbUJBQW1CLGdCQUFnQjtBQU1sRCxJQUFxQixpQkFBckIsY0FBNEMsYUFBeUI7RUFDcEU7O0VBQ0E7OztFQUlRLG9CQUFrQyxDQUFBOzs7RUFJMUMsY0FBc0I7RUFFdEIsWUFBWSxVQUFpQjtBQUM1QixVQUFNLFFBQVE7RUFDZjtFQUVBLE1BQU0sS0FBSyxRQUFvQjtBQUM5QixTQUFLLFNBQVM7QUFDZCxRQUFJLENBQUMsS0FBSyxjQUFjO0FBQ3ZCLFdBQUssZUFBZSxJQUFJLGFBQVk7SUFDckM7QUFDQSxTQUFLLGFBQWEsZUFBZSxZQUFZLHdCQUF3QjtBQUdyRSxTQUFLLGFBQWEsb0JBQW9CLENBQUMsZUFBc0I7QUFDNUQsV0FBSyxlQUFlLFVBQVU7SUFDL0IsQ0FBQztBQUlELFNBQUssYUFBWSxFQUFHLE1BQU0sQ0FBQyxNQUFLO0FBQy9CLE1BQUFBLFFBQU8sTUFBTSxxQkFBcUIsQ0FBQyxFQUFFO0lBQ3RDLENBQUM7RUFDRjs7Ozs7OztFQVFRLE1BQU0sZUFBWTtBQUN6QixJQUFBQSxRQUFPLEtBQUssOEJBQThCO0FBRTFDLFNBQUssb0JBQW9CLE1BQU0sS0FBSyxhQUFhLGdCQUFlO0FBR2hFLFFBQUk7QUFDSixRQUFJLEtBQUssa0JBQWtCLFdBQVcsR0FBRztBQUN4QyxVQUFJLEtBQUssT0FBTyxXQUFXO0FBQzFCLFFBQUFBLFFBQU8sS0FBSyxxQkFBcUIsS0FBSyxPQUFPLFNBQVMsOENBQXlDO0FBQy9GLGFBQUssYUFBYSxlQUFlLG1CQUFtQixJQUFJLEtBQUssT0FBTyxTQUFTLGFBQWE7QUFDMUY7TUFDRDtBQUNBLFlBQU0sY0FBYyxLQUFLLE9BQU87QUFDaEMsVUFBSSxDQUFDLEtBQUssT0FBTyxRQUFRLENBQUMsYUFBYTtBQUN0QyxRQUFBQSxRQUFPLEtBQUsseURBQXlEO0FBQ3JFO01BQ0Q7QUFDQSxNQUFBQSxRQUFPLEtBQUssd0VBQW1FO0FBQy9FLHVCQUFpQjtJQUNsQixPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLGNBQWMsS0FBSyxrQkFBa0IsTUFBTSxhQUFhO0FBQ3BFLGlCQUFXLEtBQUssS0FBSyxtQkFBbUI7QUFDdkMsUUFBQUEsUUFBTyxLQUFLLGFBQWEsRUFBRSxLQUFLLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFO01BQ3JFO0FBS0EsaUJBQVcsVUFBVSxLQUFLLG1CQUFtQjtBQUM1QyxhQUFLLGFBQWEsZ0JBQWdCLE9BQU8sRUFBRTtNQUM1QztBQUdBLGlCQUFXLFVBQVUsS0FBSyxtQkFBbUI7QUFDNUMsWUFBSTtBQUNILGdCQUFNLFdBQVcsTUFBTSxLQUFLLGFBQWEsdUJBQXVCLE9BQU8sRUFBRTtBQUN6RSxpQkFBTyxlQUFlO0FBQ3RCLFVBQUFBLFFBQU8sS0FBSyxPQUFPLE9BQU8sRUFBRSxjQUFjLFFBQVEsV0FBVyxPQUFPLGFBQWEsRUFBRTtRQUNwRixTQUFTLEdBQUc7QUFDWCxVQUFBQSxRQUFPLEtBQUssT0FBTyxPQUFPLEVBQUUsNkJBQTZCLENBQUMsRUFBRTtBQUM1RCxpQkFBTyxlQUFlO1FBQ3ZCO01BQ0Q7QUFFQSx1QkFBaUIsYUFBYSxLQUFLLFFBQVEsS0FBSyxpQkFBaUI7QUFFakUsVUFBSSxDQUFDLGtCQUFrQixLQUFLLE9BQU8sV0FBVztBQUM3QyxRQUFBQSxRQUFPLEtBQUsscUJBQXFCLEtBQUssT0FBTyxTQUFTLHNEQUFpRDtBQUN2RyxhQUFLLGFBQWEsZUFBZSxtQkFBbUIsSUFBSSxLQUFLLE9BQU8sU0FBUyxhQUFhO0FBQzFGO01BQ0Q7SUFDRDtBQUdBLFNBQUssVUFBVSxjQUFjO0FBSTdCLFVBQU0sYUFBYSxLQUFLO0FBQ3hCLFVBQU0sS0FBSyxvQkFBb0IsSUFBSSxVQUFVO0FBRzdDLFNBQUssY0FBYTtBQUNsQixTQUFLLGdCQUFlO0FBQ3BCLFNBQUssMEJBQXlCO0FBQzlCLFNBQUsscUJBQW9CO0FBRXpCLElBQUFBLFFBQU8sS0FBSywyQkFBMkI7RUFDeEM7O0VBR0EsTUFBTSxVQUFPO0FBQ1osU0FBSyxjQUFjLE1BQUs7QUFDeEIsSUFBQUEsUUFBTyxNQUFNLFNBQVM7RUFDdkI7RUFFQSxNQUFNLGNBQWMsUUFBb0I7QUFDdkMsVUFBTSxlQUFlLEtBQUs7QUFDMUIsU0FBSyxTQUFTO0FBQ2QsVUFBTSxpQkFBaUIsYUFBYSxRQUFRLEtBQUssaUJBQWlCO0FBQ2xFLFNBQUssVUFBVSxjQUFjO0FBSTdCLFNBQUsscUJBQW9CO0FBRXpCLFVBQU0sVUFBVSxLQUFLO0FBSXJCLFVBQU0sS0FBSyxvQkFBb0IsY0FBYyxPQUFPO0FBR3BELFNBQUssY0FBYTtBQUNsQixTQUFLLGdCQUFlO0FBQ3BCLFNBQUssMEJBQXlCO0FBQzlCLFNBQUsscUJBQW9CO0VBQzFCOzs7Ozs7Ozs7Ozs7RUFhUSxNQUFNLG9CQUFvQixjQUFzQixTQUFlO0FBQ3RFLFFBQUksQ0FBQyxTQUFTO0FBQ2IsVUFBSTtBQUFjLGFBQUssYUFBYSxhQUFhLFlBQVk7QUFDN0Q7SUFDRDtBQUVBLFFBQUksS0FBSyxPQUFPLFdBQVc7QUFFMUIsWUFBTSxTQUFTLEtBQUssa0JBQWtCLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxLQUFLLE9BQU8sU0FBUztBQUNqRixVQUFJLENBQUMsUUFBUTtBQUNaLFFBQUFBLFFBQU8sS0FBSyxlQUFlLEtBQUssT0FBTyxTQUFTLHlEQUFvRDtBQUNwRyxZQUFJO0FBQWMsZUFBSyxhQUFhLGFBQWEsWUFBWTtBQUM3RDtNQUNEO0FBRUEsVUFBSSxnQkFBZ0IsaUJBQWlCLFNBQVM7QUFDN0MsYUFBSyxhQUFhLGFBQWEsWUFBWTtNQUM1QztBQUNBLFlBQU0sZ0JBQWdCLEtBQUssYUFBYSxtQkFBbUIsT0FBTztBQUNsRSxVQUFJLENBQUMsZUFBZTtBQUNuQixhQUFLLGFBQWEsZ0JBQWdCLE9BQU87TUFDMUM7QUFDQSxVQUFJLFlBQVksZ0JBQWdCLENBQUMsZUFBZTtBQUMvQyxjQUFNLEtBQUssNkJBQTZCLE9BQU8sT0FBTyxPQUFPO01BQzlEO0FBQ0EsV0FBSyxhQUFhLGVBQWUsSUFBSSxTQUFTLE9BQU8sS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUN6RTtJQUNEO0FBR0EsVUFBTSxjQUFjLE9BQU8sS0FBSyxPQUFPLGVBQWUsRUFBRTtBQUN4RCxVQUFNLGlCQUFpQixLQUFLLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUUxRSxRQUFJLGdCQUFnQjtBQUNuQixVQUFJLGVBQWUsVUFBVSxhQUFhO0FBQ3pDLFlBQUksZ0JBQWdCLGlCQUFpQjtBQUFTLGVBQUssYUFBYSxhQUFhLFlBQVk7QUFDekYsY0FBTSxnQkFBZ0IsS0FBSyxhQUFhLG1CQUFtQixPQUFPO0FBQ2xFLFlBQUksQ0FBQyxlQUFlO0FBQ25CLGVBQUssYUFBYSxnQkFBZ0IsT0FBTztRQUMxQztBQUNBLFlBQUksWUFBWSxnQkFBZ0IsQ0FBQyxlQUFlO0FBQy9DLGdCQUFNLEtBQUssNkJBQTZCLGFBQWEsT0FBTztRQUM3RDtBQUNBLGFBQUssYUFBYSxlQUFlLElBQUksU0FBUyxXQUFXLE1BQU0sT0FBTyxFQUFFO01BQ3pFLE9BQU87QUFDTixRQUFBQSxRQUFPLE1BQ04sMEJBQTBCLFdBQVcsMkNBQTJDLGVBQWUsS0FBSyxRQUFRLE9BQU8sMEJBQXFCO0FBRXpJLGFBQUssYUFBYSxhQUFhLE9BQU87QUFDdEMsYUFBSyxhQUNKLGVBQWUsbUJBQ2YsNEJBQTRCLFdBQVcsU0FBUyxlQUFlLEtBQUssRUFBRTtNQUV4RTtBQUNBO0lBQ0Q7QUFHQSxJQUFBQSxRQUFPLEtBQUssR0FBRyxPQUFPLHdDQUFtQztBQUN6RCxRQUFJLGdCQUFnQixpQkFBaUI7QUFBUyxXQUFLLGFBQWEsYUFBYSxZQUFZO0FBQ3pGLFNBQUssYUFBYSxhQUFhLE9BQU87QUFFdEMsVUFBTSxTQUFTLE1BQU0sS0FBSyxhQUFhLFlBQVksT0FBTztBQUMxRCxRQUFJLENBQUMsUUFBUTtBQUNaLE1BQUFBLFFBQU8sTUFBTSwwQkFBMEIsT0FBTywwQkFBcUI7QUFDbkUsV0FBSyxhQUFhLGVBQWUsZ0JBQWdCLG1CQUFtQixPQUFPLEVBQUU7SUFDOUUsV0FBVyxPQUFPLFVBQVUsYUFBYTtBQUN4QyxNQUFBQSxRQUFPLE1BQ04sMEJBQTBCLFdBQVcsMkNBQTJDLE9BQU8sS0FBSyxRQUFRLE9BQU8sMEJBQXFCO0FBRWpJLFdBQUssYUFDSixlQUFlLG1CQUNmLDRCQUE0QixXQUFXLFNBQVMsT0FBTyxLQUFLLEVBQUU7SUFFaEUsT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSyxrQkFBa0IsT0FBTyxLQUFLLE9BQU8sT0FBTyxFQUFFO0FBQzFELFdBQUssYUFBYSxnQkFBZ0IsT0FBTztBQUN6QyxZQUFNLEtBQUssNkJBQTZCLGFBQWEsT0FBTztBQUM1RCxXQUFLLGFBQWEsZUFBZSxJQUFJLFNBQVMsT0FBTyxLQUFLLE1BQU0sT0FBTyxFQUFFO0lBQzFFO0VBQ0Q7Ozs7O0VBTVEsTUFBTSw2QkFBNkIsT0FBZSxJQUFVO0FBQ25FLFFBQUk7QUFDSCxZQUFNLEtBQUssYUFBYSxtQkFBbUIsRUFBRTtBQUU3QyxVQUFJLENBQUMsZ0JBQWdCLEtBQUssR0FBRztBQUc1QixRQUFBQSxRQUFPLEtBQUssNkJBQTZCLEtBQUssc0RBQWlEO0FBQy9GO01BQ0Q7SUFDRCxTQUFTLEdBQUc7QUFDWCxNQUFBQSxRQUFPLEtBQUssaUNBQWlDLEVBQUUsS0FBSyxDQUFDLEVBQUU7SUFDeEQ7RUFDRDs7RUFHUSxVQUFVLE9BQWE7QUFDOUIsU0FBSyxjQUFjO0FBQ25CLFVBQU0sU0FBUyxnQkFBZ0IsS0FBSztBQUNwQyxRQUFJLENBQUMsUUFBUTtBQUNaLE1BQUFBLFFBQU8sS0FBSyxVQUFVLEtBQUssK0JBQStCO0FBQzFELFdBQUssYUFBYSxTQUFTLE9BQU8sQ0FBQSxDQUFFO0FBQ3BDO0lBQ0Q7QUFFQSxVQUFNLFVBQVUsTUFBTSxRQUFRLE9BQU8sU0FBUyxJQUFJLE9BQU8sWUFBWSxDQUFBO0FBRXJFLFNBQUssYUFBYSxTQUFTLE9BQU8sT0FBTztBQUN6QyxRQUFJLFFBQVEsV0FBVyxHQUFHO0FBQ3pCLE1BQUFBLFFBQU8sS0FBSywrQkFBK0IsS0FBSyw2Q0FBd0M7SUFDekYsT0FBTztBQUNOLE1BQUFBLFFBQU8sTUFBTSxVQUFVLFFBQVEsTUFBTSx1QkFBdUIsS0FBSyxnQkFBZ0IsT0FBTyxTQUFTLEVBQUU7SUFDcEc7RUFDRDtFQUVBLGtCQUFlO0FBQ2QsV0FBTyxnQkFBZ0IsS0FBSyxpQkFBaUI7RUFDOUM7O0VBR0EsSUFBSSxPQUFJO0FBQ1AsV0FBTyxZQUFZLEtBQUssUUFBUSxLQUFLLGlCQUFpQjtFQUN2RDs7RUFHQSxJQUFJLFVBQU87QUFDVixXQUFPLEtBQUs7RUFDYjtFQUVBLGdCQUFhO0FBQ1osa0JBQWMsSUFBSTtFQUNuQjtFQUVBLGtCQUFlO0FBQ2Qsb0JBQWdCLElBQUk7RUFDckI7RUFFQSw0QkFBeUI7QUFDeEIsOEJBQTBCLElBQUk7RUFDL0I7RUFFQSx1QkFBb0I7QUFDbkIseUJBQXFCLElBQUk7RUFDMUI7OyIsCiAgIm5hbWVzIjogWyJwYXRoIiwgIkluc3RhbmNlU3RhdHVzIiwgIlJlZ2V4IiwgInBhdGgiLCAiZnMiLCAibG9nZ2VyIiwgImlkQWRkT3B0IiwgImZzIiwgImxvZ2dlciIsICJkZXZpY2VzRm9sZGVyIiwgInBhdGgiLCAiZGdyYW0iLCAib3MiLCAibG9nZ2VyIiwgImRncmFtIiwgImxvZ2dlciIsICJzb2NrIiwgImRncmFtIiwgImxvZ2dlciIsICJkZ3JhbSIsICJvcyIsICJsb2dnZXIiXQp9Cg==
