import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}
function combineRgb(r, g, b, a) {
  let colorNumber = (r & 255) << 16 | (g & 255) << 8 | b & 255;
  if (a && a >= 0 && a < 1) {
    colorNumber += 16777216 * Math.round(255 * (1 - a));
  }
  return colorNumber;
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path3, args) {
    this.#context.oscSend(host, port, path3, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/config.js
import fs from "fs";
import path from "path";
var logger = createModuleLogger("Config");
function resolveDevicesFolder() {
  const primaryPath = path.join(import.meta.dirname, "../devices");
  const fallbackPath = path.join(import.meta.dirname, "./devices");
  if (fs.existsSync(primaryPath)) {
    logger.debug(`Using devices folder: ${primaryPath}`);
    return primaryPath;
  }
  if (fs.existsSync(fallbackPath)) {
    logger.warn(`Primary devices folder not found, using fallback: ${fallbackPath}`);
    return fallbackPath;
  }
  const errorMsg = `Devices folder not found!
Tried:
  - ${primaryPath}
  - ${fallbackPath}
Module cannot continue without device schemas.`;
  logger.error(errorMsg);
  throw new Error(errorMsg);
}
var devicesFolder = resolveDevicesFolder();
var deviceSchemasCache = null;
function getDevicesFolder() {
  return devicesFolder;
}
function loadDeviceSchemas() {
  const schemas = {};
  try {
    const files = fs.readdirSync(devicesFolder).filter((f) => f.endsWith(".json"));
    for (const f of files) {
      const fullPath = path.join(devicesFolder, f);
      const json = JSON.parse(fs.readFileSync(fullPath, "utf8"));
      if (json?.model) {
        schemas[String(json.model)] = json;
      }
    }
    logger.debug(`Loaded ${Object.keys(schemas).length} device schemas into cache`);
  } catch (e) {
    logger.error(`Failed to load device schemas: ${e}`);
  }
  return schemas;
}
function getDeviceSchemas() {
  if (!deviceSchemasCache) {
    deviceSchemasCache = loadDeviceSchemas();
  }
  return deviceSchemasCache;
}
function getDeviceSchema(model) {
  const schemas = getDeviceSchemas();
  return schemas[model];
}
function reloadDeviceSchemas() {
  logger.info("Reloading device schemas from disk...");
  deviceSchemasCache = loadDeviceSchemas();
}
function loadAvailableModels() {
  const schemas = getDeviceSchemas();
  return Object.keys(schemas).sort();
}
function GetConfigFields(discoveredDevices = []) {
  const models = loadAvailableModels();
  const deviceChoices = [
    { id: "", label: "Manual (enter IP + model below)" },
    ...discoveredDevices.map((d) => ({
      id: d.mac ?? "",
      label: `Model ${d.model} [${d.mac}] @ ${d.ip}`
    }))
  ];
  return [
    // ── Device selection dropdown ────────────────────────────────────────
    // Stores the MAC so re-discovery with a changed IP still matches.
    {
      type: "dropdown",
      id: "deviceMac",
      label: "Device",
      width: 8,
      default: "",
      choices: deviceChoices,
      tooltip: "Select an auto-discovered Studio Technologies device, or choose Manual to enter an IP address."
    },
    // ── Manual IP entry — only visible in manual mode ────────────────────
    {
      type: "textinput",
      id: "host",
      label: "Target IP",
      width: 8,
      default: "",
      regex: Regex.IP,
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Enter the IP address of the device manually."
    },
    // ── Manual model selector — only visible in manual mode ──────────────
    {
      type: "dropdown",
      id: "activeModel",
      label: "Active Device Model",
      width: 8,
      default: models[0] ?? "",
      choices: models.map((model) => ({
        id: model,
        label: `Model ${model}`
      })),
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Select which Studio Technologies model is active for actions and feedbacks."
    },
    // ── Dev Mode ─────────────────────────────────────────────────────────
    {
      type: "checkbox",
      id: "devMode",
      label: "Dev Mode",
      width: 12,
      default: false,
      tooltip: "Enable to allow parsing of ST Devices not currently supported"
    }
  ];
}
function resolveHost(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    return device?.ip ?? "";
  }
  return String(config.host ?? "");
}
function resolveModel(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    logger.debug(`resolveModel: deviceMac="${config.deviceMac}", found device: ${device?.model ?? "none"}`);
    return device?.model ?? "";
  }
  logger.debug(`resolveModel: manual mode, activeModel="${config.activeModel}"`);
  return String(config.activeModel ?? "");
}

// dist/variables.js
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions({
    model: { name: "Device Model Number" },
    modelName: { name: "Device Model Name (Full Description)" },
    manufacturer: { name: "Device Manufacturer" },
    firmware: { name: "Device Firmware Version" },
    danteFW: { name: "Dante Module Firmware Version" },
    mac: { name: "Device MAC Address" },
    ip: { name: "Device IP Address" }
  });
}
var CLEARED_VARIABLES = {
  model: "",
  modelName: "",
  manufacturer: "",
  firmware: "",
  danteFW: "",
  mac: "",
  ip: ""
};
function UpdateVariableValues(self) {
  const currentHost = self.host;
  if (!currentHost || !self.stController.isDeviceAuthorized(currentHost)) {
    self.setVariableValues(CLEARED_VARIABLES);
    return;
  }
  const device = self.devices.find((d) => d.ip === currentHost);
  if (device) {
    self.setVariableValues({
      model: device.model || "",
      modelName: device.modelName || "",
      manufacturer: device.manufacturer || "",
      firmware: device.firmwareMain || "",
      danteFW: device.danteFirmware || "",
      mac: device.mac || "",
      ip: device.ip
    });
  } else {
    self.setVariableValues({
      ...CLEARED_VARIABLES,
      ip: currentHost
    });
  }
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  // function (context, props) {
  // 	return {
  // 		updatedConfig: null,
  // 		updatedActions: [],
  // 		updatedFeedbacks: [],
  // 	}
  // },
];

// dist/types.js
var CMD_GET_FIRMWARE = 0;
var CMD_MIC_PRE = 2;
var CMD_BUS_GET = 3;
var CMD_BUS_SET = 4;
var CMD_HEADPHONE = 5;
var CMD_BUTTON_MODE = 7;
var CMD_SYSTEM = 9;
var CMD_GET_ALL_SETTINGS = 10;
var CMD_SETTINGS_PUSH = 11;
var CMD_DEV_SPEC = 13;
var CMD_RESET_DEVICE = 14;
var CMD_GLOBAL_MIC_KILL = 16;
var CMD_MIC_PRE_BUS = 18;
var CMD_CHANNEL = 20;
function getCommandName(cmdId) {
  switch (cmdId) {
    case CMD_GET_FIRMWARE:
      return "Get Firmware Version";
    case CMD_MIC_PRE:
      return "Mic Preamp";
    case CMD_BUS_GET:
      return "Heartbeat";
    case CMD_BUS_SET:
      return "Set Bus Setting";
    case CMD_HEADPHONE:
      return "Headphone Control";
    case CMD_BUTTON_MODE:
      return "Button Mode";
    case CMD_SYSTEM:
      return "System Command";
    case CMD_GET_ALL_SETTINGS:
      return "Request All Settings";
    case CMD_SETTINGS_PUSH:
      return "Settings Push";
    case CMD_MIC_PRE_BUS:
      return "Mic/Pre Bus";
    case CMD_DEV_SPEC:
      return "Device Setting";
    case CMD_CHANNEL:
      return "Channel Setting";
    case CMD_RESET_DEVICE:
      return "Reset Device";
    case CMD_GLOBAL_MIC_KILL:
      return "Global Mic Kill";
    default:
      return `cmd_0x${cmdId.toString(16).padStart(2, "0")}`;
  }
}
function makeSettingId(model, cmdId, settingId, busCh) {
  const cmd = typeof cmdId === "number" ? cmdId.toString(16) : cmdId;
  const id = typeof settingId === "number" ? settingId.toString(16) : settingId;
  if (busCh !== void 0) {
    const ch = typeof busCh === "number" ? busCh.toString(16) : busCh;
    return `${model}_${cmd}_${ch}_${id}`;
  }
  return `${model}_${cmd}_${id}`;
}
function toHex(value, padLength = 2) {
  return `0x${value.toString(16).padStart(padLength, "0")}`;
}
function bytesToHex(bytes) {
  return `0x${Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}
function formatRgbColor(r, g, b) {
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}
function parseSettingId(id) {
  const [model, cmdIdStr, idStr] = id.split("_");
  return {
    model,
    cmdId: parseInt(cmdIdStr, 16),
    baseId: parseInt(idStr, 16)
  };
}
function modelDistance(modelA, modelB) {
  const na = parseInt(modelA.replace(/\D/g, ""), 10);
  const nb = parseInt(modelB.replace(/\D/g, ""), 10);
  if (Number.isNaN(na) || Number.isNaN(nb))
    return Infinity;
  return Math.abs(na - nb);
}
function getNormalizedSchemas(schemasRaw) {
  const normalized = {};
  for (const [model, json] of Object.entries(schemasRaw)) {
    normalized[model] = {
      model: json.model,
      cmdSchema: Array.isArray(json.cmdSchema) ? json.cmdSchema : []
    };
  }
  return normalized;
}
function findActionForSetting(schemas, model, cmdId, settingId) {
  const schema = schemas[model];
  if (!schema || !Array.isArray(schema.cmdSchema))
    return void 0;
  let action = schema.cmdSchema.find((s) => s.cmd_id === cmdId && s.id === settingId);
  if (!action) {
    action = schema.cmdSchema.find((s) => {
      if (s.cmd_id !== cmdId)
        return false;
      const idAddOption = s.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const offset = settingId - s.id;
      return idAddOption.choices.some((c) => c.id === offset);
    });
  }
  return action;
}

// dist/build-commands.js
function buildOption(o) {
  const base = {
    type: o.type,
    id: o.id,
    label: o.label,
    default: o.default,
    tooltip: o.tooltip
  };
  switch (o.type) {
    case "dropdown":
      return { ...base, choices: o.choices ?? [] };
    case "number":
      return {
        ...base,
        min: o.min,
        max: o.max,
        step: o.step ?? 1,
        range: true
      };
    case "checkbox":
      return { ...base, default: o.default ?? false };
    case "static-text":
      return { ...base, value: o.value ?? "" };
    case "textinput":
    case "colorpicker":
    default:
      return base;
  }
}
function buildActions() {
  const schemas = getDeviceSchemas();
  const actions = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const a of cmdSchema) {
      if (a.readonly === true)
        continue;
      const actionId = makeSettingId(model, a.cmd_id, a.id);
      const options = (a.options ?? []).map(buildOption);
      const action = {
        name: `[Model${model}] ${a.name}`,
        options,
        callback: async () => {
        }
      };
      actions[actionId] = action;
    }
  }
  return actions;
}
function isOnOffDropdown(setting) {
  const valueOpt = setting.options?.find((o) => o.id === "value");
  if (!valueOpt || valueOpt.type !== "dropdown" || !Array.isArray(valueOpt.choices))
    return false;
  if (valueOpt.choices.length !== 2)
    return false;
  const labels = valueOpt.choices.map((c) => String(c.label).toLowerCase());
  return labels.includes("off") && labels.includes("on");
}
function buildFeedbacks() {
  const schemas = getDeviceSchemas();
  const feedbacks = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const setting of cmdSchema) {
      if (setting.writeonly === true)
        continue;
      const baseFeedbackId = makeSettingId(model, setting.cmd_id, setting.id);
      const allOptions = (setting.options ?? []).map(buildOption);
      const valueOptions = allOptions.filter((opt) => opt.id !== "value");
      valueOptions.push({
        type: "checkbox",
        id: "showLabel",
        label: "Use Label for Value",
        default: false,
        tooltip: "Return the label text instead of the numeric value"
      });
      const valueFeedback = {
        type: "value",
        name: `[Model${model}] ${setting.name}`,
        options: valueOptions,
        callback: () => {
          return 0;
        }
      };
      if (isOnOffDropdown(setting)) {
        const boolFeedbackId = `${baseFeedbackId}_bool`;
        const boolOptions = allOptions.filter((opt) => opt.id !== "value");
        const boolFeedback = {
          type: "boolean",
          name: `[Model${model}] ${setting.name} \u2014 Is On`,
          defaultStyle: {
            bgcolor: combineRgb(0, 200, 0),
            color: combineRgb(0, 0, 0)
          },
          options: boolOptions,
          callback: () => {
            return false;
          }
        };
        feedbacks[boolFeedbackId] = boolFeedback;
      } else {
        feedbacks[baseFeedbackId] = valueFeedback;
      }
    }
  }
  return feedbacks;
}

// dist/actions.js
import path2 from "path";

// dist/settingsParser.js
import fs2 from "fs";
var logger2 = createModuleLogger("SettingsParser");
function getModelConfig(model) {
  const rgbIds = /* @__PURE__ */ new Set();
  let sectioned = false;
  try {
    const json = getDeviceSchema(model);
    if (!json) {
      return { sectioned, rgbIds };
    }
    sectioned = json.sectioned ?? false;
    for (const action of json.cmdSchema || []) {
      const hasColorpicker = action.options?.some((opt) => opt.type === "colorpicker");
      if (hasColorpicker) {
        rgbIds.add(action.id);
        const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
        if (idAddOption?.choices) {
          for (const choice of idAddOption.choices) {
            if (typeof choice.id === "number") {
              rgbIds.add(action.id + choice.id);
            }
          }
        }
      }
    }
  } catch (_err) {
  }
  return { sectioned, rgbIds };
}
function extractStPayloadIndex(buf) {
  const sigIndex = buf.indexOf(Buffer.from("Studio-T"));
  if (sigIndex < 0)
    throw new Error("No Studio-T signature in packet");
  const payloadIndex = sigIndex + 8;
  if (buf[payloadIndex] !== 90) {
    throw new Error(`Expected 0x5A after Studio-T, found ${buf[payloadIndex].toString(16)}`);
  }
  return payloadIndex;
}
function parseFlatIdValSequence(block, rgbIds = /* @__PURE__ */ new Set()) {
  let p = 0;
  const out = [];
  while (p < block.length) {
    const id = block[p];
    if (p + 1 >= block.length)
      break;
    if (rgbIds.has(id) && p + 3 < block.length) {
      out.push({
        cmd_id: CMD_DEV_SPEC,
        id,
        valueBytes: [block[p + 1], block[p + 2], block[p + 3]]
      });
      p += 4;
      continue;
    }
    out.push({ cmd_id: CMD_DEV_SPEC, id, valueBytes: [block[p + 1]] });
    p += 2;
  }
  return out;
}
function parseGetAllSettings_flat(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  const blockLen = buf[idx + 2];
  const start = idx + 3;
  const end = start + blockLen;
  if (end > buf.length)
    throw new Error("Invalid block length");
  const { rgbIds } = getModelConfig(model);
  return parseFlatIdValSequence(buf.subarray(start, end), rgbIds);
}
function parseGetAllSettings_sectioned(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  let p = cmdId === CMD_GET_ALL_SETTINGS ? idx + 3 : idx + 2;
  const end = buf.length - 1;
  const out = [];
  const { rgbIds } = getModelConfig(model);
  const commandsWithBusCh = [CMD_BUS_SET, CMD_MIC_PRE_BUS, CMD_CHANNEL];
  const commandsRawValue = [CMD_MIC_PRE];
  while (p + 2 < end) {
    const cmdLen = buf[p];
    const sectionCmdId = buf[p + 1];
    const sectionEnd = p + 1 + cmdLen;
    if (sectionEnd > end)
      break;
    const hasBusCh = commandsWithBusCh.includes(sectionCmdId);
    const isRawValue = commandsRawValue.includes(sectionCmdId);
    let busCh;
    let dataLen;
    let q;
    if (isRawValue) {
      busCh = buf[p + 2];
      const rawBytes = buf.subarray(p + 3, sectionEnd);
      const schema = getDeviceSchema(model);
      const micPreEntries = (schema?.cmdSchema ?? []).filter((a) => (a.cmd_id === CMD_MIC_PRE || a.cmd_id === CMD_MIC_PRE_BUS) && a.busCh !== void 0).sort((a, b) => a.id - b.id);
      for (let i = 0; i < rawBytes.length; i++) {
        const entry = micPreEntries[i];
        if (entry) {
          out.push({ cmd_id: entry.cmd_id, id: entry.id, busCh, valueBytes: [rawBytes[i]] });
        }
      }
      p = sectionEnd;
      continue;
    } else if (hasBusCh) {
      busCh = buf[p + 2];
      dataLen = buf[p + 3];
      q = p + 4;
    } else {
      dataLen = buf[p + 2];
      q = p + 3;
    }
    const qEnd = q + dataLen;
    const qStart = q;
    while (q + 1 < qEnd) {
      const id = buf[q];
      let valueBytes;
      if (rgbIds.has(id) && q + 3 < qEnd) {
        valueBytes = [buf[q + 1], buf[q + 2], buf[q + 3]];
        q += 4;
      } else {
        valueBytes = [buf[q + 1]];
        q += 2;
      }
      const setting = {
        cmd_id: sectionCmdId,
        id,
        valueBytes
      };
      if (busCh !== void 0) {
        setting.busCh = busCh;
      }
      out.push(setting);
    }
    if (q === qStart && sectionEnd > p + 3) {
      let pos = hasBusCh ? p + 3 : p + 2;
      let posId = 0;
      while (pos < sectionEnd) {
        const setting = { cmd_id: sectionCmdId, id: posId++, valueBytes: [buf[pos++]] };
        if (busCh !== void 0)
          setting.busCh = busCh;
        out.push(setting);
      }
    }
    p = sectionEnd;
  }
  return out;
}
function parseSettingsResponse(model, buf) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error(`Not a settings block (cmdId=0x${cmdId.toString(16)})`);
  }
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function formatParsedSetting(setting, actions) {
  let action = actions.find((a) => a.cmd_id === setting.cmd_id && a.id === setting.id);
  if (!action) {
    const baseAction = actions.find((a) => {
      if (a.cmd_id !== setting.cmd_id)
        return false;
      const idAddOption = a.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const channelOffset = setting.id - a.id;
      return idAddOption.choices.some((c) => c.id === channelOffset);
    });
    if (baseAction) {
      action = baseAction;
    }
  }
  const cmdHex = toHex(setting.cmd_id);
  const idHex = toHex(setting.id);
  const valHex = bytesToHex(setting.valueBytes);
  const valDec = setting.valueBytes.length === 3 ? formatRgbColor(setting.valueBytes[0], setting.valueBytes[1], setting.valueBytes[2]) : setting.valueBytes.length === 1 ? setting.valueBytes[0] : setting.valueBytes.join(",");
  const busChStr = setting.busCh !== void 0 ? ` ch:${setting.busCh}` : "";
  const prefix = `cmd:${cmdHex}${busChStr} id:${idHex} val:${valHex}`;
  if (action) {
    let name = action.name;
    if (setting.busCh !== void 0) {
      name = `${name} Ch${setting.busCh + 1}`;
    } else {
      const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
      if (idAddOption?.choices) {
        const channelOffset = setting.id - action.id;
        const idAddChoice = idAddOption.choices.find((c) => c.id === channelOffset);
        if (idAddChoice) {
          name = `${name} ${idAddChoice.label}`;
        }
      }
    }
    const valueOption = action.options?.find((opt) => opt.id === "value");
    if (valueOption?.choices && setting.valueBytes.length === 1) {
      const choice = valueOption.choices.find((c) => c.id === setting.valueBytes[0]);
      if (choice) {
        return `${prefix} | ${name}: ${choice.label} (${valDec})`;
      }
    }
    return `${prefix} | ${name}: ${valDec}`;
  }
  return `${prefix} | Unknown Setting`;
}
function parseGetAllSettingsWithDetection(model, buf) {
  const schema = getDeviceSchema(model);
  const declaredSectioned = schema?.sectioned;
  if (declaredSectioned !== void 0) {
    const settings = declaredSectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
    return { settings, detectedSectioned: null };
  }
  let flatSettings = [];
  let sectionedSettings = [];
  try {
    flatSettings = parseGetAllSettings_flat(buf, model);
  } catch (e) {
    logger2.debug(`Flat parser failed: ${e}`);
  }
  try {
    sectionedSettings = parseGetAllSettings_sectioned(buf, model);
  } catch (e) {
    logger2.debug(`Sectioned parser failed: ${e}`);
  }
  if (sectionedSettings.length > flatSettings.length) {
    logger2.info(`Auto-detected SECTIONED format (sectioned=${sectionedSettings.length} vs flat=${flatSettings.length})`);
    return { settings: sectionedSettings, detectedSectioned: true };
  } else if (flatSettings.length > 0) {
    logger2.info(`Auto-detected FLAT format (flat=${flatSettings.length} vs sectioned=${sectionedSettings.length})`);
    return { settings: flatSettings, detectedSectioned: false };
  } else {
    logger2.warn(`Warning: Both parsers returned 0 settings for model ${model}`);
    return { settings: [], detectedSectioned: null };
  }
}
function parseGetAllSettingsForModel(model, buf) {
  const { sectioned } = getModelConfig(model);
  return sectioned ? parseGetAllSettings_sectioned(buf, model) : parseGetAllSettings_flat(buf, model);
}
function valueBytesToOption(valueBytes) {
  if (valueBytes.length === 1) {
    return { id: "value", label: "Value", type: "number", default: valueBytes[0] };
  }
  if (valueBytes.length === 3) {
    const [r, g, b] = valueBytes;
    return {
      id: "value",
      label: "Color",
      type: "colorpicker",
      default: formatRgbColor(r, g, b)
    };
  }
  return { id: "value", label: "Value", type: "raw", default: [...valueBytes] };
}
function updateModelJsonFromSettings(modelJson, parsed, allModels) {
  const out = structuredClone(modelJson);
  if (!out.cmdSchema) {
    out.cmdSchema = [];
  }
  const candidates = Object.values(allModels).filter((m) => m.model !== modelJson.model).sort((a, b) => modelDistance(modelJson.model, a.model) - modelDistance(modelJson.model, b.model));
  logger2.info(`Updating model: ${modelJson.model}`);
  logger2.debug(`Candidates for inference: ${candidates.map((c) => c.model).join(", ")}`);
  const idAddDeferRanges = /* @__PURE__ */ new Map();
  for (const c of candidates) {
    for (const baseEntry of c.cmdSchema ?? []) {
      const idAddOpt = baseEntry.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        continue;
      const baseId = baseEntry.id;
      const cmdId = baseEntry.cmd_id;
      const key = `${cmdId}_${baseId}`;
      if (idAddDeferRanges.has(key))
        continue;
      const parsedOffsets = parsed.filter((p) => p.cmd_id === cmdId && p.id > baseId).map((p) => p.id - baseId).sort((a, b) => a - b);
      let maxSeq = 0;
      for (const off of parsedOffsets) {
        if (off === maxSeq + 1)
          maxSeq = off;
        else if (off > maxSeq + 1)
          break;
      }
      if (maxSeq > 0) {
        idAddDeferRanges.set(key, maxSeq);
        logger2.debug(`idAdd defer range for cmd_id=${toHex(cmdId)} base_id=${toHex(baseId)}: offsets 1\u2013${maxSeq}`);
      }
    }
  }
  const busChSeen = /* @__PURE__ */ new Map();
  for (const { cmd_id, id, busCh } of parsed) {
    if (busCh === void 0)
      continue;
    const key = `${cmd_id}_${id}`;
    if (!busChSeen.has(key))
      busChSeen.set(key, /* @__PURE__ */ new Set());
    busChSeen.get(key).add(busCh);
  }
  for (const { cmd_id, id, busCh, valueBytes } of parsed) {
    const existingExact = out.cmdSchema.find((a) => a.cmd_id === cmd_id && a.id === id);
    if (existingExact) {
      const opt = existingExact.options?.find((o) => o.id === "value");
      if (opt)
        opt.default = valueBytesToOption(valueBytes).default;
      const seenBusChValues = busChSeen.get(`${cmd_id}_${id}`);
      if (seenBusChValues && seenBusChValues.size > 0) {
        const maxBusCh = Math.max(...seenBusChValues);
        const hasBusChOption = existingExact.options?.some((o) => o.id === "busCh");
        if (maxBusCh === 0 && existingExact.busCh === void 0 && !hasBusChOption) {
          existingExact.busCh = 0;
          logger2.info(`Synced busCh=0 onto existing entry cmd_id=${toHex(cmd_id)} id=${toHex(id)}`);
        }
      }
      continue;
    }
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt = a.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        return false;
      if (id <= a.id)
        return false;
      const offset = id - a.id;
      return candidates.some((c) => {
        const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === a.id);
        const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
        return refIdAdd?.choices?.some((ch) => ch.id === offset);
      });
    });
    if (idAddBase) {
      const offset = id - idAddBase.id;
      const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
      if (idAddOpt?.choices && !idAddOpt.choices.some((c) => c.id === offset)) {
        let label = `Channel ${offset + 1}`;
        for (const c of candidates) {
          const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
          const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
          const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
          if (refChoice) {
            label = refChoice.label;
            break;
          }
        }
        idAddOpt.choices.push({ id: offset, label });
        logger2.info(`Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
      }
      continue;
    }
    let action;
    for (const c of candidates) {
      const match = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === id);
      if (match) {
        action = structuredClone(match);
        const baseName = match.name.replace(/\s*\(inferred from Model [^)]+\)/g, "").trim();
        action.name = `${baseName} (inferred from Model ${c.model})`;
        logger2.info(`Inferred cmd_id=${toHex(cmd_id)} id=${toHex(id)} from Model ${c.model} (exact)`);
        break;
      }
    }
    if (!action) {
      let shouldDefer = false;
      for (const c of candidates) {
        const baseEntry = c.cmdSchema?.find((a) => {
          if (a.cmd_id !== cmd_id)
            return false;
          const idAddOpt = a.options?.find((o) => o.id === "idAdd");
          if (!idAddOpt?.choices)
            return false;
          if (id <= a.id)
            return false;
          const offset = id - a.id;
          const maxSeq = idAddDeferRanges.get(`${cmd_id}_${a.id}`) ?? 0;
          return offset <= maxSeq;
        });
        if (baseEntry) {
          shouldDefer = true;
          logger2.debug(`cmd_id=${toHex(cmd_id)} id=${toHex(id)} is an idAdd offset of candidate base id=${toHex(baseEntry.id)} \u2014 deferring to pass 2`);
          break;
        }
      }
      if (shouldDefer)
        continue;
    }
    if (!action) {
      action = {
        cmd_id,
        id,
        name: `Unknown cmd:${toHex(cmd_id)} id:${toHex(id).toUpperCase()}`,
        options: [valueBytesToOption(valueBytes)]
      };
      if (busCh !== void 0)
        action.busCh = busCh;
      logger2.warn(`Could not infer cmd_id=${toHex(cmd_id)} id=${toHex(id)}`);
    } else {
      action.options = action.options?.filter((o) => o.id !== "busCh") ?? [];
      delete action.busCh;
      const seenBusChValues = busChSeen.get(`${cmd_id}_${id}`);
      if (seenBusChValues && seenBusChValues.size > 0) {
        const maxBusCh = Math.max(...seenBusChValues);
        if (maxBusCh === 0) {
          action.busCh = 0;
        } else {
          const busChChoices = Array.from({ length: maxBusCh + 1 }, (_, i) => ({
            id: i,
            label: `Channel ${i + 1}`
          }));
          action.options.unshift({
            id: "busCh",
            label: "Channel",
            type: "dropdown",
            choices: busChChoices,
            default: 0
          });
        }
      }
      const observedDefault = valueBytesToOption(valueBytes).default;
      const valueOpt = action.options?.find((o) => o.id === "value");
      if (valueOpt) {
        if (valueOpt.choices && Array.isArray(valueOpt.choices)) {
          const inChoices = valueOpt.choices.some((c) => c.id === observedDefault);
          if (!inChoices) {
            logger2.warn(`Inferred choices for cmd_id=${toHex(cmd_id)} id=${toHex(id)} don't contain observed value ${observedDefault} \u2014 discarding inherited choices`);
            valueOpt.type = "number";
            delete valueOpt.choices;
          }
        }
        valueOpt.default = observedDefault;
      }
    }
    out.cmdSchema.push(action);
  }
  for (const { cmd_id, id } of parsed) {
    const alreadyTopLevel = out.cmdSchema.some((a) => a.cmd_id === cmd_id && a.id === id);
    if (alreadyTopLevel)
      continue;
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt2 = a.options?.find((o) => o.id === "idAdd");
      return !!idAddOpt2?.choices && id > a.id;
    });
    if (!idAddBase)
      continue;
    const offset = id - idAddBase.id;
    const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
    if (!idAddOpt?.choices || idAddOpt.choices.some((c) => c.id === offset))
      continue;
    const refHasOffset = candidates.some((c) => {
      const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      return refIdAdd?.choices?.some((ch) => ch.id === offset);
    });
    const existingOffsets = idAddOpt.choices.map((c) => c.id).sort((a, b) => a - b);
    const isSequential = existingOffsets.length > 0 && offset === existingOffsets[existingOffsets.length - 1] + 1;
    if (!refHasOffset && !isSequential)
      continue;
    let label = `Channel ${offset + 1}`;
    for (const c of candidates) {
      const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
      if (refChoice) {
        label = refChoice.label;
        break;
      }
    }
    idAddOpt.choices.push({ id: offset, label });
    logger2.info(`Pass 2: Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
  }
  return out;
}
function saveModelJsonPretty(filePath, jsonObj) {
  try {
    const orderedObj = { model: jsonObj.model };
    if ("sectioned" in jsonObj) {
      orderedObj.sectioned = jsonObj.sectioned;
    }
    if ("cmdSchema" in jsonObj) {
      orderedObj.cmdSchema = jsonObj.cmdSchema.map((entry) => {
        const orderedEntry = {};
        if ("cmd_id" in entry)
          orderedEntry.cmd_id = entry.cmd_id;
        if ("id" in entry)
          orderedEntry.id = entry.id;
        if ("busCh" in entry)
          orderedEntry.busCh = entry.busCh;
        if ("name" in entry)
          orderedEntry.name = entry.name;
        if ("options" in entry)
          orderedEntry.options = entry.options;
        for (const key of Object.keys(entry)) {
          if (!(key in orderedEntry))
            orderedEntry[key] = entry[key];
        }
        return orderedEntry;
      });
    }
    for (const key of Object.keys(jsonObj)) {
      if (!(key in orderedObj)) {
        orderedObj[key] = jsonObj[key];
      }
    }
    let json = JSON.stringify(orderedObj, null, 2);
    json = json.replace(/\{\n\s+"id":\s*(\d+),\n\s+"label":\s*"([^"]*)"\n\s+\}/g, '{ "id": $1, "label": "$2" }');
    fs2.writeFileSync(filePath, json + "\n", "utf8");
  } catch (e) {
    logger2.error(`File Write Error: ${e}`);
  }
}

// dist/actions.js
var logger3 = createModuleLogger("Actions");
function UpdateActions(self) {
  const schemasRaw = getDeviceSchemas();
  const rawActions = buildActions();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredActions = {};
  const activeModel = self.activeModel;
  if (self.config.devMode) {
    wiredActions["global_getAllSettings"] = {
      name: "GLOBAL: Get All Settings",
      description: "Use this to create a schema for a new device",
      options: [],
      callback: async () => {
        const model = activeModel;
        const ip = self.host;
        const buf = await self.stController.requestAllSettings(ip);
        let modelJson = getDeviceSchema(model);
        const { settings: parsed, detectedSectioned } = parseGetAllSettingsWithDetection(model, buf);
        logger3.debug(`parsed reply: ${JSON.stringify(parsed)}`);
        if (!modelJson) {
          logger3.info(`Model ${model} has no schema \u2014 creating new JSON from settings`);
          modelJson = {
            model,
            sectioned: detectedSectioned ?? false,
            cmdSchema: []
          };
        } else if (detectedSectioned !== null) {
          logger3.info(`Auto-detected sectioned=${detectedSectioned}, adding to model JSON`);
          modelJson = { ...modelJson, sectioned: detectedSectioned };
        }
        const updated = updateModelJsonFromSettings(modelJson, parsed, schemas);
        logger3.debug(`new Actions json: ${JSON.stringify(updated, null, 2)}`);
        const devicesFolder2 = getDevicesFolder();
        const schemaPath = path2.join(devicesFolder2, `Model${model}.json`);
        saveModelJsonPretty(schemaPath, updated);
        reloadDeviceSchemas();
        logger3.info(`Model ${model} JSON auto-updated from getAllSettings`);
      }
    };
  }
  for (const [actionId, action] of Object.entries(rawActions)) {
    const { model, cmdId, baseId } = parseSettingId(actionId);
    if (model !== activeModel)
      continue;
    const schema = schemas[model];
    const rawAction = schema?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === baseId);
    wiredActions[actionId] = {
      ...action,
      callback: async (event) => {
        const ip = self.host;
        const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
        const value = event.options["value"];
        const idAdd = event.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        await self.stController.sendAwaitAck(cmdId, busCh, settingId, value, ip);
      }
    };
  }
  const activeSchema = schemas[activeModel];
  if (activeSchema) {
    const supportsMicKill = (activeSchema.cmdSchema ?? []).some((a) => a.name.includes("Kill"));
    if (supportsMicKill) {
      const actionId = `${activeModel}_micKill`;
      wiredActions[actionId] = {
        name: `[Model${activeModel}] Mic Kill`,
        options: [],
        callback: async () => {
          const ip = self.host;
          logger3.info(`Mic Kill \u2192 Model ${activeModel} @ ${ip}`);
          await self.stController.globalMicKill(ip);
          await self.stController.requestAllSettings(ip).catch((err) => {
            logger3.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
      };
    }
  }
  self.setActionDefinitions(wiredActions);
}

// dist/feedbacks.js
function getLabelForValue(schemas, model, cmdId, settingId, value) {
  const setting = findActionForSetting(schemas, model, cmdId, settingId);
  if (!setting || !Array.isArray(setting.options))
    return value;
  const valueOption = setting.options.find((opt) => opt.id === "value");
  if (!valueOption || !Array.isArray(valueOption.choices))
    return value;
  const choice = valueOption.choices.find((c) => c.id === value);
  return choice?.label ?? value;
}
function UpdateFeedbacks(self) {
  const schemasRaw = getDeviceSchemas();
  const rawFeedbacks = buildFeedbacks();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredFeedbacks = {};
  const activeModel = self.activeModel;
  for (const [feedbackId, feedback] of Object.entries(rawFeedbacks)) {
    const { model, cmdId, baseId } = parseSettingId(feedbackId);
    if (model !== activeModel)
      continue;
    wiredFeedbacks[feedbackId] = {
      ...feedback,
      callback: (feedbackEvent) => {
        const ip = self.host;
        const idAdd = feedbackEvent.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        let busCh = feedbackEvent.options["busCh"];
        if (busCh === void 0) {
          const schemaAction = findActionForSetting(schemas, model, cmdId, settingId);
          if (schemaAction?.busCh !== void 0) {
            busCh = schemaAction.busCh;
          }
        }
        if (busCh === void 0) {
          const rawAction = schemasRaw[model]?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === settingId);
          if (rawAction?.busCh !== void 0) {
            busCh = rawAction.busCh;
          }
        }
        const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
        if (feedbackId.endsWith("_bool")) {
          return current !== void 0 && current !== 0;
        }
        const showLabel = feedbackEvent.options["showLabel"] ?? false;
        if (showLabel && current !== void 0) {
          return getLabelForValue(schemas, model, cmdId, settingId, current);
        }
        return current ?? 0;
      }
    };
  }
  self.setFeedbackDefinitions(wiredFeedbacks);
}

// dist/stcontroller.js
import dgram2 from "dgram";
import os2 from "os";

// dist/dante.js
import dgram from "dgram";
import os from "os";
var logger4 = createModuleLogger("Dante");
var DANTE_MSG_INFO_REQUEST = 32;
var DANTE_MSG_INFO_RESPONSE = 368;
var DANTE_INFO_MIN_LEN = 204 + 64;
function buildDanteInfoRequest() {
  const buf = Buffer.alloc(32, 0);
  const seq = Math.floor(Math.random() * 65535);
  buf.writeUInt16BE(65535, 0);
  buf.writeUInt16BE(DANTE_MSG_INFO_REQUEST, 2);
  buf.writeUInt16BE(seq, 4);
  const mac = getFirstLocalMac();
  mac.copy(buf, 8);
  Buffer.from("Audinate", "ascii").copy(buf, 16);
  buf.writeUInt16BE(1849, 24);
  buf.writeUInt16BE(193, 26);
  buf.writeUInt32BE(1e6, 28);
  return buf;
}
function getFirstLocalMac() {
  try {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const addr of ifaces[name] ?? []) {
        if (!addr.internal && addr.family === "IPv4" && addr.mac && addr.mac !== "00:00:00:00:00:00") {
          return Buffer.from(addr.mac.split(":").map((h) => parseInt(h, 16)));
        }
      }
    }
  } catch {
  }
  return Buffer.alloc(6, 0);
}
function parseDanteInfoResponse(msg, srcIp) {
  if (msg.length < DANTE_INFO_MIN_LEN)
    return null;
  if (msg.readUInt16BE(0) !== 65535)
    return null;
  if (msg.readUInt16BE(2) !== DANTE_MSG_INFO_RESPONSE)
    return null;
  if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
    return null;
  const readStr = (offset, len) => msg.subarray(offset, offset + len).toString("ascii").split("\0")[0].trim();
  const eui64 = msg.subarray(8, 16);
  const macBytes = [eui64[0], eui64[1], eui64[2], eui64[5], eui64[6], eui64[7]];
  const mac = macBytes.map((b) => b.toString(16).padStart(2, "0")).join(":");
  const name = readStr(32, 31);
  const manufacturer = readStr(76, 64);
  const modelRaw = readStr(204, 64);
  const danteFirmware = `${msg[24]}.${msg[25]}`;
  if (!modelRaw)
    return null;
  const model = modelRaw.replace(/^Model\s+/i, "").trim().split(/\s+/)[0];
  return {
    ip: srcIp,
    name,
    manufacturer,
    model,
    modelName: modelRaw,
    // Full model description
    mac,
    danteFirmware
  };
}
async function getMacForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    tmp.once("error", (err) => {
      tmp.close();
      reject(new Error(err.message ?? String(err)));
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        tmp.close();
        const ifaces = os.networkInterfaces();
        for (const name of Object.keys(ifaces)) {
          for (const iface of ifaces[name] ?? []) {
            if (iface.family === "IPv4" && iface.address === localAddr && iface.mac && iface.mac !== "00:00:00:00:00:00") {
              return resolve(iface.mac.split(":").map((b) => parseInt(b, 16) & 255));
            }
          }
        }
        reject(new Error(`No interface found for local address ${localAddr}`));
      } catch (_e) {
        reject(new Error(String(_e)));
      }
    });
  });
}
async function getLocalAddressForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    let resolved = false;
    tmp.once("error", (err) => {
      if (!resolved) {
        resolved = true;
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      }
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        if (!resolved) {
          resolved = true;
          tmp.close();
          resolve(localAddr);
        }
      } catch (_e) {
        if (!resolved) {
          resolved = true;
          tmp.close();
          reject(new Error(String(_e)));
        }
      }
    });
  });
}
async function discoverDevices(txSocket, ensureMembership, timeoutMs = 5e3) {
  const DANTE_ANNOUNCE_GROUP = "224.0.0.233";
  const DANTE_ANNOUNCE_PORT = 8708;
  const DEFAULT_PORT = 8700;
  const queriedIps = /* @__PURE__ */ new Set();
  return new Promise((resolve) => {
    const announceSocket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const joinedInterfaces = [];
    const cleanup = () => {
      for (const iface of joinedInterfaces) {
        try {
          announceSocket.dropMembership(DANTE_ANNOUNCE_GROUP, iface);
        } catch {
        }
      }
      try {
        announceSocket.close();
      } catch {
      }
      resolve();
    };
    const timer = setTimeout(cleanup, timeoutMs);
    timer.unref?.();
    announceSocket.on("error", (err) => {
      logger4.warn(`Announce socket error: ${err.message}`);
    });
    announceSocket.on("message", (msg, rinfo) => {
      const srcIp = rinfo.address;
      if (msg.length < 24)
        return;
      if (msg.readUInt16BE(0) !== 65534)
        return;
      if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
        return;
      if (queriedIps.has(srcIp))
        return;
      queriedIps.add(srcIp);
      logger4.debug(`Announce from ${srcIp} \u2014 sending unicast query`);
      const sendQuery = async () => {
        await ensureMembership(srcIp);
        const query = buildDanteInfoRequest();
        txSocket.send(query, DEFAULT_PORT, srcIp, (err) => {
          if (err)
            logger4.warn(`Unicast query to ${srcIp} failed: ${err.message}`);
        });
      };
      sendQuery().catch((err) => logger4.warn(`Query setup failed: ${err}`));
    });
    announceSocket.bind(DANTE_ANNOUNCE_PORT, () => {
      const ifaces = os.networkInterfaces();
      for (const addrs of Object.values(ifaces)) {
        for (const addr of addrs ?? []) {
          if (addr.family === "IPv4" && !addr.internal) {
            try {
              announceSocket.addMembership(DANTE_ANNOUNCE_GROUP, addr.address);
              joinedInterfaces.push(addr.address);
            } catch {
            }
          }
        }
      }
      if (joinedInterfaces.length === 0) {
        logger4.warn(`Could not join announce multicast group on any interface`);
      } else {
        logger4.debug(`Listening for Dante announces on ${DANTE_ANNOUNCE_GROUP}:${DANTE_ANNOUNCE_PORT}`);
      }
    });
  });
}
var _conmonPending = /* @__PURE__ */ new Map();
async function openConMonSession(deviceIp, timeoutMs = 3e3) {
  const pending = _conmonPending.get(deviceIp);
  if (pending)
    return pending;
  const promise = _doConMonSession(deviceIp, timeoutMs).finally(() => {
    _conmonPending.delete(deviceIp);
  });
  _conmonPending.set(deviceIp, promise);
  return promise;
}
async function _doConMonSession(deviceIp, timeoutMs) {
  return new Promise((resolve) => {
    let settled = false;
    let keepaliveTimer = null;
    const closeSession = (sock2) => {
      if (keepaliveTimer) {
        clearInterval(keepaliveTimer);
        keepaliveTimer = null;
      }
      try {
        sock2.close();
      } catch {
      }
      logger4.debug(`ConMon session closed for ${deviceIp}`);
    };
    const fail = (sock2) => {
      if (settled)
        return;
      settled = true;
      clearTimeout(timer);
      closeSession(sock2);
      logger4.debug(`ConMon session not established for ${deviceIp} \u2014 device may not require it`);
      resolve(null);
    };
    const sock = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const timer = setTimeout(() => fail(sock), timeoutMs);
    sock.on("error", (err) => {
      logger4.warn(`ConMon socket error for ${deviceIp}: ${err.message}`);
      fail(sock);
    });
    sock.on("message", (msg) => {
      if (!settled && msg.length >= 4 && msg[0] === 18 && msg[3] === 32) {
        settled = true;
        clearTimeout(timer);
        logger4.info(`ConMon session established with ${deviceIp}`);
        let keepaliveSeq = Math.floor(Math.random() * 65534) + 1;
        const sendKeepalive = () => {
          const pkt = Buffer.alloc(20, 0);
          pkt[0] = 18;
          pkt[3] = 78;
          pkt.writeUInt16BE(keepaliveSeq++ & 65535, 4);
          pkt[6] = 48;
          pkt[7] = 16;
          sock.send(pkt, 8800, deviceIp, () => {
          });
        };
        keepaliveTimer = setInterval(sendKeepalive, 1e3);
        resolve(() => closeSession(sock));
      }
    });
    const doInit = async () => {
      let localIp;
      let localMac;
      try {
        localIp = await getLocalAddressForDestination(deviceIp);
        localMac = await getMacForDestination(deviceIp);
      } catch (e) {
        logger4.warn(`ConMon: could not get local network info for ${deviceIp}: ${e}`);
        fail(sock);
        return;
      }
      sock.bind({ port: 8800, address: localIp }, () => {
        const seq = Math.floor(Math.random() * 65534) + 1;
        const pkt = Buffer.alloc(20, 0);
        pkt[0] = 18;
        pkt[3] = 20;
        pkt.writeUInt16BE(seq, 4);
        pkt[6] = 16;
        pkt[7] = 1;
        localMac.forEach((b, i) => {
          pkt[12 + i] = b;
        });
        logger4.debug(`ConMon TX to ${deviceIp}: ${pkt.toString("hex")}`);
        sock.send(pkt, 8800, deviceIp, (err) => {
          if (err) {
            logger4.warn(`ConMon send failed for ${deviceIp}: ${err.message}`);
            fail(sock);
          }
        });
      });
    };
    doInit().catch((e) => {
      logger4.warn(`ConMon init failed for ${deviceIp}: ${e}`);
      fail(sock);
    });
  });
}
async function probeDevice(txSocket, registerListener, removeListener, ensureMembership, ip, timeoutMs = 3e3) {
  return new Promise((resolve) => {
    const key = `__probe_${ip}__`;
    let resolved = false;
    const finish = (result) => {
      if (resolved)
        return;
      resolved = true;
      removeListener(key);
      resolve(result);
    };
    registerListener(key, (device) => {
      if (device.ip === ip)
        finish(device);
    });
    const timer = setTimeout(() => finish(null), timeoutMs);
    timer.unref?.();
    const run = async () => {
      await ensureMembership(ip);
      const query = buildDanteInfoRequest();
      txSocket.send(query, 8700, ip, (err) => {
        if (err) {
          logger4.warn(`Probe to ${ip} failed: ${err.message}`);
          clearTimeout(timer);
          finish(null);
        }
      });
    };
    run().catch((e) => {
      logger4.warn(`probeDevice setup failed for ${ip}: ${e}`);
      clearTimeout(timer);
      finish(null);
    });
  });
}

// dist/stcontroller.js
var logger5 = createModuleLogger("StController");
var StController = class _StController {
  defaultPort = 8700;
  multicastGroup = "224.0.0.231";
  rxPort = 8702;
  txSocket;
  rxSocket;
  // for receiving responses (8702)
  pendingAcks = /* @__PURE__ */ new Map();
  joinedInterfaces = /* @__PURE__ */ new Set();
  // local IPs we've joined multicast on
  /** Serializes outgoing commands so each waits for ACK before the next is sent */
  sendQueue = Promise.resolve();
  /** Tracks how many commands are queued/in-flight, to defer requestAllSettings */
  pendingCommandCount = 0;
  /** Resolves once txSocket is bound and ready to send */
  txReady;
  /** Active device model and action definitions for settings decoding */
  model = "";
  actions = [];
  /**
   * Known state of every setting per device IP.
   * Keyed by IP → Map of "${cmdId}/${settingId}" → current value byte.
   * Populated on connect via requestAllSettings(), updated on every CMD_SETTINGS_PUSH (0x0b).
   * Used to diff incoming pushes (changed = info, unchanged = debug) and for feedbacks.
   */
  deviceState = /* @__PURE__ */ new Map();
  /**
   * IPs that have been verified against the configured model and are allowed
   * to receive Studio-T commands. Populated by authorizeDevice() after a
   * successful probeDevice() model match, or after multicast discovery.
   * _sendAwaitAck() rejects any destIp not in this set.
   */
  authorizedIps = /* @__PURE__ */ new Set();
  /** Callbacks registered for Dante 0x0170 device info responses — keyed by usage */
  discoveryListeners = /* @__PURE__ */ new Map();
  /** Callback to trigger feedback updates when state changes */
  feedbackCallback;
  /** Cache of local interface MAC bytes per destination IP, to avoid repeated OS lookups */
  macCache = /* @__PURE__ */ new Map();
  /** IPs for which a Dante ConMon (port 8800) session has been successfully opened */
  sessionEstablished = /* @__PURE__ */ new Set();
  /** Cleanup functions returned by openConMonSession() — call to stop keepalives and close the socket */
  _conmonCleanups = /* @__PURE__ */ new Map();
  constructor() {
    logger5.info("StController initialized");
    this.txSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.txReady = new Promise((resolve) => {
      this.txSocket.bind(0, () => {
        logger5.debug(`TX socket bound to port ${this.txSocket.address().port}`);
        resolve();
      });
    });
    this.txSocket.on("error", (err) => {
      logger5.error(`TX socket error: ${err}`);
    });
    this.rxSocket = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    this.rxSocket.on("listening", () => {
      const addr = this.rxSocket.address();
      logger5.debug(`RX socket listening on ${JSON.stringify(addr)}`);
      try {
        this.rxSocket.setMulticastLoopback(true);
      } catch (_e) {
      }
    });
    this.rxSocket.on("error", (err) => {
      logger5.error(`RX socket error: ${err}`);
    });
    this.rxSocket.on("message", (msg, rinfo) => {
      try {
        this.handleIncoming(msg, rinfo.address);
      } catch (_e) {
        logger5.error(`Error handling incoming message: ${_e}`);
      }
    });
    this.rxSocket.bind({ address: "0.0.0.0", port: this.rxPort }, () => {
      logger5.debug(`RX socket bound to 0.0.0.0:${this.rxPort}`);
      const ifaces = os2.networkInterfaces();
      for (const addrs of Object.values(ifaces)) {
        for (const addr of addrs ?? []) {
          if (addr.family === "IPv4" && !addr.internal && !this.joinedInterfaces.has(addr.address)) {
            try {
              this.rxSocket.addMembership(this.multicastGroup, addr.address);
              this.joinedInterfaces.add(addr.address);
              logger5.debug(`Pre-joined multicast ${this.multicastGroup} on ${addr.address}`);
            } catch (_e) {
              logger5.warn(`Could not pre-join multicast on ${addr.address}: ${String(_e)}`);
            }
          }
        }
      }
    });
  }
  close() {
    for (const cleanup of this._conmonCleanups.values()) {
      try {
        cleanup();
      } catch {
      }
    }
    this._conmonCleanups.clear();
    try {
      for (const localAddr of Array.from(this.joinedInterfaces)) {
        try {
          this.rxSocket.dropMembership(this.multicastGroup, localAddr);
        } catch {
        }
      }
    } catch {
    }
    try {
      this.rxSocket.close();
    } catch {
    }
    try {
      this.txSocket.close();
    } catch {
    }
  }
  /**
   * Provide the active device model and action definitions so incoming messages
   * can be decoded into human-readable names. Call from main.ts after config load.
   */
  setModel(model, actions) {
    this.model = model;
    this.actions = actions;
  }
  /**
   * Set callback to trigger when device state changes (for feedbacks).
   * Call from main.ts to wire up checkFeedbacks.
   */
  setFeedbackCallback(callback) {
    this.feedbackCallback = callback;
  }
  /** Returns true if the device at the given IP has been authorized to receive commands. */
  isDeviceAuthorized(ip) {
    return this.authorizedIps.has(ip);
  }
  /** Mark an IP as verified and allowed to receive Studio-T commands. */
  authorizeDevice(ip) {
    this.authorizedIps.add(ip);
    logger5.debug(`Authorized device at ${ip}`);
  }
  /** Remove authorization for an IP (e.g. on config change or model mismatch). */
  revokeDevice(ip) {
    this.authorizedIps.delete(ip);
    this.deviceState.delete(ip);
    this.macCache.delete(ip);
    this.sessionEstablished.delete(ip);
    this._conmonCleanups.get(ip)?.();
    this._conmonCleanups.delete(ip);
    logger5.debug(`Revoked device at ${ip}`);
  }
  /**
   * Opens a Dante ConMon session for the device. Caches the result so the
   * handshake only runs once per IP. Delegates to dante.ts openConMonSession().
   */
  async openSession(deviceIp) {
    if (this.sessionEstablished.has(deviceIp))
      return true;
    const cleanup = await openConMonSession(deviceIp);
    const success = cleanup !== null;
    this.sessionEstablished.add(deviceIp);
    if (success) {
      this._conmonCleanups.set(deviceIp, cleanup);
    }
    return success;
  }
  /**
   * Sends a unicast Dante info request to a specific IP and waits for the
   * device info response. Returns the DeviceInfo if the device responds within
   * timeoutMs, or null if no response. Used to verify a manually configured IP.
   * Does NOT require authorization — this is how authorization is established.
   */
  async probeDevice(ip, timeoutMs = 3e3) {
    await this.txReady;
    return probeDevice(this.txSocket, (key, cb) => this.discoveryListeners.set(key, cb), (key) => this.discoveryListeners.delete(key), async (destIp) => this.ensureMembershipFor(destIp), ip, timeoutMs);
  }
  /**
   * Send a CMD_GET_ALL_SETTINGS (0x0a) request to the device and store the response
   * in deviceState. Returns the raw response buffer for parsing.
   */
  async requestAllSettings(deviceIp) {
    logger5.info(`Requesting all settings from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_ALL_SETTINGS, void 0, void 0, void 0, deviceIp, false);
    return response;
  }
  /**
   * Discovers Studio Technologies Dante devices on the local network.
   *
   * Listens for Dante announces on 224.0.0.233:8708, sends unicast info requests
   * to each discovered IP, and collects 0x0170 responses via the rxSocket.
   */
  async discoverDevices(timeoutMs = 5e3) {
    const DISCOVERY_KEY = "__discovery__";
    const foundDevices = [];
    this.discoveryListeners.set(DISCOVERY_KEY, (device) => {
      if (!foundDevices.some((d) => d.ip === device.ip)) {
        foundDevices.push(device);
      }
    });
    try {
      await this.txReady;
      await discoverDevices(this.txSocket, async (destIp) => this.ensureMembershipFor(destIp), timeoutMs);
      return foundDevices;
    } finally {
      this.discoveryListeners.delete(DISCOVERY_KEY);
    }
  }
  /**
   * Requests device firmware version via Studio-T protocol (CMD_GET_FIRMWARE).
   * Returns the firmware version string (e.g., "3.01", "2.2", "1.05").
   */
  async requestFirmwareVersion(deviceIp) {
    logger5.info(`Requesting firmware version from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_FIRMWARE, void 0, void 0, void 0, deviceIp, false);
    const dataStart = 26;
    if (response.length < dataStart + 3) {
      logger5.warn(`Firmware response too short: ${response.length} bytes`);
      return "Unknown";
    }
    const major = response[dataStart + 1];
    const minor = response[dataStart + 2];
    const minorStr = minor < 10 ? minor.toString().padStart(2, "0") : minor.toString();
    const firmware = `${major}.${minorStr}`;
    logger5.debug(`Firmware version: ${firmware}`);
    return firmware;
  }
  /**
   * Joins the multicast response group on the interface that routes to destIp.
   * Only joins the specific interface used to reach the device, and only once per interface.
   */
  async ensureMembershipFor(destIp) {
    try {
      const localAddr = await getLocalAddressForDestination(destIp);
      if (!localAddr) {
        logger5.warn(`Could not determine local address for destination ${destIp}`);
        return;
      }
      if (this.joinedInterfaces.has(localAddr)) {
        return;
      }
      try {
        this.rxSocket.addMembership(this.multicastGroup, localAddr);
        this.joinedInterfaces.add(localAddr);
        logger5.info(`Joined multicast ${this.multicastGroup} on ${localAddr}`);
      } catch (_e) {
        logger5.warn(`Failed to join multicast on ${localAddr}: ${String(_e)}`);
      }
    } catch (_e) {
      logger5.warn(`ensureMembershipFor failed: ${_e}`);
    }
  }
  async sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    this.pendingCommandCount++;
    return new Promise((resolve, reject) => {
      this.sendQueue = this.sendQueue.then(async () => this._sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen).then((buf) => {
        this.pendingCommandCount--;
        if (this.pendingCommandCount === 0 && value !== void 0) {
          this.requestAllSettings(destIp).catch((err) => {
            logger5.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
        resolve(buf);
      }).catch((err) => {
        this.pendingCommandCount--;
        reject(err instanceof Error ? err : new Error(String(err)));
      }));
    });
  }
  async _sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    const timeoutMs = 2e3;
    const dataBlock = [];
    if (settingId !== void 0)
      dataBlock.push(settingId & 255);
    if (value !== void 0)
      dataBlock.push(..._StController.buildValueBytes(value));
    const payloadBody = [90, cmdId & 255];
    if (cmdId === CMD_MIC_PRE && busCh !== void 0 && settingId !== void 0 && value !== void 0) {
      if (!this.deviceState.has(destIp))
        this.deviceState.set(destIp, /* @__PURE__ */ new Map());
      const ipState = this.deviceState.get(destIp);
      const numPositions = 3;
      const positions = [];
      for (let i = 0; i < numPositions; i++) {
        const stateKey = makeSettingId(this.model, CMD_MIC_PRE, i, busCh);
        const val = i === settingId ? Number(value) : ipState.get(stateKey) ?? 0;
        positions.push(val);
        ipState.set(stateKey, val);
      }
      payloadBody.push(busCh & 255, ...positions);
    } else {
      if (busCh !== void 0)
        payloadBody.push(busCh & 255);
      if (addLen)
        payloadBody.push(dataBlock.length);
      if (dataBlock.length > 0)
        payloadBody.push(...dataBlock);
    }
    const crc = _StController.crc8DvbS2(payloadBody);
    const payloadWithCrc = Buffer.from([...payloadBody, crc]);
    if (settingId !== void 0 && value !== void 0) {
      const valueBytes = _StController.buildValueBytes(value);
      const setting = {
        cmd_id: cmdId,
        id: settingId,
        busCh,
        valueBytes
      };
      logger5.info(`TX ${destIp} | ${formatParsedSetting(setting, this.actions)}`);
    } else {
      logger5.info(`TX ${destIp} | ${getCommandName(cmdId)}`);
    }
    if (!this.authorizedIps.has(destIp)) {
      logger5.debug(`Packet (not sent \u2014 device not authorized) to ${destIp}: ${payloadWithCrc.toString("hex")}`);
      throw new Error(`Device at ${destIp} is not authorized \u2014 verify the IP and model match before sending commands`);
    }
    if (!this.sessionEstablished.has(destIp)) {
      await this.openSession(destIp);
    }
    await this.ensureMembershipFor(destIp);
    const totalLen = 24 + payloadWithCrc.length;
    const header = await this.buildHeader(totalLen, destIp);
    const packet = Buffer.concat([header, payloadWithCrc]);
    logger5.debug(`Sending packet to ${destIp}: ${packet.toString("hex")}`);
    const key = `${destIp}:${cmdId}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingAcks.delete(key);
        reject(new Error(`Timeout waiting for ACK from Model ${this.model} at ${destIp}:8700`));
      }, timeoutMs);
      this.pendingAcks.set(key, {
        resolve: (buf) => {
          clearTimeout(timer);
          resolve(buf);
        },
        reject: (err) => {
          clearTimeout(timer);
          reject(err);
        },
        timer
      });
      this.txSocket.send(packet, this.defaultPort, destIp, (err) => {
        if (err) {
          this.pendingAcks.delete(key);
          clearTimeout(timer);
          reject(new Error(err.message ?? String(err)));
        }
      });
    });
  }
  handleIncoming(msg, srcIp) {
    if (msg.length < 4)
      return;
    if (msg[0] !== 255 || msg[1] !== 255)
      return;
    const msgType = msg.readUInt16BE(2);
    if (msgType === DANTE_MSG_INFO_RESPONSE && this.discoveryListeners.size > 0) {
      const device = parseDanteInfoResponse(msg, srcIp);
      if (device) {
        logger5.debug(`Dante info response from ${srcIp}: DeviceID="${device.name}", Model="${device.model}", ModelName="${device.modelName}", Manufacturer="${device.manufacturer}"`);
        if (device.name === "Studio-T") {
          for (const cb of this.discoveryListeners.values()) {
            try {
              cb(device);
            } catch {
            }
          }
        } else {
          logger5.debug(`Ignoring non-Studio Technologies device: DeviceID="${device.name}" @ ${srcIp}`);
        }
      }
      return;
    }
    if (msg.length < 25)
      return;
    const sig = msg.subarray(16, 24);
    if (sig.toString("ascii") !== "Studio-T")
      return;
    if (!this.authorizedIps.has(srcIp)) {
      logger5.debug(`Ignoring Studio-T packet from unauthorized device ${srcIp}`);
      return;
    }
    const stPayload = msg.subarray(24);
    if (stPayload.length < 2)
      return;
    if (stPayload[0] !== 90)
      return;
    const respCmdId = stPayload[1];
    const isResponse = (respCmdId & 128) !== 0;
    const originalCmdId = respCmdId & 127;
    if (isResponse && originalCmdId === CMD_GET_ALL_SETTINGS) {
      logger5.debug(`Received packet from ${srcIp}: ${msg.toString("hex")}`);
    }
    this.logStPayload(srcIp, originalCmdId, msg, stPayload);
    if (isResponse) {
      const key = `${srcIp}:${originalCmdId}`;
      const pending = this.pendingAcks.get(key);
      if (pending) {
        this.pendingAcks.delete(key);
        pending.resolve(msg);
      }
    }
  }
  /**
   * Decodes and logs a Studio-T response payload.
   * Receives both the full msg (for parsers that need the Studio-T header)
   * and stPayload (msg.subarray(24), for direct byte access).
   *
   * stPayload layout:
   *   [0]      0x5a  magic
   *   [1]      cmdId | 0x80
   *   [2..-2]  data bytes
   *   [-1]     CRC-8/DVB-S2
   */
  logStPayload(srcIp, cmdId, msg, stPayload) {
    const cmdName = getCommandName(cmdId);
    const data = stPayload.subarray(2, stPayload.length - 1);
    const respCmdId = stPayload[1];
    const crc = stPayload[stPayload.length - 1];
    const fullStructure = `[cmd:${toHex(respCmdId)} data:${data.toString("hex")} crc:${toHex(crc)}]`;
    if (cmdId === CMD_GET_ALL_SETTINGS || cmdId === CMD_SETTINGS_PUSH) {
      if (!this.model) {
        logger5.info(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
        return;
      }
      try {
        const settings = cmdId === CMD_SETTINGS_PUSH ? parseSettingsResponse(this.model, msg) : parseGetAllSettingsForModel(this.model, msg);
        const prevState = this.deviceState.get(srcIp) ?? /* @__PURE__ */ new Map();
        const newState = new Map(prevState);
        for (const s of settings) {
          const stateKey = makeSettingId(this.model, s.cmd_id, s.id, s.busCh);
          const newValue = s.valueBytes.length === 3 ? s.valueBytes[0] << 16 | s.valueBytes[1] << 8 | s.valueBytes[2] : s.valueBytes[0] ?? 0;
          const prevValue = prevState.get(stateKey);
          const changed = prevValue === void 0 || prevValue !== newValue;
          newState.set(stateKey, newValue);
          const formatted = formatParsedSetting(s, this.actions);
          if (changed) {
            logger5.info(`RX ${srcIp} | ${formatted}`);
            if (this.feedbackCallback) {
              let baseId = s.id;
              const baseAction = this.actions.find((a) => {
                if (a.cmd_id !== s.cmd_id)
                  return false;
                if (a.id === s.id)
                  return true;
                const idAddOption = a.options?.find((o) => o.id === "idAdd");
                if (!idAddOption?.choices)
                  return false;
                const offset = s.id - a.id;
                return offset > 0 && idAddOption.choices.some((c) => c.id === offset);
              });
              if (baseAction)
                baseId = baseAction.id;
              const baseFeedbackKey = makeSettingId(this.model, s.cmd_id, baseId);
              this.feedbackCallback(baseFeedbackKey);
              this.feedbackCallback(baseFeedbackKey + "_bool");
            } else {
              logger5.warn(`feedbackCallback not set \u2014 skipping feedback update for ${stateKey}`);
            }
          } else {
            logger5.debug(`RX ${srcIp} | ${formatted}`);
          }
        }
        this.deviceState.set(srcIp, newState);
      } catch (e) {
        logger5.warn(`RX ${srcIp} | ${cmdName} | parse failed: ${e} | ${fullStructure}`);
      }
      return;
    }
    const decoded = this.decodeStData(cmdId, data);
    const logFn = cmdId === CMD_BUS_GET ? logger5.debug.bind(logger5) : logger5.info.bind(logger5);
    if (decoded) {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure} | ${decoded}`);
    } else {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
    }
  }
  /**
   * Attempts to decode the data bytes of a Studio-T response into a
   * human-readable string. Returns null to fall back to raw hex.
   */
  decodeStData(cmdId, data) {
    if (data.length === 0)
      return "ACK";
    if (data.length === 1) {
      if (data[0] === 0) {
        return "ACK ok";
      } else {
        return `ERROR ${toHex(data[0])}`;
      }
    }
    switch (cmdId) {
      // ── CMD_MIC_PRE (0x02): raw preamp echo — positional bytes, no setting IDs ──
      // Device echoes [busCh][val0][val1]... confirming the applied values.
      case CMD_MIC_PRE: {
        const busCh = data[0];
        const vals = Array.from(data.subarray(1)).map((b, i) => `[${i}]=0x${b.toString(16).padStart(2, "0")}(${b})`).join(" ");
        return `ch=${busCh} ${vals}`;
      }
      // ── CMD_DEV_SPEC (0x0d): single-byte ACK or echo of applied setting ──
      // Device sends two CMD_DEV_SPEC packets in response to a set:
      //   1. ACK:  [status]               (1 byte, 0x00 = ok)
      //   2. Echo: [busCh] [settingId] [value...]  (confirming what was applied)
      case CMD_DEV_SPEC: {
        if (data.length === 1) {
          return data[0] === 0 ? "ACK ok" : `ACK err=${toHex(data[0])}`;
        }
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const choices = action?.options?.[0]?.choices;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ? `${choiceLabel} (${toHex(valueNum)})` : bytesToHex(Array.from(valueBytes));
          const rawTag = `[${toHex(cmdId)}/${toHex(settingId)}]=${bytesToHex(Array.from(valueBytes))}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr} ${rawTag}`;
        }
        return `raw: ${data.toString("hex")}`;
      }
      // ── CMD_MIC_PRE_BUS (0x12): Multi-byte echo responses ─────────────
      case CMD_MIC_PRE_BUS: {
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choices = action?.options?.find((o) => o.id === "value")?.choices;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ?? `0x${valueBytes.toString("hex")}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr}`;
        }
        return null;
      }
      // ── Bus-scoped get/set ────────────────────────────────────────────
      case CMD_BUS_GET:
      case CMD_BUS_SET: {
        if (data.length < 2)
          return null;
        const busCh = data[0];
        const settingId = data[1];
        const value = data.subarray(2);
        return `ch=${busCh} setting=${toHex(settingId)} value=${value.toString("hex")}`;
      }
      default:
        return null;
    }
  }
  static buildValueBytes(value) {
    if (typeof value === "boolean")
      return [value ? 1 : 0];
    if (Array.isArray(value))
      return value.map((v) => Number(v) & 255);
    if (typeof value === "number") {
      if (value > 255)
        return [value >> 16 & 255, value >> 8 & 255, value & 255];
      return [value & 255];
    }
    throw new Error(`Unsupported value type for STcontroller: ${value}`);
  }
  async buildHeader(totalLen, destIp) {
    let mac = this.macCache.get(destIp);
    if (!mac) {
      mac = await getMacForDestination(destIp);
      this.macCache.set(destIp, mac);
    }
    return Buffer.concat([
      Buffer.from([255, 255, 0, totalLen & 255, 7, 225, 0, 0, ...mac, 0, 0]),
      Buffer.from("Studio-T", "utf8")
    ]);
  }
  static crc8DvbS2(data) {
    let crc = 0;
    for (const b of data) {
      crc ^= b;
      for (let i = 0; i < 8; i++) {
        crc = (crc & 128) !== 0 ? (crc << 1 ^ 213) & 255 : crc << 1 & 255;
      }
    }
    return crc;
  }
  /**
   * Returns the current known value for a setting on a device, or undefined if unknown.
   * Use for feedbacks — value is updated on every CMD_SETTINGS_PUSH (0x0b) from the device.
   *
   * @param ip        Device IP address
   * @param cmdId     Command ID (e.g. CMD_DEV_SPEC)
   * @param settingId Setting ID (e.g. 0x02 for Control Source)
   * @param busCh     Optional bus/channel ID for multi-channel commands
   */
  getSettingValue(ip, cmdId, settingId, busCh) {
    const key = makeSettingId(this.model, cmdId, settingId, busCh);
    return this.deviceState.get(ip)?.get(key);
  }
  async resetDevice(destIp) {
    return this.sendAwaitAck(CMD_RESET_DEVICE, void 0, 0, void 0, destIp, false);
  }
  async globalMicKill(destIp) {
    return this.sendAwaitAck(CMD_GLOBAL_MIC_KILL, void 0, void 0, void 0, destIp, false);
  }
};

// dist/main.js
var logger6 = createModuleLogger("ModuleInstance");
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  stController;
  /** Cached discovery results — passed into getConfigFields() so the UI
   *  can show the discovered device dropdown on subsequent config opens. */
  discoveredDevices = [];
  /** Currently active model — resolved once in syncModel() and cached here
   *  so UpdateActions, UpdateFeedbacks etc. don't each call resolveModel independently. */
  activeModel = "";
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    if (!this.stController) {
      this.stController = new StController();
    }
    this.updateStatus(InstanceStatus.Connecting, "Discovering devices...");
    this.stController.setFeedbackCallback((feedbackId) => {
      this.checkFeedbacks(feedbackId);
    });
    this.runDiscovery().catch((e) => {
      logger6.error(`Discovery failed: ${e}`);
    });
  }
  /**
   * Run device discovery, then resolve the model and update all UI.
   * - If discovery finds devices, resolveModel picks from those.
   * - Only if the list is empty do we fall back to the manual config selection.
   * All actions/feedbacks/variables are built after the model is known.
   */
  async runDiscovery() {
    logger6.info("Starting device discovery...");
    this.discoveredDevices = await this.stController.discoverDevices();
    let effectiveModel;
    if (this.discoveredDevices.length === 0) {
      if (this.config.deviceMac) {
        const modelLabel = this.config.activeModel ? `Model ${this.config.activeModel} ` : "";
        logger6.warn(`Saved device MAC "${this.config.deviceMac}" not found during discovery \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `${modelLabel}[${this.config.deviceMac}] not found`);
        return;
      }
      const manualModel = this.config.activeModel;
      if (!this.config.host || !manualModel) {
        logger6.warn("No devices discovered and no manual IP/model configured");
        return;
      }
      logger6.info("No devices discovered \u2014 will probe manual IP during authorization");
      effectiveModel = manualModel;
    } else {
      logger6.info(`Discovered ${this.discoveredDevices.length} device(s):`);
      for (const d of this.discoveredDevices) {
        logger6.info(`  - Model ${d.model} ${d.manufacturer ?? ""} @ ${d.ip}`);
      }
      for (const device of this.discoveredDevices) {
        this.stController.authorizeDevice(device.ip);
      }
      for (const device of this.discoveredDevices) {
        try {
          const firmware = await this.stController.requestFirmwareVersion(device.ip);
          device.firmwareMain = firmware;
          logger6.info(`  - ${device.ip}: Firmware ${firmware}, Dante ${device.danteFirmware}`);
        } catch (e) {
          logger6.warn(`  - ${device.ip}: Failed to get firmware: ${e}`);
          device.firmwareMain = "Unknown";
        }
      }
      effectiveModel = resolveModel(this.config, this.discoveredDevices);
      if (!effectiveModel && this.config.deviceMac) {
        const modelLabel = this.config.activeModel ? `Model ${this.config.activeModel} ` : "";
        logger6.warn(`Saved device MAC "${this.config.deviceMac}" not found among discovered devices \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `${modelLabel}[${this.config.deviceMac}] not found`);
        return;
      }
    }
    this.syncModel(effectiveModel);
    const targetHost = this.host;
    await this.verifyAuthorization("", targetHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
    logger6.info("Device discovery complete");
  }
  // When module gets deleted
  async destroy() {
    this.stController?.close();
    logger6.debug("destroy");
  }
  async configUpdated(config) {
    const previousHost = this.host;
    this.config = config;
    const effectiveModel = resolveModel(config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.updateVariableValues();
    const newHost = this.host;
    await this.verifyAuthorization(previousHost, newHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
  }
  /**
   * Re-evaluates whether the current config is authorized to send commands.
   *
   * Auto mode (deviceMac set):
   *   - Find the discovered device with matching MAC → get its current IP
   *   - Revoke the previous IP, authorize the new IP
   *   - If MAC not found in discovery, revoke and block
   *
   * Manual mode (deviceMac empty):
   *   - Check discovered list by IP+model match, or probe directly
   */
  async verifyAuthorization(previousHost, newHost) {
    if (!newHost) {
      if (previousHost)
        this.stController.revokeDevice(previousHost);
      return;
    }
    if (this.config.deviceMac) {
      const device = this.discoveredDevices.find((d) => d.mac === this.config.deviceMac);
      if (!device) {
        logger6.warn(`Device MAC "${this.config.deviceMac}" not found in current discovery \u2014 not authorizing`);
        if (previousHost)
          this.stController.revokeDevice(previousHost);
        return;
      }
      if (previousHost && previousHost !== newHost) {
        this.stController.revokeDevice(previousHost);
      }
      const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
      if (!wasAuthorized) {
        this.stController.authorizeDevice(newHost);
      }
      if (newHost !== previousHost || !wasAuthorized) {
        await this.fetchSettingsAndEnsureSchema(device.model, newHost);
      }
      this.updateStatus(InstanceStatus.Ok, `Model ${device.model} @ ${newHost}`);
      return;
    }
    const manualModel = String(this.config.activeModel ?? "");
    const discoveredAtIp = this.discoveredDevices.find((d) => d.ip === newHost);
    if (discoveredAtIp) {
      if (discoveredAtIp.model === manualModel) {
        if (previousHost && previousHost !== newHost)
          this.stController.revokeDevice(previousHost);
        const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
        if (!wasAuthorized) {
          this.stController.authorizeDevice(newHost);
        }
        if (newHost !== previousHost || !wasAuthorized) {
          await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
        }
        this.updateStatus(InstanceStatus.Ok, `Model ${manualModel} @ ${newHost}`);
      } else {
        logger6.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${discoveredAtIp.model}) at ${newHost} \u2014 commands blocked`);
        this.stController.revokeDevice(newHost);
        this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${discoveredAtIp.model}`);
      }
      return;
    }
    logger6.info(`${newHost} not in discovered list \u2014 probing`);
    if (previousHost && previousHost !== newHost)
      this.stController.revokeDevice(previousHost);
    this.stController.revokeDevice(newHost);
    const probed = await this.stController.probeDevice(newHost);
    if (!probed) {
      logger6.error(`No device responded at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.UnknownWarning, `Device offline: ${newHost}`);
    } else if (probed.model !== manualModel) {
      logger6.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${probed.model}) at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${probed.model}`);
    } else {
      logger6.info(`Verified Model ${probed.model} at ${newHost}`);
      this.stController.authorizeDevice(newHost);
      await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
      this.updateStatus(InstanceStatus.Ok, `Model ${probed.model} @ ${newHost}`);
    }
  }
  /**
   * Fetches all settings from the device. If no schema exists for the model,
   * creates one from the response and reloads the schema cache.
   */
  async fetchSettingsAndEnsureSchema(model, ip) {
    try {
      await this.stController.requestAllSettings(ip);
      if (!getDeviceSchema(model)) {
        logger6.warn(`No schema found for Model ${model} \u2014 run "GLOBAL: Get All Settings" to create one`);
        return;
      }
    } catch (e) {
      logger6.warn(`Failed to fetch settings from ${ip}: ${e}`);
    }
  }
  /** Loads the device JSON for the given model, caches it as activeModel, and pushes it to the controller. */
  syncModel(model) {
    this.activeModel = model;
    const schema = getDeviceSchema(model);
    if (!schema) {
      logger6.warn(`Model "${model}" not found in device schemas`);
      this.stController.setModel(model, []);
      return;
    }
    const actions = Array.isArray(schema.cmdSchema) ? schema.cmdSchema : [];
    this.stController.setModel(model, actions);
    if (actions.length === 0) {
      logger6.warn(`No actions found for model "${model}" \u2014 settings decoding will use raw IDs`);
    } else {
      logger6.debug(`Loaded ${actions.length} actions for model "${model}", sectioned=${schema.sectioned}`);
    }
  }
  getConfigFields() {
    return GetConfigFields(this.discoveredDevices);
  }
  /** Returns the effective host IP, resolved from MAC→IP via discoveredDevices (auto) or config.host (manual). */
  get host() {
    return resolveHost(this.config, this.discoveredDevices);
  }
  /** Returns discovered devices for use in actions/config */
  get devices() {
    return this.discoveredDevices;
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  updateVariableValues() {
    UpdateVariableValues(this);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2xvZ2dpbmcudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL3V0aWwudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvc2hhcmVkLXVkcC1zb2NrZXQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2hvc3QtYXBpL2NvbnRleHQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvYmFzZS50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9lbnVtcy50cyIsICIuLi8uLi9zcmMvY29uZmlnLnRzIiwgIi4uLy4uL3NyYy92YXJpYWJsZXMudHMiLCAiLi4vLi4vc3JjL3VwZ3JhZGVzLnRzIiwgIi4uLy4uL3NyYy90eXBlcy50cyIsICIuLi8uLi9zcmMvYnVpbGQtY29tbWFuZHMudHMiLCAiLi4vLi4vc3JjL2FjdGlvbnMudHMiLCAiLi4vLi4vc3JjL3NldHRpbmdzUGFyc2VyLnRzIiwgIi4uLy4uL3NyYy9mZWVkYmFja3MudHMiLCAiLi4vLi4vc3JjL3N0Y29udHJvbGxlci50cyIsICIuLi8uLi9zcmMvZGFudGUudHMiLCAiLi4vLi4vc3JjL21haW4udHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5pbXBvcnQgeyBSZWdleCwgdHlwZSBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsIHR5cGUgSnNvbk9iamVjdCwgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignQ29uZmlnJylcblxuZXhwb3J0IHR5cGUgTW9kdWxlQ29uZmlnID0gSnNvbk9iamVjdCAmIHtcblx0LyoqIE1BQyBvZiB0aGUgc2VsZWN0ZWQgZGlzY292ZXJlZCBkZXZpY2UgKGUuZy4gXCIwMDoxZDpjMTo5YjphNjpjZFwiKSwgb3IgJycgZm9yIG1hbnVhbCBtb2RlICovXG5cdGRldmljZU1hYzogc3RyaW5nXG5cdC8qKiBNYW51YWwgSVAgYWRkcmVzcyBcdTIwMTQgb25seSB1c2VkIHdoZW4gZGV2aWNlTWFjIGlzICcnICovXG5cdGhvc3Q6IHN0cmluZ1xuXHQvKiogTWFudWFsIG1vZGVsIHNlbGVjdGlvbiBcdTIwMTQgb25seSB1c2VkIHdoZW4gZGV2aWNlTWFjIGlzICcnICovXG5cdGFjdGl2ZU1vZGVsOiBzdHJpbmdcblx0LyoqIEVuYWJsZSBwYXJzaW5nIG9mIHVuc3VwcG9ydGVkIFNUIGRldmljZXMgKi9cblx0ZGV2TW9kZTogYm9vbGVhblxufVxuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBDRU5UUkFMSVpFRCBERVZJQ0UgU0NIRU1BIENBQ0hFXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBBbGwgZGV2aWNlIEpTT04gZmlsZXMgYXJlIGxvYWRlZCBvbmNlIGludG8gbWVtb3J5IGhlcmUuIE90aGVyIG1vZHVsZXMgc2hvdWxkXG4vLyB1c2UgZ2V0RGV2aWNlc0ZvbGRlcigpLCBnZXREZXZpY2VTY2hlbWFzKCksIGFuZCBnZXREZXZpY2VTY2hlbWEoKSBpbnN0ZWFkIG9mXG4vLyByZWFkaW5nIGZpbGVzIGRpcmVjdGx5LiBDYWxsIHJlbG9hZERldmljZVNjaGVtYXMoKSBhZnRlciB3cml0aW5nIHRvIGEgZmlsZS5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuLyoqXG4gKiBEZXRlcm1pbmVzIHRoZSBjb3JyZWN0IGRldmljZXMgZm9sZGVyIHBhdGggd2l0aCBmYWxsYmFjayBzdXBwb3J0LlxuICogQ2hlY2tzIHByaW1hcnkgcGF0aCBmaXJzdCwgdGhlbiBmYWxsYmFjaywgdGhlbiB0aHJvd3MgZXJyb3IgaWYgbmVpdGhlciBleGlzdHMuXG4gKi9cbmZ1bmN0aW9uIHJlc29sdmVEZXZpY2VzRm9sZGVyKCk6IHN0cmluZyB7XG5cdGNvbnN0IHByaW1hcnlQYXRoID0gcGF0aC5qb2luKGltcG9ydC5tZXRhLmRpcm5hbWUsICcuLi9kZXZpY2VzJylcblx0Y29uc3QgZmFsbGJhY2tQYXRoID0gcGF0aC5qb2luKGltcG9ydC5tZXRhLmRpcm5hbWUsICcuL2RldmljZXMnKVxuXG5cdC8vIENoZWNrIHByaW1hcnkgcGF0aFxuXHRpZiAoZnMuZXhpc3RzU3luYyhwcmltYXJ5UGF0aCkpIHtcblx0XHRsb2dnZXIuZGVidWcoYFVzaW5nIGRldmljZXMgZm9sZGVyOiAke3ByaW1hcnlQYXRofWApXG5cdFx0cmV0dXJuIHByaW1hcnlQYXRoXG5cdH1cblxuXHQvLyBDaGVjayBmYWxsYmFjayBwYXRoXG5cdGlmIChmcy5leGlzdHNTeW5jKGZhbGxiYWNrUGF0aCkpIHtcblx0XHRsb2dnZXIud2FybihgUHJpbWFyeSBkZXZpY2VzIGZvbGRlciBub3QgZm91bmQsIHVzaW5nIGZhbGxiYWNrOiAke2ZhbGxiYWNrUGF0aH1gKVxuXHRcdHJldHVybiBmYWxsYmFja1BhdGhcblx0fVxuXG5cdC8vIE5laXRoZXIgcGF0aCBleGlzdHMgLSBmYXRhbCBlcnJvclxuXHRjb25zdCBlcnJvck1zZyA9IGBEZXZpY2VzIGZvbGRlciBub3QgZm91bmQhXFxuVHJpZWQ6XFxuICAtICR7cHJpbWFyeVBhdGh9XFxuICAtICR7ZmFsbGJhY2tQYXRofVxcbk1vZHVsZSBjYW5ub3QgY29udGludWUgd2l0aG91dCBkZXZpY2Ugc2NoZW1hcy5gXG5cdGxvZ2dlci5lcnJvcihlcnJvck1zZylcblx0dGhyb3cgbmV3IEVycm9yKGVycm9yTXNnKVxufVxuXG4vLyBSZXNvbHZlIHRoZSBkZXZpY2VzIGZvbGRlciBwYXRoICh3aXRoIGV4aXN0ZW5jZSBjaGVjayBhbmQgZmFsbGJhY2spXG5jb25zdCBkZXZpY2VzRm9sZGVyID0gcmVzb2x2ZURldmljZXNGb2xkZXIoKVxuXG4vLyBJbi1tZW1vcnkgY2FjaGUgb2YgYWxsIGRldmljZSBzY2hlbWFzLCBrZXllZCBieSBtb2RlbCBudW1iZXJcbmxldCBkZXZpY2VTY2hlbWFzQ2FjaGU6IFJlY29yZDxzdHJpbmcsIGFueT4gfCBudWxsID0gbnVsbFxuXG4vKipcbiAqIFJldHVybnMgdGhlIGFic29sdXRlIHBhdGggdG8gdGhlIGRldmljZXMgZm9sZGVyLlxuICogVXNlIHRoaXMgaW5zdGVhZCBvZiByZWRlZmluaW5nIHRoZSBwYXRoIGluIGV2ZXJ5IGZpbGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREZXZpY2VzRm9sZGVyKCk6IHN0cmluZyB7XG5cdHJldHVybiBkZXZpY2VzRm9sZGVyXG59XG5cbi8qKlxuICogTG9hZHMgYWxsIGRldmljZSBKU09OIGZpbGVzIGZyb20gdGhlIGRldmljZXMgZm9sZGVyIGludG8gbWVtb3J5LlxuICogVGhpcyBzaG91bGQgb25seSBiZSBjYWxsZWQgb25jZSBhdCBpbml0aWFsaXphdGlvbiwgb3IgYWZ0ZXIgYSBmaWxlIGlzIHdyaXR0ZW4uXG4gKi9cbmZ1bmN0aW9uIGxvYWREZXZpY2VTY2hlbWFzKCk6IFJlY29yZDxzdHJpbmcsIGFueT4ge1xuXHRjb25zdCBzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCBhbnk+ID0ge31cblx0dHJ5IHtcblx0XHRjb25zdCBmaWxlcyA9IGZzLnJlYWRkaXJTeW5jKGRldmljZXNGb2xkZXIpLmZpbHRlcigoZikgPT4gZi5lbmRzV2l0aCgnLmpzb24nKSlcblxuXHRcdGZvciAoY29uc3QgZiBvZiBmaWxlcykge1xuXHRcdFx0Y29uc3QgZnVsbFBhdGggPSBwYXRoLmpvaW4oZGV2aWNlc0ZvbGRlciwgZilcblx0XHRcdGNvbnN0IGpzb24gPSBKU09OLnBhcnNlKGZzLnJlYWRGaWxlU3luYyhmdWxsUGF0aCwgJ3V0ZjgnKSlcblx0XHRcdGlmIChqc29uPy5tb2RlbCkge1xuXHRcdFx0XHRzY2hlbWFzW1N0cmluZyhqc29uLm1vZGVsKV0gPSBqc29uXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0bG9nZ2VyLmRlYnVnKGBMb2FkZWQgJHtPYmplY3Qua2V5cyhzY2hlbWFzKS5sZW5ndGh9IGRldmljZSBzY2hlbWFzIGludG8gY2FjaGVgKVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0bG9nZ2VyLmVycm9yKGBGYWlsZWQgdG8gbG9hZCBkZXZpY2Ugc2NoZW1hczogJHtlfWApXG5cdH1cblx0cmV0dXJuIHNjaGVtYXNcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGFsbCBkZXZpY2Ugc2NoZW1hcyBmcm9tIHRoZSBjYWNoZS5cbiAqIEluaXRpYWxpemVzIHRoZSBjYWNoZSBvbiBmaXJzdCBjYWxsLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlU2NoZW1hcygpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHtcblx0aWYgKCFkZXZpY2VTY2hlbWFzQ2FjaGUpIHtcblx0XHRkZXZpY2VTY2hlbWFzQ2FjaGUgPSBsb2FkRGV2aWNlU2NoZW1hcygpXG5cdH1cblx0cmV0dXJuIGRldmljZVNjaGVtYXNDYWNoZVxufVxuXG4vKipcbiAqIFJldHVybnMgYSBzcGVjaWZpYyBkZXZpY2Ugc2NoZW1hIGJ5IG1vZGVsIG51bWJlci5cbiAqIFJldHVybnMgdW5kZWZpbmVkIGlmIHRoZSBtb2RlbCBkb2Vzbid0IGV4aXN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsOiBzdHJpbmcpOiBhbnkge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdHJldHVybiBzY2hlbWFzW21vZGVsXVxufVxuXG4vKipcbiAqIFJlbG9hZHMgYWxsIGRldmljZSBzY2hlbWFzIGZyb20gZGlzay5cbiAqIENhbGwgdGhpcyBhZnRlciB3cml0aW5nIHRvIGEgZGV2aWNlIEpTT04gZmlsZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlbG9hZERldmljZVNjaGVtYXMoKTogdm9pZCB7XG5cdGxvZ2dlci5pbmZvKCdSZWxvYWRpbmcgZGV2aWNlIHNjaGVtYXMgZnJvbSBkaXNrLi4uJylcblx0ZGV2aWNlU2NoZW1hc0NhY2hlID0gbG9hZERldmljZVNjaGVtYXMoKVxufVxuXG4vKipcbiAqIFJldHVybnMgYSBsaXN0IG9mIGF2YWlsYWJsZSBtb2RlbCBudW1iZXJzLCBzb3J0ZWQuXG4gKi9cbmZ1bmN0aW9uIGxvYWRBdmFpbGFibGVNb2RlbHMoKTogc3RyaW5nW10ge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdHJldHVybiBPYmplY3Qua2V5cyhzY2hlbWFzKS5zb3J0KClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEdldENvbmZpZ0ZpZWxkcyhkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW10pOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdGNvbnN0IG1vZGVscyA9IGxvYWRBdmFpbGFibGVNb2RlbHMoKVxuXG5cdC8vIERyb3Bkb3duIGlkIGlzIHRoZSBkZXZpY2UgTUFDIFx1MjAxNCBzdGFibGUgYWNyb3NzIElQIGNoYW5nZXMuXG5cdC8vIEVtcHR5IGlkID0gTWFudWFsIG1vZGUuXG5cdGNvbnN0IGRldmljZUNob2ljZXMgPSBbXG5cdFx0eyBpZDogJycsIGxhYmVsOiAnTWFudWFsIChlbnRlciBJUCArIG1vZGVsIGJlbG93KScgfSxcblx0XHQuLi5kaXNjb3ZlcmVkRGV2aWNlcy5tYXAoKGQpID0+ICh7XG5cdFx0XHRpZDogZC5tYWMgPz8gJycsXG5cdFx0XHRsYWJlbDogYE1vZGVsICR7ZC5tb2RlbH0gWyR7ZC5tYWN9XSBAICR7ZC5pcH1gLFxuXHRcdH0pKSxcblx0XVxuXG5cdHJldHVybiBbXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIERldmljZSBzZWxlY3Rpb24gZHJvcGRvd24gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gU3RvcmVzIHRoZSBNQUMgc28gcmUtZGlzY292ZXJ5IHdpdGggYSBjaGFuZ2VkIElQIHN0aWxsIG1hdGNoZXMuXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdGlkOiAnZGV2aWNlTWFjJyxcblx0XHRcdGxhYmVsOiAnRGV2aWNlJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogJycsXG5cdFx0XHRjaG9pY2VzOiBkZXZpY2VDaG9pY2VzLFxuXHRcdFx0dG9vbHRpcDogJ1NlbGVjdCBhbiBhdXRvLWRpc2NvdmVyZWQgU3R1ZGlvIFRlY2hub2xvZ2llcyBkZXZpY2UsIG9yIGNob29zZSBNYW51YWwgdG8gZW50ZXIgYW4gSVAgYWRkcmVzcy4nLFxuXHRcdH0sXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgTWFudWFsIElQIGVudHJ5IFx1MjAxNCBvbmx5IHZpc2libGUgaW4gbWFudWFsIG1vZGUgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0e1xuXHRcdFx0dHlwZTogJ3RleHRpbnB1dCcsXG5cdFx0XHRpZDogJ2hvc3QnLFxuXHRcdFx0bGFiZWw6ICdUYXJnZXQgSVAnLFxuXHRcdFx0d2lkdGg6IDgsXG5cdFx0XHRkZWZhdWx0OiAnJyxcblx0XHRcdHJlZ2V4OiBSZWdleC5JUCxcblx0XHRcdGlzVmlzaWJsZUV4cHJlc3Npb246IGAhJChvcHRpb25zOmRldmljZU1hYylgLFxuXHRcdFx0dG9vbHRpcDogJ0VudGVyIHRoZSBJUCBhZGRyZXNzIG9mIHRoZSBkZXZpY2UgbWFudWFsbHkuJyxcblx0XHR9LFxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIE1hbnVhbCBtb2RlbCBzZWxlY3RvciBcdTIwMTQgb25seSB2aXNpYmxlIGluIG1hbnVhbCBtb2RlIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdHtcblx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRpZDogJ2FjdGl2ZU1vZGVsJyxcblx0XHRcdGxhYmVsOiAnQWN0aXZlIERldmljZSBNb2RlbCcsXG5cdFx0XHR3aWR0aDogOCxcblx0XHRcdGRlZmF1bHQ6IG1vZGVsc1swXSA/PyAnJyxcblx0XHRcdGNob2ljZXM6IG1vZGVscy5tYXAoKG1vZGVsKSA9PiAoe1xuXHRcdFx0XHRpZDogbW9kZWwsXG5cdFx0XHRcdGxhYmVsOiBgTW9kZWwgJHttb2RlbH1gLFxuXHRcdFx0fSkpLFxuXHRcdFx0aXNWaXNpYmxlRXhwcmVzc2lvbjogYCEkKG9wdGlvbnM6ZGV2aWNlTWFjKWAsXG5cdFx0XHR0b29sdGlwOiAnU2VsZWN0IHdoaWNoIFN0dWRpbyBUZWNobm9sb2dpZXMgbW9kZWwgaXMgYWN0aXZlIGZvciBhY3Rpb25zIGFuZCBmZWVkYmFja3MuJyxcblx0XHR9LFxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIERldiBNb2RlIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdHtcblx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRpZDogJ2Rldk1vZGUnLFxuXHRcdFx0bGFiZWw6ICdEZXYgTW9kZScsXG5cdFx0XHR3aWR0aDogMTIsXG5cdFx0XHRkZWZhdWx0OiBmYWxzZSxcblx0XHRcdHRvb2x0aXA6ICdFbmFibGUgdG8gYWxsb3cgcGFyc2luZyBvZiBTVCBEZXZpY2VzIG5vdCBjdXJyZW50bHkgc3VwcG9ydGVkJyxcblx0XHR9LFxuXHRdXG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgZWZmZWN0aXZlIGhvc3QgSVAuXG4gKiBBdXRvIG1vZGUgKGRldmljZU1hYyBzZXQpOiBmaW5kcyB0aGUgY3VycmVudCBJUCBvZiB0aGUgZGlzY292ZXJlZCBkZXZpY2Ugd2l0aCB0aGF0IE1BQy5cbiAqIE1hbnVhbCBtb2RlIChkZXZpY2VNYWMgZW1wdHkpOiByZXR1cm5zIHRoZSBtYW51YWxseSBlbnRlcmVkIGhvc3QgSVAuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlSG9zdChjb25maWc6IE1vZHVsZUNvbmZpZywgZGlzY292ZXJlZERldmljZXM6IERldmljZUluZm9bXSk6IHN0cmluZyB7XG5cdGlmIChjb25maWcuZGV2aWNlTWFjKSB7XG5cdFx0Y29uc3QgZGV2aWNlID0gZGlzY292ZXJlZERldmljZXMuZmluZCgoZCkgPT4gZC5tYWMgPT09IGNvbmZpZy5kZXZpY2VNYWMpXG5cdFx0cmV0dXJuIGRldmljZT8uaXAgPz8gJydcblx0fVxuXHRyZXR1cm4gU3RyaW5nKGNvbmZpZy5ob3N0ID8/ICcnKVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBtb2RlbC5cbiAqIEF1dG8gbW9kZTogdXNlcyB0aGUgbW9kZWwgZnJvbSB0aGUgZGlzY292ZXJlZCBkZXZpY2UgbWF0Y2hpbmcgdGhlIHN0b3JlZCBNQUMuXG4gKiBNYW51YWwgbW9kZTogdXNlcyB0aGUgbWFudWFsbHkgc2VsZWN0ZWQgYWN0aXZlTW9kZWwuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlTW9kZWwoY29uZmlnOiBNb2R1bGVDb25maWcsIGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10pOiBzdHJpbmcge1xuXHRpZiAoY29uZmlnLmRldmljZU1hYykge1xuXHRcdGNvbnN0IGRldmljZSA9IGRpc2NvdmVyZWREZXZpY2VzLmZpbmQoKGQpID0+IGQubWFjID09PSBjb25maWcuZGV2aWNlTWFjKVxuXHRcdGxvZ2dlci5kZWJ1ZyhgcmVzb2x2ZU1vZGVsOiBkZXZpY2VNYWM9XCIke2NvbmZpZy5kZXZpY2VNYWN9XCIsIGZvdW5kIGRldmljZTogJHtkZXZpY2U/Lm1vZGVsID8/ICdub25lJ31gKVxuXHRcdHJldHVybiBkZXZpY2U/Lm1vZGVsID8/ICcnXG5cdH1cblx0bG9nZ2VyLmRlYnVnKGByZXNvbHZlTW9kZWw6IG1hbnVhbCBtb2RlLCBhY3RpdmVNb2RlbD1cIiR7Y29uZmlnLmFjdGl2ZU1vZGVsfVwiYClcblx0cmV0dXJuIFN0cmluZyhjb25maWcuYWN0aXZlTW9kZWwgPz8gJycpXG59XG4iLCAiaW1wb3J0IHR5cGUgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuXG4vKipcbiAqIERlZmluZSBDb21wYW5pb24gdmFyaWFibGVzIGZvciB0aGlzIG1vZHVsZS5cbiAqIFZhcmlhYmxlcyBjYW4gYmUgdXNlZCB0byBkaXNwbGF5IGR5bmFtaWMgc3RhdGUgaW4gYnV0dG9uIGxhYmVscywgdHJpZ2dlcnMsIGV0Yy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0c2VsZi5zZXRWYXJpYWJsZURlZmluaXRpb25zKHtcblx0XHRtb2RlbDogeyBuYW1lOiAnRGV2aWNlIE1vZGVsIE51bWJlcicgfSxcblx0XHRtb2RlbE5hbWU6IHsgbmFtZTogJ0RldmljZSBNb2RlbCBOYW1lIChGdWxsIERlc2NyaXB0aW9uKScgfSxcblx0XHRtYW51ZmFjdHVyZXI6IHsgbmFtZTogJ0RldmljZSBNYW51ZmFjdHVyZXInIH0sXG5cdFx0ZmlybXdhcmU6IHsgbmFtZTogJ0RldmljZSBGaXJtd2FyZSBWZXJzaW9uJyB9LFxuXHRcdGRhbnRlRlc6IHsgbmFtZTogJ0RhbnRlIE1vZHVsZSBGaXJtd2FyZSBWZXJzaW9uJyB9LFxuXHRcdG1hYzogeyBuYW1lOiAnRGV2aWNlIE1BQyBBZGRyZXNzJyB9LFxuXHRcdGlwOiB7IG5hbWU6ICdEZXZpY2UgSVAgQWRkcmVzcycgfSxcblx0fSlcbn1cblxuY29uc3QgQ0xFQVJFRF9WQVJJQUJMRVMgPSB7XG5cdG1vZGVsOiAnJyxcblx0bW9kZWxOYW1lOiAnJyxcblx0bWFudWZhY3R1cmVyOiAnJyxcblx0ZmlybXdhcmU6ICcnLFxuXHRkYW50ZUZXOiAnJyxcblx0bWFjOiAnJyxcblx0aXA6ICcnLFxufVxuXG4vKipcbiAqIFVwZGF0ZSB2YXJpYWJsZSB2YWx1ZXMgZnJvbSBkaXNjb3ZlcmVkIGRldmljZSBpbmZvcm1hdGlvbi5cbiAqIE9ubHkgcG9wdWxhdGVzIHZhcmlhYmxlcyB3aGVuIHRoZSBjdXJyZW50IGhvc3QgaXMgYXV0aG9yaXplZC5cbiAqIENsZWFycyBhbGwgdmFyaWFibGVzIGlmIHRoZSBkZXZpY2UgaXMgbm90IGF1dGhvcml6ZWQgb3Igbm90IGZvdW5kLlxuICovXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlVmFyaWFibGVWYWx1ZXMoc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3QgY3VycmVudEhvc3QgPSBzZWxmLmhvc3RcblxuXHQvLyBDbGVhciB2YXJpYWJsZXMgaWYgbm8gaG9zdCBjb25maWd1cmVkIG9yIGRldmljZSBpcyBub3QgYXV0aG9yaXplZFxuXHRpZiAoIWN1cnJlbnRIb3N0IHx8ICFzZWxmLnN0Q29udHJvbGxlci5pc0RldmljZUF1dGhvcml6ZWQoY3VycmVudEhvc3QpKSB7XG5cdFx0c2VsZi5zZXRWYXJpYWJsZVZhbHVlcyhDTEVBUkVEX1ZBUklBQkxFUylcblx0XHRyZXR1cm5cblx0fVxuXG5cdGNvbnN0IGRldmljZSA9IHNlbGYuZGV2aWNlcy5maW5kKChkKSA9PiBkLmlwID09PSBjdXJyZW50SG9zdClcblx0aWYgKGRldmljZSkge1xuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoe1xuXHRcdFx0bW9kZWw6IGRldmljZS5tb2RlbCB8fCAnJyxcblx0XHRcdG1vZGVsTmFtZTogZGV2aWNlLm1vZGVsTmFtZSB8fCAnJyxcblx0XHRcdG1hbnVmYWN0dXJlcjogZGV2aWNlLm1hbnVmYWN0dXJlciB8fCAnJyxcblx0XHRcdGZpcm13YXJlOiBkZXZpY2UuZmlybXdhcmVNYWluIHx8ICcnLFxuXHRcdFx0ZGFudGVGVzogZGV2aWNlLmRhbnRlRmlybXdhcmUgfHwgJycsXG5cdFx0XHRtYWM6IGRldmljZS5tYWMgfHwgJycsXG5cdFx0XHRpcDogZGV2aWNlLmlwLFxuXHRcdH0pXG5cdH0gZWxzZSB7XG5cdFx0Ly8gQXV0aG9yaXplZCBidXQgbm90IGluIGRpc2NvdmVyZWQgbGlzdCAobWFudWFsIElQIHRoYXQgcHJvYmVkIHN1Y2Nlc3NmdWxseSlcblx0XHQvLyBXZSBrbm93IGl0J3MgdGhlIHJpZ2h0IGRldmljZSBidXQgZG9uJ3QgaGF2ZSBmdWxsIGluZm8geWV0XG5cdFx0c2VsZi5zZXRWYXJpYWJsZVZhbHVlcyh7XG5cdFx0XHQuLi5DTEVBUkVEX1ZBUklBQkxFUyxcblx0XHRcdGlwOiBjdXJyZW50SG9zdCxcblx0XHR9KVxuXHR9XG59XG4iLCAiaW1wb3J0IHR5cGUgeyBDb21wYW5pb25TdGF0aWNVcGdyYWRlU2NyaXB0IH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi9jb25maWcuanMnXG5cbmV4cG9ydCBjb25zdCBVcGdyYWRlU2NyaXB0czogQ29tcGFuaW9uU3RhdGljVXBncmFkZVNjcmlwdDxNb2R1bGVDb25maWc+W10gPSBbXG5cdC8qXG5cdCAqIFBsYWNlIHlvdXIgdXBncmFkZSBzY3JpcHRzIGhlcmVcblx0ICogUmVtZW1iZXIgdGhhdCBvbmNlIGl0IGhhcyBiZWVuIGFkZGVkIGl0IGNhbm5vdCBiZSByZW1vdmVkIVxuXHQgKi9cblx0Ly8gZnVuY3Rpb24gKGNvbnRleHQsIHByb3BzKSB7XG5cdC8vIFx0cmV0dXJuIHtcblx0Ly8gXHRcdHVwZGF0ZWRDb25maWc6IG51bGwsXG5cdC8vIFx0XHR1cGRhdGVkQWN0aW9uczogW10sXG5cdC8vIFx0XHR1cGRhdGVkRmVlZGJhY2tzOiBbXSxcblx0Ly8gXHR9XG5cdC8vIH0sXG5dXG4iLCAiZXhwb3J0IHR5cGUgRGV2aWNlSW5mbyA9IHtcblx0bW9kZWw6IHN0cmluZyAvLyBNb2RlbCBudW1iZXIgKGUuZy4sIFwiMzc0QVwiKVxuXHRtb2RlbE5hbWU/OiBzdHJpbmcgLy8gRnVsbCBtb2RlbCBkZXNjcmlwdGlvbiAoZS5nLiwgXCJNb2RlbCAzNzRBIEludGVyY29tIEJlbHRwYWNrXCIpXG5cdGlwOiBzdHJpbmdcblx0bmFtZT86IHN0cmluZyAvLyBEYW50ZSBkZXZpY2UgbmFtZSAodXNlci1jb25maWd1cmFibGUgbGFiZWwsIGUuZy4gXCJTVC1NMzc0QS1CZWx0cGFja1wiKVxuXHRtYW51ZmFjdHVyZXI/OiBzdHJpbmcgLy8gZS5nLiBcIlN0dWRpbyBUZWNobm9sb2dpZXMsIEluYy5cIlxuXHRmaXJtd2FyZU1haW4/OiBzdHJpbmcgLy8gRGV2aWNlIGZpcm13YXJlIHZlcnNpb24gZnJvbSBEYW50ZSBkaXNjb3ZlcnkgKGUuZy4sIFwiNC45LjBcIilcblx0ZGFudGVGaXJtd2FyZT86IHN0cmluZyAvLyBEYW50ZSBtb2R1bGUgZmlybXdhcmUgdmVyc2lvblxuXHRtYWM/OiBzdHJpbmdcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIFN0dWRpby1UIENvbW1hbmQgSUQgQ29uc3RhbnRzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuZXhwb3J0IGNvbnN0IENNRF9HRVRfRklSTVdBUkUgPSAweDAwIC8vIFJlcXVlc3QgZGV2aWNlIGZpcm13YXJlIHZlcnNpb25cbmV4cG9ydCBjb25zdCBDTURfTUlDX1BSRSA9IDB4MDIgLy8gTWljIHByZWFtcCByYXcgc2V0IChnYWluLCBwaGFudG9tKSBcdTIwMTQgcG9zaXRpb25hbCBieXRlcywgbm8gc2V0dGluZyBJRHNcbmV4cG9ydCBjb25zdCBDTURfQlVTX0dFVCA9IDB4MDMgLy8gSGVhcnRiZWF0IC8ga2VlcGFsaXZlIHBpbmdcbmV4cG9ydCBjb25zdCBDTURfQlVTX1NFVCA9IDB4MDQgLy8gU2V0IHNldHRpbmcgb24gc3BlY2lmaWMgYnVzL2NoYW5uZWxcbmV4cG9ydCBjb25zdCBDTURfSEVBRFBIT05FID0gMHgwNSAvLyBIZWFkcGhvbmUgY29udHJvbHNcbmV4cG9ydCBjb25zdCBDTURfQlVUVE9OX01PREUgPSAweDA3IC8vIEJ1dHRvbiBtb2RlIGNvbmZpZ3VyYXRpb25cbmV4cG9ydCBjb25zdCBDTURfU1lTVEVNID0gMHgwOSAvLyBTeXN0ZW0tbGV2ZWwgY29tbWFuZHNcbmV4cG9ydCBjb25zdCBDTURfR0VUX0FMTF9TRVRUSU5HUyA9IDB4MGEgLy8gUmVxdWVzdCBhbGwgY3VycmVudCBzZXR0aW5ncyBmcm9tIGRldmljZVxuZXhwb3J0IGNvbnN0IENNRF9TRVRUSU5HU19QVVNIID0gMHgwYiAvLyBVbnNvbGljaXRlZCBzZXR0aW5ncyB1cGRhdGUgZnJvbSBkZXZpY2VcbmV4cG9ydCBjb25zdCBDTURfREVWX1NQRUMgPSAweDBkIC8vIERldmljZS1zcGVjaWZpYyBzZXR0aW5nIGdldC9zZXQgd2l0aCBBQ0tcbmV4cG9ydCBjb25zdCBDTURfUkVTRVRfREVWSUNFID0gMHgwZSAvLyBGYWN0b3J5IHJlc2V0IGNvbW1hbmRcbmV4cG9ydCBjb25zdCBDTURfR0xPQkFMX01JQ19LSUxMID0gMHgxMCAvLyBFbWVyZ2VuY3kgbWljIGtpbGwgKGFsbCBjaGFubmVscylcbmV4cG9ydCBjb25zdCBDTURfTUlDX1BSRV9CVVMgPSAweDEyIC8vIE1pYy9wcmVhbXAgc2V0dGluZ3MgcGVyIGJ1cyAoZ2FpbiwgcGhhbnRvbSwgZXRjKVxuZXhwb3J0IGNvbnN0IENNRF9DSEFOTkVMID0gMHgxNCAvLyBDaGFubmVsLXNwZWNpZmljIGNvbnRyb2xzXG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBDb21tYW5kIE5hbWUgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuZXhwb3J0IGZ1bmN0aW9uIGdldENvbW1hbmROYW1lKGNtZElkOiBudW1iZXIpOiBzdHJpbmcge1xuXHRzd2l0Y2ggKGNtZElkKSB7XG5cdFx0Y2FzZSBDTURfR0VUX0ZJUk1XQVJFOlxuXHRcdFx0cmV0dXJuICdHZXQgRmlybXdhcmUgVmVyc2lvbidcblx0XHRjYXNlIENNRF9NSUNfUFJFOlxuXHRcdFx0cmV0dXJuICdNaWMgUHJlYW1wJ1xuXHRcdGNhc2UgQ01EX0JVU19HRVQ6XG5cdFx0XHRyZXR1cm4gJ0hlYXJ0YmVhdCdcblx0XHRjYXNlIENNRF9CVVNfU0VUOlxuXHRcdFx0cmV0dXJuICdTZXQgQnVzIFNldHRpbmcnXG5cdFx0Y2FzZSBDTURfSEVBRFBIT05FOlxuXHRcdFx0cmV0dXJuICdIZWFkcGhvbmUgQ29udHJvbCdcblx0XHRjYXNlIENNRF9CVVRUT05fTU9ERTpcblx0XHRcdHJldHVybiAnQnV0dG9uIE1vZGUnXG5cdFx0Y2FzZSBDTURfU1lTVEVNOlxuXHRcdFx0cmV0dXJuICdTeXN0ZW0gQ29tbWFuZCdcblx0XHRjYXNlIENNRF9HRVRfQUxMX1NFVFRJTkdTOlxuXHRcdFx0cmV0dXJuICdSZXF1ZXN0IEFsbCBTZXR0aW5ncydcblx0XHRjYXNlIENNRF9TRVRUSU5HU19QVVNIOlxuXHRcdFx0cmV0dXJuICdTZXR0aW5ncyBQdXNoJ1xuXHRcdGNhc2UgQ01EX01JQ19QUkVfQlVTOlxuXHRcdFx0cmV0dXJuICdNaWMvUHJlIEJ1cydcblx0XHRjYXNlIENNRF9ERVZfU1BFQzpcblx0XHRcdHJldHVybiAnRGV2aWNlIFNldHRpbmcnXG5cdFx0Y2FzZSBDTURfQ0hBTk5FTDpcblx0XHRcdHJldHVybiAnQ2hhbm5lbCBTZXR0aW5nJ1xuXHRcdGNhc2UgQ01EX1JFU0VUX0RFVklDRTpcblx0XHRcdHJldHVybiAnUmVzZXQgRGV2aWNlJ1xuXHRcdGNhc2UgQ01EX0dMT0JBTF9NSUNfS0lMTDpcblx0XHRcdHJldHVybiAnR2xvYmFsIE1pYyBLaWxsJ1xuXHRcdGRlZmF1bHQ6XG5cdFx0XHRyZXR1cm4gYGNtZF8weCR7Y21kSWQudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJyl9YFxuXHR9XG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBJRCBHZW5lcmF0aW9uIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogQ3JlYXRlcyBhIGNvbnNpc3RlbnQgSUQgZm9yIGFjdGlvbnMsIGZlZWRiYWNrcywgYW5kIHN0YXRlIGtleXMuXG4gKiBGb3JtYXQ6IGAke21vZGVsfV8ke2NtZF9pZH1fJHtidXNDaH1fJHtpZH1gIGZvciBjb21tYW5kcyB3aXRoIGJ1c0NoIChlLmcuLCBcIjUzMDRfMTRfMF8wXCIpXG4gKiBGb3JtYXQ6IGAke21vZGVsfV8ke2NtZF9pZH1fJHtpZH1gIGZvciBjb21tYW5kcyB3aXRob3V0IGJ1c0NoIChlLmcuLCBcIjUzMDRfMTJfZFwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gbWFrZVNldHRpbmdJZChcblx0bW9kZWw6IHN0cmluZyxcblx0Y21kSWQ6IG51bWJlciB8IHN0cmluZyxcblx0c2V0dGluZ0lkOiBudW1iZXIgfCBzdHJpbmcsXG5cdGJ1c0NoPzogbnVtYmVyIHwgc3RyaW5nLFxuKTogc3RyaW5nIHtcblx0Y29uc3QgY21kID0gdHlwZW9mIGNtZElkID09PSAnbnVtYmVyJyA/IGNtZElkLnRvU3RyaW5nKDE2KSA6IGNtZElkXG5cdGNvbnN0IGlkID0gdHlwZW9mIHNldHRpbmdJZCA9PT0gJ251bWJlcicgPyBzZXR0aW5nSWQudG9TdHJpbmcoMTYpIDogc2V0dGluZ0lkXG5cblx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRjb25zdCBjaCA9IHR5cGVvZiBidXNDaCA9PT0gJ251bWJlcicgPyBidXNDaC50b1N0cmluZygxNikgOiBidXNDaFxuXHRcdHJldHVybiBgJHttb2RlbH1fJHtjbWR9XyR7Y2h9XyR7aWR9YFxuXHR9XG5cblx0cmV0dXJuIGAke21vZGVsfV8ke2NtZH1fJHtpZH1gXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBIZXggRm9ybWF0dGluZyBIZWxwZXJzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDb252ZXJ0cyBhIG51bWJlciB0byBhIGhleCBzdHJpbmcgd2l0aCAweCBwcmVmaXggYW5kIHBhZGRpbmcuXG4gKiBAcGFyYW0gdmFsdWUgLSBUaGUgbnVtYmVyIHRvIGNvbnZlcnRcbiAqIEBwYXJhbSBwYWRMZW5ndGggLSBOdW1iZXIgb2YgaGV4IGRpZ2l0cyB0byBwYWQgdG8gKGRlZmF1bHQ6IDIpXG4gKiBAcmV0dXJucyBGb3JtYXR0ZWQgaGV4IHN0cmluZyAoZS5nLiwgXCIweDBkXCIsIFwiMHhmZlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gdG9IZXgodmFsdWU6IG51bWJlciwgcGFkTGVuZ3RoID0gMik6IHN0cmluZyB7XG5cdHJldHVybiBgMHgke3ZhbHVlLnRvU3RyaW5nKDE2KS5wYWRTdGFydChwYWRMZW5ndGgsICcwJyl9YFxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIGFycmF5IG9mIGJ5dGVzIHRvIGEgaGV4IHN0cmluZyB3aXRoIDB4IHByZWZpeC5cbiAqIEBwYXJhbSBieXRlcyAtIEFycmF5IG9mIGJ5dGVzIG9yIEJ1ZmZlclxuICogQHJldHVybnMgRm9ybWF0dGVkIGhleCBzdHJpbmcgKGUuZy4sIFwiMHgwYWZmMTJcIilcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGJ5dGVzVG9IZXgoYnl0ZXM6IG51bWJlcltdIHwgQnVmZmVyKTogc3RyaW5nIHtcblx0cmV0dXJuIGAweCR7QXJyYXkuZnJvbShieXRlcylcblx0XHQubWFwKChiKSA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKVxuXHRcdC5qb2luKCcnKX1gXG59XG5cbi8qKlxuICogRm9ybWF0cyBSR0IgY29sb3IgYnl0ZXMgYXMgYSBDU1MgaGV4IGNvbG9yIHN0cmluZy5cbiAqIEBwYXJhbSByIC0gUmVkIGNvbXBvbmVudCAoMC0yNTUpXG4gKiBAcGFyYW0gZyAtIEdyZWVuIGNvbXBvbmVudCAoMC0yNTUpXG4gKiBAcGFyYW0gYiAtIEJsdWUgY29tcG9uZW50ICgwLTI1NSlcbiAqIEByZXR1cm5zIENTUyBoZXggY29sb3Igc3RyaW5nIChlLmcuLCBcIiNGRjAwQUJcIilcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdFJnYkNvbG9yKHI6IG51bWJlciwgZzogbnVtYmVyLCBiOiBudW1iZXIpOiBzdHJpbmcge1xuXHRyZXR1cm4gYCMke1tyLCBnLCBiXVxuXHRcdC5tYXAoKHYpID0+IHYudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXG5cdFx0LmpvaW4oJycpXG5cdFx0LnRvVXBwZXJDYXNlKCl9YFxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgSUQgUGFyc2luZyBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIFBhcnNlcyBhIHNldHRpbmcgSUQgc3RyaW5nIGludG8gaXRzIGNvbXBvbmVudHMuXG4gKiBAcGFyYW0gaWQgLSBTZXR0aW5nIElEIHN0cmluZyAoZS5nLiwgXCIzOTFfZF8wXCIgb3IgXCI1MzA0XzE0XzBfMVwiKVxuICogQHJldHVybnMgUGFyc2VkIGNvbXBvbmVudHMgd2l0aCBoZXggc3RyaW5ncyBjb252ZXJ0ZWQgdG8gbnVtYmVyc1xuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VTZXR0aW5nSWQoaWQ6IHN0cmluZyk6IHsgbW9kZWw6IHN0cmluZzsgY21kSWQ6IG51bWJlcjsgYmFzZUlkOiBudW1iZXIgfSB7XG5cdGNvbnN0IFttb2RlbCwgY21kSWRTdHIsIGlkU3RyXSA9IGlkLnNwbGl0KCdfJylcblx0cmV0dXJuIHtcblx0XHRtb2RlbCxcblx0XHRjbWRJZDogcGFyc2VJbnQoY21kSWRTdHIsIDE2KSxcblx0XHRiYXNlSWQ6IHBhcnNlSW50KGlkU3RyLCAxNiksXG5cdH1cbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIE1vZGVsIERpc3RhbmNlIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogQ2FsY3VsYXRlcyBudW1lcmljIGRpc3RhbmNlIGJldHdlZW4gdHdvIG1vZGVsIG51bWJlcnMuXG4gKiBVc2VkIGZvciBmaW5kaW5nIHNpbWlsYXIgbW9kZWxzIGZvciBzZXR0aW5nIGluZmVyZW5jZS5cbiAqIEBwYXJhbSBtb2RlbEEgLSBGaXJzdCBtb2RlbCBudW1iZXIgKGUuZy4sIFwiMzkxXCIpXG4gKiBAcGFyYW0gbW9kZWxCIC0gU2Vjb25kIG1vZGVsIG51bWJlciAoZS5nLiwgXCIzOTJcIilcbiAqIEByZXR1cm5zIE51bWVyaWMgZGlzdGFuY2UgYmV0d2VlbiBtb2RlbHMsIG9yIEluZmluaXR5IGlmIGVpdGhlciBpcyBub24tbnVtZXJpY1xuICovXG5leHBvcnQgZnVuY3Rpb24gbW9kZWxEaXN0YW5jZShtb2RlbEE6IHN0cmluZywgbW9kZWxCOiBzdHJpbmcpOiBudW1iZXIge1xuXHRjb25zdCBuYSA9IHBhcnNlSW50KG1vZGVsQS5yZXBsYWNlKC9cXEQvZywgJycpLCAxMClcblx0Y29uc3QgbmIgPSBwYXJzZUludChtb2RlbEIucmVwbGFjZSgvXFxEL2csICcnKSwgMTApXG5cdGlmIChOdW1iZXIuaXNOYU4obmEpIHx8IE51bWJlci5pc05hTihuYikpIHJldHVybiBJbmZpbml0eVxuXHRyZXR1cm4gTWF0aC5hYnMobmEgLSBuYilcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIFNjaGVtYSBOb3JtYWxpemF0aW9uIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogTm9ybWFsaXplcyBkZXZpY2Ugc2NoZW1hcyB0byBlbnN1cmUgY21kU2NoZW1hIGlzIGFsd2F5cyBhbiBhcnJheS5cbiAqIFRoaXMgaGVscGVyIGVsaW1pbmF0ZXMgZHVwbGljYXRlIHNjaGVtYSB0cmFuc2Zvcm1hdGlvbiBjb2RlLlxuICogQHBhcmFtIHNjaGVtYXNSYXcgLSBSYXcgc2NoZW1hcyBmcm9tIGdldERldmljZVNjaGVtYXMoKVxuICogQHJldHVybnMgTm9ybWFsaXplZCBzY2hlbWFzIHdpdGggZ3VhcmFudGVlZCBjbWRTY2hlbWEgYXJyYXlzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXROb3JtYWxpemVkU2NoZW1hcyhcblx0c2NoZW1hc1JhdzogUmVjb3JkPHN0cmluZywgYW55Pixcbik6IFJlY29yZDxzdHJpbmcsIHsgbW9kZWw6IHN0cmluZzsgY21kU2NoZW1hOiBhbnlbXSB9PiB7XG5cdGNvbnN0IG5vcm1hbGl6ZWQ6IFJlY29yZDxzdHJpbmcsIHsgbW9kZWw6IHN0cmluZzsgY21kU2NoZW1hOiBhbnlbXSB9PiA9IHt9XG5cdGZvciAoY29uc3QgW21vZGVsLCBqc29uXSBvZiBPYmplY3QuZW50cmllcyhzY2hlbWFzUmF3KSkge1xuXHRcdG5vcm1hbGl6ZWRbbW9kZWxdID0ge1xuXHRcdFx0bW9kZWw6IGpzb24ubW9kZWwsXG5cdFx0XHRjbWRTY2hlbWE6IEFycmF5LmlzQXJyYXkoanNvbi5jbWRTY2hlbWEpID8ganNvbi5jbWRTY2hlbWEgOiBbXSxcblx0XHR9XG5cdH1cblx0cmV0dXJuIG5vcm1hbGl6ZWRcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIEFjdGlvbiBMb29rdXAgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBGaW5kcyBhbiBhY3Rpb24vc2V0dGluZyBpbiB0aGUgc2NoZW1hLCBzdXBwb3J0aW5nIGJvdGggZXhhY3QgbWF0Y2hlcyBhbmQgaWRBZGQgb2Zmc2V0cy5cbiAqIFRoaXMgaGVscGVyIGVsaW1pbmF0ZXMgZHVwbGljYXRlIGFjdGlvbiBsb29rdXAgbG9naWMgYWNyb3NzIG11bHRpcGxlIGZpbGVzLlxuICogQHBhcmFtIHNjaGVtYXMgLSBOb3JtYWxpemVkIGRldmljZSBzY2hlbWFzXG4gKiBAcGFyYW0gbW9kZWwgLSBEZXZpY2UgbW9kZWwgKGUuZy4sIFwiMzkxXCIpXG4gKiBAcGFyYW0gY21kSWQgLSBDb21tYW5kIElEXG4gKiBAcGFyYW0gc2V0dGluZ0lkIC0gU2V0dGluZyBJRCAobWF5IGluY2x1ZGUgaWRBZGQgb2Zmc2V0KVxuICogQHJldHVybnMgTWF0Y2hpbmcgYWN0aW9uL3NldHRpbmcgb3IgdW5kZWZpbmVkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmaW5kQWN0aW9uRm9yU2V0dGluZyhcblx0c2NoZW1hczogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+LFxuXHRtb2RlbDogc3RyaW5nLFxuXHRjbWRJZDogbnVtYmVyLFxuXHRzZXR0aW5nSWQ6IG51bWJlcixcbik6IGFueSB7XG5cdGNvbnN0IHNjaGVtYSA9IHNjaGVtYXNbbW9kZWxdXG5cdGlmICghc2NoZW1hIHx8ICFBcnJheS5pc0FycmF5KHNjaGVtYS5jbWRTY2hlbWEpKSByZXR1cm4gdW5kZWZpbmVkXG5cblx0Ly8gVHJ5IGV4YWN0IG1hdGNoIGZpcnN0XG5cdGxldCBhY3Rpb24gPSBzY2hlbWEuY21kU2NoZW1hLmZpbmQoKHM6IGFueSkgPT4gcy5jbWRfaWQgPT09IGNtZElkICYmIHMuaWQgPT09IHNldHRpbmdJZClcblxuXHQvLyBJZiBubyBleGFjdCBtYXRjaCwgdHJ5IHRvIGZpbmQgYmFzZSBhY3Rpb24gd2l0aCBpZEFkZFxuXHRpZiAoIWFjdGlvbikge1xuXHRcdGFjdGlvbiA9IHNjaGVtYS5jbWRTY2hlbWEuZmluZCgoczogYW55KSA9PiB7XG5cdFx0XHRpZiAocy5jbWRfaWQgIT09IGNtZElkKSByZXR1cm4gZmFsc2Vcblx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gcy5vcHRpb25zPy5maW5kKChvcHQ6IGFueSkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdGlvbj8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiBzZXR0aW5nSWQgbWF0Y2hlcyBiYXNlICsgYW55IGlkQWRkIG9mZnNldFxuXHRcdFx0Y29uc3Qgb2Zmc2V0ID0gc2V0dGluZ0lkIC0gcy5pZFxuXHRcdFx0cmV0dXJuIGlkQWRkT3B0aW9uLmNob2ljZXMuc29tZSgoYzogYW55KSA9PiBjLmlkID09PSBvZmZzZXQpXG5cdFx0fSlcblx0fVxuXG5cdHJldHVybiBhY3Rpb25cbn1cbiIsICIvKipcbiAqIGJ1aWxkLWNvbW1hbmRzLnRzXG4gKiAtIFVzZXMgY2VudHJhbGl6ZWQgZGV2aWNlIHNjaGVtYSBjYWNoZSBmcm9tIGNvbmZpZy50c1xuICogLSBQcm9kdWNlcyBDb21wYW5pb24gYWN0aW9uIGRlZmluaXRpb25zIGFuZCBmZWVkYmFja3NcbiAqL1xuXG5pbXBvcnQge1xuXHRDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyxcblx0Q29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbixcblx0Q29tcGFuaW9uRmVlZGJhY2tEZWZpbml0aW9ucyxcblx0Y29tYmluZVJnYixcbn0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7IG1ha2VTZXR0aW5nSWQgfSBmcm9tICcuL3R5cGVzLmpzJ1xuaW1wb3J0IHsgZ2V0RGV2aWNlU2NoZW1hcyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuLyogLS0tLS0tIE9wdGlvbiBCdWlsZGVyIC0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG5cbmZ1bmN0aW9uIGJ1aWxkT3B0aW9uKG86IGFueSk6IGFueSB7XG5cdGNvbnN0IGJhc2UgPSB7XG5cdFx0dHlwZTogby50eXBlLFxuXHRcdGlkOiBvLmlkLFxuXHRcdGxhYmVsOiBvLmxhYmVsLFxuXHRcdGRlZmF1bHQ6IG8uZGVmYXVsdCxcblx0XHR0b29sdGlwOiBvLnRvb2x0aXAsXG5cdH1cblxuXHRzd2l0Y2ggKG8udHlwZSkge1xuXHRcdGNhc2UgJ2Ryb3Bkb3duJzpcblx0XHRcdHJldHVybiB7IC4uLmJhc2UsIGNob2ljZXM6IG8uY2hvaWNlcyA/PyBbXSB9XG5cblx0XHRjYXNlICdudW1iZXInOlxuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0Li4uYmFzZSxcblx0XHRcdFx0bWluOiBvLm1pbixcblx0XHRcdFx0bWF4OiBvLm1heCxcblx0XHRcdFx0c3RlcDogby5zdGVwID8/IDEsXG5cdFx0XHRcdHJhbmdlOiB0cnVlLFxuXHRcdFx0fVxuXG5cdFx0Y2FzZSAnY2hlY2tib3gnOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgZGVmYXVsdDogby5kZWZhdWx0ID8/IGZhbHNlIH1cblxuXHRcdGNhc2UgJ3N0YXRpYy10ZXh0Jzpcblx0XHRcdHJldHVybiB7IC4uLmJhc2UsIHZhbHVlOiBvLnZhbHVlID8/ICcnIH1cblxuXHRcdGNhc2UgJ3RleHRpbnB1dCc6XG5cdFx0Y2FzZSAnY29sb3JwaWNrZXInOlxuXHRcdGRlZmF1bHQ6XG5cdFx0XHRyZXR1cm4gYmFzZVxuXHR9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0gQWN0aW9ucyAtLS0tLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkQWN0aW9ucygpOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyB7XG5cdGNvbnN0IHNjaGVtYXMgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgYWN0aW9uczogQ29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbnMgPSB7fVxuXG5cdGZvciAoY29uc3QgW21vZGVsLCBzY2hlbWFdIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYXMpKSB7XG5cdFx0Y29uc3QgY21kU2NoZW1hID0gc2NoZW1hLmNtZFNjaGVtYVxuXHRcdGlmICghQXJyYXkuaXNBcnJheShjbWRTY2hlbWEpKSBjb250aW51ZVxuXG5cdFx0Zm9yIChjb25zdCBhIG9mIGNtZFNjaGVtYSkge1xuXHRcdFx0Ly8gU2tpcCByZWFkLW9ubHkgZW50cmllcyBcdTIwMTQgdGhleSBhcmUgZmVlZGJhY2stb25seSAoaW5kaWNhdG9ycywgc3RhdHVzKVxuXHRcdFx0aWYgKGEucmVhZG9ubHkgPT09IHRydWUpIGNvbnRpbnVlXG5cblx0XHRcdGNvbnN0IGFjdGlvbklkID0gbWFrZVNldHRpbmdJZChtb2RlbCwgYS5jbWRfaWQsIGEuaWQpXG5cblx0XHRcdGNvbnN0IG9wdGlvbnMgPSAoYS5vcHRpb25zID8/IFtdKS5tYXAoYnVpbGRPcHRpb24pXG5cblx0XHRcdGNvbnN0IGFjdGlvbjogQ29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbiA9IHtcblx0XHRcdFx0bmFtZTogYFtNb2RlbCR7bW9kZWx9XSAke2EubmFtZX1gLFxuXHRcdFx0XHRvcHRpb25zLFxuXHRcdFx0XHRjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRcdC8qIHdpcmVkIGxhdGVyIGluIFVwZGF0ZUFjdGlvbnMgKi9cblx0XHRcdFx0fSxcblx0XHRcdH1cblxuXHRcdFx0YWN0aW9uc1thY3Rpb25JZF0gPSBhY3Rpb25cblx0XHR9XG5cdH1cblxuXHRyZXR1cm4gYWN0aW9uc1xufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tIEZlZWRiYWNrcyAtLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG5cbi8qKlxuICogUmV0dXJucyB0cnVlIGlmIHRoZSB2YWx1ZSBvcHRpb24gb2YgYSBzY2hlbWEgZW50cnkgaXMgYSBzaW1wbGUgT2ZmL09uIGRyb3Bkb3duXG4gKiAoZXhhY3RseSB0d28gY2hvaWNlcywgb25lIGxhYmVsbGVkIFwiT2ZmXCIgYW5kIG9uZSBsYWJlbGxlZCBcIk9uXCIpLlxuICovXG5mdW5jdGlvbiBpc09uT2ZmRHJvcGRvd24oc2V0dGluZzogYW55KTogYm9vbGVhbiB7XG5cdGNvbnN0IHZhbHVlT3B0ID0gc2V0dGluZy5vcHRpb25zPy5maW5kKChvOiBhbnkpID0+IG8uaWQgPT09ICd2YWx1ZScpXG5cdGlmICghdmFsdWVPcHQgfHwgdmFsdWVPcHQudHlwZSAhPT0gJ2Ryb3Bkb3duJyB8fCAhQXJyYXkuaXNBcnJheSh2YWx1ZU9wdC5jaG9pY2VzKSkgcmV0dXJuIGZhbHNlXG5cdGlmICh2YWx1ZU9wdC5jaG9pY2VzLmxlbmd0aCAhPT0gMikgcmV0dXJuIGZhbHNlXG5cdGNvbnN0IGxhYmVscyA9IHZhbHVlT3B0LmNob2ljZXMubWFwKChjOiBhbnkpID0+IFN0cmluZyhjLmxhYmVsKS50b0xvd2VyQ2FzZSgpKVxuXHRyZXR1cm4gbGFiZWxzLmluY2x1ZGVzKCdvZmYnKSAmJiBsYWJlbHMuaW5jbHVkZXMoJ29uJylcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkRmVlZGJhY2tzKCk6IENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbnMge1xuXHRjb25zdCBzY2hlbWFzID0gZ2V0RGV2aWNlU2NoZW1hcygpXG5cdGNvbnN0IGZlZWRiYWNrczogQ29tcGFuaW9uRmVlZGJhY2tEZWZpbml0aW9ucyA9IHt9XG5cblx0Zm9yIChjb25zdCBbbW9kZWwsIHNjaGVtYV0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hcykpIHtcblx0XHRjb25zdCBjbWRTY2hlbWEgPSBzY2hlbWEuY21kU2NoZW1hXG5cdFx0aWYgKCFBcnJheS5pc0FycmF5KGNtZFNjaGVtYSkpIGNvbnRpbnVlXG5cblx0XHRmb3IgKGNvbnN0IHNldHRpbmcgb2YgY21kU2NoZW1hKSB7XG5cdFx0XHQvLyBTa2lwIHdyaXRlLW9ubHkgZW50cmllcyBcdTIwMTQgdGhleSBhcmUgYWN0aW9uLW9ubHkgKGRldmljZSBuZXZlciByZXBvcnRzIHZhbHVlIGJhY2spXG5cdFx0XHRpZiAoc2V0dGluZy53cml0ZW9ubHkgPT09IHRydWUpIGNvbnRpbnVlXG5cblx0XHRcdGNvbnN0IGJhc2VGZWVkYmFja0lkID0gbWFrZVNldHRpbmdJZChtb2RlbCwgc2V0dGluZy5jbWRfaWQsIHNldHRpbmcuaWQpXG5cblx0XHRcdC8vIEJ1aWxkIG9wdGlvbnNcblx0XHRcdGNvbnN0IGFsbE9wdGlvbnMgPSAoc2V0dGluZy5vcHRpb25zID8/IFtdKS5tYXAoYnVpbGRPcHRpb24pXG5cblx0XHRcdC8vIEZpbHRlciBvdXQgJ3ZhbHVlJyBvcHRpb24gZm9yIHZhbHVlIGZlZWRiYWNrIChrZWVwIG9ubHkgYnVzQ2gvaWRBZGQpXG5cdFx0XHRjb25zdCB2YWx1ZU9wdGlvbnMgPSBhbGxPcHRpb25zLmZpbHRlcigob3B0OiBhbnkpID0+IG9wdC5pZCAhPT0gJ3ZhbHVlJylcblxuXHRcdFx0Ly8gQWRkIGEgY2hlY2tib3ggb3B0aW9uIHRvIHJldHVybiBsYWJlbCBpbnN0ZWFkIG9mIHZhbHVlXG5cdFx0XHR2YWx1ZU9wdGlvbnMucHVzaCh7XG5cdFx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRcdGlkOiAnc2hvd0xhYmVsJyxcblx0XHRcdFx0bGFiZWw6ICdVc2UgTGFiZWwgZm9yIFZhbHVlJyxcblx0XHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0XHRcdHRvb2x0aXA6ICdSZXR1cm4gdGhlIGxhYmVsIHRleHQgaW5zdGVhZCBvZiB0aGUgbnVtZXJpYyB2YWx1ZScsXG5cdFx0XHR9KVxuXG5cdFx0XHQvLyBWYWx1ZSBmZWVkYmFjayBmb3IgYWxsIHNldHRpbmdzIChhcHBlYXJzIGluIFZhcmlhYmxlcyBsaXN0KVxuXHRcdFx0Y29uc3QgdmFsdWVGZWVkYmFjazogYW55ID0ge1xuXHRcdFx0XHR0eXBlOiAndmFsdWUnLFxuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHttb2RlbH1dICR7c2V0dGluZy5uYW1lfWAsXG5cdFx0XHRcdG9wdGlvbnM6IHZhbHVlT3B0aW9ucyxcblx0XHRcdFx0Y2FsbGJhY2s6ICgpID0+IHtcblx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVGZWVkYmFja3MgKi9cblx0XHRcdFx0XHRyZXR1cm4gMFxuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXG5cdFx0XHQvLyBCb29sZWFuIGZlZWRiYWNrIGZvciBPZmYvT24gZHJvcGRvd25zIFx1MjAxNCByZXBsYWNlcyB0aGUgdmFsdWUgZmVlZGJhY2tcblx0XHRcdGlmIChpc09uT2ZmRHJvcGRvd24oc2V0dGluZykpIHtcblx0XHRcdFx0Y29uc3QgYm9vbEZlZWRiYWNrSWQgPSBgJHtiYXNlRmVlZGJhY2tJZH1fYm9vbGBcblxuXHRcdFx0XHQvLyBPcHRpb25zIHdpdGhvdXQgJ3ZhbHVlJyAoYnVzQ2gvaWRBZGQgc2VsZWN0b3JzIG9ubHksIGlmIHByZXNlbnQpXG5cdFx0XHRcdGNvbnN0IGJvb2xPcHRpb25zID0gYWxsT3B0aW9ucy5maWx0ZXIoKG9wdDogYW55KSA9PiBvcHQuaWQgIT09ICd2YWx1ZScpXG5cblx0XHRcdFx0Y29uc3QgYm9vbEZlZWRiYWNrOiBhbnkgPSB7XG5cdFx0XHRcdFx0dHlwZTogJ2Jvb2xlYW4nLFxuXHRcdFx0XHRcdG5hbWU6IGBbTW9kZWwke21vZGVsfV0gJHtzZXR0aW5nLm5hbWV9IFx1MjAxNCBJcyBPbmAsXG5cdFx0XHRcdFx0ZGVmYXVsdFN0eWxlOiB7XG5cdFx0XHRcdFx0XHRiZ2NvbG9yOiBjb21iaW5lUmdiKDAsIDIwMCwgMCksXG5cdFx0XHRcdFx0XHRjb2xvcjogY29tYmluZVJnYigwLCAwLCAwKSxcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdG9wdGlvbnM6IGJvb2xPcHRpb25zLFxuXHRcdFx0XHRcdGNhbGxiYWNrOiAoKSA9PiB7XG5cdFx0XHRcdFx0XHQvKiB3aXJlZCBsYXRlciBpbiBVcGRhdGVGZWVkYmFja3MgKi9cblx0XHRcdFx0XHRcdHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdH1cblxuXHRcdFx0XHRmZWVkYmFja3NbYm9vbEZlZWRiYWNrSWRdID0gYm9vbEZlZWRiYWNrXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRmZWVkYmFja3NbYmFzZUZlZWRiYWNrSWRdID0gdmFsdWVGZWVkYmFja1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdHJldHVybiBmZWVkYmFja3Ncbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRBY3Rpb25zIH0gZnJvbSAnLi9idWlsZC1jb21tYW5kcy5qcydcbmltcG9ydCB7IGdldERldmljZXNGb2xkZXIsIGdldERldmljZVNjaGVtYSwgZ2V0RGV2aWNlU2NoZW1hcywgcmVsb2FkRGV2aWNlU2NoZW1hcyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgcGFyc2VTZXR0aW5nSWQsIGdldE5vcm1hbGl6ZWRTY2hlbWFzIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJ1xuXG5pbXBvcnQgeyBwYXJzZUdldEFsbFNldHRpbmdzV2l0aERldGVjdGlvbiwgc2F2ZU1vZGVsSnNvblByZXR0eSwgdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzIH0gZnJvbSAnLi9zZXR0aW5nc1BhcnNlci5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdBY3Rpb25zJylcblxuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZUFjdGlvbnMoc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3Qgc2NoZW1hc1JhdyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCByYXdBY3Rpb25zID0gYnVpbGRBY3Rpb25zKClcblx0Y29uc3Qgc2NoZW1hcyA9IGdldE5vcm1hbGl6ZWRTY2hlbWFzKHNjaGVtYXNSYXcpXG5cdGNvbnN0IHdpcmVkQWN0aW9uczogYW55ID0ge31cblxuXHRjb25zdCBhY3RpdmVNb2RlbCA9IHNlbGYuYWN0aXZlTW9kZWxcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEdMT0JBTDogR0VUIEFMTCBTRVRUSU5HUyAoQVVUTyBKU09OIFVQREFURSkgXHUyMDE0IERldiBNb2RlIG9ubHlcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0aWYgKHNlbGYuY29uZmlnLmRldk1vZGUpIHtcblx0XHR3aXJlZEFjdGlvbnNbJ2dsb2JhbF9nZXRBbGxTZXR0aW5ncyddID0ge1xuXHRcdFx0bmFtZTogJ0dMT0JBTDogR2V0IEFsbCBTZXR0aW5ncycsXG5cdFx0XHRkZXNjcmlwdGlvbjogJ1VzZSB0aGlzIHRvIGNyZWF0ZSBhIHNjaGVtYSBmb3IgYSBuZXcgZGV2aWNlJyxcblx0XHRcdG9wdGlvbnM6IFtdLFxuXHRcdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdFx0Y29uc3QgbW9kZWwgPSBhY3RpdmVNb2RlbFxuXHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXG5cdFx0XHRcdGNvbnN0IGJ1ZiA9IGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhpcClcblxuXHRcdFx0XHRsZXQgbW9kZWxKc29uID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXG5cdFx0XHRcdGNvbnN0IHsgc2V0dGluZ3M6IHBhcnNlZCwgZGV0ZWN0ZWRTZWN0aW9uZWQgfSA9IHBhcnNlR2V0QWxsU2V0dGluZ3NXaXRoRGV0ZWN0aW9uKG1vZGVsLCBidWYpXG5cdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgcGFyc2VkIHJlcGx5OiAke0pTT04uc3RyaW5naWZ5KHBhcnNlZCl9YClcblxuXHRcdFx0XHRpZiAoIW1vZGVsSnNvbikge1xuXHRcdFx0XHRcdGxvZ2dlci5pbmZvKGBNb2RlbCAke21vZGVsfSBoYXMgbm8gc2NoZW1hIFx1MjAxNCBjcmVhdGluZyBuZXcgSlNPTiBmcm9tIHNldHRpbmdzYClcblx0XHRcdFx0XHRtb2RlbEpzb24gPSB7XG5cdFx0XHRcdFx0XHRtb2RlbCxcblx0XHRcdFx0XHRcdHNlY3Rpb25lZDogZGV0ZWN0ZWRTZWN0aW9uZWQgPz8gZmFsc2UsXG5cdFx0XHRcdFx0XHRjbWRTY2hlbWE6IFtdLFxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSBlbHNlIGlmIChkZXRlY3RlZFNlY3Rpb25lZCAhPT0gbnVsbCkge1xuXHRcdFx0XHRcdGxvZ2dlci5pbmZvKGBBdXRvLWRldGVjdGVkIHNlY3Rpb25lZD0ke2RldGVjdGVkU2VjdGlvbmVkfSwgYWRkaW5nIHRvIG1vZGVsIEpTT05gKVxuXHRcdFx0XHRcdG1vZGVsSnNvbiA9IHsgLi4ubW9kZWxKc29uLCBzZWN0aW9uZWQ6IGRldGVjdGVkU2VjdGlvbmVkIH1cblx0XHRcdFx0fVxuXG5cdFx0XHRcdGNvbnN0IHVwZGF0ZWQgPSB1cGRhdGVNb2RlbEpzb25Gcm9tU2V0dGluZ3MobW9kZWxKc29uLCBwYXJzZWQsIHNjaGVtYXMpXG5cdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgbmV3IEFjdGlvbnMganNvbjogJHtKU09OLnN0cmluZ2lmeSh1cGRhdGVkLCBudWxsLCAyKX1gKVxuXG5cdFx0XHRcdGNvbnN0IGRldmljZXNGb2xkZXIgPSBnZXREZXZpY2VzRm9sZGVyKClcblx0XHRcdFx0Y29uc3Qgc2NoZW1hUGF0aCA9IHBhdGguam9pbihkZXZpY2VzRm9sZGVyLCBgTW9kZWwke21vZGVsfS5qc29uYClcblx0XHRcdFx0c2F2ZU1vZGVsSnNvblByZXR0eShzY2hlbWFQYXRoLCB1cGRhdGVkKVxuXG5cdFx0XHRcdHJlbG9hZERldmljZVNjaGVtYXMoKVxuXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBNb2RlbCAke21vZGVsfSBKU09OIGF1dG8tdXBkYXRlZCBmcm9tIGdldEFsbFNldHRpbmdzYClcblx0XHRcdH0sXG5cdFx0fVxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBCVUlMRCBQRVItU0VUVElORyBBQ1RJT05TIChGSUxURVJFRCBCWSBBQ1RJVkUgTU9ERUwpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdGZvciAoY29uc3QgW2FjdGlvbklkLCBhY3Rpb25dIG9mIE9iamVjdC5lbnRyaWVzKHJhd0FjdGlvbnMpKSB7XG5cdFx0Y29uc3QgeyBtb2RlbCwgY21kSWQsIGJhc2VJZCB9ID0gcGFyc2VTZXR0aW5nSWQoYWN0aW9uSWQpXG5cblx0XHQvLyBPbmx5IGluY2x1ZGUgYWN0aW9ucyBmb3IgdGhlIGN1cnJlbnRseSBhY3RpdmUgbW9kZWxcblx0XHRpZiAobW9kZWwgIT09IGFjdGl2ZU1vZGVsKSBjb250aW51ZVxuXG5cdFx0Ly8gR2V0IHRoZSByYXcgYWN0aW9uIHNjaGVtYSB0byBhY2Nlc3MgZml4ZWQgYnVzQ2ggdmFsdWVcblx0XHRjb25zdCBzY2hlbWEgPSBzY2hlbWFzW21vZGVsXVxuXHRcdGNvbnN0IHJhd0FjdGlvbiA9IHNjaGVtYT8uY21kU2NoZW1hPy5maW5kKChhOiBhbnkpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBiYXNlSWQpXG5cblx0XHR3aXJlZEFjdGlvbnNbYWN0aW9uSWRdID0ge1xuXHRcdFx0Li4uYWN0aW9uLFxuXHRcdFx0Y2FsbGJhY2s6IGFzeW5jIChldmVudDogYW55KSA9PiB7XG5cdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZXZlbnQub3B0aW9uc1snYnVzQ2gnXSAhPT0gdW5kZWZpbmVkID8gZXZlbnQub3B0aW9uc1snYnVzQ2gnXSA6IHJhd0FjdGlvbj8uYnVzQ2hcblx0XHRcdFx0Y29uc3QgdmFsdWUgPSBldmVudC5vcHRpb25zWyd2YWx1ZSddXG5cdFx0XHRcdGNvbnN0IGlkQWRkID0gZXZlbnQub3B0aW9uc1snaWRBZGQnXSA/PyAwXG5cdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGJhc2VJZCArIGlkQWRkXG5cblx0XHRcdFx0YXdhaXQgc2VsZi5zdENvbnRyb2xsZXIuc2VuZEF3YWl0QWNrKGNtZElkLCBidXNDaCwgc2V0dGluZ0lkLCB2YWx1ZSwgaXApXG5cdFx0XHR9LFxuXHRcdH1cblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgTUlDIEtJTEwgKE9OTFkgSUYgQUNUSVZFIE1PREVMIFNVUFBPUlRTIElUKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Y29uc3QgYWN0aXZlU2NoZW1hID0gc2NoZW1hc1thY3RpdmVNb2RlbF1cblx0aWYgKGFjdGl2ZVNjaGVtYSkge1xuXHRcdGNvbnN0IHN1cHBvcnRzTWljS2lsbCA9IChhY3RpdmVTY2hlbWEuY21kU2NoZW1hID8/IFtdKS5zb21lKChhOiBhbnkpID0+IGEubmFtZS5pbmNsdWRlcygnS2lsbCcpKVxuXG5cdFx0aWYgKHN1cHBvcnRzTWljS2lsbCkge1xuXHRcdFx0Y29uc3QgYWN0aW9uSWQgPSBgJHthY3RpdmVNb2RlbH1fbWljS2lsbGBcblxuXHRcdFx0d2lyZWRBY3Rpb25zW2FjdGlvbklkXSA9IHtcblx0XHRcdFx0bmFtZTogYFtNb2RlbCR7YWN0aXZlTW9kZWx9XSBNaWMgS2lsbGAsXG5cdFx0XHRcdG9wdGlvbnM6IFtdLFxuXHRcdFx0XHRjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRcdGNvbnN0IGlwID0gc2VsZi5ob3N0XG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYE1pYyBLaWxsIFx1MjE5MiBNb2RlbCAke2FjdGl2ZU1vZGVsfSBAICR7aXB9YClcblx0XHRcdFx0XHRhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5nbG9iYWxNaWNLaWxsKGlwKVxuXHRcdFx0XHRcdGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhpcCkuY2F0Y2goKGVycikgPT4ge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oYEZhaWxlZCB0byByZWZyZXNoIHNldHRpbmdzIGFmdGVyIGNvbW1hbmQ6ICR7ZXJyfWApXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0fSxcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHRzZWxmLnNldEFjdGlvbkRlZmluaXRpb25zKHdpcmVkQWN0aW9ucylcbn1cbiIsICJpbXBvcnQgZnMgZnJvbSAnZnMnXG5pbXBvcnQgeyBnZXREZXZpY2VTY2hlbWEgfSBmcm9tICcuL2NvbmZpZy5qcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQge1xuXHRDTURfTUlDX1BSRSxcblx0Q01EX0JVU19TRVQsXG5cdENNRF9DSEFOTkVMLFxuXHRDTURfREVWX1NQRUMsXG5cdENNRF9HRVRfQUxMX1NFVFRJTkdTLFxuXHRDTURfTUlDX1BSRV9CVVMsXG5cdENNRF9TRVRUSU5HU19QVVNILFxuXHR0b0hleCxcblx0Ynl0ZXNUb0hleCxcblx0Zm9ybWF0UmdiQ29sb3IsXG5cdG1vZGVsRGlzdGFuY2UsXG59IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignU2V0dGluZ3NQYXJzZXInKVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBUWVBFU1xuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgdHlwZSBQYXJzZWRTZXR0aW5nID0ge1xuXHRjbWRfaWQ6IG51bWJlclxuXHRpZDogbnVtYmVyXG5cdGJ1c0NoPzogbnVtYmVyIC8vIE9wdGlvbmFsOiBvbmx5IHByZXNlbnQgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2ggKDB4MDQsIDB4MTIsIDB4MTQpXG5cdHZhbHVlQnl0ZXM6IG51bWJlcltdXG59XG5cbmV4cG9ydCB0eXBlIFN0QWN0aW9uT3B0aW9uID0ge1xuXHRpZD86IHN0cmluZ1xuXHRsYWJlbDogc3RyaW5nXG5cdHR5cGU6IHN0cmluZ1xuXHRkZWZhdWx0OiB1bmtub3duXG5cdHRvb2x0aXA/OiBzdHJpbmdcblx0Y2hvaWNlcz86IEFycmF5PHsgaWQ6IG51bWJlcjsgbGFiZWw6IHN0cmluZyB9PlxufVxuXG5leHBvcnQgdHlwZSBTdEFjdGlvbiA9IHtcblx0Y21kX2lkOiBudW1iZXJcblx0aWQ6IG51bWJlclxuXHRuYW1lOiBzdHJpbmdcblx0b3B0aW9uczogU3RBY3Rpb25PcHRpb25bXVxuXHRidXNDaD86IG51bWJlciAvLyBGaXhlZCBjaGFubmVsIHZhbHVlIGZvciBhY3Rpb25zIHRoYXQgZG9uJ3QgaGF2ZSBhIGNoYW5uZWwgb3B0aW9uXG5cdHJlYWRvbmx5PzogYm9vbGVhbiAvLyBJZiB0cnVlLCBlbnRyeSBpcyBmZWVkYmFjay1vbmx5IFx1MjAxNCBubyBhY3Rpb24gd2lsbCBiZSBjcmVhdGVkXG5cdHdyaXRlb25seT86IGJvb2xlYW4gLy8gSWYgdHJ1ZSwgZW50cnkgaXMgYWN0aW9uLW9ubHkgXHUyMDE0IG5vIGZlZWRiYWNrIHdpbGwgYmUgY3JlYXRlZCAoZGV2aWNlIG5ldmVyIHJlcG9ydHMgdGhpcyB2YWx1ZSBiYWNrKVxufVxuXG5leHBvcnQgdHlwZSBTdE1vZGVsSnNvbiA9IHtcblx0bW9kZWw6IHN0cmluZ1xuXHRzZWN0aW9uZWQ/OiBib29sZWFuXG5cdGNtZFNjaGVtYTogU3RBY3Rpb25bXVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBGT1JNQVQgSEVMUEVSU1xuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBnZXRNb2RlbENvbmZpZyhtb2RlbDogc3RyaW5nKTogeyBzZWN0aW9uZWQ6IGJvb2xlYW47IHJnYklkczogU2V0PG51bWJlcj4gfSB7XG5cdGNvbnN0IHJnYklkcyA9IG5ldyBTZXQ8bnVtYmVyPigpXG5cdGxldCBzZWN0aW9uZWQgPSBmYWxzZVxuXG5cdHRyeSB7XG5cdFx0Ly8gVXNlIGNlbnRyYWxpemVkIGNhY2hlIGluc3RlYWQgb2YgcmVhZGluZyBmcm9tIGRpc2tcblx0XHRjb25zdCBqc29uID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRcdGlmICghanNvbikge1xuXHRcdFx0Ly8gSWYgd2UgY2FuJ3QgbG9hZCB0aGUgc2NoZW1hLCByZXR1cm4gZGVmYXVsdHNcblx0XHRcdHJldHVybiB7IHNlY3Rpb25lZCwgcmdiSWRzIH1cblx0XHR9XG5cblx0XHQvLyBSZWFkIHNlY3Rpb25lZCBwcm9wZXJ0eSAoZGVmYXVsdCB0byBmYWxzZSBpZiBub3Qgc3BlY2lmaWVkKVxuXHRcdHNlY3Rpb25lZCA9IGpzb24uc2VjdGlvbmVkID8/IGZhbHNlXG5cblx0XHQvLyBCdWlsZCBSR0IgSURzIHNldFxuXHRcdGZvciAoY29uc3QgYWN0aW9uIG9mIGpzb24uY21kU2NoZW1hIHx8IFtdKSB7XG5cdFx0XHRjb25zdCBoYXNDb2xvcnBpY2tlciA9IGFjdGlvbi5vcHRpb25zPy5zb21lKChvcHQ6IFN0QWN0aW9uT3B0aW9uKSA9PiBvcHQudHlwZSA9PT0gJ2NvbG9ycGlja2VyJylcblx0XHRcdGlmIChoYXNDb2xvcnBpY2tlcikge1xuXHRcdFx0XHQvLyBBZGQgdGhlIGJhc2UgSURcblx0XHRcdFx0cmdiSWRzLmFkZChhY3Rpb24uaWQpXG5cblx0XHRcdFx0Ly8gSWYgdGhpcyBhY3Rpb24gaGFzIGlkQWRkIGNob2ljZXMsIGFkZCBhbGwgdGhlIG9mZnNldCBJRHMgdG9vXG5cdFx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdDogU3RBY3Rpb25PcHRpb24pID0+IG9wdC5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0aWYgKGlkQWRkT3B0aW9uPy5jaG9pY2VzKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBjaG9pY2Ugb2YgaWRBZGRPcHRpb24uY2hvaWNlcykge1xuXHRcdFx0XHRcdFx0aWYgKHR5cGVvZiBjaG9pY2UuaWQgPT09ICdudW1iZXInKSB7XG5cdFx0XHRcdFx0XHRcdHJnYklkcy5hZGQoYWN0aW9uLmlkICsgY2hvaWNlLmlkKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fSBjYXRjaCAoX2Vycikge1xuXHRcdC8vIElmIHdlIGNhbid0IGxvYWQgdGhlIHNjaGVtYSwgcmV0dXJuIGRlZmF1bHRzXG5cdH1cblxuXHRyZXR1cm4geyBzZWN0aW9uZWQsIHJnYklkcyB9XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZJTkQgVEhFIFJFQUwgNUEgUEFZTE9BRCBJTkRFWFxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBleHRyYWN0U3RQYXlsb2FkSW5kZXgoYnVmOiBCdWZmZXIpOiBudW1iZXIge1xuXHRjb25zdCBzaWdJbmRleCA9IGJ1Zi5pbmRleE9mKEJ1ZmZlci5mcm9tKCdTdHVkaW8tVCcpKVxuXHRpZiAoc2lnSW5kZXggPCAwKSB0aHJvdyBuZXcgRXJyb3IoJ05vIFN0dWRpby1UIHNpZ25hdHVyZSBpbiBwYWNrZXQnKVxuXG5cdGNvbnN0IHBheWxvYWRJbmRleCA9IHNpZ0luZGV4ICsgOFxuXHRpZiAoYnVmW3BheWxvYWRJbmRleF0gIT09IDB4NWEpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoYEV4cGVjdGVkIDB4NUEgYWZ0ZXIgU3R1ZGlvLVQsIGZvdW5kICR7YnVmW3BheWxvYWRJbmRleF0udG9TdHJpbmcoMTYpfWApXG5cdH1cblxuXHRyZXR1cm4gcGF5bG9hZEluZGV4XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIEZMQVQgUEFSU0VSXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIHBhcnNlRmxhdElkVmFsU2VxdWVuY2UoYmxvY2s6IEJ1ZmZlciwgcmdiSWRzOiBTZXQ8bnVtYmVyPiA9IG5ldyBTZXQoKSk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGxldCBwID0gMFxuXHRjb25zdCBvdXQ6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cblx0d2hpbGUgKHAgPCBibG9jay5sZW5ndGgpIHtcblx0XHRjb25zdCBpZCA9IGJsb2NrW3BdXG5cdFx0aWYgKHAgKyAxID49IGJsb2NrLmxlbmd0aCkgYnJlYWtcblxuXHRcdC8vIFJHQiBjYXNlIC0gY2hlY2sgaWYgdGhpcyBJRCBpcyBhIGtub3duIGNvbG9ycGlja2VyXG5cdFx0aWYgKHJnYklkcy5oYXMoaWQpICYmIHAgKyAzIDwgYmxvY2subGVuZ3RoKSB7XG5cdFx0XHRvdXQucHVzaCh7XG5cdFx0XHRcdGNtZF9pZDogQ01EX0RFVl9TUEVDLFxuXHRcdFx0XHRpZCxcblx0XHRcdFx0dmFsdWVCeXRlczogW2Jsb2NrW3AgKyAxXSwgYmxvY2tbcCArIDJdLCBibG9ja1twICsgM11dLFxuXHRcdFx0fSlcblx0XHRcdHAgKz0gNFxuXHRcdFx0Y29udGludWVcblx0XHR9XG5cblx0XHRvdXQucHVzaCh7IGNtZF9pZDogQ01EX0RFVl9TUEVDLCBpZCwgdmFsdWVCeXRlczogW2Jsb2NrW3AgKyAxXV0gfSlcblx0XHRwICs9IDJcblx0fVxuXG5cdHJldHVybiBvdXRcbn1cblxuZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc19mbGF0KGJ1ZjogQnVmZmVyLCBtb2RlbDogc3RyaW5nKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0Y29uc3QgaWR4ID0gZXh0cmFjdFN0UGF5bG9hZEluZGV4KGJ1Zilcblx0Y29uc3QgY21kSWQgPSBidWZbaWR4ICsgMV0gJiAweDdmXG5cdGlmIChjbWRJZCAhPT0gQ01EX0dFVF9BTExfU0VUVElOR1MgJiYgY21kSWQgIT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKCdOb3QgYSBnZXRBbGxTZXR0aW5ncyByZXBseScpXG5cdH1cblxuXHRjb25zdCBibG9ja0xlbiA9IGJ1ZltpZHggKyAyXVxuXHRjb25zdCBzdGFydCA9IGlkeCArIDNcblx0Y29uc3QgZW5kID0gc3RhcnQgKyBibG9ja0xlblxuXHRpZiAoZW5kID4gYnVmLmxlbmd0aCkgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIGJsb2NrIGxlbmd0aCcpXG5cblx0Y29uc3QgeyByZ2JJZHMgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXHRyZXR1cm4gcGFyc2VGbGF0SWRWYWxTZXF1ZW5jZShidWYuc3ViYXJyYXkoc3RhcnQsIGVuZCksIHJnYklkcylcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgU0VDVElPTkVEIFBBUlNFUlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWY6IEJ1ZmZlciwgbW9kZWw6IHN0cmluZyk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcignTm90IGEgZ2V0QWxsU2V0dGluZ3MgcmVwbHknKVxuXHR9XG5cblx0Ly8gQ01EX0dFVF9BTExfU0VUVElOR1MgaGFzIGEgdG90YWwtbGVuZ3RoIGJ5dGUgYXQgaWR4KzIgYmVmb3JlIHRoZSBzZWN0aW9uczsgQ01EX1NFVFRJTkdTX1BVU0ggZG9lcyBub3QuXG5cdGxldCBwID0gY21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTID8gaWR4ICsgMyA6IGlkeCArIDJcblx0Y29uc3QgZW5kID0gYnVmLmxlbmd0aCAtIDFcblx0Y29uc3Qgb3V0OiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXG5cdC8vIEdldCBSR0IgSURzIGZvciB0aGlzIG1vZGVsXG5cdGNvbnN0IHsgcmdiSWRzIH0gPSBnZXRNb2RlbENvbmZpZyhtb2RlbClcblxuXHQvLyBDb21tYW5kIElEcyB0aGF0IGluY2x1ZGUgYSBidXNDaCBieXRlIGluIHRoZWlyIHNlY3Rpb24gc3RydWN0dXJlLFxuXHQvLyBmb2xsb3dlZCBieSBhIGRhdGFMZW4gYnl0ZSBhbmQgdGhlbiBpZDp2YWwgcGFpcnMuXG5cdGNvbnN0IGNvbW1hbmRzV2l0aEJ1c0NoID0gW0NNRF9CVVNfU0VULCBDTURfTUlDX1BSRV9CVVMsIENNRF9DSEFOTkVMXVxuXG5cdC8vIENvbW1hbmQgSURzIHRoYXQgaW5jbHVkZSBhIGJ1c0NoIGJ5dGUgYnV0IHN0b3JlIHJhdyBwb3NpdGlvbmFsIHZhbHVlIGJ5dGVzXG5cdC8vIHJhdGhlciB0aGFuIGlkOnZhbCBwYWlycyAobm8gZGF0YUxlbiBieXRlLCBubyBzZXR0aW5nIElEcykuXG5cdC8vIEZvcm1hdDogW2NtZExlbl0gW2NtZElkXSBbYnVzQ2hdIFt2YWwwXSBbdmFsMV0gLi4uXG5cdGNvbnN0IGNvbW1hbmRzUmF3VmFsdWUgPSBbQ01EX01JQ19QUkVdIC8vIGNtZD0weDAyXG5cblx0d2hpbGUgKHAgKyAyIDwgZW5kKSB7XG5cdFx0Y29uc3QgY21kTGVuID0gYnVmW3BdXG5cdFx0Y29uc3Qgc2VjdGlvbkNtZElkID0gYnVmW3AgKyAxXVxuXG5cdFx0Y29uc3Qgc2VjdGlvbkVuZCA9IHAgKyAxICsgY21kTGVuXG5cdFx0aWYgKHNlY3Rpb25FbmQgPiBlbmQpIGJyZWFrXG5cblx0XHRjb25zdCBoYXNCdXNDaCA9IGNvbW1hbmRzV2l0aEJ1c0NoLmluY2x1ZGVzKHNlY3Rpb25DbWRJZClcblx0XHRjb25zdCBpc1Jhd1ZhbHVlID0gY29tbWFuZHNSYXdWYWx1ZS5pbmNsdWRlcyhzZWN0aW9uQ21kSWQpXG5cblx0XHRsZXQgYnVzQ2g6IG51bWJlciB8IHVuZGVmaW5lZFxuXHRcdGxldCBkYXRhTGVuOiBudW1iZXJcblx0XHRsZXQgcTogbnVtYmVyXG5cblx0XHRpZiAoaXNSYXdWYWx1ZSkge1xuXHRcdFx0Ly8gU3RydWN0dXJlOiBbY21kTGVuXSBbY21kSWRdIFtidXNDaF0gW3ZhbDBdIFt2YWwxXSAuLi5cblx0XHRcdC8vIEJ1aWxkIHBvc2l0aW9uYWwgbWFwIGZyb20gc2NoZW1hOiBmaW5kIGFsbCBlbnRyaWVzIGZvciBDTURfTUlDX1BSRSAoMHgwMikgb3Jcblx0XHRcdC8vIENNRF9NSUNfUFJFX0JVUyAoMHgxMikgd2l0aCBhIGZpeGVkIGJ1c0NoLCBzb3J0ZWQgYnkgaWQgXHUyMDE0IGVhY2ggYmVjb21lcyBvbmVcblx0XHRcdC8vIHBvc2l0aW9uYWwgc2xvdC4gVGhpcyBtYWtlcyB0aGUgcmVtYXAgc2NoZW1hLWRyaXZlbjpcblx0XHRcdC8vICAgMjE0ICAoY21kX2lkPTIsICBpZD0wLzEpIFx1MjE5MiBwb3MwXHUyMTkyKDIsMCksICBwb3MxXHUyMTkyKDIsMSlcblx0XHRcdC8vICAgMjE0QSAoY21kX2lkPTE4LCBpZD0xLzIpIFx1MjE5MiBwb3MwXHUyMTkyKDE4LDEpLCBwb3MxXHUyMTkyKDE4LDIpXG5cdFx0XHQvLyBQb3NpdGlvbnMgd2l0aCBubyBzY2hlbWEgZW50cnkgYXJlIGRyb3BwZWQgKGUuZy4gdW5rbm93biAzcmQgYnl0ZSkuXG5cdFx0XHRidXNDaCA9IGJ1ZltwICsgMl1cblx0XHRcdGNvbnN0IHJhd0J5dGVzID0gYnVmLnN1YmFycmF5KHAgKyAzLCBzZWN0aW9uRW5kKVxuXG5cdFx0XHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdFx0XHRjb25zdCBtaWNQcmVFbnRyaWVzID0gKHNjaGVtYT8uY21kU2NoZW1hID8/IFtdKVxuXHRcdFx0XHQuZmlsdGVyKChhOiBTdEFjdGlvbikgPT4gKGEuY21kX2lkID09PSBDTURfTUlDX1BSRSB8fCBhLmNtZF9pZCA9PT0gQ01EX01JQ19QUkVfQlVTKSAmJiBhLmJ1c0NoICE9PSB1bmRlZmluZWQpXG5cdFx0XHRcdC5zb3J0KChhOiBTdEFjdGlvbiwgYjogU3RBY3Rpb24pID0+IGEuaWQgLSBiLmlkKVxuXG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IHJhd0J5dGVzLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRcdGNvbnN0IGVudHJ5ID0gbWljUHJlRW50cmllc1tpXVxuXHRcdFx0XHRpZiAoZW50cnkpIHtcblx0XHRcdFx0XHRvdXQucHVzaCh7IGNtZF9pZDogZW50cnkuY21kX2lkLCBpZDogZW50cnkuaWQsIGJ1c0NoLCB2YWx1ZUJ5dGVzOiBbcmF3Qnl0ZXNbaV1dIH0pXG5cdFx0XHRcdH1cblx0XHRcdFx0Ly8gbm8gZW50cnkgPSB1bmtub3duIHBvc2l0aW9uYWwgYnl0ZSwgZHJvcCBpdFxuXHRcdFx0fVxuXHRcdFx0cCA9IHNlY3Rpb25FbmRcblx0XHRcdGNvbnRpbnVlXG5cdFx0fSBlbHNlIGlmIChoYXNCdXNDaCkge1xuXHRcdFx0Ly8gU3RydWN0dXJlOiBbY21kTGVuXSBbY21kSWRdIFtidXNDaF0gW2RhdGFMZW5dIFtpZDp2YWwgcGFpcnNdXG5cdFx0XHRidXNDaCA9IGJ1ZltwICsgMl1cblx0XHRcdGRhdGFMZW4gPSBidWZbcCArIDNdXG5cdFx0XHRxID0gcCArIDRcblx0XHR9IGVsc2Uge1xuXHRcdFx0Ly8gU3RydWN0dXJlOiBbY21kTGVuXSBbY21kSWRdIFtkYXRhTGVuXSBbaWQ6dmFsIHBhaXJzXVxuXHRcdFx0ZGF0YUxlbiA9IGJ1ZltwICsgMl1cblx0XHRcdHEgPSBwICsgM1xuXHRcdH1cblxuXHRcdGNvbnN0IHFFbmQgPSBxICsgZGF0YUxlblxuXHRcdGNvbnN0IHFTdGFydCA9IHFcblxuXHRcdHdoaWxlIChxICsgMSA8IHFFbmQpIHtcblx0XHRcdGNvbnN0IGlkID0gYnVmW3FdXG5cdFx0XHRsZXQgdmFsdWVCeXRlczogbnVtYmVyW11cblxuXHRcdFx0Ly8gQ2hlY2sgaWYgdGhpcyBJRCBpcyBhbiBSR0IgY29sb3JwaWNrZXIgKG5lZWRzIDMgYnl0ZXMpXG5cdFx0XHRpZiAocmdiSWRzLmhhcyhpZCkgJiYgcSArIDMgPCBxRW5kKSB7XG5cdFx0XHRcdHZhbHVlQnl0ZXMgPSBbYnVmW3EgKyAxXSwgYnVmW3EgKyAyXSwgYnVmW3EgKyAzXV1cblx0XHRcdFx0cSArPSA0XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHR2YWx1ZUJ5dGVzID0gW2J1ZltxICsgMV1dXG5cdFx0XHRcdHEgKz0gMlxuXHRcdFx0fVxuXG5cdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0ge1xuXHRcdFx0XHRjbWRfaWQ6IHNlY3Rpb25DbWRJZCxcblx0XHRcdFx0aWQsXG5cdFx0XHRcdHZhbHVlQnl0ZXMsXG5cdFx0XHR9XG5cdFx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRzZXR0aW5nLmJ1c0NoID0gYnVzQ2hcblx0XHRcdH1cblx0XHRcdG91dC5wdXNoKHNldHRpbmcpXG5cdFx0fVxuXG5cdFx0Ly8gUG9zaXRpb25hbCBmYWxsYmFjazogaWYgdGhlIGJ5dGUgd2UgcmVhZCBhcyBkYXRhTGVuIHdhcyAweDAwIGJ1dCB0aGUgc2VjdGlvblxuXHRcdC8vIHN0aWxsIGNvbnRhaW5zIGRhdGEgYnl0ZXMsIHRoaXMgc2VjdGlvbiBsaWtlbHkgdXNlcyBhIG5vLWRhdGFMZW4gZm9ybWF0IHdoZXJlXG5cdFx0Ly8gZWFjaCBieXRlIGFmdGVyIGNtZElkIGlzIGEgcmF3IHZhbHVlIGF0IGEgZml4ZWQgcG9zaXRpb24gKHBvc2l0aW9uID0gaWQpLlxuXHRcdC8vIFJlLXBhcnNlIGZyb20gcCsyIChyaWdodCBhZnRlciBjbWRJZCksIHRyZWF0aW5nIHRoZSBcImRhdGFMZW5cIiBieXRlIGFzIGlkPTAuXG5cdFx0Ly8gT25seSBmaXJlIGlmIG5vIGJ5dGVzIHdlcmUgY29uc3VtZWQgYnkgdGhlIG1haW4gbG9vcCAocSA9PT0gcVN0YXJ0KSwgdG8gYXZvaWRcblx0XHQvLyByZS1wYXJzaW5nIGJ5dGVzIHRoYXQgd2VyZSBhbHJlYWR5IHN1Y2Nlc3NmdWxseSBwYXJzZWQuXG5cdFx0aWYgKHEgPT09IHFTdGFydCAmJiBzZWN0aW9uRW5kID4gcCArIDMpIHtcblx0XHRcdGxldCBwb3MgPSBoYXNCdXNDaCA/IHAgKyAzIDogcCArIDIgLy8gc2tpcCBjbWRJZCAoYW5kIGJ1c0NoIGlmIHByZXNlbnQpXG5cdFx0XHRsZXQgcG9zSWQgPSAwXG5cdFx0XHR3aGlsZSAocG9zIDwgc2VjdGlvbkVuZCkge1xuXHRcdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0geyBjbWRfaWQ6IHNlY3Rpb25DbWRJZCwgaWQ6IHBvc0lkKyssIHZhbHVlQnl0ZXM6IFtidWZbcG9zKytdXSB9XG5cdFx0XHRcdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSBzZXR0aW5nLmJ1c0NoID0gYnVzQ2hcblx0XHRcdFx0b3V0LnB1c2goc2V0dGluZylcblx0XHRcdH1cblx0XHR9XG5cblx0XHRwID0gc2VjdGlvbkVuZFxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBHRU5FUklDIFNFVFRJTkdTIFJFU1BPTlNFIFBBUlNFUiAoMHgwYSBnZXQtYWxsICsgMHgwYiB1bnNvbGljaXRlZCBwdXNoKVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIFBhcnNlcyBhbnkgZnVsbCBzZXR0aW5ncyBibG9jayByZWdhcmRsZXNzIG9mIHdoZXRoZXIgdGhlIGNtZElkIGlzIDB4MGFcbiAqIChyZXNwb25zZSB0byBHZXQgQWxsIFNldHRpbmdzKSBvciAweDBiICh1bnNvbGljaXRlZCBwdXNoIGFmdGVyIGEgc2V0KS5cbiAqIEJvdGggdXNlIHRoZSBzYW1lIHNlY3Rpb25lZCBvciBmbGF0IGJsb2NrIGxheW91dC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlU2V0dGluZ3NSZXNwb25zZShtb2RlbDogc3RyaW5nLCBidWY6IEJ1ZmZlcik6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcihgTm90IGEgc2V0dGluZ3MgYmxvY2sgKGNtZElkPTB4JHtjbWRJZC50b1N0cmluZygxNil9KWApXG5cdH1cblx0Y29uc3QgeyBzZWN0aW9uZWQgfSA9IGdldE1vZGVsQ29uZmlnKG1vZGVsKVxuXHRyZXR1cm4gc2VjdGlvbmVkID8gcGFyc2VHZXRBbGxTZXR0aW5nc19zZWN0aW9uZWQoYnVmLCBtb2RlbCkgOiBwYXJzZUdldEFsbFNldHRpbmdzX2ZsYXQoYnVmLCBtb2RlbClcbn1cblxuLyoqXG4gKiBGb3JtYXRzIGEgc2luZ2xlIHBhcnNlZCBzZXR0aW5nIGludG8gYSBodW1hbi1yZWFkYWJsZSBzdHJpbmcgdXNpbmcgYWN0aW9uXG4gKiBkZWZpbml0aW9ucyBmcm9tIHRoZSBkZXZpY2UgSlNPTi4gRmFsbHMgYmFjayB0byBoZXggSURzIHdoZW4gdW5rbm93bi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdFBhcnNlZFNldHRpbmcoc2V0dGluZzogUGFyc2VkU2V0dGluZywgYWN0aW9uczogU3RBY3Rpb25bXSk6IHN0cmluZyB7XG5cdC8vIFRyeSBleGFjdCBtYXRjaCBmaXJzdFxuXHRsZXQgYWN0aW9uID0gYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gc2V0dGluZy5jbWRfaWQgJiYgYS5pZCA9PT0gc2V0dGluZy5pZClcblxuXHQvLyBJZiBubyBleGFjdCBtYXRjaCBhbmQgaWQgPiBiYXNlIGlkLCB0cnkgdG8gZmluZCBhY3Rpb24gd2l0aCBpZEFkZCBvcHRpb25cblx0Ly8gVGhpcyBoYW5kbGVzIGNhc2VzIGxpa2UgQ01EX0hFQURQSE9ORSAoMHgwNSwgZS5nLiBQaG9uZXMgUm91dGluZykgYW5kXG5cdC8vIENNRF9CVVRUT05fTU9ERSAoMHgwNywgZS5nLiBCdXR0b25zKSB3aGVyZSBpZCAwLTMgcmVwcmVzZW50cyBjaGFubmVscyAxLTRcblx0aWYgKCFhY3Rpb24pIHtcblx0XHRjb25zdCBiYXNlQWN0aW9uID0gYWN0aW9ucy5maW5kKChhKSA9PiB7XG5cdFx0XHRpZiAoYS5jbWRfaWQgIT09IHNldHRpbmcuY21kX2lkKSByZXR1cm4gZmFsc2Vcblx0XHRcdC8vIENoZWNrIGlmIHRoaXMgYWN0aW9uIGhhcyBhbiBpZEFkZCBvcHRpb24gKGluZGljYXRpbmcgY2hhbm5lbCBzZWxlY3Rpb24pXG5cdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IGEub3B0aW9ucz8uZmluZCgob3B0KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoIWlkQWRkT3B0aW9uPy5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdC8vIENoZWNrIGlmIHRoZSBzZXR0aW5nLmlkIG9mZnNldCBtYXRjaGVzIG9uZSBvZiB0aGUgaWRBZGQgY2hvaWNlIElEc1xuXHRcdFx0Y29uc3QgY2hhbm5lbE9mZnNldCA9IHNldHRpbmcuaWQgLSBhLmlkXG5cdFx0XHRyZXR1cm4gaWRBZGRPcHRpb24uY2hvaWNlcy5zb21lKChjKSA9PiBjLmlkID09PSBjaGFubmVsT2Zmc2V0KVxuXHRcdH0pXG5cdFx0aWYgKGJhc2VBY3Rpb24pIHtcblx0XHRcdGFjdGlvbiA9IGJhc2VBY3Rpb25cblx0XHR9XG5cdH1cblxuXHRjb25zdCBjbWRIZXggPSB0b0hleChzZXR0aW5nLmNtZF9pZClcblx0Y29uc3QgaWRIZXggPSB0b0hleChzZXR0aW5nLmlkKVxuXHRjb25zdCB2YWxIZXggPSBieXRlc1RvSGV4KHNldHRpbmcudmFsdWVCeXRlcylcblx0Y29uc3QgdmFsRGVjID1cblx0XHRzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAzXG5cdFx0XHQ/IGZvcm1hdFJnYkNvbG9yKHNldHRpbmcudmFsdWVCeXRlc1swXSwgc2V0dGluZy52YWx1ZUJ5dGVzWzFdLCBzZXR0aW5nLnZhbHVlQnl0ZXNbMl0pXG5cdFx0XHQ6IHNldHRpbmcudmFsdWVCeXRlcy5sZW5ndGggPT09IDFcblx0XHRcdFx0PyBzZXR0aW5nLnZhbHVlQnl0ZXNbMF1cblx0XHRcdFx0OiBzZXR0aW5nLnZhbHVlQnl0ZXMuam9pbignLCcpXG5cblx0Ly8gQnVpbGQgdGhlIHByZWZpeDogY21kOjB4MTIgY2g6MCBpZDoweDAxIHZhbDoweDE0IChjaCBvbmx5IGZvciBjb21tYW5kcyB3aXRoIGJ1c0NoKVxuXHRjb25zdCBidXNDaFN0ciA9IHNldHRpbmcuYnVzQ2ggIT09IHVuZGVmaW5lZCA/IGAgY2g6JHtzZXR0aW5nLmJ1c0NofWAgOiAnJ1xuXHRjb25zdCBwcmVmaXggPSBgY21kOiR7Y21kSGV4fSR7YnVzQ2hTdHJ9IGlkOiR7aWRIZXh9IHZhbDoke3ZhbEhleH1gXG5cblx0Ly8gSWYgd2UgaGF2ZSBhbiBhY3Rpb24gd2l0aCBhIG5hbWUgYW5kIGNob2ljZSBsYWJlbCwgdXNlIGl0XG5cdGlmIChhY3Rpb24pIHtcblx0XHRsZXQgbmFtZSA9IGFjdGlvbi5uYW1lXG5cblx0XHQvLyBJZiBzZXR0aW5nIGhhcyBidXNDaCwgYWRkIGNoYW5uZWwgaW5mbyB0byBuYW1lXG5cdFx0aWYgKHNldHRpbmcuYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0bmFtZSA9IGAke25hbWV9IENoJHtzZXR0aW5nLmJ1c0NoICsgMX1gXG5cdFx0fVxuXHRcdC8vIE90aGVyd2lzZSwgaWYgdGhpcyBhY3Rpb24gaGFzIGlkQWRkLCBpbmNsdWRlIHRoZSBpZEFkZCBsYWJlbFxuXHRcdGVsc2Uge1xuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgob3B0KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoaWRBZGRPcHRpb24/LmNob2ljZXMpIHtcblx0XHRcdFx0Y29uc3QgY2hhbm5lbE9mZnNldCA9IHNldHRpbmcuaWQgLSBhY3Rpb24uaWRcblx0XHRcdFx0Y29uc3QgaWRBZGRDaG9pY2UgPSBpZEFkZE9wdGlvbi5jaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IGNoYW5uZWxPZmZzZXQpXG5cdFx0XHRcdGlmIChpZEFkZENob2ljZSkge1xuXHRcdFx0XHRcdG5hbWUgPSBgJHtuYW1lfSAke2lkQWRkQ2hvaWNlLmxhYmVsfWBcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIExvb2sgZm9yIHRoZSB2YWx1ZSBvcHRpb24gKG5vdCBidXNDaCBvciBpZEFkZClcblx0XHRjb25zdCB2YWx1ZU9wdGlvbiA9IGFjdGlvbi5vcHRpb25zPy5maW5kKChvcHQpID0+IG9wdC5pZCA9PT0gJ3ZhbHVlJylcblx0XHRpZiAodmFsdWVPcHRpb24/LmNob2ljZXMgJiYgc2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0Y29uc3QgY2hvaWNlID0gdmFsdWVPcHRpb24uY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSBzZXR0aW5nLnZhbHVlQnl0ZXNbMF0pXG5cdFx0XHRpZiAoY2hvaWNlKSB7XG5cdFx0XHRcdHJldHVybiBgJHtwcmVmaXh9IHwgJHtuYW1lfTogJHtjaG9pY2UubGFiZWx9ICgke3ZhbERlY30pYFxuXHRcdFx0fVxuXHRcdH1cblx0XHRyZXR1cm4gYCR7cHJlZml4fSB8ICR7bmFtZX06ICR7dmFsRGVjfWBcblx0fVxuXG5cdC8vIE5vIGFjdGlvbiBmb3VuZCAtIGp1c3Qgc2hvdyB0aGUgcmF3IHZhbHVlc1xuXHRyZXR1cm4gYCR7cHJlZml4fSB8IFVua25vd24gU2V0dGluZ2Bcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgUEFSU0VSIERJU1BBVENIIFdJVEggQVVUTy1ERVRFQ1RJT05cbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBQYXJzZXMgZ2V0QWxsU2V0dGluZ3MgcmVzcG9uc2Ugd2l0aCBhdXRvbWF0aWMgZm9ybWF0IGRldGVjdGlvbi5cbiAqXG4gKiBAcmV0dXJucyB7c2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXSwgZGV0ZWN0ZWRTZWN0aW9uZWQ6IGJvb2xlYW4gfCBudWxsfVxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24oXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGJ1ZjogQnVmZmVyLFxuKTogeyBzZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdOyBkZXRlY3RlZFNlY3Rpb25lZDogYm9vbGVhbiB8IG51bGwgfSB7XG5cdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0Y29uc3QgZGVjbGFyZWRTZWN0aW9uZWQgPSBzY2hlbWE/LnNlY3Rpb25lZFxuXG5cdC8vIElmIGV4cGxpY2l0bHkgZGVjbGFyZWQgaW4gSlNPTiwgdXNlIHRoYXRcblx0aWYgKGRlY2xhcmVkU2VjdGlvbmVkICE9PSB1bmRlZmluZWQpIHtcblx0XHRjb25zdCBzZXR0aW5ncyA9IGRlY2xhcmVkU2VjdGlvbmVkXG5cdFx0XHQ/IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpXG5cdFx0XHQ6IHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWYsIG1vZGVsKVxuXHRcdHJldHVybiB7IHNldHRpbmdzLCBkZXRlY3RlZFNlY3Rpb25lZDogbnVsbCB9IC8vIG51bGwgPSB1c2VkIGRlY2xhcmVkIHZhbHVlXG5cdH1cblxuXHQvLyBObyBkZWNsYXJhdGlvbiAtIHRyeSBib3RoIHBhcnNlcnMgYW5kIHBpY2sgdGhlIGJlc3Qgb25lXG5cdGxldCBmbGF0U2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXSA9IFtdXG5cdGxldCBzZWN0aW9uZWRTZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdID0gW11cblxuXHR0cnkge1xuXHRcdGZsYXRTZXR0aW5ncyA9IHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWYsIG1vZGVsKVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0bG9nZ2VyLmRlYnVnKGBGbGF0IHBhcnNlciBmYWlsZWQ6ICR7ZX1gKVxuXHR9XG5cblx0dHJ5IHtcblx0XHRzZWN0aW9uZWRTZXR0aW5ncyA9IHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRsb2dnZXIuZGVidWcoYFNlY3Rpb25lZCBwYXJzZXIgZmFpbGVkOiAke2V9YClcblx0fVxuXG5cdC8vIFBpY2sgdGhlIHBhcnNlciB0aGF0IHJldHVybmVkIG1vcmUgc2V0dGluZ3Ncblx0aWYgKHNlY3Rpb25lZFNldHRpbmdzLmxlbmd0aCA+IGZsYXRTZXR0aW5ncy5sZW5ndGgpIHtcblx0XHRsb2dnZXIuaW5mbyhgQXV0by1kZXRlY3RlZCBTRUNUSU9ORUQgZm9ybWF0IChzZWN0aW9uZWQ9JHtzZWN0aW9uZWRTZXR0aW5ncy5sZW5ndGh9IHZzIGZsYXQ9JHtmbGF0U2V0dGluZ3MubGVuZ3RofSlgKVxuXHRcdHJldHVybiB7IHNldHRpbmdzOiBzZWN0aW9uZWRTZXR0aW5ncywgZGV0ZWN0ZWRTZWN0aW9uZWQ6IHRydWUgfVxuXHR9IGVsc2UgaWYgKGZsYXRTZXR0aW5ncy5sZW5ndGggPiAwKSB7XG5cdFx0bG9nZ2VyLmluZm8oYEF1dG8tZGV0ZWN0ZWQgRkxBVCBmb3JtYXQgKGZsYXQ9JHtmbGF0U2V0dGluZ3MubGVuZ3RofSB2cyBzZWN0aW9uZWQ9JHtzZWN0aW9uZWRTZXR0aW5ncy5sZW5ndGh9KWApXG5cdFx0cmV0dXJuIHsgc2V0dGluZ3M6IGZsYXRTZXR0aW5ncywgZGV0ZWN0ZWRTZWN0aW9uZWQ6IGZhbHNlIH1cblx0fSBlbHNlIHtcblx0XHQvLyBCb3RoIHBhcnNlcnMgcmV0dXJuZWQgMCBzZXR0aW5nc1xuXHRcdGxvZ2dlci53YXJuKGBXYXJuaW5nOiBCb3RoIHBhcnNlcnMgcmV0dXJuZWQgMCBzZXR0aW5ncyBmb3IgbW9kZWwgJHttb2RlbH1gKVxuXHRcdHJldHVybiB7IHNldHRpbmdzOiBbXSwgZGV0ZWN0ZWRTZWN0aW9uZWQ6IG51bGwgfVxuXHR9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwobW9kZWw6IHN0cmluZywgYnVmOiBCdWZmZXIpOiBQYXJzZWRTZXR0aW5nW10ge1xuXHRjb25zdCB7IHNlY3Rpb25lZCB9ID0gZ2V0TW9kZWxDb25maWcobW9kZWwpXG5cdHJldHVybiBzZWN0aW9uZWQgPyBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWYsIG1vZGVsKSA6IHBhcnNlR2V0QWxsU2V0dGluZ3NfZmxhdChidWYsIG1vZGVsKVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBWQUxVRSBcdTIxOTIgT1BUSU9OXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIHZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzOiBudW1iZXJbXSk6IFN0QWN0aW9uT3B0aW9uIHtcblx0aWYgKHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxKSB7XG5cdFx0cmV0dXJuIHsgaWQ6ICd2YWx1ZScsIGxhYmVsOiAnVmFsdWUnLCB0eXBlOiAnbnVtYmVyJywgZGVmYXVsdDogdmFsdWVCeXRlc1swXSB9XG5cdH1cblxuXHRpZiAodmFsdWVCeXRlcy5sZW5ndGggPT09IDMpIHtcblx0XHRjb25zdCBbciwgZywgYl0gPSB2YWx1ZUJ5dGVzXG5cdFx0cmV0dXJuIHtcblx0XHRcdGlkOiAndmFsdWUnLFxuXHRcdFx0bGFiZWw6ICdDb2xvcicsXG5cdFx0XHR0eXBlOiAnY29sb3JwaWNrZXInLFxuXHRcdFx0ZGVmYXVsdDogZm9ybWF0UmdiQ29sb3IociwgZywgYiksXG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIHsgaWQ6ICd2YWx1ZScsIGxhYmVsOiAnVmFsdWUnLCB0eXBlOiAncmF3JywgZGVmYXVsdDogWy4uLnZhbHVlQnl0ZXNdIH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgU01BUlQgSlNPTiBVUERBVEVcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZU1vZGVsSnNvbkZyb21TZXR0aW5ncyhcblx0bW9kZWxKc29uOiBTdE1vZGVsSnNvbixcblx0cGFyc2VkOiBQYXJzZWRTZXR0aW5nW10sXG5cdGFsbE1vZGVsczogUmVjb3JkPHN0cmluZywgU3RNb2RlbEpzb24+LFxuKTogU3RNb2RlbEpzb24ge1xuXHRjb25zdCBvdXQgPSBzdHJ1Y3R1cmVkQ2xvbmUobW9kZWxKc29uKVxuXG5cdC8vIEVuc3VyZSBjbWRTY2hlbWEgYXJyYXkgZXhpc3RzXG5cdGlmICghb3V0LmNtZFNjaGVtYSkge1xuXHRcdG91dC5jbWRTY2hlbWEgPSBbXVxuXHR9XG5cblx0Ly8gU29ydCBvdGhlciBtb2RlbHMgYnkgbnVtZXJpYyBkaXN0YW5jZSB0byBjdXJyZW50IG1vZGVsXG5cdGNvbnN0IGNhbmRpZGF0ZXMgPSBPYmplY3QudmFsdWVzKGFsbE1vZGVscylcblx0XHQuZmlsdGVyKChtKSA9PiBtLm1vZGVsICE9PSBtb2RlbEpzb24ubW9kZWwpIC8vIGV4Y2x1ZGUgc2VsZlxuXHRcdC5zb3J0KChhLCBiKSA9PiBtb2RlbERpc3RhbmNlKG1vZGVsSnNvbi5tb2RlbCwgYS5tb2RlbCkgLSBtb2RlbERpc3RhbmNlKG1vZGVsSnNvbi5tb2RlbCwgYi5tb2RlbCkpXG5cblx0bG9nZ2VyLmluZm8oYFVwZGF0aW5nIG1vZGVsOiAke21vZGVsSnNvbi5tb2RlbH1gKVxuXHRsb2dnZXIuZGVidWcoYENhbmRpZGF0ZXMgZm9yIGluZmVyZW5jZTogJHtjYW5kaWRhdGVzLm1hcCgoYykgPT4gYy5tb2RlbCkuam9pbignLCAnKX1gKVxuXG5cdC8vIFByZS1zY2FuOiBmb3IgZWFjaCBjYW5kaWRhdGUgaWRBZGQgYmFzZSBlbnRyeSwgZmluZCB0aGUgbWF4aW11bSBzZXF1ZW50aWFsXG5cdC8vIG9mZnNldCB0aGUgcGFja2V0IGNvbnRhaW5zIChldmVuIGJleW9uZCB3aGF0IHRoZSByZWZlcmVuY2UgbW9kZWwga25vd3MpLlxuXHQvLyBLZXk6IGAke2NtZF9pZH1fJHtiYXNlX2lkfWAsIHZhbHVlOiBtYXggc2VxdWVudGlhbCBvZmZzZXQgc2VlbiBpbiBwYXJzZWQgZGF0YS5cblx0Y29uc3QgaWRBZGREZWZlclJhbmdlcyA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KClcblx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRmb3IgKGNvbnN0IGJhc2VFbnRyeSBvZiBjLmNtZFNjaGVtYSA/PyBbXSkge1xuXHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBiYXNlRW50cnkub3B0aW9ucz8uZmluZCgobzogYW55KSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdD8uY2hvaWNlcykgY29udGludWVcblx0XHRcdGNvbnN0IGJhc2VJZCA9IGJhc2VFbnRyeS5pZFxuXHRcdFx0Y29uc3QgY21kSWQgPSBiYXNlRW50cnkuY21kX2lkXG5cdFx0XHRjb25zdCBrZXkgPSBgJHtjbWRJZH1fJHtiYXNlSWR9YFxuXHRcdFx0aWYgKGlkQWRkRGVmZXJSYW5nZXMuaGFzKGtleSkpIGNvbnRpbnVlXG5cdFx0XHQvLyBGaW5kIHRoZSBtYXggc2VxdWVudGlhbCBvZmZzZXQgcHJlc2VudCBpbiB0aGUgcGFyc2VkIHBhY2tldCBmb3IgdGhpcyBiYXNlXG5cdFx0XHRjb25zdCBwYXJzZWRPZmZzZXRzID0gcGFyc2VkXG5cdFx0XHRcdC5maWx0ZXIoKHApID0+IHAuY21kX2lkID09PSBjbWRJZCAmJiBwLmlkID4gYmFzZUlkKVxuXHRcdFx0XHQubWFwKChwKSA9PiBwLmlkIC0gYmFzZUlkKVxuXHRcdFx0XHQuc29ydCgoYSwgYikgPT4gYSAtIGIpXG5cdFx0XHQvLyBXYWxrIGZyb20gMSB1cHdhcmQgXHUyMDE0IHN0b3AgYXQgZmlyc3QgZ2FwXG5cdFx0XHRsZXQgbWF4U2VxID0gMFxuXHRcdFx0Zm9yIChjb25zdCBvZmYgb2YgcGFyc2VkT2Zmc2V0cykge1xuXHRcdFx0XHRpZiAob2ZmID09PSBtYXhTZXEgKyAxKSBtYXhTZXEgPSBvZmZcblx0XHRcdFx0ZWxzZSBpZiAob2ZmID4gbWF4U2VxICsgMSkgYnJlYWtcblx0XHRcdH1cblx0XHRcdGlmIChtYXhTZXEgPiAwKSB7XG5cdFx0XHRcdGlkQWRkRGVmZXJSYW5nZXMuc2V0KGtleSwgbWF4U2VxKVxuXHRcdFx0XHRsb2dnZXIuZGVidWcoYGlkQWRkIGRlZmVyIHJhbmdlIGZvciBjbWRfaWQ9JHt0b0hleChjbWRJZCl9IGJhc2VfaWQ9JHt0b0hleChiYXNlSWQpfTogb2Zmc2V0cyAxXHUyMDEzJHttYXhTZXF9YClcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHQvLyBQcmUtY29tcHV0ZSB0aGUgc2V0IG9mIGFsbCBidXNDaCB2YWx1ZXMgc2VlbiBwZXIgKGNtZF9pZCwgaWQpIHBhaXIgYWNyb3NzIHRoZSBmdWxsXG5cdC8vIHBhcnNlZCByZXNwb25zZSBcdTIwMTQgdXNlZCBsYXRlciB0byBkZWNpZGUgZml4ZWQgdnMuIHNlbGVjdGFibGUgYnVzQ2guXG5cdGNvbnN0IGJ1c0NoU2VlbiA9IG5ldyBNYXA8c3RyaW5nLCBTZXQ8bnVtYmVyPj4oKVxuXHRmb3IgKGNvbnN0IHsgY21kX2lkLCBpZCwgYnVzQ2ggfSBvZiBwYXJzZWQpIHtcblx0XHRpZiAoYnVzQ2ggPT09IHVuZGVmaW5lZCkgY29udGludWVcblx0XHRjb25zdCBrZXkgPSBgJHtjbWRfaWR9XyR7aWR9YFxuXHRcdGlmICghYnVzQ2hTZWVuLmhhcyhrZXkpKSBidXNDaFNlZW4uc2V0KGtleSwgbmV3IFNldCgpKVxuXHRcdGJ1c0NoU2Vlbi5nZXQoa2V5KSEuYWRkKGJ1c0NoKVxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBQQVNTIDE6IHJlc29sdmUgZWFjaCBwYXJzZWQgZW50cnkgXHUyMDE0IGV4YWN0IG1hdGNoLCBpbmZlcnJlZCxcblx0Ly8gaWRBZGQtZm9sZCAob2Zmc2V0IGludG8gYW4gYWxyZWFkeS1hZGRlZCBiYXNlIGVudHJ5KSwgb3IgdW5rbm93blxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdGZvciAoY29uc3QgeyBjbWRfaWQsIGlkLCBidXNDaCwgdmFsdWVCeXRlcyB9IG9mIHBhcnNlZCkge1xuXHRcdC8vIDFhLiBFeGFjdCBtYXRjaCBhbHJlYWR5IGluIG91dHB1dCBzY2hlbWEgXHUyMDE0IHJlZnJlc2ggdGhlIGRlZmF1bHQgYW5kIHN5bmMgYnVzQ2hcblx0XHRjb25zdCBleGlzdGluZ0V4YWN0ID0gb3V0LmNtZFNjaGVtYS5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXHRcdGlmIChleGlzdGluZ0V4YWN0KSB7XG5cdFx0XHRjb25zdCBvcHQgPSBleGlzdGluZ0V4YWN0Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICd2YWx1ZScpXG5cdFx0XHRpZiAob3B0KSBvcHQuZGVmYXVsdCA9IHZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzKS5kZWZhdWx0XG5cblx0XHRcdC8vIFN5bmMgYnVzQ2ggZnJvbSBwYWNrZXQgZGF0YSBpZiB0aGUgZXhpc3RpbmcgZW50cnkgaXMgbWlzc2luZyBpdFxuXHRcdFx0Y29uc3Qgc2VlbkJ1c0NoVmFsdWVzID0gYnVzQ2hTZWVuLmdldChgJHtjbWRfaWR9XyR7aWR9YClcblx0XHRcdGlmIChzZWVuQnVzQ2hWYWx1ZXMgJiYgc2VlbkJ1c0NoVmFsdWVzLnNpemUgPiAwKSB7XG5cdFx0XHRcdGNvbnN0IG1heEJ1c0NoID0gTWF0aC5tYXgoLi4uc2VlbkJ1c0NoVmFsdWVzKVxuXHRcdFx0XHRjb25zdCBoYXNCdXNDaE9wdGlvbiA9IGV4aXN0aW5nRXhhY3Qub3B0aW9ucz8uc29tZSgobykgPT4gby5pZCA9PT0gJ2J1c0NoJylcblx0XHRcdFx0aWYgKG1heEJ1c0NoID09PSAwICYmIGV4aXN0aW5nRXhhY3QuYnVzQ2ggPT09IHVuZGVmaW5lZCAmJiAhaGFzQnVzQ2hPcHRpb24pIHtcblx0XHRcdFx0XHRleGlzdGluZ0V4YWN0LmJ1c0NoID0gMFxuXHRcdFx0XHRcdGxvZ2dlci5pbmZvKGBTeW5jZWQgYnVzQ2g9MCBvbnRvIGV4aXN0aW5nIGVudHJ5IGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfWApXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGNvbnRpbnVlXG5cdFx0fVxuXG5cdFx0Ly8gMWIuIENoZWNrIGlmIHRoaXMgaWQgZm9sZHMgaW50byBhbiBhbHJlYWR5LWFkZGVkIGJhc2UgZW50cnkgdmlhIGlkQWRkLlxuXHRcdC8vICAgICBHYXRlOiB0aGUgb2Zmc2V0IG11c3QgYWN0dWFsbHkgZXhpc3QgaW4gdGhlIHJlZmVyZW5jZSBtb2RlbCdzIGlkQWRkIGNob2ljZXNcblx0XHQvLyAgICAgdG8gYXZvaWQgc3dhbGxvd2luZyB1bnJlbGF0ZWQgc2FtZS1jbWRfaWQgZW50cmllcyAoZS5nLiBTaWRldG9uZSBhdCBpZD0yMSkuXG5cdFx0Y29uc3QgaWRBZGRCYXNlID0gb3V0LmNtZFNjaGVtYS5maW5kKChhKSA9PiB7XG5cdFx0XHRpZiAoYS5jbWRfaWQgIT09IGNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBpZEFkZE9wdCA9IGEub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmICghaWRBZGRPcHQ/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0aWYgKGlkIDw9IGEuaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3Qgb2Zmc2V0ID0gaWQgLSBhLmlkXG5cdFx0XHQvLyBPbmx5IGZvbGQgaWYgYSByZWZlcmVuY2UgbW9kZWwgZXhwbGljaXRseSBsaXN0cyB0aGlzIG9mZnNldCBpbiBpdHMgaWRBZGQgY2hvaWNlc1xuXHRcdFx0cmV0dXJuIGNhbmRpZGF0ZXMuc29tZSgoYykgPT4ge1xuXHRcdFx0XHRjb25zdCByZWZFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChyKSA9PiByLmNtZF9pZCA9PT0gY21kX2lkICYmIHIuaWQgPT09IGEuaWQpXG5cdFx0XHRcdGNvbnN0IHJlZklkQWRkID0gcmVmRW50cnk/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdHJldHVybiByZWZJZEFkZD8uY2hvaWNlcz8uc29tZSgoY2g6IGFueSkgPT4gY2guaWQgPT09IG9mZnNldClcblx0XHRcdH0pXG5cdFx0fSlcblx0XHRpZiAoaWRBZGRCYXNlKSB7XG5cdFx0XHRjb25zdCBvZmZzZXQgPSBpZCAtIGlkQWRkQmFzZS5pZFxuXHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBpZEFkZEJhc2Uub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGlmIChpZEFkZE9wdD8uY2hvaWNlcyAmJiAhaWRBZGRPcHQuY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9mZnNldCkpIHtcblx0XHRcdFx0bGV0IGxhYmVsID0gYENoYW5uZWwgJHtvZmZzZXQgKyAxfWBcblx0XHRcdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdFx0XHRjb25zdCByZWZFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkQWRkQmFzZS5pZClcblx0XHRcdFx0XHRjb25zdCByZWZJZEFkZCA9IHJlZkVudHJ5Py5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRcdGNvbnN0IHJlZkNob2ljZSA9IHJlZklkQWRkPy5jaG9pY2VzPy5maW5kKChjaDogYW55KSA9PiBjaC5pZCA9PT0gb2Zmc2V0KVxuXHRcdFx0XHRcdGlmIChyZWZDaG9pY2UpIHtcblx0XHRcdFx0XHRcdGxhYmVsID0gcmVmQ2hvaWNlLmxhYmVsXG5cdFx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRpZEFkZE9wdC5jaG9pY2VzLnB1c2goeyBpZDogb2Zmc2V0LCBsYWJlbCB9KVxuXHRcdFx0XHRsb2dnZXIuaW5mbyhcblx0XHRcdFx0XHRgRm9sZGVkIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfSBpbnRvIGlkQWRkIGJhc2UgaWQ9JHt0b0hleChpZEFkZEJhc2UuaWQpfSBhcyBvZmZzZXQgJHtvZmZzZXR9IChcIiR7bGFiZWx9XCIpYCxcblx0XHRcdFx0KVxuXHRcdFx0fVxuXHRcdFx0Y29udGludWVcblx0XHR9XG5cblx0XHQvLyAxYy4gTm8gZXhhY3QgbWF0Y2ggXHUyMDE0IHRyeSBpbmZlcmVuY2UgZnJvbSBjYW5kaWRhdGUgbW9kZWxzXG5cdFx0bGV0IGFjdGlvbjogU3RBY3Rpb24gfCB1bmRlZmluZWRcblxuXHRcdGZvciAoY29uc3QgYyBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0XHRjb25zdCBtYXRjaCA9IGMuY21kU2NoZW1hPy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kX2lkICYmIGEuaWQgPT09IGlkKVxuXHRcdFx0aWYgKG1hdGNoKSB7XG5cdFx0XHRcdGFjdGlvbiA9IHN0cnVjdHVyZWRDbG9uZShtYXRjaClcblx0XHRcdFx0Ly8gU3RyaXAgYW55IGV4aXN0aW5nIFwiKGluZmVycmVkIGZyb20gTW9kZWwgWClcIiBzdWZmaXhlcyBiZWZvcmUgYWRkaW5nIG91ciBvd25cblx0XHRcdFx0Y29uc3QgYmFzZU5hbWUgPSBtYXRjaC5uYW1lLnJlcGxhY2UoL1xccypcXChpbmZlcnJlZCBmcm9tIE1vZGVsIFteKV0rXFwpL2csICcnKS50cmltKClcblx0XHRcdFx0YWN0aW9uLm5hbWUgPSBgJHtiYXNlTmFtZX0gKGluZmVycmVkIGZyb20gTW9kZWwgJHtjLm1vZGVsfSlgXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBJbmZlcnJlZCBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gZnJvbSBNb2RlbCAke2MubW9kZWx9IChleGFjdClgKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIENoZWNrIGlmIHRoaXMgaWQgc2hvdWxkIGJlIGRlZmVycmVkIHRvIHBhc3MgMiBcdTIwMTRcblx0XHQvLyBpdCdzIGEgc2VxdWVudGlhbCBpZEFkZCBvZmZzZXQgb2YgYSBrbm93biBjYW5kaWRhdGUgYmFzZSBlbnRyeS5cblx0XHRpZiAoIWFjdGlvbikge1xuXHRcdFx0bGV0IHNob3VsZERlZmVyID0gZmFsc2Vcblx0XHRcdGZvciAoY29uc3QgYyBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0XHRcdGNvbnN0IGJhc2VFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChhOiBhbnkpID0+IHtcblx0XHRcdFx0XHRpZiAoYS5jbWRfaWQgIT09IGNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBhLm9wdGlvbnM/LmZpbmQoKG86IGFueSkgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0XHRpZiAoIWlkQWRkT3B0Py5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRpZiAoaWQgPD0gYS5pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0Y29uc3Qgb2Zmc2V0ID0gaWQgLSBhLmlkXG5cdFx0XHRcdFx0Y29uc3QgbWF4U2VxID0gaWRBZGREZWZlclJhbmdlcy5nZXQoYCR7Y21kX2lkfV8ke2EuaWR9YCkgPz8gMFxuXHRcdFx0XHRcdHJldHVybiBvZmZzZXQgPD0gbWF4U2VxXG5cdFx0XHRcdH0pXG5cdFx0XHRcdGlmIChiYXNlRW50cnkpIHtcblx0XHRcdFx0XHRzaG91bGREZWZlciA9IHRydWVcblx0XHRcdFx0XHRsb2dnZXIuZGVidWcoXG5cdFx0XHRcdFx0XHRgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9IGlzIGFuIGlkQWRkIG9mZnNldCBvZiBjYW5kaWRhdGUgYmFzZSBpZD0ke3RvSGV4KGJhc2VFbnRyeS5pZCl9IFx1MjAxNCBkZWZlcnJpbmcgdG8gcGFzcyAyYCxcblx0XHRcdFx0XHQpXG5cdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKHNob3VsZERlZmVyKSBjb250aW51ZVxuXHRcdH1cblxuXHRcdC8vIEZhbGxiYWNrOiB1bmtub3duIHNldHRpbmdcblx0XHRpZiAoIWFjdGlvbikge1xuXHRcdFx0YWN0aW9uID0ge1xuXHRcdFx0XHRjbWRfaWQsXG5cdFx0XHRcdGlkLFxuXHRcdFx0XHRuYW1lOiBgVW5rbm93biBjbWQ6JHt0b0hleChjbWRfaWQpfSBpZDoke3RvSGV4KGlkKS50b1VwcGVyQ2FzZSgpfWAsXG5cdFx0XHRcdG9wdGlvbnM6IFt2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlcyldLFxuXHRcdFx0fVxuXHRcdFx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIGFjdGlvbi5idXNDaCA9IGJ1c0NoXG5cdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IGluZmVyIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfWApXG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBGaXggMTogYnVzQ2ggaGFuZGxpbmcgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHQvLyBTdHJpcCBhbnkgaW5oZXJpdGVkIGJ1c0NoIG9wdGlvbiBmcm9tIHRoZSBjYW5kaWRhdGUgXHUyMDE0IHdlJ2xsIHJlLWRlcml2ZVxuXHRcdFx0Ly8gaXQgZnJvbSB3aGF0IHRoZSBwYWNrZXQgYWN0dWFsbHkgcmVwb3J0ZWQgZm9yIHRoaXMgZGV2aWNlLlxuXHRcdFx0YWN0aW9uLm9wdGlvbnMgPSBhY3Rpb24ub3B0aW9ucz8uZmlsdGVyKChvKSA9PiBvLmlkICE9PSAnYnVzQ2gnKSA/PyBbXVxuXHRcdFx0ZGVsZXRlIGFjdGlvbi5idXNDaFxuXG5cdFx0XHRjb25zdCBzZWVuQnVzQ2hWYWx1ZXMgPSBidXNDaFNlZW4uZ2V0KGAke2NtZF9pZH1fJHtpZH1gKVxuXHRcdFx0aWYgKHNlZW5CdXNDaFZhbHVlcyAmJiBzZWVuQnVzQ2hWYWx1ZXMuc2l6ZSA+IDApIHtcblx0XHRcdFx0Y29uc3QgbWF4QnVzQ2ggPSBNYXRoLm1heCguLi5zZWVuQnVzQ2hWYWx1ZXMpXG5cdFx0XHRcdGlmIChtYXhCdXNDaCA9PT0gMCkge1xuXHRcdFx0XHRcdC8vIE9ubHkgZXZlciBzYXcgYnVzQ2g9MCBcdTIxOTIgZml4ZWQgcHJvcGVydHksIG5vdCBhbiBvcHRpb25cblx0XHRcdFx0XHRhY3Rpb24uYnVzQ2ggPSAwXG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0Ly8gTXVsdGlwbGUgY2hhbm5lbHMgb2JzZXJ2ZWQgXHUyMTkyIHNlbGVjdGFibGUgb3B0aW9uXG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2hDaG9pY2VzID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogbWF4QnVzQ2ggKyAxIH0sIChfLCBpKSA9PiAoe1xuXHRcdFx0XHRcdFx0aWQ6IGksXG5cdFx0XHRcdFx0XHRsYWJlbDogYENoYW5uZWwgJHtpICsgMX1gLFxuXHRcdFx0XHRcdH0pKVxuXHRcdFx0XHRcdGFjdGlvbi5vcHRpb25zLnVuc2hpZnQoe1xuXHRcdFx0XHRcdFx0aWQ6ICdidXNDaCcsXG5cdFx0XHRcdFx0XHRsYWJlbDogJ0NoYW5uZWwnLFxuXHRcdFx0XHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdFx0XHRcdGNob2ljZXM6IGJ1c0NoQ2hvaWNlcyxcblx0XHRcdFx0XHRcdGRlZmF1bHQ6IDAsXG5cdFx0XHRcdFx0fSBhcyBhbnkpXG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIEZpeCAyOiBkZWZhdWx0IG11c3QgZXhpc3QgaW4gY2hvaWNlcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRcdC8vIFNldCB0aGUgZGVmYXVsdCB0byB0aGUgb2JzZXJ2ZWQgdmFsdWUuIElmIHRoYXQgdmFsdWUgaXNuJ3QgaW4gdGhlXG5cdFx0XHQvLyBpbmhlcml0ZWQgY2hvaWNlcyBsaXN0LCB0aGUgY2hvaWNlcyBhcmUgZnJvbSBhIHN0cnVjdHVyYWxseSBkaWZmZXJlbnRcblx0XHRcdC8vIG1vZGVsIGFuZCBjYW4ndCBiZSB0cnVzdGVkIFx1MjAxNCBkaXNjYXJkIHRoZW0gYW5kIGZhbGwgYmFjayB0byBhIHBsYWluIG51bWJlci5cblx0XHRcdGNvbnN0IG9ic2VydmVkRGVmYXVsdCA9IHZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzKS5kZWZhdWx0XG5cdFx0XHRjb25zdCB2YWx1ZU9wdCA9IGFjdGlvbi5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAndmFsdWUnKVxuXHRcdFx0aWYgKHZhbHVlT3B0KSB7XG5cdFx0XHRcdGlmICh2YWx1ZU9wdC5jaG9pY2VzICYmIEFycmF5LmlzQXJyYXkodmFsdWVPcHQuY2hvaWNlcykpIHtcblx0XHRcdFx0XHRjb25zdCBpbkNob2ljZXMgPSB2YWx1ZU9wdC5jaG9pY2VzLnNvbWUoKGM6IGFueSkgPT4gYy5pZCA9PT0gb2JzZXJ2ZWREZWZhdWx0KVxuXHRcdFx0XHRcdGlmICghaW5DaG9pY2VzKSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIud2Fybihcblx0XHRcdFx0XHRcdFx0YEluZmVycmVkIGNob2ljZXMgZm9yIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfSBkb24ndCBjb250YWluIG9ic2VydmVkIHZhbHVlICR7b2JzZXJ2ZWREZWZhdWx0fSBcdTIwMTQgZGlzY2FyZGluZyBpbmhlcml0ZWQgY2hvaWNlc2AsXG5cdFx0XHRcdFx0XHQpXG5cdFx0XHRcdFx0XHQvLyBLZWVwIGxhYmVsL3Rvb2x0aXAgYnV0IGRyb3AgY2hvaWNlcywgc3dpdGNoIHRvIHBsYWluIG51bWJlclxuXHRcdFx0XHRcdFx0dmFsdWVPcHQudHlwZSA9ICdudW1iZXInXG5cdFx0XHRcdFx0XHRkZWxldGUgKHZhbHVlT3B0IGFzIGFueSkuY2hvaWNlc1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHR2YWx1ZU9wdC5kZWZhdWx0ID0gb2JzZXJ2ZWREZWZhdWx0XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0b3V0LmNtZFNjaGVtYS5wdXNoKGFjdGlvbilcblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gUEFTUyAyOiBmb2xkIGFueSBkZWZlcnJlZCBpZEFkZCBvZmZzZXRzIHdob3NlIGJhc2UgZW50cnlcblx0Ly8gaXMgbm93IHByZXNlbnQgaW4gdGhlIG91dHB1dCBzY2hlbWEuXG5cdC8vIEdhdGU6IHRoZSBvZmZzZXQgbXVzdCBlaXRoZXIgZXhpc3QgaW4gYSByZWZlcmVuY2UgbW9kZWwncyBjaG9pY2VzLFxuXHQvLyBPUiB0aGUgYmFzZSBlbnRyeSBpdHNlbGYgd2FzIGluZmVycmVkIChoYXMgaWRBZGQpIGFuZCB0aGUgb2Zmc2V0XG5cdC8vIGNvbnRpbnVlcyBzZXF1ZW50aWFsbHkgYmV5b25kIHRoZSByZWZlcmVuY2UgbW9kZWwncyBrbm93biByYW5nZS5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHRmb3IgKGNvbnN0IHsgY21kX2lkLCBpZCB9IG9mIHBhcnNlZCkge1xuXHRcdGNvbnN0IGFscmVhZHlUb3BMZXZlbCA9IG91dC5jbWRTY2hlbWEuc29tZSgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZF9pZCAmJiBhLmlkID09PSBpZClcblx0XHRpZiAoYWxyZWFkeVRvcExldmVsKSBjb250aW51ZVxuXG5cdFx0Ly8gRmluZCBhIGJhc2UgZW50cnkgaW4gdGhlIG91dHB1dCB0aGF0IGhhcyBpZEFkZCBhbmQgd2hvc2UgaWQgPCB0aGlzIGlkXG5cdFx0Y29uc3QgaWRBZGRCYXNlID0gb3V0LmNtZFNjaGVtYS5maW5kKChhKSA9PiB7XG5cdFx0XHRpZiAoYS5jbWRfaWQgIT09IGNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBpZEFkZE9wdCA9IGEub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdHJldHVybiAhIWlkQWRkT3B0Py5jaG9pY2VzICYmIGlkID4gYS5pZFxuXHRcdH0pXG5cdFx0aWYgKCFpZEFkZEJhc2UpIGNvbnRpbnVlXG5cblx0XHRjb25zdCBvZmZzZXQgPSBpZCAtIGlkQWRkQmFzZS5pZFxuXHRcdGNvbnN0IGlkQWRkT3B0ID0gaWRBZGRCYXNlLm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0aWYgKCFpZEFkZE9wdD8uY2hvaWNlcyB8fCBpZEFkZE9wdC5jaG9pY2VzLnNvbWUoKGM6IGFueSkgPT4gYy5pZCA9PT0gb2Zmc2V0KSkgY29udGludWVcblxuXHRcdC8vIEFjY2VwdCB0aGUgZm9sZCBpZjogYSByZWZlcmVuY2UgbW9kZWwgZXhwbGljaXRseSBoYXMgdGhpcyBvZmZzZXQsXG5cdFx0Ly8gT1IgdGhlIG9mZnNldHMgYXJlIHN0cmljdGx5IHNlcXVlbnRpYWwgZnJvbSAwIChkZXZpY2UgaGFzIG1vcmUgY2hhbm5lbHMgdGhhbiByZWZlcmVuY2UpXG5cdFx0Y29uc3QgcmVmSGFzT2Zmc2V0ID0gY2FuZGlkYXRlcy5zb21lKChjKSA9PiB7XG5cdFx0XHRjb25zdCByZWZFbnRyeSA9IGMuY21kU2NoZW1hPy5maW5kKChyKSA9PiByLmNtZF9pZCA9PT0gY21kX2lkICYmIHIuaWQgPT09IGlkQWRkQmFzZS5pZClcblx0XHRcdGNvbnN0IHJlZklkQWRkID0gcmVmRW50cnk/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRyZXR1cm4gcmVmSWRBZGQ/LmNob2ljZXM/LnNvbWUoKGNoOiBhbnkpID0+IGNoLmlkID09PSBvZmZzZXQpXG5cdFx0fSlcblx0XHRjb25zdCBleGlzdGluZ09mZnNldHMgPSBpZEFkZE9wdC5jaG9pY2VzLm1hcCgoYzogYW55KSA9PiBjLmlkIGFzIG51bWJlcikuc29ydCgoYSwgYikgPT4gYSAtIGIpXG5cdFx0Y29uc3QgaXNTZXF1ZW50aWFsID0gZXhpc3RpbmdPZmZzZXRzLmxlbmd0aCA+IDAgJiYgb2Zmc2V0ID09PSBleGlzdGluZ09mZnNldHNbZXhpc3RpbmdPZmZzZXRzLmxlbmd0aCAtIDFdICsgMVxuXG5cdFx0aWYgKCFyZWZIYXNPZmZzZXQgJiYgIWlzU2VxdWVudGlhbCkgY29udGludWVcblxuXHRcdC8vIEluaGVyaXQgbGFiZWwgZnJvbSByZWZlcmVuY2UgbW9kZWwgaWYgYXZhaWxhYmxlLCBvdGhlcndpc2UgZ2VuZXJhdGUgb25lXG5cdFx0bGV0IGxhYmVsID0gYENoYW5uZWwgJHtvZmZzZXQgKyAxfWBcblx0XHRmb3IgKGNvbnN0IGMgb2YgY2FuZGlkYXRlcykge1xuXHRcdFx0Y29uc3QgcmVmRW50cnkgPSBjLmNtZFNjaGVtYT8uZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZF9pZCAmJiBhLmlkID09PSBpZEFkZEJhc2UuaWQpXG5cdFx0XHRjb25zdCByZWZJZEFkZCA9IHJlZkVudHJ5Py5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0Y29uc3QgcmVmQ2hvaWNlID0gcmVmSWRBZGQ/LmNob2ljZXM/LmZpbmQoKGNoOiBhbnkpID0+IGNoLmlkID09PSBvZmZzZXQpXG5cdFx0XHRpZiAocmVmQ2hvaWNlKSB7XG5cdFx0XHRcdGxhYmVsID0gcmVmQ2hvaWNlLmxhYmVsXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0aWRBZGRPcHQuY2hvaWNlcy5wdXNoKHsgaWQ6IG9mZnNldCwgbGFiZWwgfSlcblx0XHRsb2dnZXIuaW5mbyhcblx0XHRcdGBQYXNzIDI6IEZvbGRlZCBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gaW50byBpZEFkZCBiYXNlIGlkPSR7dG9IZXgoaWRBZGRCYXNlLmlkKX0gYXMgb2Zmc2V0ICR7b2Zmc2V0fSAoXCIke2xhYmVsfVwiKWAsXG5cdFx0KVxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBTQVZFXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCBmdW5jdGlvbiBzYXZlTW9kZWxKc29uUHJldHR5KGZpbGVQYXRoOiBzdHJpbmcsIGpzb25PYmo6IFN0TW9kZWxKc29uKTogdm9pZCB7XG5cdHRyeSB7XG5cdFx0Ly8gRW5zdXJlIHByb3BlciBrZXkgb3JkZXJpbmc6IG1vZGVsLCBzZWN0aW9uZWQgKGlmIHByZXNlbnQpLCByZWZyZXNoQWZ0ZXJDb21tYW5kLCBjbWRTY2hlbWFcblx0XHRjb25zdCBvcmRlcmVkT2JqOiBhbnkgPSB7IG1vZGVsOiBqc29uT2JqLm1vZGVsIH1cblxuXHRcdC8vIEFkZCBzZWN0aW9uZWQga2V5IGlmIHByZXNlbnQgKHJpZ2h0IGFmdGVyIG1vZGVsKVxuXHRcdGlmICgnc2VjdGlvbmVkJyBpbiBqc29uT2JqKSB7XG5cdFx0XHRvcmRlcmVkT2JqLnNlY3Rpb25lZCA9IGpzb25PYmouc2VjdGlvbmVkXG5cdFx0fVxuXG5cdFx0Ly8gQWRkIG90aGVyIGtleXMgaW4gb3JkZXJcblx0XHRpZiAoJ2NtZFNjaGVtYScgaW4ganNvbk9iaikge1xuXHRcdFx0b3JkZXJlZE9iai5jbWRTY2hlbWEgPSBqc29uT2JqLmNtZFNjaGVtYS5tYXAoKGVudHJ5OiBhbnkpID0+IHtcblx0XHRcdFx0Ly8gRW5mb3JjZSBrZXkgb3JkZXIgd2l0aGluIGVhY2ggc2NoZW1hIGVudHJ5OiBjbWRfaWQsIGlkLCBidXNDaCwgbmFtZSwgb3B0aW9uc1xuXHRcdFx0XHRjb25zdCBvcmRlcmVkRW50cnk6IGFueSA9IHt9XG5cdFx0XHRcdGlmICgnY21kX2lkJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5LmNtZF9pZCA9IGVudHJ5LmNtZF9pZFxuXHRcdFx0XHRpZiAoJ2lkJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5LmlkID0gZW50cnkuaWRcblx0XHRcdFx0aWYgKCdidXNDaCcgaW4gZW50cnkpIG9yZGVyZWRFbnRyeS5idXNDaCA9IGVudHJ5LmJ1c0NoXG5cdFx0XHRcdGlmICgnbmFtZScgaW4gZW50cnkpIG9yZGVyZWRFbnRyeS5uYW1lID0gZW50cnkubmFtZVxuXHRcdFx0XHRpZiAoJ29wdGlvbnMnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkub3B0aW9ucyA9IGVudHJ5Lm9wdGlvbnNcblx0XHRcdFx0Ly8gQ29weSBhbnkgcmVtYWluaW5nIGtleXNcblx0XHRcdFx0Zm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMoZW50cnkpKSB7XG5cdFx0XHRcdFx0aWYgKCEoa2V5IGluIG9yZGVyZWRFbnRyeSkpIG9yZGVyZWRFbnRyeVtrZXldID0gZW50cnlba2V5XVxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBvcmRlcmVkRW50cnlcblx0XHRcdH0pXG5cdFx0fVxuXHRcdC8vIENvcHkgYW55IG90aGVyIGtleXMgdGhhdCBtaWdodCBleGlzdFxuXHRcdGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGpzb25PYmopKSB7XG5cdFx0XHRpZiAoIShrZXkgaW4gb3JkZXJlZE9iaikpIHtcblx0XHRcdFx0b3JkZXJlZE9ialtrZXldID0gKGpzb25PYmogYXMgYW55KVtrZXldXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gQ3VzdG9tIGZvcm1hdHRlcjoga2VlcCBjaG9pY2Ugb2JqZWN0cyBjb21wYWN0IG9uIG9uZSBsaW5lXG5cdFx0bGV0IGpzb24gPSBKU09OLnN0cmluZ2lmeShvcmRlcmVkT2JqLCBudWxsLCAyKVxuXG5cdFx0Ly8gUmVwbGFjZSBleHBhbmRlZCBjaG9pY2Ugb2JqZWN0cyB3aXRoIGNvbXBhY3Qgc2luZ2xlLWxpbmUgZm9ybWF0XG5cdFx0Ly8gTWF0Y2hlczoge1xcbiAgICAgICAgICAgIFwiaWRcIjogWCxcXG4gICAgICAgICAgICBcImxhYmVsXCI6IFwiWVwiXFxuICAgICAgICAgIH1cblx0XHQvLyBSZXBsYWNlcyB3aXRoOiB7IFwiaWRcIjogWCwgXCJsYWJlbFwiOiBcIllcIiB9XG5cdFx0anNvbiA9IGpzb24ucmVwbGFjZSgvXFx7XFxuXFxzK1wiaWRcIjpcXHMqKFxcZCspLFxcblxccytcImxhYmVsXCI6XFxzKlwiKFteXCJdKilcIlxcblxccytcXH0vZywgJ3sgXCJpZFwiOiAkMSwgXCJsYWJlbFwiOiBcIiQyXCIgfScpXG5cblx0XHRmcy53cml0ZUZpbGVTeW5jKGZpbGVQYXRoLCBqc29uICsgJ1xcbicsICd1dGY4Jylcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5lcnJvcihgRmlsZSBXcml0ZSBFcnJvcjogJHtlfWApXG5cdH1cbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRGZWVkYmFja3MgfSBmcm9tICcuL2J1aWxkLWNvbW1hbmRzLmpzJ1xuaW1wb3J0IHsgZ2V0RGV2aWNlU2NoZW1hcyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgcGFyc2VTZXR0aW5nSWQsIGdldE5vcm1hbGl6ZWRTY2hlbWFzLCBmaW5kQWN0aW9uRm9yU2V0dGluZyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbi8qKlxuICogSGVscGVyIGZ1bmN0aW9uIHRvIGdldCBsYWJlbCBmcm9tIGNob2ljZXMgYmFzZWQgb24gdmFsdWVcbiAqL1xuZnVuY3Rpb24gZ2V0TGFiZWxGb3JWYWx1ZShcblx0c2NoZW1hczogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+LFxuXHRtb2RlbDogc3RyaW5nLFxuXHRjbWRJZDogbnVtYmVyLFxuXHRzZXR0aW5nSWQ6IG51bWJlcixcblx0dmFsdWU6IG51bWJlcixcbik6IHN0cmluZyB8IG51bWJlciB7XG5cdGNvbnN0IHNldHRpbmcgPSBmaW5kQWN0aW9uRm9yU2V0dGluZyhzY2hlbWFzLCBtb2RlbCwgY21kSWQsIHNldHRpbmdJZClcblx0aWYgKCFzZXR0aW5nIHx8ICFBcnJheS5pc0FycmF5KHNldHRpbmcub3B0aW9ucykpIHJldHVybiB2YWx1ZVxuXG5cdC8vIEZpbmQgdGhlICd2YWx1ZScgb3B0aW9uIHdoaWNoIGNvbnRhaW5zIHRoZSBjaG9pY2VzXG5cdGNvbnN0IHZhbHVlT3B0aW9uID0gc2V0dGluZy5vcHRpb25zLmZpbmQoKG9wdDogYW55KSA9PiBvcHQuaWQgPT09ICd2YWx1ZScpXG5cdGlmICghdmFsdWVPcHRpb24gfHwgIUFycmF5LmlzQXJyYXkodmFsdWVPcHRpb24uY2hvaWNlcykpIHJldHVybiB2YWx1ZVxuXG5cdC8vIEZpbmQgdGhlIGNob2ljZSB3aXRoIG1hdGNoaW5nIGlkXG5cdGNvbnN0IGNob2ljZSA9IHZhbHVlT3B0aW9uLmNob2ljZXMuZmluZCgoYzogYW55KSA9PiBjLmlkID09PSB2YWx1ZSlcblx0cmV0dXJuIGNob2ljZT8ubGFiZWwgPz8gdmFsdWVcbn1cblxuLyoqXG4gKiBCdWlsZCBhbmQgd2lyZSBDb21wYW5pb24gZmVlZGJhY2sgZGVmaW5pdGlvbnNcbiAqIFBhdHRlcm4gbWF0Y2hlcyBhY3Rpb25zLnRzIC0gZmlsdGVycyBieSBhY3RpdmUgbW9kZWwgYW5kIHdpcmVzIGNhbGxiYWNrc1xuICovXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlRmVlZGJhY2tzKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IHNjaGVtYXNSYXcgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgcmF3RmVlZGJhY2tzID0gYnVpbGRGZWVkYmFja3MoKVxuXHRjb25zdCBzY2hlbWFzID0gZ2V0Tm9ybWFsaXplZFNjaGVtYXMoc2NoZW1hc1Jhdylcblx0Y29uc3Qgd2lyZWRGZWVkYmFja3M6IGFueSA9IHt9XG5cblx0Ly8gR2V0IHRoZSBhY3RpdmUgbW9kZWwgZnJvbSB0aGUgY2FjaGVkIHZhbHVlIHNldCBieSBzeW5jTW9kZWwoKVxuXHRjb25zdCBhY3RpdmVNb2RlbCA9IHNlbGYuYWN0aXZlTW9kZWxcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEJVSUxEIFBFUi1TRVRUSU5HIEZFRURCQUNLUyAoRklMVEVSRUQgQlkgQUNUSVZFIE1PREVMKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHRmb3IgKGNvbnN0IFtmZWVkYmFja0lkLCBmZWVkYmFja10gb2YgT2JqZWN0LmVudHJpZXMocmF3RmVlZGJhY2tzKSkge1xuXHRcdGNvbnN0IHsgbW9kZWwsIGNtZElkLCBiYXNlSWQgfSA9IHBhcnNlU2V0dGluZ0lkKGZlZWRiYWNrSWQpXG5cblx0XHQvLyBPbmx5IGluY2x1ZGUgZmVlZGJhY2tzIGZvciB0aGUgY3VycmVudGx5IGFjdGl2ZSBtb2RlbFxuXHRcdGlmIChtb2RlbCAhPT0gYWN0aXZlTW9kZWwpIGNvbnRpbnVlXG5cblx0XHQvLyBWQUxVRSBGRUVEQkFDSzogUmV0dXJucyBjdXJyZW50IHZhbHVlIGZvciBsb2NhbCB2YXJpYWJsZVxuXHRcdHdpcmVkRmVlZGJhY2tzW2ZlZWRiYWNrSWRdID0ge1xuXHRcdFx0Li4uZmVlZGJhY2ssXG5cdFx0XHRjYWxsYmFjazogKGZlZWRiYWNrRXZlbnQ6IGFueSkgPT4ge1xuXHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXHRcdFx0XHRjb25zdCBpZEFkZCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snaWRBZGQnXSA/PyAwXG5cdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGJhc2VJZCArIGlkQWRkXG5cblx0XHRcdFx0Ly8gYnVzQ2ggZnJvbSBvcHRpb25zIHRha2VzIHByaW9yaXR5OyBmYWxsIGJhY2sgdG8gZml4ZWQgYnVzQ2ggaW4gc2NoZW1hXG5cdFx0XHRcdGxldCBidXNDaCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snYnVzQ2gnXVxuXHRcdFx0XHRpZiAoYnVzQ2ggPT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdGNvbnN0IHNjaGVtYUFjdGlvbiA9IGZpbmRBY3Rpb25Gb3JTZXR0aW5nKHNjaGVtYXMsIG1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkKVxuXHRcdFx0XHRcdGlmIChzY2hlbWFBY3Rpb24/LmJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRcdGJ1c0NoID0gc2NoZW1hQWN0aW9uLmJ1c0NoXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdC8vIExhc3QgcmVzb3J0OiBsb29rIHVwIGZpeGVkIGJ1c0NoIGRpcmVjdGx5IGZyb20gdGhlIHJhdyBkZXZpY2Ugc2NoZW1hLFxuXHRcdFx0XHQvLyBpbiBjYXNlIGdldE5vcm1hbGl6ZWRTY2hlbWFzKCkgc3RyaXBwZWQgdGhlIHByb3BlcnR5IChlLmcuIE1pYyBFbGVjdHJldCBQb3dlcikuXG5cdFx0XHRcdGlmIChidXNDaCA9PT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0Y29uc3QgcmF3QWN0aW9uID0gc2NoZW1hc1Jhd1ttb2RlbF0/LmNtZFNjaGVtYT8uZmluZCgoYTogYW55KSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gc2V0dGluZ0lkKVxuXHRcdFx0XHRcdGlmIChyYXdBY3Rpb24/LmJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRcdGJ1c0NoID0gcmF3QWN0aW9uLmJ1c0NoXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cblx0XHRcdFx0Y29uc3QgY3VycmVudCA9IHNlbGYuc3RDb250cm9sbGVyLmdldFNldHRpbmdWYWx1ZShpcCwgY21kSWQsIHNldHRpbmdJZCwgYnVzQ2gpXG5cblx0XHRcdFx0Ly8gQm9vbGVhbiBmZWVkYmFja3M6IGFueSBub24temVybyB2YWx1ZSA9IGFjdGl2ZSAodHJ1ZSksIHplcm8gPSBpbmFjdGl2ZSAoZmFsc2UpLlxuXHRcdFx0XHQvLyBUaGlzIHdvcmtzIGZvciBhbGwgT24vT2ZmIHNldHRpbmdzIHJlZ2FyZGxlc3Mgb2Ygd2hhdCB0aGUgXCJPblwiIElEIHZhbHVlIGlzXG5cdFx0XHRcdC8vIGluIHRoZSBzY2hlbWEgKGUuZy4gTWljIEVsZWN0cmV0IFBvd2VyIHVzZXMgNSBmb3IgT24sIG5vdCAxKS5cblx0XHRcdFx0aWYgKGZlZWRiYWNrSWQuZW5kc1dpdGgoJ19ib29sJykpIHtcblx0XHRcdFx0XHRyZXR1cm4gY3VycmVudCAhPT0gdW5kZWZpbmVkICYmIGN1cnJlbnQgIT09IDBcblx0XHRcdFx0fVxuXG5cdFx0XHRcdC8vIENoZWNrIGlmIHVzZXIgd2FudHMgbGFiZWwgaW5zdGVhZCBvZiBudW1lcmljIHZhbHVlXG5cdFx0XHRcdGNvbnN0IHNob3dMYWJlbCA9IGZlZWRiYWNrRXZlbnQub3B0aW9uc1snc2hvd0xhYmVsJ10gPz8gZmFsc2VcblxuXHRcdFx0XHRpZiAoc2hvd0xhYmVsICYmIGN1cnJlbnQgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdC8vIFJldHVybiB0aGUgbGFiZWwgZnJvbSBjaG9pY2VzXG5cdFx0XHRcdFx0cmV0dXJuIGdldExhYmVsRm9yVmFsdWUoc2NoZW1hcywgbW9kZWwsIGNtZElkLCBzZXR0aW5nSWQsIGN1cnJlbnQpXG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBSZXR1cm4gbnVtZXJpYyB2YWx1ZSBkaXJlY3RseSBmb3IgbG9jYWwgdmFyaWFibGUgKHR5cGU6ICd2YWx1ZScpXG5cdFx0XHRcdHJldHVybiBjdXJyZW50ID8/IDBcblx0XHRcdH0sXG5cdFx0fVxuXHR9XG5cblx0c2VsZi5zZXRGZWVkYmFja0RlZmluaXRpb25zKHdpcmVkRmVlZGJhY2tzKVxufVxuIiwgImltcG9ydCBkZ3JhbSBmcm9tICdkZ3JhbSdcbmltcG9ydCBvcyBmcm9tICdvcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQge1xuXHRDTURfQlVTX0dFVCxcblx0Q01EX0JVU19TRVQsXG5cdENNRF9ERVZfU1BFQyxcblx0Q01EX0dFVF9BTExfU0VUVElOR1MsXG5cdENNRF9HRVRfRklSTVdBUkUsXG5cdENNRF9HTE9CQUxfTUlDX0tJTEwsXG5cdENNRF9NSUNfUFJFLFxuXHRDTURfTUlDX1BSRV9CVVMsXG5cdENNRF9SRVNFVF9ERVZJQ0UsXG5cdENNRF9TRVRUSU5HU19QVVNILFxuXHRnZXRDb21tYW5kTmFtZSxcblx0bWFrZVNldHRpbmdJZCxcblx0dG9IZXgsXG5cdGJ5dGVzVG9IZXgsXG5cdHR5cGUgRGV2aWNlSW5mbyxcbn0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7XG5cdHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbCxcblx0cGFyc2VTZXR0aW5nc1Jlc3BvbnNlLFxuXHRmb3JtYXRQYXJzZWRTZXR0aW5nLFxuXHR0eXBlIFN0QWN0aW9uLFxuXHR0eXBlIFBhcnNlZFNldHRpbmcsXG59IGZyb20gJy4vc2V0dGluZ3NQYXJzZXIuanMnXG5pbXBvcnQge1xuXHREQU5URV9NU0dfSU5GT19SRVNQT05TRSxcblx0cGFyc2VEYW50ZUluZm9SZXNwb25zZSxcblx0ZGlzY292ZXJEZXZpY2VzLFxuXHRvcGVuQ29uTW9uU2Vzc2lvbixcblx0cHJvYmVEZXZpY2UgYXMgZGFudGVQcm9iZURldmljZSxcblx0Z2V0TWFjRm9yRGVzdGluYXRpb24sXG5cdGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uLFxufSBmcm9tICcuL2RhbnRlLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ1N0Q29udHJvbGxlcicpXG5cbmV4cG9ydCBjbGFzcyBTdENvbnRyb2xsZXIge1xuXHRwcml2YXRlIHJlYWRvbmx5IGRlZmF1bHRQb3J0OiBudW1iZXIgPSA4NzAwXG5cdHByaXZhdGUgcmVhZG9ubHkgbXVsdGljYXN0R3JvdXAgPSAnMjI0LjAuMC4yMzEnXG5cdHByaXZhdGUgcmVhZG9ubHkgcnhQb3J0ID0gODcwMlxuXG5cdHByaXZhdGUgdHhTb2NrZXQ6IGRncmFtLlNvY2tldFxuXHRwcml2YXRlIHJ4U29ja2V0OiBkZ3JhbS5Tb2NrZXQgLy8gZm9yIHJlY2VpdmluZyByZXNwb25zZXMgKDg3MDIpXG5cdHByaXZhdGUgcGVuZGluZ0Fja3M6IE1hcDxcblx0XHRzdHJpbmcsXG5cdFx0eyByZXNvbHZlOiAoYnVmOiBCdWZmZXIpID0+IHZvaWQ7IHJlamVjdDogKGU6IEVycm9yKSA9PiB2b2lkOyB0aW1lcjogTm9kZUpTLlRpbWVvdXQgfVxuXHQ+ID0gbmV3IE1hcCgpXG5cdHByaXZhdGUgam9pbmVkSW50ZXJmYWNlczogU2V0PHN0cmluZz4gPSBuZXcgU2V0KCkgLy8gbG9jYWwgSVBzIHdlJ3ZlIGpvaW5lZCBtdWx0aWNhc3Qgb25cblxuXHQvKiogU2VyaWFsaXplcyBvdXRnb2luZyBjb21tYW5kcyBzbyBlYWNoIHdhaXRzIGZvciBBQ0sgYmVmb3JlIHRoZSBuZXh0IGlzIHNlbnQgKi9cblx0cHJpdmF0ZSBzZW5kUXVldWU6IFByb21pc2U8dm9pZD4gPSBQcm9taXNlLnJlc29sdmUoKVxuXG5cdC8qKiBUcmFja3MgaG93IG1hbnkgY29tbWFuZHMgYXJlIHF1ZXVlZC9pbi1mbGlnaHQsIHRvIGRlZmVyIHJlcXVlc3RBbGxTZXR0aW5ncyAqL1xuXHRwcml2YXRlIHBlbmRpbmdDb21tYW5kQ291bnQgPSAwXG5cblx0LyoqIFJlc29sdmVzIG9uY2UgdHhTb2NrZXQgaXMgYm91bmQgYW5kIHJlYWR5IHRvIHNlbmQgKi9cblx0cHJpdmF0ZSB0eFJlYWR5OiBQcm9taXNlPHZvaWQ+XG5cblx0LyoqIEFjdGl2ZSBkZXZpY2UgbW9kZWwgYW5kIGFjdGlvbiBkZWZpbml0aW9ucyBmb3Igc2V0dGluZ3MgZGVjb2RpbmcgKi9cblx0cHJpdmF0ZSBtb2RlbDogc3RyaW5nID0gJydcblx0cHJpdmF0ZSBhY3Rpb25zOiBTdEFjdGlvbltdID0gW11cblxuXHQvKipcblx0ICogS25vd24gc3RhdGUgb2YgZXZlcnkgc2V0dGluZyBwZXIgZGV2aWNlIElQLlxuXHQgKiBLZXllZCBieSBJUCBcdTIxOTIgTWFwIG9mIFwiJHtjbWRJZH0vJHtzZXR0aW5nSWR9XCIgXHUyMTkyIGN1cnJlbnQgdmFsdWUgYnl0ZS5cblx0ICogUG9wdWxhdGVkIG9uIGNvbm5lY3QgdmlhIHJlcXVlc3RBbGxTZXR0aW5ncygpLCB1cGRhdGVkIG9uIGV2ZXJ5IENNRF9TRVRUSU5HU19QVVNIICgweDBiKS5cblx0ICogVXNlZCB0byBkaWZmIGluY29taW5nIHB1c2hlcyAoY2hhbmdlZCA9IGluZm8sIHVuY2hhbmdlZCA9IGRlYnVnKSBhbmQgZm9yIGZlZWRiYWNrcy5cblx0ICovXG5cdHByaXZhdGUgZGV2aWNlU3RhdGU6IE1hcDxzdHJpbmcsIE1hcDxzdHJpbmcsIG51bWJlcj4+ID0gbmV3IE1hcCgpXG5cblx0LyoqXG5cdCAqIElQcyB0aGF0IGhhdmUgYmVlbiB2ZXJpZmllZCBhZ2FpbnN0IHRoZSBjb25maWd1cmVkIG1vZGVsIGFuZCBhcmUgYWxsb3dlZFxuXHQgKiB0byByZWNlaXZlIFN0dWRpby1UIGNvbW1hbmRzLiBQb3B1bGF0ZWQgYnkgYXV0aG9yaXplRGV2aWNlKCkgYWZ0ZXIgYVxuXHQgKiBzdWNjZXNzZnVsIHByb2JlRGV2aWNlKCkgbW9kZWwgbWF0Y2gsIG9yIGFmdGVyIG11bHRpY2FzdCBkaXNjb3ZlcnkuXG5cdCAqIF9zZW5kQXdhaXRBY2soKSByZWplY3RzIGFueSBkZXN0SXAgbm90IGluIHRoaXMgc2V0LlxuXHQgKi9cblx0cHJpdmF0ZSBhdXRob3JpemVkSXBzOiBTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKVxuXG5cdC8qKiBDYWxsYmFja3MgcmVnaXN0ZXJlZCBmb3IgRGFudGUgMHgwMTcwIGRldmljZSBpbmZvIHJlc3BvbnNlcyBcdTIwMTQga2V5ZWQgYnkgdXNhZ2UgKi9cblx0cHJpdmF0ZSBkaXNjb3ZlcnlMaXN0ZW5lcnM6IE1hcDxzdHJpbmcsIChkZXZpY2U6IERldmljZUluZm8pID0+IHZvaWQ+ID0gbmV3IE1hcCgpXG5cblx0LyoqIENhbGxiYWNrIHRvIHRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlcyB3aGVuIHN0YXRlIGNoYW5nZXMgKi9cblx0cHJpdmF0ZSBmZWVkYmFja0NhbGxiYWNrPzogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZFxuXG5cdC8qKiBDYWNoZSBvZiBsb2NhbCBpbnRlcmZhY2UgTUFDIGJ5dGVzIHBlciBkZXN0aW5hdGlvbiBJUCwgdG8gYXZvaWQgcmVwZWF0ZWQgT1MgbG9va3VwcyAqL1xuXHRwcml2YXRlIG1hY0NhY2hlOiBNYXA8c3RyaW5nLCBudW1iZXJbXT4gPSBuZXcgTWFwKClcblxuXHQvKiogSVBzIGZvciB3aGljaCBhIERhbnRlIENvbk1vbiAocG9ydCA4ODAwKSBzZXNzaW9uIGhhcyBiZWVuIHN1Y2Nlc3NmdWxseSBvcGVuZWQgKi9cblx0cHJpdmF0ZSBzZXNzaW9uRXN0YWJsaXNoZWQ6IFNldDxzdHJpbmc+ID0gbmV3IFNldCgpXG5cblx0LyoqIENsZWFudXAgZnVuY3Rpb25zIHJldHVybmVkIGJ5IG9wZW5Db25Nb25TZXNzaW9uKCkgXHUyMDE0IGNhbGwgdG8gc3RvcCBrZWVwYWxpdmVzIGFuZCBjbG9zZSB0aGUgc29ja2V0ICovXG5cdHByaXZhdGUgX2Nvbm1vbkNsZWFudXBzOiBNYXA8c3RyaW5nLCAoKSA9PiB2b2lkPiA9IG5ldyBNYXAoKVxuXG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdGxvZ2dlci5pbmZvKCdTdENvbnRyb2xsZXIgaW5pdGlhbGl6ZWQnKVxuXG5cdFx0Ly8gU2VuZCBzb2NrZXQgXHUyMDE0IGJpbmQgdG8gZXBoZW1lcmFsIHBvcnQuIFJlc3BvbnNlcyBhbHdheXMgZ28gdG8gcnhTb2NrZXQgb25cblx0XHQvLyBwb3J0IDg3MDIgKERhbnRlIGhhcmRjb2RlcyB0aGUgcmVzcG9uc2UgZGVzdGluYXRpb24gcG9ydCB0byA4NzAyKS5cblx0XHR0aGlzLnR4U29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblx0XHR0aGlzLnR4UmVhZHkgPSBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuXHRcdFx0dGhpcy50eFNvY2tldC5iaW5kKDAsICgpID0+IHtcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBUWCBzb2NrZXQgYm91bmQgdG8gcG9ydCAkeyh0aGlzLnR4U29ja2V0LmFkZHJlc3MoKSBhcyB7IHBvcnQ6IG51bWJlciB9KS5wb3J0fWApXG5cdFx0XHRcdHJlc29sdmUoKVxuXHRcdFx0fSlcblx0XHR9KVxuXHRcdHRoaXMudHhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBUWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdC8vIFJlY2VpdmUgc29ja2V0IC0gYmluZCB0byBhbGwgYWRkcmVzc2VzIHNvIGtlcm5lbCBjYW4gZGVsaXZlciBtdWx0aWNhc3QgcGFja2V0c1xuXHRcdHRoaXMucnhTb2NrZXQgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXG5cdFx0dGhpcy5yeFNvY2tldC5vbignbGlzdGVuaW5nJywgKCkgPT4ge1xuXHRcdFx0Y29uc3QgYWRkciA9IHRoaXMucnhTb2NrZXQuYWRkcmVzcygpXG5cdFx0XHRsb2dnZXIuZGVidWcoYFJYIHNvY2tldCBsaXN0ZW5pbmcgb24gJHtKU09OLnN0cmluZ2lmeShhZGRyKX1gKVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5yeFNvY2tldC5zZXRNdWx0aWNhc3RMb29wYmFjayh0cnVlKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBSWCBzb2NrZXQgZXJyb3I6ICR7ZXJyfWApXG5cdFx0fSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ21lc3NhZ2UnLCAobXNnLCByaW5mbykgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5oYW5kbGVJbmNvbWluZyhtc2csIHJpbmZvLmFkZHJlc3MpXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRsb2dnZXIuZXJyb3IoYEVycm9yIGhhbmRsaW5nIGluY29taW5nIG1lc3NhZ2U6ICR7X2V9YClcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0Ly8gQmluZCB0byB3aWxkY2FyZCBzbyBrZXJuZWwgY2FuIGRlbGl2ZXIgbXVsdGljYXN0IHBhY2tldHMgZm9yIGpvaW5lZCBpbnRlcmZhY2VzLlxuXHRcdC8vIEFmdGVyIGJpbmRpbmcsIGVhZ2VybHkgam9pbiAyMjQuMC4wLjIzMSBvbiBldmVyeSBub24tbG9vcGJhY2sgSVB2NCBpbnRlcmZhY2Ugc29cblx0XHQvLyB0aGF0IHVuc29saWNpdGVkIENNRF9TRVRUSU5HU19QVVNIICgweDBiKSBwYWNrZXRzIGFyZSBub3QgbWlzc2VkIGJlZm9yZSB0aGVcblx0XHQvLyBmaXJzdCBvdXRnb2luZyBjb21tYW5kIHRyaWdnZXJzIHRoZSBsYXp5IGVuc3VyZU1lbWJlcnNoaXBGb3IoKSBqb2luLlxuXHRcdHRoaXMucnhTb2NrZXQuYmluZCh7IGFkZHJlc3M6ICcwLjAuMC4wJywgcG9ydDogdGhpcy5yeFBvcnQgfSwgKCkgPT4ge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCBzb2NrZXQgYm91bmQgdG8gMC4wLjAuMDoke3RoaXMucnhQb3J0fWApXG5cdFx0XHRjb25zdCBpZmFjZXMgPSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpIGFzIFJlY29yZDxzdHJpbmcsIGltcG9ydCgnb3MnKS5OZXR3b3JrSW50ZXJmYWNlSW5mb1tdPlxuXHRcdFx0Zm9yIChjb25zdCBhZGRycyBvZiBPYmplY3QudmFsdWVzKGlmYWNlcykpIHtcblx0XHRcdFx0Zm9yIChjb25zdCBhZGRyIG9mIGFkZHJzID8/IFtdKSB7XG5cdFx0XHRcdFx0aWYgKGFkZHIuZmFtaWx5ID09PSAnSVB2NCcgJiYgIWFkZHIuaW50ZXJuYWwgJiYgIXRoaXMuam9pbmVkSW50ZXJmYWNlcy5oYXMoYWRkci5hZGRyZXNzKSkge1xuXHRcdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdFx0dGhpcy5yeFNvY2tldC5hZGRNZW1iZXJzaGlwKHRoaXMubXVsdGljYXN0R3JvdXAsIGFkZHIuYWRkcmVzcylcblx0XHRcdFx0XHRcdFx0dGhpcy5qb2luZWRJbnRlcmZhY2VzLmFkZChhZGRyLmFkZHJlc3MpXG5cdFx0XHRcdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgUHJlLWpvaW5lZCBtdWx0aWNhc3QgJHt0aGlzLm11bHRpY2FzdEdyb3VwfSBvbiAke2FkZHIuYWRkcmVzc31gKVxuXHRcdFx0XHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oYENvdWxkIG5vdCBwcmUtam9pbiBtdWx0aWNhc3Qgb24gJHthZGRyLmFkZHJlc3N9OiAke1N0cmluZyhfZSl9YClcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KVxuXHR9XG5cblx0cHVibGljIGNsb3NlKCk6IHZvaWQge1xuXHRcdC8vIFN0b3AgYWxsIENvbk1vbiBrZWVwYWxpdmVzIGFuZCBjbG9zZSB0aGVpciBzb2NrZXRzIGJlZm9yZSBjbG9zaW5nIHRoZSBtYWluIHNvY2tldHNcblx0XHRmb3IgKGNvbnN0IGNsZWFudXAgb2YgdGhpcy5fY29ubW9uQ2xlYW51cHMudmFsdWVzKCkpIHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNsZWFudXAoKVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdH1cblx0XHR0aGlzLl9jb25tb25DbGVhbnVwcy5jbGVhcigpXG5cdFx0dHJ5IHtcblx0XHRcdGZvciAoY29uc3QgbG9jYWxBZGRyIG9mIEFycmF5LmZyb20odGhpcy5qb2luZWRJbnRlcmZhY2VzKSkge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdHRoaXMucnhTb2NrZXQuZHJvcE1lbWJlcnNoaXAodGhpcy5tdWx0aWNhc3RHcm91cCwgbG9jYWxBZGRyKVxuXHRcdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0gY2F0Y2gge1xuXHRcdFx0LyogaWdub3JlICovXG5cdFx0fVxuXHRcdHRyeSB7XG5cdFx0XHR0aGlzLnJ4U29ja2V0LmNsb3NlKClcblx0XHR9IGNhdGNoIHtcblx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdH1cblx0XHR0cnkge1xuXHRcdFx0dGhpcy50eFNvY2tldC5jbG9zZSgpXG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogUHJvdmlkZSB0aGUgYWN0aXZlIGRldmljZSBtb2RlbCBhbmQgYWN0aW9uIGRlZmluaXRpb25zIHNvIGluY29taW5nIG1lc3NhZ2VzXG5cdCAqIGNhbiBiZSBkZWNvZGVkIGludG8gaHVtYW4tcmVhZGFibGUgbmFtZXMuIENhbGwgZnJvbSBtYWluLnRzIGFmdGVyIGNvbmZpZyBsb2FkLlxuXHQgKi9cblx0cHVibGljIHNldE1vZGVsKG1vZGVsOiBzdHJpbmcsIGFjdGlvbnM6IFN0QWN0aW9uW10pOiB2b2lkIHtcblx0XHR0aGlzLm1vZGVsID0gbW9kZWxcblx0XHR0aGlzLmFjdGlvbnMgPSBhY3Rpb25zXG5cdH1cblxuXHQvKipcblx0ICogU2V0IGNhbGxiYWNrIHRvIHRyaWdnZXIgd2hlbiBkZXZpY2Ugc3RhdGUgY2hhbmdlcyAoZm9yIGZlZWRiYWNrcykuXG5cdCAqIENhbGwgZnJvbSBtYWluLnRzIHRvIHdpcmUgdXAgY2hlY2tGZWVkYmFja3MuXG5cdCAqL1xuXHRwdWJsaWMgc2V0RmVlZGJhY2tDYWxsYmFjayhjYWxsYmFjazogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZCk6IHZvaWQge1xuXHRcdHRoaXMuZmVlZGJhY2tDYWxsYmFjayA9IGNhbGxiYWNrXG5cdH1cblxuXHQvKiogUmV0dXJucyB0cnVlIGlmIHRoZSBkZXZpY2UgYXQgdGhlIGdpdmVuIElQIGhhcyBiZWVuIGF1dGhvcml6ZWQgdG8gcmVjZWl2ZSBjb21tYW5kcy4gKi9cblx0cHVibGljIGlzRGV2aWNlQXV0aG9yaXplZChpcDogc3RyaW5nKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuYXV0aG9yaXplZElwcy5oYXMoaXApXG5cdH1cblxuXHQvKiogTWFyayBhbiBJUCBhcyB2ZXJpZmllZCBhbmQgYWxsb3dlZCB0byByZWNlaXZlIFN0dWRpby1UIGNvbW1hbmRzLiAqL1xuXHRwdWJsaWMgYXV0aG9yaXplRGV2aWNlKGlwOiBzdHJpbmcpOiB2b2lkIHtcblx0XHR0aGlzLmF1dGhvcml6ZWRJcHMuYWRkKGlwKVxuXHRcdGxvZ2dlci5kZWJ1ZyhgQXV0aG9yaXplZCBkZXZpY2UgYXQgJHtpcH1gKVxuXHR9XG5cblx0LyoqIFJlbW92ZSBhdXRob3JpemF0aW9uIGZvciBhbiBJUCAoZS5nLiBvbiBjb25maWcgY2hhbmdlIG9yIG1vZGVsIG1pc21hdGNoKS4gKi9cblx0cHVibGljIHJldm9rZURldmljZShpcDogc3RyaW5nKTogdm9pZCB7XG5cdFx0dGhpcy5hdXRob3JpemVkSXBzLmRlbGV0ZShpcClcblx0XHR0aGlzLmRldmljZVN0YXRlLmRlbGV0ZShpcClcblx0XHR0aGlzLm1hY0NhY2hlLmRlbGV0ZShpcClcblx0XHR0aGlzLnNlc3Npb25Fc3RhYmxpc2hlZC5kZWxldGUoaXApXG5cdFx0dGhpcy5fY29ubW9uQ2xlYW51cHMuZ2V0KGlwKT8uKClcblx0XHR0aGlzLl9jb25tb25DbGVhbnVwcy5kZWxldGUoaXApXG5cdFx0bG9nZ2VyLmRlYnVnKGBSZXZva2VkIGRldmljZSBhdCAke2lwfWApXG5cdH1cblxuXHQvKipcblx0ICogT3BlbnMgYSBEYW50ZSBDb25Nb24gc2Vzc2lvbiBmb3IgdGhlIGRldmljZS4gQ2FjaGVzIHRoZSByZXN1bHQgc28gdGhlXG5cdCAqIGhhbmRzaGFrZSBvbmx5IHJ1bnMgb25jZSBwZXIgSVAuIERlbGVnYXRlcyB0byBkYW50ZS50cyBvcGVuQ29uTW9uU2Vzc2lvbigpLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIG9wZW5TZXNzaW9uKGRldmljZUlwOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcblx0XHRpZiAodGhpcy5zZXNzaW9uRXN0YWJsaXNoZWQuaGFzKGRldmljZUlwKSkgcmV0dXJuIHRydWVcblx0XHRjb25zdCBjbGVhbnVwID0gYXdhaXQgb3BlbkNvbk1vblNlc3Npb24oZGV2aWNlSXApXG5cdFx0Y29uc3Qgc3VjY2VzcyA9IGNsZWFudXAgIT09IG51bGxcblx0XHQvLyBNYXJrIGFzIGF0dGVtcHRlZCByZWdhcmRsZXNzIG9mIG91dGNvbWUgXHUyMDE0IHJldHJ5aW5nIGltbWVkaWF0ZWx5IHdvdWxkIGhpdCB0aGVcblx0XHQvLyBzYW1lIGJpbmQgZXJyb3IgKEVBRERSSU5VU0UpLiBEZXZpY2VzIHRoYXQgZG9uJ3QgbmVlZCBDb25Nb24gd29yayBmaW5lIHdpdGhvdXQgaXQuXG5cdFx0dGhpcy5zZXNzaW9uRXN0YWJsaXNoZWQuYWRkKGRldmljZUlwKVxuXHRcdGlmIChzdWNjZXNzKSB7XG5cdFx0XHR0aGlzLl9jb25tb25DbGVhbnVwcy5zZXQoZGV2aWNlSXAsIGNsZWFudXApXG5cdFx0fVxuXHRcdHJldHVybiBzdWNjZXNzXG5cdH1cblxuXHQvKipcblx0ICogU2VuZHMgYSB1bmljYXN0IERhbnRlIGluZm8gcmVxdWVzdCB0byBhIHNwZWNpZmljIElQIGFuZCB3YWl0cyBmb3IgdGhlXG5cdCAqIGRldmljZSBpbmZvIHJlc3BvbnNlLiBSZXR1cm5zIHRoZSBEZXZpY2VJbmZvIGlmIHRoZSBkZXZpY2UgcmVzcG9uZHMgd2l0aGluXG5cdCAqIHRpbWVvdXRNcywgb3IgbnVsbCBpZiBubyByZXNwb25zZS4gVXNlZCB0byB2ZXJpZnkgYSBtYW51YWxseSBjb25maWd1cmVkIElQLlxuXHQgKiBEb2VzIE5PVCByZXF1aXJlIGF1dGhvcml6YXRpb24gXHUyMDE0IHRoaXMgaXMgaG93IGF1dGhvcml6YXRpb24gaXMgZXN0YWJsaXNoZWQuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgcHJvYmVEZXZpY2UoaXA6IHN0cmluZywgdGltZW91dE1zID0gMzAwMCk6IFByb21pc2U8RGV2aWNlSW5mbyB8IG51bGw+IHtcblx0XHRhd2FpdCB0aGlzLnR4UmVhZHlcblx0XHRyZXR1cm4gZGFudGVQcm9iZURldmljZShcblx0XHRcdHRoaXMudHhTb2NrZXQsXG5cdFx0XHQoa2V5LCBjYikgPT4gdGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuc2V0KGtleSwgY2IpLFxuXHRcdFx0KGtleSkgPT4gdGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuZGVsZXRlKGtleSksXG5cdFx0XHRhc3luYyAoZGVzdElwKSA9PiB0aGlzLmVuc3VyZU1lbWJlcnNoaXBGb3IoZGVzdElwKSxcblx0XHRcdGlwLFxuXHRcdFx0dGltZW91dE1zLFxuXHRcdClcblx0fVxuXG5cdC8qKlxuXHQgKiBTZW5kIGEgQ01EX0dFVF9BTExfU0VUVElOR1MgKDB4MGEpIHJlcXVlc3QgdG8gdGhlIGRldmljZSBhbmQgc3RvcmUgdGhlIHJlc3BvbnNlXG5cdCAqIGluIGRldmljZVN0YXRlLiBSZXR1cm5zIHRoZSByYXcgcmVzcG9uc2UgYnVmZmVyIGZvciBwYXJzaW5nLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIHJlcXVlc3RBbGxTZXR0aW5ncyhkZXZpY2VJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRsb2dnZXIuaW5mbyhgUmVxdWVzdGluZyBhbGwgc2V0dGluZ3MgZnJvbSAke2RldmljZUlwfWApXG5cdFx0Y29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLnNlbmRBd2FpdEFjayhDTURfR0VUX0FMTF9TRVRUSU5HUywgdW5kZWZpbmVkLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgZGV2aWNlSXAsIGZhbHNlKVxuXHRcdC8vIGRldmljZVN0YXRlIGlzIHBvcHVsYXRlZCBieSBsb2dTdFBheWxvYWQgd2hlbiB0aGUgQ01EX0dFVF9BTExfU0VUVElOR1MgcmVzcG9uc2UgYXJyaXZlc1xuXHRcdHJldHVybiByZXNwb25zZVxuXHR9XG5cblx0LyoqXG5cdCAqIERpc2NvdmVycyBTdHVkaW8gVGVjaG5vbG9naWVzIERhbnRlIGRldmljZXMgb24gdGhlIGxvY2FsIG5ldHdvcmsuXG5cdCAqXG5cdCAqIExpc3RlbnMgZm9yIERhbnRlIGFubm91bmNlcyBvbiAyMjQuMC4wLjIzMzo4NzA4LCBzZW5kcyB1bmljYXN0IGluZm8gcmVxdWVzdHNcblx0ICogdG8gZWFjaCBkaXNjb3ZlcmVkIElQLCBhbmQgY29sbGVjdHMgMHgwMTcwIHJlc3BvbnNlcyB2aWEgdGhlIHJ4U29ja2V0LlxuXHQgKi9cblx0cHVibGljIGFzeW5jIGRpc2NvdmVyRGV2aWNlcyh0aW1lb3V0TXMgPSA1MDAwKTogUHJvbWlzZTxEZXZpY2VJbmZvW10+IHtcblx0XHRjb25zdCBESVNDT1ZFUllfS0VZID0gJ19fZGlzY292ZXJ5X18nXG5cdFx0Y29uc3QgZm91bmREZXZpY2VzOiBEZXZpY2VJbmZvW10gPSBbXVxuXG5cdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuc2V0KERJU0NPVkVSWV9LRVksIChkZXZpY2U6IERldmljZUluZm8pID0+IHtcblx0XHRcdGlmICghZm91bmREZXZpY2VzLnNvbWUoKGQpID0+IGQuaXAgPT09IGRldmljZS5pcCkpIHtcblx0XHRcdFx0Zm91bmREZXZpY2VzLnB1c2goZGV2aWNlKVxuXHRcdFx0fVxuXHRcdH0pXG5cblx0XHR0cnkge1xuXHRcdFx0YXdhaXQgdGhpcy50eFJlYWR5XG5cdFx0XHRhd2FpdCBkaXNjb3ZlckRldmljZXModGhpcy50eFNvY2tldCwgYXN5bmMgKGRlc3RJcCkgPT4gdGhpcy5lbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcCksIHRpbWVvdXRNcylcblx0XHRcdHJldHVybiBmb3VuZERldmljZXNcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0dGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuZGVsZXRlKERJU0NPVkVSWV9LRVkpXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIFJlcXVlc3RzIGRldmljZSBmaXJtd2FyZSB2ZXJzaW9uIHZpYSBTdHVkaW8tVCBwcm90b2NvbCAoQ01EX0dFVF9GSVJNV0FSRSkuXG5cdCAqIFJldHVybnMgdGhlIGZpcm13YXJlIHZlcnNpb24gc3RyaW5nIChlLmcuLCBcIjMuMDFcIiwgXCIyLjJcIiwgXCIxLjA1XCIpLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIHJlcXVlc3RGaXJtd2FyZVZlcnNpb24oZGV2aWNlSXA6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG5cdFx0bG9nZ2VyLmluZm8oYFJlcXVlc3RpbmcgZmlybXdhcmUgdmVyc2lvbiBmcm9tICR7ZGV2aWNlSXB9YClcblx0XHRjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuc2VuZEF3YWl0QWNrKENNRF9HRVRfRklSTVdBUkUsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIGRldmljZUlwLCBmYWxzZSlcblxuXHRcdC8vIFJlc3BvbnNlIHN0cnVjdHVyZTogW2hlYWRlcl0gMHg1YSAweDgwIFtmaXJtd2FyZV9kYXRhXSBDUkNcblx0XHQvLyBGaXJtd2FyZSBkYXRhIHN0YXJ0cyBhdCBieXRlIDI2ICgyNC1ieXRlIGhlYWRlciArIDB4NWEgKyAweDgwKVxuXHRcdGNvbnN0IGRhdGFTdGFydCA9IDI2XG5cblx0XHRpZiAocmVzcG9uc2UubGVuZ3RoIDwgZGF0YVN0YXJ0ICsgMykge1xuXHRcdFx0bG9nZ2VyLndhcm4oYEZpcm13YXJlIHJlc3BvbnNlIHRvbyBzaG9ydDogJHtyZXNwb25zZS5sZW5ndGh9IGJ5dGVzYClcblx0XHRcdHJldHVybiAnVW5rbm93bidcblx0XHR9XG5cblx0XHQvLyBGaXJtd2FyZSBmb3JtYXQ6IFt1bmtub3duX2J5dGUsIG1ham9yLCBtaW5vcl1cblx0XHRjb25zdCBtYWpvciA9IHJlc3BvbnNlW2RhdGFTdGFydCArIDFdXG5cdFx0Y29uc3QgbWlub3IgPSByZXNwb25zZVtkYXRhU3RhcnQgKyAyXVxuXG5cdFx0Y29uc3QgbWlub3JTdHIgPVxuXHRcdFx0bWlub3IgPCAxMFxuXHRcdFx0XHQ/IG1pbm9yLnRvU3RyaW5nKCkucGFkU3RhcnQoMiwgJzAnKSAvLyBlLmcuIDEgXHUyMTkyIFwiMDFcIiwgNSBcdTIxOTIgXCIwNVwiXG5cdFx0XHRcdDogbWlub3IudG9TdHJpbmcoKSAvLyBlLmcuIDEwIFx1MjE5MiBcIjEwXCJcblxuXHRcdGNvbnN0IGZpcm13YXJlID0gYCR7bWFqb3J9LiR7bWlub3JTdHJ9YFxuXG5cdFx0bG9nZ2VyLmRlYnVnKGBGaXJtd2FyZSB2ZXJzaW9uOiAke2Zpcm13YXJlfWApXG5cdFx0cmV0dXJuIGZpcm13YXJlXG5cdH1cblxuXHQvKipcblx0ICogSm9pbnMgdGhlIG11bHRpY2FzdCByZXNwb25zZSBncm91cCBvbiB0aGUgaW50ZXJmYWNlIHRoYXQgcm91dGVzIHRvIGRlc3RJcC5cblx0ICogT25seSBqb2lucyB0aGUgc3BlY2lmaWMgaW50ZXJmYWNlIHVzZWQgdG8gcmVhY2ggdGhlIGRldmljZSwgYW5kIG9ubHkgb25jZSBwZXIgaW50ZXJmYWNlLlxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyBlbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IGxvY2FsQWRkciA9IGF3YWl0IGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uKGRlc3RJcClcblx0XHRcdGlmICghbG9jYWxBZGRyKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3QgZGV0ZXJtaW5lIGxvY2FsIGFkZHJlc3MgZm9yIGRlc3RpbmF0aW9uICR7ZGVzdElwfWApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHRpZiAodGhpcy5qb2luZWRJbnRlcmZhY2VzLmhhcyhsb2NhbEFkZHIpKSB7XG5cdFx0XHRcdC8vIGFscmVhZHkgam9pbmVkXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHR0cnkge1xuXHRcdFx0XHR0aGlzLnJ4U29ja2V0LmFkZE1lbWJlcnNoaXAodGhpcy5tdWx0aWNhc3RHcm91cCwgbG9jYWxBZGRyKVxuXHRcdFx0XHR0aGlzLmpvaW5lZEludGVyZmFjZXMuYWRkKGxvY2FsQWRkcilcblx0XHRcdFx0bG9nZ2VyLmluZm8oYEpvaW5lZCBtdWx0aWNhc3QgJHt0aGlzLm11bHRpY2FzdEdyb3VwfSBvbiAke2xvY2FsQWRkcn1gKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYEZhaWxlZCB0byBqb2luIG11bHRpY2FzdCBvbiAke2xvY2FsQWRkcn06ICR7U3RyaW5nKF9lKX1gKVxuXHRcdFx0fVxuXHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRsb2dnZXIud2FybihgZW5zdXJlTWVtYmVyc2hpcEZvciBmYWlsZWQ6ICR7X2V9YClcblx0XHR9XG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgc2VuZEF3YWl0QWNrKFxuXHRcdGNtZElkOiBudW1iZXIsXG5cdFx0YnVzQ2g6IG51bWJlciB8IHVuZGVmaW5lZCxcblx0XHRzZXR0aW5nSWQ6IG51bWJlciB8IHVuZGVmaW5lZCxcblx0XHR2YWx1ZTogdW5rbm93bixcblx0XHRkZXN0SXA6IHN0cmluZyxcblx0XHRhZGRMZW4gPSB0cnVlLFxuXHQpOiBQcm9taXNlPEJ1ZmZlcj4ge1xuXHRcdHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudCsrXG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlPEJ1ZmZlcj4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdFx0dGhpcy5zZW5kUXVldWUgPSB0aGlzLnNlbmRRdWV1ZS50aGVuKGFzeW5jICgpID0+XG5cdFx0XHRcdHRoaXMuX3NlbmRBd2FpdEFjayhjbWRJZCwgYnVzQ2gsIHNldHRpbmdJZCwgdmFsdWUsIGRlc3RJcCwgYWRkTGVuKVxuXHRcdFx0XHRcdC50aGVuKChidWYpID0+IHtcblx0XHRcdFx0XHRcdHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudC0tXG5cdFx0XHRcdFx0XHQvLyBPbmx5IHRyaWdnZXIgcmVxdWVzdEFsbFNldHRpbmdzIGFmdGVyIGEgd3JpdGUgKFNFVCkgY29tbWFuZCwgbm90IGEgcmVhZC9wb2xsLlxuXHRcdFx0XHRcdFx0Ly8gQSB3cml0ZSBhbHdheXMgaGFzIGEgdmFsdWU7IHJlYWRzIChHRVQsIEJVU19HRVQpIG5ldmVyIGRvLlxuXHRcdFx0XHRcdFx0aWYgKHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudCA9PT0gMCAmJiB2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0XHRcdHRoaXMucmVxdWVzdEFsbFNldHRpbmdzKGRlc3RJcCkuY2F0Y2goKGVycikgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gcmVmcmVzaCBzZXR0aW5ncyBhZnRlciBjb21tYW5kOiAke2Vycn1gKVxuXHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0cmVzb2x2ZShidWYpXG5cdFx0XHRcdFx0fSlcblx0XHRcdFx0XHQuY2F0Y2goKGVycikgPT4ge1xuXHRcdFx0XHRcdFx0dGhpcy5wZW5kaW5nQ29tbWFuZENvdW50LS1cblx0XHRcdFx0XHRcdHJlamVjdChlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyciA6IG5ldyBFcnJvcihTdHJpbmcoZXJyKSkpXG5cdFx0XHRcdFx0fSksXG5cdFx0XHQpXG5cdFx0fSlcblx0fVxuXG5cdHByaXZhdGUgYXN5bmMgX3NlbmRBd2FpdEFjayhcblx0XHRjbWRJZDogbnVtYmVyLFxuXHRcdGJ1c0NoOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0c2V0dGluZ0lkOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0dmFsdWU6IHVua25vd24sXG5cdFx0ZGVzdElwOiBzdHJpbmcsXG5cdFx0YWRkTGVuID0gdHJ1ZSxcblx0KTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRjb25zdCB0aW1lb3V0TXMgPSAyMDAwXG5cblx0XHRjb25zdCBkYXRhQmxvY2s6IG51bWJlcltdID0gW11cblx0XHRpZiAoc2V0dGluZ0lkICE9PSB1bmRlZmluZWQpIGRhdGFCbG9jay5wdXNoKHNldHRpbmdJZCAmIDB4ZmYpXG5cdFx0aWYgKHZhbHVlICE9PSB1bmRlZmluZWQpIGRhdGFCbG9jay5wdXNoKC4uLlN0Q29udHJvbGxlci5idWlsZFZhbHVlQnl0ZXModmFsdWUpKVxuXG5cdFx0Y29uc3QgcGF5bG9hZEJvZHk6IG51bWJlcltdID0gWzB4NWEsIGNtZElkICYgMHhmZl1cblxuXHRcdGlmIChjbWRJZCA9PT0gQ01EX01JQ19QUkUgJiYgYnVzQ2ggIT09IHVuZGVmaW5lZCAmJiBzZXR0aW5nSWQgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHQvLyBQb3NpdGlvbmFsIGZvcm1hdDogWzB4NWFdIFsweDAyXSBbYnVzQ2hdIFt2YWwwXSBbdmFsMV0gW3ZhbDJdIC4uLlxuXHRcdFx0Ly8gUmVhZCBhbGwgcG9zaXRpb25zIGZyb20gZGV2aWNlU3RhdGUsIG92ZXJyaWRlIHRoZSB0YXJnZXQgcG9zaXRpb24gd2l0aCBuZXcgdmFsdWUuXG5cdFx0XHQvLyBBbHNvIHVwZGF0ZSBkZXZpY2VTdGF0ZSBvcHRpbWlzdGljYWxseSBzbyBjb25zZWN1dGl2ZSBDTURfTUlDX1BSRSBjb21tYW5kcyBjaGFpbiBjb3JyZWN0bHkuXG5cdFx0XHRpZiAoIXRoaXMuZGV2aWNlU3RhdGUuaGFzKGRlc3RJcCkpIHRoaXMuZGV2aWNlU3RhdGUuc2V0KGRlc3RJcCwgbmV3IE1hcCgpKVxuXHRcdFx0Y29uc3QgaXBTdGF0ZSA9IHRoaXMuZGV2aWNlU3RhdGUuZ2V0KGRlc3RJcCkhXG5cdFx0XHRjb25zdCBudW1Qb3NpdGlvbnMgPSAzIC8vIGdhaW4sIGVsZWN0cmV0L3BoYW50b20sIHVua25vd25cblx0XHRcdGNvbnN0IHBvc2l0aW9uczogbnVtYmVyW10gPSBbXVxuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBudW1Qb3NpdGlvbnM7IGkrKykge1xuXHRcdFx0XHRjb25zdCBzdGF0ZUtleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgQ01EX01JQ19QUkUsIGksIGJ1c0NoKVxuXHRcdFx0XHRjb25zdCB2YWwgPSBpID09PSBzZXR0aW5nSWQgPyBOdW1iZXIodmFsdWUpIDogKGlwU3RhdGUuZ2V0KHN0YXRlS2V5KSA/PyAwKVxuXHRcdFx0XHRwb3NpdGlvbnMucHVzaCh2YWwpXG5cdFx0XHRcdGlwU3RhdGUuc2V0KHN0YXRlS2V5LCB2YWwpIC8vIG9wdGltaXN0aWMgdXBkYXRlXG5cdFx0XHR9XG5cdFx0XHRwYXlsb2FkQm9keS5wdXNoKGJ1c0NoICYgMHhmZiwgLi4ucG9zaXRpb25zKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkgcGF5bG9hZEJvZHkucHVzaChidXNDaCAmIDB4ZmYpXG5cdFx0XHRpZiAoYWRkTGVuKSBwYXlsb2FkQm9keS5wdXNoKGRhdGFCbG9jay5sZW5ndGgpXG5cdFx0XHRpZiAoZGF0YUJsb2NrLmxlbmd0aCA+IDApIHBheWxvYWRCb2R5LnB1c2goLi4uZGF0YUJsb2NrKVxuXHRcdH1cblxuXHRcdGNvbnN0IGNyYyA9IFN0Q29udHJvbGxlci5jcmM4RHZiUzIocGF5bG9hZEJvZHkpXG5cdFx0Y29uc3QgcGF5bG9hZFdpdGhDcmMgPSBCdWZmZXIuZnJvbShbLi4ucGF5bG9hZEJvZHksIGNyY10pXG5cblx0XHQvLyBIdW1hbi1yZWFkYWJsZSBpbmZvIGxvZyBmb3IgdGhlIG91dGdvaW5nIGNvbW1hbmRcblx0XHRpZiAoc2V0dGluZ0lkICE9PSB1bmRlZmluZWQgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IFN0Q29udHJvbGxlci5idWlsZFZhbHVlQnl0ZXModmFsdWUpXG5cdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0ge1xuXHRcdFx0XHRjbWRfaWQ6IGNtZElkLFxuXHRcdFx0XHRpZDogc2V0dGluZ0lkLFxuXHRcdFx0XHRidXNDaCxcblx0XHRcdFx0dmFsdWVCeXRlcyxcblx0XHRcdH1cblx0XHRcdGxvZ2dlci5pbmZvKGBUWCAke2Rlc3RJcH0gfCAke2Zvcm1hdFBhcnNlZFNldHRpbmcoc2V0dGluZywgdGhpcy5hY3Rpb25zKX1gKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgVFggJHtkZXN0SXB9IHwgJHtnZXRDb21tYW5kTmFtZShjbWRJZCl9YClcblx0XHR9XG5cblx0XHQvLyBSZWplY3QgY29tbWFuZHMgdG8gdW52ZXJpZmllZCBkZXZpY2VzIFx1MjAxNCBsb2cgdGhlIHdvdWxkLWJlIHBhY2tldCBmaXJzdCBhdCBkZWJ1Z1xuXHRcdC8vIHNvIHRoZSBieXRlcyBhcmUgdmlzaWJsZSBldmVuIHdoZW4gdGhlIGRldmljZSBpcyBvZmZsaW5lLlxuXHRcdGlmICghdGhpcy5hdXRob3JpemVkSXBzLmhhcyhkZXN0SXApKSB7XG5cdFx0XHRsb2dnZXIuZGVidWcoYFBhY2tldCAobm90IHNlbnQgXHUyMDE0IGRldmljZSBub3QgYXV0aG9yaXplZCkgdG8gJHtkZXN0SXB9OiAke3BheWxvYWRXaXRoQ3JjLnRvU3RyaW5nKCdoZXgnKX1gKVxuXHRcdFx0dGhyb3cgbmV3IEVycm9yKGBEZXZpY2UgYXQgJHtkZXN0SXB9IGlzIG5vdCBhdXRob3JpemVkIFx1MjAxNCB2ZXJpZnkgdGhlIElQIGFuZCBtb2RlbCBtYXRjaCBiZWZvcmUgc2VuZGluZyBjb21tYW5kc2ApXG5cdFx0fVxuXG5cdFx0Ly8gRW5zdXJlIHRoZSBEYW50ZSBDb25Nb24gc2Vzc2lvbiAocG9ydCA4ODAwKSBpcyBvcGVuIGJlZm9yZSBzZW5kaW5nIGFueSBTdHVkaW8tVFxuXHRcdC8vIGNvbW1hbmQuIG9wZW5TZXNzaW9uKCkgY2FjaGVzIHRoZSByZXN1bHQgXHUyMDE0IGhhbmRzaGFrZSBvbmx5IHJ1bnMgb25jZSBwZXIgSVAuXG5cdFx0aWYgKCF0aGlzLnNlc3Npb25Fc3RhYmxpc2hlZC5oYXMoZGVzdElwKSkge1xuXHRcdFx0YXdhaXQgdGhpcy5vcGVuU2Vzc2lvbihkZXN0SXApXG5cdFx0XHQvLyBTZXNzaW9uIGZhaWx1cmUgaXMgbm9uLWZhdGFsIFx1MjAxNCBtYW55IGRldmljZXMgcmVzcG9uZCB0byBTdHVkaW8tVCByZWdhcmRsZXNzLlxuXHRcdH1cblxuXHRcdC8vIEVuc3VyZSB3ZSBhcmUgbGlzdGVuaW5nIGZvciByZXBsaWVzIG9uIHRoZSBpbnRlcmZhY2UgdGhhdCB3aWxsIHJlY2VpdmUgdGhlbVxuXHRcdGF3YWl0IHRoaXMuZW5zdXJlTWVtYmVyc2hpcEZvcihkZXN0SXApXG5cblx0XHRjb25zdCB0b3RhbExlbiA9IDI0ICsgcGF5bG9hZFdpdGhDcmMubGVuZ3RoXG5cdFx0Y29uc3QgaGVhZGVyID0gYXdhaXQgdGhpcy5idWlsZEhlYWRlcih0b3RhbExlbiwgZGVzdElwKVxuXHRcdGNvbnN0IHBhY2tldCA9IEJ1ZmZlci5jb25jYXQoW2hlYWRlciwgcGF5bG9hZFdpdGhDcmNdKVxuXG5cdFx0bG9nZ2VyLmRlYnVnKGBTZW5kaW5nIHBhY2tldCB0byAke2Rlc3RJcH06ICR7cGFja2V0LnRvU3RyaW5nKCdoZXgnKX1gKVxuXG5cdFx0Y29uc3Qga2V5ID0gYCR7ZGVzdElwfToke2NtZElkfWBcblxuXHRcdHJldHVybiBuZXcgUHJvbWlzZTxCdWZmZXI+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHRcdHRoaXMucGVuZGluZ0Fja3MuZGVsZXRlKGtleSlcblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihgVGltZW91dCB3YWl0aW5nIGZvciBBQ0sgZnJvbSBNb2RlbCAke3RoaXMubW9kZWx9IGF0ICR7ZGVzdElwfTo4NzAwYCkpXG5cdFx0XHR9LCB0aW1lb3V0TXMpXG5cblx0XHRcdHRoaXMucGVuZGluZ0Fja3Muc2V0KGtleSwge1xuXHRcdFx0XHRyZXNvbHZlOiAoYnVmKSA9PiB7XG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdHJlc29sdmUoYnVmKVxuXHRcdFx0XHR9LFxuXHRcdFx0XHRyZWplY3Q6IChlcnIpID0+IHtcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0cmVqZWN0KGVycilcblx0XHRcdFx0fSxcblx0XHRcdFx0dGltZXIsXG5cdFx0XHR9KVxuXG5cdFx0XHR0aGlzLnR4U29ja2V0LnNlbmQocGFja2V0LCB0aGlzLmRlZmF1bHRQb3J0LCBkZXN0SXAsIChlcnIpID0+IHtcblx0XHRcdFx0aWYgKGVycikge1xuXHRcdFx0XHRcdHRoaXMucGVuZGluZ0Fja3MuZGVsZXRlKGtleSlcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0XHRcdH1cblx0XHRcdH0pXG5cdFx0fSlcblx0fVxuXG5cdHByaXZhdGUgaGFuZGxlSW5jb21pbmcobXNnOiBCdWZmZXIsIHNyY0lwOiBzdHJpbmcpIHtcblx0XHRpZiAobXNnLmxlbmd0aCA8IDQpIHJldHVyblxuXHRcdGlmIChtc2dbMF0gIT09IDB4ZmYgfHwgbXNnWzFdICE9PSAweGZmKSByZXR1cm5cblxuXHRcdGNvbnN0IG1zZ1R5cGUgPSBtc2cucmVhZFVJbnQxNkJFKDIpXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgRGFudGUgZGV2aWNlIGluZm8gcmVzcG9uc2UgKDB4MDE3MCkgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gVGhlc2UgaGF2ZSBcIkF1ZGluYXRlXCIgYXQgb2Zmc2V0IDE2LCBub3QgXCJTdHVkaW8tVFwiIFx1MjAxNCBoYW5kbGUgYmVmb3JlXG5cdFx0Ly8gdGhlIFN0dWRpby1UIHNpZ25hdHVyZSBjaGVjayBiZWxvdy5cblx0XHRpZiAobXNnVHlwZSA9PT0gREFOVEVfTVNHX0lORk9fUkVTUE9OU0UgJiYgdGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMuc2l6ZSA+IDApIHtcblx0XHRcdGNvbnN0IGRldmljZSA9IHBhcnNlRGFudGVJbmZvUmVzcG9uc2UobXNnLCBzcmNJcClcblx0XHRcdGlmIChkZXZpY2UpIHtcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKFxuXHRcdFx0XHRcdGBEYW50ZSBpbmZvIHJlc3BvbnNlIGZyb20gJHtzcmNJcH06IGAgK1xuXHRcdFx0XHRcdFx0YERldmljZUlEPVwiJHtkZXZpY2UubmFtZX1cIiwgYCArXG5cdFx0XHRcdFx0XHRgTW9kZWw9XCIke2RldmljZS5tb2RlbH1cIiwgYCArXG5cdFx0XHRcdFx0XHRgTW9kZWxOYW1lPVwiJHtkZXZpY2UubW9kZWxOYW1lfVwiLCBgICtcblx0XHRcdFx0XHRcdGBNYW51ZmFjdHVyZXI9XCIke2RldmljZS5tYW51ZmFjdHVyZXJ9XCJgLFxuXHRcdFx0XHQpXG5cblx0XHRcdFx0Ly8gT25seSBhY2NlcHQgU3R1ZGlvIFRlY2hub2xvZ2llcyBkZXZpY2VzIChpZGVudGlmaWVkIGJ5IERldmljZUlEIFwiU3R1ZGlvLVRcIilcblx0XHRcdFx0aWYgKGRldmljZS5uYW1lID09PSAnU3R1ZGlvLVQnKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBjYiBvZiB0aGlzLmRpc2NvdmVyeUxpc3RlbmVycy52YWx1ZXMoKSkge1xuXHRcdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdFx0Y2IoZGV2aWNlKVxuXHRcdFx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRsb2dnZXIuZGVidWcoYElnbm9yaW5nIG5vbi1TdHVkaW8gVGVjaG5vbG9naWVzIGRldmljZTogRGV2aWNlSUQ9XCIke2RldmljZS5uYW1lfVwiIEAgJHtzcmNJcH1gKVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRpZiAobXNnLmxlbmd0aCA8IDI1KSByZXR1cm5cblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBTdHVkaW8tVCBjb250cm9sIHByb3RvY29sIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdGNvbnN0IHNpZyA9IG1zZy5zdWJhcnJheSgxNiwgMjQpXG5cdFx0aWYgKHNpZy50b1N0cmluZygnYXNjaWknKSAhPT0gJ1N0dWRpby1UJykgcmV0dXJuXG5cblx0XHQvLyBJZ25vcmUgU3R1ZGlvLVQgcGFja2V0cyBmcm9tIGRldmljZXMgd2UgaGF2ZW4ndCBhdXRob3JpemVkLlxuXHRcdC8vIFRoaXMgcHJldmVudHMgY3Jvc3MtY29udGFtaW5hdGlvbiB3aGVuIG11bHRpcGxlIGRldmljZXMgKG9yIG11bHRpcGxlXG5cdFx0Ly8gQ29tcGFuaW9uIGluc3RhbmNlcykgYXJlIG9uIHRoZSBzYW1lIG5ldHdvcmsgXHUyMDE0IGFsbCBzaGFyZSB0aGUgbXVsdGljYXN0XG5cdFx0Ly8gZ3JvdXAgMjI0LjAuMC4yMzE6ODcwMiBhbmQgd2lsbCByZWNlaXZlIGVhY2ggb3RoZXIncyBBQ0tzIGFuZCBwdXNoZXMuXG5cdFx0aWYgKCF0aGlzLmF1dGhvcml6ZWRJcHMuaGFzKHNyY0lwKSkge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBJZ25vcmluZyBTdHVkaW8tVCBwYWNrZXQgZnJvbSB1bmF1dGhvcml6ZWQgZGV2aWNlICR7c3JjSXB9YClcblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdC8vIFBheWxvYWQgc3RhcnRzIGF0IG9mZnNldCAyNFxuXHRcdC8vIExheW91dDogWzB4NWFdIFtjbWRJZHwweDgwXSBbZGF0YS4uLl0gW2NyY11cblx0XHRjb25zdCBzdFBheWxvYWQgPSBtc2cuc3ViYXJyYXkoMjQpXG5cdFx0aWYgKHN0UGF5bG9hZC5sZW5ndGggPCAyKSByZXR1cm5cblx0XHRpZiAoc3RQYXlsb2FkWzBdICE9PSAweDVhKSByZXR1cm5cblxuXHRcdC8vIERldmljZSByZXBsaWVzIHdpdGggY21kIHwgMHg4MFxuXHRcdGNvbnN0IHJlc3BDbWRJZCA9IHN0UGF5bG9hZFsxXVxuXHRcdGNvbnN0IGlzUmVzcG9uc2UgPSAocmVzcENtZElkICYgMHg4MCkgIT09IDBcblx0XHRjb25zdCBvcmlnaW5hbENtZElkID0gcmVzcENtZElkICYgMHg3ZiAvLyBzdHJpcCB0aGUgcmVzcG9uc2UgZmxhZ1xuXG5cdFx0Ly8gTG9nIHJhdyBwYWNrZXQgZm9yIENNRF9HRVRfQUxMX1NFVFRJTkdTICgweDBhKSByZXNwb25zZXMgYmVmb3JlIHBhcnNpbmdcblx0XHRpZiAoaXNSZXNwb25zZSAmJiBvcmlnaW5hbENtZElkID09PSBDTURfR0VUX0FMTF9TRVRUSU5HUykge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBSZWNlaXZlZCBwYWNrZXQgZnJvbSAke3NyY0lwfTogJHttc2cudG9TdHJpbmcoJ2hleCcpfWApXG5cdFx0fVxuXG5cdFx0Ly8gTG9nIHRoZSBwYXlsb2FkICh3b3JrcyBmb3IgYm90aCByZXF1ZXN0cyBhbmQgcmVzcG9uc2VzKVxuXHRcdHRoaXMubG9nU3RQYXlsb2FkKHNyY0lwLCBvcmlnaW5hbENtZElkLCBtc2csIHN0UGF5bG9hZClcblxuXHRcdC8vIE9ubHkgcHJvY2VzcyBhcyBBQ0sgaWYgdGhpcyBpcyBhIHJlc3BvbnNlIHRvIG91ciByZXF1ZXN0XG5cdFx0aWYgKGlzUmVzcG9uc2UpIHtcblx0XHRcdGNvbnN0IGtleSA9IGAke3NyY0lwfToke29yaWdpbmFsQ21kSWR9YFxuXHRcdFx0Y29uc3QgcGVuZGluZyA9IHRoaXMucGVuZGluZ0Fja3MuZ2V0KGtleSlcblx0XHRcdGlmIChwZW5kaW5nKSB7XG5cdFx0XHRcdHRoaXMucGVuZGluZ0Fja3MuZGVsZXRlKGtleSlcblx0XHRcdFx0cGVuZGluZy5yZXNvbHZlKG1zZylcblx0XHRcdH1cblx0XHR9XG5cdFx0Ly8gVW5zb2xpY2l0ZWQgbWVzc2FnZXMgYW5kIHJlcXVlc3RzIGZyb20gb3RoZXIgc291cmNlcyBhcmUgbG9nZ2VkIGFib3ZlXG5cdH1cblxuXHQvKipcblx0ICogRGVjb2RlcyBhbmQgbG9ncyBhIFN0dWRpby1UIHJlc3BvbnNlIHBheWxvYWQuXG5cdCAqIFJlY2VpdmVzIGJvdGggdGhlIGZ1bGwgbXNnIChmb3IgcGFyc2VycyB0aGF0IG5lZWQgdGhlIFN0dWRpby1UIGhlYWRlcilcblx0ICogYW5kIHN0UGF5bG9hZCAobXNnLnN1YmFycmF5KDI0KSwgZm9yIGRpcmVjdCBieXRlIGFjY2VzcykuXG5cdCAqXG5cdCAqIHN0UGF5bG9hZCBsYXlvdXQ6XG5cdCAqICAgWzBdICAgICAgMHg1YSAgbWFnaWNcblx0ICogICBbMV0gICAgICBjbWRJZCB8IDB4ODBcblx0ICogICBbMi4uLTJdICBkYXRhIGJ5dGVzXG5cdCAqICAgWy0xXSAgICAgQ1JDLTgvRFZCLVMyXG5cdCAqL1xuXHRwcml2YXRlIGxvZ1N0UGF5bG9hZChzcmNJcDogc3RyaW5nLCBjbWRJZDogbnVtYmVyLCBtc2c6IEJ1ZmZlciwgc3RQYXlsb2FkOiBCdWZmZXIpOiB2b2lkIHtcblx0XHRjb25zdCBjbWROYW1lID0gZ2V0Q29tbWFuZE5hbWUoY21kSWQpXG5cdFx0Y29uc3QgZGF0YSA9IHN0UGF5bG9hZC5zdWJhcnJheSgyLCBzdFBheWxvYWQubGVuZ3RoIC0gMSkgLy8gc3RyaXAgbWFnaWMrY21kSWQgaGVhZGVyIGFuZCBDUkNcblxuXHRcdC8vIFBheWxvYWQgc3RydWN0dXJlOiBbY21kOjB4OGRdIFtkYXRhIGJ5dGVzLi4uXSBbY3JjXVxuXHRcdGNvbnN0IHJlc3BDbWRJZCA9IHN0UGF5bG9hZFsxXVxuXHRcdGNvbnN0IGNyYyA9IHN0UGF5bG9hZFtzdFBheWxvYWQubGVuZ3RoIC0gMV1cblx0XHRjb25zdCBmdWxsU3RydWN0dXJlID0gYFtjbWQ6JHt0b0hleChyZXNwQ21kSWQpfSBkYXRhOiR7ZGF0YS50b1N0cmluZygnaGV4Jyl9IGNyYzoke3RvSGV4KGNyYyl9XWBcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfR0VUX0FMTF9TRVRUSU5HUyAoMHgwYSkgYW5kIENNRF9TRVRUSU5HU19QVVNIICgweDBiKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBQYXJzZSBhbGwgc2V0dGluZ3MsIGRpZmYgYWdhaW5zdCBkZXZpY2VTdGF0ZSwgbG9nIGNoYW5nZWQgYXQgaW5mbyAvIHVuY2hhbmdlZCBhdCBkZWJ1Zyxcblx0XHQvLyB0aGVuIHVwZGF0ZSBkZXZpY2VTdGF0ZS4gQ01EX0dFVF9BTExfU0VUVElOR1MgYWxzbyBzZXJ2ZXMgYXMgdGhlIGluaXRpYWwgc3RhdGUgcG9wdWxhdGlvbiBvbiBjb25uZWN0LlxuXHRcdGlmIChjbWRJZCA9PT0gQ01EX0dFVF9BTExfU0VUVElOR1MgfHwgY21kSWQgPT09IENNRF9TRVRUSU5HU19QVVNIKSB7XG5cdFx0XHRpZiAoIXRoaXMubW9kZWwpIHtcblx0XHRcdFx0bG9nZ2VyLmluZm8oYFJYICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8ICR7ZnVsbFN0cnVjdHVyZX1gKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IHNldHRpbmdzID1cblx0XHRcdFx0XHRjbWRJZCA9PT0gQ01EX1NFVFRJTkdTX1BVU0hcblx0XHRcdFx0XHRcdD8gcGFyc2VTZXR0aW5nc1Jlc3BvbnNlKHRoaXMubW9kZWwsIG1zZylcblx0XHRcdFx0XHRcdDogcGFyc2VHZXRBbGxTZXR0aW5nc0Zvck1vZGVsKHRoaXMubW9kZWwsIG1zZylcblxuXHRcdFx0XHRjb25zdCBwcmV2U3RhdGUgPSB0aGlzLmRldmljZVN0YXRlLmdldChzcmNJcCkgPz8gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4oKVxuXHRcdFx0XHRjb25zdCBuZXdTdGF0ZSA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KHByZXZTdGF0ZSkgLy8gY29weSBcdTIwMTQgdXBkYXRlIGluIHBsYWNlXG5cblx0XHRcdFx0Zm9yIChjb25zdCBzIG9mIHNldHRpbmdzKSB7XG5cdFx0XHRcdFx0Y29uc3Qgc3RhdGVLZXkgPSBtYWtlU2V0dGluZ0lkKHRoaXMubW9kZWwsIHMuY21kX2lkLCBzLmlkLCBzLmJ1c0NoKVxuXHRcdFx0XHRcdC8vIEZvciBSR0IgY29sb3JzICgzIGJ5dGVzKSwgcGFjayBpbnRvIHNpbmdsZSBudW1iZXI6IChSIDw8IDE2KSB8IChHIDw8IDgpIHwgQlxuXHRcdFx0XHRcdGNvbnN0IG5ld1ZhbHVlID1cblx0XHRcdFx0XHRcdHMudmFsdWVCeXRlcy5sZW5ndGggPT09IDNcblx0XHRcdFx0XHRcdFx0PyAocy52YWx1ZUJ5dGVzWzBdIDw8IDE2KSB8IChzLnZhbHVlQnl0ZXNbMV0gPDwgOCkgfCBzLnZhbHVlQnl0ZXNbMl1cblx0XHRcdFx0XHRcdFx0OiAocy52YWx1ZUJ5dGVzWzBdID8/IDApXG5cdFx0XHRcdFx0Y29uc3QgcHJldlZhbHVlID0gcHJldlN0YXRlLmdldChzdGF0ZUtleSlcblx0XHRcdFx0XHRjb25zdCBjaGFuZ2VkID0gcHJldlZhbHVlID09PSB1bmRlZmluZWQgfHwgcHJldlZhbHVlICE9PSBuZXdWYWx1ZVxuXG5cdFx0XHRcdFx0bmV3U3RhdGUuc2V0KHN0YXRlS2V5LCBuZXdWYWx1ZSlcblxuXHRcdFx0XHRcdGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdFBhcnNlZFNldHRpbmcocywgdGhpcy5hY3Rpb25zKVxuXHRcdFx0XHRcdGlmIChjaGFuZ2VkKSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgUlggJHtzcmNJcH0gfCAke2Zvcm1hdHRlZH1gKVxuXHRcdFx0XHRcdFx0Ly8gVHJpZ2dlciBmZWVkYmFjayB1cGRhdGUgXHUyMDE0IHVzZSBiYXNlIGtleSB3aXRob3V0IGJ1c0NoIHNvIGl0IG1hdGNoZXMgdGhlIGZlZWRiYWNrIGRlZmluaXRpb24gSURcblx0XHRcdFx0XHRcdGlmICh0aGlzLmZlZWRiYWNrQ2FsbGJhY2spIHtcblx0XHRcdFx0XHRcdFx0bGV0IGJhc2VJZCA9IHMuaWRcblx0XHRcdFx0XHRcdFx0Y29uc3QgYmFzZUFjdGlvbiA9IHRoaXMuYWN0aW9ucy5maW5kKChhKSA9PiB7XG5cdFx0XHRcdFx0XHRcdFx0aWYgKGEuY21kX2lkICE9PSBzLmNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0XHRcdFx0aWYgKGEuaWQgPT09IHMuaWQpIHJldHVybiB0cnVlXG5cdFx0XHRcdFx0XHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhLm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdFx0XHRcdFx0aWYgKCFpZEFkZE9wdGlvbj8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0XHRcdFx0Y29uc3Qgb2Zmc2V0ID0gcy5pZCAtIGEuaWRcblx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gb2Zmc2V0ID4gMCAmJiBpZEFkZE9wdGlvbi5jaG9pY2VzLnNvbWUoKGMpID0+IGMuaWQgPT09IG9mZnNldClcblx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdFx0aWYgKGJhc2VBY3Rpb24pIGJhc2VJZCA9IGJhc2VBY3Rpb24uaWRcblx0XHRcdFx0XHRcdFx0Y29uc3QgYmFzZUZlZWRiYWNrS2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBzLmNtZF9pZCwgYmFzZUlkKVxuXHRcdFx0XHRcdFx0XHR0aGlzLmZlZWRiYWNrQ2FsbGJhY2soYmFzZUZlZWRiYWNrS2V5KVxuXHRcdFx0XHRcdFx0XHR0aGlzLmZlZWRiYWNrQ2FsbGJhY2soYmFzZUZlZWRiYWNrS2V5ICsgJ19ib29sJylcblx0XHRcdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKGBmZWVkYmFja0NhbGxiYWNrIG5vdCBzZXQgXHUyMDE0IHNraXBwaW5nIGZlZWRiYWNrIHVwZGF0ZSBmb3IgJHtzdGF0ZUtleX1gKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIuZGVidWcoYFJYICR7c3JjSXB9IHwgJHtmb3JtYXR0ZWR9YClcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0dGhpcy5kZXZpY2VTdGF0ZS5zZXQoc3JjSXAsIG5ld1N0YXRlKVxuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRsb2dnZXIud2FybihgUlggJHtzcmNJcH0gfCAke2NtZE5hbWV9IHwgcGFyc2UgZmFpbGVkOiAke2V9IHwgJHtmdWxsU3RydWN0dXJlfWApXG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQWxsIG90aGVyIGNvbW1hbmRzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdGNvbnN0IGRlY29kZWQgPSB0aGlzLmRlY29kZVN0RGF0YShjbWRJZCwgZGF0YSlcblx0XHQvLyBDTURfQlVTX0dFVCAoa2VlcGFsaXZlKSBpcyBoaWdoLWZyZXF1ZW5jeSBub2lzZSBcdTIwMTQgbG9nIGF0IGRlYnVnIG9ubHlcblx0XHRjb25zdCBsb2dGbiA9IGNtZElkID09PSBDTURfQlVTX0dFVCA/IGxvZ2dlci5kZWJ1Zy5iaW5kKGxvZ2dlcikgOiBsb2dnZXIuaW5mby5iaW5kKGxvZ2dlcilcblx0XHRpZiAoZGVjb2RlZCkge1xuXHRcdFx0bG9nRm4oYFJYICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8ICR7ZnVsbFN0cnVjdHVyZX0gfCAke2RlY29kZWR9YClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nRm4oYFJYICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8ICR7ZnVsbFN0cnVjdHVyZX1gKVxuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBBdHRlbXB0cyB0byBkZWNvZGUgdGhlIGRhdGEgYnl0ZXMgb2YgYSBTdHVkaW8tVCByZXNwb25zZSBpbnRvIGFcblx0ICogaHVtYW4tcmVhZGFibGUgc3RyaW5nLiBSZXR1cm5zIG51bGwgdG8gZmFsbCBiYWNrIHRvIHJhdyBoZXguXG5cdCAqL1xuXHRwcml2YXRlIGRlY29kZVN0RGF0YShjbWRJZDogbnVtYmVyLCBkYXRhOiBCdWZmZXIpOiBzdHJpbmcgfCBudWxsIHtcblx0XHRpZiAoZGF0YS5sZW5ndGggPT09IDApIHJldHVybiAnQUNLJ1xuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIENoZWNrIGZvciBzaW5nbGUtYnl0ZSByZXNwb25zZXMgKEFDSyBvciBlcnJvcikgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0aWYgKGRhdGEubGVuZ3RoID09PSAxKSB7XG5cdFx0XHRpZiAoZGF0YVswXSA9PT0gMHgwMCkge1xuXHRcdFx0XHRyZXR1cm4gJ0FDSyBvaydcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdHJldHVybiBgRVJST1IgJHt0b0hleChkYXRhWzBdKX1gXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0c3dpdGNoIChjbWRJZCkge1xuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9NSUNfUFJFICgweDAyKTogcmF3IHByZWFtcCBlY2hvIFx1MjAxNCBwb3NpdGlvbmFsIGJ5dGVzLCBubyBzZXR0aW5nIElEcyBcdTI1MDBcdTI1MDBcblx0XHRcdC8vIERldmljZSBlY2hvZXMgW2J1c0NoXVt2YWwwXVt2YWwxXS4uLiBjb25maXJtaW5nIHRoZSBhcHBsaWVkIHZhbHVlcy5cblx0XHRcdGNhc2UgQ01EX01JQ19QUkU6IHtcblx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBkYXRhWzBdXG5cdFx0XHRcdGNvbnN0IHZhbHMgPSBBcnJheS5mcm9tKGRhdGEuc3ViYXJyYXkoMSkpXG5cdFx0XHRcdFx0Lm1hcCgoYiwgaSkgPT4gYFske2l9XT0weCR7Yi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX0oJHtifSlgKVxuXHRcdFx0XHRcdC5qb2luKCcgJylcblx0XHRcdFx0cmV0dXJuIGBjaD0ke2J1c0NofSAke3ZhbHN9YFxuXHRcdFx0fVxuXG5cdFx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX0RFVl9TUEVDICgweDBkKTogc2luZ2xlLWJ5dGUgQUNLIG9yIGVjaG8gb2YgYXBwbGllZCBzZXR0aW5nIFx1MjUwMFx1MjUwMFxuXHRcdFx0Ly8gRGV2aWNlIHNlbmRzIHR3byBDTURfREVWX1NQRUMgcGFja2V0cyBpbiByZXNwb25zZSB0byBhIHNldDpcblx0XHRcdC8vICAgMS4gQUNLOiAgW3N0YXR1c10gICAgICAgICAgICAgICAoMSBieXRlLCAweDAwID0gb2spXG5cdFx0XHQvLyAgIDIuIEVjaG86IFtidXNDaF0gW3NldHRpbmdJZF0gW3ZhbHVlLi4uXSAgKGNvbmZpcm1pbmcgd2hhdCB3YXMgYXBwbGllZClcblx0XHRcdGNhc2UgQ01EX0RFVl9TUEVDOiB7XG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0XHRcdHJldHVybiBkYXRhWzBdID09PSAweDAwID8gJ0FDSyBvaycgOiBgQUNLIGVycj0ke3RvSGV4KGRhdGFbMF0pfWBcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPj0gMykge1xuXHRcdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGRhdGFbMV1cblx0XHRcdFx0XHRjb25zdCB2YWx1ZUJ5dGVzID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRcdGNvbnN0IGFjdGlvbiA9IHRoaXMuYWN0aW9ucy5maW5kKChhKSA9PiBhLmNtZF9pZCA9PT0gY21kSWQgJiYgYS5pZCA9PT0gc2V0dGluZ0lkKVxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdOYW1lID0gYWN0aW9uPy5uYW1lID8/IGBzZXR0aW5nPSR7dG9IZXgoc2V0dGluZ0lkKX1gXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlcyA9IGFjdGlvbj8ub3B0aW9ucz8uWzBdPy5jaG9pY2VzXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVOdW0gPSB2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSA/IHZhbHVlQnl0ZXNbMF0gOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VMYWJlbCA9XG5cdFx0XHRcdFx0XHRjaG9pY2VzICYmIHZhbHVlTnVtICE9PSB1bmRlZmluZWQgPyBjaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IHZhbHVlTnVtKT8ubGFiZWwgOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCB2YWx1ZVN0ciA9IGNob2ljZUxhYmVsID8gYCR7Y2hvaWNlTGFiZWx9ICgke3RvSGV4KHZhbHVlTnVtISl9KWAgOiBieXRlc1RvSGV4KEFycmF5LmZyb20odmFsdWVCeXRlcykpXG5cdFx0XHRcdFx0Y29uc3QgcmF3VGFnID0gYFske3RvSGV4KGNtZElkKX0vJHt0b0hleChzZXR0aW5nSWQpfV09JHtieXRlc1RvSGV4KEFycmF5LmZyb20odmFsdWVCeXRlcykpfWBcblx0XHRcdFx0XHRyZXR1cm4gYGVjaG8gY2g9JHtidXNDaH0gfCAke3NldHRpbmdOYW1lfTogJHt2YWx1ZVN0cn0gJHtyYXdUYWd9YFxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBgcmF3OiAke2RhdGEudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9NSUNfUFJFX0JVUyAoMHgxMik6IE11bHRpLWJ5dGUgZWNobyByZXNwb25zZXMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHRjYXNlIENNRF9NSUNfUFJFX0JVUzoge1xuXHRcdFx0XHQvLyBBbHJlYWR5IGhhbmRsZWQgc2luZ2xlLWJ5dGUgYWJvdmUsIHNvIG11bHRpLWJ5dGUgbXVzdCBiZSBlY2hvXG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA+PSAzKSB7XG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBkYXRhWzBdXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gZGF0YVsxXVxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlQnl0ZXMgPSBkYXRhLnN1YmFycmF5KDIpXG5cdFx0XHRcdFx0Y29uc3QgYWN0aW9uID0gdGhpcy5hY3Rpb25zLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBzZXR0aW5nSWQpXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ05hbWUgPSBhY3Rpb24/Lm5hbWUgPz8gYHNldHRpbmc9JHt0b0hleChzZXR0aW5nSWQpfWBcblx0XHRcdFx0XHRjb25zdCB2YWx1ZU51bSA9IHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxID8gdmFsdWVCeXRlc1swXSA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IGNob2ljZXMgPSBhY3Rpb24/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICd2YWx1ZScpPy5jaG9pY2VzXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlTGFiZWwgPVxuXHRcdFx0XHRcdFx0Y2hvaWNlcyAmJiB2YWx1ZU51bSAhPT0gdW5kZWZpbmVkID8gY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSB2YWx1ZU51bSk/LmxhYmVsIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVTdHIgPSBjaG9pY2VMYWJlbCA/PyBgMHgke3ZhbHVlQnl0ZXMudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdFx0XHRyZXR1cm4gYGVjaG8gY2g9JHtidXNDaH0gfCAke3NldHRpbmdOYW1lfTogJHt2YWx1ZVN0cn1gXG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIG51bGxcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIEJ1cy1zY29wZWQgZ2V0L3NldCBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRcdGNhc2UgQ01EX0JVU19HRVQ6XG5cdFx0XHRjYXNlIENNRF9CVVNfU0VUOiB7XG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA8IDIpIHJldHVybiBudWxsXG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBkYXRhWzFdXG5cdFx0XHRcdGNvbnN0IHZhbHVlID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRyZXR1cm4gYGNoPSR7YnVzQ2h9IHNldHRpbmc9JHt0b0hleChzZXR0aW5nSWQpfSB2YWx1ZT0ke3ZhbHVlLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHR9XG5cblx0XHRcdGRlZmF1bHQ6XG5cdFx0XHRcdHJldHVybiBudWxsIC8vIGZhbGwgdGhyb3VnaCB0byByYXcgaGV4XG5cdFx0fVxuXHR9XG5cblx0cHJpdmF0ZSBzdGF0aWMgYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlOiB1bmtub3duKTogbnVtYmVyW10ge1xuXHRcdGlmICh0eXBlb2YgdmFsdWUgPT09ICdib29sZWFuJykgcmV0dXJuIFt2YWx1ZSA/IDEgOiAwXVxuXHRcdGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkgcmV0dXJuIHZhbHVlLm1hcCgodikgPT4gTnVtYmVyKHYpICYgMHhmZilcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykge1xuXHRcdFx0aWYgKHZhbHVlID4gMHhmZikgcmV0dXJuIFsodmFsdWUgPj4gMTYpICYgMHhmZiwgKHZhbHVlID4+IDgpICYgMHhmZiwgdmFsdWUgJiAweGZmXVxuXHRcdFx0cmV0dXJuIFt2YWx1ZSAmIDB4ZmZdXG5cdFx0fVxuXHRcdHRocm93IG5ldyBFcnJvcihgVW5zdXBwb3J0ZWQgdmFsdWUgdHlwZSBmb3IgU1Rjb250cm9sbGVyOiAke3ZhbHVlfWApXG5cdH1cblxuXHRwcml2YXRlIGFzeW5jIGJ1aWxkSGVhZGVyKHRvdGFsTGVuOiBudW1iZXIsIGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRsZXQgbWFjID0gdGhpcy5tYWNDYWNoZS5nZXQoZGVzdElwKVxuXHRcdGlmICghbWFjKSB7XG5cdFx0XHRtYWMgPSBhd2FpdCBnZXRNYWNGb3JEZXN0aW5hdGlvbihkZXN0SXApXG5cdFx0XHR0aGlzLm1hY0NhY2hlLnNldChkZXN0SXAsIG1hYylcblx0XHR9XG5cblx0XHRyZXR1cm4gQnVmZmVyLmNvbmNhdChbXG5cdFx0XHRCdWZmZXIuZnJvbShbMHhmZiwgMHhmZiwgMHgwMCwgdG90YWxMZW4gJiAweGZmLCAweDA3LCAweGUxLCAweDAwLCAweDAwLCAuLi5tYWMsIDB4MDAsIDB4MDBdKSxcblx0XHRcdEJ1ZmZlci5mcm9tKCdTdHVkaW8tVCcsICd1dGY4JyksXG5cdFx0XSlcblx0fVxuXG5cdHByaXZhdGUgc3RhdGljIGNyYzhEdmJTMihkYXRhOiBudW1iZXJbXSk6IG51bWJlciB7XG5cdFx0bGV0IGNyYyA9IDBcblx0XHRmb3IgKGNvbnN0IGIgb2YgZGF0YSkge1xuXHRcdFx0Y3JjIF49IGJcblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgODsgaSsrKSB7XG5cdFx0XHRcdGNyYyA9IChjcmMgJiAweDgwKSAhPT0gMCA/ICgoY3JjIDw8IDEpIF4gMHhkNSkgJiAweGZmIDogKGNyYyA8PCAxKSAmIDB4ZmZcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIGNyY1xuXHR9XG5cblx0LyoqXG5cdCAqIFJldHVybnMgdGhlIGN1cnJlbnQga25vd24gdmFsdWUgZm9yIGEgc2V0dGluZyBvbiBhIGRldmljZSwgb3IgdW5kZWZpbmVkIGlmIHVua25vd24uXG5cdCAqIFVzZSBmb3IgZmVlZGJhY2tzIFx1MjAxNCB2YWx1ZSBpcyB1cGRhdGVkIG9uIGV2ZXJ5IENNRF9TRVRUSU5HU19QVVNIICgweDBiKSBmcm9tIHRoZSBkZXZpY2UuXG5cdCAqXG5cdCAqIEBwYXJhbSBpcCAgICAgICAgRGV2aWNlIElQIGFkZHJlc3Ncblx0ICogQHBhcmFtIGNtZElkICAgICBDb21tYW5kIElEIChlLmcuIENNRF9ERVZfU1BFQylcblx0ICogQHBhcmFtIHNldHRpbmdJZCBTZXR0aW5nIElEIChlLmcuIDB4MDIgZm9yIENvbnRyb2wgU291cmNlKVxuXHQgKiBAcGFyYW0gYnVzQ2ggICAgIE9wdGlvbmFsIGJ1cy9jaGFubmVsIElEIGZvciBtdWx0aS1jaGFubmVsIGNvbW1hbmRzXG5cdCAqL1xuXHRwdWJsaWMgZ2V0U2V0dGluZ1ZhbHVlKGlwOiBzdHJpbmcsIGNtZElkOiBudW1iZXIsIHNldHRpbmdJZDogbnVtYmVyLCBidXNDaD86IG51bWJlcik6IG51bWJlciB8IHVuZGVmaW5lZCB7XG5cdFx0Y29uc3Qga2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkLCBidXNDaClcblx0XHRyZXR1cm4gdGhpcy5kZXZpY2VTdGF0ZS5nZXQoaXApPy5nZXQoa2V5KVxuXHR9XG5cblx0cHVibGljIGFzeW5jIHJlc2V0RGV2aWNlKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRyZXR1cm4gdGhpcy5zZW5kQXdhaXRBY2soQ01EX1JFU0VUX0RFVklDRSwgdW5kZWZpbmVkLCAweDAwLCB1bmRlZmluZWQsIGRlc3RJcCwgZmFsc2UpXG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgZ2xvYmFsTWljS2lsbChkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0cmV0dXJuIHRoaXMuc2VuZEF3YWl0QWNrKENNRF9HTE9CQUxfTUlDX0tJTEwsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIGRlc3RJcCwgZmFsc2UpXG5cdH1cbn1cbiIsICJpbXBvcnQgZGdyYW0gZnJvbSAnZGdyYW0nXG5pbXBvcnQgb3MgZnJvbSAnb3MnXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHR5cGUgeyBEZXZpY2VJbmZvIH0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdEYW50ZScpXG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBEYW50ZSBkaXNjb3ZlcnkgY29uc3RhbnRzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG4vKiogRGFudGUgZGV2aWNlIGluZm8gcmVxdWVzdCBtZXNzYWdlIHR5cGUgKHNlbnQgdG8gcG9ydCA4NzAwKSAqL1xuY29uc3QgREFOVEVfTVNHX0lORk9fUkVRVUVTVCA9IDB4MDAyMFxuLyoqIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlIG1lc3NhZ2UgdHlwZSAocmVjZWl2ZWQgb24gcG9ydCA4NzAyKSAqL1xuZXhwb3J0IGNvbnN0IERBTlRFX01TR19JTkZPX1JFU1BPTlNFID0gMHgwMTcwXG5jb25zdCBEQU5URV9JTkZPX01JTl9MRU4gPSAweGNjICsgNjQgLy8gMjY4IGJ5dGVzIFx1MjAxNCBuZWVkIGZ1bGwgbW9kZWwgZmllbGRcblxuZnVuY3Rpb24gYnVpbGREYW50ZUluZm9SZXF1ZXN0KCk6IEJ1ZmZlciB7XG5cdGNvbnN0IGJ1ZiA9IEJ1ZmZlci5hbGxvYygzMiwgMClcblx0Y29uc3Qgc2VxID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMHhmZmZmKVxuXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKDB4ZmZmZiwgMClcblx0YnVmLndyaXRlVUludDE2QkUoREFOVEVfTVNHX0lORk9fUkVRVUVTVCwgMilcblx0YnVmLndyaXRlVUludDE2QkUoc2VxLCA0KVxuXG5cdGNvbnN0IG1hYyA9IGdldEZpcnN0TG9jYWxNYWMoKVxuXHRtYWMuY29weShidWYsIDgpXG5cblx0QnVmZmVyLmZyb20oJ0F1ZGluYXRlJywgJ2FzY2lpJykuY29weShidWYsIDE2KVxuXHRidWYud3JpdGVVSW50MTZCRSgweDA3MzksIDI0KVxuXHRidWYud3JpdGVVSW50MTZCRSgweDAwYzEsIDI2KVxuXHRidWYud3JpdGVVSW50MzJCRSgweDAwMGY0MjQwLCAyOClcblxuXHRyZXR1cm4gYnVmXG59XG5cbi8qKiBSZXR1cm5zIHRoZSBmaXJzdCBub24tbG9vcGJhY2sgTUFDIGFzIGEgNi1ieXRlIEJ1ZmZlciwgb3IgemVyb3MuICovXG5mdW5jdGlvbiBnZXRGaXJzdExvY2FsTWFjKCk6IEJ1ZmZlciB7XG5cdHRyeSB7XG5cdFx0Y29uc3QgaWZhY2VzID0gb3MubmV0d29ya0ludGVyZmFjZXMoKVxuXHRcdGZvciAoY29uc3QgbmFtZSBvZiBPYmplY3Qua2V5cyhpZmFjZXMpKSB7XG5cdFx0XHRmb3IgKGNvbnN0IGFkZHIgb2YgaWZhY2VzW25hbWVdID8/IFtdKSB7XG5cdFx0XHRcdGlmICghYWRkci5pbnRlcm5hbCAmJiBhZGRyLmZhbWlseSA9PT0gJ0lQdjQnICYmIGFkZHIubWFjICYmIGFkZHIubWFjICE9PSAnMDA6MDA6MDA6MDA6MDA6MDAnKSB7XG5cdFx0XHRcdFx0cmV0dXJuIEJ1ZmZlci5mcm9tKGFkZHIubWFjLnNwbGl0KCc6JykubWFwKChoOiBzdHJpbmcpID0+IHBhcnNlSW50KGgsIDE2KSkpXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH0gY2F0Y2gge1xuXHRcdC8qIGlnbm9yZSAqL1xuXHR9XG5cdHJldHVybiBCdWZmZXIuYWxsb2MoNiwgMClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlRGFudGVJbmZvUmVzcG9uc2UobXNnOiBCdWZmZXIsIHNyY0lwOiBzdHJpbmcpOiBEZXZpY2VJbmZvIHwgbnVsbCB7XG5cdGlmIChtc2cubGVuZ3RoIDwgREFOVEVfSU5GT19NSU5fTEVOKSByZXR1cm4gbnVsbFxuXHRpZiAobXNnLnJlYWRVSW50MTZCRSgwKSAhPT0gMHhmZmZmKSByZXR1cm4gbnVsbFxuXHRpZiAobXNnLnJlYWRVSW50MTZCRSgyKSAhPT0gREFOVEVfTVNHX0lORk9fUkVTUE9OU0UpIHJldHVybiBudWxsXG5cdGlmIChtc2cuc3ViYXJyYXkoMTYsIDI0KS50b1N0cmluZygnYXNjaWknKSAhPT0gJ0F1ZGluYXRlJykgcmV0dXJuIG51bGxcblxuXHRjb25zdCByZWFkU3RyID0gKG9mZnNldDogbnVtYmVyLCBsZW46IG51bWJlcik6IHN0cmluZyA9PlxuXHRcdG1zZ1xuXHRcdFx0LnN1YmFycmF5KG9mZnNldCwgb2Zmc2V0ICsgbGVuKVxuXHRcdFx0LnRvU3RyaW5nKCdhc2NpaScpXG5cdFx0XHQuc3BsaXQoJ1xcMCcpWzBdXG5cdFx0XHQudHJpbSgpXG5cblx0Y29uc3QgZXVpNjQgPSBtc2cuc3ViYXJyYXkoOCwgMTYpXG5cdGNvbnN0IG1hY0J5dGVzID0gW2V1aTY0WzBdLCBldWk2NFsxXSwgZXVpNjRbMl0sIGV1aTY0WzVdLCBldWk2NFs2XSwgZXVpNjRbN11dXG5cdGNvbnN0IG1hYyA9IG1hY0J5dGVzLm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSkuam9pbignOicpXG5cblx0Y29uc3QgbmFtZSA9IHJlYWRTdHIoMHgyMCwgMzEpIC8vIERhbnRlIGRldmljZSBsYWJlbCAoY2FuIGJlIHVwIHRvIDMxIGNoYXJzIHBlciBEYW50ZSBzcGVjKVxuXHRjb25zdCBtYW51ZmFjdHVyZXIgPSByZWFkU3RyKDB4NGMsIDY0KSAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGNvbnN0IG1vZGVsUmF3ID0gcmVhZFN0cigweGNjLCA2NClcblx0Y29uc3QgZGFudGVGaXJtd2FyZSA9IGAke21zZ1sweDE4XX0uJHttc2dbMHgxOV19YFxuXG5cdGlmICghbW9kZWxSYXcpIHJldHVybiBudWxsXG5cblx0Ly8gRXh0cmFjdCBqdXN0IHRoZSBtb2RlbCBudW1iZXIvY29kZSAoZS5nLiBcIk1vZGVsIDM5MSBBbGVydGluZyBVbml0XCIgXHUyMTkyIFwiMzkxXCIpXG5cdC8vIFN0cmlwIFwiTW9kZWwgXCIgcHJlZml4LCB0aGVuIHRha2Ugb25seSB0aGUgZmlyc3Qgd29yZCAodGhlIG1vZGVsIG51bWJlcilcblx0Y29uc3QgbW9kZWwgPSBtb2RlbFJhd1xuXHRcdC5yZXBsYWNlKC9eTW9kZWxcXHMrL2ksICcnKVxuXHRcdC50cmltKClcblx0XHQuc3BsaXQoL1xccysvKVswXVxuXG5cdHJldHVybiB7XG5cdFx0aXA6IHNyY0lwLFxuXHRcdG5hbWUsXG5cdFx0bWFudWZhY3R1cmVyLFxuXHRcdG1vZGVsLFxuXHRcdG1vZGVsTmFtZTogbW9kZWxSYXcsIC8vIEZ1bGwgbW9kZWwgZGVzY3JpcHRpb25cblx0XHRtYWMsXG5cdFx0ZGFudGVGaXJtd2FyZSxcblx0fVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIE1BQyBhZGRyZXNzIGJ5dGVzIG9mIHRoZSBsb2NhbCBpbnRlcmZhY2UgdXNlZCB0byByb3V0ZSB0byBkZXN0SXAuXG4gKiBVc2VzIGEgdGVtcG9yYXJ5IFVEUCBjb25uZWN0IHRvIGxldCB0aGUgT1Mgc2VsZWN0IHRoZSBvdXRnb2luZyBpbnRlcmZhY2UsXG4gKiB0aGVuIGZpbmRzIHRoZSBtYXRjaGluZyBNQUMgZnJvbSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFjRm9yRGVzdGluYXRpb24oZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPG51bWJlcltdPiB7XG5cdHJldHVybiBuZXcgUHJvbWlzZTxudW1iZXJbXT4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGNvbnN0IHRtcCA9IGRncmFtLmNyZWF0ZVNvY2tldCgndWRwNCcpXG5cblx0XHR0bXAub25jZSgnZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0fSlcblxuXHRcdHRtcC5jb25uZWN0KDksIGRlc3RJcCwgKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3QgYWRkciA9IHRtcC5hZGRyZXNzKCkgYXMgeyBhZGRyZXNzOiBzdHJpbmcgfVxuXHRcdFx0XHRjb25zdCBsb2NhbEFkZHIgPSBhZGRyLmFkZHJlc3Ncblx0XHRcdFx0dG1wLmNsb3NlKClcblxuXHRcdFx0XHRjb25zdCBpZmFjZXMgPSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpXG5cdFx0XHRcdGZvciAoY29uc3QgbmFtZSBvZiBPYmplY3Qua2V5cyhpZmFjZXMpKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBpZmFjZSBvZiBpZmFjZXNbbmFtZV0gPz8gW10pIHtcblx0XHRcdFx0XHRcdGlmIChcblx0XHRcdFx0XHRcdFx0aWZhY2UuZmFtaWx5ID09PSAnSVB2NCcgJiZcblx0XHRcdFx0XHRcdFx0aWZhY2UuYWRkcmVzcyA9PT0gbG9jYWxBZGRyICYmXG5cdFx0XHRcdFx0XHRcdGlmYWNlLm1hYyAmJlxuXHRcdFx0XHRcdFx0XHRpZmFjZS5tYWMgIT09ICcwMDowMDowMDowMDowMDowMCdcblx0XHRcdFx0XHRcdCkge1xuXHRcdFx0XHRcdFx0XHRyZXR1cm4gcmVzb2x2ZShpZmFjZS5tYWMuc3BsaXQoJzonKS5tYXAoKGIpID0+IHBhcnNlSW50KGIsIDE2KSAmIDB4ZmYpKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGBObyBpbnRlcmZhY2UgZm91bmQgZm9yIGxvY2FsIGFkZHJlc3MgJHtsb2NhbEFkZHJ9YCkpXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKFN0cmluZyhfZSkpKVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0pXG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgbG9jYWwgSVAgYWRkcmVzcyB1c2VkIGJ5IHRoZSBPUyB0byByb3V0ZSB0byBkZXN0SXAuXG4gKiBVc2VzIGEgdGVtcG9yYXJ5IFVEUCBzb2NrZXQgY29ubmVjdCB0byBsZXQgdGhlIE9TIHNlbGVjdCB0aGUgb3V0Z29pbmcgaW50ZXJmYWNlLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TG9jYWxBZGRyZXNzRm9yRGVzdGluYXRpb24oZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuXHRyZXR1cm4gbmV3IFByb21pc2U8c3RyaW5nPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0Y29uc3QgdG1wID0gZGdyYW0uY3JlYXRlU29ja2V0KCd1ZHA0JylcblxuXHRcdGxldCByZXNvbHZlZCA9IGZhbHNlXG5cdFx0dG1wLm9uY2UoJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0aWYgKCFyZXNvbHZlZCkge1xuXHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdC8vIFVzZSBhbiBhcmJpdHJhcnkgcG9ydCBmb3IgY29ubmVjdDsgd2Ugb25seSBuZWVkIHRoZSBrZXJuZWwgdG8gYXNzaWduIGEgbG9jYWwgYWRkcmVzcy5cblx0XHR0bXAuY29ubmVjdCg5LCBkZXN0SXAsICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IGFkZHIgPSB0bXAuYWRkcmVzcygpIGFzIHsgYWRkcmVzczogc3RyaW5nIH1cblx0XHRcdFx0Y29uc3QgbG9jYWxBZGRyID0gYWRkci5hZGRyZXNzXG5cdFx0XHRcdGlmICghcmVzb2x2ZWQpIHtcblx0XHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0XHRcdHJlc29sdmUobG9jYWxBZGRyKVxuXHRcdFx0XHR9XG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRpZiAoIXJlc29sdmVkKSB7XG5cdFx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0XHRyZWplY3QobmV3IEVycm9yKFN0cmluZyhfZSkpKVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSlcblx0fSlcbn1cblxuLyoqXG4gKiBMaXN0ZW5zIGZvciBEYW50ZSBkZXZpY2UgYW5ub3VuY2VzIG9uIHRoZSBsb2NhbCBuZXR3b3JrIGFuZCBzZW5kcyB1bmljYXN0XG4gKiBpbmZvIHJlcXVlc3RzIHRvIGVhY2ggZGlzY292ZXJlZCBJUC4gUmVzcG9uc2VzIGFycml2ZSBvbiB0aGUgY2FsbGVyJ3MgcnhTb2NrZXRcbiAqIHZpYSBoYW5kbGVJbmNvbWluZygpIFx1MjE5MiBkaXNjb3ZlcnlMaXN0ZW5lcnMuXG4gKlxuICogQHBhcmFtIHR4U29ja2V0IC0gVGhlIHNvY2tldCB0byB1c2UgZm9yIHNlbmRpbmcgZGlzY292ZXJ5IHJlcXVlc3RzXG4gKiBAcGFyYW0gZW5zdXJlTWVtYmVyc2hpcCAtIENhbGxiYWNrIHRvIGVuc3VyZSBtdWx0aWNhc3QgbWVtYmVyc2hpcCBiZWZvcmUgcXVlcnlpbmdcbiAqIEBwYXJhbSB0aW1lb3V0TXMgLSBIb3cgbG9uZyB0byBsaXN0ZW4gZm9yIGFubm91bmNlcyBiZWZvcmUgcmVzb2x2aW5nXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkaXNjb3ZlckRldmljZXMoXG5cdHR4U29ja2V0OiBkZ3JhbS5Tb2NrZXQsXG5cdGVuc3VyZU1lbWJlcnNoaXA6IChkZXN0SXA6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPixcblx0dGltZW91dE1zID0gNTAwMCxcbik6IFByb21pc2U8dm9pZD4ge1xuXHRjb25zdCBEQU5URV9BTk5PVU5DRV9HUk9VUCA9ICcyMjQuMC4wLjIzMydcblx0Y29uc3QgREFOVEVfQU5OT1VOQ0VfUE9SVCA9IDg3MDhcblx0Y29uc3QgREVGQVVMVF9QT1JUID0gODcwMFxuXG5cdGNvbnN0IHF1ZXJpZWRJcHMgPSBuZXcgU2V0PHN0cmluZz4oKVxuXG5cdHJldHVybiBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuXHRcdGNvbnN0IGFubm91bmNlU29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblx0XHRjb25zdCBqb2luZWRJbnRlcmZhY2VzOiBzdHJpbmdbXSA9IFtdXG5cblx0XHRjb25zdCBjbGVhbnVwID0gKCkgPT4ge1xuXHRcdFx0Zm9yIChjb25zdCBpZmFjZSBvZiBqb2luZWRJbnRlcmZhY2VzKSB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuZHJvcE1lbWJlcnNoaXAoREFOVEVfQU5OT1VOQ0VfR1JPVVAsIGlmYWNlKVxuXHRcdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuY2xvc2UoKVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdFx0cmVzb2x2ZSgpXG5cdFx0fVxuXG5cdFx0Y29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KGNsZWFudXAsIHRpbWVvdXRNcylcblx0XHR0aW1lci51bnJlZj8uKClcblxuXHRcdGFubm91bmNlU29ja2V0Lm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGxvZ2dlci53YXJuKGBBbm5vdW5jZSBzb2NrZXQgZXJyb3I6ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHR9KVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQub24oJ21lc3NhZ2UnLCAobXNnLCByaW5mbykgPT4ge1xuXHRcdFx0Y29uc3Qgc3JjSXAgPSByaW5mby5hZGRyZXNzXG5cdFx0XHQvLyBWYWxpZGF0ZSBpdCdzIGEgRGFudGUgYW5ub3VuY2UgKG1hZ2ljIDB4ZmZmZSArIFwiQXVkaW5hdGVcIiBhdCBvZmZzZXQgMTYpXG5cdFx0XHRpZiAobXNnLmxlbmd0aCA8IDI0KSByZXR1cm5cblx0XHRcdGlmIChtc2cucmVhZFVJbnQxNkJFKDApICE9PSAweGZmZmUpIHJldHVyblxuXHRcdFx0aWYgKG1zZy5zdWJhcnJheSgxNiwgMjQpLnRvU3RyaW5nKCdhc2NpaScpICE9PSAnQXVkaW5hdGUnKSByZXR1cm5cblxuXHRcdFx0aWYgKHF1ZXJpZWRJcHMuaGFzKHNyY0lwKSkgcmV0dXJuXG5cdFx0XHRxdWVyaWVkSXBzLmFkZChzcmNJcClcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgQW5ub3VuY2UgZnJvbSAke3NyY0lwfSBcdTIwMTQgc2VuZGluZyB1bmljYXN0IHF1ZXJ5YClcblxuXHRcdFx0Ly8gSm9pbiAyMjQuMC4wLjIzMSBvbiB0aGUgaW50ZXJmYWNlIHRoYXQgcm91dGVzIHRvIHRoaXMgZGV2aWNlIEJFRk9SRSBzZW5kaW5nXG5cdFx0XHQvLyB0aGUgcXVlcnkuIFRoZSBkZXZpY2UgbXVsdGljYXN0cyBpdHMgMHgwMTcwIHJlc3BvbnNlIHRvIDIyNC4wLjAuMjMxOjg3MDJcblx0XHRcdC8vIGluIGFkZGl0aW9uIHRvIHVuaWNhc3RpbmcgaXQgXHUyMDE0IHJ4U29ja2V0IG11c3QgYmUgYSBtZW1iZXIgdG8gcmVjZWl2ZSBpdC5cblx0XHRcdGNvbnN0IHNlbmRRdWVyeSA9IGFzeW5jICgpID0+IHtcblx0XHRcdFx0YXdhaXQgZW5zdXJlTWVtYmVyc2hpcChzcmNJcClcblx0XHRcdFx0Y29uc3QgcXVlcnkgPSBidWlsZERhbnRlSW5mb1JlcXVlc3QoKVxuXHRcdFx0XHR0eFNvY2tldC5zZW5kKHF1ZXJ5LCBERUZBVUxUX1BPUlQsIHNyY0lwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdFx0aWYgKGVycikgbG9nZ2VyLndhcm4oYFVuaWNhc3QgcXVlcnkgdG8gJHtzcmNJcH0gZmFpbGVkOiAke2Vyci5tZXNzYWdlfWApXG5cdFx0XHRcdH0pXG5cdFx0XHR9XG5cdFx0XHRzZW5kUXVlcnkoKS5jYXRjaCgoZXJyKSA9PiBsb2dnZXIud2FybihgUXVlcnkgc2V0dXAgZmFpbGVkOiAke2Vycn1gKSlcblx0XHR9KVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQuYmluZChEQU5URV9BTk5PVU5DRV9QT1JULCAoKSA9PiB7XG5cdFx0XHQvLyBKb2luIDIyNC4wLjAuMjMzIG9uIGV2ZXJ5IG5vbi1sb29wYmFjayBJUHY0IGludGVyZmFjZSBzbyB0aGF0IGFubm91bmNlc1xuXHRcdFx0Ly8gYXJlIHJlY2VpdmVkIHJlZ2FyZGxlc3Mgb2Ygd2hpY2ggaW50ZXJmYWNlIHRoZSBkZXZpY2UgaXMgb24uXG5cdFx0XHQvLyBPbiBXaW5kb3dzIHdpdGggbXVsdGlwbGUgaW50ZXJmYWNlcyAoZS5nLiBIeXBlci1WICsgTEFOKSwgdGhlIE9TIGRlZmF1bHRcblx0XHRcdC8vIG11bHRpY2FzdCBpbnRlcmZhY2UgbWF5IG5vdCBiZSB0aGUgb25lIGNvbm5lY3RlZCB0byB0aGUgRGFudGUgbmV0d29yay5cblx0XHRcdGNvbnN0IGlmYWNlcyA9IG9zLm5ldHdvcmtJbnRlcmZhY2VzKClcblx0XHRcdGZvciAoY29uc3QgYWRkcnMgb2YgT2JqZWN0LnZhbHVlcyhpZmFjZXMpKSB7XG5cdFx0XHRcdGZvciAoY29uc3QgYWRkciBvZiBhZGRycyA/PyBbXSkge1xuXHRcdFx0XHRcdGlmIChhZGRyLmZhbWlseSA9PT0gJ0lQdjQnICYmICFhZGRyLmludGVybmFsKSB7XG5cdFx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0XHRhbm5vdW5jZVNvY2tldC5hZGRNZW1iZXJzaGlwKERBTlRFX0FOTk9VTkNFX0dST1VQLCBhZGRyLmFkZHJlc3MpXG5cdFx0XHRcdFx0XHRcdGpvaW5lZEludGVyZmFjZXMucHVzaChhZGRyLmFkZHJlc3MpXG5cdFx0XHRcdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0XHRcdFx0LyogaWdub3JlIFx1MjAxNCBpbnRlcmZhY2UgbWF5IG5vdCBzdXBwb3J0IG11bHRpY2FzdCAqL1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKGpvaW5lZEludGVyZmFjZXMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3Qgam9pbiBhbm5vdW5jZSBtdWx0aWNhc3QgZ3JvdXAgb24gYW55IGludGVyZmFjZWApXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRsb2dnZXIuZGVidWcoYExpc3RlbmluZyBmb3IgRGFudGUgYW5ub3VuY2VzIG9uICR7REFOVEVfQU5OT1VOQ0VfR1JPVVB9OiR7REFOVEVfQU5OT1VOQ0VfUE9SVH1gKVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0pXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBDb25Nb24gc2Vzc2lvbiAocG9ydCA4ODAwKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuLyoqIENvYWxlc2NlcyBjb25jdXJyZW50IG9wZW5Db25Nb25TZXNzaW9uIGNhbGxzIHBlciBJUCAqL1xuY29uc3QgX2Nvbm1vblBlbmRpbmcgPSBuZXcgTWFwPHN0cmluZywgUHJvbWlzZTwoKCkgPT4gdm9pZCkgfCBudWxsPj4oKVxuXG4vKipcbiAqIE9wZW5zIGEgRGFudGUgQ29uTW9uIChDb250cm9sICYgTW9uaXRvcmluZykgc2Vzc2lvbiB3aXRoIHRoZSBkZXZpY2Ugb24gcG9ydCA4ODAwLlxuICogQ29hbGVzY2VzIGNvbmN1cnJlbnQgY2FsbHMgZm9yIHRoZSBzYW1lIElQIFx1MjAxNCBvbmx5IG9uZSBoYW5kc2hha2UgcnVucyBhdCBhIHRpbWUuXG4gKlxuICogUmV0dXJucyBhIGNsZWFudXAgZnVuY3Rpb24gdGhhdCBzdG9wcyBrZWVwYWxpdmVzIGFuZCBjbG9zZXMgdGhlIHNvY2tldCxcbiAqIG9yIG51bGwgaWYgdGhlIHNlc3Npb24gY291bGQgbm90IGJlIGVzdGFibGlzaGVkLlxuICpcbiAqIFRoZSA1NDAxQSAoYW5kIHBvc3NpYmx5IG90aGVyIGRldmljZXMpIHJlcXVpcmUgdGhlIENvbk1vbiBzZXNzaW9uIHRvIG9yaWdpbmF0ZVxuICogZnJvbSBwb3J0IDg4MDAgQU5EIHJlbWFpbiBhbGl2ZSB3aXRoIHBlcmlvZGljIGtlZXBhbGl2ZXMgKHR5cGUgMHgwMDRlKSBiZWZvcmVcbiAqIHRoZXkgd2lsbCByZXNwb25kIHRvIFN0dWRpby1UIGNvbW1hbmRzLiBPdGhlciBkZXZpY2VzICgzNzRBLCAzOTEpIGFjY2VwdFxuICogQ29uTW9uIGZyb20gYW55IGVwaGVtZXJhbCBwb3J0IGFuZCBkb24ndCByZXF1aXJlIGtlZXBhbGl2ZXMgdG8gcmVzcG9uZC5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG9wZW5Db25Nb25TZXNzaW9uKGRldmljZUlwOiBzdHJpbmcsIHRpbWVvdXRNcyA9IDMwMDApOiBQcm9taXNlPCgoKSA9PiB2b2lkKSB8IG51bGw+IHtcblx0Y29uc3QgcGVuZGluZyA9IF9jb25tb25QZW5kaW5nLmdldChkZXZpY2VJcClcblx0aWYgKHBlbmRpbmcpIHJldHVybiBwZW5kaW5nXG5cblx0Y29uc3QgcHJvbWlzZSA9IF9kb0Nvbk1vblNlc3Npb24oZGV2aWNlSXAsIHRpbWVvdXRNcykuZmluYWxseSgoKSA9PiB7XG5cdFx0X2Nvbm1vblBlbmRpbmcuZGVsZXRlKGRldmljZUlwKVxuXHR9KVxuXHRfY29ubW9uUGVuZGluZy5zZXQoZGV2aWNlSXAsIHByb21pc2UpXG5cdHJldHVybiBwcm9taXNlXG59XG5cbmFzeW5jIGZ1bmN0aW9uIF9kb0Nvbk1vblNlc3Npb24oZGV2aWNlSXA6IHN0cmluZywgdGltZW91dE1zOiBudW1iZXIpOiBQcm9taXNlPCgoKSA9PiB2b2lkKSB8IG51bGw+IHtcblx0cmV0dXJuIG5ldyBQcm9taXNlPCgoKSA9PiB2b2lkKSB8IG51bGw+KChyZXNvbHZlKSA9PiB7XG5cdFx0bGV0IHNldHRsZWQgPSBmYWxzZVxuXHRcdGxldCBrZWVwYWxpdmVUaW1lcjogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGxcblxuXHRcdGNvbnN0IGNsb3NlU2Vzc2lvbiA9IChzb2NrOiBkZ3JhbS5Tb2NrZXQpID0+IHtcblx0XHRcdGlmIChrZWVwYWxpdmVUaW1lcikge1xuXHRcdFx0XHRjbGVhckludGVydmFsKGtlZXBhbGl2ZVRpbWVyKVxuXHRcdFx0XHRrZWVwYWxpdmVUaW1lciA9IG51bGxcblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdHNvY2suY2xvc2UoKVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBDb25Nb24gc2Vzc2lvbiBjbG9zZWQgZm9yICR7ZGV2aWNlSXB9YClcblx0XHR9XG5cblx0XHRjb25zdCBmYWlsID0gKHNvY2s6IGRncmFtLlNvY2tldCkgPT4ge1xuXHRcdFx0aWYgKHNldHRsZWQpIHJldHVyblxuXHRcdFx0c2V0dGxlZCA9IHRydWVcblx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdGNsb3NlU2Vzc2lvbihzb2NrKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBDb25Nb24gc2Vzc2lvbiBub3QgZXN0YWJsaXNoZWQgZm9yICR7ZGV2aWNlSXB9IFx1MjAxNCBkZXZpY2UgbWF5IG5vdCByZXF1aXJlIGl0YClcblx0XHRcdHJlc29sdmUobnVsbClcblx0XHR9XG5cblx0XHQvLyBCaW5kIHRvIHBvcnQgODgwMCBcdTIwMTQgdGhlIDU0MDFBIGdhdGVzIFN0dWRpby1UIHJlc3BvbnNlcyBvbiBDb25Nb25cblx0XHQvLyBvcmlnaW5hdGluZyBmcm9tIHRoaXMgcG9ydC4gT3RoZXIgZGV2aWNlcyBhY2NlcHQgZXBoZW1lcmFsIHBvcnRzLlxuXHRcdGNvbnN0IHNvY2sgPSBkZ3JhbS5jcmVhdGVTb2NrZXQoeyB0eXBlOiAndWRwNCcsIHJldXNlQWRkcjogdHJ1ZSB9KVxuXHRcdGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiBmYWlsKHNvY2spLCB0aW1lb3V0TXMpXG5cblx0XHRzb2NrLm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGxvZ2dlci53YXJuKGBDb25Nb24gc29ja2V0IGVycm9yIGZvciAke2RldmljZUlwfTogJHtlcnIubWVzc2FnZX1gKVxuXHRcdFx0ZmFpbChzb2NrKVxuXHRcdH0pXG5cblx0XHRzb2NrLm9uKCdtZXNzYWdlJywgKG1zZzogQnVmZmVyKSA9PiB7XG5cdFx0XHQvLyBEZXZpY2UgQUNLOiAxMiAwMCAwMCAyMCAuLi4gKGxlbmd0aCBmaWVsZCA9IDB4MjApXG5cdFx0XHRpZiAoIXNldHRsZWQgJiYgbXNnLmxlbmd0aCA+PSA0ICYmIG1zZ1swXSA9PT0gMHgxMiAmJiBtc2dbM10gPT09IDB4MjApIHtcblx0XHRcdFx0c2V0dGxlZCA9IHRydWVcblx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgQ29uTW9uIHNlc3Npb24gZXN0YWJsaXNoZWQgd2l0aCAke2RldmljZUlwfWApXG5cblx0XHRcdFx0Ly8gU3RhcnQga2VlcGFsaXZlcyBcdTIwMTQgdHlwZSAweDAwNGUsIHNhbWUgMjAtYnl0ZSBmb3JtYXQgYXMgdGhlIG9wZW4gcGFja2V0LlxuXHRcdFx0XHQvLyBSZXF1aXJlZCB0byBrZWVwIHRoZSBzZXNzaW9uIGFsaXZlIG9uIHRoZSBkZXZpY2Ugc2lkZS5cblx0XHRcdFx0Ly8gSW50ZXJ2YWwgbWF0Y2hlcyBTVENvbnRyb2xsZXIgKH4xIHNlY29uZCBvYnNlcnZlZCBpbiBjYXB0dXJlcykuXG5cdFx0XHRcdGxldCBrZWVwYWxpdmVTZXEgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAweGZmZmUpICsgMVxuXHRcdFx0XHRjb25zdCBzZW5kS2VlcGFsaXZlID0gKCkgPT4ge1xuXHRcdFx0XHRcdGNvbnN0IHBrdCA9IEJ1ZmZlci5hbGxvYygyMCwgMClcblx0XHRcdFx0XHRwa3RbMF0gPSAweDEyXG5cdFx0XHRcdFx0cGt0WzNdID0gMHg0ZSAvLyBrZWVwYWxpdmUgdHlwZVxuXHRcdFx0XHRcdHBrdC53cml0ZVVJbnQxNkJFKGtlZXBhbGl2ZVNlcSsrICYgMHhmZmZmLCA0KVxuXHRcdFx0XHRcdHBrdFs2XSA9IDB4MzBcblx0XHRcdFx0XHRwa3RbN10gPSAweDEwXG5cdFx0XHRcdFx0c29jay5zZW5kKHBrdCwgODgwMCwgZGV2aWNlSXAsICgpID0+IHtcblx0XHRcdFx0XHRcdC8qIGZpcmUgYW5kIGZvcmdldCAqL1xuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdH1cblx0XHRcdFx0a2VlcGFsaXZlVGltZXIgPSBzZXRJbnRlcnZhbChzZW5kS2VlcGFsaXZlLCAxMDAwKVxuXG5cdFx0XHRcdC8vIFJldHVybiBjbGVhbnVwIGZ1bmN0aW9uIHRvIGNhbGxlclxuXHRcdFx0XHRyZXNvbHZlKCgpID0+IGNsb3NlU2Vzc2lvbihzb2NrKSlcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0Y29uc3QgZG9Jbml0ID0gYXN5bmMgKCkgPT4ge1xuXHRcdFx0bGV0IGxvY2FsSXA6IHN0cmluZ1xuXHRcdFx0bGV0IGxvY2FsTWFjOiBudW1iZXJbXVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0bG9jYWxJcCA9IGF3YWl0IGdldExvY2FsQWRkcmVzc0ZvckRlc3RpbmF0aW9uKGRldmljZUlwKVxuXHRcdFx0XHRsb2NhbE1hYyA9IGF3YWl0IGdldE1hY0ZvckRlc3RpbmF0aW9uKGRldmljZUlwKVxuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRsb2dnZXIud2FybihgQ29uTW9uOiBjb3VsZCBub3QgZ2V0IGxvY2FsIG5ldHdvcmsgaW5mbyBmb3IgJHtkZXZpY2VJcH06ICR7ZX1gKVxuXHRcdFx0XHRmYWlsKHNvY2spXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHQvLyBCaW5kIHRvIHBvcnQgODgwMCBzbyB0aGUgZGV2aWNlIHNlZXMgdGhlIHNlc3Npb24gYXMgY29taW5nIGZyb20gdGhlXG5cdFx0XHQvLyBzdGFuZGFyZCBDb25Nb24gcG9ydC4gcmV1c2VBZGRyIGFsbG93cyB0aGlzIGV2ZW4gaWYgYW5vdGhlciBwcm9jZXNzXG5cdFx0XHQvLyAoZS5nLiBTVENvbnRyb2xsZXIpIGlzIGFsc28gcnVubmluZyBhIENvbk1vbiBzZXNzaW9uLlxuXHRcdFx0c29jay5iaW5kKHsgcG9ydDogODgwMCwgYWRkcmVzczogbG9jYWxJcCB9LCAoKSA9PiB7XG5cdFx0XHRcdGNvbnN0IHNlcSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDB4ZmZmZSkgKyAxXG5cdFx0XHRcdC8vIDIwLWJ5dGUgY29ubmVjdCBwYWNrZXQ6IDEyIDAwIDAwIDE0IFtzZXFdIDEwIDAxIDAwIDAwIDAwIDAwIFtNQUMgNkJdIDAwIDAwXG5cdFx0XHRcdGNvbnN0IHBrdCA9IEJ1ZmZlci5hbGxvYygyMCwgMClcblx0XHRcdFx0cGt0WzBdID0gMHgxMlxuXHRcdFx0XHRwa3RbM10gPSAweDE0IC8vIG9wZW4gdHlwZVxuXHRcdFx0XHRwa3Qud3JpdGVVSW50MTZCRShzZXEsIDQpXG5cdFx0XHRcdHBrdFs2XSA9IDB4MTBcblx0XHRcdFx0cGt0WzddID0gMHgwMVxuXHRcdFx0XHRsb2NhbE1hYy5mb3JFYWNoKChiLCBpKSA9PiB7XG5cdFx0XHRcdFx0cGt0WzEyICsgaV0gPSBiXG5cdFx0XHRcdH0pXG5cdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgQ29uTW9uIFRYIHRvICR7ZGV2aWNlSXB9OiAke3BrdC50b1N0cmluZygnaGV4Jyl9YClcblx0XHRcdFx0c29jay5zZW5kKHBrdCwgODgwMCwgZGV2aWNlSXAsIChlcnIpID0+IHtcblx0XHRcdFx0XHRpZiAoZXJyKSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIud2FybihgQ29uTW9uIHNlbmQgZmFpbGVkIGZvciAke2RldmljZUlwfTogJHtlcnIubWVzc2FnZX1gKVxuXHRcdFx0XHRcdFx0ZmFpbChzb2NrKVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSlcblx0XHRcdH0pXG5cdFx0fVxuXG5cdFx0ZG9Jbml0KCkuY2F0Y2goKGUpID0+IHtcblx0XHRcdGxvZ2dlci53YXJuKGBDb25Nb24gaW5pdCBmYWlsZWQgZm9yICR7ZGV2aWNlSXB9OiAke2V9YClcblx0XHRcdGZhaWwoc29jaylcblx0XHR9KVxuXHR9KVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgRGV2aWNlIHByb2JlIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG4vKipcbiAqIFNlbmRzIGEgdW5pY2FzdCBEYW50ZSBpbmZvIHJlcXVlc3QgdG8gYSBzcGVjaWZpYyBJUCBhbmQgd2FpdHMgZm9yIHRoZSBkZXZpY2UgaW5mb1xuICogcmVzcG9uc2UuIFVzZWQgdG8gdmVyaWZ5IGEgbWFudWFsbHkgY29uZmlndXJlZCBJUC5cbiAqXG4gKiBAcGFyYW0gdHhTb2NrZXQgICAgICAgICBCb3VuZCBzb2NrZXQgdG8gc2VuZCB0aGUgcXVlcnkgZnJvbVxuICogQHBhcmFtIHJlZ2lzdGVyTGlzdGVuZXIgUmVnaXN0ZXIgYSBjYWxsYmFjayAoa2V5ZWQpIHRvIHJlY2VpdmUgcGFyc2VkIERldmljZUluZm8gcmVzcG9uc2VzXG4gKiBAcGFyYW0gcmVtb3ZlTGlzdGVuZXIgICBSZW1vdmUgYSBwcmV2aW91c2x5IHJlZ2lzdGVyZWQgbGlzdGVuZXIgYnkga2V5XG4gKiBAcGFyYW0gZW5zdXJlTWVtYmVyc2hpcCBFbnN1cmUgbXVsdGljYXN0IG1lbWJlcnNoaXAgb24gdGhlIG91dGdvaW5nIGludGVyZmFjZVxuICogQHBhcmFtIGlwICAgICAgICAgICAgICAgVGFyZ2V0IGRldmljZSBJUFxuICogQHBhcmFtIHRpbWVvdXRNcyAgICAgICAgVGltZW91dCBpbiBtaWxsaXNlY29uZHNcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHByb2JlRGV2aWNlKFxuXHR0eFNvY2tldDogZGdyYW0uU29ja2V0LFxuXHRyZWdpc3Rlckxpc3RlbmVyOiAoa2V5OiBzdHJpbmcsIGNiOiAoZGV2aWNlOiBEZXZpY2VJbmZvKSA9PiB2b2lkKSA9PiB2b2lkLFxuXHRyZW1vdmVMaXN0ZW5lcjogKGtleTogc3RyaW5nKSA9PiB2b2lkLFxuXHRlbnN1cmVNZW1iZXJzaGlwOiAoaXA6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPixcblx0aXA6IHN0cmluZyxcblx0dGltZW91dE1zID0gMzAwMCxcbik6IFByb21pc2U8RGV2aWNlSW5mbyB8IG51bGw+IHtcblx0cmV0dXJuIG5ldyBQcm9taXNlPERldmljZUluZm8gfCBudWxsPigocmVzb2x2ZSkgPT4ge1xuXHRcdGNvbnN0IGtleSA9IGBfX3Byb2JlXyR7aXB9X19gXG5cdFx0bGV0IHJlc29sdmVkID0gZmFsc2VcblxuXHRcdGNvbnN0IGZpbmlzaCA9IChyZXN1bHQ6IERldmljZUluZm8gfCBudWxsKSA9PiB7XG5cdFx0XHRpZiAocmVzb2x2ZWQpIHJldHVyblxuXHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRyZW1vdmVMaXN0ZW5lcihrZXkpXG5cdFx0XHRyZXNvbHZlKHJlc3VsdClcblx0XHR9XG5cblx0XHRyZWdpc3Rlckxpc3RlbmVyKGtleSwgKGRldmljZTogRGV2aWNlSW5mbykgPT4ge1xuXHRcdFx0aWYgKGRldmljZS5pcCA9PT0gaXApIGZpbmlzaChkZXZpY2UpXG5cdFx0fSlcblxuXHRcdGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiBmaW5pc2gobnVsbCksIHRpbWVvdXRNcylcblx0XHR0aW1lci51bnJlZj8uKClcblxuXHRcdGNvbnN0IHJ1biA9IGFzeW5jICgpID0+IHtcblx0XHRcdGF3YWl0IGVuc3VyZU1lbWJlcnNoaXAoaXApXG5cdFx0XHRjb25zdCBxdWVyeSA9IGJ1aWxkRGFudGVJbmZvUmVxdWVzdCgpXG5cdFx0XHR0eFNvY2tldC5zZW5kKHF1ZXJ5LCA4NzAwLCBpcCwgKGVycikgPT4ge1xuXHRcdFx0XHRpZiAoZXJyKSB7XG5cdFx0XHRcdFx0bG9nZ2VyLndhcm4oYFByb2JlIHRvICR7aXB9IGZhaWxlZDogJHtlcnIubWVzc2FnZX1gKVxuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRmaW5pc2gobnVsbClcblx0XHRcdFx0fVxuXHRcdFx0fSlcblx0XHR9XG5cblx0XHRydW4oKS5jYXRjaCgoZSkgPT4ge1xuXHRcdFx0bG9nZ2VyLndhcm4oYHByb2JlRGV2aWNlIHNldHVwIGZhaWxlZCBmb3IgJHtpcH06ICR7ZX1gKVxuXHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0ZmluaXNoKG51bGwpXG5cdFx0fSlcblx0fSlcbn1cbiIsICJpbXBvcnQge1xuXHRJbnN0YW5jZVR5cGVzLFxuXHRJbnN0YW5jZUJhc2UsXG5cdEluc3RhbmNlU3RhdHVzLFxuXHRTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsXG5cdGNyZWF0ZU1vZHVsZUxvZ2dlcixcbn0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7IEdldENvbmZpZ0ZpZWxkcywgcmVzb2x2ZUhvc3QsIHJlc29sdmVNb2RlbCwgZ2V0RGV2aWNlU2NoZW1hLCB0eXBlIE1vZHVsZUNvbmZpZyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgVXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucywgVXBkYXRlVmFyaWFibGVWYWx1ZXMgfSBmcm9tICcuL3ZhcmlhYmxlcy5qcydcbmltcG9ydCB7IFVwZ3JhZGVTY3JpcHRzIH0gZnJvbSAnLi91cGdyYWRlcy5qcydcbmltcG9ydCB7IFVwZGF0ZUFjdGlvbnMgfSBmcm9tICcuL2FjdGlvbnMuanMnXG5pbXBvcnQgeyBVcGRhdGVGZWVkYmFja3MgfSBmcm9tICcuL2ZlZWRiYWNrcy5qcydcbmltcG9ydCB7IFN0Q29udHJvbGxlciB9IGZyb20gJy4vc3Rjb250cm9sbGVyLmpzJ1xuaW1wb3J0IHR5cGUgeyBEZXZpY2VJbmZvIH0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdNb2R1bGVJbnN0YW5jZScpXG5cbmV4cG9ydCB0eXBlIE1vZHVsZVR5cGVzID0gSW5zdGFuY2VUeXBlcyAmIHtcblx0Y29uZmlnOiBNb2R1bGVDb25maWdcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTW9kdWxlSW5zdGFuY2UgZXh0ZW5kcyBJbnN0YW5jZUJhc2U8TW9kdWxlVHlwZXM+IHtcblx0Y29uZmlnITogTW9kdWxlQ29uZmlnIC8vIFNldHVwIGluIGluaXQoKVxuXHRzdENvbnRyb2xsZXIhOiBTdENvbnRyb2xsZXJcblxuXHQvKiogQ2FjaGVkIGRpc2NvdmVyeSByZXN1bHRzIFx1MjAxNCBwYXNzZWQgaW50byBnZXRDb25maWdGaWVsZHMoKSBzbyB0aGUgVUlcblx0ICogIGNhbiBzaG93IHRoZSBkaXNjb3ZlcmVkIGRldmljZSBkcm9wZG93biBvbiBzdWJzZXF1ZW50IGNvbmZpZyBvcGVucy4gKi9cblx0cHJpdmF0ZSBkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW11cblxuXHQvKiogQ3VycmVudGx5IGFjdGl2ZSBtb2RlbCBcdTIwMTQgcmVzb2x2ZWQgb25jZSBpbiBzeW5jTW9kZWwoKSBhbmQgY2FjaGVkIGhlcmVcblx0ICogIHNvIFVwZGF0ZUFjdGlvbnMsIFVwZGF0ZUZlZWRiYWNrcyBldGMuIGRvbid0IGVhY2ggY2FsbCByZXNvbHZlTW9kZWwgaW5kZXBlbmRlbnRseS4gKi9cblx0YWN0aXZlTW9kZWw6IHN0cmluZyA9ICcnXG5cblx0Y29uc3RydWN0b3IoaW50ZXJuYWw6IHVua25vd24pIHtcblx0XHRzdXBlcihpbnRlcm5hbClcblx0fVxuXG5cdGFzeW5jIGluaXQoY29uZmlnOiBNb2R1bGVDb25maWcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZ1xuXHRcdGlmICghdGhpcy5zdENvbnRyb2xsZXIpIHtcblx0XHRcdHRoaXMuc3RDb250cm9sbGVyID0gbmV3IFN0Q29udHJvbGxlcigpXG5cdFx0fVxuXHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLkNvbm5lY3RpbmcsICdEaXNjb3ZlcmluZyBkZXZpY2VzLi4uJylcblxuXHRcdC8vIFdpcmUgZmVlZGJhY2sgY2FsbGJhY2sgc28gc3RDb250cm9sbGVyIGNhbiB0cmlnZ2VyIGZlZWRiYWNrIHVwZGF0ZXNcblx0XHR0aGlzLnN0Q29udHJvbGxlci5zZXRGZWVkYmFja0NhbGxiYWNrKChmZWVkYmFja0lkOiBzdHJpbmcpID0+IHtcblx0XHRcdHRoaXMuY2hlY2tGZWVkYmFja3MoZmVlZGJhY2tJZClcblx0XHR9KVxuXG5cdFx0Ly8gU3RhcnQgZGlzY292ZXJ5IGluIHRoZSBiYWNrZ3JvdW5kIFx1MjAxNCBhbGwgbW9kZWwgcmVzb2x1dGlvbiwgc2NoZW1hIHN5bmMsXG5cdFx0Ly8gYW5kIFVJIHVwZGF0ZXMgaGFwcGVuIGluc2lkZSBydW5EaXNjb3ZlcnkoKSBvbmNlIHRoZSBkZXZpY2UgbGlzdCBpcyBrbm93bi5cblx0XHR0aGlzLnJ1bkRpc2NvdmVyeSgpLmNhdGNoKChlKSA9PiB7XG5cdFx0XHRsb2dnZXIuZXJyb3IoYERpc2NvdmVyeSBmYWlsZWQ6ICR7ZX1gKVxuXHRcdH0pXG5cdH1cblxuXHQvKipcblx0ICogUnVuIGRldmljZSBkaXNjb3ZlcnksIHRoZW4gcmVzb2x2ZSB0aGUgbW9kZWwgYW5kIHVwZGF0ZSBhbGwgVUkuXG5cdCAqIC0gSWYgZGlzY292ZXJ5IGZpbmRzIGRldmljZXMsIHJlc29sdmVNb2RlbCBwaWNrcyBmcm9tIHRob3NlLlxuXHQgKiAtIE9ubHkgaWYgdGhlIGxpc3QgaXMgZW1wdHkgZG8gd2UgZmFsbCBiYWNrIHRvIHRoZSBtYW51YWwgY29uZmlnIHNlbGVjdGlvbi5cblx0ICogQWxsIGFjdGlvbnMvZmVlZGJhY2tzL3ZhcmlhYmxlcyBhcmUgYnVpbHQgYWZ0ZXIgdGhlIG1vZGVsIGlzIGtub3duLlxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyBydW5EaXNjb3ZlcnkoKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0bG9nZ2VyLmluZm8oJ1N0YXJ0aW5nIGRldmljZSBkaXNjb3ZlcnkuLi4nKVxuXG5cdFx0dGhpcy5kaXNjb3ZlcmVkRGV2aWNlcyA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLmRpc2NvdmVyRGV2aWNlcygpXG5cblx0XHQvLyBEZXRlcm1pbmUgZWZmZWN0aXZlIG1vZGVsIFx1MjAxNCBmcm9tIGRpc2NvdmVyZWQgZGV2aWNlcyBmaXJzdCwgbWFudWFsIGNvbmZpZyBvbmx5IGFzIGZhbGxiYWNrXG5cdFx0bGV0IGVmZmVjdGl2ZU1vZGVsOiBzdHJpbmdcblx0XHRpZiAodGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5sZW5ndGggPT09IDApIHtcblx0XHRcdC8vIElmIGEgc3BlY2lmaWMgZGV2aWNlIE1BQyB3YXMgc2F2ZWQgaW4gY29uZmlnLCBpdCB3YXNuJ3QgZm91bmQgXHUyMDE0IHN0b3AgaGVyZS5cblx0XHRcdGlmICh0aGlzLmNvbmZpZy5kZXZpY2VNYWMpIHtcblx0XHRcdFx0Y29uc3QgbW9kZWxMYWJlbCA9IHRoaXMuY29uZmlnLmFjdGl2ZU1vZGVsID8gYE1vZGVsICR7dGhpcy5jb25maWcuYWN0aXZlTW9kZWx9IGAgOiAnJ1xuXHRcdFx0XHRsb2dnZXIud2FybihgU2F2ZWQgZGV2aWNlIE1BQyBcIiR7dGhpcy5jb25maWcuZGV2aWNlTWFjfVwiIG5vdCBmb3VuZCBkdXJpbmcgZGlzY292ZXJ5IFx1MjAxNCBzdG9wcGluZ2ApXG5cdFx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLkNvbm5lY3Rpb25GYWlsdXJlLCBgJHttb2RlbExhYmVsfVske3RoaXMuY29uZmlnLmRldmljZU1hY31dIG5vdCBmb3VuZGApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdFx0Y29uc3QgbWFudWFsTW9kZWwgPSB0aGlzLmNvbmZpZy5hY3RpdmVNb2RlbFxuXHRcdFx0aWYgKCF0aGlzLmNvbmZpZy5ob3N0IHx8ICFtYW51YWxNb2RlbCkge1xuXHRcdFx0XHRsb2dnZXIud2FybignTm8gZGV2aWNlcyBkaXNjb3ZlcmVkIGFuZCBubyBtYW51YWwgSVAvbW9kZWwgY29uZmlndXJlZCcpXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdFx0bG9nZ2VyLmluZm8oJ05vIGRldmljZXMgZGlzY292ZXJlZCBcdTIwMTQgd2lsbCBwcm9iZSBtYW51YWwgSVAgZHVyaW5nIGF1dGhvcml6YXRpb24nKVxuXHRcdFx0ZWZmZWN0aXZlTW9kZWwgPSBtYW51YWxNb2RlbFxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgRGlzY292ZXJlZCAke3RoaXMuZGlzY292ZXJlZERldmljZXMubGVuZ3RofSBkZXZpY2Uocyk6YClcblx0XHRcdGZvciAoY29uc3QgZCBvZiB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKSB7XG5cdFx0XHRcdGxvZ2dlci5pbmZvKGAgIC0gTW9kZWwgJHtkLm1vZGVsfSAke2QubWFudWZhY3R1cmVyID8/ICcnfSBAICR7ZC5pcH1gKVxuXHRcdFx0fVxuXG5cdFx0XHQvLyBBdXRob3JpemUgYWxsIGRpc2NvdmVyZWQgZGV2aWNlcyBzbyBmaXJtd2FyZSByZXF1ZXN0cyBjYW4gcHJvY2VlZC5cblx0XHRcdC8vIHZlcmlmeUF1dGhvcml6YXRpb24gKGNhbGxlZCBiZWxvdykgd2lsbCByZXZva2UgYW55IHRoYXQgZG9uJ3QgbWF0Y2hcblx0XHRcdC8vIHRoZSBjdXJyZW50IGNvbmZpZyBzZWxlY3Rpb24uXG5cdFx0XHRmb3IgKGNvbnN0IGRldmljZSBvZiB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKSB7XG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShkZXZpY2UuaXApXG5cdFx0XHR9XG5cblx0XHRcdC8vIFJlcXVlc3QgZmlybXdhcmUgdmVyc2lvbiBmcm9tIGVhY2ggZGlzY292ZXJlZCBkZXZpY2Vcblx0XHRcdGZvciAoY29uc3QgZGV2aWNlIG9mIHRoaXMuZGlzY292ZXJlZERldmljZXMpIHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRjb25zdCBmaXJtd2FyZSA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnJlcXVlc3RGaXJtd2FyZVZlcnNpb24oZGV2aWNlLmlwKVxuXHRcdFx0XHRcdGRldmljZS5maXJtd2FyZU1haW4gPSBmaXJtd2FyZVxuXHRcdFx0XHRcdGxvZ2dlci5pbmZvKGAgIC0gJHtkZXZpY2UuaXB9OiBGaXJtd2FyZSAke2Zpcm13YXJlfSwgRGFudGUgJHtkZXZpY2UuZGFudGVGaXJtd2FyZX1gKVxuXHRcdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0bG9nZ2VyLndhcm4oYCAgLSAke2RldmljZS5pcH06IEZhaWxlZCB0byBnZXQgZmlybXdhcmU6ICR7ZX1gKVxuXHRcdFx0XHRcdGRldmljZS5maXJtd2FyZU1haW4gPSAnVW5rbm93bidcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHRlZmZlY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbCh0aGlzLmNvbmZpZywgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblxuXHRcdFx0Ly8gSWYgYSBzcGVjaWZpYyBNQUMgd2FzIHNhdmVkIGJ1dCBpc24ndCBpbiB0aGUgZGlzY292ZXJlZCBsaXN0LCBzdG9wLlxuXHRcdFx0aWYgKCFlZmZlY3RpdmVNb2RlbCAmJiB0aGlzLmNvbmZpZy5kZXZpY2VNYWMpIHtcblx0XHRcdFx0Y29uc3QgbW9kZWxMYWJlbCA9IHRoaXMuY29uZmlnLmFjdGl2ZU1vZGVsID8gYE1vZGVsICR7dGhpcy5jb25maWcuYWN0aXZlTW9kZWx9IGAgOiAnJ1xuXHRcdFx0XHRsb2dnZXIud2FybihgU2F2ZWQgZGV2aWNlIE1BQyBcIiR7dGhpcy5jb25maWcuZGV2aWNlTWFjfVwiIG5vdCBmb3VuZCBhbW9uZyBkaXNjb3ZlcmVkIGRldmljZXMgXHUyMDE0IHN0b3BwaW5nYClcblx0XHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuQ29ubmVjdGlvbkZhaWx1cmUsIGAke21vZGVsTGFiZWx9WyR7dGhpcy5jb25maWcuZGV2aWNlTWFjfV0gbm90IGZvdW5kYClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gU3luYyBtb2RlbCBzY2hlbWEgdG8gY29udHJvbGxlclxuXHRcdHRoaXMuc3luY01vZGVsKGVmZmVjdGl2ZU1vZGVsKVxuXG5cdFx0Ly8gVmVyaWZ5IHRoYXQgdGhlIGN1cnJlbnRseSBjb25maWd1cmVkIGhvc3QrbW9kZWwgaXMgdmFsaWQgbm93IHRoYXRcblx0XHQvLyBkaXNjb3ZlcnkgcmVzdWx0cyBhcmUga25vd24uIFRoaXMgaXMgdGhlIHNhbWUgY2hlY2sgY29uZmlnVXBkYXRlZCB1c2VzLlxuXHRcdGNvbnN0IHRhcmdldEhvc3QgPSB0aGlzLmhvc3Rcblx0XHRhd2FpdCB0aGlzLnZlcmlmeUF1dGhvcml6YXRpb24oJycsIHRhcmdldEhvc3QpXG5cblx0XHQvLyBCdWlsZCBhbGwgVUkgbm93IHRoYXQgbW9kZWwgYW5kIGF1dGhvcml6YXRpb24gc3RhdGUgYXJlIGtub3duXG5cdFx0dGhpcy51cGRhdGVBY3Rpb25zKClcblx0XHR0aGlzLnVwZGF0ZUZlZWRiYWNrcygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlVmFsdWVzKClcblxuXHRcdGxvZ2dlci5pbmZvKCdEZXZpY2UgZGlzY292ZXJ5IGNvbXBsZXRlJylcblx0fVxuXG5cdC8vIFdoZW4gbW9kdWxlIGdldHMgZGVsZXRlZFxuXHRhc3luYyBkZXN0cm95KCk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRoaXMuc3RDb250cm9sbGVyPy5jbG9zZSgpXG5cdFx0bG9nZ2VyLmRlYnVnKCdkZXN0cm95Jylcblx0fVxuXG5cdGFzeW5jIGNvbmZpZ1VwZGF0ZWQoY29uZmlnOiBNb2R1bGVDb25maWcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHRjb25zdCBwcmV2aW91c0hvc3QgPSB0aGlzLmhvc3Rcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZ1xuXHRcdGNvbnN0IGVmZmVjdGl2ZU1vZGVsID0gcmVzb2x2ZU1vZGVsKGNvbmZpZywgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcylcblx0XHR0aGlzLnN5bmNNb2RlbChlZmZlY3RpdmVNb2RlbClcblxuXHRcdC8vIENsZWFyIHZhcmlhYmxlcyBpbW1lZGlhdGVseSBcdTIwMTQgdGhlIG5ldyBzZWxlY3Rpb24gaXNuJ3QgYXV0aG9yaXplZCB5ZXQuXG5cdFx0Ly8gVGhleSdsbCBiZSByZXBvcHVsYXRlZCBiZWxvdyBvbmNlIHZlcmlmeUF1dGhvcml6YXRpb24gY29tcGxldGVzLlxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVWYWx1ZXMoKVxuXG5cdFx0Y29uc3QgbmV3SG9zdCA9IHRoaXMuaG9zdFxuXG5cdFx0Ly8gUmUtdmVyaWZ5IGF1dGhvcml6YXRpb24gb24gZXZlcnkgY29uZmlnIGNoYW5nZSAobW9kZWwgb3IgSVApLlxuXHRcdC8vIFRoaXMgaGFuZGxlcyBzd2l0Y2hpbmcgZnJvbSBhIHZhbGlkIGRldmljZSB0byBhbiBpbnZhbGlkIG9uZSBhbmQgYmFjay5cblx0XHRhd2FpdCB0aGlzLnZlcmlmeUF1dGhvcml6YXRpb24ocHJldmlvdXNIb3N0LCBuZXdIb3N0KVxuXG5cdFx0Ly8gUmVidWlsZCBVSSBhZnRlciBhdXRob3JpemF0aW9uIHN0YXRlIGlzIHNldHRsZWRcblx0XHR0aGlzLnVwZGF0ZUFjdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlRmVlZGJhY2tzKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVWYWx1ZXMoKVxuXHR9XG5cblx0LyoqXG5cdCAqIFJlLWV2YWx1YXRlcyB3aGV0aGVyIHRoZSBjdXJyZW50IGNvbmZpZyBpcyBhdXRob3JpemVkIHRvIHNlbmQgY29tbWFuZHMuXG5cdCAqXG5cdCAqIEF1dG8gbW9kZSAoZGV2aWNlTWFjIHNldCk6XG5cdCAqICAgLSBGaW5kIHRoZSBkaXNjb3ZlcmVkIGRldmljZSB3aXRoIG1hdGNoaW5nIE1BQyBcdTIxOTIgZ2V0IGl0cyBjdXJyZW50IElQXG5cdCAqICAgLSBSZXZva2UgdGhlIHByZXZpb3VzIElQLCBhdXRob3JpemUgdGhlIG5ldyBJUFxuXHQgKiAgIC0gSWYgTUFDIG5vdCBmb3VuZCBpbiBkaXNjb3ZlcnksIHJldm9rZSBhbmQgYmxvY2tcblx0ICpcblx0ICogTWFudWFsIG1vZGUgKGRldmljZU1hYyBlbXB0eSk6XG5cdCAqICAgLSBDaGVjayBkaXNjb3ZlcmVkIGxpc3QgYnkgSVArbW9kZWwgbWF0Y2gsIG9yIHByb2JlIGRpcmVjdGx5XG5cdCAqL1xuXHRwcml2YXRlIGFzeW5jIHZlcmlmeUF1dGhvcml6YXRpb24ocHJldmlvdXNIb3N0OiBzdHJpbmcsIG5ld0hvc3Q6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdGlmICghbmV3SG9zdCkge1xuXHRcdFx0aWYgKHByZXZpb3VzSG9zdCkgdGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNvbmZpZy5kZXZpY2VNYWMpIHtcblx0XHRcdC8vIEF1dG8gbW9kZSBcdTIwMTQgbWF0Y2ggYnkgTUFDLCB1c2Ugd2hhdGV2ZXIgSVAgZGlzY292ZXJ5IGZvdW5kIGl0IGF0XG5cdFx0XHRjb25zdCBkZXZpY2UgPSB0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmZpbmQoKGQpID0+IGQubWFjID09PSB0aGlzLmNvbmZpZy5kZXZpY2VNYWMpXG5cdFx0XHRpZiAoIWRldmljZSkge1xuXHRcdFx0XHRsb2dnZXIud2FybihgRGV2aWNlIE1BQyBcIiR7dGhpcy5jb25maWcuZGV2aWNlTWFjfVwiIG5vdCBmb3VuZCBpbiBjdXJyZW50IGRpc2NvdmVyeSBcdTIwMTQgbm90IGF1dGhvcml6aW5nYClcblx0XHRcdFx0aWYgKHByZXZpb3VzSG9zdCkgdGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cblx0XHRcdGlmIChwcmV2aW91c0hvc3QgJiYgcHJldmlvdXNIb3N0ICE9PSBuZXdIb3N0KSB7XG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHR9XG5cdFx0XHRjb25zdCB3YXNBdXRob3JpemVkID0gdGhpcy5zdENvbnRyb2xsZXIuaXNEZXZpY2VBdXRob3JpemVkKG5ld0hvc3QpXG5cdFx0XHRpZiAoIXdhc0F1dGhvcml6ZWQpIHtcblx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuYXV0aG9yaXplRGV2aWNlKG5ld0hvc3QpXG5cdFx0XHR9XG5cdFx0XHRpZiAobmV3SG9zdCAhPT0gcHJldmlvdXNIb3N0IHx8ICF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdGF3YWl0IHRoaXMuZmV0Y2hTZXR0aW5nc0FuZEVuc3VyZVNjaGVtYShkZXZpY2UubW9kZWwsIG5ld0hvc3QpXG5cdFx0XHR9XG5cdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5PaywgYE1vZGVsICR7ZGV2aWNlLm1vZGVsfSBAICR7bmV3SG9zdH1gKVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Ly8gTWFudWFsIG1vZGUgXHUyMDE0IGNvbmZpZy5ob3N0ICsgY29uZmlnLmFjdGl2ZU1vZGVsIG11c3QgbWF0Y2hcblx0XHRjb25zdCBtYW51YWxNb2RlbCA9IFN0cmluZyh0aGlzLmNvbmZpZy5hY3RpdmVNb2RlbCA/PyAnJylcblx0XHRjb25zdCBkaXNjb3ZlcmVkQXRJcCA9IHRoaXMuZGlzY292ZXJlZERldmljZXMuZmluZCgoZCkgPT4gZC5pcCA9PT0gbmV3SG9zdClcblxuXHRcdGlmIChkaXNjb3ZlcmVkQXRJcCkge1xuXHRcdFx0aWYgKGRpc2NvdmVyZWRBdElwLm1vZGVsID09PSBtYW51YWxNb2RlbCkge1xuXHRcdFx0XHRpZiAocHJldmlvdXNIb3N0ICYmIHByZXZpb3VzSG9zdCAhPT0gbmV3SG9zdCkgdGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHRcdFx0Y29uc3Qgd2FzQXV0aG9yaXplZCA9IHRoaXMuc3RDb250cm9sbGVyLmlzRGV2aWNlQXV0aG9yaXplZChuZXdIb3N0KVxuXHRcdFx0XHRpZiAoIXdhc0F1dGhvcml6ZWQpIHtcblx0XHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5hdXRob3JpemVEZXZpY2UobmV3SG9zdClcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAobmV3SG9zdCAhPT0gcHJldmlvdXNIb3N0IHx8ICF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdFx0YXdhaXQgdGhpcy5mZXRjaFNldHRpbmdzQW5kRW5zdXJlU2NoZW1hKG1hbnVhbE1vZGVsLCBuZXdIb3N0KVxuXHRcdFx0XHR9XG5cdFx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLk9rLCBgTW9kZWwgJHttYW51YWxNb2RlbH0gQCAke25ld0hvc3R9YClcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGxvZ2dlci5lcnJvcihcblx0XHRcdFx0XHRgRGV2aWNlIHNlbGVjdGVkIChNb2RlbCAke21hbnVhbE1vZGVsfSkgZG9lcyBub3QgbWF0Y2ggZGV0ZWN0ZWQgZGV2aWNlIChNb2RlbCAke2Rpc2NvdmVyZWRBdElwLm1vZGVsfSkgYXQgJHtuZXdIb3N0fSBcdTIwMTQgY29tbWFuZHMgYmxvY2tlZGAsXG5cdFx0XHRcdClcblx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKG5ld0hvc3QpXG5cdFx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKFxuXHRcdFx0XHRcdEluc3RhbmNlU3RhdHVzLkNvbm5lY3Rpb25GYWlsdXJlLFxuXHRcdFx0XHRcdGBNb2RlbCBtaXNtYXRjaDogZXhwZWN0ZWQgJHttYW51YWxNb2RlbH0sIGdvdCAke2Rpc2NvdmVyZWRBdElwLm1vZGVsfWAsXG5cdFx0XHRcdClcblx0XHRcdH1cblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdC8vIElQIG5vdCBpbiBkaXNjb3ZlcmVkIGxpc3QgXHUyMDE0IHByb2JlIGl0IGRpcmVjdGx5IHZpYSBEYW50ZVxuXHRcdGxvZ2dlci5pbmZvKGAke25ld0hvc3R9IG5vdCBpbiBkaXNjb3ZlcmVkIGxpc3QgXHUyMDE0IHByb2JpbmdgKVxuXHRcdGlmIChwcmV2aW91c0hvc3QgJiYgcHJldmlvdXNIb3N0ICE9PSBuZXdIb3N0KSB0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShuZXdIb3N0KVxuXG5cdFx0Y29uc3QgcHJvYmVkID0gYXdhaXQgdGhpcy5zdENvbnRyb2xsZXIucHJvYmVEZXZpY2UobmV3SG9zdClcblx0XHRpZiAoIXByb2JlZCkge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBObyBkZXZpY2UgcmVzcG9uZGVkIGF0ICR7bmV3SG9zdH0gXHUyMDE0IGNvbW1hbmRzIGJsb2NrZWRgKVxuXHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuVW5rbm93bldhcm5pbmcsIGBEZXZpY2Ugb2ZmbGluZTogJHtuZXdIb3N0fWApXG5cdFx0fSBlbHNlIGlmIChwcm9iZWQubW9kZWwgIT09IG1hbnVhbE1vZGVsKSB7XG5cdFx0XHRsb2dnZXIuZXJyb3IoXG5cdFx0XHRcdGBEZXZpY2Ugc2VsZWN0ZWQgKE1vZGVsICR7bWFudWFsTW9kZWx9KSBkb2VzIG5vdCBtYXRjaCBkZXRlY3RlZCBkZXZpY2UgKE1vZGVsICR7cHJvYmVkLm1vZGVsfSkgYXQgJHtuZXdIb3N0fSBcdTIwMTQgY29tbWFuZHMgYmxvY2tlZGAsXG5cdFx0XHQpXG5cdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhcblx0XHRcdFx0SW5zdGFuY2VTdGF0dXMuQ29ubmVjdGlvbkZhaWx1cmUsXG5cdFx0XHRcdGBNb2RlbCBtaXNtYXRjaDogZXhwZWN0ZWQgJHttYW51YWxNb2RlbH0sIGdvdCAke3Byb2JlZC5tb2RlbH1gLFxuXHRcdFx0KVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuaW5mbyhgVmVyaWZpZWQgTW9kZWwgJHtwcm9iZWQubW9kZWx9IGF0ICR7bmV3SG9zdH1gKVxuXHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuYXV0aG9yaXplRGV2aWNlKG5ld0hvc3QpXG5cdFx0XHRhd2FpdCB0aGlzLmZldGNoU2V0dGluZ3NBbmRFbnN1cmVTY2hlbWEobWFudWFsTW9kZWwsIG5ld0hvc3QpXG5cdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5PaywgYE1vZGVsICR7cHJvYmVkLm1vZGVsfSBAICR7bmV3SG9zdH1gKVxuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBGZXRjaGVzIGFsbCBzZXR0aW5ncyBmcm9tIHRoZSBkZXZpY2UuIElmIG5vIHNjaGVtYSBleGlzdHMgZm9yIHRoZSBtb2RlbCxcblx0ICogY3JlYXRlcyBvbmUgZnJvbSB0aGUgcmVzcG9uc2UgYW5kIHJlbG9hZHMgdGhlIHNjaGVtYSBjYWNoZS5cblx0ICovXG5cdHByaXZhdGUgYXN5bmMgZmV0Y2hTZXR0aW5nc0FuZEVuc3VyZVNjaGVtYShtb2RlbDogc3RyaW5nLCBpcDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dHJ5IHtcblx0XHRcdGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhpcClcblxuXHRcdFx0aWYgKCFnZXREZXZpY2VTY2hlbWEobW9kZWwpKSB7XG5cdFx0XHRcdC8vIE5vIHNjaGVtYSBleGlzdHMgXHUyMDE0IGRvIE5PVCBhdXRvLWNyZWF0ZSBvbmUgaGVyZS5cblx0XHRcdFx0Ly8gVGhlIHVzZXIgbXVzdCBydW4gXCJHTE9CQUw6IEdldCBBbGwgU2V0dGluZ3NcIiB0byBjcmVhdGUgaXQuXG5cdFx0XHRcdGxvZ2dlci53YXJuKGBObyBzY2hlbWEgZm91bmQgZm9yIE1vZGVsICR7bW9kZWx9IFx1MjAxNCBydW4gXCJHTE9CQUw6IEdldCBBbGwgU2V0dGluZ3NcIiB0byBjcmVhdGUgb25lYClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYEZhaWxlZCB0byBmZXRjaCBzZXR0aW5ncyBmcm9tICR7aXB9OiAke2V9YClcblx0XHR9XG5cdH1cblxuXHQvKiogTG9hZHMgdGhlIGRldmljZSBKU09OIGZvciB0aGUgZ2l2ZW4gbW9kZWwsIGNhY2hlcyBpdCBhcyBhY3RpdmVNb2RlbCwgYW5kIHB1c2hlcyBpdCB0byB0aGUgY29udHJvbGxlci4gKi9cblx0cHJpdmF0ZSBzeW5jTW9kZWwobW9kZWw6IHN0cmluZyk6IHZvaWQge1xuXHRcdHRoaXMuYWN0aXZlTW9kZWwgPSBtb2RlbFxuXHRcdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYShtb2RlbClcblx0XHRpZiAoIXNjaGVtYSkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYE1vZGVsIFwiJHttb2RlbH1cIiBub3QgZm91bmQgaW4gZGV2aWNlIHNjaGVtYXNgKVxuXHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuc2V0TW9kZWwobW9kZWwsIFtdKVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Y29uc3QgYWN0aW9ucyA9IEFycmF5LmlzQXJyYXkoc2NoZW1hLmNtZFNjaGVtYSkgPyBzY2hlbWEuY21kU2NoZW1hIDogW11cblxuXHRcdHRoaXMuc3RDb250cm9sbGVyLnNldE1vZGVsKG1vZGVsLCBhY3Rpb25zKVxuXHRcdGlmIChhY3Rpb25zLmxlbmd0aCA9PT0gMCkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYE5vIGFjdGlvbnMgZm91bmQgZm9yIG1vZGVsIFwiJHttb2RlbH1cIiBcdTIwMTQgc2V0dGluZ3MgZGVjb2Rpbmcgd2lsbCB1c2UgcmF3IElEc2ApXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgTG9hZGVkICR7YWN0aW9ucy5sZW5ndGh9IGFjdGlvbnMgZm9yIG1vZGVsIFwiJHttb2RlbH1cIiwgc2VjdGlvbmVkPSR7c2NoZW1hLnNlY3Rpb25lZH1gKVxuXHRcdH1cblx0fVxuXG5cdGdldENvbmZpZ0ZpZWxkcygpOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdFx0cmV0dXJuIEdldENvbmZpZ0ZpZWxkcyh0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHR9XG5cblx0LyoqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBob3N0IElQLCByZXNvbHZlZCBmcm9tIE1BQ1x1MjE5MklQIHZpYSBkaXNjb3ZlcmVkRGV2aWNlcyAoYXV0bykgb3IgY29uZmlnLmhvc3QgKG1hbnVhbCkuICovXG5cdGdldCBob3N0KCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIHJlc29sdmVIb3N0KHRoaXMuY29uZmlnLCB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHR9XG5cblx0LyoqIFJldHVybnMgZGlzY292ZXJlZCBkZXZpY2VzIGZvciB1c2UgaW4gYWN0aW9ucy9jb25maWcgKi9cblx0Z2V0IGRldmljZXMoKTogRGV2aWNlSW5mb1tdIHtcblx0XHRyZXR1cm4gdGhpcy5kaXNjb3ZlcmVkRGV2aWNlc1xuXHR9XG5cblx0dXBkYXRlQWN0aW9ucygpOiB2b2lkIHtcblx0XHRVcGRhdGVBY3Rpb25zKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVGZWVkYmFja3MoKTogdm9pZCB7XG5cdFx0VXBkYXRlRmVlZGJhY2tzKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKCk6IHZvaWQge1xuXHRcdFVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnModGhpcylcblx0fVxuXG5cdHVwZGF0ZVZhcmlhYmxlVmFsdWVzKCk6IHZvaWQge1xuXHRcdFVwZGF0ZVZhcmlhYmxlVmFsdWVzKHRoaXMpXG5cdH1cbn1cblxuZXhwb3J0IHsgVXBncmFkZVNjcmlwdHMgfVxuIl0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7QUFrQkEsSUFBTSxxQkFBa0MsQ0FBQyxRQUFRLE9BQU8sWUFBVztBQUVsRSxVQUFRLElBQUksSUFBSSxNQUFNLFlBQVcsQ0FBRSxJQUFJLFNBQVMsS0FBSyxNQUFNLE1BQU0sRUFBRSxJQUFJLE9BQU8sRUFBRTtBQUNqRjtBQUVBLFNBQVMsVUFBVSxRQUE0QixPQUFpQixTQUFlO0FBQzlFLFFBQU0sT0FBTyxPQUFPLE9BQU8scUJBQXFCLGFBQWEsT0FBTyxtQkFBbUI7QUFDdkYsT0FBSyxRQUFRLE9BQU8sT0FBTztBQUM1QjtBQU9NLFNBQVUsbUJBQW1CLFFBQWU7QUFDakQsU0FBTztJQUNOLE9BQU8sQ0FBQyxZQUFvQixVQUFVLFFBQVEsU0FBUyxPQUFPO0lBQzlELE1BQU0sQ0FBQyxZQUFvQixVQUFVLFFBQVEsUUFBUSxPQUFPO0lBQzVELE1BQU0sQ0FBQyxZQUFvQixVQUFVLFFBQVEsUUFBUSxPQUFPO0lBQzVELE9BQU8sQ0FBQyxZQUFvQixVQUFVLFFBQVEsU0FBUyxPQUFPOztBQUVoRTs7O0FDVE0sU0FBVSxZQUFZLE1BQVc7QUFFdkM7QUF5Qk0sU0FBVSxXQUFXLEdBQVcsR0FBVyxHQUFXLEdBQVU7QUFDckUsTUFBSSxlQUF3QixJQUFJLFFBQVMsTUFBUSxJQUFJLFFBQVMsSUFBTSxJQUFJO0FBQ3hFLE1BQUksS0FBSyxLQUFLLEtBQUssSUFBSSxHQUFHO0FBQ3pCLG1CQUFlLFdBQVksS0FBSyxNQUFNLE9BQU8sSUFBSSxFQUFFO0VBQ3BEO0FBQ0EsU0FBTztBQUNSOzs7QUMvREEsU0FBUyxvQkFBb0I7QUEyRXZCLElBQU8sc0JBQVAsY0FBbUMsYUFBbUM7RUFDbEU7RUFDQTtFQUVULElBQVcsV0FBUTtBQUNsQixXQUFPLEtBQUssWUFBWTtFQUN6QjtFQUNBLElBQVcsYUFBVTtBQUNwQixXQUFPLEtBQUssWUFBWTtFQUN6QjtFQUVBLElBQVksYUFBVTtBQUNyQixRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVyxVQUFVO0FBQ25ELGFBQU8sS0FBSztJQUNiLE9BQU87QUFDTixhQUFPO0lBQ1I7RUFDRDtFQUVBLFNBQXVFO0VBRXZFLFlBQVksU0FBeUMsU0FBK0I7QUFDbkYsVUFBSztBQUVMLFNBQUssV0FBVztBQUNoQixTQUFLLFdBQVcsRUFBRSxHQUFHLFFBQU87RUFDN0I7RUFFQSxLQUFLLE1BQWMsVUFBbUIsVUFBcUI7QUFDMUQsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVc7QUFBVSxZQUFNLElBQUksTUFBTSx5QkFBeUI7QUFDN0YsWUFBUSxLQUFLLFFBQVE7TUFDcEIsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLG9DQUFvQztNQUNyRCxLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0seUJBQXlCO01BQzFDLEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSxtQkFBbUI7TUFDcEMsS0FBSztBQUNKO01BQ0Q7QUFDQyxvQkFBWSxLQUFLLE1BQU07QUFDdkIsY0FBTSxJQUFJLE1BQU0sc0JBQXNCO0lBQ3hDO0FBRUEsU0FBSyxTQUFTO0FBRWQsUUFBSTtBQUFVLFdBQUssR0FBRyxhQUFhLFFBQVE7QUFFM0MsU0FBSyxTQUNILG9CQUFvQjtNQUNwQixRQUFRLEtBQUssU0FBUztNQUN0QixZQUFZOztLQUVaLEVBQ0EsS0FDQSxDQUFDLGFBQVk7QUFDWixXQUFLLFNBQVMsRUFBRSxZQUFZLE1BQU0sU0FBUTtBQUMxQyxXQUFLLFNBQVMsd0JBQXdCLElBQUksVUFBVSxJQUFJO0FBQ3hELFdBQUssS0FBSyxXQUFXO0lBQ3RCLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxTQUFTO0FBQ2QsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFFQSxNQUFNLFVBQXFCO0FBQzFCLFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXLFVBQVU7SUFFcEQsT0FBTztBQUNOLGNBQVEsS0FBSyxRQUFRO1FBQ3BCLEtBQUs7QUFDSixnQkFBTSxJQUFJLE1BQU0sb0NBQW9DO1FBQ3JELEtBQUs7UUFDTCxLQUFLO1FBQ0wsS0FBSztBQUNKLGdCQUFNLElBQUksTUFBTSxvQkFBb0I7UUFDckM7QUFDQyxzQkFBWSxLQUFLLE1BQU07QUFDdkIsZ0JBQU0sSUFBSSxNQUFNLHNCQUFzQjtNQUN4QztJQUNEO0FBRUEsVUFBTSxXQUFXLEtBQUssT0FBTztBQUM3QixTQUFLLFNBQVM7QUFFZCxRQUFJO0FBQVUsV0FBSyxHQUFHLFNBQVMsUUFBUTtBQUV2QyxTQUFLLFNBQ0gscUJBQXFCO01BQ3JCO0tBQ0EsRUFDQSxLQUNBLE1BQUs7QUFDSixXQUFLLFNBQVMsd0JBQXdCLE9BQU8sUUFBUTtBQUNyRCxXQUFLLEtBQUssT0FBTztJQUNsQixHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxRQUFRO0FBQ3JELFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBV0EsS0FDQyxjQUNBLGNBQ0EsaUJBQ0EsZ0JBQ0EsU0FDQSxVQUFxQjtBQUVyQixRQUFJLE9BQU8saUJBQWlCO0FBQVUsWUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ3pFLFFBQUksT0FBTyxvQkFBb0IsVUFBVTtBQUN4QyxVQUFJLE9BQU8sbUJBQW1CLFlBQVksT0FBTyxZQUFZO0FBQVUsY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQzFHLFVBQUksYUFBYSxVQUFhLE9BQU8sYUFBYTtBQUFZLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUVqRyxZQUFNLFNBQVMsS0FBSyxlQUFlLGNBQWMsY0FBYyxlQUFlO0FBQzlFLFdBQUssV0FBVyxRQUFRLGdCQUFnQixTQUFTLFFBQVE7SUFDMUQsV0FBVyxPQUFPLG9CQUFvQixVQUFVO0FBQy9DLFVBQUksbUJBQW1CLFVBQWEsT0FBTyxtQkFBbUI7QUFBWSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFFN0csWUFBTSxTQUFTLEtBQUssZUFBZSxjQUFjLEdBQUcsTUFBUztBQUM3RCxXQUFLLFdBQVcsUUFBUSxjQUFjLGlCQUFpQixjQUFjO0lBQ3RFLE9BQU87QUFDTixZQUFNLElBQUksTUFBTSxtQkFBbUI7SUFDcEM7RUFDRDtFQUVBLGVBQ0MsY0FDQSxRQUNBLFFBQTBCO0FBRTFCLFFBQUk7QUFDSixRQUFJLE9BQU8saUJBQWlCLFVBQVU7QUFDckMsZUFBUyxPQUFPLEtBQUssY0FBYyxPQUFPO0lBQzNDLFdBQVcsT0FBTyxTQUFTLFlBQVksR0FBRztBQUN6QyxlQUFTO0lBQ1YsV0FBVyxNQUFNLFFBQVEsWUFBWSxHQUFHO0FBRXZDLGFBQU8sT0FBTyxLQUFLLFlBQVk7SUFDaEMsT0FBTztBQUNOLGVBQVMsT0FBTyxLQUFLLGFBQWEsUUFBUSxhQUFhLFlBQVksYUFBYSxVQUFVO0lBQzNGO0FBRUEsV0FBTyxPQUFPLFNBQVMsUUFBUSxXQUFXLFNBQVksU0FBUyxTQUFTLE1BQVM7RUFDbEY7RUFFQSxXQUFXLFFBQWdCLE1BQWMsU0FBaUIsVUFBcUI7QUFDOUUsUUFBSSxDQUFDLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVztBQUFVLFlBQU0sSUFBSSxNQUFNLG9CQUFvQjtBQUV6RixTQUFLLFNBQ0gsb0JBQW9CO01BQ3BCLFVBQVUsS0FBSyxPQUFPO01BQ3RCLFNBQVM7TUFFVDtNQUNBO0tBQ0EsRUFDQSxLQUNBLE1BQUs7QUFDSixpQkFBVTtJQUNYLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFFQSxxQkFBcUIsU0FBK0I7QUFDbkQsUUFBSTtBQUNILFdBQUssS0FBSyxXQUFXLFFBQVEsU0FBUyxRQUFRLE1BQU07SUFDckQsU0FBUyxJQUFJO0lBRWI7RUFDRDtFQUNBLG1CQUFtQixPQUFZO0FBQzlCLFNBQUssU0FBUztBQUVkLFVBQU0sYUFBYSxLQUFLO0FBQ3hCLFFBQUk7QUFBWSxXQUFLLFNBQVMsd0JBQXdCLE9BQU8sV0FBVyxRQUFRO0FBRWhGLFFBQUk7QUFDSCxXQUFLLEtBQUssU0FBUyxLQUFLO0lBQ3pCLFNBQVMsSUFBSTtJQUViO0VBQ0Q7Ozs7QUM5UEssU0FBVSxrQkFBbUQsS0FBWTtBQUM5RSxRQUFNLE9BQU87QUFDYixTQUFPLENBQUMsQ0FBQyxRQUFRLE9BQU8sU0FBUyxZQUFZLE9BQU8sS0FBSyxPQUFPLFlBQVksS0FBSyx1QkFBdUI7QUFDekc7OztBQzZCTSxJQUFnQixlQUFoQixNQUE0QjtFQUN4QjtFQUNBO0VBRUE7RUFFVCxJQUFXLEtBQUU7QUFDWixXQUFPLEtBQUssU0FBUztFQUN0QjtFQUVBLElBQVcsa0JBQWU7QUFDekIsV0FBTyxLQUFLO0VBQ2I7Ozs7O0VBTUEsSUFBVyxRQUFLO0FBQ2YsV0FBTyxLQUFLLFNBQVM7RUFDdEI7Ozs7RUFLQSxZQUFZLFVBQWlCO0FBQzVCLFFBQUksQ0FBQyxrQkFBNkIsUUFBUSxLQUFLLENBQUMsU0FBUztBQUN4RCxZQUFNLElBQUksTUFDVCxtR0FBbUc7QUFHckcsU0FBSyxXQUFXO0FBRWhCLFNBQUssVUFBVSxtQkFBa0I7QUFFakMsU0FBSyx3QkFBd0IsS0FBSyxzQkFBc0IsS0FBSyxJQUFJO0FBRWpFLFNBQUssV0FBVztNQUNmLDJCQUEyQjtNQUMzQix3QkFBd0I7O0FBR3pCLFNBQUssSUFBSSxTQUFTLGNBQWM7RUFDakM7RUErQkEsV0FBVyxXQUE0QyxZQUFpQztBQUN2RixTQUFLLFNBQVMsV0FBVyxXQUFXLFVBQVU7RUFDL0M7Ozs7O0VBdUJBLHFCQUFxQixTQUF5RDtBQUM3RSxTQUFLLFNBQVMscUJBQXFCLE9BQU87RUFDM0M7Ozs7O0VBTUEsdUJBQXVCLFdBQStEO0FBQ3JGLFNBQUssU0FBUyx1QkFBdUIsU0FBUztFQUMvQzs7Ozs7O0VBT0EscUJBQ0MsV0FDQSxTQUE4QztBQUU5QyxTQUFLLFNBQVMscUJBQXFCLFdBQVcsT0FBTztFQUN0RDs7Ozs7RUFNQSx1QkFBdUIsV0FBK0Q7QUFDckYsUUFBSSxNQUFNLFFBQVEsU0FBUztBQUFHLFlBQU0sSUFBSSxNQUFNLHdEQUF3RDtBQUV0RyxTQUFLLFNBQVMsdUJBQXVCLFNBQVM7RUFDL0M7Ozs7O0VBTUEsa0JBQWtCLFFBQXVDO0FBQ3hELFNBQUssU0FBUyxrQkFBa0IsTUFBTTtFQUN2Qzs7Ozs7O0VBT0EsaUJBQW1DLFlBQWE7QUFDL0MsV0FBTyxLQUFLLFNBQVMsaUJBQWlCLFVBQVU7RUFDakQ7Ozs7RUFLQSxvQkFBaUI7QUFDaEIsU0FBSyxTQUFTLGtCQUFpQjtFQUNoQzs7Ozs7OztFQVFBLGVBQ0MsaUJBQ0csZUFBbUQ7QUFFdEQsU0FBSyxTQUFTLGVBQWUsQ0FBQyxjQUFjLEdBQUcsYUFBYSxDQUFDO0VBQzlEOzs7OztFQU1BLHNCQUFzQixhQUFxQjtBQUMxQyxTQUFLLFNBQVMsbUJBQW1CLFdBQVc7RUFDN0M7Ozs7OztFQU9BLG9CQUFvQixXQUFtQjtBQUN0QyxTQUFLLFNBQVMsaUJBQWlCLFNBQVM7RUFDekM7Ozs7OztFQU1BLHNCQUFzQixXQUFtQjtBQUN4QyxTQUFLLFNBQVMsbUJBQW1CLFNBQVM7RUFDM0M7Ozs7OztFQU9BLHdCQUF3QixhQUFxQjtBQUM1QyxTQUFLLFNBQVMscUJBQXFCLFdBQVc7RUFDL0M7Ozs7OztFQU9BLGFBQWEsUUFBaUMsY0FBcUI7QUFDbEUsU0FBSyxTQUFTLGFBQWEsUUFBUSxZQUFZO0VBQ2hEOzs7Ozs7OztFQVNBLFFBQVEsTUFBYyxNQUFjQSxPQUFjLE1BQXNCO0FBQ3ZFLFNBQUssU0FBUyxRQUFRLE1BQU0sTUFBTUEsT0FBTSxJQUFJO0VBQzdDOzs7Ozs7Ozs7OztFQVlBLGFBQWEsUUFBd0IsU0FBdUI7QUFDM0QsU0FBSyxTQUFTLGFBQWEsUUFBUSxXQUFXLElBQUk7RUFDbkQ7Ozs7OztFQU9BLElBQUksT0FBaUIsU0FBZTtBQUNuQyxZQUFRLE9BQU87TUFDZCxLQUFLO0FBQ0osYUFBSyxRQUFRLE1BQU0sT0FBTztBQUMxQjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLE1BQU0sT0FBTztBQUMxQjtNQUNEO0FBQ0Msb0JBQVksS0FBSztBQUNqQixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO0lBQ0Y7RUFDRDtFQVlBLHNCQUNDLGVBQ0EsVUFBeUM7QUFFekMsVUFBTSxVQUFrQyxPQUFPLGtCQUFrQixXQUFXLEVBQUUsTUFBTSxjQUFhLElBQUs7QUFFdEcsVUFBTSxTQUFTLElBQUksb0JBQW9CLEtBQUssVUFBVSxPQUFPO0FBQzdELFFBQUk7QUFBVSxhQUFPLEdBQUcsV0FBVyxRQUFRO0FBRTNDLFdBQU87RUFDUjs7OztBQy9VRCxJQUFZO0NBQVosU0FBWUMsaUJBQWM7QUFDekIsRUFBQUEsZ0JBQUEsSUFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsWUFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsY0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsbUJBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLFdBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGNBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGdCQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSx1QkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEseUJBQUEsSUFBQTtBQUNELEdBVlksbUJBQUEsaUJBQWMsQ0FBQSxFQUFBO0FBYXBCLElBQVc7Q0FBakIsU0FBaUJDLFFBQUs7QUFFUixFQUFBQSxPQUFBLEtBQUs7QUFDTCxFQUFBQSxPQUFBLFdBQ1o7QUFDWSxFQUFBQSxPQUFBLFVBQVU7QUFDVixFQUFBQSxPQUFBLE9BQ1o7QUFDWSxFQUFBQSxPQUFBLGNBQWM7QUFDZCxFQUFBQSxPQUFBLFVBQVU7QUFDVixFQUFBQSxPQUFBLFFBQVE7QUFDUixFQUFBQSxPQUFBLGVBQWU7QUFDZixFQUFBQSxPQUFBLGVBQWU7QUFDZixFQUFBQSxPQUFBLFNBQVM7QUFDVCxFQUFBQSxPQUFBLGdCQUFnQjtBQUNoQixFQUFBQSxPQUFBLFlBQVk7QUFDWixFQUFBQSxPQUFBLFdBQ1o7QUFDRixHQWxCaUIsVUFBQSxRQUFLLENBQUEsRUFBQTs7O0FDakJ0QixPQUFPLFFBQVE7QUFDZixPQUFPLFVBQVU7QUFJakIsSUFBTSxTQUFTLG1CQUFtQixRQUFRO0FBeUIxQyxTQUFTLHVCQUFvQjtBQUM1QixRQUFNLGNBQWMsS0FBSyxLQUFLLFlBQVksU0FBUyxZQUFZO0FBQy9ELFFBQU0sZUFBZSxLQUFLLEtBQUssWUFBWSxTQUFTLFdBQVc7QUFHL0QsTUFBSSxHQUFHLFdBQVcsV0FBVyxHQUFHO0FBQy9CLFdBQU8sTUFBTSx5QkFBeUIsV0FBVyxFQUFFO0FBQ25ELFdBQU87RUFDUjtBQUdBLE1BQUksR0FBRyxXQUFXLFlBQVksR0FBRztBQUNoQyxXQUFPLEtBQUsscURBQXFELFlBQVksRUFBRTtBQUMvRSxXQUFPO0VBQ1I7QUFHQSxRQUFNLFdBQVc7O01BQTBDLFdBQVc7TUFBUyxZQUFZOztBQUMzRixTQUFPLE1BQU0sUUFBUTtBQUNyQixRQUFNLElBQUksTUFBTSxRQUFRO0FBQ3pCO0FBR0EsSUFBTSxnQkFBZ0IscUJBQW9CO0FBRzFDLElBQUkscUJBQWlEO0FBTS9DLFNBQVUsbUJBQWdCO0FBQy9CLFNBQU87QUFDUjtBQU1BLFNBQVMsb0JBQWlCO0FBQ3pCLFFBQU0sVUFBK0IsQ0FBQTtBQUNyQyxNQUFJO0FBQ0gsVUFBTSxRQUFRLEdBQUcsWUFBWSxhQUFhLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxTQUFTLE9BQU8sQ0FBQztBQUU3RSxlQUFXLEtBQUssT0FBTztBQUN0QixZQUFNLFdBQVcsS0FBSyxLQUFLLGVBQWUsQ0FBQztBQUMzQyxZQUFNLE9BQU8sS0FBSyxNQUFNLEdBQUcsYUFBYSxVQUFVLE1BQU0sQ0FBQztBQUN6RCxVQUFJLE1BQU0sT0FBTztBQUNoQixnQkFBUSxPQUFPLEtBQUssS0FBSyxDQUFDLElBQUk7TUFDL0I7SUFDRDtBQUVBLFdBQU8sTUFBTSxVQUFVLE9BQU8sS0FBSyxPQUFPLEVBQUUsTUFBTSw0QkFBNEI7RUFDL0UsU0FBUyxHQUFHO0FBQ1gsV0FBTyxNQUFNLGtDQUFrQyxDQUFDLEVBQUU7RUFDbkQ7QUFDQSxTQUFPO0FBQ1I7QUFNTSxTQUFVLG1CQUFnQjtBQUMvQixNQUFJLENBQUMsb0JBQW9CO0FBQ3hCLHlCQUFxQixrQkFBaUI7RUFDdkM7QUFDQSxTQUFPO0FBQ1I7QUFNTSxTQUFVLGdCQUFnQixPQUFhO0FBQzVDLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsU0FBTyxRQUFRLEtBQUs7QUFDckI7QUFNTSxTQUFVLHNCQUFtQjtBQUNsQyxTQUFPLEtBQUssdUNBQXVDO0FBQ25ELHVCQUFxQixrQkFBaUI7QUFDdkM7QUFLQSxTQUFTLHNCQUFtQjtBQUMzQixRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFNBQU8sT0FBTyxLQUFLLE9BQU8sRUFBRSxLQUFJO0FBQ2pDO0FBRU0sU0FBVSxnQkFBZ0Isb0JBQWtDLENBQUEsR0FBRTtBQUNuRSxRQUFNLFNBQVMsb0JBQW1CO0FBSWxDLFFBQU0sZ0JBQWdCO0lBQ3JCLEVBQUUsSUFBSSxJQUFJLE9BQU8sa0NBQWlDO0lBQ2xELEdBQUcsa0JBQWtCLElBQUksQ0FBQyxPQUFPO01BQ2hDLElBQUksRUFBRSxPQUFPO01BQ2IsT0FBTyxTQUFTLEVBQUUsS0FBSyxLQUFLLEVBQUUsR0FBRyxPQUFPLEVBQUUsRUFBRTtNQUMzQzs7QUFHSCxTQUFPOzs7SUFHTjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTO01BQ1QsU0FBUztNQUNULFNBQVM7OztJQUlWO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVM7TUFDVCxPQUFPLE1BQU07TUFDYixxQkFBcUI7TUFDckIsU0FBUzs7O0lBSVY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUyxPQUFPLENBQUMsS0FBSztNQUN0QixTQUFTLE9BQU8sSUFBSSxDQUFDLFdBQVc7UUFDL0IsSUFBSTtRQUNKLE9BQU8sU0FBUyxLQUFLO1FBQ3BCO01BQ0YscUJBQXFCO01BQ3JCLFNBQVM7OztJQUlWO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVM7TUFDVCxTQUFTOzs7QUFHWjtBQU9NLFNBQVUsWUFBWSxRQUFzQixtQkFBK0I7QUFDaEYsTUFBSSxPQUFPLFdBQVc7QUFDckIsVUFBTSxTQUFTLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsT0FBTyxTQUFTO0FBQ3ZFLFdBQU8sUUFBUSxNQUFNO0VBQ3RCO0FBQ0EsU0FBTyxPQUFPLE9BQU8sUUFBUSxFQUFFO0FBQ2hDO0FBT00sU0FBVSxhQUFhLFFBQXNCLG1CQUErQjtBQUNqRixNQUFJLE9BQU8sV0FBVztBQUNyQixVQUFNLFNBQVMsa0JBQWtCLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxPQUFPLFNBQVM7QUFDdkUsV0FBTyxNQUFNLDRCQUE0QixPQUFPLFNBQVMsb0JBQW9CLFFBQVEsU0FBUyxNQUFNLEVBQUU7QUFDdEcsV0FBTyxRQUFRLFNBQVM7RUFDekI7QUFDQSxTQUFPLE1BQU0sMkNBQTJDLE9BQU8sV0FBVyxHQUFHO0FBQzdFLFNBQU8sT0FBTyxPQUFPLGVBQWUsRUFBRTtBQUN2Qzs7O0FDcE5NLFNBQVUsMEJBQTBCLE1BQW9CO0FBQzdELE9BQUssdUJBQXVCO0lBQzNCLE9BQU8sRUFBRSxNQUFNLHNCQUFxQjtJQUNwQyxXQUFXLEVBQUUsTUFBTSx1Q0FBc0M7SUFDekQsY0FBYyxFQUFFLE1BQU0sc0JBQXFCO0lBQzNDLFVBQVUsRUFBRSxNQUFNLDBCQUF5QjtJQUMzQyxTQUFTLEVBQUUsTUFBTSxnQ0FBK0I7SUFDaEQsS0FBSyxFQUFFLE1BQU0scUJBQW9CO0lBQ2pDLElBQUksRUFBRSxNQUFNLG9CQUFtQjtHQUMvQjtBQUNGO0FBRUEsSUFBTSxvQkFBb0I7RUFDekIsT0FBTztFQUNQLFdBQVc7RUFDWCxjQUFjO0VBQ2QsVUFBVTtFQUNWLFNBQVM7RUFDVCxLQUFLO0VBQ0wsSUFBSTs7QUFRQyxTQUFVLHFCQUFxQixNQUFvQjtBQUN4RCxRQUFNLGNBQWMsS0FBSztBQUd6QixNQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssYUFBYSxtQkFBbUIsV0FBVyxHQUFHO0FBQ3ZFLFNBQUssa0JBQWtCLGlCQUFpQjtBQUN4QztFQUNEO0FBRUEsUUFBTSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sV0FBVztBQUM1RCxNQUFJLFFBQVE7QUFDWCxTQUFLLGtCQUFrQjtNQUN0QixPQUFPLE9BQU8sU0FBUztNQUN2QixXQUFXLE9BQU8sYUFBYTtNQUMvQixjQUFjLE9BQU8sZ0JBQWdCO01BQ3JDLFVBQVUsT0FBTyxnQkFBZ0I7TUFDakMsU0FBUyxPQUFPLGlCQUFpQjtNQUNqQyxLQUFLLE9BQU8sT0FBTztNQUNuQixJQUFJLE9BQU87S0FDWDtFQUNGLE9BQU87QUFHTixTQUFLLGtCQUFrQjtNQUN0QixHQUFHO01BQ0gsSUFBSTtLQUNKO0VBQ0Y7QUFDRDs7O0FDMURPLElBQU0saUJBQStEOzs7Ozs7Ozs7Ozs7Ozs7QUNTckUsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxjQUFjO0FBQ3BCLElBQU0sY0FBYztBQUNwQixJQUFNLGNBQWM7QUFDcEIsSUFBTSxnQkFBZ0I7QUFDdEIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxhQUFhO0FBQ25CLElBQU0sdUJBQXVCO0FBQzdCLElBQU0sb0JBQW9CO0FBQzFCLElBQU0sZUFBZTtBQUNyQixJQUFNLG1CQUFtQjtBQUN6QixJQUFNLHNCQUFzQjtBQUM1QixJQUFNLGtCQUFrQjtBQUN4QixJQUFNLGNBQWM7QUFHckIsU0FBVSxlQUFlLE9BQWE7QUFDM0MsVUFBUSxPQUFPO0lBQ2QsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSO0FBQ0MsYUFBTyxTQUFTLE1BQU0sU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztFQUNyRDtBQUNEO0FBUU0sU0FBVSxjQUNmLE9BQ0EsT0FDQSxXQUNBLE9BQXVCO0FBRXZCLFFBQU0sTUFBTSxPQUFPLFVBQVUsV0FBVyxNQUFNLFNBQVMsRUFBRSxJQUFJO0FBQzdELFFBQU0sS0FBSyxPQUFPLGNBQWMsV0FBVyxVQUFVLFNBQVMsRUFBRSxJQUFJO0FBRXBFLE1BQUksVUFBVSxRQUFXO0FBQ3hCLFVBQU0sS0FBSyxPQUFPLFVBQVUsV0FBVyxNQUFNLFNBQVMsRUFBRSxJQUFJO0FBQzVELFdBQU8sR0FBRyxLQUFLLElBQUksR0FBRyxJQUFJLEVBQUUsSUFBSSxFQUFFO0VBQ25DO0FBRUEsU0FBTyxHQUFHLEtBQUssSUFBSSxHQUFHLElBQUksRUFBRTtBQUM3QjtBQVNNLFNBQVUsTUFBTSxPQUFlLFlBQVksR0FBQztBQUNqRCxTQUFPLEtBQUssTUFBTSxTQUFTLEVBQUUsRUFBRSxTQUFTLFdBQVcsR0FBRyxDQUFDO0FBQ3hEO0FBT00sU0FBVSxXQUFXLE9BQXdCO0FBQ2xELFNBQU8sS0FBSyxNQUFNLEtBQUssS0FBSyxFQUMxQixJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFLENBQUM7QUFDWDtBQVNNLFNBQVUsZUFBZSxHQUFXLEdBQVcsR0FBUztBQUM3RCxTQUFPLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxFQUNqQixJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFLEVBQ1AsWUFBVyxDQUFFO0FBQ2hCO0FBUU0sU0FBVSxlQUFlLElBQVU7QUFDeEMsUUFBTSxDQUFDLE9BQU8sVUFBVSxLQUFLLElBQUksR0FBRyxNQUFNLEdBQUc7QUFDN0MsU0FBTztJQUNOO0lBQ0EsT0FBTyxTQUFTLFVBQVUsRUFBRTtJQUM1QixRQUFRLFNBQVMsT0FBTyxFQUFFOztBQUU1QjtBQVVNLFNBQVUsY0FBYyxRQUFnQixRQUFjO0FBQzNELFFBQU0sS0FBSyxTQUFTLE9BQU8sUUFBUSxPQUFPLEVBQUUsR0FBRyxFQUFFO0FBQ2pELFFBQU0sS0FBSyxTQUFTLE9BQU8sUUFBUSxPQUFPLEVBQUUsR0FBRyxFQUFFO0FBQ2pELE1BQUksT0FBTyxNQUFNLEVBQUUsS0FBSyxPQUFPLE1BQU0sRUFBRTtBQUFHLFdBQU87QUFDakQsU0FBTyxLQUFLLElBQUksS0FBSyxFQUFFO0FBQ3hCO0FBU00sU0FBVSxxQkFDZixZQUErQjtBQUUvQixRQUFNLGFBQWtFLENBQUE7QUFDeEUsYUFBVyxDQUFDLE9BQU8sSUFBSSxLQUFLLE9BQU8sUUFBUSxVQUFVLEdBQUc7QUFDdkQsZUFBVyxLQUFLLElBQUk7TUFDbkIsT0FBTyxLQUFLO01BQ1osV0FBVyxNQUFNLFFBQVEsS0FBSyxTQUFTLElBQUksS0FBSyxZQUFZLENBQUE7O0VBRTlEO0FBQ0EsU0FBTztBQUNSO0FBWU0sU0FBVSxxQkFDZixTQUNBLE9BQ0EsT0FDQSxXQUFpQjtBQUVqQixRQUFNLFNBQVMsUUFBUSxLQUFLO0FBQzVCLE1BQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxRQUFRLE9BQU8sU0FBUztBQUFHLFdBQU87QUFHeEQsTUFBSSxTQUFTLE9BQU8sVUFBVSxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUd2RixNQUFJLENBQUMsUUFBUTtBQUNaLGFBQVMsT0FBTyxVQUFVLEtBQUssQ0FBQyxNQUFVO0FBQ3pDLFVBQUksRUFBRSxXQUFXO0FBQU8sZUFBTztBQUMvQixZQUFNLGNBQWMsRUFBRSxTQUFTLEtBQUssQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBQ3BFLFVBQUksQ0FBQyxhQUFhO0FBQVMsZUFBTztBQUVsQyxZQUFNLFNBQVMsWUFBWSxFQUFFO0FBQzdCLGFBQU8sWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxNQUFNO0lBQzVELENBQUM7RUFDRjtBQUVBLFNBQU87QUFDUjs7O0FDNUxBLFNBQVMsWUFBWSxHQUFNO0FBQzFCLFFBQU0sT0FBTztJQUNaLE1BQU0sRUFBRTtJQUNSLElBQUksRUFBRTtJQUNOLE9BQU8sRUFBRTtJQUNULFNBQVMsRUFBRTtJQUNYLFNBQVMsRUFBRTs7QUFHWixVQUFRLEVBQUUsTUFBTTtJQUNmLEtBQUs7QUFDSixhQUFPLEVBQUUsR0FBRyxNQUFNLFNBQVMsRUFBRSxXQUFXLENBQUEsRUFBRTtJQUUzQyxLQUFLO0FBQ0osYUFBTztRQUNOLEdBQUc7UUFDSCxLQUFLLEVBQUU7UUFDUCxLQUFLLEVBQUU7UUFDUCxNQUFNLEVBQUUsUUFBUTtRQUNoQixPQUFPOztJQUdULEtBQUs7QUFDSixhQUFPLEVBQUUsR0FBRyxNQUFNLFNBQVMsRUFBRSxXQUFXLE1BQUs7SUFFOUMsS0FBSztBQUNKLGFBQU8sRUFBRSxHQUFHLE1BQU0sT0FBTyxFQUFFLFNBQVMsR0FBRTtJQUV2QyxLQUFLO0lBQ0wsS0FBSztJQUNMO0FBQ0MsYUFBTztFQUNUO0FBQ0Q7QUFNTSxTQUFVLGVBQVk7QUFDM0IsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxRQUFNLFVBQXNDLENBQUE7QUFFNUMsYUFBVyxDQUFDLE9BQU8sTUFBTSxLQUFLLE9BQU8sUUFBUSxPQUFPLEdBQUc7QUFDdEQsVUFBTSxZQUFZLE9BQU87QUFDekIsUUFBSSxDQUFDLE1BQU0sUUFBUSxTQUFTO0FBQUc7QUFFL0IsZUFBVyxLQUFLLFdBQVc7QUFFMUIsVUFBSSxFQUFFLGFBQWE7QUFBTTtBQUV6QixZQUFNLFdBQVcsY0FBYyxPQUFPLEVBQUUsUUFBUSxFQUFFLEVBQUU7QUFFcEQsWUFBTSxXQUFXLEVBQUUsV0FBVyxDQUFBLEdBQUksSUFBSSxXQUFXO0FBRWpELFlBQU0sU0FBb0M7UUFDekMsTUFBTSxTQUFTLEtBQUssS0FBSyxFQUFFLElBQUk7UUFDL0I7UUFDQSxVQUFVLFlBQVc7UUFFckI7O0FBR0QsY0FBUSxRQUFRLElBQUk7SUFDckI7RUFDRDtBQUVBLFNBQU87QUFDUjtBQVVBLFNBQVMsZ0JBQWdCLFNBQVk7QUFDcEMsUUFBTSxXQUFXLFFBQVEsU0FBUyxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sT0FBTztBQUNuRSxNQUFJLENBQUMsWUFBWSxTQUFTLFNBQVMsY0FBYyxDQUFDLE1BQU0sUUFBUSxTQUFTLE9BQU87QUFBRyxXQUFPO0FBQzFGLE1BQUksU0FBUyxRQUFRLFdBQVc7QUFBRyxXQUFPO0FBQzFDLFFBQU0sU0FBUyxTQUFTLFFBQVEsSUFBSSxDQUFDLE1BQVcsT0FBTyxFQUFFLEtBQUssRUFBRSxZQUFXLENBQUU7QUFDN0UsU0FBTyxPQUFPLFNBQVMsS0FBSyxLQUFLLE9BQU8sU0FBUyxJQUFJO0FBQ3REO0FBRU0sU0FBVSxpQkFBYztBQUM3QixRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFFBQU0sWUFBMEMsQ0FBQTtBQUVoRCxhQUFXLENBQUMsT0FBTyxNQUFNLEtBQUssT0FBTyxRQUFRLE9BQU8sR0FBRztBQUN0RCxVQUFNLFlBQVksT0FBTztBQUN6QixRQUFJLENBQUMsTUFBTSxRQUFRLFNBQVM7QUFBRztBQUUvQixlQUFXLFdBQVcsV0FBVztBQUVoQyxVQUFJLFFBQVEsY0FBYztBQUFNO0FBRWhDLFlBQU0saUJBQWlCLGNBQWMsT0FBTyxRQUFRLFFBQVEsUUFBUSxFQUFFO0FBR3RFLFlBQU0sY0FBYyxRQUFRLFdBQVcsQ0FBQSxHQUFJLElBQUksV0FBVztBQUcxRCxZQUFNLGVBQWUsV0FBVyxPQUFPLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUd2RSxtQkFBYSxLQUFLO1FBQ2pCLE1BQU07UUFDTixJQUFJO1FBQ0osT0FBTztRQUNQLFNBQVM7UUFDVCxTQUFTO09BQ1Q7QUFHRCxZQUFNLGdCQUFxQjtRQUMxQixNQUFNO1FBQ04sTUFBTSxTQUFTLEtBQUssS0FBSyxRQUFRLElBQUk7UUFDckMsU0FBUztRQUNULFVBQVUsTUFBSztBQUVkLGlCQUFPO1FBQ1I7O0FBSUQsVUFBSSxnQkFBZ0IsT0FBTyxHQUFHO0FBQzdCLGNBQU0saUJBQWlCLEdBQUcsY0FBYztBQUd4QyxjQUFNLGNBQWMsV0FBVyxPQUFPLENBQUMsUUFBYSxJQUFJLE9BQU8sT0FBTztBQUV0RSxjQUFNLGVBQW9CO1VBQ3pCLE1BQU07VUFDTixNQUFNLFNBQVMsS0FBSyxLQUFLLFFBQVEsSUFBSTtVQUNyQyxjQUFjO1lBQ2IsU0FBUyxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBQzdCLE9BQU8sV0FBVyxHQUFHLEdBQUcsQ0FBQzs7VUFFMUIsU0FBUztVQUNULFVBQVUsTUFBSztBQUVkLG1CQUFPO1VBQ1I7O0FBR0Qsa0JBQVUsY0FBYyxJQUFJO01BQzdCLE9BQU87QUFDTixrQkFBVSxjQUFjLElBQUk7TUFDN0I7SUFDRDtFQUNEO0FBRUEsU0FBTztBQUNSOzs7QUN6S0EsT0FBT0MsV0FBVTs7O0FDTGpCLE9BQU9DLFNBQVE7QUFpQmYsSUFBTUMsVUFBUyxtQkFBbUIsZ0JBQWdCO0FBMENsRCxTQUFTLGVBQWUsT0FBYTtBQUNwQyxRQUFNLFNBQVMsb0JBQUksSUFBRztBQUN0QixNQUFJLFlBQVk7QUFFaEIsTUFBSTtBQUVILFVBQU0sT0FBTyxnQkFBZ0IsS0FBSztBQUNsQyxRQUFJLENBQUMsTUFBTTtBQUVWLGFBQU8sRUFBRSxXQUFXLE9BQU07SUFDM0I7QUFHQSxnQkFBWSxLQUFLLGFBQWE7QUFHOUIsZUFBVyxVQUFVLEtBQUssYUFBYSxDQUFBLEdBQUk7QUFDMUMsWUFBTSxpQkFBaUIsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUF3QixJQUFJLFNBQVMsYUFBYTtBQUMvRixVQUFJLGdCQUFnQjtBQUVuQixlQUFPLElBQUksT0FBTyxFQUFFO0FBR3BCLGNBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQXdCLElBQUksT0FBTyxPQUFPO0FBQ3BGLFlBQUksYUFBYSxTQUFTO0FBQ3pCLHFCQUFXLFVBQVUsWUFBWSxTQUFTO0FBQ3pDLGdCQUFJLE9BQU8sT0FBTyxPQUFPLFVBQVU7QUFDbEMscUJBQU8sSUFBSSxPQUFPLEtBQUssT0FBTyxFQUFFO1lBQ2pDO1VBQ0Q7UUFDRDtNQUNEO0lBQ0Q7RUFDRCxTQUFTLE1BQU07RUFFZjtBQUVBLFNBQU8sRUFBRSxXQUFXLE9BQU07QUFDM0I7QUFNQSxTQUFTLHNCQUFzQixLQUFXO0FBQ3pDLFFBQU0sV0FBVyxJQUFJLFFBQVEsT0FBTyxLQUFLLFVBQVUsQ0FBQztBQUNwRCxNQUFJLFdBQVc7QUFBRyxVQUFNLElBQUksTUFBTSxpQ0FBaUM7QUFFbkUsUUFBTSxlQUFlLFdBQVc7QUFDaEMsTUFBSSxJQUFJLFlBQVksTUFBTSxJQUFNO0FBQy9CLFVBQU0sSUFBSSxNQUFNLHVDQUF1QyxJQUFJLFlBQVksRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFO0VBQ3hGO0FBRUEsU0FBTztBQUNSO0FBTUEsU0FBUyx1QkFBdUIsT0FBZSxTQUFzQixvQkFBSSxJQUFHLEdBQUU7QUFDN0UsTUFBSSxJQUFJO0FBQ1IsUUFBTSxNQUF1QixDQUFBO0FBRTdCLFNBQU8sSUFBSSxNQUFNLFFBQVE7QUFDeEIsVUFBTSxLQUFLLE1BQU0sQ0FBQztBQUNsQixRQUFJLElBQUksS0FBSyxNQUFNO0FBQVE7QUFHM0IsUUFBSSxPQUFPLElBQUksRUFBRSxLQUFLLElBQUksSUFBSSxNQUFNLFFBQVE7QUFDM0MsVUFBSSxLQUFLO1FBQ1IsUUFBUTtRQUNSO1FBQ0EsWUFBWSxDQUFDLE1BQU0sSUFBSSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQyxDQUFDO09BQ3JEO0FBQ0QsV0FBSztBQUNMO0lBQ0Q7QUFFQSxRQUFJLEtBQUssRUFBRSxRQUFRLGNBQWMsSUFBSSxZQUFZLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUU7QUFDakUsU0FBSztFQUNOO0FBRUEsU0FBTztBQUNSO0FBRUEsU0FBUyx5QkFBeUIsS0FBYSxPQUFhO0FBQzNELFFBQU0sTUFBTSxzQkFBc0IsR0FBRztBQUNyQyxRQUFNLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSTtBQUM3QixNQUFJLFVBQVUsd0JBQXdCLFVBQVUsbUJBQW1CO0FBQ2xFLFVBQU0sSUFBSSxNQUFNLDRCQUE0QjtFQUM3QztBQUVBLFFBQU0sV0FBVyxJQUFJLE1BQU0sQ0FBQztBQUM1QixRQUFNLFFBQVEsTUFBTTtBQUNwQixRQUFNLE1BQU0sUUFBUTtBQUNwQixNQUFJLE1BQU0sSUFBSTtBQUFRLFVBQU0sSUFBSSxNQUFNLHNCQUFzQjtBQUU1RCxRQUFNLEVBQUUsT0FBTSxJQUFLLGVBQWUsS0FBSztBQUN2QyxTQUFPLHVCQUF1QixJQUFJLFNBQVMsT0FBTyxHQUFHLEdBQUcsTUFBTTtBQUMvRDtBQU1BLFNBQVMsOEJBQThCLEtBQWEsT0FBYTtBQUNoRSxRQUFNLE1BQU0sc0JBQXNCLEdBQUc7QUFDckMsUUFBTSxRQUFRLElBQUksTUFBTSxDQUFDLElBQUk7QUFDN0IsTUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFNLElBQUksTUFBTSw0QkFBNEI7RUFDN0M7QUFHQSxNQUFJLElBQUksVUFBVSx1QkFBdUIsTUFBTSxJQUFJLE1BQU07QUFDekQsUUFBTSxNQUFNLElBQUksU0FBUztBQUN6QixRQUFNLE1BQXVCLENBQUE7QUFHN0IsUUFBTSxFQUFFLE9BQU0sSUFBSyxlQUFlLEtBQUs7QUFJdkMsUUFBTSxvQkFBb0IsQ0FBQyxhQUFhLGlCQUFpQixXQUFXO0FBS3BFLFFBQU0sbUJBQW1CLENBQUMsV0FBVztBQUVyQyxTQUFPLElBQUksSUFBSSxLQUFLO0FBQ25CLFVBQU0sU0FBUyxJQUFJLENBQUM7QUFDcEIsVUFBTSxlQUFlLElBQUksSUFBSSxDQUFDO0FBRTlCLFVBQU0sYUFBYSxJQUFJLElBQUk7QUFDM0IsUUFBSSxhQUFhO0FBQUs7QUFFdEIsVUFBTSxXQUFXLGtCQUFrQixTQUFTLFlBQVk7QUFDeEQsVUFBTSxhQUFhLGlCQUFpQixTQUFTLFlBQVk7QUFFekQsUUFBSTtBQUNKLFFBQUk7QUFDSixRQUFJO0FBRUosUUFBSSxZQUFZO0FBUWYsY0FBUSxJQUFJLElBQUksQ0FBQztBQUNqQixZQUFNLFdBQVcsSUFBSSxTQUFTLElBQUksR0FBRyxVQUFVO0FBRS9DLFlBQU0sU0FBUyxnQkFBZ0IsS0FBSztBQUNwQyxZQUFNLGlCQUFpQixRQUFRLGFBQWEsQ0FBQSxHQUMxQyxPQUFPLENBQUMsT0FBaUIsRUFBRSxXQUFXLGVBQWUsRUFBRSxXQUFXLG9CQUFvQixFQUFFLFVBQVUsTUFBUyxFQUMzRyxLQUFLLENBQUMsR0FBYSxNQUFnQixFQUFFLEtBQUssRUFBRSxFQUFFO0FBRWhELGVBQVMsSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7QUFDekMsY0FBTSxRQUFRLGNBQWMsQ0FBQztBQUM3QixZQUFJLE9BQU87QUFDVixjQUFJLEtBQUssRUFBRSxRQUFRLE1BQU0sUUFBUSxJQUFJLE1BQU0sSUFBSSxPQUFPLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFDLENBQUU7UUFDbEY7TUFFRDtBQUNBLFVBQUk7QUFDSjtJQUNELFdBQVcsVUFBVTtBQUVwQixjQUFRLElBQUksSUFBSSxDQUFDO0FBQ2pCLGdCQUFVLElBQUksSUFBSSxDQUFDO0FBQ25CLFVBQUksSUFBSTtJQUNULE9BQU87QUFFTixnQkFBVSxJQUFJLElBQUksQ0FBQztBQUNuQixVQUFJLElBQUk7SUFDVDtBQUVBLFVBQU0sT0FBTyxJQUFJO0FBQ2pCLFVBQU0sU0FBUztBQUVmLFdBQU8sSUFBSSxJQUFJLE1BQU07QUFDcEIsWUFBTSxLQUFLLElBQUksQ0FBQztBQUNoQixVQUFJO0FBR0osVUFBSSxPQUFPLElBQUksRUFBRSxLQUFLLElBQUksSUFBSSxNQUFNO0FBQ25DLHFCQUFhLENBQUMsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLENBQUM7QUFDaEQsYUFBSztNQUNOLE9BQU87QUFDTixxQkFBYSxDQUFDLElBQUksSUFBSSxDQUFDLENBQUM7QUFDeEIsYUFBSztNQUNOO0FBRUEsWUFBTSxVQUF5QjtRQUM5QixRQUFRO1FBQ1I7UUFDQTs7QUFFRCxVQUFJLFVBQVUsUUFBVztBQUN4QixnQkFBUSxRQUFRO01BQ2pCO0FBQ0EsVUFBSSxLQUFLLE9BQU87SUFDakI7QUFRQSxRQUFJLE1BQU0sVUFBVSxhQUFhLElBQUksR0FBRztBQUN2QyxVQUFJLE1BQU0sV0FBVyxJQUFJLElBQUksSUFBSTtBQUNqQyxVQUFJLFFBQVE7QUFDWixhQUFPLE1BQU0sWUFBWTtBQUN4QixjQUFNLFVBQXlCLEVBQUUsUUFBUSxjQUFjLElBQUksU0FBUyxZQUFZLENBQUMsSUFBSSxLQUFLLENBQUMsRUFBQztBQUM1RixZQUFJLFVBQVU7QUFBVyxrQkFBUSxRQUFRO0FBQ3pDLFlBQUksS0FBSyxPQUFPO01BQ2pCO0lBQ0Q7QUFFQSxRQUFJO0VBQ0w7QUFFQSxTQUFPO0FBQ1I7QUFXTSxTQUFVLHNCQUFzQixPQUFlLEtBQVc7QUFDL0QsUUFBTSxNQUFNLHNCQUFzQixHQUFHO0FBQ3JDLFFBQU0sUUFBUSxJQUFJLE1BQU0sQ0FBQyxJQUFJO0FBQzdCLE1BQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBTSxJQUFJLE1BQU0saUNBQWlDLE1BQU0sU0FBUyxFQUFFLENBQUMsR0FBRztFQUN2RTtBQUNBLFFBQU0sRUFBRSxVQUFTLElBQUssZUFBZSxLQUFLO0FBQzFDLFNBQU8sWUFBWSw4QkFBOEIsS0FBSyxLQUFLLElBQUkseUJBQXlCLEtBQUssS0FBSztBQUNuRztBQU1NLFNBQVUsb0JBQW9CLFNBQXdCLFNBQW1CO0FBRTlFLE1BQUksU0FBUyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxRQUFRLFVBQVUsRUFBRSxPQUFPLFFBQVEsRUFBRTtBQUtuRixNQUFJLENBQUMsUUFBUTtBQUNaLFVBQU0sYUFBYSxRQUFRLEtBQUssQ0FBQyxNQUFLO0FBQ3JDLFVBQUksRUFBRSxXQUFXLFFBQVE7QUFBUSxlQUFPO0FBRXhDLFlBQU0sY0FBYyxFQUFFLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDL0QsVUFBSSxDQUFDLGFBQWE7QUFBUyxlQUFPO0FBRWxDLFlBQU0sZ0JBQWdCLFFBQVEsS0FBSyxFQUFFO0FBQ3JDLGFBQU8sWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxhQUFhO0lBQzlELENBQUM7QUFDRCxRQUFJLFlBQVk7QUFDZixlQUFTO0lBQ1Y7RUFDRDtBQUVBLFFBQU0sU0FBUyxNQUFNLFFBQVEsTUFBTTtBQUNuQyxRQUFNLFFBQVEsTUFBTSxRQUFRLEVBQUU7QUFDOUIsUUFBTSxTQUFTLFdBQVcsUUFBUSxVQUFVO0FBQzVDLFFBQU0sU0FDTCxRQUFRLFdBQVcsV0FBVyxJQUMzQixlQUFlLFFBQVEsV0FBVyxDQUFDLEdBQUcsUUFBUSxXQUFXLENBQUMsR0FBRyxRQUFRLFdBQVcsQ0FBQyxDQUFDLElBQ2xGLFFBQVEsV0FBVyxXQUFXLElBQzdCLFFBQVEsV0FBVyxDQUFDLElBQ3BCLFFBQVEsV0FBVyxLQUFLLEdBQUc7QUFHaEMsUUFBTSxXQUFXLFFBQVEsVUFBVSxTQUFZLE9BQU8sUUFBUSxLQUFLLEtBQUs7QUFDeEUsUUFBTSxTQUFTLE9BQU8sTUFBTSxHQUFHLFFBQVEsT0FBTyxLQUFLLFFBQVEsTUFBTTtBQUdqRSxNQUFJLFFBQVE7QUFDWCxRQUFJLE9BQU8sT0FBTztBQUdsQixRQUFJLFFBQVEsVUFBVSxRQUFXO0FBQ2hDLGFBQU8sR0FBRyxJQUFJLE1BQU0sUUFBUSxRQUFRLENBQUM7SUFDdEMsT0FFSztBQUNKLFlBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDcEUsVUFBSSxhQUFhLFNBQVM7QUFDekIsY0FBTSxnQkFBZ0IsUUFBUSxLQUFLLE9BQU87QUFDMUMsY0FBTSxjQUFjLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sYUFBYTtBQUMxRSxZQUFJLGFBQWE7QUFDaEIsaUJBQU8sR0FBRyxJQUFJLElBQUksWUFBWSxLQUFLO1FBQ3BDO01BQ0Q7SUFDRDtBQUdBLFVBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDcEUsUUFBSSxhQUFhLFdBQVcsUUFBUSxXQUFXLFdBQVcsR0FBRztBQUM1RCxZQUFNLFNBQVMsWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLFdBQVcsQ0FBQyxDQUFDO0FBQzdFLFVBQUksUUFBUTtBQUNYLGVBQU8sR0FBRyxNQUFNLE1BQU0sSUFBSSxLQUFLLE9BQU8sS0FBSyxLQUFLLE1BQU07TUFDdkQ7SUFDRDtBQUNBLFdBQU8sR0FBRyxNQUFNLE1BQU0sSUFBSSxLQUFLLE1BQU07RUFDdEM7QUFHQSxTQUFPLEdBQUcsTUFBTTtBQUNqQjtBQVdNLFNBQVUsaUNBQ2YsT0FDQSxLQUFXO0FBRVgsUUFBTSxTQUFTLGdCQUFnQixLQUFLO0FBQ3BDLFFBQU0sb0JBQW9CLFFBQVE7QUFHbEMsTUFBSSxzQkFBc0IsUUFBVztBQUNwQyxVQUFNLFdBQVcsb0JBQ2QsOEJBQThCLEtBQUssS0FBSyxJQUN4Qyx5QkFBeUIsS0FBSyxLQUFLO0FBQ3RDLFdBQU8sRUFBRSxVQUFVLG1CQUFtQixLQUFJO0VBQzNDO0FBR0EsTUFBSSxlQUFnQyxDQUFBO0FBQ3BDLE1BQUksb0JBQXFDLENBQUE7QUFFekMsTUFBSTtBQUNILG1CQUFlLHlCQUF5QixLQUFLLEtBQUs7RUFDbkQsU0FBUyxHQUFHO0FBQ1gsSUFBQUEsUUFBTyxNQUFNLHVCQUF1QixDQUFDLEVBQUU7RUFDeEM7QUFFQSxNQUFJO0FBQ0gsd0JBQW9CLDhCQUE4QixLQUFLLEtBQUs7RUFDN0QsU0FBUyxHQUFHO0FBQ1gsSUFBQUEsUUFBTyxNQUFNLDRCQUE0QixDQUFDLEVBQUU7RUFDN0M7QUFHQSxNQUFJLGtCQUFrQixTQUFTLGFBQWEsUUFBUTtBQUNuRCxJQUFBQSxRQUFPLEtBQUssNkNBQTZDLGtCQUFrQixNQUFNLFlBQVksYUFBYSxNQUFNLEdBQUc7QUFDbkgsV0FBTyxFQUFFLFVBQVUsbUJBQW1CLG1CQUFtQixLQUFJO0VBQzlELFdBQVcsYUFBYSxTQUFTLEdBQUc7QUFDbkMsSUFBQUEsUUFBTyxLQUFLLG1DQUFtQyxhQUFhLE1BQU0saUJBQWlCLGtCQUFrQixNQUFNLEdBQUc7QUFDOUcsV0FBTyxFQUFFLFVBQVUsY0FBYyxtQkFBbUIsTUFBSztFQUMxRCxPQUFPO0FBRU4sSUFBQUEsUUFBTyxLQUFLLHVEQUF1RCxLQUFLLEVBQUU7QUFDMUUsV0FBTyxFQUFFLFVBQVUsQ0FBQSxHQUFJLG1CQUFtQixLQUFJO0VBQy9DO0FBQ0Q7QUFFTSxTQUFVLDRCQUE0QixPQUFlLEtBQVc7QUFDckUsUUFBTSxFQUFFLFVBQVMsSUFBSyxlQUFlLEtBQUs7QUFDMUMsU0FBTyxZQUFZLDhCQUE4QixLQUFLLEtBQUssSUFBSSx5QkFBeUIsS0FBSyxLQUFLO0FBQ25HO0FBTUEsU0FBUyxtQkFBbUIsWUFBb0I7QUFDL0MsTUFBSSxXQUFXLFdBQVcsR0FBRztBQUM1QixXQUFPLEVBQUUsSUFBSSxTQUFTLE9BQU8sU0FBUyxNQUFNLFVBQVUsU0FBUyxXQUFXLENBQUMsRUFBQztFQUM3RTtBQUVBLE1BQUksV0FBVyxXQUFXLEdBQUc7QUFDNUIsVUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDLElBQUk7QUFDbEIsV0FBTztNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsTUFBTTtNQUNOLFNBQVMsZUFBZSxHQUFHLEdBQUcsQ0FBQzs7RUFFakM7QUFFQSxTQUFPLEVBQUUsSUFBSSxTQUFTLE9BQU8sU0FBUyxNQUFNLE9BQU8sU0FBUyxDQUFDLEdBQUcsVUFBVSxFQUFDO0FBQzVFO0FBTU0sU0FBVSw0QkFDZixXQUNBLFFBQ0EsV0FBc0M7QUFFdEMsUUFBTSxNQUFNLGdCQUFnQixTQUFTO0FBR3JDLE1BQUksQ0FBQyxJQUFJLFdBQVc7QUFDbkIsUUFBSSxZQUFZLENBQUE7RUFDakI7QUFHQSxRQUFNLGFBQWEsT0FBTyxPQUFPLFNBQVMsRUFDeEMsT0FBTyxDQUFDLE1BQU0sRUFBRSxVQUFVLFVBQVUsS0FBSyxFQUN6QyxLQUFLLENBQUMsR0FBRyxNQUFNLGNBQWMsVUFBVSxPQUFPLEVBQUUsS0FBSyxJQUFJLGNBQWMsVUFBVSxPQUFPLEVBQUUsS0FBSyxDQUFDO0FBRWxHLEVBQUFBLFFBQU8sS0FBSyxtQkFBbUIsVUFBVSxLQUFLLEVBQUU7QUFDaEQsRUFBQUEsUUFBTyxNQUFNLDZCQUE2QixXQUFXLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssSUFBSSxDQUFDLEVBQUU7QUFLckYsUUFBTSxtQkFBbUIsb0JBQUksSUFBRztBQUNoQyxhQUFXLEtBQUssWUFBWTtBQUMzQixlQUFXLGFBQWEsRUFBRSxhQUFhLENBQUEsR0FBSTtBQUMxQyxZQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxPQUFPO0FBQ3JFLFVBQUksQ0FBQyxVQUFVO0FBQVM7QUFDeEIsWUFBTSxTQUFTLFVBQVU7QUFDekIsWUFBTSxRQUFRLFVBQVU7QUFDeEIsWUFBTSxNQUFNLEdBQUcsS0FBSyxJQUFJLE1BQU07QUFDOUIsVUFBSSxpQkFBaUIsSUFBSSxHQUFHO0FBQUc7QUFFL0IsWUFBTSxnQkFBZ0IsT0FDcEIsT0FBTyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxLQUFLLE1BQU0sRUFDakQsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLE1BQU0sRUFDeEIsS0FBSyxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUM7QUFFdEIsVUFBSSxTQUFTO0FBQ2IsaUJBQVcsT0FBTyxlQUFlO0FBQ2hDLFlBQUksUUFBUSxTQUFTO0FBQUcsbUJBQVM7aUJBQ3hCLE1BQU0sU0FBUztBQUFHO01BQzVCO0FBQ0EsVUFBSSxTQUFTLEdBQUc7QUFDZix5QkFBaUIsSUFBSSxLQUFLLE1BQU07QUFDaEMsUUFBQUEsUUFBTyxNQUFNLGdDQUFnQyxNQUFNLEtBQUssQ0FBQyxZQUFZLE1BQU0sTUFBTSxDQUFDLG9CQUFlLE1BQU0sRUFBRTtNQUMxRztJQUNEO0VBQ0Q7QUFJQSxRQUFNLFlBQVksb0JBQUksSUFBRztBQUN6QixhQUFXLEVBQUUsUUFBUSxJQUFJLE1BQUssS0FBTSxRQUFRO0FBQzNDLFFBQUksVUFBVTtBQUFXO0FBQ3pCLFVBQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxFQUFFO0FBQzNCLFFBQUksQ0FBQyxVQUFVLElBQUksR0FBRztBQUFHLGdCQUFVLElBQUksS0FBSyxvQkFBSSxJQUFHLENBQUU7QUFDckQsY0FBVSxJQUFJLEdBQUcsRUFBRyxJQUFJLEtBQUs7RUFDOUI7QUFNQSxhQUFXLEVBQUUsUUFBUSxJQUFJLE9BQU8sV0FBVSxLQUFNLFFBQVE7QUFFdkQsVUFBTSxnQkFBZ0IsSUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxFQUFFO0FBQ2xGLFFBQUksZUFBZTtBQUNsQixZQUFNLE1BQU0sY0FBYyxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQy9ELFVBQUk7QUFBSyxZQUFJLFVBQVUsbUJBQW1CLFVBQVUsRUFBRTtBQUd0RCxZQUFNLGtCQUFrQixVQUFVLElBQUksR0FBRyxNQUFNLElBQUksRUFBRSxFQUFFO0FBQ3ZELFVBQUksbUJBQW1CLGdCQUFnQixPQUFPLEdBQUc7QUFDaEQsY0FBTSxXQUFXLEtBQUssSUFBSSxHQUFHLGVBQWU7QUFDNUMsY0FBTSxpQkFBaUIsY0FBYyxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQzFFLFlBQUksYUFBYSxLQUFLLGNBQWMsVUFBVSxVQUFhLENBQUMsZ0JBQWdCO0FBQzNFLHdCQUFjLFFBQVE7QUFDdEIsVUFBQUEsUUFBTyxLQUFLLDZDQUE2QyxNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLEVBQUU7UUFDekY7TUFDRDtBQUNBO0lBQ0Q7QUFLQSxVQUFNLFlBQVksSUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFLO0FBQzFDLFVBQUksRUFBRSxXQUFXO0FBQVEsZUFBTztBQUNoQyxZQUFNLFdBQVcsRUFBRSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ3hELFVBQUksQ0FBQyxVQUFVO0FBQVMsZUFBTztBQUMvQixVQUFJLE1BQU0sRUFBRTtBQUFJLGVBQU87QUFDdkIsWUFBTSxTQUFTLEtBQUssRUFBRTtBQUV0QixhQUFPLFdBQVcsS0FBSyxDQUFDLE1BQUs7QUFDNUIsY0FBTSxXQUFXLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRSxFQUFFO0FBQzlFLGNBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsZUFBTyxVQUFVLFNBQVMsS0FBSyxDQUFDLE9BQVksR0FBRyxPQUFPLE1BQU07TUFDN0QsQ0FBQztJQUNGLENBQUM7QUFDRCxRQUFJLFdBQVc7QUFDZCxZQUFNLFNBQVMsS0FBSyxVQUFVO0FBQzlCLFlBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsVUFBSSxVQUFVLFdBQVcsQ0FBQyxTQUFTLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE1BQU0sR0FBRztBQUM3RSxZQUFJLFFBQVEsV0FBVyxTQUFTLENBQUM7QUFDakMsbUJBQVcsS0FBSyxZQUFZO0FBQzNCLGdCQUFNLFdBQVcsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxVQUFVLEVBQUU7QUFDdEYsZ0JBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsZ0JBQU0sWUFBWSxVQUFVLFNBQVMsS0FBSyxDQUFDLE9BQVksR0FBRyxPQUFPLE1BQU07QUFDdkUsY0FBSSxXQUFXO0FBQ2Qsb0JBQVEsVUFBVTtBQUNsQjtVQUNEO1FBQ0Q7QUFDQSxpQkFBUyxRQUFRLEtBQUssRUFBRSxJQUFJLFFBQVEsTUFBSyxDQUFFO0FBQzNDLFFBQUFBLFFBQU8sS0FDTixpQkFBaUIsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyx1QkFBdUIsTUFBTSxVQUFVLEVBQUUsQ0FBQyxjQUFjLE1BQU0sTUFBTSxLQUFLLElBQUk7TUFFN0g7QUFDQTtJQUNEO0FBR0EsUUFBSTtBQUVKLGVBQVcsS0FBSyxZQUFZO0FBQzNCLFlBQU0sUUFBUSxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUU7QUFDekUsVUFBSSxPQUFPO0FBQ1YsaUJBQVMsZ0JBQWdCLEtBQUs7QUFFOUIsY0FBTSxXQUFXLE1BQU0sS0FBSyxRQUFRLHFDQUFxQyxFQUFFLEVBQUUsS0FBSTtBQUNqRixlQUFPLE9BQU8sR0FBRyxRQUFRLHlCQUF5QixFQUFFLEtBQUs7QUFDekQsUUFBQUEsUUFBTyxLQUFLLG1CQUFtQixNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLGVBQWUsRUFBRSxLQUFLLFVBQVU7QUFDNUY7TUFDRDtJQUNEO0FBSUEsUUFBSSxDQUFDLFFBQVE7QUFDWixVQUFJLGNBQWM7QUFDbEIsaUJBQVcsS0FBSyxZQUFZO0FBQzNCLGNBQU0sWUFBWSxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQVU7QUFDOUMsY0FBSSxFQUFFLFdBQVc7QUFBUSxtQkFBTztBQUNoQyxnQkFBTSxXQUFXLEVBQUUsU0FBUyxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sT0FBTztBQUM3RCxjQUFJLENBQUMsVUFBVTtBQUFTLG1CQUFPO0FBQy9CLGNBQUksTUFBTSxFQUFFO0FBQUksbUJBQU87QUFDdkIsZ0JBQU0sU0FBUyxLQUFLLEVBQUU7QUFDdEIsZ0JBQU0sU0FBUyxpQkFBaUIsSUFBSSxHQUFHLE1BQU0sSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLO0FBQzVELGlCQUFPLFVBQVU7UUFDbEIsQ0FBQztBQUNELFlBQUksV0FBVztBQUNkLHdCQUFjO0FBQ2QsVUFBQUEsUUFBTyxNQUNOLFVBQVUsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyw0Q0FBNEMsTUFBTSxVQUFVLEVBQUUsQ0FBQyw2QkFBd0I7QUFFL0g7UUFDRDtNQUNEO0FBQ0EsVUFBSTtBQUFhO0lBQ2xCO0FBR0EsUUFBSSxDQUFDLFFBQVE7QUFDWixlQUFTO1FBQ1I7UUFDQTtRQUNBLE1BQU0sZUFBZSxNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxFQUFFLFlBQVcsQ0FBRTtRQUNoRSxTQUFTLENBQUMsbUJBQW1CLFVBQVUsQ0FBQzs7QUFFekMsVUFBSSxVQUFVO0FBQVcsZUFBTyxRQUFRO0FBQ3hDLE1BQUFBLFFBQU8sS0FBSywwQkFBMEIsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxFQUFFO0lBQ3RFLE9BQU87QUFJTixhQUFPLFVBQVUsT0FBTyxTQUFTLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLEtBQUssQ0FBQTtBQUNwRSxhQUFPLE9BQU87QUFFZCxZQUFNLGtCQUFrQixVQUFVLElBQUksR0FBRyxNQUFNLElBQUksRUFBRSxFQUFFO0FBQ3ZELFVBQUksbUJBQW1CLGdCQUFnQixPQUFPLEdBQUc7QUFDaEQsY0FBTSxXQUFXLEtBQUssSUFBSSxHQUFHLGVBQWU7QUFDNUMsWUFBSSxhQUFhLEdBQUc7QUFFbkIsaUJBQU8sUUFBUTtRQUNoQixPQUFPO0FBRU4sZ0JBQU0sZUFBZSxNQUFNLEtBQUssRUFBRSxRQUFRLFdBQVcsRUFBQyxHQUFJLENBQUMsR0FBRyxPQUFPO1lBQ3BFLElBQUk7WUFDSixPQUFPLFdBQVcsSUFBSSxDQUFDO1lBQ3RCO0FBQ0YsaUJBQU8sUUFBUSxRQUFRO1lBQ3RCLElBQUk7WUFDSixPQUFPO1lBQ1AsTUFBTTtZQUNOLFNBQVM7WUFDVCxTQUFTO1dBQ0Y7UUFDVDtNQUNEO0FBTUEsWUFBTSxrQkFBa0IsbUJBQW1CLFVBQVUsRUFBRTtBQUN2RCxZQUFNLFdBQVcsT0FBTyxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQzdELFVBQUksVUFBVTtBQUNiLFlBQUksU0FBUyxXQUFXLE1BQU0sUUFBUSxTQUFTLE9BQU8sR0FBRztBQUN4RCxnQkFBTSxZQUFZLFNBQVMsUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sZUFBZTtBQUM1RSxjQUFJLENBQUMsV0FBVztBQUNmLFlBQUFBLFFBQU8sS0FDTiwrQkFBK0IsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxpQ0FBaUMsZUFBZSxzQ0FBaUM7QUFHOUkscUJBQVMsT0FBTztBQUNoQixtQkFBUSxTQUFpQjtVQUMxQjtRQUNEO0FBQ0EsaUJBQVMsVUFBVTtNQUNwQjtJQUNEO0FBRUEsUUFBSSxVQUFVLEtBQUssTUFBTTtFQUMxQjtBQVNBLGFBQVcsRUFBRSxRQUFRLEdBQUUsS0FBTSxRQUFRO0FBQ3BDLFVBQU0sa0JBQWtCLElBQUksVUFBVSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRTtBQUNwRixRQUFJO0FBQWlCO0FBR3JCLFVBQU0sWUFBWSxJQUFJLFVBQVUsS0FBSyxDQUFDLE1BQUs7QUFDMUMsVUFBSSxFQUFFLFdBQVc7QUFBUSxlQUFPO0FBQ2hDLFlBQU1DLFlBQVcsRUFBRSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ3hELGFBQU8sQ0FBQyxDQUFDQSxXQUFVLFdBQVcsS0FBSyxFQUFFO0lBQ3RDLENBQUM7QUFDRCxRQUFJLENBQUM7QUFBVztBQUVoQixVQUFNLFNBQVMsS0FBSyxVQUFVO0FBQzlCLFVBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsUUFBSSxDQUFDLFVBQVUsV0FBVyxTQUFTLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE1BQU07QUFBRztBQUk5RSxVQUFNLGVBQWUsV0FBVyxLQUFLLENBQUMsTUFBSztBQUMxQyxZQUFNLFdBQVcsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxVQUFVLEVBQUU7QUFDdEYsWUFBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUNoRSxhQUFPLFVBQVUsU0FBUyxLQUFLLENBQUMsT0FBWSxHQUFHLE9BQU8sTUFBTTtJQUM3RCxDQUFDO0FBQ0QsVUFBTSxrQkFBa0IsU0FBUyxRQUFRLElBQUksQ0FBQyxNQUFXLEVBQUUsRUFBWSxFQUFFLEtBQUssQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDO0FBQzdGLFVBQU0sZUFBZSxnQkFBZ0IsU0FBUyxLQUFLLFdBQVcsZ0JBQWdCLGdCQUFnQixTQUFTLENBQUMsSUFBSTtBQUU1RyxRQUFJLENBQUMsZ0JBQWdCLENBQUM7QUFBYztBQUdwQyxRQUFJLFFBQVEsV0FBVyxTQUFTLENBQUM7QUFDakMsZUFBVyxLQUFLLFlBQVk7QUFDM0IsWUFBTSxXQUFXLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sVUFBVSxFQUFFO0FBQ3RGLFlBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsWUFBTSxZQUFZLFVBQVUsU0FBUyxLQUFLLENBQUMsT0FBWSxHQUFHLE9BQU8sTUFBTTtBQUN2RSxVQUFJLFdBQVc7QUFDZCxnQkFBUSxVQUFVO0FBQ2xCO01BQ0Q7SUFDRDtBQUVBLGFBQVMsUUFBUSxLQUFLLEVBQUUsSUFBSSxRQUFRLE1BQUssQ0FBRTtBQUMzQyxJQUFBRCxRQUFPLEtBQ04seUJBQXlCLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsdUJBQXVCLE1BQU0sVUFBVSxFQUFFLENBQUMsY0FBYyxNQUFNLE1BQU0sS0FBSyxJQUFJO0VBRXJJO0FBRUEsU0FBTztBQUNSO0FBTU0sU0FBVSxvQkFBb0IsVUFBa0IsU0FBb0I7QUFDekUsTUFBSTtBQUVILFVBQU0sYUFBa0IsRUFBRSxPQUFPLFFBQVEsTUFBSztBQUc5QyxRQUFJLGVBQWUsU0FBUztBQUMzQixpQkFBVyxZQUFZLFFBQVE7SUFDaEM7QUFHQSxRQUFJLGVBQWUsU0FBUztBQUMzQixpQkFBVyxZQUFZLFFBQVEsVUFBVSxJQUFJLENBQUMsVUFBYztBQUUzRCxjQUFNLGVBQW9CLENBQUE7QUFDMUIsWUFBSSxZQUFZO0FBQU8sdUJBQWEsU0FBUyxNQUFNO0FBQ25ELFlBQUksUUFBUTtBQUFPLHVCQUFhLEtBQUssTUFBTTtBQUMzQyxZQUFJLFdBQVc7QUFBTyx1QkFBYSxRQUFRLE1BQU07QUFDakQsWUFBSSxVQUFVO0FBQU8sdUJBQWEsT0FBTyxNQUFNO0FBQy9DLFlBQUksYUFBYTtBQUFPLHVCQUFhLFVBQVUsTUFBTTtBQUVyRCxtQkFBVyxPQUFPLE9BQU8sS0FBSyxLQUFLLEdBQUc7QUFDckMsY0FBSSxFQUFFLE9BQU87QUFBZSx5QkFBYSxHQUFHLElBQUksTUFBTSxHQUFHO1FBQzFEO0FBQ0EsZUFBTztNQUNSLENBQUM7SUFDRjtBQUVBLGVBQVcsT0FBTyxPQUFPLEtBQUssT0FBTyxHQUFHO0FBQ3ZDLFVBQUksRUFBRSxPQUFPLGFBQWE7QUFDekIsbUJBQVcsR0FBRyxJQUFLLFFBQWdCLEdBQUc7TUFDdkM7SUFDRDtBQUdBLFFBQUksT0FBTyxLQUFLLFVBQVUsWUFBWSxNQUFNLENBQUM7QUFLN0MsV0FBTyxLQUFLLFFBQVEsMERBQTBELDZCQUE2QjtBQUUzRyxJQUFBRSxJQUFHLGNBQWMsVUFBVSxPQUFPLE1BQU0sTUFBTTtFQUMvQyxTQUFTLEdBQUc7QUFDWCxJQUFBRixRQUFPLE1BQU0scUJBQXFCLENBQUMsRUFBRTtFQUN0QztBQUNEOzs7QUR0eEJBLElBQU1HLFVBQVMsbUJBQW1CLFNBQVM7QUFFckMsU0FBVSxjQUFjLE1BQW9CO0FBQ2pELFFBQU0sYUFBYSxpQkFBZ0I7QUFDbkMsUUFBTSxhQUFhLGFBQVk7QUFDL0IsUUFBTSxVQUFVLHFCQUFxQixVQUFVO0FBQy9DLFFBQU0sZUFBb0IsQ0FBQTtBQUUxQixRQUFNLGNBQWMsS0FBSztBQU16QixNQUFJLEtBQUssT0FBTyxTQUFTO0FBQ3hCLGlCQUFhLHVCQUF1QixJQUFJO01BQ3ZDLE1BQU07TUFDTixhQUFhO01BQ2IsU0FBUyxDQUFBO01BQ1QsVUFBVSxZQUFXO0FBQ3BCLGNBQU0sUUFBUTtBQUNkLGNBQU0sS0FBSyxLQUFLO0FBRWhCLGNBQU0sTUFBTSxNQUFNLEtBQUssYUFBYSxtQkFBbUIsRUFBRTtBQUV6RCxZQUFJLFlBQVksZ0JBQWdCLEtBQUs7QUFFckMsY0FBTSxFQUFFLFVBQVUsUUFBUSxrQkFBaUIsSUFBSyxpQ0FBaUMsT0FBTyxHQUFHO0FBQzNGLFFBQUFBLFFBQU8sTUFBTSxpQkFBaUIsS0FBSyxVQUFVLE1BQU0sQ0FBQyxFQUFFO0FBRXRELFlBQUksQ0FBQyxXQUFXO0FBQ2YsVUFBQUEsUUFBTyxLQUFLLFNBQVMsS0FBSyx1REFBa0Q7QUFDNUUsc0JBQVk7WUFDWDtZQUNBLFdBQVcscUJBQXFCO1lBQ2hDLFdBQVcsQ0FBQTs7UUFFYixXQUFXLHNCQUFzQixNQUFNO0FBQ3RDLFVBQUFBLFFBQU8sS0FBSywyQkFBMkIsaUJBQWlCLHdCQUF3QjtBQUNoRixzQkFBWSxFQUFFLEdBQUcsV0FBVyxXQUFXLGtCQUFpQjtRQUN6RDtBQUVBLGNBQU0sVUFBVSw0QkFBNEIsV0FBVyxRQUFRLE9BQU87QUFDdEUsUUFBQUEsUUFBTyxNQUFNLHFCQUFxQixLQUFLLFVBQVUsU0FBUyxNQUFNLENBQUMsQ0FBQyxFQUFFO0FBRXBFLGNBQU1DLGlCQUFnQixpQkFBZ0I7QUFDdEMsY0FBTSxhQUFhQyxNQUFLLEtBQUtELGdCQUFlLFFBQVEsS0FBSyxPQUFPO0FBQ2hFLDRCQUFvQixZQUFZLE9BQU87QUFFdkMsNEJBQW1CO0FBRW5CLFFBQUFELFFBQU8sS0FBSyxTQUFTLEtBQUssd0NBQXdDO01BQ25FOztFQUVGO0FBTUEsYUFBVyxDQUFDLFVBQVUsTUFBTSxLQUFLLE9BQU8sUUFBUSxVQUFVLEdBQUc7QUFDNUQsVUFBTSxFQUFFLE9BQU8sT0FBTyxPQUFNLElBQUssZUFBZSxRQUFRO0FBR3hELFFBQUksVUFBVTtBQUFhO0FBRzNCLFVBQU0sU0FBUyxRQUFRLEtBQUs7QUFDNUIsVUFBTSxZQUFZLFFBQVEsV0FBVyxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sTUFBTTtBQUUzRixpQkFBYSxRQUFRLElBQUk7TUFDeEIsR0FBRztNQUNILFVBQVUsT0FBTyxVQUFjO0FBQzlCLGNBQU0sS0FBSyxLQUFLO0FBQ2hCLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVksTUFBTSxRQUFRLE9BQU8sSUFBSSxXQUFXO0FBQ3pGLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTztBQUNuQyxjQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU8sS0FBSztBQUN4QyxjQUFNLFlBQVksU0FBUztBQUUzQixjQUFNLEtBQUssYUFBYSxhQUFhLE9BQU8sT0FBTyxXQUFXLE9BQU8sRUFBRTtNQUN4RTs7RUFFRjtBQUtBLFFBQU0sZUFBZSxRQUFRLFdBQVc7QUFDeEMsTUFBSSxjQUFjO0FBQ2pCLFVBQU0sbUJBQW1CLGFBQWEsYUFBYSxDQUFBLEdBQUksS0FBSyxDQUFDLE1BQVcsRUFBRSxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBRS9GLFFBQUksaUJBQWlCO0FBQ3BCLFlBQU0sV0FBVyxHQUFHLFdBQVc7QUFFL0IsbUJBQWEsUUFBUSxJQUFJO1FBQ3hCLE1BQU0sU0FBUyxXQUFXO1FBQzFCLFNBQVMsQ0FBQTtRQUNULFVBQVUsWUFBVztBQUNwQixnQkFBTSxLQUFLLEtBQUs7QUFDaEIsVUFBQUEsUUFBTyxLQUFLLHlCQUFvQixXQUFXLE1BQU0sRUFBRSxFQUFFO0FBQ3JELGdCQUFNLEtBQUssYUFBYSxjQUFjLEVBQUU7QUFDeEMsZ0JBQU0sS0FBSyxhQUFhLG1CQUFtQixFQUFFLEVBQUUsTUFBTSxDQUFDLFFBQU87QUFDNUQsWUFBQUEsUUFBTyxLQUFLLDZDQUE2QyxHQUFHLEVBQUU7VUFDL0QsQ0FBQztRQUNGOztJQUVGO0VBQ0Q7QUFFQSxPQUFLLHFCQUFxQixZQUFZO0FBQ3ZDOzs7QUUvR0EsU0FBUyxpQkFDUixTQUNBLE9BQ0EsT0FDQSxXQUNBLE9BQWE7QUFFYixRQUFNLFVBQVUscUJBQXFCLFNBQVMsT0FBTyxPQUFPLFNBQVM7QUFDckUsTUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLFFBQVEsUUFBUSxPQUFPO0FBQUcsV0FBTztBQUd4RCxRQUFNLGNBQWMsUUFBUSxRQUFRLEtBQUssQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBQ3pFLE1BQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxRQUFRLFlBQVksT0FBTztBQUFHLFdBQU87QUFHaEUsUUFBTSxTQUFTLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sS0FBSztBQUNsRSxTQUFPLFFBQVEsU0FBUztBQUN6QjtBQU1NLFNBQVUsZ0JBQWdCLE1BQW9CO0FBQ25ELFFBQU0sYUFBYSxpQkFBZ0I7QUFDbkMsUUFBTSxlQUFlLGVBQWM7QUFDbkMsUUFBTSxVQUFVLHFCQUFxQixVQUFVO0FBQy9DLFFBQU0saUJBQXNCLENBQUE7QUFHNUIsUUFBTSxjQUFjLEtBQUs7QUFNekIsYUFBVyxDQUFDLFlBQVksUUFBUSxLQUFLLE9BQU8sUUFBUSxZQUFZLEdBQUc7QUFDbEUsVUFBTSxFQUFFLE9BQU8sT0FBTyxPQUFNLElBQUssZUFBZSxVQUFVO0FBRzFELFFBQUksVUFBVTtBQUFhO0FBRzNCLG1CQUFlLFVBQVUsSUFBSTtNQUM1QixHQUFHO01BQ0gsVUFBVSxDQUFDLGtCQUFzQjtBQUNoQyxjQUFNLEtBQUssS0FBSztBQUNoQixjQUFNLFFBQVEsY0FBYyxRQUFRLE9BQU8sS0FBSztBQUNoRCxjQUFNLFlBQVksU0FBUztBQUczQixZQUFJLFFBQVEsY0FBYyxRQUFRLE9BQU87QUFDekMsWUFBSSxVQUFVLFFBQVc7QUFDeEIsZ0JBQU0sZUFBZSxxQkFBcUIsU0FBUyxPQUFPLE9BQU8sU0FBUztBQUMxRSxjQUFJLGNBQWMsVUFBVSxRQUFXO0FBQ3RDLG9CQUFRLGFBQWE7VUFDdEI7UUFDRDtBQUdBLFlBQUksVUFBVSxRQUFXO0FBQ3hCLGdCQUFNLFlBQVksV0FBVyxLQUFLLEdBQUcsV0FBVyxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUN6RyxjQUFJLFdBQVcsVUFBVSxRQUFXO0FBQ25DLG9CQUFRLFVBQVU7VUFDbkI7UUFDRDtBQUVBLGNBQU0sVUFBVSxLQUFLLGFBQWEsZ0JBQWdCLElBQUksT0FBTyxXQUFXLEtBQUs7QUFLN0UsWUFBSSxXQUFXLFNBQVMsT0FBTyxHQUFHO0FBQ2pDLGlCQUFPLFlBQVksVUFBYSxZQUFZO1FBQzdDO0FBR0EsY0FBTSxZQUFZLGNBQWMsUUFBUSxXQUFXLEtBQUs7QUFFeEQsWUFBSSxhQUFhLFlBQVksUUFBVztBQUV2QyxpQkFBTyxpQkFBaUIsU0FBUyxPQUFPLE9BQU8sV0FBVyxPQUFPO1FBQ2xFO0FBR0EsZUFBTyxXQUFXO01BQ25COztFQUVGO0FBRUEsT0FBSyx1QkFBdUIsY0FBYztBQUMzQzs7O0FDbkdBLE9BQU9HLFlBQVc7QUFDbEIsT0FBT0MsU0FBUTs7O0FDRGYsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sUUFBUTtBQUlmLElBQU1DLFVBQVMsbUJBQW1CLE9BQU87QUFLekMsSUFBTSx5QkFBeUI7QUFFeEIsSUFBTSwwQkFBMEI7QUFDdkMsSUFBTSxxQkFBcUIsTUFBTztBQUVsQyxTQUFTLHdCQUFxQjtBQUM3QixRQUFNLE1BQU0sT0FBTyxNQUFNLElBQUksQ0FBQztBQUM5QixRQUFNLE1BQU0sS0FBSyxNQUFNLEtBQUssT0FBTSxJQUFLLEtBQU07QUFFN0MsTUFBSSxjQUFjLE9BQVEsQ0FBQztBQUMzQixNQUFJLGNBQWMsd0JBQXdCLENBQUM7QUFDM0MsTUFBSSxjQUFjLEtBQUssQ0FBQztBQUV4QixRQUFNLE1BQU0saUJBQWdCO0FBQzVCLE1BQUksS0FBSyxLQUFLLENBQUM7QUFFZixTQUFPLEtBQUssWUFBWSxPQUFPLEVBQUUsS0FBSyxLQUFLLEVBQUU7QUFDN0MsTUFBSSxjQUFjLE1BQVEsRUFBRTtBQUM1QixNQUFJLGNBQWMsS0FBUSxFQUFFO0FBQzVCLE1BQUksY0FBYyxLQUFZLEVBQUU7QUFFaEMsU0FBTztBQUNSO0FBR0EsU0FBUyxtQkFBZ0I7QUFDeEIsTUFBSTtBQUNILFVBQU0sU0FBUyxHQUFHLGtCQUFpQjtBQUNuQyxlQUFXLFFBQVEsT0FBTyxLQUFLLE1BQU0sR0FBRztBQUN2QyxpQkFBVyxRQUFRLE9BQU8sSUFBSSxLQUFLLENBQUEsR0FBSTtBQUN0QyxZQUFJLENBQUMsS0FBSyxZQUFZLEtBQUssV0FBVyxVQUFVLEtBQUssT0FBTyxLQUFLLFFBQVEscUJBQXFCO0FBQzdGLGlCQUFPLE9BQU8sS0FBSyxLQUFLLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQWMsU0FBUyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBQzNFO01BQ0Q7SUFDRDtFQUNELFFBQVE7RUFFUjtBQUNBLFNBQU8sT0FBTyxNQUFNLEdBQUcsQ0FBQztBQUN6QjtBQUVNLFNBQVUsdUJBQXVCLEtBQWEsT0FBYTtBQUNoRSxNQUFJLElBQUksU0FBUztBQUFvQixXQUFPO0FBQzVDLE1BQUksSUFBSSxhQUFhLENBQUMsTUFBTTtBQUFRLFdBQU87QUFDM0MsTUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQXlCLFdBQU87QUFDNUQsTUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFLEVBQUUsU0FBUyxPQUFPLE1BQU07QUFBWSxXQUFPO0FBRWxFLFFBQU0sVUFBVSxDQUFDLFFBQWdCLFFBQ2hDLElBQ0UsU0FBUyxRQUFRLFNBQVMsR0FBRyxFQUM3QixTQUFTLE9BQU8sRUFDaEIsTUFBTSxJQUFJLEVBQUUsQ0FBQyxFQUNiLEtBQUk7QUFFUCxRQUFNLFFBQVEsSUFBSSxTQUFTLEdBQUcsRUFBRTtBQUNoQyxRQUFNLFdBQVcsQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQztBQUM1RSxRQUFNLE1BQU0sU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFBRSxLQUFLLEdBQUc7QUFFekUsUUFBTSxPQUFPLFFBQVEsSUFBTSxFQUFFO0FBQzdCLFFBQU0sZUFBZSxRQUFRLElBQU0sRUFBRTtBQUNyQyxRQUFNLFdBQVcsUUFBUSxLQUFNLEVBQUU7QUFDakMsUUFBTSxnQkFBZ0IsR0FBRyxJQUFJLEVBQUksQ0FBQyxJQUFJLElBQUksRUFBSSxDQUFDO0FBRS9DLE1BQUksQ0FBQztBQUFVLFdBQU87QUFJdEIsUUFBTSxRQUFRLFNBQ1osUUFBUSxjQUFjLEVBQUUsRUFDeEIsS0FBSSxFQUNKLE1BQU0sS0FBSyxFQUFFLENBQUM7QUFFaEIsU0FBTztJQUNOLElBQUk7SUFDSjtJQUNBO0lBQ0E7SUFDQSxXQUFXOztJQUNYO0lBQ0E7O0FBRUY7QUFPQSxlQUFzQixxQkFBcUIsUUFBYztBQUN4RCxTQUFPLElBQUksUUFBa0IsQ0FBQyxTQUFTLFdBQVU7QUFDaEQsVUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBRXJDLFFBQUksS0FBSyxTQUFTLENBQUMsUUFBTztBQUN6QixVQUFJLE1BQUs7QUFDVCxhQUFPLElBQUksTUFBTSxJQUFJLFdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQztJQUM3QyxDQUFDO0FBRUQsUUFBSSxRQUFRLEdBQUcsUUFBUSxNQUFLO0FBQzNCLFVBQUk7QUFDSCxjQUFNLE9BQU8sSUFBSSxRQUFPO0FBQ3hCLGNBQU0sWUFBWSxLQUFLO0FBQ3ZCLFlBQUksTUFBSztBQUVULGNBQU0sU0FBUyxHQUFHLGtCQUFpQjtBQUNuQyxtQkFBVyxRQUFRLE9BQU8sS0FBSyxNQUFNLEdBQUc7QUFDdkMscUJBQVcsU0FBUyxPQUFPLElBQUksS0FBSyxDQUFBLEdBQUk7QUFDdkMsZ0JBQ0MsTUFBTSxXQUFXLFVBQ2pCLE1BQU0sWUFBWSxhQUNsQixNQUFNLE9BQ04sTUFBTSxRQUFRLHFCQUNiO0FBQ0QscUJBQU8sUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sU0FBUyxHQUFHLEVBQUUsSUFBSSxHQUFJLENBQUM7WUFDdkU7VUFDRDtRQUNEO0FBQ0EsZUFBTyxJQUFJLE1BQU0sd0NBQXdDLFNBQVMsRUFBRSxDQUFDO01BQ3RFLFNBQVMsSUFBSTtBQUNaLGVBQU8sSUFBSSxNQUFNLE9BQU8sRUFBRSxDQUFDLENBQUM7TUFDN0I7SUFDRCxDQUFDO0VBQ0YsQ0FBQztBQUNGO0FBTUEsZUFBc0IsOEJBQThCLFFBQWM7QUFDakUsU0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFVBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUVyQyxRQUFJLFdBQVc7QUFDZixRQUFJLEtBQUssU0FBUyxDQUFDLFFBQU87QUFDekIsVUFBSSxDQUFDLFVBQVU7QUFDZCxtQkFBVztBQUNYLFlBQUksTUFBSztBQUNULGVBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO01BQzdDO0lBQ0QsQ0FBQztBQUdELFFBQUksUUFBUSxHQUFHLFFBQVEsTUFBSztBQUMzQixVQUFJO0FBQ0gsY0FBTSxPQUFPLElBQUksUUFBTztBQUN4QixjQUFNLFlBQVksS0FBSztBQUN2QixZQUFJLENBQUMsVUFBVTtBQUNkLHFCQUFXO0FBQ1gsY0FBSSxNQUFLO0FBQ1Qsa0JBQVEsU0FBUztRQUNsQjtNQUNELFNBQVMsSUFBSTtBQUNaLFlBQUksQ0FBQyxVQUFVO0FBQ2QscUJBQVc7QUFDWCxjQUFJLE1BQUs7QUFDVCxpQkFBTyxJQUFJLE1BQU0sT0FBTyxFQUFFLENBQUMsQ0FBQztRQUM3QjtNQUNEO0lBQ0QsQ0FBQztFQUNGLENBQUM7QUFDRjtBQVdBLGVBQXNCLGdCQUNyQixVQUNBLGtCQUNBLFlBQVksS0FBSTtBQUVoQixRQUFNLHVCQUF1QjtBQUM3QixRQUFNLHNCQUFzQjtBQUM1QixRQUFNLGVBQWU7QUFFckIsUUFBTSxhQUFhLG9CQUFJLElBQUc7QUFFMUIsU0FBTyxJQUFJLFFBQWMsQ0FBQyxZQUFXO0FBQ3BDLFVBQU0saUJBQWlCLE1BQU0sYUFBYSxFQUFFLE1BQU0sUUFBUSxXQUFXLEtBQUksQ0FBRTtBQUMzRSxVQUFNLG1CQUE2QixDQUFBO0FBRW5DLFVBQU0sVUFBVSxNQUFLO0FBQ3BCLGlCQUFXLFNBQVMsa0JBQWtCO0FBQ3JDLFlBQUk7QUFDSCx5QkFBZSxlQUFlLHNCQUFzQixLQUFLO1FBQzFELFFBQVE7UUFFUjtNQUNEO0FBQ0EsVUFBSTtBQUNILHVCQUFlLE1BQUs7TUFDckIsUUFBUTtNQUVSO0FBQ0EsY0FBTztJQUNSO0FBRUEsVUFBTSxRQUFRLFdBQVcsU0FBUyxTQUFTO0FBQzNDLFVBQU0sUUFBTztBQUViLG1CQUFlLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDbEMsTUFBQUEsUUFBTyxLQUFLLDBCQUEwQixJQUFJLE9BQU8sRUFBRTtJQUNwRCxDQUFDO0FBRUQsbUJBQWUsR0FBRyxXQUFXLENBQUMsS0FBSyxVQUFTO0FBQzNDLFlBQU0sUUFBUSxNQUFNO0FBRXBCLFVBQUksSUFBSSxTQUFTO0FBQUk7QUFDckIsVUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQVE7QUFDcEMsVUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFLEVBQUUsU0FBUyxPQUFPLE1BQU07QUFBWTtBQUUzRCxVQUFJLFdBQVcsSUFBSSxLQUFLO0FBQUc7QUFDM0IsaUJBQVcsSUFBSSxLQUFLO0FBQ3BCLE1BQUFBLFFBQU8sTUFBTSxpQkFBaUIsS0FBSywrQkFBMEI7QUFLN0QsWUFBTSxZQUFZLFlBQVc7QUFDNUIsY0FBTSxpQkFBaUIsS0FBSztBQUM1QixjQUFNLFFBQVEsc0JBQXFCO0FBQ25DLGlCQUFTLEtBQUssT0FBTyxjQUFjLE9BQU8sQ0FBQyxRQUFPO0FBQ2pELGNBQUk7QUFBSyxZQUFBQSxRQUFPLEtBQUssb0JBQW9CLEtBQUssWUFBWSxJQUFJLE9BQU8sRUFBRTtRQUN4RSxDQUFDO01BQ0Y7QUFDQSxnQkFBUyxFQUFHLE1BQU0sQ0FBQyxRQUFRQSxRQUFPLEtBQUssdUJBQXVCLEdBQUcsRUFBRSxDQUFDO0lBQ3JFLENBQUM7QUFFRCxtQkFBZSxLQUFLLHFCQUFxQixNQUFLO0FBSzdDLFlBQU0sU0FBUyxHQUFHLGtCQUFpQjtBQUNuQyxpQkFBVyxTQUFTLE9BQU8sT0FBTyxNQUFNLEdBQUc7QUFDMUMsbUJBQVcsUUFBUSxTQUFTLENBQUEsR0FBSTtBQUMvQixjQUFJLEtBQUssV0FBVyxVQUFVLENBQUMsS0FBSyxVQUFVO0FBQzdDLGdCQUFJO0FBQ0gsNkJBQWUsY0FBYyxzQkFBc0IsS0FBSyxPQUFPO0FBQy9ELCtCQUFpQixLQUFLLEtBQUssT0FBTztZQUNuQyxRQUFRO1lBRVI7VUFDRDtRQUNEO01BQ0Q7QUFDQSxVQUFJLGlCQUFpQixXQUFXLEdBQUc7QUFDbEMsUUFBQUEsUUFBTyxLQUFLLDBEQUEwRDtNQUN2RSxPQUFPO0FBQ04sUUFBQUEsUUFBTyxNQUFNLG9DQUFvQyxvQkFBb0IsSUFBSSxtQkFBbUIsRUFBRTtNQUMvRjtJQUNELENBQUM7RUFDRixDQUFDO0FBQ0Y7QUFLQSxJQUFNLGlCQUFpQixvQkFBSSxJQUFHO0FBYzlCLGVBQXNCLGtCQUFrQixVQUFrQixZQUFZLEtBQUk7QUFDekUsUUFBTSxVQUFVLGVBQWUsSUFBSSxRQUFRO0FBQzNDLE1BQUk7QUFBUyxXQUFPO0FBRXBCLFFBQU0sVUFBVSxpQkFBaUIsVUFBVSxTQUFTLEVBQUUsUUFBUSxNQUFLO0FBQ2xFLG1CQUFlLE9BQU8sUUFBUTtFQUMvQixDQUFDO0FBQ0QsaUJBQWUsSUFBSSxVQUFVLE9BQU87QUFDcEMsU0FBTztBQUNSO0FBRUEsZUFBZSxpQkFBaUIsVUFBa0IsV0FBaUI7QUFDbEUsU0FBTyxJQUFJLFFBQTZCLENBQUMsWUFBVztBQUNuRCxRQUFJLFVBQVU7QUFDZCxRQUFJLGlCQUF3RDtBQUU1RCxVQUFNLGVBQWUsQ0FBQ0MsVUFBc0I7QUFDM0MsVUFBSSxnQkFBZ0I7QUFDbkIsc0JBQWMsY0FBYztBQUM1Qix5QkFBaUI7TUFDbEI7QUFDQSxVQUFJO0FBQ0gsUUFBQUEsTUFBSyxNQUFLO01BQ1gsUUFBUTtNQUVSO0FBQ0EsTUFBQUQsUUFBTyxNQUFNLDZCQUE2QixRQUFRLEVBQUU7SUFDckQ7QUFFQSxVQUFNLE9BQU8sQ0FBQ0MsVUFBc0I7QUFDbkMsVUFBSTtBQUFTO0FBQ2IsZ0JBQVU7QUFDVixtQkFBYSxLQUFLO0FBQ2xCLG1CQUFhQSxLQUFJO0FBQ2pCLE1BQUFELFFBQU8sTUFBTSxzQ0FBc0MsUUFBUSxtQ0FBOEI7QUFDekYsY0FBUSxJQUFJO0lBQ2I7QUFJQSxVQUFNLE9BQU8sTUFBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBQ2pFLFVBQU0sUUFBUSxXQUFXLE1BQU0sS0FBSyxJQUFJLEdBQUcsU0FBUztBQUVwRCxTQUFLLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDeEIsTUFBQUEsUUFBTyxLQUFLLDJCQUEyQixRQUFRLEtBQUssSUFBSSxPQUFPLEVBQUU7QUFDakUsV0FBSyxJQUFJO0lBQ1YsQ0FBQztBQUVELFNBQUssR0FBRyxXQUFXLENBQUMsUUFBZTtBQUVsQyxVQUFJLENBQUMsV0FBVyxJQUFJLFVBQVUsS0FBSyxJQUFJLENBQUMsTUFBTSxNQUFRLElBQUksQ0FBQyxNQUFNLElBQU07QUFDdEUsa0JBQVU7QUFDVixxQkFBYSxLQUFLO0FBQ2xCLFFBQUFBLFFBQU8sS0FBSyxtQ0FBbUMsUUFBUSxFQUFFO0FBS3pELFlBQUksZUFBZSxLQUFLLE1BQU0sS0FBSyxPQUFNLElBQUssS0FBTSxJQUFJO0FBQ3hELGNBQU0sZ0JBQWdCLE1BQUs7QUFDMUIsZ0JBQU0sTUFBTSxPQUFPLE1BQU0sSUFBSSxDQUFDO0FBQzlCLGNBQUksQ0FBQyxJQUFJO0FBQ1QsY0FBSSxDQUFDLElBQUk7QUFDVCxjQUFJLGNBQWMsaUJBQWlCLE9BQVEsQ0FBQztBQUM1QyxjQUFJLENBQUMsSUFBSTtBQUNULGNBQUksQ0FBQyxJQUFJO0FBQ1QsZUFBSyxLQUFLLEtBQUssTUFBTSxVQUFVLE1BQUs7VUFFcEMsQ0FBQztRQUNGO0FBQ0EseUJBQWlCLFlBQVksZUFBZSxHQUFJO0FBR2hELGdCQUFRLE1BQU0sYUFBYSxJQUFJLENBQUM7TUFDakM7SUFDRCxDQUFDO0FBRUQsVUFBTSxTQUFTLFlBQVc7QUFDekIsVUFBSTtBQUNKLFVBQUk7QUFDSixVQUFJO0FBQ0gsa0JBQVUsTUFBTSw4QkFBOEIsUUFBUTtBQUN0RCxtQkFBVyxNQUFNLHFCQUFxQixRQUFRO01BQy9DLFNBQVMsR0FBRztBQUNYLFFBQUFBLFFBQU8sS0FBSyxnREFBZ0QsUUFBUSxLQUFLLENBQUMsRUFBRTtBQUM1RSxhQUFLLElBQUk7QUFDVDtNQUNEO0FBS0EsV0FBSyxLQUFLLEVBQUUsTUFBTSxNQUFNLFNBQVMsUUFBTyxHQUFJLE1BQUs7QUFDaEQsY0FBTSxNQUFNLEtBQUssTUFBTSxLQUFLLE9BQU0sSUFBSyxLQUFNLElBQUk7QUFFakQsY0FBTSxNQUFNLE9BQU8sTUFBTSxJQUFJLENBQUM7QUFDOUIsWUFBSSxDQUFDLElBQUk7QUFDVCxZQUFJLENBQUMsSUFBSTtBQUNULFlBQUksY0FBYyxLQUFLLENBQUM7QUFDeEIsWUFBSSxDQUFDLElBQUk7QUFDVCxZQUFJLENBQUMsSUFBSTtBQUNULGlCQUFTLFFBQVEsQ0FBQyxHQUFHLE1BQUs7QUFDekIsY0FBSSxLQUFLLENBQUMsSUFBSTtRQUNmLENBQUM7QUFDRCxRQUFBQSxRQUFPLE1BQU0sZ0JBQWdCLFFBQVEsS0FBSyxJQUFJLFNBQVMsS0FBSyxDQUFDLEVBQUU7QUFDL0QsYUFBSyxLQUFLLEtBQUssTUFBTSxVQUFVLENBQUMsUUFBTztBQUN0QyxjQUFJLEtBQUs7QUFDUixZQUFBQSxRQUFPLEtBQUssMEJBQTBCLFFBQVEsS0FBSyxJQUFJLE9BQU8sRUFBRTtBQUNoRSxpQkFBSyxJQUFJO1VBQ1Y7UUFDRCxDQUFDO01BQ0YsQ0FBQztJQUNGO0FBRUEsV0FBTSxFQUFHLE1BQU0sQ0FBQyxNQUFLO0FBQ3BCLE1BQUFBLFFBQU8sS0FBSywwQkFBMEIsUUFBUSxLQUFLLENBQUMsRUFBRTtBQUN0RCxXQUFLLElBQUk7SUFDVixDQUFDO0VBQ0YsQ0FBQztBQUNGO0FBZUEsZUFBc0IsWUFDckIsVUFDQSxrQkFDQSxnQkFDQSxrQkFDQSxJQUNBLFlBQVksS0FBSTtBQUVoQixTQUFPLElBQUksUUFBMkIsQ0FBQyxZQUFXO0FBQ2pELFVBQU0sTUFBTSxXQUFXLEVBQUU7QUFDekIsUUFBSSxXQUFXO0FBRWYsVUFBTSxTQUFTLENBQUMsV0FBNkI7QUFDNUMsVUFBSTtBQUFVO0FBQ2QsaUJBQVc7QUFDWCxxQkFBZSxHQUFHO0FBQ2xCLGNBQVEsTUFBTTtJQUNmO0FBRUEscUJBQWlCLEtBQUssQ0FBQyxXQUFzQjtBQUM1QyxVQUFJLE9BQU8sT0FBTztBQUFJLGVBQU8sTUFBTTtJQUNwQyxDQUFDO0FBRUQsVUFBTSxRQUFRLFdBQVcsTUFBTSxPQUFPLElBQUksR0FBRyxTQUFTO0FBQ3RELFVBQU0sUUFBTztBQUViLFVBQU0sTUFBTSxZQUFXO0FBQ3RCLFlBQU0saUJBQWlCLEVBQUU7QUFDekIsWUFBTSxRQUFRLHNCQUFxQjtBQUNuQyxlQUFTLEtBQUssT0FBTyxNQUFNLElBQUksQ0FBQyxRQUFPO0FBQ3RDLFlBQUksS0FBSztBQUNSLFVBQUFBLFFBQU8sS0FBSyxZQUFZLEVBQUUsWUFBWSxJQUFJLE9BQU8sRUFBRTtBQUNuRCx1QkFBYSxLQUFLO0FBQ2xCLGlCQUFPLElBQUk7UUFDWjtNQUNELENBQUM7SUFDRjtBQUVBLFFBQUcsRUFBRyxNQUFNLENBQUMsTUFBSztBQUNqQixNQUFBQSxRQUFPLEtBQUssZ0NBQWdDLEVBQUUsS0FBSyxDQUFDLEVBQUU7QUFDdEQsbUJBQWEsS0FBSztBQUNsQixhQUFPLElBQUk7SUFDWixDQUFDO0VBQ0YsQ0FBQztBQUNGOzs7QUQ1YUEsSUFBTUUsVUFBUyxtQkFBbUIsY0FBYztBQUUxQyxJQUFPLGVBQVAsTUFBTyxjQUFZO0VBQ1AsY0FBc0I7RUFDdEIsaUJBQWlCO0VBQ2pCLFNBQVM7RUFFbEI7RUFDQTs7RUFDQSxjQUdKLG9CQUFJLElBQUc7RUFDSCxtQkFBZ0Msb0JBQUksSUFBRzs7O0VBR3ZDLFlBQTJCLFFBQVEsUUFBTzs7RUFHMUMsc0JBQXNCOztFQUd0Qjs7RUFHQSxRQUFnQjtFQUNoQixVQUFzQixDQUFBOzs7Ozs7O0VBUXRCLGNBQWdELG9CQUFJLElBQUc7Ozs7Ozs7RUFRdkQsZ0JBQTZCLG9CQUFJLElBQUc7O0VBR3BDLHFCQUFnRSxvQkFBSSxJQUFHOztFQUd2RTs7RUFHQSxXQUFrQyxvQkFBSSxJQUFHOztFQUd6QyxxQkFBa0Msb0JBQUksSUFBRzs7RUFHekMsa0JBQTJDLG9CQUFJLElBQUc7RUFFMUQsY0FBQTtBQUNDLElBQUFBLFFBQU8sS0FBSywwQkFBMEI7QUFJdEMsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFDcEUsU0FBSyxVQUFVLElBQUksUUFBYyxDQUFDLFlBQVc7QUFDNUMsV0FBSyxTQUFTLEtBQUssR0FBRyxNQUFLO0FBQzFCLFFBQUFELFFBQU8sTUFBTSwyQkFBNEIsS0FBSyxTQUFTLFFBQU8sRUFBd0IsSUFBSSxFQUFFO0FBQzVGLGdCQUFPO01BQ1IsQ0FBQztJQUNGLENBQUM7QUFDRCxTQUFLLFNBQVMsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNqQyxNQUFBQSxRQUFPLE1BQU0sb0JBQW9CLEdBQUcsRUFBRTtJQUN2QyxDQUFDO0FBR0QsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFFcEUsU0FBSyxTQUFTLEdBQUcsYUFBYSxNQUFLO0FBQ2xDLFlBQU0sT0FBTyxLQUFLLFNBQVMsUUFBTztBQUNsQyxNQUFBRCxRQUFPLE1BQU0sMEJBQTBCLEtBQUssVUFBVSxJQUFJLENBQUMsRUFBRTtBQUM3RCxVQUFJO0FBQ0gsYUFBSyxTQUFTLHFCQUFxQixJQUFJO01BQ3hDLFNBQVMsSUFBSTtNQUViO0lBQ0QsQ0FBQztBQUVELFNBQUssU0FBUyxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ2pDLE1BQUFBLFFBQU8sTUFBTSxvQkFBb0IsR0FBRyxFQUFFO0lBQ3ZDLENBQUM7QUFFRCxTQUFLLFNBQVMsR0FBRyxXQUFXLENBQUMsS0FBSyxVQUFTO0FBQzFDLFVBQUk7QUFDSCxhQUFLLGVBQWUsS0FBSyxNQUFNLE9BQU87TUFDdkMsU0FBUyxJQUFJO0FBQ1osUUFBQUEsUUFBTyxNQUFNLG9DQUFvQyxFQUFFLEVBQUU7TUFDdEQ7SUFDRCxDQUFDO0FBTUQsU0FBSyxTQUFTLEtBQUssRUFBRSxTQUFTLFdBQVcsTUFBTSxLQUFLLE9BQU0sR0FBSSxNQUFLO0FBQ2xFLE1BQUFBLFFBQU8sTUFBTSw4QkFBOEIsS0FBSyxNQUFNLEVBQUU7QUFDeEQsWUFBTSxTQUFTRSxJQUFHLGtCQUFpQjtBQUNuQyxpQkFBVyxTQUFTLE9BQU8sT0FBTyxNQUFNLEdBQUc7QUFDMUMsbUJBQVcsUUFBUSxTQUFTLENBQUEsR0FBSTtBQUMvQixjQUFJLEtBQUssV0FBVyxVQUFVLENBQUMsS0FBSyxZQUFZLENBQUMsS0FBSyxpQkFBaUIsSUFBSSxLQUFLLE9BQU8sR0FBRztBQUN6RixnQkFBSTtBQUNILG1CQUFLLFNBQVMsY0FBYyxLQUFLLGdCQUFnQixLQUFLLE9BQU87QUFDN0QsbUJBQUssaUJBQWlCLElBQUksS0FBSyxPQUFPO0FBQ3RDLGNBQUFGLFFBQU8sTUFBTSx3QkFBd0IsS0FBSyxjQUFjLE9BQU8sS0FBSyxPQUFPLEVBQUU7WUFDOUUsU0FBUyxJQUFJO0FBQ1osY0FBQUEsUUFBTyxLQUFLLG1DQUFtQyxLQUFLLE9BQU8sS0FBSyxPQUFPLEVBQUUsQ0FBQyxFQUFFO1lBQzdFO1VBQ0Q7UUFDRDtNQUNEO0lBQ0QsQ0FBQztFQUNGO0VBRU8sUUFBSztBQUVYLGVBQVcsV0FBVyxLQUFLLGdCQUFnQixPQUFNLEdBQUk7QUFDcEQsVUFBSTtBQUNILGdCQUFPO01BQ1IsUUFBUTtNQUVSO0lBQ0Q7QUFDQSxTQUFLLGdCQUFnQixNQUFLO0FBQzFCLFFBQUk7QUFDSCxpQkFBVyxhQUFhLE1BQU0sS0FBSyxLQUFLLGdCQUFnQixHQUFHO0FBQzFELFlBQUk7QUFDSCxlQUFLLFNBQVMsZUFBZSxLQUFLLGdCQUFnQixTQUFTO1FBQzVELFFBQVE7UUFFUjtNQUNEO0lBQ0QsUUFBUTtJQUVSO0FBQ0EsUUFBSTtBQUNILFdBQUssU0FBUyxNQUFLO0lBQ3BCLFFBQVE7SUFFUjtBQUNBLFFBQUk7QUFDSCxXQUFLLFNBQVMsTUFBSztJQUNwQixRQUFRO0lBRVI7RUFDRDs7Ozs7RUFNTyxTQUFTLE9BQWUsU0FBbUI7QUFDakQsU0FBSyxRQUFRO0FBQ2IsU0FBSyxVQUFVO0VBQ2hCOzs7OztFQU1PLG9CQUFvQixVQUFzQztBQUNoRSxTQUFLLG1CQUFtQjtFQUN6Qjs7RUFHTyxtQkFBbUIsSUFBVTtBQUNuQyxXQUFPLEtBQUssY0FBYyxJQUFJLEVBQUU7RUFDakM7O0VBR08sZ0JBQWdCLElBQVU7QUFDaEMsU0FBSyxjQUFjLElBQUksRUFBRTtBQUN6QixJQUFBQSxRQUFPLE1BQU0sd0JBQXdCLEVBQUUsRUFBRTtFQUMxQzs7RUFHTyxhQUFhLElBQVU7QUFDN0IsU0FBSyxjQUFjLE9BQU8sRUFBRTtBQUM1QixTQUFLLFlBQVksT0FBTyxFQUFFO0FBQzFCLFNBQUssU0FBUyxPQUFPLEVBQUU7QUFDdkIsU0FBSyxtQkFBbUIsT0FBTyxFQUFFO0FBQ2pDLFNBQUssZ0JBQWdCLElBQUksRUFBRSxJQUFHO0FBQzlCLFNBQUssZ0JBQWdCLE9BQU8sRUFBRTtBQUM5QixJQUFBQSxRQUFPLE1BQU0scUJBQXFCLEVBQUUsRUFBRTtFQUN2Qzs7Ozs7RUFNTyxNQUFNLFlBQVksVUFBZ0I7QUFDeEMsUUFBSSxLQUFLLG1CQUFtQixJQUFJLFFBQVE7QUFBRyxhQUFPO0FBQ2xELFVBQU0sVUFBVSxNQUFNLGtCQUFrQixRQUFRO0FBQ2hELFVBQU0sVUFBVSxZQUFZO0FBRzVCLFNBQUssbUJBQW1CLElBQUksUUFBUTtBQUNwQyxRQUFJLFNBQVM7QUFDWixXQUFLLGdCQUFnQixJQUFJLFVBQVUsT0FBTztJQUMzQztBQUNBLFdBQU87RUFDUjs7Ozs7OztFQVFPLE1BQU0sWUFBWSxJQUFZLFlBQVksS0FBSTtBQUNwRCxVQUFNLEtBQUs7QUFDWCxXQUFPLFlBQ04sS0FBSyxVQUNMLENBQUMsS0FBSyxPQUFPLEtBQUssbUJBQW1CLElBQUksS0FBSyxFQUFFLEdBQ2hELENBQUMsUUFBUSxLQUFLLG1CQUFtQixPQUFPLEdBQUcsR0FDM0MsT0FBTyxXQUFXLEtBQUssb0JBQW9CLE1BQU0sR0FDakQsSUFDQSxTQUFTO0VBRVg7Ozs7O0VBTU8sTUFBTSxtQkFBbUIsVUFBZ0I7QUFDL0MsSUFBQUEsUUFBTyxLQUFLLGdDQUFnQyxRQUFRLEVBQUU7QUFDdEQsVUFBTSxXQUFXLE1BQU0sS0FBSyxhQUFhLHNCQUFzQixRQUFXLFFBQVcsUUFBVyxVQUFVLEtBQUs7QUFFL0csV0FBTztFQUNSOzs7Ozs7O0VBUU8sTUFBTSxnQkFBZ0IsWUFBWSxLQUFJO0FBQzVDLFVBQU0sZ0JBQWdCO0FBQ3RCLFVBQU0sZUFBNkIsQ0FBQTtBQUVuQyxTQUFLLG1CQUFtQixJQUFJLGVBQWUsQ0FBQyxXQUFzQjtBQUNqRSxVQUFJLENBQUMsYUFBYSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTyxFQUFFLEdBQUc7QUFDbEQscUJBQWEsS0FBSyxNQUFNO01BQ3pCO0lBQ0QsQ0FBQztBQUVELFFBQUk7QUFDSCxZQUFNLEtBQUs7QUFDWCxZQUFNLGdCQUFnQixLQUFLLFVBQVUsT0FBTyxXQUFXLEtBQUssb0JBQW9CLE1BQU0sR0FBRyxTQUFTO0FBQ2xHLGFBQU87SUFDUjtBQUNDLFdBQUssbUJBQW1CLE9BQU8sYUFBYTtJQUM3QztFQUNEOzs7OztFQU1PLE1BQU0sdUJBQXVCLFVBQWdCO0FBQ25ELElBQUFBLFFBQU8sS0FBSyxvQ0FBb0MsUUFBUSxFQUFFO0FBQzFELFVBQU0sV0FBVyxNQUFNLEtBQUssYUFBYSxrQkFBa0IsUUFBVyxRQUFXLFFBQVcsVUFBVSxLQUFLO0FBSTNHLFVBQU0sWUFBWTtBQUVsQixRQUFJLFNBQVMsU0FBUyxZQUFZLEdBQUc7QUFDcEMsTUFBQUEsUUFBTyxLQUFLLGdDQUFnQyxTQUFTLE1BQU0sUUFBUTtBQUNuRSxhQUFPO0lBQ1I7QUFHQSxVQUFNLFFBQVEsU0FBUyxZQUFZLENBQUM7QUFDcEMsVUFBTSxRQUFRLFNBQVMsWUFBWSxDQUFDO0FBRXBDLFVBQU0sV0FDTCxRQUFRLEtBQ0wsTUFBTSxTQUFRLEVBQUcsU0FBUyxHQUFHLEdBQUcsSUFDaEMsTUFBTSxTQUFRO0FBRWxCLFVBQU0sV0FBVyxHQUFHLEtBQUssSUFBSSxRQUFRO0FBRXJDLElBQUFBLFFBQU8sTUFBTSxxQkFBcUIsUUFBUSxFQUFFO0FBQzVDLFdBQU87RUFDUjs7Ozs7RUFNUSxNQUFNLG9CQUFvQixRQUFjO0FBQy9DLFFBQUk7QUFDSCxZQUFNLFlBQVksTUFBTSw4QkFBOEIsTUFBTTtBQUM1RCxVQUFJLENBQUMsV0FBVztBQUNmLFFBQUFBLFFBQU8sS0FBSyxxREFBcUQsTUFBTSxFQUFFO0FBQ3pFO01BQ0Q7QUFFQSxVQUFJLEtBQUssaUJBQWlCLElBQUksU0FBUyxHQUFHO0FBRXpDO01BQ0Q7QUFFQSxVQUFJO0FBQ0gsYUFBSyxTQUFTLGNBQWMsS0FBSyxnQkFBZ0IsU0FBUztBQUMxRCxhQUFLLGlCQUFpQixJQUFJLFNBQVM7QUFDbkMsUUFBQUEsUUFBTyxLQUFLLG9CQUFvQixLQUFLLGNBQWMsT0FBTyxTQUFTLEVBQUU7TUFDdEUsU0FBUyxJQUFJO0FBQ1osUUFBQUEsUUFBTyxLQUFLLCtCQUErQixTQUFTLEtBQUssT0FBTyxFQUFFLENBQUMsRUFBRTtNQUN0RTtJQUNELFNBQVMsSUFBSTtBQUNaLE1BQUFBLFFBQU8sS0FBSywrQkFBK0IsRUFBRSxFQUFFO0lBQ2hEO0VBQ0Q7RUFFTyxNQUFNLGFBQ1osT0FDQSxPQUNBLFdBQ0EsT0FDQSxRQUNBLFNBQVMsTUFBSTtBQUViLFNBQUs7QUFDTCxXQUFPLElBQUksUUFBZ0IsQ0FBQyxTQUFTLFdBQVU7QUFDOUMsV0FBSyxZQUFZLEtBQUssVUFBVSxLQUFLLFlBQ3BDLEtBQUssY0FBYyxPQUFPLE9BQU8sV0FBVyxPQUFPLFFBQVEsTUFBTSxFQUMvRCxLQUFLLENBQUMsUUFBTztBQUNiLGFBQUs7QUFHTCxZQUFJLEtBQUssd0JBQXdCLEtBQUssVUFBVSxRQUFXO0FBQzFELGVBQUssbUJBQW1CLE1BQU0sRUFBRSxNQUFNLENBQUMsUUFBTztBQUM3QyxZQUFBQSxRQUFPLEtBQUssNkNBQTZDLEdBQUcsRUFBRTtVQUMvRCxDQUFDO1FBQ0Y7QUFDQSxnQkFBUSxHQUFHO01BQ1osQ0FBQyxFQUNBLE1BQU0sQ0FBQyxRQUFPO0FBQ2QsYUFBSztBQUNMLGVBQU8sZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUM7TUFDM0QsQ0FBQyxDQUFDO0lBRUwsQ0FBQztFQUNGO0VBRVEsTUFBTSxjQUNiLE9BQ0EsT0FDQSxXQUNBLE9BQ0EsUUFDQSxTQUFTLE1BQUk7QUFFYixVQUFNLFlBQVk7QUFFbEIsVUFBTSxZQUFzQixDQUFBO0FBQzVCLFFBQUksY0FBYztBQUFXLGdCQUFVLEtBQUssWUFBWSxHQUFJO0FBQzVELFFBQUksVUFBVTtBQUFXLGdCQUFVLEtBQUssR0FBRyxjQUFhLGdCQUFnQixLQUFLLENBQUM7QUFFOUUsVUFBTSxjQUF3QixDQUFDLElBQU0sUUFBUSxHQUFJO0FBRWpELFFBQUksVUFBVSxlQUFlLFVBQVUsVUFBYSxjQUFjLFVBQWEsVUFBVSxRQUFXO0FBSW5HLFVBQUksQ0FBQyxLQUFLLFlBQVksSUFBSSxNQUFNO0FBQUcsYUFBSyxZQUFZLElBQUksUUFBUSxvQkFBSSxJQUFHLENBQUU7QUFDekUsWUFBTSxVQUFVLEtBQUssWUFBWSxJQUFJLE1BQU07QUFDM0MsWUFBTSxlQUFlO0FBQ3JCLFlBQU0sWUFBc0IsQ0FBQTtBQUM1QixlQUFTLElBQUksR0FBRyxJQUFJLGNBQWMsS0FBSztBQUN0QyxjQUFNLFdBQVcsY0FBYyxLQUFLLE9BQU8sYUFBYSxHQUFHLEtBQUs7QUFDaEUsY0FBTSxNQUFNLE1BQU0sWUFBWSxPQUFPLEtBQUssSUFBSyxRQUFRLElBQUksUUFBUSxLQUFLO0FBQ3hFLGtCQUFVLEtBQUssR0FBRztBQUNsQixnQkFBUSxJQUFJLFVBQVUsR0FBRztNQUMxQjtBQUNBLGtCQUFZLEtBQUssUUFBUSxLQUFNLEdBQUcsU0FBUztJQUM1QyxPQUFPO0FBQ04sVUFBSSxVQUFVO0FBQVcsb0JBQVksS0FBSyxRQUFRLEdBQUk7QUFDdEQsVUFBSTtBQUFRLG9CQUFZLEtBQUssVUFBVSxNQUFNO0FBQzdDLFVBQUksVUFBVSxTQUFTO0FBQUcsb0JBQVksS0FBSyxHQUFHLFNBQVM7SUFDeEQ7QUFFQSxVQUFNLE1BQU0sY0FBYSxVQUFVLFdBQVc7QUFDOUMsVUFBTSxpQkFBaUIsT0FBTyxLQUFLLENBQUMsR0FBRyxhQUFhLEdBQUcsQ0FBQztBQUd4RCxRQUFJLGNBQWMsVUFBYSxVQUFVLFFBQVc7QUFDbkQsWUFBTSxhQUFhLGNBQWEsZ0JBQWdCLEtBQUs7QUFDckQsWUFBTSxVQUF5QjtRQUM5QixRQUFRO1FBQ1IsSUFBSTtRQUNKO1FBQ0E7O0FBRUQsTUFBQUEsUUFBTyxLQUFLLE1BQU0sTUFBTSxNQUFNLG9CQUFvQixTQUFTLEtBQUssT0FBTyxDQUFDLEVBQUU7SUFDM0UsT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSyxNQUFNLE1BQU0sTUFBTSxlQUFlLEtBQUssQ0FBQyxFQUFFO0lBQ3REO0FBSUEsUUFBSSxDQUFDLEtBQUssY0FBYyxJQUFJLE1BQU0sR0FBRztBQUNwQyxNQUFBQSxRQUFPLE1BQU0scURBQWdELE1BQU0sS0FBSyxlQUFlLFNBQVMsS0FBSyxDQUFDLEVBQUU7QUFDeEcsWUFBTSxJQUFJLE1BQU0sYUFBYSxNQUFNLGlGQUE0RTtJQUNoSDtBQUlBLFFBQUksQ0FBQyxLQUFLLG1CQUFtQixJQUFJLE1BQU0sR0FBRztBQUN6QyxZQUFNLEtBQUssWUFBWSxNQUFNO0lBRTlCO0FBR0EsVUFBTSxLQUFLLG9CQUFvQixNQUFNO0FBRXJDLFVBQU0sV0FBVyxLQUFLLGVBQWU7QUFDckMsVUFBTSxTQUFTLE1BQU0sS0FBSyxZQUFZLFVBQVUsTUFBTTtBQUN0RCxVQUFNLFNBQVMsT0FBTyxPQUFPLENBQUMsUUFBUSxjQUFjLENBQUM7QUFFckQsSUFBQUEsUUFBTyxNQUFNLHFCQUFxQixNQUFNLEtBQUssT0FBTyxTQUFTLEtBQUssQ0FBQyxFQUFFO0FBRXJFLFVBQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxLQUFLO0FBRTlCLFdBQU8sSUFBSSxRQUFnQixDQUFDLFNBQVMsV0FBVTtBQUM5QyxZQUFNLFFBQVEsV0FBVyxNQUFLO0FBQzdCLGFBQUssWUFBWSxPQUFPLEdBQUc7QUFDM0IsZUFBTyxJQUFJLE1BQU0sc0NBQXNDLEtBQUssS0FBSyxPQUFPLE1BQU0sT0FBTyxDQUFDO01BQ3ZGLEdBQUcsU0FBUztBQUVaLFdBQUssWUFBWSxJQUFJLEtBQUs7UUFDekIsU0FBUyxDQUFDLFFBQU87QUFDaEIsdUJBQWEsS0FBSztBQUNsQixrQkFBUSxHQUFHO1FBQ1o7UUFDQSxRQUFRLENBQUMsUUFBTztBQUNmLHVCQUFhLEtBQUs7QUFDbEIsaUJBQU8sR0FBRztRQUNYO1FBQ0E7T0FDQTtBQUVELFdBQUssU0FBUyxLQUFLLFFBQVEsS0FBSyxhQUFhLFFBQVEsQ0FBQyxRQUFPO0FBQzVELFlBQUksS0FBSztBQUNSLGVBQUssWUFBWSxPQUFPLEdBQUc7QUFDM0IsdUJBQWEsS0FBSztBQUNsQixpQkFBTyxJQUFJLE1BQU0sSUFBSSxXQUFXLE9BQU8sR0FBRyxDQUFDLENBQUM7UUFDN0M7TUFDRCxDQUFDO0lBQ0YsQ0FBQztFQUNGO0VBRVEsZUFBZSxLQUFhLE9BQWE7QUFDaEQsUUFBSSxJQUFJLFNBQVM7QUFBRztBQUNwQixRQUFJLElBQUksQ0FBQyxNQUFNLE9BQVEsSUFBSSxDQUFDLE1BQU07QUFBTTtBQUV4QyxVQUFNLFVBQVUsSUFBSSxhQUFhLENBQUM7QUFLbEMsUUFBSSxZQUFZLDJCQUEyQixLQUFLLG1CQUFtQixPQUFPLEdBQUc7QUFDNUUsWUFBTSxTQUFTLHVCQUF1QixLQUFLLEtBQUs7QUFDaEQsVUFBSSxRQUFRO0FBQ1gsUUFBQUEsUUFBTyxNQUNOLDRCQUE0QixLQUFLLGVBQ25CLE9BQU8sSUFBSSxhQUNkLE9BQU8sS0FBSyxpQkFDUixPQUFPLFNBQVMsb0JBQ2IsT0FBTyxZQUFZLEdBQUc7QUFJekMsWUFBSSxPQUFPLFNBQVMsWUFBWTtBQUMvQixxQkFBVyxNQUFNLEtBQUssbUJBQW1CLE9BQU0sR0FBSTtBQUNsRCxnQkFBSTtBQUNILGlCQUFHLE1BQU07WUFDVixRQUFRO1lBRVI7VUFDRDtRQUNELE9BQU87QUFDTixVQUFBQSxRQUFPLE1BQU0sc0RBQXNELE9BQU8sSUFBSSxPQUFPLEtBQUssRUFBRTtRQUM3RjtNQUNEO0FBQ0E7SUFDRDtBQUVBLFFBQUksSUFBSSxTQUFTO0FBQUk7QUFHckIsVUFBTSxNQUFNLElBQUksU0FBUyxJQUFJLEVBQUU7QUFDL0IsUUFBSSxJQUFJLFNBQVMsT0FBTyxNQUFNO0FBQVk7QUFNMUMsUUFBSSxDQUFDLEtBQUssY0FBYyxJQUFJLEtBQUssR0FBRztBQUNuQyxNQUFBQSxRQUFPLE1BQU0scURBQXFELEtBQUssRUFBRTtBQUN6RTtJQUNEO0FBSUEsVUFBTSxZQUFZLElBQUksU0FBUyxFQUFFO0FBQ2pDLFFBQUksVUFBVSxTQUFTO0FBQUc7QUFDMUIsUUFBSSxVQUFVLENBQUMsTUFBTTtBQUFNO0FBRzNCLFVBQU0sWUFBWSxVQUFVLENBQUM7QUFDN0IsVUFBTSxjQUFjLFlBQVksU0FBVTtBQUMxQyxVQUFNLGdCQUFnQixZQUFZO0FBR2xDLFFBQUksY0FBYyxrQkFBa0Isc0JBQXNCO0FBQ3pELE1BQUFBLFFBQU8sTUFBTSx3QkFBd0IsS0FBSyxLQUFLLElBQUksU0FBUyxLQUFLLENBQUMsRUFBRTtJQUNyRTtBQUdBLFNBQUssYUFBYSxPQUFPLGVBQWUsS0FBSyxTQUFTO0FBR3RELFFBQUksWUFBWTtBQUNmLFlBQU0sTUFBTSxHQUFHLEtBQUssSUFBSSxhQUFhO0FBQ3JDLFlBQU0sVUFBVSxLQUFLLFlBQVksSUFBSSxHQUFHO0FBQ3hDLFVBQUksU0FBUztBQUNaLGFBQUssWUFBWSxPQUFPLEdBQUc7QUFDM0IsZ0JBQVEsUUFBUSxHQUFHO01BQ3BCO0lBQ0Q7RUFFRDs7Ozs7Ozs7Ozs7O0VBYVEsYUFBYSxPQUFlLE9BQWUsS0FBYSxXQUFpQjtBQUNoRixVQUFNLFVBQVUsZUFBZSxLQUFLO0FBQ3BDLFVBQU0sT0FBTyxVQUFVLFNBQVMsR0FBRyxVQUFVLFNBQVMsQ0FBQztBQUd2RCxVQUFNLFlBQVksVUFBVSxDQUFDO0FBQzdCLFVBQU0sTUFBTSxVQUFVLFVBQVUsU0FBUyxDQUFDO0FBQzFDLFVBQU0sZ0JBQWdCLFFBQVEsTUFBTSxTQUFTLENBQUMsU0FBUyxLQUFLLFNBQVMsS0FBSyxDQUFDLFFBQVEsTUFBTSxHQUFHLENBQUM7QUFLN0YsUUFBSSxVQUFVLHdCQUF3QixVQUFVLG1CQUFtQjtBQUNsRSxVQUFJLENBQUMsS0FBSyxPQUFPO0FBQ2hCLFFBQUFBLFFBQU8sS0FBSyxNQUFNLEtBQUssTUFBTSxPQUFPLE1BQU0sYUFBYSxFQUFFO0FBQ3pEO01BQ0Q7QUFDQSxVQUFJO0FBQ0gsY0FBTSxXQUNMLFVBQVUsb0JBQ1Asc0JBQXNCLEtBQUssT0FBTyxHQUFHLElBQ3JDLDRCQUE0QixLQUFLLE9BQU8sR0FBRztBQUUvQyxjQUFNLFlBQVksS0FBSyxZQUFZLElBQUksS0FBSyxLQUFLLG9CQUFJLElBQUc7QUFDeEQsY0FBTSxXQUFXLElBQUksSUFBb0IsU0FBUztBQUVsRCxtQkFBVyxLQUFLLFVBQVU7QUFDekIsZ0JBQU0sV0FBVyxjQUFjLEtBQUssT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSztBQUVsRSxnQkFBTSxXQUNMLEVBQUUsV0FBVyxXQUFXLElBQ3BCLEVBQUUsV0FBVyxDQUFDLEtBQUssS0FBTyxFQUFFLFdBQVcsQ0FBQyxLQUFLLElBQUssRUFBRSxXQUFXLENBQUMsSUFDaEUsRUFBRSxXQUFXLENBQUMsS0FBSztBQUN4QixnQkFBTSxZQUFZLFVBQVUsSUFBSSxRQUFRO0FBQ3hDLGdCQUFNLFVBQVUsY0FBYyxVQUFhLGNBQWM7QUFFekQsbUJBQVMsSUFBSSxVQUFVLFFBQVE7QUFFL0IsZ0JBQU0sWUFBWSxvQkFBb0IsR0FBRyxLQUFLLE9BQU87QUFDckQsY0FBSSxTQUFTO0FBQ1osWUFBQUEsUUFBTyxLQUFLLE1BQU0sS0FBSyxNQUFNLFNBQVMsRUFBRTtBQUV4QyxnQkFBSSxLQUFLLGtCQUFrQjtBQUMxQixrQkFBSSxTQUFTLEVBQUU7QUFDZixvQkFBTSxhQUFhLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBSztBQUMxQyxvQkFBSSxFQUFFLFdBQVcsRUFBRTtBQUFRLHlCQUFPO0FBQ2xDLG9CQUFJLEVBQUUsT0FBTyxFQUFFO0FBQUkseUJBQU87QUFDMUIsc0JBQU0sY0FBYyxFQUFFLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDM0Qsb0JBQUksQ0FBQyxhQUFhO0FBQVMseUJBQU87QUFDbEMsc0JBQU0sU0FBUyxFQUFFLEtBQUssRUFBRTtBQUN4Qix1QkFBTyxTQUFTLEtBQUssWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxNQUFNO2NBQ3JFLENBQUM7QUFDRCxrQkFBSTtBQUFZLHlCQUFTLFdBQVc7QUFDcEMsb0JBQU0sa0JBQWtCLGNBQWMsS0FBSyxPQUFPLEVBQUUsUUFBUSxNQUFNO0FBQ2xFLG1CQUFLLGlCQUFpQixlQUFlO0FBQ3JDLG1CQUFLLGlCQUFpQixrQkFBa0IsT0FBTztZQUNoRCxPQUFPO0FBQ04sY0FBQUEsUUFBTyxLQUFLLGdFQUEyRCxRQUFRLEVBQUU7WUFDbEY7VUFDRCxPQUFPO0FBQ04sWUFBQUEsUUFBTyxNQUFNLE1BQU0sS0FBSyxNQUFNLFNBQVMsRUFBRTtVQUMxQztRQUNEO0FBQ0EsYUFBSyxZQUFZLElBQUksT0FBTyxRQUFRO01BQ3JDLFNBQVMsR0FBRztBQUNYLFFBQUFBLFFBQU8sS0FBSyxNQUFNLEtBQUssTUFBTSxPQUFPLG9CQUFvQixDQUFDLE1BQU0sYUFBYSxFQUFFO01BQy9FO0FBQ0E7SUFDRDtBQUdBLFVBQU0sVUFBVSxLQUFLLGFBQWEsT0FBTyxJQUFJO0FBRTdDLFVBQU0sUUFBUSxVQUFVLGNBQWNBLFFBQU8sTUFBTSxLQUFLQSxPQUFNLElBQUlBLFFBQU8sS0FBSyxLQUFLQSxPQUFNO0FBQ3pGLFFBQUksU0FBUztBQUNaLFlBQU0sTUFBTSxLQUFLLE1BQU0sT0FBTyxNQUFNLGFBQWEsTUFBTSxPQUFPLEVBQUU7SUFDakUsT0FBTztBQUNOLFlBQU0sTUFBTSxLQUFLLE1BQU0sT0FBTyxNQUFNLGFBQWEsRUFBRTtJQUNwRDtFQUNEOzs7OztFQU1RLGFBQWEsT0FBZSxNQUFZO0FBQy9DLFFBQUksS0FBSyxXQUFXO0FBQUcsYUFBTztBQUc5QixRQUFJLEtBQUssV0FBVyxHQUFHO0FBQ3RCLFVBQUksS0FBSyxDQUFDLE1BQU0sR0FBTTtBQUNyQixlQUFPO01BQ1IsT0FBTztBQUNOLGVBQU8sU0FBUyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7TUFDL0I7SUFDRDtBQUVBLFlBQVEsT0FBTzs7O01BR2QsS0FBSyxhQUFhO0FBQ2pCLGNBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsY0FBTSxPQUFPLE1BQU0sS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDLEVBQ3RDLElBQUksQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQ2pFLEtBQUssR0FBRztBQUNWLGVBQU8sTUFBTSxLQUFLLElBQUksSUFBSTtNQUMzQjs7Ozs7TUFNQSxLQUFLLGNBQWM7QUFDbEIsWUFBSSxLQUFLLFdBQVcsR0FBRztBQUN0QixpQkFBTyxLQUFLLENBQUMsTUFBTSxJQUFPLFdBQVcsV0FBVyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDL0Q7QUFDQSxZQUFJLEtBQUssVUFBVSxHQUFHO0FBQ3JCLGdCQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGdCQUFNLFlBQVksS0FBSyxDQUFDO0FBQ3hCLGdCQUFNLGFBQWEsS0FBSyxTQUFTLENBQUM7QUFDbEMsZ0JBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFDaEYsZ0JBQU0sY0FBYyxRQUFRLFFBQVEsV0FBVyxNQUFNLFNBQVMsQ0FBQztBQUMvRCxnQkFBTSxVQUFVLFFBQVEsVUFBVSxDQUFDLEdBQUc7QUFDdEMsZ0JBQU0sV0FBVyxXQUFXLFdBQVcsSUFBSSxXQUFXLENBQUMsSUFBSTtBQUMzRCxnQkFBTSxjQUNMLFdBQVcsYUFBYSxTQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO0FBQ3JGLGdCQUFNLFdBQVcsY0FBYyxHQUFHLFdBQVcsS0FBSyxNQUFNLFFBQVMsQ0FBQyxNQUFNLFdBQVcsTUFBTSxLQUFLLFVBQVUsQ0FBQztBQUN6RyxnQkFBTSxTQUFTLElBQUksTUFBTSxLQUFLLENBQUMsSUFBSSxNQUFNLFNBQVMsQ0FBQyxLQUFLLFdBQVcsTUFBTSxLQUFLLFVBQVUsQ0FBQyxDQUFDO0FBQzFGLGlCQUFPLFdBQVcsS0FBSyxNQUFNLFdBQVcsS0FBSyxRQUFRLElBQUksTUFBTTtRQUNoRTtBQUNBLGVBQU8sUUFBUSxLQUFLLFNBQVMsS0FBSyxDQUFDO01BQ3BDOztNQUdBLEtBQUssaUJBQWlCO0FBRXJCLFlBQUksS0FBSyxVQUFVLEdBQUc7QUFDckIsZ0JBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsZ0JBQU0sWUFBWSxLQUFLLENBQUM7QUFDeEIsZ0JBQU0sYUFBYSxLQUFLLFNBQVMsQ0FBQztBQUNsQyxnQkFBTSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUNoRixnQkFBTSxjQUFjLFFBQVEsUUFBUSxXQUFXLE1BQU0sU0FBUyxDQUFDO0FBQy9ELGdCQUFNLFdBQVcsV0FBVyxXQUFXLElBQUksV0FBVyxDQUFDLElBQUk7QUFDM0QsZ0JBQU0sVUFBVSxRQUFRLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU8sR0FBRztBQUNoRSxnQkFBTSxjQUNMLFdBQVcsYUFBYSxTQUFZLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO0FBQ3JGLGdCQUFNLFdBQVcsZUFBZSxLQUFLLFdBQVcsU0FBUyxLQUFLLENBQUM7QUFDL0QsaUJBQU8sV0FBVyxLQUFLLE1BQU0sV0FBVyxLQUFLLFFBQVE7UUFDdEQ7QUFDQSxlQUFPO01BQ1I7O01BR0EsS0FBSztNQUNMLEtBQUssYUFBYTtBQUNqQixZQUFJLEtBQUssU0FBUztBQUFHLGlCQUFPO0FBQzVCLGNBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsY0FBTSxZQUFZLEtBQUssQ0FBQztBQUN4QixjQUFNLFFBQVEsS0FBSyxTQUFTLENBQUM7QUFDN0IsZUFBTyxNQUFNLEtBQUssWUFBWSxNQUFNLFNBQVMsQ0FBQyxVQUFVLE1BQU0sU0FBUyxLQUFLLENBQUM7TUFDOUU7TUFFQTtBQUNDLGVBQU87SUFDVDtFQUNEO0VBRVEsT0FBTyxnQkFBZ0IsT0FBYztBQUM1QyxRQUFJLE9BQU8sVUFBVTtBQUFXLGFBQU8sQ0FBQyxRQUFRLElBQUksQ0FBQztBQUNyRCxRQUFJLE1BQU0sUUFBUSxLQUFLO0FBQUcsYUFBTyxNQUFNLElBQUksQ0FBQyxNQUFNLE9BQU8sQ0FBQyxJQUFJLEdBQUk7QUFDbEUsUUFBSSxPQUFPLFVBQVUsVUFBVTtBQUM5QixVQUFJLFFBQVE7QUFBTSxlQUFPLENBQUUsU0FBUyxLQUFNLEtBQU8sU0FBUyxJQUFLLEtBQU0sUUFBUSxHQUFJO0FBQ2pGLGFBQU8sQ0FBQyxRQUFRLEdBQUk7SUFDckI7QUFDQSxVQUFNLElBQUksTUFBTSw0Q0FBNEMsS0FBSyxFQUFFO0VBQ3BFO0VBRVEsTUFBTSxZQUFZLFVBQWtCLFFBQWM7QUFDekQsUUFBSSxNQUFNLEtBQUssU0FBUyxJQUFJLE1BQU07QUFDbEMsUUFBSSxDQUFDLEtBQUs7QUFDVCxZQUFNLE1BQU0scUJBQXFCLE1BQU07QUFDdkMsV0FBSyxTQUFTLElBQUksUUFBUSxHQUFHO0lBQzlCO0FBRUEsV0FBTyxPQUFPLE9BQU87TUFDcEIsT0FBTyxLQUFLLENBQUMsS0FBTSxLQUFNLEdBQU0sV0FBVyxLQUFNLEdBQU0sS0FBTSxHQUFNLEdBQU0sR0FBRyxLQUFLLEdBQU0sQ0FBSSxDQUFDO01BQzNGLE9BQU8sS0FBSyxZQUFZLE1BQU07S0FDOUI7RUFDRjtFQUVRLE9BQU8sVUFBVSxNQUFjO0FBQ3RDLFFBQUksTUFBTTtBQUNWLGVBQVcsS0FBSyxNQUFNO0FBQ3JCLGFBQU87QUFDUCxlQUFTLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztBQUMzQixlQUFPLE1BQU0sU0FBVSxLQUFNLE9BQU8sSUFBSyxPQUFRLE1BQVEsT0FBTyxJQUFLO01BQ3RFO0lBQ0Q7QUFDQSxXQUFPO0VBQ1I7Ozs7Ozs7Ozs7RUFXTyxnQkFBZ0IsSUFBWSxPQUFlLFdBQW1CLE9BQWM7QUFDbEYsVUFBTSxNQUFNLGNBQWMsS0FBSyxPQUFPLE9BQU8sV0FBVyxLQUFLO0FBQzdELFdBQU8sS0FBSyxZQUFZLElBQUksRUFBRSxHQUFHLElBQUksR0FBRztFQUN6QztFQUVPLE1BQU0sWUFBWSxRQUFjO0FBQ3RDLFdBQU8sS0FBSyxhQUFhLGtCQUFrQixRQUFXLEdBQU0sUUFBVyxRQUFRLEtBQUs7RUFDckY7RUFFTyxNQUFNLGNBQWMsUUFBYztBQUN4QyxXQUFPLEtBQUssYUFBYSxxQkFBcUIsUUFBVyxRQUFXLFFBQVcsUUFBUSxLQUFLO0VBQzdGOzs7O0FFanlCRCxJQUFNRyxVQUFTLG1CQUFtQixnQkFBZ0I7QUFNbEQsSUFBcUIsaUJBQXJCLGNBQTRDLGFBQXlCO0VBQ3BFOztFQUNBOzs7RUFJUSxvQkFBa0MsQ0FBQTs7O0VBSTFDLGNBQXNCO0VBRXRCLFlBQVksVUFBaUI7QUFDNUIsVUFBTSxRQUFRO0VBQ2Y7RUFFQSxNQUFNLEtBQUssUUFBb0I7QUFDOUIsU0FBSyxTQUFTO0FBQ2QsUUFBSSxDQUFDLEtBQUssY0FBYztBQUN2QixXQUFLLGVBQWUsSUFBSSxhQUFZO0lBQ3JDO0FBQ0EsU0FBSyxhQUFhLGVBQWUsWUFBWSx3QkFBd0I7QUFHckUsU0FBSyxhQUFhLG9CQUFvQixDQUFDLGVBQXNCO0FBQzVELFdBQUssZUFBZSxVQUFVO0lBQy9CLENBQUM7QUFJRCxTQUFLLGFBQVksRUFBRyxNQUFNLENBQUMsTUFBSztBQUMvQixNQUFBQSxRQUFPLE1BQU0scUJBQXFCLENBQUMsRUFBRTtJQUN0QyxDQUFDO0VBQ0Y7Ozs7Ozs7RUFRUSxNQUFNLGVBQVk7QUFDekIsSUFBQUEsUUFBTyxLQUFLLDhCQUE4QjtBQUUxQyxTQUFLLG9CQUFvQixNQUFNLEtBQUssYUFBYSxnQkFBZTtBQUdoRSxRQUFJO0FBQ0osUUFBSSxLQUFLLGtCQUFrQixXQUFXLEdBQUc7QUFFeEMsVUFBSSxLQUFLLE9BQU8sV0FBVztBQUMxQixjQUFNLGFBQWEsS0FBSyxPQUFPLGNBQWMsU0FBUyxLQUFLLE9BQU8sV0FBVyxNQUFNO0FBQ25GLFFBQUFBLFFBQU8sS0FBSyxxQkFBcUIsS0FBSyxPQUFPLFNBQVMsOENBQXlDO0FBQy9GLGFBQUssYUFBYSxlQUFlLG1CQUFtQixHQUFHLFVBQVUsSUFBSSxLQUFLLE9BQU8sU0FBUyxhQUFhO0FBQ3ZHO01BQ0Q7QUFDQSxZQUFNLGNBQWMsS0FBSyxPQUFPO0FBQ2hDLFVBQUksQ0FBQyxLQUFLLE9BQU8sUUFBUSxDQUFDLGFBQWE7QUFDdEMsUUFBQUEsUUFBTyxLQUFLLHlEQUF5RDtBQUNyRTtNQUNEO0FBQ0EsTUFBQUEsUUFBTyxLQUFLLHdFQUFtRTtBQUMvRSx1QkFBaUI7SUFDbEIsT0FBTztBQUNOLE1BQUFBLFFBQU8sS0FBSyxjQUFjLEtBQUssa0JBQWtCLE1BQU0sYUFBYTtBQUNwRSxpQkFBVyxLQUFLLEtBQUssbUJBQW1CO0FBQ3ZDLFFBQUFBLFFBQU8sS0FBSyxhQUFhLEVBQUUsS0FBSyxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRTtNQUNyRTtBQUtBLGlCQUFXLFVBQVUsS0FBSyxtQkFBbUI7QUFDNUMsYUFBSyxhQUFhLGdCQUFnQixPQUFPLEVBQUU7TUFDNUM7QUFHQSxpQkFBVyxVQUFVLEtBQUssbUJBQW1CO0FBQzVDLFlBQUk7QUFDSCxnQkFBTSxXQUFXLE1BQU0sS0FBSyxhQUFhLHVCQUF1QixPQUFPLEVBQUU7QUFDekUsaUJBQU8sZUFBZTtBQUN0QixVQUFBQSxRQUFPLEtBQUssT0FBTyxPQUFPLEVBQUUsY0FBYyxRQUFRLFdBQVcsT0FBTyxhQUFhLEVBQUU7UUFDcEYsU0FBUyxHQUFHO0FBQ1gsVUFBQUEsUUFBTyxLQUFLLE9BQU8sT0FBTyxFQUFFLDZCQUE2QixDQUFDLEVBQUU7QUFDNUQsaUJBQU8sZUFBZTtRQUN2QjtNQUNEO0FBRUEsdUJBQWlCLGFBQWEsS0FBSyxRQUFRLEtBQUssaUJBQWlCO0FBR2pFLFVBQUksQ0FBQyxrQkFBa0IsS0FBSyxPQUFPLFdBQVc7QUFDN0MsY0FBTSxhQUFhLEtBQUssT0FBTyxjQUFjLFNBQVMsS0FBSyxPQUFPLFdBQVcsTUFBTTtBQUNuRixRQUFBQSxRQUFPLEtBQUsscUJBQXFCLEtBQUssT0FBTyxTQUFTLHNEQUFpRDtBQUN2RyxhQUFLLGFBQWEsZUFBZSxtQkFBbUIsR0FBRyxVQUFVLElBQUksS0FBSyxPQUFPLFNBQVMsYUFBYTtBQUN2RztNQUNEO0lBQ0Q7QUFHQSxTQUFLLFVBQVUsY0FBYztBQUk3QixVQUFNLGFBQWEsS0FBSztBQUN4QixVQUFNLEtBQUssb0JBQW9CLElBQUksVUFBVTtBQUc3QyxTQUFLLGNBQWE7QUFDbEIsU0FBSyxnQkFBZTtBQUNwQixTQUFLLDBCQUF5QjtBQUM5QixTQUFLLHFCQUFvQjtBQUV6QixJQUFBQSxRQUFPLEtBQUssMkJBQTJCO0VBQ3hDOztFQUdBLE1BQU0sVUFBTztBQUNaLFNBQUssY0FBYyxNQUFLO0FBQ3hCLElBQUFBLFFBQU8sTUFBTSxTQUFTO0VBQ3ZCO0VBRUEsTUFBTSxjQUFjLFFBQW9CO0FBQ3ZDLFVBQU0sZUFBZSxLQUFLO0FBQzFCLFNBQUssU0FBUztBQUNkLFVBQU0saUJBQWlCLGFBQWEsUUFBUSxLQUFLLGlCQUFpQjtBQUNsRSxTQUFLLFVBQVUsY0FBYztBQUk3QixTQUFLLHFCQUFvQjtBQUV6QixVQUFNLFVBQVUsS0FBSztBQUlyQixVQUFNLEtBQUssb0JBQW9CLGNBQWMsT0FBTztBQUdwRCxTQUFLLGNBQWE7QUFDbEIsU0FBSyxnQkFBZTtBQUNwQixTQUFLLDBCQUF5QjtBQUM5QixTQUFLLHFCQUFvQjtFQUMxQjs7Ozs7Ozs7Ozs7O0VBYVEsTUFBTSxvQkFBb0IsY0FBc0IsU0FBZTtBQUN0RSxRQUFJLENBQUMsU0FBUztBQUNiLFVBQUk7QUFBYyxhQUFLLGFBQWEsYUFBYSxZQUFZO0FBQzdEO0lBQ0Q7QUFFQSxRQUFJLEtBQUssT0FBTyxXQUFXO0FBRTFCLFlBQU0sU0FBUyxLQUFLLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsS0FBSyxPQUFPLFNBQVM7QUFDakYsVUFBSSxDQUFDLFFBQVE7QUFDWixRQUFBQSxRQUFPLEtBQUssZUFBZSxLQUFLLE9BQU8sU0FBUyx5REFBb0Q7QUFDcEcsWUFBSTtBQUFjLGVBQUssYUFBYSxhQUFhLFlBQVk7QUFDN0Q7TUFDRDtBQUVBLFVBQUksZ0JBQWdCLGlCQUFpQixTQUFTO0FBQzdDLGFBQUssYUFBYSxhQUFhLFlBQVk7TUFDNUM7QUFDQSxZQUFNLGdCQUFnQixLQUFLLGFBQWEsbUJBQW1CLE9BQU87QUFDbEUsVUFBSSxDQUFDLGVBQWU7QUFDbkIsYUFBSyxhQUFhLGdCQUFnQixPQUFPO01BQzFDO0FBQ0EsVUFBSSxZQUFZLGdCQUFnQixDQUFDLGVBQWU7QUFDL0MsY0FBTSxLQUFLLDZCQUE2QixPQUFPLE9BQU8sT0FBTztNQUM5RDtBQUNBLFdBQUssYUFBYSxlQUFlLElBQUksU0FBUyxPQUFPLEtBQUssTUFBTSxPQUFPLEVBQUU7QUFDekU7SUFDRDtBQUdBLFVBQU0sY0FBYyxPQUFPLEtBQUssT0FBTyxlQUFlLEVBQUU7QUFDeEQsVUFBTSxpQkFBaUIsS0FBSyxrQkFBa0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFFMUUsUUFBSSxnQkFBZ0I7QUFDbkIsVUFBSSxlQUFlLFVBQVUsYUFBYTtBQUN6QyxZQUFJLGdCQUFnQixpQkFBaUI7QUFBUyxlQUFLLGFBQWEsYUFBYSxZQUFZO0FBQ3pGLGNBQU0sZ0JBQWdCLEtBQUssYUFBYSxtQkFBbUIsT0FBTztBQUNsRSxZQUFJLENBQUMsZUFBZTtBQUNuQixlQUFLLGFBQWEsZ0JBQWdCLE9BQU87UUFDMUM7QUFDQSxZQUFJLFlBQVksZ0JBQWdCLENBQUMsZUFBZTtBQUMvQyxnQkFBTSxLQUFLLDZCQUE2QixhQUFhLE9BQU87UUFDN0Q7QUFDQSxhQUFLLGFBQWEsZUFBZSxJQUFJLFNBQVMsV0FBVyxNQUFNLE9BQU8sRUFBRTtNQUN6RSxPQUFPO0FBQ04sUUFBQUEsUUFBTyxNQUNOLDBCQUEwQixXQUFXLDJDQUEyQyxlQUFlLEtBQUssUUFBUSxPQUFPLDBCQUFxQjtBQUV6SSxhQUFLLGFBQWEsYUFBYSxPQUFPO0FBQ3RDLGFBQUssYUFDSixlQUFlLG1CQUNmLDRCQUE0QixXQUFXLFNBQVMsZUFBZSxLQUFLLEVBQUU7TUFFeEU7QUFDQTtJQUNEO0FBR0EsSUFBQUEsUUFBTyxLQUFLLEdBQUcsT0FBTyx3Q0FBbUM7QUFDekQsUUFBSSxnQkFBZ0IsaUJBQWlCO0FBQVMsV0FBSyxhQUFhLGFBQWEsWUFBWTtBQUN6RixTQUFLLGFBQWEsYUFBYSxPQUFPO0FBRXRDLFVBQU0sU0FBUyxNQUFNLEtBQUssYUFBYSxZQUFZLE9BQU87QUFDMUQsUUFBSSxDQUFDLFFBQVE7QUFDWixNQUFBQSxRQUFPLE1BQU0sMEJBQTBCLE9BQU8sMEJBQXFCO0FBQ25FLFdBQUssYUFBYSxlQUFlLGdCQUFnQixtQkFBbUIsT0FBTyxFQUFFO0lBQzlFLFdBQVcsT0FBTyxVQUFVLGFBQWE7QUFDeEMsTUFBQUEsUUFBTyxNQUNOLDBCQUEwQixXQUFXLDJDQUEyQyxPQUFPLEtBQUssUUFBUSxPQUFPLDBCQUFxQjtBQUVqSSxXQUFLLGFBQ0osZUFBZSxtQkFDZiw0QkFBNEIsV0FBVyxTQUFTLE9BQU8sS0FBSyxFQUFFO0lBRWhFLE9BQU87QUFDTixNQUFBQSxRQUFPLEtBQUssa0JBQWtCLE9BQU8sS0FBSyxPQUFPLE9BQU8sRUFBRTtBQUMxRCxXQUFLLGFBQWEsZ0JBQWdCLE9BQU87QUFDekMsWUFBTSxLQUFLLDZCQUE2QixhQUFhLE9BQU87QUFDNUQsV0FBSyxhQUFhLGVBQWUsSUFBSSxTQUFTLE9BQU8sS0FBSyxNQUFNLE9BQU8sRUFBRTtJQUMxRTtFQUNEOzs7OztFQU1RLE1BQU0sNkJBQTZCLE9BQWUsSUFBVTtBQUNuRSxRQUFJO0FBQ0gsWUFBTSxLQUFLLGFBQWEsbUJBQW1CLEVBQUU7QUFFN0MsVUFBSSxDQUFDLGdCQUFnQixLQUFLLEdBQUc7QUFHNUIsUUFBQUEsUUFBTyxLQUFLLDZCQUE2QixLQUFLLHNEQUFpRDtBQUMvRjtNQUNEO0lBQ0QsU0FBUyxHQUFHO0FBQ1gsTUFBQUEsUUFBTyxLQUFLLGlDQUFpQyxFQUFFLEtBQUssQ0FBQyxFQUFFO0lBQ3hEO0VBQ0Q7O0VBR1EsVUFBVSxPQUFhO0FBQzlCLFNBQUssY0FBYztBQUNuQixVQUFNLFNBQVMsZ0JBQWdCLEtBQUs7QUFDcEMsUUFBSSxDQUFDLFFBQVE7QUFDWixNQUFBQSxRQUFPLEtBQUssVUFBVSxLQUFLLCtCQUErQjtBQUMxRCxXQUFLLGFBQWEsU0FBUyxPQUFPLENBQUEsQ0FBRTtBQUNwQztJQUNEO0FBRUEsVUFBTSxVQUFVLE1BQU0sUUFBUSxPQUFPLFNBQVMsSUFBSSxPQUFPLFlBQVksQ0FBQTtBQUVyRSxTQUFLLGFBQWEsU0FBUyxPQUFPLE9BQU87QUFDekMsUUFBSSxRQUFRLFdBQVcsR0FBRztBQUN6QixNQUFBQSxRQUFPLEtBQUssK0JBQStCLEtBQUssNkNBQXdDO0lBQ3pGLE9BQU87QUFDTixNQUFBQSxRQUFPLE1BQU0sVUFBVSxRQUFRLE1BQU0sdUJBQXVCLEtBQUssZ0JBQWdCLE9BQU8sU0FBUyxFQUFFO0lBQ3BHO0VBQ0Q7RUFFQSxrQkFBZTtBQUNkLFdBQU8sZ0JBQWdCLEtBQUssaUJBQWlCO0VBQzlDOztFQUdBLElBQUksT0FBSTtBQUNQLFdBQU8sWUFBWSxLQUFLLFFBQVEsS0FBSyxpQkFBaUI7RUFDdkQ7O0VBR0EsSUFBSSxVQUFPO0FBQ1YsV0FBTyxLQUFLO0VBQ2I7RUFFQSxnQkFBYTtBQUNaLGtCQUFjLElBQUk7RUFDbkI7RUFFQSxrQkFBZTtBQUNkLG9CQUFnQixJQUFJO0VBQ3JCO0VBRUEsNEJBQXlCO0FBQ3hCLDhCQUEwQixJQUFJO0VBQy9CO0VBRUEsdUJBQW9CO0FBQ25CLHlCQUFxQixJQUFJO0VBQzFCOzsiLAogICJuYW1lcyI6IFsicGF0aCIsICJJbnN0YW5jZVN0YXR1cyIsICJSZWdleCIsICJwYXRoIiwgImZzIiwgImxvZ2dlciIsICJpZEFkZE9wdCIsICJmcyIsICJsb2dnZXIiLCAiZGV2aWNlc0ZvbGRlciIsICJwYXRoIiwgImRncmFtIiwgIm9zIiwgImxvZ2dlciIsICJzb2NrIiwgImxvZ2dlciIsICJkZ3JhbSIsICJvcyIsICJsb2dnZXIiXQp9Cg==
