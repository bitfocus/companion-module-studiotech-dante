import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}
function combineRgb(r, g, b, a) {
  let colorNumber = (r & 255) << 16 | (g & 255) << 8 | b & 255;
  if (a && a >= 0 && a < 1) {
    colorNumber += 16777216 * Math.round(255 * (1 - a));
  }
  return colorNumber;
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path3, args) {
    this.#context.oscSend(host, port, path3, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/config.js
import fs from "fs";
import path from "path";
var logger = createModuleLogger("Config");
function resolveDevicesFolder() {
  const primaryPath = path.join(import.meta.dirname, "../devices");
  const fallbackPath = path.join(import.meta.dirname, "./devices");
  if (fs.existsSync(primaryPath)) {
    logger.debug(`Using devices folder: ${primaryPath}`);
    return primaryPath;
  }
  if (fs.existsSync(fallbackPath)) {
    logger.warn(`Primary devices folder not found, using fallback: ${fallbackPath}`);
    return fallbackPath;
  }
  const errorMsg = `Devices folder not found!
Tried:
  - ${primaryPath}
  - ${fallbackPath}
Module cannot continue without device schemas.`;
  logger.error(errorMsg);
  throw new Error(errorMsg);
}
var devicesFolder = resolveDevicesFolder();
var deviceSchemasCache = null;
function getDevicesFolder() {
  return devicesFolder;
}
function loadDeviceSchemas() {
  const schemas = {};
  try {
    const files = fs.readdirSync(devicesFolder).filter((f) => f.endsWith(".json"));
    for (const f of files) {
      const fullPath = path.join(devicesFolder, f);
      const json = JSON.parse(fs.readFileSync(fullPath, "utf8"));
      if (json?.model) {
        schemas[String(json.model)] = json;
      }
    }
    logger.debug(`Loaded ${Object.keys(schemas).length} device schemas into cache`);
  } catch (e) {
    logger.error(`Failed to load device schemas: ${e}`);
  }
  return schemas;
}
function getDeviceSchemas() {
  if (!deviceSchemasCache) {
    deviceSchemasCache = loadDeviceSchemas();
  }
  return deviceSchemasCache;
}
function getDeviceSchema(model) {
  const schemas = getDeviceSchemas();
  return schemas[model];
}
function reloadDeviceSchemas() {
  logger.info("Reloading device schemas from disk...");
  deviceSchemasCache = loadDeviceSchemas();
}
function loadAvailableModels() {
  const schemas = getDeviceSchemas();
  return Object.keys(schemas).sort();
}
function GetConfigFields(discoveredDevices = []) {
  const models = loadAvailableModels();
  const deviceChoices = [
    { id: "", label: "Manual (enter IP + model below)" },
    ...discoveredDevices.map((d) => ({
      id: d.mac ?? "",
      label: `Model ${d.model} [${d.mac}] @ ${d.ip}`
    }))
  ];
  return [
    // ── Device selection dropdown ────────────────────────────────────────
    // Stores the MAC so re-discovery with a changed IP still matches.
    {
      type: "dropdown",
      id: "deviceMac",
      label: "Device",
      width: 8,
      default: "",
      choices: deviceChoices,
      tooltip: "Select an auto-discovered Studio Technologies device, or choose Manual to enter an IP address."
    },
    // ── Manual IP entry — only visible in manual mode ────────────────────
    {
      type: "textinput",
      id: "host",
      label: "Target IP",
      width: 8,
      default: "",
      regex: Regex.IP,
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Enter the IP address of the device manually."
    },
    // ── Manual model selector — only visible in manual mode ──────────────
    {
      type: "dropdown",
      id: "activeModel",
      label: "Active Device Model",
      width: 8,
      default: models[0] ?? "",
      choices: models.map((model) => ({
        id: model,
        label: `Model ${model}`
      })),
      isVisibleExpression: `!$(options:deviceMac)`,
      tooltip: "Select which Studio Technologies model is active for actions and feedbacks."
    },
    // ── Dev Mode ─────────────────────────────────────────────────────────
    {
      type: "checkbox",
      id: "devMode",
      label: "Dev Mode",
      width: 12,
      default: false,
      tooltip: "Enable to allow parsing of ST Devices not currently supported"
    }
  ];
}
function resolveHost(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    return device?.ip ?? "";
  }
  return String(config.host ?? "");
}
function resolveModel(config, discoveredDevices) {
  if (config.deviceMac) {
    const device = discoveredDevices.find((d) => d.mac === config.deviceMac);
    logger.debug(`resolveModel: deviceMac="${config.deviceMac}", found device: ${device?.model ?? "none"}`);
    return device?.model ?? "";
  }
  logger.debug(`resolveModel: manual mode, activeModel="${config.activeModel}"`);
  return String(config.activeModel ?? "");
}

// dist/variables.js
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions({
    model: { name: "Device Model Number" },
    modelName: { name: "Device Model Name (Full Description)" },
    manufacturer: { name: "Device Manufacturer" },
    firmware: { name: "Device Firmware Version" },
    danteFW: { name: "Dante Module Firmware Version" },
    mac: { name: "Device MAC Address" },
    ip: { name: "Device IP Address" }
  });
}
var CLEARED_VARIABLES = {
  model: "",
  modelName: "",
  manufacturer: "",
  firmware: "",
  danteFW: "",
  mac: "",
  ip: ""
};
function UpdateVariableValues(self) {
  const currentHost = self.host;
  if (!currentHost || !self.stController.isDeviceAuthorized(currentHost)) {
    self.setVariableValues(CLEARED_VARIABLES);
    return;
  }
  const device = self.devices.find((d) => d.ip === currentHost);
  if (device) {
    self.setVariableValues({
      model: device.model || "",
      modelName: device.modelName || "",
      manufacturer: device.manufacturer || "",
      firmware: device.firmwareMain || "",
      danteFW: device.danteFirmware || "",
      mac: device.mac || "",
      ip: device.ip
    });
  } else {
    self.setVariableValues({
      ...CLEARED_VARIABLES,
      ip: currentHost
    });
  }
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  // function (context, props) {
  // 	return {
  // 		updatedConfig: null,
  // 		updatedActions: [],
  // 		updatedFeedbacks: [],
  // 	}
  // },
];

// dist/types.js
var CMD_GET_FIRMWARE = 0;
var CMD_MIC_PRE = 2;
var CMD_BUS_GET = 3;
var CMD_BUS_SET = 4;
var CMD_HEADPHONE = 5;
var CMD_BUTTON_MODE = 7;
var CMD_SYSTEM = 9;
var CMD_GET_ALL_SETTINGS = 10;
var CMD_SETTINGS_PUSH = 11;
var CMD_DEV_SPEC = 13;
var CMD_RESET_DEVICE = 14;
var CMD_GLOBAL_MIC_KILL = 16;
var CMD_MIC_PRE_BUS = 18;
var CMD_CHANNEL = 20;
function getCommandName(cmdId) {
  switch (cmdId) {
    case CMD_GET_FIRMWARE:
      return "Get Firmware Version";
    case CMD_MIC_PRE:
      return "Mic Preamp";
    case CMD_BUS_GET:
      return "Heartbeat";
    case CMD_BUS_SET:
      return "Set Bus Setting";
    case CMD_HEADPHONE:
      return "Headphone Control";
    case CMD_BUTTON_MODE:
      return "Button Mode";
    case CMD_SYSTEM:
      return "System Command";
    case CMD_GET_ALL_SETTINGS:
      return "Request All Settings";
    case CMD_SETTINGS_PUSH:
      return "Settings Push";
    case CMD_MIC_PRE_BUS:
      return "Mic/Pre Bus";
    case CMD_DEV_SPEC:
      return "Device Setting";
    case CMD_CHANNEL:
      return "Channel Setting";
    case CMD_RESET_DEVICE:
      return "Reset Device";
    case CMD_GLOBAL_MIC_KILL:
      return "Global Mic Kill";
    default:
      return `cmd_0x${cmdId.toString(16).padStart(2, "0")}`;
  }
}
function makeSettingId(model, cmdId, settingId, busCh) {
  const cmd = typeof cmdId === "number" ? cmdId.toString(16) : cmdId;
  const id = typeof settingId === "number" ? settingId.toString(16) : settingId;
  if (busCh !== void 0) {
    const ch = typeof busCh === "number" ? busCh.toString(16) : busCh;
    return `${model}_${cmd}_${ch}_${id}`;
  }
  return `${model}_${cmd}_${id}`;
}
function toHex(value, padLength = 2) {
  return `0x${value.toString(16).padStart(padLength, "0")}`;
}
function bytesToHex(bytes) {
  return `0x${Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
}
function formatRgbColor(r, g, b) {
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}
function parseSettingId(id) {
  const [model, cmdIdStr, idStr] = id.split("_");
  return {
    model,
    cmdId: parseInt(cmdIdStr, 16),
    baseId: parseInt(idStr, 16)
  };
}
function modelDistance(modelA, modelB) {
  const na = parseInt(modelA.replace(/\D/g, ""), 10);
  const nb = parseInt(modelB.replace(/\D/g, ""), 10);
  if (Number.isNaN(na) || Number.isNaN(nb))
    return Infinity;
  return Math.abs(na - nb);
}
function getNormalizedSchemas(schemasRaw) {
  const normalized = {};
  for (const [model, json] of Object.entries(schemasRaw)) {
    normalized[model] = {
      model: json.model,
      cmdSchema: Array.isArray(json.cmdSchema) ? json.cmdSchema : []
    };
  }
  return normalized;
}
function findActionForSetting(schemas, model, cmdId, settingId) {
  const schema = schemas[model];
  if (!schema || !Array.isArray(schema.cmdSchema))
    return void 0;
  let action = schema.cmdSchema.find((s) => s.cmd_id === cmdId && s.id === settingId);
  if (!action) {
    action = schema.cmdSchema.find((s) => {
      if (s.cmd_id !== cmdId)
        return false;
      const idAddOption = s.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const offset = settingId - s.id;
      return idAddOption.choices.some((c) => c.id === offset);
    });
  }
  return action;
}

// dist/build-commands.js
function buildOption(o) {
  const base = {
    type: o.type,
    id: o.id,
    label: o.label,
    default: o.default,
    tooltip: o.tooltip
  };
  switch (o.type) {
    case "dropdown":
      return { ...base, choices: o.choices ?? [] };
    case "number":
      return {
        ...base,
        min: o.min,
        max: o.max,
        step: o.step ?? 1,
        range: true
      };
    case "checkbox":
      return { ...base, default: o.default ?? false };
    case "static-text":
      return { ...base, value: o.value ?? "" };
    case "textinput":
    case "colorpicker":
    default:
      return base;
  }
}
function buildActions() {
  const schemas = getDeviceSchemas();
  const actions = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const a of cmdSchema) {
      if (a.readonly === true)
        continue;
      const actionId = makeSettingId(model, a.cmd_id, a.id);
      const allBuiltOptions = (a.options ?? []).map(buildOption);
      const options = a.value !== void 0 ? allBuiltOptions.filter((o) => o.id !== "value") : allBuiltOptions;
      const action = {
        name: `[Model${model}] ${a.name}`,
        options,
        callback: async () => {
        }
      };
      actions[actionId] = action;
    }
  }
  return actions;
}
function isBooleanDropdown(setting) {
  const valueOpt = setting.options?.find((o) => o.id === "value");
  if (!valueOpt)
    return false;
  if (valueOpt.type === "checkbox")
    return true;
  if (valueOpt.type !== "dropdown" || !Array.isArray(valueOpt.choices))
    return false;
  if (valueOpt.choices.length !== 2)
    return false;
  const labels = valueOpt.choices.map((c) => String(c.label).toLowerCase());
  return labels.includes("off") && labels.includes("on");
}
function buildFeedbacks() {
  const schemas = getDeviceSchemas();
  const feedbacks = {};
  for (const [model, schema] of Object.entries(schemas)) {
    const cmdSchema = schema.cmdSchema;
    if (!Array.isArray(cmdSchema))
      continue;
    for (const setting of cmdSchema) {
      if (setting.writeonly === true)
        continue;
      const baseFeedbackId = makeSettingId(model, setting.cmd_id, setting.id);
      if (setting.value !== void 0) {
        const fixedOptions = (setting.options ?? []).map(buildOption).filter((opt) => opt.id === "busCh" || opt.id === "idAdd");
        feedbacks[baseFeedbackId] = {
          type: "boolean",
          name: `[Model${model}] ${setting.name} \u2014 Active`,
          defaultStyle: {
            bgcolor: combineRgb(0, 200, 0),
            color: combineRgb(0, 0, 0)
          },
          options: fixedOptions,
          callback: () => {
            return false;
          }
        };
        continue;
      }
      const allOptions = (setting.options ?? []).map(buildOption);
      const valueOptions = allOptions.filter((opt) => opt.id !== "value");
      const isColorSetting = setting.options?.some((o) => o.id === "value" && o.type === "colorpicker");
      if (!isColorSetting) {
        valueOptions.push({
          type: "checkbox",
          id: "showLabel",
          label: "Use Label for Value",
          default: false,
          tooltip: "Return the label text instead of the numeric value"
        });
      }
      const valueFeedback = {
        type: "value",
        name: `[Model${model}] ${setting.name}`,
        options: valueOptions,
        callback: () => {
          return 0;
        }
      };
      feedbacks[baseFeedbackId] = valueFeedback;
      if (isBooleanDropdown(setting)) {
        const boolFeedbackId = `${baseFeedbackId}_bool`;
        const boolOptions = allOptions.filter((opt) => opt.id !== "value");
        const boolFeedback = {
          type: "boolean",
          name: `[Model${model}] ${setting.name} \u2014 Is On`,
          defaultStyle: {
            bgcolor: combineRgb(0, 200, 0),
            color: combineRgb(0, 0, 0)
          },
          options: boolOptions,
          callback: () => {
            return false;
          }
        };
        feedbacks[boolFeedbackId] = boolFeedback;
      }
    }
  }
  return feedbacks;
}

// dist/actions.js
import path2 from "path";

// dist/settingsParser.js
import fs2 from "fs";
var logger2 = createModuleLogger("SettingsParser");
function getRgbIds(model) {
  const rgbIds = /* @__PURE__ */ new Set();
  try {
    const json = getDeviceSchema(model);
    if (!json)
      return rgbIds;
    for (const action of json.cmdSchema || []) {
      const hasColorpicker = action.options?.some((opt) => opt.type === "colorpicker");
      if (hasColorpicker) {
        rgbIds.add(action.id);
        const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
        if (idAddOption?.choices) {
          for (const choice of idAddOption.choices) {
            if (typeof choice.id === "number") {
              rgbIds.add(action.id + choice.id);
            }
          }
        }
      }
    }
  } catch (_err) {
  }
  return rgbIds;
}
function extractStPayloadIndex(buf) {
  const sigIndex = buf.indexOf(Buffer.from("Studio-T"));
  if (sigIndex < 0)
    throw new Error("No Studio-T signature in packet");
  const payloadIndex = sigIndex + 8;
  if (buf[payloadIndex] !== 90) {
    throw new Error(`Expected 0x5A after Studio-T, found ${buf[payloadIndex].toString(16)}`);
  }
  return payloadIndex;
}
function parseGetAllSettings_sectioned(buf, model) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error("Not a getAllSettings reply");
  }
  let p = cmdId === CMD_GET_ALL_SETTINGS ? idx + 3 : idx + 2;
  const end = buf.length - 1;
  const out = [];
  const rgbIds = getRgbIds(model);
  const commandsWithBusCh = [CMD_BUS_SET, CMD_MIC_PRE_BUS, CMD_CHANNEL];
  const commandsRawValue = [CMD_MIC_PRE];
  while (p + 2 < end) {
    const cmdLen = buf[p];
    const sectionCmdId = buf[p + 1];
    const sectionEnd = p + 1 + cmdLen;
    if (sectionEnd > end)
      break;
    const hasBusCh = commandsWithBusCh.includes(sectionCmdId);
    const isRawValue = commandsRawValue.includes(sectionCmdId);
    let busCh;
    let dataLen;
    let q;
    if (isRawValue) {
      busCh = buf[p + 2];
      const rawBytes = buf.subarray(p + 3, sectionEnd);
      const schema = getDeviceSchema(model);
      const micPreEntries = (schema?.cmdSchema ?? []).filter((a) => (a.cmd_id === CMD_MIC_PRE || a.cmd_id === CMD_MIC_PRE_BUS) && a.busCh !== void 0).sort((a, b) => a.id - b.id);
      for (let i = 0; i < rawBytes.length; i++) {
        const entry = micPreEntries[i];
        if (entry) {
          out.push({ cmd_id: entry.cmd_id, id: entry.id, busCh, valueBytes: [rawBytes[i]] });
        }
      }
      p = sectionEnd;
      continue;
    } else if (hasBusCh) {
      busCh = buf[p + 2];
      dataLen = buf[p + 3];
      q = p + 4;
    } else {
      dataLen = buf[p + 2];
      q = p + 3;
    }
    const qEnd = q + dataLen;
    const qStart = q;
    while (q + 1 < qEnd) {
      const id = buf[q];
      let valueBytes;
      if (rgbIds.has(id) && q + 3 < qEnd) {
        valueBytes = [buf[q + 1], buf[q + 2], buf[q + 3]];
        q += 4;
      } else {
        valueBytes = [buf[q + 1]];
        q += 2;
      }
      const setting = {
        cmd_id: sectionCmdId,
        id,
        valueBytes
      };
      if (busCh !== void 0) {
        setting.busCh = busCh;
      }
      out.push(setting);
    }
    if (q === qStart && sectionEnd > p + 3) {
      let pos = hasBusCh ? p + 3 : p + 2;
      let posId = 0;
      while (pos < sectionEnd) {
        const setting = { cmd_id: sectionCmdId, id: posId++, valueBytes: [buf[pos++]] };
        if (busCh !== void 0)
          setting.busCh = busCh;
        out.push(setting);
      }
    }
    p = sectionEnd;
  }
  return out;
}
function parseSettingsResponse(model, buf) {
  const idx = extractStPayloadIndex(buf);
  const cmdId = buf[idx + 1] & 127;
  if (cmdId !== CMD_GET_ALL_SETTINGS && cmdId !== CMD_SETTINGS_PUSH) {
    throw new Error(`Not a settings block (cmdId=0x${cmdId.toString(16)})`);
  }
  return parseGetAllSettings_sectioned(buf, model);
}
function formatParsedSetting(setting, actions) {
  let action = actions.find((a) => a.cmd_id === setting.cmd_id && a.id === setting.id);
  if (!action) {
    const baseAction = actions.find((a) => {
      if (a.cmd_id !== setting.cmd_id)
        return false;
      const idAddOption = a.options?.find((opt) => opt.id === "idAdd");
      if (!idAddOption?.choices)
        return false;
      const channelOffset = setting.id - a.id;
      return idAddOption.choices.some((c) => c.id === channelOffset);
    });
    if (baseAction) {
      action = baseAction;
    }
  }
  const cmdHex = toHex(setting.cmd_id);
  const idHex = toHex(setting.id);
  const valHex = bytesToHex(setting.valueBytes);
  const valDec = setting.valueBytes.length === 3 ? formatRgbColor(setting.valueBytes[0], setting.valueBytes[1], setting.valueBytes[2]) : setting.valueBytes.length === 1 ? setting.valueBytes[0] : setting.valueBytes.join(",");
  const busChStr = setting.busCh !== void 0 ? ` ch:${setting.busCh}` : "";
  const prefix = `cmd:${cmdHex}${busChStr} id:${idHex} val:${valHex}`;
  if (action) {
    let name = action.name;
    if (setting.busCh !== void 0) {
      name = `${name} Ch${setting.busCh + 1}`;
    } else {
      const idAddOption = action.options?.find((opt) => opt.id === "idAdd");
      if (idAddOption?.choices) {
        const channelOffset = setting.id - action.id;
        const idAddChoice = idAddOption.choices.find((c) => c.id === channelOffset);
        if (idAddChoice) {
          name = `${name} ${idAddChoice.label}`;
        }
      }
    }
    const valueOption = action.options?.find((opt) => opt.id === "value");
    const fixedValue = action.value;
    if (fixedValue !== void 0 && valueOption === void 0) {
      return `${prefix} | ${name}: ${fixedValue}`;
    }
    if (valueOption?.choices && setting.valueBytes.length === 1) {
      const choice = valueOption.choices.find((c) => c.id === setting.valueBytes[0]);
      if (choice) {
        return `${prefix} | ${name}: ${choice.label} (${valDec})`;
      }
    }
    return `${prefix} | ${name}: ${valDec}`;
  }
  return `${prefix} | Unknown Setting`;
}
function parseGetAllSettingsWithDetection(model, buf) {
  const settings = parseGetAllSettings_sectioned(buf, model);
  return { settings, detectedSectioned: null };
}
function parseGetAllSettingsForModel(model, buf) {
  return parseGetAllSettings_sectioned(buf, model);
}
function valueBytesToOption(valueBytes) {
  if (valueBytes.length === 1) {
    return { id: "value", label: "Value", type: "number", default: valueBytes[0] };
  }
  if (valueBytes.length === 3) {
    const [r, g, b] = valueBytes;
    return {
      id: "value",
      label: "Color",
      type: "colorpicker",
      default: formatRgbColor(r, g, b)
    };
  }
  return { id: "value", label: "Value", type: "raw", default: [...valueBytes] };
}
function updateModelJsonFromSettings(modelJson, parsed, allModels) {
  const out = structuredClone(modelJson);
  if (!out.cmdSchema) {
    out.cmdSchema = [];
  }
  const candidates = Object.values(allModels).filter((m) => m.model !== modelJson.model).sort((a, b) => modelDistance(modelJson.model, a.model) - modelDistance(modelJson.model, b.model));
  logger2.info(`Updating model: ${modelJson.model}`);
  logger2.debug(`Candidates for inference: ${candidates.map((c) => c.model).join(", ")}`);
  const idAddDeferRanges = /* @__PURE__ */ new Map();
  for (const c of candidates) {
    for (const baseEntry of c.cmdSchema ?? []) {
      const idAddOpt = baseEntry.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        continue;
      const baseId = baseEntry.id;
      const cmdId = baseEntry.cmd_id;
      const key = `${cmdId}_${baseId}`;
      if (idAddDeferRanges.has(key))
        continue;
      const parsedOffsets = parsed.filter((p) => p.cmd_id === cmdId && p.id > baseId).map((p) => p.id - baseId).sort((a, b) => a - b);
      let maxSeq = 0;
      for (const off of parsedOffsets) {
        if (off === maxSeq + 1)
          maxSeq = off;
        else if (off > maxSeq + 1)
          break;
      }
      if (maxSeq > 0) {
        idAddDeferRanges.set(key, maxSeq);
        logger2.debug(`idAdd defer range for cmd_id=${toHex(cmdId)} base_id=${toHex(baseId)}: offsets 1\u2013${maxSeq}`);
      }
    }
  }
  const busChSeen = /* @__PURE__ */ new Map();
  for (const { cmd_id, id, busCh } of parsed) {
    if (busCh === void 0)
      continue;
    const key = `${cmd_id}_${id}`;
    if (!busChSeen.has(key))
      busChSeen.set(key, /* @__PURE__ */ new Set());
    busChSeen.get(key).add(busCh);
  }
  for (const { cmd_id, id, busCh, valueBytes } of parsed) {
    const existingExact = out.cmdSchema.find((a) => a.cmd_id === cmd_id && a.id === id);
    if (existingExact) {
      const opt = existingExact.options?.find((o) => o.id === "value");
      if (opt)
        opt.default = valueBytesToOption(valueBytes).default;
      const seenBusChValues = busChSeen.get(`${cmd_id}_${id}`);
      if (seenBusChValues && seenBusChValues.size > 0) {
        const maxBusCh = Math.max(...seenBusChValues);
        const hasBusChOption = existingExact.options?.some((o) => o.id === "busCh");
        if (maxBusCh === 0 && existingExact.busCh === void 0 && !hasBusChOption) {
          existingExact.busCh = 0;
          logger2.info(`Synced busCh=0 onto existing entry cmd_id=${toHex(cmd_id)} id=${toHex(id)}`);
        }
      }
      continue;
    }
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt = a.options?.find((o) => o.id === "idAdd");
      if (!idAddOpt?.choices)
        return false;
      if (id <= a.id)
        return false;
      const offset = id - a.id;
      return candidates.some((c) => {
        const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === a.id);
        const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
        return refIdAdd?.choices?.some((ch) => ch.id === offset);
      });
    });
    if (idAddBase) {
      const offset = id - idAddBase.id;
      const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
      if (idAddOpt?.choices && !idAddOpt.choices.some((c) => c.id === offset)) {
        let label = `Channel ${offset + 1}`;
        for (const c of candidates) {
          const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
          const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
          const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
          if (refChoice) {
            label = refChoice.label;
            break;
          }
        }
        idAddOpt.choices.push({ id: offset, label });
        logger2.info(`Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
      }
      continue;
    }
    let action;
    for (const c of candidates) {
      const match = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === id);
      if (match) {
        action = structuredClone(match);
        const baseName = match.name.replace(/\s*\(inferred from Model [^)]+\)/g, "").trim();
        action.name = `${baseName} (inferred from Model ${c.model})`;
        logger2.info(`Inferred cmd_id=${toHex(cmd_id)} id=${toHex(id)} from Model ${c.model} (exact)`);
        break;
      }
    }
    if (!action) {
      let shouldDefer = false;
      for (const c of candidates) {
        const baseEntry = c.cmdSchema?.find((a) => {
          if (a.cmd_id !== cmd_id)
            return false;
          const idAddOpt = a.options?.find((o) => o.id === "idAdd");
          if (!idAddOpt?.choices)
            return false;
          if (id <= a.id)
            return false;
          const offset = id - a.id;
          const maxSeq = idAddDeferRanges.get(`${cmd_id}_${a.id}`) ?? 0;
          return offset <= maxSeq;
        });
        if (baseEntry) {
          shouldDefer = true;
          logger2.debug(`cmd_id=${toHex(cmd_id)} id=${toHex(id)} is an idAdd offset of candidate base id=${toHex(baseEntry.id)} \u2014 deferring to pass 2`);
          break;
        }
      }
      if (shouldDefer)
        continue;
    }
    if (!action) {
      action = {
        cmd_id,
        id,
        name: `Unknown cmd:${toHex(cmd_id)} id:${toHex(id).toUpperCase()}`,
        options: [valueBytesToOption(valueBytes)]
      };
      if (busCh !== void 0)
        action.busCh = busCh;
      logger2.warn(`Could not infer cmd_id=${toHex(cmd_id)} id=${toHex(id)}`);
    } else {
      action.options = action.options?.filter((o) => o.id !== "busCh") ?? [];
      delete action.busCh;
      const seenBusChValues = busChSeen.get(`${cmd_id}_${id}`);
      if (seenBusChValues && seenBusChValues.size > 0) {
        const maxBusCh = Math.max(...seenBusChValues);
        if (maxBusCh === 0) {
          action.busCh = 0;
        } else {
          const busChChoices = Array.from({ length: maxBusCh + 1 }, (_, i) => ({
            id: i,
            label: `Channel ${i + 1}`
          }));
          action.options.unshift({
            id: "busCh",
            label: "Channel",
            type: "dropdown",
            choices: busChChoices,
            default: 0
          });
        }
      }
      const observedDefault = valueBytesToOption(valueBytes).default;
      const valueOpt = action.options?.find((o) => o.id === "value");
      if (valueOpt) {
        if (valueOpt.choices && Array.isArray(valueOpt.choices)) {
          const inChoices = valueOpt.choices.some((c) => c.id === observedDefault);
          if (!inChoices) {
            logger2.warn(`Inferred choices for cmd_id=${toHex(cmd_id)} id=${toHex(id)} don't contain observed value ${observedDefault} \u2014 discarding inherited choices`);
            valueOpt.type = "number";
            delete valueOpt.choices;
          }
        }
        valueOpt.default = observedDefault;
      }
    }
    out.cmdSchema.push(action);
  }
  for (const { cmd_id, id } of parsed) {
    const alreadyTopLevel = out.cmdSchema.some((a) => a.cmd_id === cmd_id && a.id === id);
    if (alreadyTopLevel)
      continue;
    const idAddBase = out.cmdSchema.find((a) => {
      if (a.cmd_id !== cmd_id)
        return false;
      const idAddOpt2 = a.options?.find((o) => o.id === "idAdd");
      return !!idAddOpt2?.choices && id > a.id;
    });
    if (!idAddBase)
      continue;
    const offset = id - idAddBase.id;
    const idAddOpt = idAddBase.options?.find((o) => o.id === "idAdd");
    if (!idAddOpt?.choices || idAddOpt.choices.some((c) => c.id === offset))
      continue;
    const refHasOffset = candidates.some((c) => {
      const refEntry = c.cmdSchema?.find((r) => r.cmd_id === cmd_id && r.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      return refIdAdd?.choices?.some((ch) => ch.id === offset);
    });
    const existingOffsets = idAddOpt.choices.map((c) => c.id).sort((a, b) => a - b);
    const isSequential = existingOffsets.length > 0 && offset === existingOffsets[existingOffsets.length - 1] + 1;
    if (!refHasOffset && !isSequential)
      continue;
    let label = `Channel ${offset + 1}`;
    for (const c of candidates) {
      const refEntry = c.cmdSchema?.find((a) => a.cmd_id === cmd_id && a.id === idAddBase.id);
      const refIdAdd = refEntry?.options?.find((o) => o.id === "idAdd");
      const refChoice = refIdAdd?.choices?.find((ch) => ch.id === offset);
      if (refChoice) {
        label = refChoice.label;
        break;
      }
    }
    idAddOpt.choices.push({ id: offset, label });
    logger2.info(`Pass 2: Folded cmd_id=${toHex(cmd_id)} id=${toHex(id)} into idAdd base id=${toHex(idAddBase.id)} as offset ${offset} ("${label}")`);
  }
  return out;
}
function saveModelJsonPretty(filePath, jsonObj) {
  try {
    const orderedObj = { model: jsonObj.model };
    if ("useConMon" in jsonObj) {
      orderedObj.useConMon = jsonObj.useConMon;
    }
    if ("cmdSchema" in jsonObj) {
      orderedObj.cmdSchema = jsonObj.cmdSchema.map((entry) => {
        const orderedEntry = {};
        if ("cmd_id" in entry)
          orderedEntry.cmd_id = entry.cmd_id;
        if ("id" in entry)
          orderedEntry.id = entry.id;
        if ("busCh" in entry)
          orderedEntry.busCh = entry.busCh;
        if ("name" in entry)
          orderedEntry.name = entry.name;
        if ("value" in entry)
          orderedEntry.value = entry.value;
        if ("options" in entry)
          orderedEntry.options = entry.options;
        for (const key of Object.keys(entry)) {
          if (!(key in orderedEntry))
            orderedEntry[key] = entry[key];
        }
        return orderedEntry;
      });
    }
    for (const key of Object.keys(jsonObj)) {
      if (!(key in orderedObj)) {
        orderedObj[key] = jsonObj[key];
      }
    }
    let json = JSON.stringify(orderedObj, null, 2);
    json = json.replace(/\{\n\s+"id":\s*(\d+),\n\s+"label":\s*"([^"]*)"\n\s+\}/g, '{ "id": $1, "label": "$2" }');
    fs2.writeFileSync(filePath, json + "\n", "utf8");
  } catch (e) {
    logger2.error(`File Write Error: ${e}`);
  }
}

// dist/actions.js
var logger3 = createModuleLogger("Actions");
function UpdateActions(self) {
  const schemasRaw = getDeviceSchemas();
  const rawActions = buildActions();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredActions = {};
  const activeModel = self.activeModel;
  if (self.config.devMode) {
    wiredActions["global_getAllSettings"] = {
      name: "GLOBAL: Get All Settings",
      description: "Use this to create a schema for a new device",
      options: [],
      callback: async () => {
        const model = activeModel;
        const ip = self.host;
        const buf = await self.stController.requestAllSettings(ip);
        let modelJson = getDeviceSchema(model);
        const { settings: parsed } = parseGetAllSettingsWithDetection(model, buf);
        logger3.debug(`parsed reply: ${JSON.stringify(parsed)}`);
        if (!modelJson) {
          logger3.info(`Model ${model} has no schema \u2014 creating new JSON from settings`);
          modelJson = {
            model,
            cmdSchema: []
          };
        }
        const updated = updateModelJsonFromSettings(modelJson, parsed, schemas);
        logger3.debug(`new Actions json: ${JSON.stringify(updated, null, 2)}`);
        const devicesFolder2 = getDevicesFolder();
        const schemaPath = path2.join(devicesFolder2, `Model${model}.json`);
        saveModelJsonPretty(schemaPath, updated);
        reloadDeviceSchemas();
        logger3.info(`Model ${model} JSON auto-updated from getAllSettings`);
      }
    };
  }
  for (const [actionId, action] of Object.entries(rawActions)) {
    const { model, cmdId, baseId } = parseSettingId(actionId);
    if (model !== activeModel)
      continue;
    const rawSchema = schemasRaw[model];
    const rawAction = rawSchema?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === baseId);
    wiredActions[actionId] = {
      ...action,
      callback: async (event) => {
        const ip = self.host;
        const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
        const value = rawAction?.value !== void 0 ? rawAction.value : event.options["value"];
        const idAdd = event.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        await self.stController.sendAwaitAck(cmdId, busCh, settingId, value, ip);
      },
      ...rawAction?.value === void 0 && {
        learn: (event) => {
          const ip = self.host;
          const idAdd = event.options["idAdd"] ?? 0;
          const settingId = baseId + idAdd;
          const busCh = event.options["busCh"] !== void 0 ? event.options["busCh"] : rawAction?.busCh;
          const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
          if (current === void 0)
            return void 0;
          return { ...event.options, value: current };
        }
      }
    };
  }
  const activeSchema = schemas[activeModel];
  if (activeSchema) {
    const supportsMicKill = (activeSchema.cmdSchema ?? []).some((a) => a.name.includes("Kill"));
    if (supportsMicKill) {
      const actionId = `${activeModel}_micKill`;
      wiredActions[actionId] = {
        name: `[Model${activeModel}] Mic Kill`,
        options: [],
        callback: async () => {
          const ip = self.host;
          logger3.info(`Mic Kill \u2192 Model ${activeModel} @ ${ip}`);
          await self.stController.globalMicKill(ip);
          await self.stController.requestAllSettings(ip).catch((err) => {
            logger3.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
      };
    }
  }
  self.setActionDefinitions(wiredActions);
}

// dist/feedbacks.js
function getLabelForValue(schemas, model, cmdId, settingId, value) {
  const setting = findActionForSetting(schemas, model, cmdId, settingId);
  if (!setting || !Array.isArray(setting.options))
    return value;
  const valueOption = setting.options.find((opt) => opt.id === "value");
  if (!valueOption || !Array.isArray(valueOption.choices))
    return value;
  const choice = valueOption.choices.find((c) => c.id === value);
  return choice?.label ?? value;
}
function UpdateFeedbacks(self) {
  const schemasRaw = getDeviceSchemas();
  const rawFeedbacks = buildFeedbacks();
  const schemas = getNormalizedSchemas(schemasRaw);
  const wiredFeedbacks = {};
  const activeModel = self.activeModel;
  for (const [feedbackId, feedback] of Object.entries(rawFeedbacks)) {
    const parseId = feedbackId.endsWith("_bool") ? feedbackId.slice(0, -5) : feedbackId;
    const { model, cmdId, baseId } = parseSettingId(parseId);
    if (model !== activeModel)
      continue;
    wiredFeedbacks[feedbackId] = {
      ...feedback,
      callback: (feedbackEvent) => {
        const ip = self.host;
        const idAdd = feedbackEvent.options["idAdd"] ?? 0;
        const settingId = baseId + idAdd;
        let busCh = feedbackEvent.options["busCh"];
        if (busCh === void 0) {
          const schemaAction = findActionForSetting(schemas, model, cmdId, settingId);
          if (schemaAction?.busCh !== void 0) {
            busCh = schemaAction.busCh;
          }
        }
        if (busCh === void 0) {
          const rawAction = schemasRaw[model]?.cmdSchema?.find((a) => a.cmd_id === cmdId && a.id === settingId);
          if (rawAction?.busCh !== void 0) {
            busCh = rawAction.busCh;
          }
        }
        const current = self.stController.getSettingValue(ip, cmdId, settingId, busCh);
        if (feedbackId.endsWith("_bool")) {
          return current !== void 0 && current !== 0;
        }
        const showLabel = feedbackEvent.options["showLabel"] ?? false;
        if (showLabel && current !== void 0) {
          const label = getLabelForValue(schemas, model, cmdId, settingId, current);
          if (typeof label === "number") {
            return label !== 0 ? "true" : "false";
          }
          return label;
        }
        return current ?? 0;
      }
    };
  }
  self.setFeedbackDefinitions(wiredFeedbacks);
}

// dist/stcontroller.js
import dgram3 from "dgram";
import os2 from "os";

// dist/dante.js
import dgram from "dgram";
import os from "os";
var logger4 = createModuleLogger("Dante");
var DANTE_MSG_INFO_REQUEST = 32;
var DANTE_MSG_INFO_RESPONSE = 368;
var DANTE_INFO_MIN_LEN = 204 + 64;
function buildDanteInfoRequest() {
  const buf = Buffer.alloc(32, 0);
  const seq = Math.floor(Math.random() * 65535);
  buf.writeUInt16BE(65535, 0);
  buf.writeUInt16BE(DANTE_MSG_INFO_REQUEST, 2);
  buf.writeUInt16BE(seq, 4);
  const mac = getFirstLocalMac();
  mac.copy(buf, 8);
  Buffer.from("Audinate", "ascii").copy(buf, 16);
  buf.writeUInt16BE(1849, 24);
  buf.writeUInt16BE(193, 26);
  buf.writeUInt32BE(1e6, 28);
  return buf;
}
function getFirstLocalMac() {
  try {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const addr of ifaces[name] ?? []) {
        if (!addr.internal && addr.family === "IPv4" && addr.mac && addr.mac !== "00:00:00:00:00:00") {
          return Buffer.from(addr.mac.split(":").map((h) => parseInt(h, 16)));
        }
      }
    }
  } catch {
  }
  return Buffer.alloc(6, 0);
}
function parseDanteInfoResponse(msg, srcIp) {
  if (msg.length < DANTE_INFO_MIN_LEN)
    return null;
  if (msg.readUInt16BE(0) !== 65535)
    return null;
  if (msg.readUInt16BE(2) !== DANTE_MSG_INFO_RESPONSE)
    return null;
  if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
    return null;
  const readStr = (offset, len) => msg.subarray(offset, offset + len).toString("ascii").split("\0")[0].trim();
  const eui64 = msg.subarray(8, 16);
  const macBytes = [eui64[0], eui64[1], eui64[2], eui64[5], eui64[6], eui64[7]];
  const mac = macBytes.map((b) => b.toString(16).padStart(2, "0")).join(":");
  const name = readStr(32, 31);
  const manufacturer = readStr(76, 64);
  const modelRaw = readStr(204, 64);
  const danteFirmware = `${msg[24]}.${msg[25]}`;
  if (!modelRaw)
    return null;
  const model = modelRaw.replace(/^Model\s+/i, "").trim().split(/\s+/)[0];
  return {
    ip: srcIp,
    name,
    manufacturer,
    model,
    modelName: modelRaw,
    // Full model description
    mac,
    danteFirmware
  };
}
async function getMacForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    tmp.once("error", (err) => {
      tmp.close();
      reject(new Error(err.message ?? String(err)));
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        tmp.close();
        const ifaces = os.networkInterfaces();
        for (const name of Object.keys(ifaces)) {
          for (const iface of ifaces[name] ?? []) {
            if (iface.family === "IPv4" && iface.address === localAddr && iface.mac && iface.mac !== "00:00:00:00:00:00") {
              return resolve(iface.mac.split(":").map((b) => parseInt(b, 16) & 255));
            }
          }
        }
        reject(new Error(`No interface found for local address ${localAddr}`));
      } catch (_e) {
        reject(new Error(String(_e)));
      }
    });
  });
}
async function getLocalAddressForDestination(destIp) {
  return new Promise((resolve, reject) => {
    const tmp = dgram.createSocket("udp4");
    let resolved = false;
    tmp.once("error", (err) => {
      if (!resolved) {
        resolved = true;
        tmp.close();
        reject(new Error(err.message ?? String(err)));
      }
    });
    tmp.connect(9, destIp, () => {
      try {
        const addr = tmp.address();
        const localAddr = addr.address;
        if (!resolved) {
          resolved = true;
          tmp.close();
          resolve(localAddr);
        }
      } catch (_e) {
        if (!resolved) {
          resolved = true;
          tmp.close();
          reject(new Error(String(_e)));
        }
      }
    });
  });
}
async function discoverDevices(txSocket, ensureMembership, timeoutMs = 5e3) {
  const DANTE_ANNOUNCE_GROUP = "224.0.0.233";
  const DANTE_ANNOUNCE_PORT = 8708;
  const DEFAULT_PORT = 8700;
  const queriedIps = /* @__PURE__ */ new Set();
  return new Promise((resolve) => {
    const announceSocket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    const joinedInterfaces = [];
    const cleanup = () => {
      for (const iface of joinedInterfaces) {
        try {
          announceSocket.dropMembership(DANTE_ANNOUNCE_GROUP, iface);
        } catch {
        }
      }
      try {
        announceSocket.close();
      } catch {
      }
      resolve();
    };
    const timer = setTimeout(cleanup, timeoutMs);
    timer.unref?.();
    announceSocket.on("error", (err) => {
      logger4.warn(`Announce socket error: ${err.message}`);
    });
    announceSocket.on("message", (msg, rinfo) => {
      const srcIp = rinfo.address;
      if (msg.length < 24)
        return;
      if (msg.readUInt16BE(0) !== 65534)
        return;
      if (msg.subarray(16, 24).toString("ascii") !== "Audinate")
        return;
      if (queriedIps.has(srcIp))
        return;
      queriedIps.add(srcIp);
      logger4.debug(`Announce from ${srcIp} \u2014 sending unicast query`);
      const sendQuery = async () => {
        await ensureMembership(srcIp);
        const query = buildDanteInfoRequest();
        txSocket.send(query, DEFAULT_PORT, srcIp, (err) => {
          if (err)
            logger4.warn(`Unicast query to ${srcIp} failed: ${err.message}`);
        });
      };
      sendQuery().catch((err) => logger4.warn(`Query setup failed: ${err}`));
    });
    announceSocket.bind(DANTE_ANNOUNCE_PORT, () => {
      const ifaces = os.networkInterfaces();
      for (const addrs of Object.values(ifaces)) {
        for (const addr of addrs ?? []) {
          if (addr.family === "IPv4" && !addr.internal) {
            try {
              announceSocket.addMembership(DANTE_ANNOUNCE_GROUP, addr.address);
              joinedInterfaces.push(addr.address);
            } catch {
            }
          }
        }
      }
      if (joinedInterfaces.length === 0) {
        logger4.warn(`Could not join announce multicast group on any interface`);
      } else {
        logger4.debug(`Listening for Dante announces on ${DANTE_ANNOUNCE_GROUP}:${DANTE_ANNOUNCE_PORT}`);
      }
    });
  });
}
async function probeDevice(txSocket, registerListener, removeListener, ensureMembership, ip, timeoutMs = 3e3) {
  return new Promise((resolve) => {
    const key = `__probe_${ip}__`;
    let resolved = false;
    const finish = (result) => {
      if (resolved)
        return;
      resolved = true;
      removeListener(key);
      resolve(result);
    };
    registerListener(key, (device) => {
      if (device.ip === ip)
        finish(device);
    });
    const timer = setTimeout(() => finish(null), timeoutMs);
    timer.unref?.();
    const run = async () => {
      await ensureMembership(ip);
      const query = buildDanteInfoRequest();
      txSocket.send(query, 8700, ip, (err) => {
        if (err) {
          logger4.warn(`Probe to ${ip} failed: ${err.message}`);
          clearTimeout(timer);
          finish(null);
        }
      });
    };
    run().catch((e) => {
      logger4.warn(`probeDevice setup failed for ${ip}: ${e}`);
      clearTimeout(timer);
      finish(null);
    });
  });
}

// dist/conmon.js
import dgram2 from "dgram";
var logger5 = createModuleLogger("ConMon");
var _conmonPending = /* @__PURE__ */ new Map();
async function openConMonSession(deviceIp, timeoutMs = 3e3) {
  const pending = _conmonPending.get(deviceIp);
  if (pending)
    return pending;
  const promise = _doConMonSession(deviceIp, timeoutMs).finally(() => {
    _conmonPending.delete(deviceIp);
  });
  _conmonPending.set(deviceIp, promise);
  return promise;
}
async function _doConMonSession(deviceIp, timeoutMs) {
  return new Promise((resolve) => {
    let settled = false;
    let keepaliveTimer = null;
    const closeSession = (sock2) => {
      if (keepaliveTimer) {
        clearInterval(keepaliveTimer);
        keepaliveTimer = null;
      }
      try {
        sock2.close();
      } catch {
      }
      logger5.debug(`ConMon session closed for ${deviceIp}`);
    };
    const fail = (sock2) => {
      if (settled)
        return;
      settled = true;
      clearTimeout(timer);
      closeSession(sock2);
      logger5.debug(`ConMon session not established for ${deviceIp}`);
      resolve(null);
    };
    const sock = dgram2.createSocket({ type: "udp4", reuseAddr: true });
    const timer = setTimeout(() => fail(sock), timeoutMs);
    sock.on("error", (err) => {
      logger5.warn(`ConMon socket error for ${deviceIp}: ${err.message}`);
      fail(sock);
    });
    sock.on("message", (msg) => {
      if (!settled && msg.length >= 4 && msg[0] === 18 && msg[3] === 32) {
        settled = true;
        clearTimeout(timer);
        logger5.info(`ConMon session established with ${deviceIp}`);
        let keepaliveSeq = Math.floor(Math.random() * 65534) + 1;
        const sendKeepalive = () => {
          const pkt = Buffer.alloc(20, 0);
          pkt[0] = 18;
          pkt[3] = 78;
          pkt.writeUInt16BE(keepaliveSeq++ & 65535, 4);
          pkt[6] = 48;
          pkt[7] = 16;
          sock.send(pkt, 8800, deviceIp, () => {
          });
        };
        keepaliveTimer = setInterval(sendKeepalive, 1e3);
        resolve(() => closeSession(sock));
      }
    });
    const doInit = async () => {
      let localIp;
      let localMac;
      try {
        localIp = await getLocalAddressForDestination(deviceIp);
        localMac = await getMacForDestination(deviceIp);
      } catch (e) {
        logger5.warn(`ConMon: could not get local network info for ${deviceIp}: ${e}`);
        fail(sock);
        return;
      }
      sock.bind({ port: 8800, address: localIp }, () => {
        const seq = Math.floor(Math.random() * 65534) + 1;
        const pkt = Buffer.alloc(20, 0);
        pkt[0] = 18;
        pkt[3] = 20;
        pkt.writeUInt16BE(seq, 4);
        pkt[6] = 16;
        pkt[7] = 1;
        localMac.forEach((b, i) => {
          pkt[12 + i] = b;
        });
        logger5.debug(`ConMon TX to ${deviceIp}: ${pkt.toString("hex")}`);
        sock.send(pkt, 8800, deviceIp, (err) => {
          if (err) {
            logger5.warn(`ConMon send failed for ${deviceIp}: ${err.message}`);
            fail(sock);
          }
        });
      });
    };
    doInit().catch((e) => {
      logger5.warn(`ConMon init failed for ${deviceIp}: ${e}`);
      fail(sock);
    });
  });
}

// dist/stcontroller.js
var logger6 = createModuleLogger("StController");
var StController = class _StController {
  defaultPort = 8700;
  multicastGroup = "224.0.0.231";
  rxPort = 8702;
  txSocket;
  rxSocket;
  // for receiving responses (8702)
  rxMcastSocket = null;
  // diagnostic: tracks which responses arrive via multicast
  mcastDeliveries = /* @__PURE__ */ new Set();
  // keys seen on multicast socket this cycle
  pendingAcks = /* @__PURE__ */ new Map();
  joinedInterfaces = /* @__PURE__ */ new Set();
  // local IPs we've joined multicast on
  /** Serializes outgoing commands so each waits for ACK before the next is sent */
  sendQueue = Promise.resolve();
  /** Tracks how many commands are queued/in-flight, to defer requestAllSettings */
  pendingCommandCount = 0;
  /** Resolves once txSocket is bound and ready to send */
  txReady;
  /** Active device model and action definitions for settings decoding */
  model = "";
  actions = [];
  /**
   * Known state of every setting per device IP.
   * Keyed by IP → Map of "${cmdId}/${settingId}" → current value byte.
   * Populated on connect via requestAllSettings(), updated on every CMD_SETTINGS_PUSH (0x0b).
   * Used to diff incoming pushes (changed = info, unchanged = debug) and for feedbacks.
   */
  deviceState = /* @__PURE__ */ new Map();
  /**
   * IPs that have been verified against the configured model and are allowed
   * to receive Studio-T commands. Populated by authorizeDevice() after a
   * successful probeDevice() model match, or after multicast discovery.
   * _sendAwaitAck() rejects any destIp not in this set.
   */
  authorizedIps = /* @__PURE__ */ new Set();
  /** Callbacks registered for Dante 0x0170 device info responses — keyed by usage */
  discoveryListeners = /* @__PURE__ */ new Map();
  /** Callback to trigger feedback updates when state changes */
  feedbackCallback;
  /** Cache of local interface MAC bytes per destination IP, to avoid repeated OS lookups */
  macCache = /* @__PURE__ */ new Map();
  /** Tracks session readiness per IP — set for devices that established ConMon, and also
   *  for devices that don't require ConMon (useConMon not set), so the check is only done once. */
  sessionEstablished = /* @__PURE__ */ new Set();
  /** Cleanup functions returned by openConMonSession() — call to stop keepalives and close the socket */
  _conmonCleanups = /* @__PURE__ */ new Map();
  constructor() {
    logger6.info("StController initialized");
    this.txSocket = dgram3.createSocket({ type: "udp4", reuseAddr: true });
    this.txReady = new Promise((resolve) => {
      this.txSocket.bind(0, () => {
        logger6.debug(`TX socket bound to port ${this.txSocket.address().port}`);
        resolve();
      });
    });
    this.txSocket.on("error", (err) => {
      logger6.error(`TX socket error: ${err}`);
    });
    this.rxSocket = dgram3.createSocket({ type: "udp4", reuseAddr: true });
    this.rxSocket.on("listening", () => {
      const addr = this.rxSocket.address();
      logger6.debug(`RX socket listening on ${JSON.stringify(addr)}`);
      try {
        this.rxSocket.setMulticastLoopback(true);
      } catch (_e) {
      }
    });
    this.rxSocket.on("error", (err) => {
      logger6.error(`RX socket error: ${err}`);
    });
    this.rxSocket.on("message", (msg, rinfo) => {
      try {
        this.handleIncoming(msg, rinfo.address);
      } catch (_e) {
        logger6.error(`Error handling incoming message: ${_e}`);
      }
    });
    this.rxSocket.bind({ address: "0.0.0.0", port: this.rxPort }, () => {
      logger6.debug(`RX socket bound to 0.0.0.0:${this.rxPort}`);
      const ifaces = os2.networkInterfaces();
      for (const addrs of Object.values(ifaces)) {
        for (const addr of addrs ?? []) {
          if (addr.family === "IPv4" && !addr.internal && !this.joinedInterfaces.has(addr.address)) {
            try {
              this.rxSocket.addMembership(this.multicastGroup, addr.address);
              this.joinedInterfaces.add(addr.address);
              logger6.debug(`Pre-joined multicast ${this.multicastGroup} on ${addr.address}`);
            } catch (_e) {
              logger6.warn(`Could not pre-join multicast on ${addr.address}: ${String(_e)}`);
            }
          }
        }
      }
    });
    this.rxMcastSocket = dgram3.createSocket({ type: "udp4", reuseAddr: true });
    this.rxMcastSocket.on("error", (err) => {
      logger6.debug(`RX mcast socket error: ${err.message}`);
    });
    this.rxMcastSocket.on("message", (msg, rinfo) => {
      if (msg.length < 25)
        return;
      if (msg[0] !== 255 || msg[1] !== 255)
        return;
      const sig = msg.subarray(16, 24);
      if (sig.toString("ascii") !== "Studio-T")
        return;
      const stPayload = msg.subarray(24);
      if (stPayload.length < 2 || stPayload[0] !== 90)
        return;
      const respCmdId = stPayload[1];
      const isResponse = (respCmdId & 128) !== 0;
      const originalCmdId = respCmdId & 127;
      if (isResponse) {
        const key = `${rinfo.address}:${originalCmdId}`;
        const wasUnicastAlready = !this.mcastDeliveries.has(key);
        this.mcastDeliveries.add(key);
        logger6.debug(`Multicast delivery: ${rinfo.address} cmd:${toHex(originalCmdId)}` + (wasUnicastAlready ? " (unicast also pending)" : " (multicast only so far)"));
        setTimeout(() => this.mcastDeliveries.delete(key), 500);
      }
    });
    this.rxMcastSocket.bind({ address: this.multicastGroup, port: this.rxPort }, () => {
      logger6.debug(`RX mcast socket bound to ${this.multicastGroup}:${this.rxPort}`);
    });
  }
  close() {
    for (const cleanup of this._conmonCleanups.values()) {
      try {
        cleanup();
      } catch {
      }
    }
    this._conmonCleanups.clear();
    try {
      for (const localAddr of Array.from(this.joinedInterfaces)) {
        try {
          this.rxSocket.dropMembership(this.multicastGroup, localAddr);
        } catch {
        }
      }
    } catch {
    }
    try {
      this.rxMcastSocket?.close();
      this.rxMcastSocket = null;
    } catch {
    }
    try {
      this.rxSocket.close();
    } catch {
    }
    try {
      this.txSocket.close();
    } catch {
    }
  }
  /**
   * Provide the active device model and action definitions so incoming messages
   * can be decoded into human-readable names. Call from main.ts after config load.
   */
  setModel(model, actions) {
    this.model = model;
    this.actions = actions;
  }
  /**
   * Set callback to trigger when device state changes (for feedbacks).
   * Call from main.ts to wire up checkFeedbacks.
   */
  setFeedbackCallback(callback) {
    this.feedbackCallback = callback;
  }
  /** Returns true if the device at the given IP has been authorized to receive commands. */
  isDeviceAuthorized(ip) {
    return this.authorizedIps.has(ip);
  }
  /** Mark an IP as verified and allowed to receive Studio-T commands. */
  authorizeDevice(ip) {
    this.authorizedIps.add(ip);
    logger6.debug(`Authorized device at ${ip}`);
  }
  /** Remove authorization for an IP (e.g. on config change or model mismatch). */
  revokeDevice(ip) {
    this.authorizedIps.delete(ip);
    this.deviceState.delete(ip);
    this.macCache.delete(ip);
    this.sessionEstablished.delete(ip);
    this._conmonCleanups.get(ip)?.();
    this._conmonCleanups.delete(ip);
    logger6.debug(`Revoked device at ${ip}`);
  }
  /**
   * Opens a Dante ConMon session for the device if "useConMon": true is set in its
   * device JSON. Caches the result so the handshake only runs once per IP.
   * Delegates to conmon.ts. Devices without useConMon are marked as ready immediately.
   */
  async openSession(deviceIp) {
    if (this.sessionEstablished.has(deviceIp))
      return true;
    const schema = getDeviceSchema(this.model);
    if (!schema?.useConMon) {
      this.sessionEstablished.add(deviceIp);
      return true;
    }
    const cleanup = await openConMonSession(deviceIp);
    const success = cleanup !== null;
    this.sessionEstablished.add(deviceIp);
    if (success) {
      this._conmonCleanups.set(deviceIp, cleanup);
    }
    return success;
  }
  /**
   * Sends a unicast Dante info request to a specific IP and waits for the
   * device info response. Returns the DeviceInfo if the device responds within
   * timeoutMs, or null if no response. Used to verify a manually configured IP.
   * Does NOT require authorization — this is how authorization is established.
   */
  async probeDevice(ip, timeoutMs = 3e3) {
    await this.txReady;
    return probeDevice(this.txSocket, (key, cb) => this.discoveryListeners.set(key, cb), (key) => this.discoveryListeners.delete(key), async (destIp) => this.ensureMembershipFor(destIp), ip, timeoutMs);
  }
  /**
   * Send a CMD_GET_ALL_SETTINGS (0x0a) request to the device and store the response
   * in deviceState. Returns the raw response buffer for parsing.
   */
  async requestAllSettings(deviceIp) {
    logger6.info(`Requesting all settings from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_ALL_SETTINGS, void 0, void 0, void 0, deviceIp, false);
    return response;
  }
  /**
   * Discovers Studio Technologies Dante devices on the local network.
   *
   * Listens for Dante announces on 224.0.0.233:8708, sends unicast info requests
   * to each discovered IP, and collects 0x0170 responses via the rxSocket.
   */
  async discoverDevices(timeoutMs = 5e3) {
    const DISCOVERY_KEY = "__discovery__";
    const foundDevices = [];
    this.discoveryListeners.set(DISCOVERY_KEY, (device) => {
      if (!foundDevices.some((d) => d.ip === device.ip)) {
        foundDevices.push(device);
      }
    });
    try {
      await this.txReady;
      await discoverDevices(this.txSocket, async (destIp) => this.ensureMembershipFor(destIp), timeoutMs);
      return foundDevices;
    } finally {
      this.discoveryListeners.delete(DISCOVERY_KEY);
    }
  }
  /**
   * Requests device firmware version via Studio-T protocol (CMD_GET_FIRMWARE).
   * Returns the firmware version string (e.g., "3.01", "2.2", "1.05").
   */
  async requestFirmwareVersion(deviceIp) {
    logger6.info(`Requesting firmware version from ${deviceIp}`);
    const response = await this.sendAwaitAck(CMD_GET_FIRMWARE, void 0, void 0, void 0, deviceIp, false);
    const dataStart = 26;
    if (response.length < dataStart + 3) {
      logger6.warn(`Firmware response too short: ${response.length} bytes`);
      return "Unknown";
    }
    const major = response[dataStart + 1];
    const minor = response[dataStart + 2];
    const minorStr = minor < 10 ? minor.toString().padStart(2, "0") : minor.toString();
    const firmware = `${major}.${minorStr}`;
    logger6.debug(`Firmware version: ${firmware}`);
    return firmware;
  }
  /**
   * Joins the multicast response group on the interface that routes to destIp.
   * Only joins the specific interface used to reach the device, and only once per interface.
   */
  async ensureMembershipFor(destIp) {
    try {
      const localAddr = await getLocalAddressForDestination(destIp);
      if (!localAddr) {
        logger6.warn(`Could not determine local address for destination ${destIp}`);
        return;
      }
      if (this.joinedInterfaces.has(localAddr)) {
        return;
      }
      try {
        this.rxSocket.addMembership(this.multicastGroup, localAddr);
        this.joinedInterfaces.add(localAddr);
        logger6.info(`Joined multicast ${this.multicastGroup} on ${localAddr}`);
      } catch (_e) {
        logger6.warn(`Failed to join multicast on ${localAddr}: ${String(_e)}`);
      }
    } catch (_e) {
      logger6.warn(`ensureMembershipFor failed: ${_e}`);
    }
  }
  async sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    this.pendingCommandCount++;
    return new Promise((resolve, reject) => {
      this.sendQueue = this.sendQueue.then(async () => this._sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen).then((buf) => {
        this.pendingCommandCount--;
        if (this.pendingCommandCount === 0 && value !== void 0) {
          this.requestAllSettings(destIp).catch((err) => {
            logger6.warn(`Failed to refresh settings after command: ${err}`);
          });
        }
        resolve(buf);
      }).catch((err) => {
        this.pendingCommandCount--;
        reject(err instanceof Error ? err : new Error(String(err)));
      }));
    });
  }
  async _sendAwaitAck(cmdId, busCh, settingId, value, destIp, addLen = true) {
    const timeoutMs = 2e3;
    const dataBlock = [];
    if (settingId !== void 0)
      dataBlock.push(settingId & 255);
    if (value !== void 0)
      dataBlock.push(..._StController.buildValueBytes(value));
    const payloadBody = [90, cmdId & 255];
    if (cmdId === CMD_MIC_PRE && busCh !== void 0 && settingId !== void 0 && value !== void 0) {
      if (!this.deviceState.has(destIp))
        this.deviceState.set(destIp, /* @__PURE__ */ new Map());
      const ipState = this.deviceState.get(destIp);
      const numPositions = 3;
      const positions = [];
      for (let i = 0; i < numPositions; i++) {
        const stateKey = makeSettingId(this.model, CMD_MIC_PRE, i, busCh);
        const val = i === settingId ? Number(value) : ipState.get(stateKey) ?? 0;
        positions.push(val);
        ipState.set(stateKey, val);
      }
      payloadBody.push(busCh & 255, ...positions);
    } else {
      if (busCh !== void 0)
        payloadBody.push(busCh & 255);
      if (addLen)
        payloadBody.push(dataBlock.length);
      if (dataBlock.length > 0)
        payloadBody.push(...dataBlock);
    }
    const crc = _StController.crc8DvbS2(payloadBody);
    const payloadWithCrc = Buffer.from([...payloadBody, crc]);
    if (settingId !== void 0 && value !== void 0) {
      const valueBytes = _StController.buildValueBytes(value);
      const setting = {
        cmd_id: cmdId,
        id: settingId,
        busCh,
        valueBytes
      };
      logger6.info(`TX ${destIp} | ${formatParsedSetting(setting, this.actions)}`);
    } else {
      logger6.info(`TX ${destIp} | ${getCommandName(cmdId)}`);
    }
    if (!this.authorizedIps.has(destIp)) {
      logger6.debug(`Packet (not sent \u2014 device not authorized) to ${destIp}: ${payloadWithCrc.toString("hex")}`);
      throw new Error(`Device at ${destIp} is not authorized \u2014 verify the IP and model match before sending commands`);
    }
    if (!this.sessionEstablished.has(destIp)) {
      await this.openSession(destIp);
    }
    await this.ensureMembershipFor(destIp);
    const totalLen = 24 + payloadWithCrc.length;
    const header = await this.buildHeader(totalLen, destIp);
    const packet = Buffer.concat([header, payloadWithCrc]);
    logger6.debug(`Sending packet to ${destIp}: ${packet.toString("hex")}`);
    const key = `${destIp}:${cmdId}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingAcks.delete(key);
        reject(new Error(`Timeout waiting for ACK from Model ${this.model} at ${destIp}:8700`));
      }, timeoutMs);
      this.pendingAcks.set(key, {
        resolve: (buf) => {
          clearTimeout(timer);
          resolve(buf);
        },
        reject: (err) => {
          clearTimeout(timer);
          reject(err);
        },
        timer
      });
      this.txSocket.send(packet, this.defaultPort, destIp, (err) => {
        if (err) {
          this.pendingAcks.delete(key);
          clearTimeout(timer);
          reject(new Error(err.message ?? String(err)));
        }
      });
    });
  }
  handleIncoming(msg, srcIp) {
    if (msg.length < 4)
      return;
    if (msg[0] !== 255 || msg[1] !== 255)
      return;
    const msgType = msg.readUInt16BE(2);
    if (msgType === DANTE_MSG_INFO_RESPONSE && this.discoveryListeners.size > 0) {
      const device = parseDanteInfoResponse(msg, srcIp);
      if (device) {
        logger6.debug(`Dante info response from ${srcIp}: DeviceID="${device.name}", Model="${device.model}", ModelName="${device.modelName}", Manufacturer="${device.manufacturer}"`);
        if (device.name === "Studio-T") {
          for (const cb of this.discoveryListeners.values()) {
            try {
              cb(device);
            } catch {
            }
          }
        } else {
          logger6.debug(`Ignoring non-Studio Technologies device: DeviceID="${device.name}" @ ${srcIp}`);
        }
      }
      return;
    }
    if (msg.length < 25)
      return;
    const sig = msg.subarray(16, 24);
    if (sig.toString("ascii") !== "Studio-T")
      return;
    if (!this.authorizedIps.has(srcIp)) {
      logger6.debug(`Ignoring Studio-T packet from unauthorized device ${srcIp}`);
      return;
    }
    const stPayload = msg.subarray(24);
    if (stPayload.length < 2)
      return;
    if (stPayload[0] !== 90)
      return;
    const respCmdId = stPayload[1];
    const isResponse = (respCmdId & 128) !== 0;
    const originalCmdId = respCmdId & 127;
    if (isResponse) {
      const key = `${srcIp}:${originalCmdId}`;
      const pending = this.pendingAcks.get(key);
      if (pending) {
        this.pendingAcks.delete(key);
        const viaMulticast = this.mcastDeliveries.has(key);
        logger6.debug(`RX delivery method: ${srcIp} cmd:${toHex(originalCmdId)} via ${viaMulticast ? "multicast" : "unicast"}`);
        if (originalCmdId === CMD_GET_ALL_SETTINGS) {
          logger6.debug(`Received packet from ${srcIp}: ${msg.toString("hex")}`);
        }
        this.logStPayload(srcIp, originalCmdId, msg, stPayload);
        pending.resolve(msg);
      } else if (originalCmdId === CMD_SETTINGS_PUSH) {
        this.logStPayload(srcIp, originalCmdId, msg, stPayload);
      }
    } else {
      const data = stPayload.subarray(2, stPayload.length - 1);
      const hasSchemaEntries = this.actions.some((a) => a.cmd_id === originalCmdId);
      if (hasSchemaEntries && data.length >= 2) {
        const dataLen = data[0];
        const payload = data.subarray(1);
        if (payload.length >= dataLen && dataLen > 0) {
          const parsed = [];
          let q = 0;
          while (q + 1 < dataLen) {
            const id = payload[q];
            const valueBytes = [payload[q + 1]];
            parsed.push({ cmd_id: originalCmdId, id, valueBytes });
            q += 2;
          }
          if (parsed.length > 0) {
            this.applyParsedSettings(srcIp, parsed);
            return;
          }
        }
      }
      this.logStPayload(srcIp, originalCmdId, msg, stPayload);
    }
  }
  /**
   * Applies a list of parsed settings to deviceState, logs changes, and triggers feedbacks.
   * Shared by the CMD_GET_ALL_SETTINGS/CMD_SETTINGS_PUSH path and the direct-push path.
   */
  applyParsedSettings(srcIp, settings) {
    const state = this.deviceState.get(srcIp) ?? /* @__PURE__ */ new Map();
    if (!this.deviceState.has(srcIp))
      this.deviceState.set(srcIp, state);
    for (const s of settings) {
      const stateKey = makeSettingId(this.model, s.cmd_id, s.id, s.busCh);
      const newValue = s.valueBytes.length === 3 ? s.valueBytes[0] << 16 | s.valueBytes[1] << 8 | s.valueBytes[2] : s.valueBytes[0] ?? 0;
      const prevValue = state.get(stateKey);
      const changed = prevValue === void 0 || prevValue !== newValue;
      state.set(stateKey, newValue);
      const formatted = formatParsedSetting(s, this.actions);
      if (changed) {
        logger6.info(`RX ${srcIp} | ${formatted}`);
        if (this.feedbackCallback) {
          let baseId = s.id;
          const baseAction = this.actions.find((a) => {
            if (a.cmd_id !== s.cmd_id)
              return false;
            if (a.id === s.id)
              return true;
            const idAddOption = a.options?.find((o) => o.id === "idAdd");
            if (!idAddOption?.choices)
              return false;
            const offset = s.id - a.id;
            return offset > 0 && idAddOption.choices.some((c) => c.id === offset);
          });
          if (baseAction)
            baseId = baseAction.id;
          const baseFeedbackKey = makeSettingId(this.model, s.cmd_id, baseId);
          this.feedbackCallback(baseFeedbackKey);
          this.feedbackCallback(baseFeedbackKey + "_bool");
        } else {
          logger6.warn(`feedbackCallback not set \u2014 skipping feedback update for ${stateKey}`);
        }
      } else {
        logger6.debug(`RX ${srcIp} | ${formatted}`);
      }
    }
  }
  /**
   * Decodes and logs a Studio-T response payload.
   * Receives both the full msg (for parsers that need the Studio-T header)
   * and stPayload (msg.subarray(24), for direct byte access).
   *
   * stPayload layout:
   *   [0]      0x5a  magic
   *   [1]      cmdId | 0x80
   *   [2..-2]  data bytes
   *   [-1]     CRC-8/DVB-S2
   */
  logStPayload(srcIp, cmdId, msg, stPayload) {
    const cmdName = getCommandName(cmdId);
    const data = stPayload.subarray(2, stPayload.length - 1);
    const respCmdId = stPayload[1];
    const crc = stPayload[stPayload.length - 1];
    const fullStructure = `[cmd:${toHex(respCmdId)} data:${data.toString("hex")} crc:${toHex(crc)}]`;
    if (cmdId === CMD_GET_ALL_SETTINGS || cmdId === CMD_SETTINGS_PUSH) {
      if (!this.model) {
        logger6.info(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
        return;
      }
      try {
        const settings = cmdId === CMD_SETTINGS_PUSH ? parseSettingsResponse(this.model, msg) : parseGetAllSettingsForModel(this.model, msg);
        this.applyParsedSettings(srcIp, settings);
      } catch (e) {
        logger6.warn(`RX ${srcIp} | ${cmdName} | parse failed: ${e} | ${fullStructure}`);
      }
      return;
    }
    const decoded = this.decodeStData(cmdId, data);
    const logFn = cmdId === CMD_BUS_GET ? logger6.debug.bind(logger6) : logger6.info.bind(logger6);
    if (decoded) {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure} | ${decoded}`);
    } else {
      logFn(`RX ${srcIp} | ${cmdName} | ${fullStructure}`);
    }
  }
  /**
   * Attempts to decode the data bytes of a Studio-T response into a
   * human-readable string. Returns null to fall back to raw hex.
   */
  decodeStData(cmdId, data) {
    if (data.length === 0)
      return "ACK";
    if (data.length === 1) {
      if (data[0] === 0) {
        return "ACK ok";
      } else {
        return `ERROR ${toHex(data[0])}`;
      }
    }
    switch (cmdId) {
      // ── CMD_MIC_PRE (0x02): raw preamp echo — positional bytes, no setting IDs ──
      // Device echoes [busCh][val0][val1]... confirming the applied values.
      case CMD_MIC_PRE: {
        const busCh = data[0];
        const vals = Array.from(data.subarray(1)).map((b, i) => `[${i}]=0x${b.toString(16).padStart(2, "0")}(${b})`).join(" ");
        return `ch=${busCh} ${vals}`;
      }
      // ── CMD_DEV_SPEC (0x0d): single-byte ACK or echo of applied setting ──
      // Device sends two CMD_DEV_SPEC packets in response to a set:
      //   1. ACK:  [status]               (1 byte, 0x00 = ok)
      //   2. Echo: [busCh] [settingId] [value...]  (confirming what was applied)
      case CMD_DEV_SPEC: {
        if (data.length === 1) {
          return data[0] === 0 ? "ACK ok" : `ACK err=${toHex(data[0])}`;
        }
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const choices = action?.options?.find((o) => o.id === "value")?.choices;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ? `${choiceLabel} (${toHex(valueNum)})` : bytesToHex(Array.from(valueBytes));
          const rawTag = `[${toHex(cmdId)}/${toHex(settingId)}]=${bytesToHex(Array.from(valueBytes))}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr} ${rawTag}`;
        }
        return `raw: ${data.toString("hex")}`;
      }
      // ── CMD_MIC_PRE_BUS (0x12): Multi-byte echo responses ─────────────
      case CMD_MIC_PRE_BUS: {
        if (data.length >= 3) {
          const busCh = data[0];
          const settingId = data[1];
          const valueBytes = data.subarray(2);
          const action = this.actions.find((a) => a.cmd_id === cmdId && a.id === settingId);
          const settingName = action?.name ?? `setting=${toHex(settingId)}`;
          const valueNum = valueBytes.length === 1 ? valueBytes[0] : void 0;
          const choices = action?.options?.find((o) => o.id === "value")?.choices;
          const choiceLabel = choices && valueNum !== void 0 ? choices.find((c) => c.id === valueNum)?.label : void 0;
          const valueStr = choiceLabel ?? `0x${valueBytes.toString("hex")}`;
          return `echo ch=${busCh} | ${settingName}: ${valueStr}`;
        }
        return null;
      }
      // ── Bus-scoped get/set ────────────────────────────────────────────
      case CMD_BUS_GET:
      case CMD_BUS_SET: {
        if (data.length < 2)
          return null;
        const busCh = data[0];
        const settingId = data[1];
        const value = data.subarray(2);
        return `ch=${busCh} setting=${toHex(settingId)} value=${value.toString("hex")}`;
      }
      default:
        return null;
    }
  }
  static buildValueBytes(value) {
    if (typeof value === "boolean")
      return [value ? 1 : 0];
    if (Array.isArray(value))
      return value.map((v) => Number(v) & 255);
    if (typeof value === "number") {
      if (value > 255)
        return [value >> 16 & 255, value >> 8 & 255, value & 255];
      return [value & 255];
    }
    throw new Error(`Unsupported value type for STcontroller: ${value}`);
  }
  async buildHeader(totalLen, destIp) {
    let mac = this.macCache.get(destIp);
    if (!mac) {
      mac = await getMacForDestination(destIp);
      this.macCache.set(destIp, mac);
    }
    return Buffer.concat([
      Buffer.from([255, 255, 0, totalLen & 255, 7, 225, 0, 0, ...mac, 0, 0]),
      Buffer.from("Studio-T", "utf8")
    ]);
  }
  static crc8DvbS2(data) {
    let crc = 0;
    for (const b of data) {
      crc ^= b;
      for (let i = 0; i < 8; i++) {
        crc = (crc & 128) !== 0 ? (crc << 1 ^ 213) & 255 : crc << 1 & 255;
      }
    }
    return crc;
  }
  /**
   * Returns the current known value for a setting on a device, or undefined if unknown.
   * Use for feedbacks — value is updated on every CMD_SETTINGS_PUSH (0x0b) from the device.
   *
   * @param ip        Device IP address
   * @param cmdId     Command ID (e.g. CMD_DEV_SPEC)
   * @param settingId Setting ID (e.g. 0x02 for Control Source)
   * @param busCh     Optional bus/channel ID for multi-channel commands
   */
  getSettingValue(ip, cmdId, settingId, busCh) {
    const key = makeSettingId(this.model, cmdId, settingId, busCh);
    return this.deviceState.get(ip)?.get(key);
  }
  async resetDevice(destIp) {
    return this.sendAwaitAck(CMD_RESET_DEVICE, void 0, 0, void 0, destIp, false);
  }
  async globalMicKill(destIp) {
    return this.sendAwaitAck(CMD_GLOBAL_MIC_KILL, void 0, void 0, void 0, destIp, false);
  }
};

// dist/main.js
var logger7 = createModuleLogger("ModuleInstance");
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  stController;
  /** Cached discovery results — passed into getConfigFields() so the UI
   *  can show the discovered device dropdown on subsequent config opens. */
  discoveredDevices = [];
  /** Currently active model — resolved once in syncModel() and cached here
   *  so UpdateActions, UpdateFeedbacks etc. don't each call resolveModel independently. */
  activeModel = "";
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    if (!this.stController) {
      this.stController = new StController();
    }
    this.updateStatus(InstanceStatus.Connecting, "Discovering devices...");
    this.stController.setFeedbackCallback((feedbackId) => {
      this.checkFeedbacks(feedbackId);
    });
    this.runDiscovery().catch((e) => {
      logger7.error(`Discovery failed: ${e}`);
    });
  }
  /**
   * Run device discovery, then resolve the model and update all UI.
   * - If discovery finds devices, resolveModel picks from those.
   * - Only if the list is empty do we fall back to the manual config selection.
   * All actions/feedbacks/variables are built after the model is known.
   */
  async runDiscovery() {
    logger7.info("Starting device discovery...");
    this.discoveredDevices = await this.stController.discoverDevices();
    let effectiveModel;
    if (this.discoveredDevices.length === 0) {
      if (this.config.deviceMac) {
        logger7.warn(`Saved device MAC "${this.config.deviceMac}" not found during discovery \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `[${this.config.deviceMac}] not found`);
        return;
      }
      const manualModel = this.config.activeModel;
      if (!this.config.host || !manualModel) {
        logger7.warn("No devices discovered and no manual IP/model configured");
        return;
      }
      logger7.info("No devices discovered \u2014 will probe manual IP during authorization");
      effectiveModel = manualModel;
    } else {
      logger7.info(`Discovered ${this.discoveredDevices.length} device(s):`);
      for (const d of this.discoveredDevices) {
        logger7.info(`  - Model ${d.model} ${d.manufacturer ?? ""} @ ${d.ip}`);
      }
      for (const device of this.discoveredDevices) {
        this.stController.authorizeDevice(device.ip);
      }
      for (const device of this.discoveredDevices) {
        try {
          const firmware = await this.stController.requestFirmwareVersion(device.ip);
          device.firmwareMain = firmware;
          logger7.info(`  - ${device.ip}: Firmware ${firmware}, Dante ${device.danteFirmware}`);
        } catch (e) {
          logger7.warn(`  - ${device.ip}: Failed to get firmware: ${e}`);
          device.firmwareMain = "Unknown";
        }
      }
      effectiveModel = resolveModel(this.config, this.discoveredDevices);
      if (!effectiveModel && this.config.deviceMac) {
        logger7.warn(`Saved device MAC "${this.config.deviceMac}" not found among discovered devices \u2014 stopping`);
        this.updateStatus(InstanceStatus.ConnectionFailure, `[${this.config.deviceMac}] not found`);
        return;
      }
    }
    this.syncModel(effectiveModel);
    const targetHost = this.host;
    await this.verifyAuthorization("", targetHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
    logger7.info("Device discovery complete");
  }
  // When module gets deleted
  async destroy() {
    this.stController?.close();
    logger7.debug("destroy");
  }
  async configUpdated(config) {
    const previousHost = this.host;
    this.config = config;
    const effectiveModel = resolveModel(config, this.discoveredDevices);
    this.syncModel(effectiveModel);
    this.updateVariableValues();
    const newHost = this.host;
    await this.verifyAuthorization(previousHost, newHost);
    this.updateActions();
    this.updateFeedbacks();
    this.updateVariableDefinitions();
    this.updateVariableValues();
  }
  /**
   * Re-evaluates whether the current config is authorized to send commands.
   *
   * Auto mode (deviceMac set):
   *   - Find the discovered device with matching MAC → get its current IP
   *   - Revoke the previous IP, authorize the new IP
   *   - If MAC not found in discovery, revoke and block
   *
   * Manual mode (deviceMac empty):
   *   - Check discovered list by IP+model match, or probe directly
   */
  async verifyAuthorization(previousHost, newHost) {
    if (!newHost) {
      if (previousHost)
        this.stController.revokeDevice(previousHost);
      return;
    }
    if (this.config.deviceMac) {
      const device = this.discoveredDevices.find((d) => d.mac === this.config.deviceMac);
      if (!device) {
        logger7.warn(`Device MAC "${this.config.deviceMac}" not found in current discovery \u2014 not authorizing`);
        if (previousHost)
          this.stController.revokeDevice(previousHost);
        return;
      }
      if (previousHost && previousHost !== newHost) {
        this.stController.revokeDevice(previousHost);
      }
      const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
      if (!wasAuthorized) {
        this.stController.authorizeDevice(newHost);
      }
      if (newHost !== previousHost || !wasAuthorized) {
        await this.fetchSettingsAndEnsureSchema(device.model, newHost);
      }
      this.updateStatus(InstanceStatus.Ok, `Model ${device.model} @ ${newHost}`);
      return;
    }
    const manualModel = String(this.config.activeModel ?? "");
    const discoveredAtIp = this.discoveredDevices.find((d) => d.ip === newHost);
    if (discoveredAtIp) {
      if (discoveredAtIp.model === manualModel) {
        if (previousHost && previousHost !== newHost)
          this.stController.revokeDevice(previousHost);
        const wasAuthorized = this.stController.isDeviceAuthorized(newHost);
        if (!wasAuthorized) {
          this.stController.authorizeDevice(newHost);
        }
        if (newHost !== previousHost || !wasAuthorized) {
          await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
        }
        this.updateStatus(InstanceStatus.Ok, `Model ${manualModel} @ ${newHost}`);
      } else {
        logger7.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${discoveredAtIp.model}) at ${newHost} \u2014 commands blocked`);
        this.stController.revokeDevice(newHost);
        this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${discoveredAtIp.model}`);
      }
      return;
    }
    logger7.info(`${newHost} not in discovered list \u2014 probing`);
    if (previousHost && previousHost !== newHost)
      this.stController.revokeDevice(previousHost);
    this.stController.revokeDevice(newHost);
    const probed = await this.stController.probeDevice(newHost);
    if (!probed) {
      logger7.error(`No device responded at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.UnknownWarning, `Device offline: ${newHost}`);
    } else if (probed.model !== manualModel) {
      logger7.error(`Device selected (Model ${manualModel}) does not match detected device (Model ${probed.model}) at ${newHost} \u2014 commands blocked`);
      this.updateStatus(InstanceStatus.ConnectionFailure, `Model mismatch: expected ${manualModel}, got ${probed.model}`);
    } else {
      logger7.info(`Verified Model ${probed.model} at ${newHost}`);
      this.stController.authorizeDevice(newHost);
      await this.fetchSettingsAndEnsureSchema(manualModel, newHost);
      this.updateStatus(InstanceStatus.Ok, `Model ${probed.model} @ ${newHost}`);
    }
  }
  /**
   * Fetches all settings from the device. If no schema exists for the model,
   * creates one from the response and reloads the schema cache.
   */
  async fetchSettingsAndEnsureSchema(model, ip) {
    try {
      await this.stController.requestAllSettings(ip);
      if (!getDeviceSchema(model)) {
        logger7.warn(`No schema found for Model ${model} \u2014 run "GLOBAL: Get All Settings" to create one`);
        return;
      }
    } catch (e) {
      logger7.warn(`Failed to fetch settings from ${ip}: ${e}`);
    }
  }
  /** Loads the device JSON for the given model, caches it as activeModel, and pushes it to the controller. */
  syncModel(model) {
    this.activeModel = model;
    const schema = getDeviceSchema(model);
    if (!schema) {
      logger7.warn(`Model "${model}" not found in device schemas`);
      this.stController.setModel(model, []);
      return;
    }
    const actions = Array.isArray(schema.cmdSchema) ? schema.cmdSchema : [];
    this.stController.setModel(model, actions);
    if (actions.length === 0) {
      logger7.warn(`No actions found for model "${model}" \u2014 settings decoding will use raw IDs`);
    } else {
      logger7.debug(`Loaded ${actions.length} actions for model "${model}"`);
    }
  }
  getConfigFields() {
    return GetConfigFields(this.discoveredDevices);
  }
  /** Returns the effective host IP, resolved from MAC→IP via discoveredDevices (auto) or config.host (manual). */
  get host() {
    return resolveHost(this.config, this.discoveredDevices);
  }
  /** Returns discovered devices for use in actions/config */
  get devices() {
    return this.discoveredDevices;
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  updateVariableValues() {
    UpdateVariableValues(this);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2xvZ2dpbmcudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL3V0aWwudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvc2hhcmVkLXVkcC1zb2NrZXQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL2hvc3QtYXBpL2NvbnRleHQudHMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0Bjb21wYW5pb24tbW9kdWxlL2Jhc2Uvc3JjL21vZHVsZS1hcGkvYmFzZS50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9lbnVtcy50cyIsICIuLi8uLi9zcmMvY29uZmlnLnRzIiwgIi4uLy4uL3NyYy92YXJpYWJsZXMudHMiLCAiLi4vLi4vc3JjL3VwZ3JhZGVzLnRzIiwgIi4uLy4uL3NyYy90eXBlcy50cyIsICIuLi8uLi9zcmMvYnVpbGQtY29tbWFuZHMudHMiLCAiLi4vLi4vc3JjL2FjdGlvbnMudHMiLCAiLi4vLi4vc3JjL3NldHRpbmdzUGFyc2VyLnRzIiwgIi4uLy4uL3NyYy9mZWVkYmFja3MudHMiLCAiLi4vLi4vc3JjL3N0Y29udHJvbGxlci50cyIsICIuLi8uLi9zcmMvZGFudGUudHMiLCAiLi4vLi4vc3JjL2Nvbm1vbi50cyIsICIuLi8uLi9zcmMvbWFpbi50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFtudWxsLCBudWxsLCBudWxsLCBudWxsLCBudWxsLCBudWxsLCAiaW1wb3J0IGZzIGZyb20gJ2ZzJ1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCdcbmltcG9ydCB7IFJlZ2V4LCB0eXBlIFNvbWVDb21wYW5pb25Db25maWdGaWVsZCwgdHlwZSBKc29uT2JqZWN0LCBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHR5cGUgeyBEZXZpY2VJbmZvIH0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdDb25maWcnKVxuXG5leHBvcnQgdHlwZSBNb2R1bGVDb25maWcgPSBKc29uT2JqZWN0ICYge1xuXHQvKiogTUFDIG9mIHRoZSBzZWxlY3RlZCBkaXNjb3ZlcmVkIGRldmljZSAoZS5nLiBcIjAwOjFkOmMxOjliOmE2OmNkXCIpLCBvciAnJyBmb3IgbWFudWFsIG1vZGUgKi9cblx0ZGV2aWNlTWFjOiBzdHJpbmdcblx0LyoqIE1hbnVhbCBJUCBhZGRyZXNzIFx1MjAxNCBvbmx5IHVzZWQgd2hlbiBkZXZpY2VNYWMgaXMgJycgKi9cblx0aG9zdDogc3RyaW5nXG5cdC8qKiBNYW51YWwgbW9kZWwgc2VsZWN0aW9uIFx1MjAxNCBvbmx5IHVzZWQgd2hlbiBkZXZpY2VNYWMgaXMgJycgKi9cblx0YWN0aXZlTW9kZWw6IHN0cmluZ1xuXHQvKiogRW5hYmxlIHBhcnNpbmcgb2YgdW5zdXBwb3J0ZWQgU1QgZGV2aWNlcyAqL1xuXHRkZXZNb2RlOiBib29sZWFuXG59XG5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbi8vIENFTlRSQUxJWkVEIERFVklDRSBTQ0hFTUEgQ0FDSEVcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbi8vIEFsbCBkZXZpY2UgSlNPTiBmaWxlcyBhcmUgbG9hZGVkIG9uY2UgaW50byBtZW1vcnkgaGVyZS4gT3RoZXIgbW9kdWxlcyBzaG91bGRcbi8vIHVzZSBnZXREZXZpY2VzRm9sZGVyKCksIGdldERldmljZVNjaGVtYXMoKSwgYW5kIGdldERldmljZVNjaGVtYSgpIGluc3RlYWQgb2Zcbi8vIHJlYWRpbmcgZmlsZXMgZGlyZWN0bHkuIENhbGwgcmVsb2FkRGV2aWNlU2NoZW1hcygpIGFmdGVyIHdyaXRpbmcgdG8gYSBmaWxlLlxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuXG4vKipcbiAqIERldGVybWluZXMgdGhlIGNvcnJlY3QgZGV2aWNlcyBmb2xkZXIgcGF0aCB3aXRoIGZhbGxiYWNrIHN1cHBvcnQuXG4gKiBDaGVja3MgcHJpbWFyeSBwYXRoIGZpcnN0LCB0aGVuIGZhbGxiYWNrLCB0aGVuIHRocm93cyBlcnJvciBpZiBuZWl0aGVyIGV4aXN0cy5cbiAqL1xuZnVuY3Rpb24gcmVzb2x2ZURldmljZXNGb2xkZXIoKTogc3RyaW5nIHtcblx0Y29uc3QgcHJpbWFyeVBhdGggPSBwYXRoLmpvaW4oaW1wb3J0Lm1ldGEuZGlybmFtZSwgJy4uL2RldmljZXMnKVxuXHRjb25zdCBmYWxsYmFja1BhdGggPSBwYXRoLmpvaW4oaW1wb3J0Lm1ldGEuZGlybmFtZSwgJy4vZGV2aWNlcycpXG5cblx0Ly8gQ2hlY2sgcHJpbWFyeSBwYXRoXG5cdGlmIChmcy5leGlzdHNTeW5jKHByaW1hcnlQYXRoKSkge1xuXHRcdGxvZ2dlci5kZWJ1ZyhgVXNpbmcgZGV2aWNlcyBmb2xkZXI6ICR7cHJpbWFyeVBhdGh9YClcblx0XHRyZXR1cm4gcHJpbWFyeVBhdGhcblx0fVxuXG5cdC8vIENoZWNrIGZhbGxiYWNrIHBhdGhcblx0aWYgKGZzLmV4aXN0c1N5bmMoZmFsbGJhY2tQYXRoKSkge1xuXHRcdGxvZ2dlci53YXJuKGBQcmltYXJ5IGRldmljZXMgZm9sZGVyIG5vdCBmb3VuZCwgdXNpbmcgZmFsbGJhY2s6ICR7ZmFsbGJhY2tQYXRofWApXG5cdFx0cmV0dXJuIGZhbGxiYWNrUGF0aFxuXHR9XG5cblx0Ly8gTmVpdGhlciBwYXRoIGV4aXN0cyAtIGZhdGFsIGVycm9yXG5cdGNvbnN0IGVycm9yTXNnID0gYERldmljZXMgZm9sZGVyIG5vdCBmb3VuZCFcXG5UcmllZDpcXG4gIC0gJHtwcmltYXJ5UGF0aH1cXG4gIC0gJHtmYWxsYmFja1BhdGh9XFxuTW9kdWxlIGNhbm5vdCBjb250aW51ZSB3aXRob3V0IGRldmljZSBzY2hlbWFzLmBcblx0bG9nZ2VyLmVycm9yKGVycm9yTXNnKVxuXHR0aHJvdyBuZXcgRXJyb3IoZXJyb3JNc2cpXG59XG5cbi8vIFJlc29sdmUgdGhlIGRldmljZXMgZm9sZGVyIHBhdGggKHdpdGggZXhpc3RlbmNlIGNoZWNrIGFuZCBmYWxsYmFjaylcbmNvbnN0IGRldmljZXNGb2xkZXIgPSByZXNvbHZlRGV2aWNlc0ZvbGRlcigpXG5cbi8vIEluLW1lbW9yeSBjYWNoZSBvZiBhbGwgZGV2aWNlIHNjaGVtYXMsIGtleWVkIGJ5IG1vZGVsIG51bWJlclxubGV0IGRldmljZVNjaGVtYXNDYWNoZTogUmVjb3JkPHN0cmluZywgYW55PiB8IG51bGwgPSBudWxsXG5cbi8qKlxuICogUmV0dXJucyB0aGUgYWJzb2x1dGUgcGF0aCB0byB0aGUgZGV2aWNlcyBmb2xkZXIuXG4gKiBVc2UgdGhpcyBpbnN0ZWFkIG9mIHJlZGVmaW5pbmcgdGhlIHBhdGggaW4gZXZlcnkgZmlsZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldERldmljZXNGb2xkZXIoKTogc3RyaW5nIHtcblx0cmV0dXJuIGRldmljZXNGb2xkZXJcbn1cblxuLyoqXG4gKiBMb2FkcyBhbGwgZGV2aWNlIEpTT04gZmlsZXMgZnJvbSB0aGUgZGV2aWNlcyBmb2xkZXIgaW50byBtZW1vcnkuXG4gKiBUaGlzIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBvbmNlIGF0IGluaXRpYWxpemF0aW9uLCBvciBhZnRlciBhIGZpbGUgaXMgd3JpdHRlbi5cbiAqL1xuZnVuY3Rpb24gbG9hZERldmljZVNjaGVtYXMoKTogUmVjb3JkPHN0cmluZywgYW55PiB7XG5cdGNvbnN0IHNjaGVtYXM6IFJlY29yZDxzdHJpbmcsIGFueT4gPSB7fVxuXHR0cnkge1xuXHRcdGNvbnN0IGZpbGVzID0gZnMucmVhZGRpclN5bmMoZGV2aWNlc0ZvbGRlcikuZmlsdGVyKChmKSA9PiBmLmVuZHNXaXRoKCcuanNvbicpKVxuXG5cdFx0Zm9yIChjb25zdCBmIG9mIGZpbGVzKSB7XG5cdFx0XHRjb25zdCBmdWxsUGF0aCA9IHBhdGguam9pbihkZXZpY2VzRm9sZGVyLCBmKVxuXHRcdFx0Y29uc3QganNvbiA9IEpTT04ucGFyc2UoZnMucmVhZEZpbGVTeW5jKGZ1bGxQYXRoLCAndXRmOCcpKVxuXHRcdFx0aWYgKGpzb24/Lm1vZGVsKSB7XG5cdFx0XHRcdHNjaGVtYXNbU3RyaW5nKGpzb24ubW9kZWwpXSA9IGpzb25cblx0XHRcdH1cblx0XHR9XG5cblx0XHRsb2dnZXIuZGVidWcoYExvYWRlZCAke09iamVjdC5rZXlzKHNjaGVtYXMpLmxlbmd0aH0gZGV2aWNlIHNjaGVtYXMgaW50byBjYWNoZWApXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRsb2dnZXIuZXJyb3IoYEZhaWxlZCB0byBsb2FkIGRldmljZSBzY2hlbWFzOiAke2V9YClcblx0fVxuXHRyZXR1cm4gc2NoZW1hc1xufVxuXG4vKipcbiAqIFJldHVybnMgYWxsIGRldmljZSBzY2hlbWFzIGZyb20gdGhlIGNhY2hlLlxuICogSW5pdGlhbGl6ZXMgdGhlIGNhY2hlIG9uIGZpcnN0IGNhbGwuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREZXZpY2VTY2hlbWFzKCk6IFJlY29yZDxzdHJpbmcsIGFueT4ge1xuXHRpZiAoIWRldmljZVNjaGVtYXNDYWNoZSkge1xuXHRcdGRldmljZVNjaGVtYXNDYWNoZSA9IGxvYWREZXZpY2VTY2hlbWFzKClcblx0fVxuXHRyZXR1cm4gZGV2aWNlU2NoZW1hc0NhY2hlXG59XG5cbi8qKlxuICogUmV0dXJucyBhIHNwZWNpZmljIGRldmljZSBzY2hlbWEgYnkgbW9kZWwgbnVtYmVyLlxuICogUmV0dXJucyB1bmRlZmluZWQgaWYgdGhlIG1vZGVsIGRvZXNuJ3QgZXhpc3QuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREZXZpY2VTY2hlbWEobW9kZWw6IHN0cmluZyk6IGFueSB7XG5cdGNvbnN0IHNjaGVtYXMgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0cmV0dXJuIHNjaGVtYXNbbW9kZWxdXG59XG5cbi8qKlxuICogUmVsb2FkcyBhbGwgZGV2aWNlIHNjaGVtYXMgZnJvbSBkaXNrLlxuICogQ2FsbCB0aGlzIGFmdGVyIHdyaXRpbmcgdG8gYSBkZXZpY2UgSlNPTiBmaWxlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVsb2FkRGV2aWNlU2NoZW1hcygpOiB2b2lkIHtcblx0bG9nZ2VyLmluZm8oJ1JlbG9hZGluZyBkZXZpY2Ugc2NoZW1hcyBmcm9tIGRpc2suLi4nKVxuXHRkZXZpY2VTY2hlbWFzQ2FjaGUgPSBsb2FkRGV2aWNlU2NoZW1hcygpXG59XG5cbi8qKlxuICogUmV0dXJucyBhIGxpc3Qgb2YgYXZhaWxhYmxlIG1vZGVsIG51bWJlcnMsIHNvcnRlZC5cbiAqL1xuZnVuY3Rpb24gbG9hZEF2YWlsYWJsZU1vZGVscygpOiBzdHJpbmdbXSB7XG5cdGNvbnN0IHNjaGVtYXMgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0cmV0dXJuIE9iamVjdC5rZXlzKHNjaGVtYXMpLnNvcnQoKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gR2V0Q29uZmlnRmllbGRzKGRpc2NvdmVyZWREZXZpY2VzOiBEZXZpY2VJbmZvW10gPSBbXSk6IFNvbWVDb21wYW5pb25Db25maWdGaWVsZFtdIHtcblx0Y29uc3QgbW9kZWxzID0gbG9hZEF2YWlsYWJsZU1vZGVscygpXG5cblx0Ly8gRHJvcGRvd24gaWQgaXMgdGhlIGRldmljZSBNQUMgXHUyMDE0IHN0YWJsZSBhY3Jvc3MgSVAgY2hhbmdlcy5cblx0Ly8gRW1wdHkgaWQgPSBNYW51YWwgbW9kZS5cblx0Y29uc3QgZGV2aWNlQ2hvaWNlcyA9IFtcblx0XHR7IGlkOiAnJywgbGFiZWw6ICdNYW51YWwgKGVudGVyIElQICsgbW9kZWwgYmVsb3cpJyB9LFxuXHRcdC4uLmRpc2NvdmVyZWREZXZpY2VzLm1hcCgoZCkgPT4gKHtcblx0XHRcdGlkOiBkLm1hYyA/PyAnJyxcblx0XHRcdGxhYmVsOiBgTW9kZWwgJHtkLm1vZGVsfSBbJHtkLm1hY31dIEAgJHtkLmlwfWAsXG5cdFx0fSkpLFxuXHRdXG5cblx0cmV0dXJuIFtcblx0XHQvLyBcdTI1MDBcdTI1MDAgRGV2aWNlIHNlbGVjdGlvbiBkcm9wZG93biBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHQvLyBTdG9yZXMgdGhlIE1BQyBzbyByZS1kaXNjb3Zlcnkgd2l0aCBhIGNoYW5nZWQgSVAgc3RpbGwgbWF0Y2hlcy5cblx0XHR7XG5cdFx0XHR0eXBlOiAnZHJvcGRvd24nLFxuXHRcdFx0aWQ6ICdkZXZpY2VNYWMnLFxuXHRcdFx0bGFiZWw6ICdEZXZpY2UnLFxuXHRcdFx0d2lkdGg6IDgsXG5cdFx0XHRkZWZhdWx0OiAnJyxcblx0XHRcdGNob2ljZXM6IGRldmljZUNob2ljZXMsXG5cdFx0XHR0b29sdGlwOiAnU2VsZWN0IGFuIGF1dG8tZGlzY292ZXJlZCBTdHVkaW8gVGVjaG5vbG9naWVzIGRldmljZSwgb3IgY2hvb3NlIE1hbnVhbCB0byBlbnRlciBhbiBJUCBhZGRyZXNzLicsXG5cdFx0fSxcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBNYW51YWwgSVAgZW50cnkgXHUyMDE0IG9ubHkgdmlzaWJsZSBpbiBtYW51YWwgbW9kZSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHR7XG5cdFx0XHR0eXBlOiAndGV4dGlucHV0Jyxcblx0XHRcdGlkOiAnaG9zdCcsXG5cdFx0XHRsYWJlbDogJ1RhcmdldCBJUCcsXG5cdFx0XHR3aWR0aDogOCxcblx0XHRcdGRlZmF1bHQ6ICcnLFxuXHRcdFx0cmVnZXg6IFJlZ2V4LklQLFxuXHRcdFx0aXNWaXNpYmxlRXhwcmVzc2lvbjogYCEkKG9wdGlvbnM6ZGV2aWNlTWFjKWAsXG5cdFx0XHR0b29sdGlwOiAnRW50ZXIgdGhlIElQIGFkZHJlc3Mgb2YgdGhlIGRldmljZSBtYW51YWxseS4nLFxuXHRcdH0sXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgTWFudWFsIG1vZGVsIHNlbGVjdG9yIFx1MjAxNCBvbmx5IHZpc2libGUgaW4gbWFudWFsIG1vZGUgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdGlkOiAnYWN0aXZlTW9kZWwnLFxuXHRcdFx0bGFiZWw6ICdBY3RpdmUgRGV2aWNlIE1vZGVsJyxcblx0XHRcdHdpZHRoOiA4LFxuXHRcdFx0ZGVmYXVsdDogbW9kZWxzWzBdID8/ICcnLFxuXHRcdFx0Y2hvaWNlczogbW9kZWxzLm1hcCgobW9kZWwpID0+ICh7XG5cdFx0XHRcdGlkOiBtb2RlbCxcblx0XHRcdFx0bGFiZWw6IGBNb2RlbCAke21vZGVsfWAsXG5cdFx0XHR9KSksXG5cdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiBgISQob3B0aW9uczpkZXZpY2VNYWMpYCxcblx0XHRcdHRvb2x0aXA6ICdTZWxlY3Qgd2hpY2ggU3R1ZGlvIFRlY2hub2xvZ2llcyBtb2RlbCBpcyBhY3RpdmUgZm9yIGFjdGlvbnMgYW5kIGZlZWRiYWNrcy4nLFxuXHRcdH0sXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgRGV2IE1vZGUgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2NoZWNrYm94Jyxcblx0XHRcdGlkOiAnZGV2TW9kZScsXG5cdFx0XHRsYWJlbDogJ0RldiBNb2RlJyxcblx0XHRcdHdpZHRoOiAxMixcblx0XHRcdGRlZmF1bHQ6IGZhbHNlLFxuXHRcdFx0dG9vbHRpcDogJ0VuYWJsZSB0byBhbGxvdyBwYXJzaW5nIG9mIFNUIERldmljZXMgbm90IGN1cnJlbnRseSBzdXBwb3J0ZWQnLFxuXHRcdH0sXG5cdF1cbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBlZmZlY3RpdmUgaG9zdCBJUC5cbiAqIEF1dG8gbW9kZSAoZGV2aWNlTWFjIHNldCk6IGZpbmRzIHRoZSBjdXJyZW50IElQIG9mIHRoZSBkaXNjb3ZlcmVkIGRldmljZSB3aXRoIHRoYXQgTUFDLlxuICogTWFudWFsIG1vZGUgKGRldmljZU1hYyBlbXB0eSk6IHJldHVybnMgdGhlIG1hbnVhbGx5IGVudGVyZWQgaG9zdCBJUC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVIb3N0KGNvbmZpZzogTW9kdWxlQ29uZmlnLCBkaXNjb3ZlcmVkRGV2aWNlczogRGV2aWNlSW5mb1tdKTogc3RyaW5nIHtcblx0aWYgKGNvbmZpZy5kZXZpY2VNYWMpIHtcblx0XHRjb25zdCBkZXZpY2UgPSBkaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLm1hYyA9PT0gY29uZmlnLmRldmljZU1hYylcblx0XHRyZXR1cm4gZGV2aWNlPy5pcCA/PyAnJ1xuXHR9XG5cdHJldHVybiBTdHJpbmcoY29uZmlnLmhvc3QgPz8gJycpXG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgZWZmZWN0aXZlIG1vZGVsLlxuICogQXV0byBtb2RlOiB1c2VzIHRoZSBtb2RlbCBmcm9tIHRoZSBkaXNjb3ZlcmVkIGRldmljZSBtYXRjaGluZyB0aGUgc3RvcmVkIE1BQy5cbiAqIE1hbnVhbCBtb2RlOiB1c2VzIHRoZSBtYW51YWxseSBzZWxlY3RlZCBhY3RpdmVNb2RlbC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVNb2RlbChjb25maWc6IE1vZHVsZUNvbmZpZywgZGlzY292ZXJlZERldmljZXM6IERldmljZUluZm9bXSk6IHN0cmluZyB7XG5cdGlmIChjb25maWcuZGV2aWNlTWFjKSB7XG5cdFx0Y29uc3QgZGV2aWNlID0gZGlzY292ZXJlZERldmljZXMuZmluZCgoZCkgPT4gZC5tYWMgPT09IGNvbmZpZy5kZXZpY2VNYWMpXG5cdFx0bG9nZ2VyLmRlYnVnKGByZXNvbHZlTW9kZWw6IGRldmljZU1hYz1cIiR7Y29uZmlnLmRldmljZU1hY31cIiwgZm91bmQgZGV2aWNlOiAke2RldmljZT8ubW9kZWwgPz8gJ25vbmUnfWApXG5cdFx0cmV0dXJuIGRldmljZT8ubW9kZWwgPz8gJydcblx0fVxuXHRsb2dnZXIuZGVidWcoYHJlc29sdmVNb2RlbDogbWFudWFsIG1vZGUsIGFjdGl2ZU1vZGVsPVwiJHtjb25maWcuYWN0aXZlTW9kZWx9XCJgKVxuXHRyZXR1cm4gU3RyaW5nKGNvbmZpZy5hY3RpdmVNb2RlbCA/PyAnJylcbn1cbiIsICJpbXBvcnQgdHlwZSBNb2R1bGVJbnN0YW5jZSBmcm9tICcuL21haW4uanMnXG5cbi8qKlxuICogRGVmaW5lIENvbXBhbmlvbiB2YXJpYWJsZXMgZm9yIHRoaXMgbW9kdWxlLlxuICogVmFyaWFibGVzIGNhbiBiZSB1c2VkIHRvIGRpc3BsYXkgZHluYW1pYyBzdGF0ZSBpbiBidXR0b24gbGFiZWxzLCB0cmlnZ2VycywgZXRjLlxuICovXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRzZWxmLnNldFZhcmlhYmxlRGVmaW5pdGlvbnMoe1xuXHRcdG1vZGVsOiB7IG5hbWU6ICdEZXZpY2UgTW9kZWwgTnVtYmVyJyB9LFxuXHRcdG1vZGVsTmFtZTogeyBuYW1lOiAnRGV2aWNlIE1vZGVsIE5hbWUgKEZ1bGwgRGVzY3JpcHRpb24pJyB9LFxuXHRcdG1hbnVmYWN0dXJlcjogeyBuYW1lOiAnRGV2aWNlIE1hbnVmYWN0dXJlcicgfSxcblx0XHRmaXJtd2FyZTogeyBuYW1lOiAnRGV2aWNlIEZpcm13YXJlIFZlcnNpb24nIH0sXG5cdFx0ZGFudGVGVzogeyBuYW1lOiAnRGFudGUgTW9kdWxlIEZpcm13YXJlIFZlcnNpb24nIH0sXG5cdFx0bWFjOiB7IG5hbWU6ICdEZXZpY2UgTUFDIEFkZHJlc3MnIH0sXG5cdFx0aXA6IHsgbmFtZTogJ0RldmljZSBJUCBBZGRyZXNzJyB9LFxuXHR9KVxufVxuXG5jb25zdCBDTEVBUkVEX1ZBUklBQkxFUyA9IHtcblx0bW9kZWw6ICcnLFxuXHRtb2RlbE5hbWU6ICcnLFxuXHRtYW51ZmFjdHVyZXI6ICcnLFxuXHRmaXJtd2FyZTogJycsXG5cdGRhbnRlRlc6ICcnLFxuXHRtYWM6ICcnLFxuXHRpcDogJycsXG59XG5cbi8qKlxuICogVXBkYXRlIHZhcmlhYmxlIHZhbHVlcyBmcm9tIGRpc2NvdmVyZWQgZGV2aWNlIGluZm9ybWF0aW9uLlxuICogT25seSBwb3B1bGF0ZXMgdmFyaWFibGVzIHdoZW4gdGhlIGN1cnJlbnQgaG9zdCBpcyBhdXRob3JpemVkLlxuICogQ2xlYXJzIGFsbCB2YXJpYWJsZXMgaWYgdGhlIGRldmljZSBpcyBub3QgYXV0aG9yaXplZCBvciBub3QgZm91bmQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVWYXJpYWJsZVZhbHVlcyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRjb25zdCBjdXJyZW50SG9zdCA9IHNlbGYuaG9zdFxuXG5cdC8vIENsZWFyIHZhcmlhYmxlcyBpZiBubyBob3N0IGNvbmZpZ3VyZWQgb3IgZGV2aWNlIGlzIG5vdCBhdXRob3JpemVkXG5cdGlmICghY3VycmVudEhvc3QgfHwgIXNlbGYuc3RDb250cm9sbGVyLmlzRGV2aWNlQXV0aG9yaXplZChjdXJyZW50SG9zdCkpIHtcblx0XHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKENMRUFSRURfVkFSSUFCTEVTKVxuXHRcdHJldHVyblxuXHR9XG5cblx0Y29uc3QgZGV2aWNlID0gc2VsZi5kZXZpY2VzLmZpbmQoKGQpID0+IGQuaXAgPT09IGN1cnJlbnRIb3N0KVxuXHRpZiAoZGV2aWNlKSB7XG5cdFx0c2VsZi5zZXRWYXJpYWJsZVZhbHVlcyh7XG5cdFx0XHRtb2RlbDogZGV2aWNlLm1vZGVsIHx8ICcnLFxuXHRcdFx0bW9kZWxOYW1lOiBkZXZpY2UubW9kZWxOYW1lIHx8ICcnLFxuXHRcdFx0bWFudWZhY3R1cmVyOiBkZXZpY2UubWFudWZhY3R1cmVyIHx8ICcnLFxuXHRcdFx0ZmlybXdhcmU6IGRldmljZS5maXJtd2FyZU1haW4gfHwgJycsXG5cdFx0XHRkYW50ZUZXOiBkZXZpY2UuZGFudGVGaXJtd2FyZSB8fCAnJyxcblx0XHRcdG1hYzogZGV2aWNlLm1hYyB8fCAnJyxcblx0XHRcdGlwOiBkZXZpY2UuaXAsXG5cdFx0fSlcblx0fSBlbHNlIHtcblx0XHQvLyBBdXRob3JpemVkIGJ1dCBub3QgaW4gZGlzY292ZXJlZCBsaXN0IChtYW51YWwgSVAgdGhhdCBwcm9iZWQgc3VjY2Vzc2Z1bGx5KVxuXHRcdC8vIFdlIGtub3cgaXQncyB0aGUgcmlnaHQgZGV2aWNlIGJ1dCBkb24ndCBoYXZlIGZ1bGwgaW5mbyB5ZXRcblx0XHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKHtcblx0XHRcdC4uLkNMRUFSRURfVkFSSUFCTEVTLFxuXHRcdFx0aXA6IGN1cnJlbnRIb3N0LFxuXHRcdH0pXG5cdH1cbn1cbiIsICJpbXBvcnQgdHlwZSB7IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVTY3JpcHQgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHR5cGUgeyBNb2R1bGVDb25maWcgfSBmcm9tICcuL2NvbmZpZy5qcydcblxuZXhwb3J0IGNvbnN0IFVwZ3JhZGVTY3JpcHRzOiBDb21wYW5pb25TdGF0aWNVcGdyYWRlU2NyaXB0PE1vZHVsZUNvbmZpZz5bXSA9IFtcblx0Lypcblx0ICogUGxhY2UgeW91ciB1cGdyYWRlIHNjcmlwdHMgaGVyZVxuXHQgKiBSZW1lbWJlciB0aGF0IG9uY2UgaXQgaGFzIGJlZW4gYWRkZWQgaXQgY2Fubm90IGJlIHJlbW92ZWQhXG5cdCAqL1xuXHQvLyBmdW5jdGlvbiAoY29udGV4dCwgcHJvcHMpIHtcblx0Ly8gXHRyZXR1cm4ge1xuXHQvLyBcdFx0dXBkYXRlZENvbmZpZzogbnVsbCxcblx0Ly8gXHRcdHVwZGF0ZWRBY3Rpb25zOiBbXSxcblx0Ly8gXHRcdHVwZGF0ZWRGZWVkYmFja3M6IFtdLFxuXHQvLyBcdH1cblx0Ly8gfSxcbl1cbiIsICJleHBvcnQgdHlwZSBEZXZpY2VJbmZvID0ge1xuXHRtb2RlbDogc3RyaW5nIC8vIE1vZGVsIG51bWJlciAoZS5nLiwgXCIzNzRBXCIpXG5cdG1vZGVsTmFtZT86IHN0cmluZyAvLyBGdWxsIG1vZGVsIGRlc2NyaXB0aW9uIChlLmcuLCBcIk1vZGVsIDM3NEEgSW50ZXJjb20gQmVsdHBhY2tcIilcblx0aXA6IHN0cmluZ1xuXHRuYW1lPzogc3RyaW5nIC8vIERhbnRlIGRldmljZSBuYW1lICh1c2VyLWNvbmZpZ3VyYWJsZSBsYWJlbCwgZS5nLiBcIlNULU0zNzRBLUJlbHRwYWNrXCIpXG5cdG1hbnVmYWN0dXJlcj86IHN0cmluZyAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGZpcm13YXJlTWFpbj86IHN0cmluZyAvLyBEZXZpY2UgZmlybXdhcmUgdmVyc2lvbiBmcm9tIERhbnRlIGRpc2NvdmVyeSAoZS5nLiwgXCI0LjkuMFwiKVxuXHRkYW50ZUZpcm13YXJlPzogc3RyaW5nIC8vIERhbnRlIG1vZHVsZSBmaXJtd2FyZSB2ZXJzaW9uXG5cdG1hYz86IHN0cmluZ1xufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgQ29tbWFuZCBJRCBDb25zdGFudHMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgY29uc3QgQ01EX0dFVF9GSVJNV0FSRSA9IDB4MDAgLy8gUmVxdWVzdCBkZXZpY2UgZmlybXdhcmUgdmVyc2lvblxuZXhwb3J0IGNvbnN0IENNRF9NSUNfUFJFID0gMHgwMiAvLyBNaWMgcHJlYW1wIHJhdyBzZXQgKGdhaW4sIHBoYW50b20pIFx1MjAxNCBwb3NpdGlvbmFsIGJ5dGVzLCBubyBzZXR0aW5nIElEc1xuZXhwb3J0IGNvbnN0IENNRF9CVVNfR0VUID0gMHgwMyAvLyBIZWFydGJlYXQgLyBrZWVwYWxpdmUgcGluZ1xuZXhwb3J0IGNvbnN0IENNRF9CVVNfU0VUID0gMHgwNCAvLyBTZXQgc2V0dGluZyBvbiBzcGVjaWZpYyBidXMvY2hhbm5lbFxuZXhwb3J0IGNvbnN0IENNRF9IRUFEUEhPTkUgPSAweDA1IC8vIEhlYWRwaG9uZSBjb250cm9sc1xuZXhwb3J0IGNvbnN0IENNRF9CVVRUT05fTU9ERSA9IDB4MDcgLy8gQnV0dG9uIG1vZGUgY29uZmlndXJhdGlvblxuZXhwb3J0IGNvbnN0IENNRF9TWVNURU0gPSAweDA5IC8vIFN5c3RlbS1sZXZlbCBjb21tYW5kc1xuZXhwb3J0IGNvbnN0IENNRF9HRVRfQUxMX1NFVFRJTkdTID0gMHgwYSAvLyBSZXF1ZXN0IGFsbCBjdXJyZW50IHNldHRpbmdzIGZyb20gZGV2aWNlXG5leHBvcnQgY29uc3QgQ01EX1NFVFRJTkdTX1BVU0ggPSAweDBiIC8vIFVuc29saWNpdGVkIHNldHRpbmdzIHVwZGF0ZSBmcm9tIGRldmljZVxuZXhwb3J0IGNvbnN0IENNRF9ERVZfU1BFQyA9IDB4MGQgLy8gRGV2aWNlLXNwZWNpZmljIHNldHRpbmcgZ2V0L3NldCB3aXRoIEFDS1xuZXhwb3J0IGNvbnN0IENNRF9SRVNFVF9ERVZJQ0UgPSAweDBlIC8vIEZhY3RvcnkgcmVzZXQgY29tbWFuZFxuZXhwb3J0IGNvbnN0IENNRF9HTE9CQUxfTUlDX0tJTEwgPSAweDEwIC8vIEVtZXJnZW5jeSBtaWMga2lsbCAoYWxsIGNoYW5uZWxzKVxuZXhwb3J0IGNvbnN0IENNRF9NSUNfUFJFX0JVUyA9IDB4MTIgLy8gTWljL3ByZWFtcCBzZXR0aW5ncyBwZXIgYnVzIChnYWluLCBwaGFudG9tLCBldGMpXG5leHBvcnQgY29uc3QgQ01EX0NIQU5ORUwgPSAweDE0IC8vIENoYW5uZWwtc3BlY2lmaWMgY29udHJvbHNcblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIENvbW1hbmQgTmFtZSBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q29tbWFuZE5hbWUoY21kSWQ6IG51bWJlcik6IHN0cmluZyB7XG5cdHN3aXRjaCAoY21kSWQpIHtcblx0XHRjYXNlIENNRF9HRVRfRklSTVdBUkU6XG5cdFx0XHRyZXR1cm4gJ0dldCBGaXJtd2FyZSBWZXJzaW9uJ1xuXHRcdGNhc2UgQ01EX01JQ19QUkU6XG5cdFx0XHRyZXR1cm4gJ01pYyBQcmVhbXAnXG5cdFx0Y2FzZSBDTURfQlVTX0dFVDpcblx0XHRcdHJldHVybiAnSGVhcnRiZWF0J1xuXHRcdGNhc2UgQ01EX0JVU19TRVQ6XG5cdFx0XHRyZXR1cm4gJ1NldCBCdXMgU2V0dGluZydcblx0XHRjYXNlIENNRF9IRUFEUEhPTkU6XG5cdFx0XHRyZXR1cm4gJ0hlYWRwaG9uZSBDb250cm9sJ1xuXHRcdGNhc2UgQ01EX0JVVFRPTl9NT0RFOlxuXHRcdFx0cmV0dXJuICdCdXR0b24gTW9kZSdcblx0XHRjYXNlIENNRF9TWVNURU06XG5cdFx0XHRyZXR1cm4gJ1N5c3RlbSBDb21tYW5kJ1xuXHRcdGNhc2UgQ01EX0dFVF9BTExfU0VUVElOR1M6XG5cdFx0XHRyZXR1cm4gJ1JlcXVlc3QgQWxsIFNldHRpbmdzJ1xuXHRcdGNhc2UgQ01EX1NFVFRJTkdTX1BVU0g6XG5cdFx0XHRyZXR1cm4gJ1NldHRpbmdzIFB1c2gnXG5cdFx0Y2FzZSBDTURfTUlDX1BSRV9CVVM6XG5cdFx0XHRyZXR1cm4gJ01pYy9QcmUgQnVzJ1xuXHRcdGNhc2UgQ01EX0RFVl9TUEVDOlxuXHRcdFx0cmV0dXJuICdEZXZpY2UgU2V0dGluZydcblx0XHRjYXNlIENNRF9DSEFOTkVMOlxuXHRcdFx0cmV0dXJuICdDaGFubmVsIFNldHRpbmcnXG5cdFx0Y2FzZSBDTURfUkVTRVRfREVWSUNFOlxuXHRcdFx0cmV0dXJuICdSZXNldCBEZXZpY2UnXG5cdFx0Y2FzZSBDTURfR0xPQkFMX01JQ19LSUxMOlxuXHRcdFx0cmV0dXJuICdHbG9iYWwgTWljIEtpbGwnXG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBgY21kXzB4JHtjbWRJZC50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX1gXG5cdH1cbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIElEIEdlbmVyYXRpb24gSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDcmVhdGVzIGEgY29uc2lzdGVudCBJRCBmb3IgYWN0aW9ucywgZmVlZGJhY2tzLCBhbmQgc3RhdGUga2V5cy5cbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2J1c0NofV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2ggKGUuZy4sIFwiNTMwNF8xNF8wXzBcIilcbiAqIEZvcm1hdDogYCR7bW9kZWx9XyR7Y21kX2lkfV8ke2lkfWAgZm9yIGNvbW1hbmRzIHdpdGhvdXQgYnVzQ2ggKGUuZy4sIFwiNTMwNF8xMl9kXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtYWtlU2V0dGluZ0lkKFxuXHRtb2RlbDogc3RyaW5nLFxuXHRjbWRJZDogbnVtYmVyIHwgc3RyaW5nLFxuXHRzZXR0aW5nSWQ6IG51bWJlciB8IHN0cmluZyxcblx0YnVzQ2g/OiBudW1iZXIgfCBzdHJpbmcsXG4pOiBzdHJpbmcge1xuXHRjb25zdCBjbWQgPSB0eXBlb2YgY21kSWQgPT09ICdudW1iZXInID8gY21kSWQudG9TdHJpbmcoMTYpIDogY21kSWRcblx0Y29uc3QgaWQgPSB0eXBlb2Ygc2V0dGluZ0lkID09PSAnbnVtYmVyJyA/IHNldHRpbmdJZC50b1N0cmluZygxNikgOiBzZXR0aW5nSWRcblxuXHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdGNvbnN0IGNoID0gdHlwZW9mIGJ1c0NoID09PSAnbnVtYmVyJyA/IGJ1c0NoLnRvU3RyaW5nKDE2KSA6IGJ1c0NoXG5cdFx0cmV0dXJuIGAke21vZGVsfV8ke2NtZH1fJHtjaH1fJHtpZH1gXG5cdH1cblxuXHRyZXR1cm4gYCR7bW9kZWx9XyR7Y21kfV8ke2lkfWBcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIEhleCBGb3JtYXR0aW5nIEhlbHBlcnMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIENvbnZlcnRzIGEgbnVtYmVyIHRvIGEgaGV4IHN0cmluZyB3aXRoIDB4IHByZWZpeCBhbmQgcGFkZGluZy5cbiAqIEBwYXJhbSB2YWx1ZSAtIFRoZSBudW1iZXIgdG8gY29udmVydFxuICogQHBhcmFtIHBhZExlbmd0aCAtIE51bWJlciBvZiBoZXggZGlnaXRzIHRvIHBhZCB0byAoZGVmYXVsdDogMilcbiAqIEByZXR1cm5zIEZvcm1hdHRlZCBoZXggc3RyaW5nIChlLmcuLCBcIjB4MGRcIiwgXCIweGZmXCIpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0hleCh2YWx1ZTogbnVtYmVyLCBwYWRMZW5ndGggPSAyKTogc3RyaW5nIHtcblx0cmV0dXJuIGAweCR7dmFsdWUudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KHBhZExlbmd0aCwgJzAnKX1gXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gYXJyYXkgb2YgYnl0ZXMgdG8gYSBoZXggc3RyaW5nIHdpdGggMHggcHJlZml4LlxuICogQHBhcmFtIGJ5dGVzIC0gQXJyYXkgb2YgYnl0ZXMgb3IgQnVmZmVyXG4gKiBAcmV0dXJucyBGb3JtYXR0ZWQgaGV4IHN0cmluZyAoZS5nLiwgXCIweDBhZmYxMlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gYnl0ZXNUb0hleChieXRlczogbnVtYmVyW10gfCBCdWZmZXIpOiBzdHJpbmcge1xuXHRyZXR1cm4gYDB4JHtBcnJheS5mcm9tKGJ5dGVzKVxuXHRcdC5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXG5cdFx0LmpvaW4oJycpfWBcbn1cblxuLyoqXG4gKiBGb3JtYXRzIFJHQiBjb2xvciBieXRlcyBhcyBhIENTUyBoZXggY29sb3Igc3RyaW5nLlxuICogQHBhcmFtIHIgLSBSZWQgY29tcG9uZW50ICgwLTI1NSlcbiAqIEBwYXJhbSBnIC0gR3JlZW4gY29tcG9uZW50ICgwLTI1NSlcbiAqIEBwYXJhbSBiIC0gQmx1ZSBjb21wb25lbnQgKDAtMjU1KVxuICogQHJldHVybnMgQ1NTIGhleCBjb2xvciBzdHJpbmcgKGUuZy4sIFwiI0ZGMDBBQlwiKVxuICovXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0UmdiQ29sb3IocjogbnVtYmVyLCBnOiBudW1iZXIsIGI6IG51bWJlcik6IHN0cmluZyB7XG5cdHJldHVybiBgIyR7W3IsIGcsIGJdXG5cdFx0Lm1hcCgodikgPT4gdi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcblx0XHQuam9pbignJylcblx0XHQudG9VcHBlckNhc2UoKX1gXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBJRCBQYXJzaW5nIEhlbHBlciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8qKlxuICogUGFyc2VzIGEgc2V0dGluZyBJRCBzdHJpbmcgaW50byBpdHMgY29tcG9uZW50cy5cbiAqIEBwYXJhbSBpZCAtIFNldHRpbmcgSUQgc3RyaW5nIChlLmcuLCBcIjM5MV9kXzBcIiBvciBcIjUzMDRfMTRfMF8xXCIpXG4gKiBAcmV0dXJucyBQYXJzZWQgY29tcG9uZW50cyB3aXRoIGhleCBzdHJpbmdzIGNvbnZlcnRlZCB0byBudW1iZXJzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVNldHRpbmdJZChpZDogc3RyaW5nKTogeyBtb2RlbDogc3RyaW5nOyBjbWRJZDogbnVtYmVyOyBiYXNlSWQ6IG51bWJlciB9IHtcblx0Y29uc3QgW21vZGVsLCBjbWRJZFN0ciwgaWRTdHJdID0gaWQuc3BsaXQoJ18nKVxuXHRyZXR1cm4ge1xuXHRcdG1vZGVsLFxuXHRcdGNtZElkOiBwYXJzZUludChjbWRJZFN0ciwgMTYpLFxuXHRcdGJhc2VJZDogcGFyc2VJbnQoaWRTdHIsIDE2KSxcblx0fVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgTW9kZWwgRGlzdGFuY2UgSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBDYWxjdWxhdGVzIG51bWVyaWMgZGlzdGFuY2UgYmV0d2VlbiB0d28gbW9kZWwgbnVtYmVycy5cbiAqIFVzZWQgZm9yIGZpbmRpbmcgc2ltaWxhciBtb2RlbHMgZm9yIHNldHRpbmcgaW5mZXJlbmNlLlxuICogQHBhcmFtIG1vZGVsQSAtIEZpcnN0IG1vZGVsIG51bWJlciAoZS5nLiwgXCIzOTFcIilcbiAqIEBwYXJhbSBtb2RlbEIgLSBTZWNvbmQgbW9kZWwgbnVtYmVyIChlLmcuLCBcIjM5MlwiKVxuICogQHJldHVybnMgTnVtZXJpYyBkaXN0YW5jZSBiZXR3ZWVuIG1vZGVscywgb3IgSW5maW5pdHkgaWYgZWl0aGVyIGlzIG5vbi1udW1lcmljXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtb2RlbERpc3RhbmNlKG1vZGVsQTogc3RyaW5nLCBtb2RlbEI6IHN0cmluZyk6IG51bWJlciB7XG5cdGNvbnN0IG5hID0gcGFyc2VJbnQobW9kZWxBLnJlcGxhY2UoL1xcRC9nLCAnJyksIDEwKVxuXHRjb25zdCBuYiA9IHBhcnNlSW50KG1vZGVsQi5yZXBsYWNlKC9cXEQvZywgJycpLCAxMClcblx0aWYgKE51bWJlci5pc05hTihuYSkgfHwgTnVtYmVyLmlzTmFOKG5iKSkgcmV0dXJuIEluZmluaXR5XG5cdHJldHVybiBNYXRoLmFicyhuYSAtIG5iKVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgU2NoZW1hIE5vcm1hbGl6YXRpb24gSGVscGVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLyoqXG4gKiBOb3JtYWxpemVzIGRldmljZSBzY2hlbWFzIHRvIGVuc3VyZSBjbWRTY2hlbWEgaXMgYWx3YXlzIGFuIGFycmF5LlxuICogVGhpcyBoZWxwZXIgZWxpbWluYXRlcyBkdXBsaWNhdGUgc2NoZW1hIHRyYW5zZm9ybWF0aW9uIGNvZGUuXG4gKiBAcGFyYW0gc2NoZW1hc1JhdyAtIFJhdyBzY2hlbWFzIGZyb20gZ2V0RGV2aWNlU2NoZW1hcygpXG4gKiBAcmV0dXJucyBOb3JtYWxpemVkIHNjaGVtYXMgd2l0aCBndWFyYW50ZWVkIGNtZFNjaGVtYSBhcnJheXNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldE5vcm1hbGl6ZWRTY2hlbWFzKFxuXHRzY2hlbWFzUmF3OiBSZWNvcmQ8c3RyaW5nLCBhbnk+LFxuKTogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+IHtcblx0Y29uc3Qgbm9ybWFsaXplZDogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+ID0ge31cblx0Zm9yIChjb25zdCBbbW9kZWwsIGpzb25dIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYXNSYXcpKSB7XG5cdFx0bm9ybWFsaXplZFttb2RlbF0gPSB7XG5cdFx0XHRtb2RlbDoganNvbi5tb2RlbCxcblx0XHRcdGNtZFNjaGVtYTogQXJyYXkuaXNBcnJheShqc29uLmNtZFNjaGVtYSkgPyBqc29uLmNtZFNjaGVtYSA6IFtdLFxuXHRcdH1cblx0fVxuXHRyZXR1cm4gbm9ybWFsaXplZFxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgQWN0aW9uIExvb2t1cCBIZWxwZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vKipcbiAqIEZpbmRzIGFuIGFjdGlvbi9zZXR0aW5nIGluIHRoZSBzY2hlbWEsIHN1cHBvcnRpbmcgYm90aCBleGFjdCBtYXRjaGVzIGFuZCBpZEFkZCBvZmZzZXRzLlxuICogVGhpcyBoZWxwZXIgZWxpbWluYXRlcyBkdXBsaWNhdGUgYWN0aW9uIGxvb2t1cCBsb2dpYyBhY3Jvc3MgbXVsdGlwbGUgZmlsZXMuXG4gKiBAcGFyYW0gc2NoZW1hcyAtIE5vcm1hbGl6ZWQgZGV2aWNlIHNjaGVtYXNcbiAqIEBwYXJhbSBtb2RlbCAtIERldmljZSBtb2RlbCAoZS5nLiwgXCIzOTFcIilcbiAqIEBwYXJhbSBjbWRJZCAtIENvbW1hbmQgSURcbiAqIEBwYXJhbSBzZXR0aW5nSWQgLSBTZXR0aW5nIElEIChtYXkgaW5jbHVkZSBpZEFkZCBvZmZzZXQpXG4gKiBAcmV0dXJucyBNYXRjaGluZyBhY3Rpb24vc2V0dGluZyBvciB1bmRlZmluZWRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZpbmRBY3Rpb25Gb3JTZXR0aW5nKFxuXHRzY2hlbWFzOiBSZWNvcmQ8c3RyaW5nLCB7IG1vZGVsOiBzdHJpbmc7IGNtZFNjaGVtYTogYW55W10gfT4sXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGNtZElkOiBudW1iZXIsXG5cdHNldHRpbmdJZDogbnVtYmVyLFxuKTogYW55IHtcblx0Y29uc3Qgc2NoZW1hID0gc2NoZW1hc1ttb2RlbF1cblx0aWYgKCFzY2hlbWEgfHwgIUFycmF5LmlzQXJyYXkoc2NoZW1hLmNtZFNjaGVtYSkpIHJldHVybiB1bmRlZmluZWRcblxuXHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0bGV0IGFjdGlvbiA9IHNjaGVtYS5jbWRTY2hlbWEuZmluZCgoczogYW55KSA9PiBzLmNtZF9pZCA9PT0gY21kSWQgJiYgcy5pZCA9PT0gc2V0dGluZ0lkKVxuXG5cdC8vIElmIG5vIGV4YWN0IG1hdGNoLCB0cnkgdG8gZmluZCBiYXNlIGFjdGlvbiB3aXRoIGlkQWRkXG5cdGlmICghYWN0aW9uKSB7XG5cdFx0YWN0aW9uID0gc2NoZW1hLmNtZFNjaGVtYS5maW5kKChzOiBhbnkpID0+IHtcblx0XHRcdGlmIChzLmNtZF9pZCAhPT0gY21kSWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBzLm9wdGlvbnM/LmZpbmQoKG9wdDogYW55KSA9PiBvcHQuaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoIWlkQWRkT3B0aW9uPy5jaG9pY2VzKSByZXR1cm4gZmFsc2Vcblx0XHRcdC8vIENoZWNrIGlmIHNldHRpbmdJZCBtYXRjaGVzIGJhc2UgKyBhbnkgaWRBZGQgb2Zmc2V0XG5cdFx0XHRjb25zdCBvZmZzZXQgPSBzZXR0aW5nSWQgLSBzLmlkXG5cdFx0XHRyZXR1cm4gaWRBZGRPcHRpb24uY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9mZnNldClcblx0XHR9KVxuXHR9XG5cblx0cmV0dXJuIGFjdGlvblxufVxuIiwgIi8qKlxuICogYnVpbGQtY29tbWFuZHMudHNcbiAqIC0gVXNlcyBjZW50cmFsaXplZCBkZXZpY2Ugc2NoZW1hIGNhY2hlIGZyb20gY29uZmlnLnRzXG4gKiAtIFByb2R1Y2VzIENvbXBhbmlvbiBhY3Rpb24gZGVmaW5pdGlvbnMgYW5kIGZlZWRiYWNrc1xuICovXG5cbmltcG9ydCB7XG5cdENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zLFxuXHRDb21wYW5pb25BY3Rpb25EZWZpbml0aW9uLFxuXHRDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zLFxuXHRjb21iaW5lUmdiLFxufSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHsgbWFrZVNldHRpbmdJZCB9IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQgeyBnZXREZXZpY2VTY2hlbWFzIH0gZnJvbSAnLi9jb25maWcuanMnXG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0gT3B0aW9uIEJ1aWxkZXIgLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuZnVuY3Rpb24gYnVpbGRPcHRpb24obzogYW55KTogYW55IHtcblx0Y29uc3QgYmFzZSA9IHtcblx0XHR0eXBlOiBvLnR5cGUsXG5cdFx0aWQ6IG8uaWQsXG5cdFx0bGFiZWw6IG8ubGFiZWwsXG5cdFx0ZGVmYXVsdDogby5kZWZhdWx0LFxuXHRcdHRvb2x0aXA6IG8udG9vbHRpcCxcblx0fVxuXG5cdHN3aXRjaCAoby50eXBlKSB7XG5cdFx0Y2FzZSAnZHJvcGRvd24nOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgY2hvaWNlczogby5jaG9pY2VzID8/IFtdIH1cblxuXHRcdGNhc2UgJ251bWJlcic6XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHQuLi5iYXNlLFxuXHRcdFx0XHRtaW46IG8ubWluLFxuXHRcdFx0XHRtYXg6IG8ubWF4LFxuXHRcdFx0XHRzdGVwOiBvLnN0ZXAgPz8gMSxcblx0XHRcdFx0cmFuZ2U6IHRydWUsXG5cdFx0XHR9XG5cblx0XHRjYXNlICdjaGVja2JveCc6XG5cdFx0XHRyZXR1cm4geyAuLi5iYXNlLCBkZWZhdWx0OiBvLmRlZmF1bHQgPz8gZmFsc2UgfVxuXG5cdFx0Y2FzZSAnc3RhdGljLXRleHQnOlxuXHRcdFx0cmV0dXJuIHsgLi4uYmFzZSwgdmFsdWU6IG8udmFsdWUgPz8gJycgfVxuXG5cdFx0Y2FzZSAndGV4dGlucHV0Jzpcblx0XHRjYXNlICdjb2xvcnBpY2tlcic6XG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBiYXNlXG5cdH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cbi8qIC0tLS0tLS0tLSBBY3Rpb25zIC0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRBY3Rpb25zKCk6IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCBhY3Rpb25zOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyA9IHt9XG5cblx0Zm9yIChjb25zdCBbbW9kZWwsIHNjaGVtYV0gb2YgT2JqZWN0LmVudHJpZXMoc2NoZW1hcykpIHtcblx0XHRjb25zdCBjbWRTY2hlbWEgPSBzY2hlbWEuY21kU2NoZW1hXG5cdFx0aWYgKCFBcnJheS5pc0FycmF5KGNtZFNjaGVtYSkpIGNvbnRpbnVlXG5cblx0XHRmb3IgKGNvbnN0IGEgb2YgY21kU2NoZW1hKSB7XG5cdFx0XHQvLyBTa2lwIHJlYWQtb25seSBlbnRyaWVzIFx1MjAxNCB0aGV5IGFyZSBmZWVkYmFjay1vbmx5IChpbmRpY2F0b3JzLCBzdGF0dXMpXG5cdFx0XHRpZiAoYS5yZWFkb25seSA9PT0gdHJ1ZSkgY29udGludWVcblxuXHRcdFx0Y29uc3QgYWN0aW9uSWQgPSBtYWtlU2V0dGluZ0lkKG1vZGVsLCBhLmNtZF9pZCwgYS5pZClcblxuXHRcdFx0Ly8gRml4ZWQtdmFsdWUgYWN0aW9uczoga2VlcCBpZEFkZC9idXNDaCBzZWxlY3RvcnMgYnV0IGRyb3AgdGhlIHZhbHVlIG9wdGlvblxuXHRcdFx0Y29uc3QgYWxsQnVpbHRPcHRpb25zID0gKGEub3B0aW9ucyA/PyBbXSkubWFwKGJ1aWxkT3B0aW9uKVxuXHRcdFx0Y29uc3Qgb3B0aW9ucyA9IGEudmFsdWUgIT09IHVuZGVmaW5lZCA/IGFsbEJ1aWx0T3B0aW9ucy5maWx0ZXIoKG86IGFueSkgPT4gby5pZCAhPT0gJ3ZhbHVlJykgOiBhbGxCdWlsdE9wdGlvbnNcblxuXHRcdFx0Y29uc3QgYWN0aW9uOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9uID0ge1xuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHttb2RlbH1dICR7YS5uYW1lfWAsXG5cdFx0XHRcdG9wdGlvbnMsXG5cdFx0XHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdFx0Lyogd2lyZWQgbGF0ZXIgaW4gVXBkYXRlQWN0aW9ucyAqL1xuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXG5cdFx0XHRhY3Rpb25zW2FjdGlvbklkXSA9IGFjdGlvblxuXHRcdH1cblx0fVxuXG5cdHJldHVybiBhY3Rpb25zXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG4vKiAtLS0tLS0tLS0gRmVlZGJhY2tzIC0tLS0tLS0tLSAqL1xuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuLyoqXG4gKiBSZXR1cm5zIHRydWUgaWYgdGhlIHNldHRpbmcncyB2YWx1ZSBvcHRpb24gcmVwcmVzZW50cyBhIGJvb2xlYW4gKG9uL29mZikgY2hvaWNlOlxuICogLSB0eXBlICdjaGVja2JveCcsIE9SXG4gKiAtIGEgMi1jaG9pY2UgZHJvcGRvd24gd2hlcmUgb25lIGxhYmVsIGlzIFwib2ZmXCIgYW5kIHRoZSBvdGhlciBpcyBcIm9uXCJcbiAqL1xuZnVuY3Rpb24gaXNCb29sZWFuRHJvcGRvd24oc2V0dGluZzogYW55KTogYm9vbGVhbiB7XG5cdGNvbnN0IHZhbHVlT3B0ID0gc2V0dGluZy5vcHRpb25zPy5maW5kKChvOiBhbnkpID0+IG8uaWQgPT09ICd2YWx1ZScpXG5cdGlmICghdmFsdWVPcHQpIHJldHVybiBmYWxzZVxuXHRpZiAodmFsdWVPcHQudHlwZSA9PT0gJ2NoZWNrYm94JykgcmV0dXJuIHRydWVcblx0aWYgKHZhbHVlT3B0LnR5cGUgIT09ICdkcm9wZG93bicgfHwgIUFycmF5LmlzQXJyYXkodmFsdWVPcHQuY2hvaWNlcykpIHJldHVybiBmYWxzZVxuXHRpZiAodmFsdWVPcHQuY2hvaWNlcy5sZW5ndGggIT09IDIpIHJldHVybiBmYWxzZVxuXHRjb25zdCBsYWJlbHMgPSB2YWx1ZU9wdC5jaG9pY2VzLm1hcCgoYzogYW55KSA9PiBTdHJpbmcoYy5sYWJlbCkudG9Mb3dlckNhc2UoKSlcblx0cmV0dXJuIGxhYmVscy5pbmNsdWRlcygnb2ZmJykgJiYgbGFiZWxzLmluY2x1ZGVzKCdvbicpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBidWlsZEZlZWRiYWNrcygpOiBDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zIHtcblx0Y29uc3Qgc2NoZW1hcyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCBmZWVkYmFja3M6IENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbnMgPSB7fVxuXG5cdGZvciAoY29uc3QgW21vZGVsLCBzY2hlbWFdIG9mIE9iamVjdC5lbnRyaWVzKHNjaGVtYXMpKSB7XG5cdFx0Y29uc3QgY21kU2NoZW1hID0gc2NoZW1hLmNtZFNjaGVtYVxuXHRcdGlmICghQXJyYXkuaXNBcnJheShjbWRTY2hlbWEpKSBjb250aW51ZVxuXG5cdFx0Zm9yIChjb25zdCBzZXR0aW5nIG9mIGNtZFNjaGVtYSkge1xuXHRcdFx0Ly8gU2tpcCB3cml0ZS1vbmx5IGVudHJpZXMgXHUyMDE0IHRoZXkgYXJlIGFjdGlvbi1vbmx5IChkZXZpY2UgbmV2ZXIgcmVwb3J0cyB2YWx1ZSBiYWNrKVxuXHRcdFx0aWYgKHNldHRpbmcud3JpdGVvbmx5ID09PSB0cnVlKSBjb250aW51ZVxuXG5cdFx0XHRjb25zdCBiYXNlRmVlZGJhY2tJZCA9IG1ha2VTZXR0aW5nSWQobW9kZWwsIHNldHRpbmcuY21kX2lkLCBzZXR0aW5nLmlkKVxuXG5cdFx0XHQvLyBGaXhlZC12YWx1ZSBlbnRyaWVzOiBzaW5nbGUgYm9vbGVhbiBmZWVkYmFjayBcdTIwMTQgdHJ1ZSB3aGVuIGN1cnJlbnQgdmFsdWUgbWF0Y2hlcyB0aGUgZml4ZWQgdmFsdWVcblx0XHRcdGlmIChzZXR0aW5nLnZhbHVlICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0Y29uc3QgZml4ZWRPcHRpb25zID0gKHNldHRpbmcub3B0aW9ucyA/PyBbXSlcblx0XHRcdFx0XHQubWFwKGJ1aWxkT3B0aW9uKVxuXHRcdFx0XHRcdC5maWx0ZXIoKG9wdDogYW55KSA9PiBvcHQuaWQgPT09ICdidXNDaCcgfHwgb3B0LmlkID09PSAnaWRBZGQnKVxuXG5cdFx0XHRcdGZlZWRiYWNrc1tiYXNlRmVlZGJhY2tJZF0gPSB7XG5cdFx0XHRcdFx0dHlwZTogJ2Jvb2xlYW4nLFxuXHRcdFx0XHRcdG5hbWU6IGBbTW9kZWwke21vZGVsfV0gJHtzZXR0aW5nLm5hbWV9IFx1MjAxNCBBY3RpdmVgLFxuXHRcdFx0XHRcdGRlZmF1bHRTdHlsZToge1xuXHRcdFx0XHRcdFx0Ymdjb2xvcjogY29tYmluZVJnYigwLCAyMDAsIDApLFxuXHRcdFx0XHRcdFx0Y29sb3I6IGNvbWJpbmVSZ2IoMCwgMCwgMCksXG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0XHRvcHRpb25zOiBmaXhlZE9wdGlvbnMsXG5cdFx0XHRcdFx0Y2FsbGJhY2s6ICgpID0+IHtcblx0XHRcdFx0XHRcdC8qIHdpcmVkIGxhdGVyIGluIFVwZGF0ZUZlZWRiYWNrcyAqL1xuXHRcdFx0XHRcdFx0cmV0dXJuIGZhbHNlXG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0fSBhcyBhbnlcblx0XHRcdFx0Y29udGludWVcblx0XHRcdH1cblxuXHRcdFx0Ly8gQnVpbGQgb3B0aW9uc1xuXHRcdFx0Y29uc3QgYWxsT3B0aW9ucyA9IChzZXR0aW5nLm9wdGlvbnMgPz8gW10pLm1hcChidWlsZE9wdGlvbilcblxuXHRcdFx0Ly8gRmlsdGVyIG91dCAndmFsdWUnIG9wdGlvbiBmb3IgdmFsdWUgZmVlZGJhY2sgKGtlZXAgb25seSBidXNDaC9pZEFkZClcblx0XHRcdGNvbnN0IHZhbHVlT3B0aW9ucyA9IGFsbE9wdGlvbnMuZmlsdGVyKChvcHQ6IGFueSkgPT4gb3B0LmlkICE9PSAndmFsdWUnKVxuXG5cdFx0XHQvLyBBZGQgYSBjaGVja2JveCBvcHRpb24gdG8gcmV0dXJuIGxhYmVsIGluc3RlYWQgb2YgdmFsdWVcblx0XHRcdC8vIChub3QgYXBwbGljYWJsZSBmb3IgY29sb3JwaWNrZXIgc2V0dGluZ3MgXHUyMDE0IHRoZXkgaGF2ZSBubyBkaXNjcmV0ZSBjaG9pY2VzKVxuXHRcdFx0Y29uc3QgaXNDb2xvclNldHRpbmcgPSBzZXR0aW5nLm9wdGlvbnM/LnNvbWUoKG86IGFueSkgPT4gby5pZCA9PT0gJ3ZhbHVlJyAmJiBvLnR5cGUgPT09ICdjb2xvcnBpY2tlcicpXG5cdFx0XHRpZiAoIWlzQ29sb3JTZXR0aW5nKSB7XG5cdFx0XHRcdHZhbHVlT3B0aW9ucy5wdXNoKHtcblx0XHRcdFx0XHR0eXBlOiAnY2hlY2tib3gnLFxuXHRcdFx0XHRcdGlkOiAnc2hvd0xhYmVsJyxcblx0XHRcdFx0XHRsYWJlbDogJ1VzZSBMYWJlbCBmb3IgVmFsdWUnLFxuXHRcdFx0XHRcdGRlZmF1bHQ6IGZhbHNlLFxuXHRcdFx0XHRcdHRvb2x0aXA6ICdSZXR1cm4gdGhlIGxhYmVsIHRleHQgaW5zdGVhZCBvZiB0aGUgbnVtZXJpYyB2YWx1ZScsXG5cdFx0XHRcdH0pXG5cdFx0XHR9XG5cblx0XHRcdC8vIFZhbHVlIGZlZWRiYWNrIGZvciBhbGwgc2V0dGluZ3MgKGFwcGVhcnMgaW4gVmFyaWFibGVzIGxpc3QpXG5cdFx0XHRjb25zdCB2YWx1ZUZlZWRiYWNrOiBhbnkgPSB7XG5cdFx0XHRcdHR5cGU6ICd2YWx1ZScsXG5cdFx0XHRcdG5hbWU6IGBbTW9kZWwke21vZGVsfV0gJHtzZXR0aW5nLm5hbWV9YCxcblx0XHRcdFx0b3B0aW9uczogdmFsdWVPcHRpb25zLFxuXHRcdFx0XHRjYWxsYmFjazogKCkgPT4ge1xuXHRcdFx0XHRcdC8qIHdpcmVkIGxhdGVyIGluIFVwZGF0ZUZlZWRiYWNrcyAqL1xuXHRcdFx0XHRcdHJldHVybiAwXG5cdFx0XHRcdH0sXG5cdFx0XHR9XG5cblx0XHRcdGZlZWRiYWNrc1tiYXNlRmVlZGJhY2tJZF0gPSB2YWx1ZUZlZWRiYWNrXG5cblx0XHRcdC8vIEJvb2xlYW4gZmVlZGJhY2sgZm9yIE9mZi9PbiBkcm9wZG93bnMgXHUyMDE0IGFkZGl0aW9uYWwgZmVlZGJhY2sgZm9yIGJ1dHRvbiBjb2xvcmluZ1xuXHRcdFx0aWYgKGlzQm9vbGVhbkRyb3Bkb3duKHNldHRpbmcpKSB7XG5cdFx0XHRcdGNvbnN0IGJvb2xGZWVkYmFja0lkID0gYCR7YmFzZUZlZWRiYWNrSWR9X2Jvb2xgXG5cblx0XHRcdFx0Ly8gT3B0aW9ucyB3aXRob3V0ICd2YWx1ZScgKGJ1c0NoL2lkQWRkIHNlbGVjdG9ycyBvbmx5LCBpZiBwcmVzZW50KVxuXHRcdFx0XHRjb25zdCBib29sT3B0aW9ucyA9IGFsbE9wdGlvbnMuZmlsdGVyKChvcHQ6IGFueSkgPT4gb3B0LmlkICE9PSAndmFsdWUnKVxuXG5cdFx0XHRcdGNvbnN0IGJvb2xGZWVkYmFjazogYW55ID0ge1xuXHRcdFx0XHRcdHR5cGU6ICdib29sZWFuJyxcblx0XHRcdFx0XHRuYW1lOiBgW01vZGVsJHttb2RlbH1dICR7c2V0dGluZy5uYW1lfSBcdTIwMTQgSXMgT25gLFxuXHRcdFx0XHRcdGRlZmF1bHRTdHlsZToge1xuXHRcdFx0XHRcdFx0Ymdjb2xvcjogY29tYmluZVJnYigwLCAyMDAsIDApLFxuXHRcdFx0XHRcdFx0Y29sb3I6IGNvbWJpbmVSZ2IoMCwgMCwgMCksXG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0XHRvcHRpb25zOiBib29sT3B0aW9ucyxcblx0XHRcdFx0XHRjYWxsYmFjazogKCkgPT4ge1xuXHRcdFx0XHRcdFx0Lyogd2lyZWQgbGF0ZXIgaW4gVXBkYXRlRmVlZGJhY2tzICovXG5cdFx0XHRcdFx0XHRyZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHR9XG5cblx0XHRcdFx0ZmVlZGJhY2tzW2Jvb2xGZWVkYmFja0lkXSA9IGJvb2xGZWVkYmFja1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdHJldHVybiBmZWVkYmFja3Ncbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRBY3Rpb25zIH0gZnJvbSAnLi9idWlsZC1jb21tYW5kcy5qcydcbmltcG9ydCB7IGdldERldmljZXNGb2xkZXIsIGdldERldmljZVNjaGVtYSwgZ2V0RGV2aWNlU2NoZW1hcywgcmVsb2FkRGV2aWNlU2NoZW1hcyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgcGFyc2VTZXR0aW5nSWQsIGdldE5vcm1hbGl6ZWRTY2hlbWFzIH0gZnJvbSAnLi90eXBlcy5qcydcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJ1xuXG5pbXBvcnQgeyBwYXJzZUdldEFsbFNldHRpbmdzV2l0aERldGVjdGlvbiwgc2F2ZU1vZGVsSnNvblByZXR0eSwgdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzIH0gZnJvbSAnLi9zZXR0aW5nc1BhcnNlci5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdBY3Rpb25zJylcblxuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZUFjdGlvbnMoc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3Qgc2NoZW1hc1JhdyA9IGdldERldmljZVNjaGVtYXMoKVxuXHRjb25zdCByYXdBY3Rpb25zID0gYnVpbGRBY3Rpb25zKClcblx0Y29uc3Qgc2NoZW1hcyA9IGdldE5vcm1hbGl6ZWRTY2hlbWFzKHNjaGVtYXNSYXcpXG5cdGNvbnN0IHdpcmVkQWN0aW9uczogYW55ID0ge31cblxuXHRjb25zdCBhY3RpdmVNb2RlbCA9IHNlbGYuYWN0aXZlTW9kZWxcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEdMT0JBTDogR0VUIEFMTCBTRVRUSU5HUyAoQVVUTyBKU09OIFVQREFURSkgXHUyMDE0IERldiBNb2RlIG9ubHlcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0aWYgKHNlbGYuY29uZmlnLmRldk1vZGUpIHtcblx0XHR3aXJlZEFjdGlvbnNbJ2dsb2JhbF9nZXRBbGxTZXR0aW5ncyddID0ge1xuXHRcdFx0bmFtZTogJ0dMT0JBTDogR2V0IEFsbCBTZXR0aW5ncycsXG5cdFx0XHRkZXNjcmlwdGlvbjogJ1VzZSB0aGlzIHRvIGNyZWF0ZSBhIHNjaGVtYSBmb3IgYSBuZXcgZGV2aWNlJyxcblx0XHRcdG9wdGlvbnM6IFtdLFxuXHRcdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHtcblx0XHRcdFx0Y29uc3QgbW9kZWwgPSBhY3RpdmVNb2RlbFxuXHRcdFx0XHRjb25zdCBpcCA9IHNlbGYuaG9zdFxuXG5cdFx0XHRcdGNvbnN0IGJ1ZiA9IGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLnJlcXVlc3RBbGxTZXR0aW5ncyhpcClcblxuXHRcdFx0XHRsZXQgbW9kZWxKc29uID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXG5cdFx0XHRcdGNvbnN0IHsgc2V0dGluZ3M6IHBhcnNlZCB9ID0gcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24obW9kZWwsIGJ1Zilcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBwYXJzZWQgcmVwbHk6ICR7SlNPTi5zdHJpbmdpZnkocGFyc2VkKX1gKVxuXG5cdFx0XHRcdGlmICghbW9kZWxKc29uKSB7XG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYE1vZGVsICR7bW9kZWx9IGhhcyBubyBzY2hlbWEgXHUyMDE0IGNyZWF0aW5nIG5ldyBKU09OIGZyb20gc2V0dGluZ3NgKVxuXHRcdFx0XHRcdG1vZGVsSnNvbiA9IHtcblx0XHRcdFx0XHRcdG1vZGVsLFxuXHRcdFx0XHRcdFx0Y21kU2NoZW1hOiBbXSxcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRjb25zdCB1cGRhdGVkID0gdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzKG1vZGVsSnNvbiwgcGFyc2VkLCBzY2hlbWFzKVxuXHRcdFx0XHRsb2dnZXIuZGVidWcoYG5ldyBBY3Rpb25zIGpzb246ICR7SlNPTi5zdHJpbmdpZnkodXBkYXRlZCwgbnVsbCwgMil9YClcblxuXHRcdFx0XHRjb25zdCBkZXZpY2VzRm9sZGVyID0gZ2V0RGV2aWNlc0ZvbGRlcigpXG5cdFx0XHRcdGNvbnN0IHNjaGVtYVBhdGggPSBwYXRoLmpvaW4oZGV2aWNlc0ZvbGRlciwgYE1vZGVsJHttb2RlbH0uanNvbmApXG5cdFx0XHRcdHNhdmVNb2RlbEpzb25QcmV0dHkoc2NoZW1hUGF0aCwgdXBkYXRlZClcblxuXHRcdFx0XHRyZWxvYWREZXZpY2VTY2hlbWFzKClcblxuXHRcdFx0XHRsb2dnZXIuaW5mbyhgTW9kZWwgJHttb2RlbH0gSlNPTiBhdXRvLXVwZGF0ZWQgZnJvbSBnZXRBbGxTZXR0aW5nc2ApXG5cdFx0XHR9LFxuXHRcdH1cblx0fVxuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBcdTI3MDUgQlVJTEQgUEVSLVNFVFRJTkcgQUNUSU9OUyAoRklMVEVSRUQgQlkgQUNUSVZFIE1PREVMKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHRmb3IgKGNvbnN0IFthY3Rpb25JZCwgYWN0aW9uXSBvZiBPYmplY3QuZW50cmllcyhyYXdBY3Rpb25zKSkge1xuXHRcdGNvbnN0IHsgbW9kZWwsIGNtZElkLCBiYXNlSWQgfSA9IHBhcnNlU2V0dGluZ0lkKGFjdGlvbklkKVxuXG5cdFx0Ly8gT25seSBpbmNsdWRlIGFjdGlvbnMgZm9yIHRoZSBjdXJyZW50bHkgYWN0aXZlIG1vZGVsXG5cdFx0aWYgKG1vZGVsICE9PSBhY3RpdmVNb2RlbCkgY29udGludWVcblxuXHRcdC8vIEdldCB0aGUgcmF3IGFjdGlvbiBzY2hlbWEgdG8gYWNjZXNzIGZpeGVkIGJ1c0NoIGFuZCB2YWx1ZSBwcm9wZXJ0aWVzLlxuXHRcdC8vIFVzZSBzY2hlbWFzUmF3IChub3QgdGhlIG5vcm1hbGl6ZWQgc2NoZW1hcykgdG8gcHJlc2VydmUgdG9wLWxldmVsIGZpZWxkc1xuXHRcdC8vIGxpa2UgYHZhbHVlYCB0aGF0IG5vcm1hbGl6YXRpb24gbWF5IHN0cmlwLlxuXHRcdGNvbnN0IHJhd1NjaGVtYSA9IHNjaGVtYXNSYXdbbW9kZWxdXG5cdFx0Y29uc3QgcmF3QWN0aW9uID0gcmF3U2NoZW1hPy5jbWRTY2hlbWE/LmZpbmQoKGE6IGFueSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IGJhc2VJZClcblxuXHRcdHdpcmVkQWN0aW9uc1thY3Rpb25JZF0gPSB7XG5cdFx0XHQuLi5hY3Rpb24sXG5cdFx0XHRjYWxsYmFjazogYXN5bmMgKGV2ZW50OiBhbnkpID0+IHtcblx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3Rcblx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBldmVudC5vcHRpb25zWydidXNDaCddICE9PSB1bmRlZmluZWQgPyBldmVudC5vcHRpb25zWydidXNDaCddIDogcmF3QWN0aW9uPy5idXNDaFxuXHRcdFx0XHRjb25zdCB2YWx1ZSA9IHJhd0FjdGlvbj8udmFsdWUgIT09IHVuZGVmaW5lZCA/IHJhd0FjdGlvbi52YWx1ZSA6IGV2ZW50Lm9wdGlvbnNbJ3ZhbHVlJ11cblx0XHRcdFx0Y29uc3QgaWRBZGQgPSBldmVudC5vcHRpb25zWydpZEFkZCddID8/IDBcblx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gYmFzZUlkICsgaWRBZGRcblxuXHRcdFx0XHRhd2FpdCBzZWxmLnN0Q29udHJvbGxlci5zZW5kQXdhaXRBY2soY21kSWQsIGJ1c0NoLCBzZXR0aW5nSWQsIHZhbHVlLCBpcClcblx0XHRcdH0sXG5cdFx0XHQuLi4ocmF3QWN0aW9uPy52YWx1ZSA9PT0gdW5kZWZpbmVkICYmIHtcblx0XHRcdFx0bGVhcm46IChldmVudDogYW55KSA9PiB7XG5cdFx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3Rcblx0XHRcdFx0XHRjb25zdCBpZEFkZCA9IGV2ZW50Lm9wdGlvbnNbJ2lkQWRkJ10gPz8gMFxuXHRcdFx0XHRcdGNvbnN0IHNldHRpbmdJZCA9IGJhc2VJZCArIGlkQWRkXG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBldmVudC5vcHRpb25zWydidXNDaCddICE9PSB1bmRlZmluZWQgPyBldmVudC5vcHRpb25zWydidXNDaCddIDogcmF3QWN0aW9uPy5idXNDaFxuXG5cdFx0XHRcdFx0Y29uc3QgY3VycmVudCA9IHNlbGYuc3RDb250cm9sbGVyLmdldFNldHRpbmdWYWx1ZShpcCwgY21kSWQsIHNldHRpbmdJZCwgYnVzQ2gpXG5cdFx0XHRcdFx0aWYgKGN1cnJlbnQgPT09IHVuZGVmaW5lZCkgcmV0dXJuIHVuZGVmaW5lZFxuXG5cdFx0XHRcdFx0cmV0dXJuIHsgLi4uZXZlbnQub3B0aW9ucywgdmFsdWU6IGN1cnJlbnQgfVxuXHRcdFx0XHR9LFxuXHRcdFx0fSksXG5cdFx0fVxuXHR9XG5cblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFx1MjcwNSBNSUMgS0lMTCAoT05MWSBJRiBBQ1RJVkUgTU9ERUwgU1VQUE9SVFMgSVQpXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHRjb25zdCBhY3RpdmVTY2hlbWEgPSBzY2hlbWFzW2FjdGl2ZU1vZGVsXVxuXHRpZiAoYWN0aXZlU2NoZW1hKSB7XG5cdFx0Y29uc3Qgc3VwcG9ydHNNaWNLaWxsID0gKGFjdGl2ZVNjaGVtYS5jbWRTY2hlbWEgPz8gW10pLnNvbWUoKGE6IGFueSkgPT4gYS5uYW1lLmluY2x1ZGVzKCdLaWxsJykpXG5cblx0XHRpZiAoc3VwcG9ydHNNaWNLaWxsKSB7XG5cdFx0XHRjb25zdCBhY3Rpb25JZCA9IGAke2FjdGl2ZU1vZGVsfV9taWNLaWxsYFxuXG5cdFx0XHR3aXJlZEFjdGlvbnNbYWN0aW9uSWRdID0ge1xuXHRcdFx0XHRuYW1lOiBgW01vZGVsJHthY3RpdmVNb2RlbH1dIE1pYyBLaWxsYCxcblx0XHRcdFx0b3B0aW9uczogW10sXG5cdFx0XHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3Rcblx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgTWljIEtpbGwgXHUyMTkyIE1vZGVsICR7YWN0aXZlTW9kZWx9IEAgJHtpcH1gKVxuXHRcdFx0XHRcdGF3YWl0IHNlbGYuc3RDb250cm9sbGVyLmdsb2JhbE1pY0tpbGwoaXApXG5cdFx0XHRcdFx0YXdhaXQgc2VsZi5zdENvbnRyb2xsZXIucmVxdWVzdEFsbFNldHRpbmdzKGlwKS5jYXRjaCgoZXJyKSA9PiB7XG5cdFx0XHRcdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIHJlZnJlc2ggc2V0dGluZ3MgYWZ0ZXIgY29tbWFuZDogJHtlcnJ9YClcblx0XHRcdFx0XHR9KVxuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdHNlbGYuc2V0QWN0aW9uRGVmaW5pdGlvbnMod2lyZWRBY3Rpb25zKVxufVxuIiwgImltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCB7IGdldERldmljZVNjaGVtYSB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgY3JlYXRlTW9kdWxlTG9nZ2VyIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7XG5cdENNRF9NSUNfUFJFLFxuXHRDTURfQlVTX1NFVCxcblx0Q01EX0NIQU5ORUwsXG5cdENNRF9HRVRfQUxMX1NFVFRJTkdTLFxuXHRDTURfTUlDX1BSRV9CVVMsXG5cdENNRF9TRVRUSU5HU19QVVNILFxuXHR0b0hleCxcblx0Ynl0ZXNUb0hleCxcblx0Zm9ybWF0UmdiQ29sb3IsXG5cdG1vZGVsRGlzdGFuY2UsXG59IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignU2V0dGluZ3NQYXJzZXInKVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBUWVBFU1xuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgdHlwZSBQYXJzZWRTZXR0aW5nID0ge1xuXHRjbWRfaWQ6IG51bWJlclxuXHRpZDogbnVtYmVyXG5cdGJ1c0NoPzogbnVtYmVyIC8vIE9wdGlvbmFsOiBvbmx5IHByZXNlbnQgZm9yIGNvbW1hbmRzIHdpdGggYnVzQ2ggKDB4MDQsIDB4MTIsIDB4MTQpXG5cdHZhbHVlQnl0ZXM6IG51bWJlcltdXG59XG5cbmV4cG9ydCB0eXBlIFN0QWN0aW9uT3B0aW9uID0ge1xuXHRpZD86IHN0cmluZ1xuXHRsYWJlbDogc3RyaW5nXG5cdHR5cGU6IHN0cmluZ1xuXHRkZWZhdWx0OiB1bmtub3duXG5cdHRvb2x0aXA/OiBzdHJpbmdcblx0Y2hvaWNlcz86IEFycmF5PHsgaWQ6IG51bWJlcjsgbGFiZWw6IHN0cmluZyB9PlxufVxuXG5leHBvcnQgdHlwZSBTdEFjdGlvbiA9IHtcblx0Y21kX2lkOiBudW1iZXJcblx0aWQ6IG51bWJlclxuXHRuYW1lOiBzdHJpbmdcblx0b3B0aW9uczogU3RBY3Rpb25PcHRpb25bXVxuXHRidXNDaD86IG51bWJlciAvLyBGaXhlZCBjaGFubmVsIHZhbHVlIGZvciBhY3Rpb25zIHRoYXQgZG9uJ3QgaGF2ZSBhIGNoYW5uZWwgb3B0aW9uXG5cdHZhbHVlPzogbnVtYmVyIC8vIEZpeGVkIHZhbHVlIFx1MjAxNCBhY3Rpb24gYWx3YXlzIHNlbmRzIHRoaXMgdmFsdWUsIG5vIHVzZXIgaW5wdXQgbmVlZGVkXG5cdHJlYWRvbmx5PzogYm9vbGVhbiAvLyBJZiB0cnVlLCBlbnRyeSBpcyBmZWVkYmFjay1vbmx5IFx1MjAxNCBubyBhY3Rpb24gd2lsbCBiZSBjcmVhdGVkXG5cdHdyaXRlb25seT86IGJvb2xlYW4gLy8gSWYgdHJ1ZSwgZW50cnkgaXMgYWN0aW9uLW9ubHkgXHUyMDE0IG5vIGZlZWRiYWNrIHdpbGwgYmUgY3JlYXRlZCAoZGV2aWNlIG5ldmVyIHJlcG9ydHMgdGhpcyB2YWx1ZSBiYWNrKVxufVxuXG5leHBvcnQgdHlwZSBTdE1vZGVsSnNvbiA9IHtcblx0bW9kZWw6IHN0cmluZ1xuXHR1c2VDb25Nb24/OiBib29sZWFuXG5cdGNtZFNjaGVtYTogU3RBY3Rpb25bXVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBGT1JNQVQgSEVMUEVSU1xuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBnZXRSZ2JJZHMobW9kZWw6IHN0cmluZyk6IFNldDxudW1iZXI+IHtcblx0Y29uc3QgcmdiSWRzID0gbmV3IFNldDxudW1iZXI+KClcblx0dHJ5IHtcblx0XHRjb25zdCBqc29uID0gZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKVxuXHRcdGlmICghanNvbikgcmV0dXJuIHJnYklkc1xuXHRcdGZvciAoY29uc3QgYWN0aW9uIG9mIGpzb24uY21kU2NoZW1hIHx8IFtdKSB7XG5cdFx0XHRjb25zdCBoYXNDb2xvcnBpY2tlciA9IGFjdGlvbi5vcHRpb25zPy5zb21lKChvcHQ6IFN0QWN0aW9uT3B0aW9uKSA9PiBvcHQudHlwZSA9PT0gJ2NvbG9ycGlja2VyJylcblx0XHRcdGlmIChoYXNDb2xvcnBpY2tlcikge1xuXHRcdFx0XHRyZ2JJZHMuYWRkKGFjdGlvbi5pZClcblx0XHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgob3B0OiBTdEFjdGlvbk9wdGlvbikgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRpZiAoaWRBZGRPcHRpb24/LmNob2ljZXMpIHtcblx0XHRcdFx0XHRmb3IgKGNvbnN0IGNob2ljZSBvZiBpZEFkZE9wdGlvbi5jaG9pY2VzKSB7XG5cdFx0XHRcdFx0XHRpZiAodHlwZW9mIGNob2ljZS5pZCA9PT0gJ251bWJlcicpIHtcblx0XHRcdFx0XHRcdFx0cmdiSWRzLmFkZChhY3Rpb24uaWQgKyBjaG9pY2UuaWQpXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHR9IGNhdGNoIChfZXJyKSB7XG5cdFx0Ly8gcmV0dXJuIGVtcHR5IHNldCBvbiBlcnJvclxuXHR9XG5cdHJldHVybiByZ2JJZHNcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgRklORCBUSEUgUkVBTCA1QSBQQVlMT0FEIElOREVYXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmZ1bmN0aW9uIGV4dHJhY3RTdFBheWxvYWRJbmRleChidWY6IEJ1ZmZlcik6IG51bWJlciB7XG5cdGNvbnN0IHNpZ0luZGV4ID0gYnVmLmluZGV4T2YoQnVmZmVyLmZyb20oJ1N0dWRpby1UJykpXG5cdGlmIChzaWdJbmRleCA8IDApIHRocm93IG5ldyBFcnJvcignTm8gU3R1ZGlvLVQgc2lnbmF0dXJlIGluIHBhY2tldCcpXG5cblx0Y29uc3QgcGF5bG9hZEluZGV4ID0gc2lnSW5kZXggKyA4XG5cdGlmIChidWZbcGF5bG9hZEluZGV4XSAhPT0gMHg1YSkge1xuXHRcdHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgMHg1QSBhZnRlciBTdHVkaW8tVCwgZm91bmQgJHtidWZbcGF5bG9hZEluZGV4XS50b1N0cmluZygxNil9YClcblx0fVxuXG5cdHJldHVybiBwYXlsb2FkSW5kZXhcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgU0VDVElPTkVEIFBBUlNFUlxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5mdW5jdGlvbiBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWY6IEJ1ZmZlciwgbW9kZWw6IHN0cmluZyk6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcignTm90IGEgZ2V0QWxsU2V0dGluZ3MgcmVwbHknKVxuXHR9XG5cblx0Ly8gQ01EX0dFVF9BTExfU0VUVElOR1MgaGFzIGEgdG90YWwtbGVuZ3RoIGJ5dGUgYXQgaWR4KzIgYmVmb3JlIHRoZSBzZWN0aW9uczsgQ01EX1NFVFRJTkdTX1BVU0ggZG9lcyBub3QuXG5cdGxldCBwID0gY21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTID8gaWR4ICsgMyA6IGlkeCArIDJcblx0Y29uc3QgZW5kID0gYnVmLmxlbmd0aCAtIDFcblx0Y29uc3Qgb3V0OiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXG5cdGNvbnN0IHJnYklkcyA9IGdldFJnYklkcyhtb2RlbClcblxuXHQvLyBDb21tYW5kIElEcyB0aGF0IGluY2x1ZGUgYSBidXNDaCBieXRlIGluIHRoZWlyIHNlY3Rpb24gc3RydWN0dXJlLFxuXHQvLyBmb2xsb3dlZCBieSBhIGRhdGFMZW4gYnl0ZSBhbmQgdGhlbiBpZDp2YWwgcGFpcnMuXG5cdGNvbnN0IGNvbW1hbmRzV2l0aEJ1c0NoID0gW0NNRF9CVVNfU0VULCBDTURfTUlDX1BSRV9CVVMsIENNRF9DSEFOTkVMXVxuXG5cdC8vIENvbW1hbmQgSURzIHRoYXQgaW5jbHVkZSBhIGJ1c0NoIGJ5dGUgYnV0IHN0b3JlIHJhdyBwb3NpdGlvbmFsIHZhbHVlIGJ5dGVzXG5cdC8vIHJhdGhlciB0aGFuIGlkOnZhbCBwYWlycyAobm8gZGF0YUxlbiBieXRlLCBubyBzZXR0aW5nIElEcykuXG5cdC8vIEZvcm1hdDogW2NtZExlbl0gW2NtZElkXSBbYnVzQ2hdIFt2YWwwXSBbdmFsMV0gLi4uXG5cdGNvbnN0IGNvbW1hbmRzUmF3VmFsdWUgPSBbQ01EX01JQ19QUkVdIC8vIGNtZD0weDAyXG5cblx0d2hpbGUgKHAgKyAyIDwgZW5kKSB7XG5cdFx0Y29uc3QgY21kTGVuID0gYnVmW3BdXG5cdFx0Y29uc3Qgc2VjdGlvbkNtZElkID0gYnVmW3AgKyAxXVxuXG5cdFx0Y29uc3Qgc2VjdGlvbkVuZCA9IHAgKyAxICsgY21kTGVuXG5cdFx0aWYgKHNlY3Rpb25FbmQgPiBlbmQpIGJyZWFrXG5cblx0XHRjb25zdCBoYXNCdXNDaCA9IGNvbW1hbmRzV2l0aEJ1c0NoLmluY2x1ZGVzKHNlY3Rpb25DbWRJZClcblx0XHRjb25zdCBpc1Jhd1ZhbHVlID0gY29tbWFuZHNSYXdWYWx1ZS5pbmNsdWRlcyhzZWN0aW9uQ21kSWQpXG5cblx0XHRsZXQgYnVzQ2g6IG51bWJlciB8IHVuZGVmaW5lZFxuXHRcdGxldCBkYXRhTGVuOiBudW1iZXJcblx0XHRsZXQgcTogbnVtYmVyXG5cblx0XHRpZiAoaXNSYXdWYWx1ZSkge1xuXHRcdFx0Ly8gU3RydWN0dXJlOiBbY21kTGVuXSBbY21kSWRdIFtidXNDaF0gW3ZhbDBdIFt2YWwxXSAuLi5cblx0XHRcdC8vIEJ1aWxkIHBvc2l0aW9uYWwgbWFwIGZyb20gc2NoZW1hOiBmaW5kIGFsbCBlbnRyaWVzIGZvciBDTURfTUlDX1BSRSAoMHgwMikgb3Jcblx0XHRcdC8vIENNRF9NSUNfUFJFX0JVUyAoMHgxMikgd2l0aCBhIGZpeGVkIGJ1c0NoLCBzb3J0ZWQgYnkgaWQgXHUyMDE0IGVhY2ggYmVjb21lcyBvbmVcblx0XHRcdC8vIHBvc2l0aW9uYWwgc2xvdC4gVGhpcyBtYWtlcyB0aGUgcmVtYXAgc2NoZW1hLWRyaXZlbjpcblx0XHRcdC8vICAgMjE0ICAoY21kX2lkPTIsICBpZD0wLzEpIFx1MjE5MiBwb3MwXHUyMTkyKDIsMCksICBwb3MxXHUyMTkyKDIsMSlcblx0XHRcdC8vICAgMjE0QSAoY21kX2lkPTE4LCBpZD0xLzIpIFx1MjE5MiBwb3MwXHUyMTkyKDE4LDEpLCBwb3MxXHUyMTkyKDE4LDIpXG5cdFx0XHQvLyBQb3NpdGlvbnMgd2l0aCBubyBzY2hlbWEgZW50cnkgYXJlIGRyb3BwZWQgKGUuZy4gdW5rbm93biAzcmQgYnl0ZSkuXG5cdFx0XHRidXNDaCA9IGJ1ZltwICsgMl1cblx0XHRcdGNvbnN0IHJhd0J5dGVzID0gYnVmLnN1YmFycmF5KHAgKyAzLCBzZWN0aW9uRW5kKVxuXG5cdFx0XHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdFx0XHRjb25zdCBtaWNQcmVFbnRyaWVzID0gKHNjaGVtYT8uY21kU2NoZW1hID8/IFtdKVxuXHRcdFx0XHQuZmlsdGVyKChhOiBTdEFjdGlvbikgPT4gKGEuY21kX2lkID09PSBDTURfTUlDX1BSRSB8fCBhLmNtZF9pZCA9PT0gQ01EX01JQ19QUkVfQlVTKSAmJiBhLmJ1c0NoICE9PSB1bmRlZmluZWQpXG5cdFx0XHRcdC5zb3J0KChhOiBTdEFjdGlvbiwgYjogU3RBY3Rpb24pID0+IGEuaWQgLSBiLmlkKVxuXG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IHJhd0J5dGVzLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRcdGNvbnN0IGVudHJ5ID0gbWljUHJlRW50cmllc1tpXVxuXHRcdFx0XHRpZiAoZW50cnkpIHtcblx0XHRcdFx0XHRvdXQucHVzaCh7IGNtZF9pZDogZW50cnkuY21kX2lkLCBpZDogZW50cnkuaWQsIGJ1c0NoLCB2YWx1ZUJ5dGVzOiBbcmF3Qnl0ZXNbaV1dIH0pXG5cdFx0XHRcdH1cblx0XHRcdFx0Ly8gbm8gZW50cnkgPSB1bmtub3duIHBvc2l0aW9uYWwgYnl0ZSwgZHJvcCBpdFxuXHRcdFx0fVxuXHRcdFx0cCA9IHNlY3Rpb25FbmRcblx0XHRcdGNvbnRpbnVlXG5cdFx0fSBlbHNlIGlmIChoYXNCdXNDaCkge1xuXHRcdFx0Ly8gU3RydWN0dXJlOiBbY21kTGVuXSBbY21kSWRdIFtidXNDaF0gW2RhdGFMZW5dIFtpZDp2YWwgcGFpcnNdXG5cdFx0XHRidXNDaCA9IGJ1ZltwICsgMl1cblx0XHRcdGRhdGFMZW4gPSBidWZbcCArIDNdXG5cdFx0XHRxID0gcCArIDRcblx0XHR9IGVsc2Uge1xuXHRcdFx0Ly8gU3RydWN0dXJlOiBbY21kTGVuXSBbY21kSWRdIFtkYXRhTGVuXSBbaWQ6dmFsIHBhaXJzXVxuXHRcdFx0ZGF0YUxlbiA9IGJ1ZltwICsgMl1cblx0XHRcdHEgPSBwICsgM1xuXHRcdH1cblxuXHRcdGNvbnN0IHFFbmQgPSBxICsgZGF0YUxlblxuXHRcdGNvbnN0IHFTdGFydCA9IHFcblxuXHRcdHdoaWxlIChxICsgMSA8IHFFbmQpIHtcblx0XHRcdGNvbnN0IGlkID0gYnVmW3FdXG5cdFx0XHRsZXQgdmFsdWVCeXRlczogbnVtYmVyW11cblxuXHRcdFx0Ly8gQ2hlY2sgaWYgdGhpcyBJRCBpcyBhbiBSR0IgY29sb3JwaWNrZXIgKG5lZWRzIDMgYnl0ZXMpXG5cdFx0XHRpZiAocmdiSWRzLmhhcyhpZCkgJiYgcSArIDMgPCBxRW5kKSB7XG5cdFx0XHRcdHZhbHVlQnl0ZXMgPSBbYnVmW3EgKyAxXSwgYnVmW3EgKyAyXSwgYnVmW3EgKyAzXV1cblx0XHRcdFx0cSArPSA0XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHR2YWx1ZUJ5dGVzID0gW2J1ZltxICsgMV1dXG5cdFx0XHRcdHEgKz0gMlxuXHRcdFx0fVxuXG5cdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0ge1xuXHRcdFx0XHRjbWRfaWQ6IHNlY3Rpb25DbWRJZCxcblx0XHRcdFx0aWQsXG5cdFx0XHRcdHZhbHVlQnl0ZXMsXG5cdFx0XHR9XG5cdFx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRzZXR0aW5nLmJ1c0NoID0gYnVzQ2hcblx0XHRcdH1cblx0XHRcdG91dC5wdXNoKHNldHRpbmcpXG5cdFx0fVxuXG5cdFx0Ly8gUG9zaXRpb25hbCBmYWxsYmFjazogaWYgdGhlIGJ5dGUgd2UgcmVhZCBhcyBkYXRhTGVuIHdhcyAweDAwIGJ1dCB0aGUgc2VjdGlvblxuXHRcdC8vIHN0aWxsIGNvbnRhaW5zIGRhdGEgYnl0ZXMsIHRoaXMgc2VjdGlvbiBsaWtlbHkgdXNlcyBhIG5vLWRhdGFMZW4gZm9ybWF0IHdoZXJlXG5cdFx0Ly8gZWFjaCBieXRlIGFmdGVyIGNtZElkIGlzIGEgcmF3IHZhbHVlIGF0IGEgZml4ZWQgcG9zaXRpb24gKHBvc2l0aW9uID0gaWQpLlxuXHRcdC8vIFJlLXBhcnNlIGZyb20gcCsyIChyaWdodCBhZnRlciBjbWRJZCksIHRyZWF0aW5nIHRoZSBcImRhdGFMZW5cIiBieXRlIGFzIGlkPTAuXG5cdFx0Ly8gT25seSBmaXJlIGlmIG5vIGJ5dGVzIHdlcmUgY29uc3VtZWQgYnkgdGhlIG1haW4gbG9vcCAocSA9PT0gcVN0YXJ0KSwgdG8gYXZvaWRcblx0XHQvLyByZS1wYXJzaW5nIGJ5dGVzIHRoYXQgd2VyZSBhbHJlYWR5IHN1Y2Nlc3NmdWxseSBwYXJzZWQuXG5cdFx0aWYgKHEgPT09IHFTdGFydCAmJiBzZWN0aW9uRW5kID4gcCArIDMpIHtcblx0XHRcdGxldCBwb3MgPSBoYXNCdXNDaCA/IHAgKyAzIDogcCArIDIgLy8gc2tpcCBjbWRJZCAoYW5kIGJ1c0NoIGlmIHByZXNlbnQpXG5cdFx0XHRsZXQgcG9zSWQgPSAwXG5cdFx0XHR3aGlsZSAocG9zIDwgc2VjdGlvbkVuZCkge1xuXHRcdFx0XHRjb25zdCBzZXR0aW5nOiBQYXJzZWRTZXR0aW5nID0geyBjbWRfaWQ6IHNlY3Rpb25DbWRJZCwgaWQ6IHBvc0lkKyssIHZhbHVlQnl0ZXM6IFtidWZbcG9zKytdXSB9XG5cdFx0XHRcdGlmIChidXNDaCAhPT0gdW5kZWZpbmVkKSBzZXR0aW5nLmJ1c0NoID0gYnVzQ2hcblx0XHRcdFx0b3V0LnB1c2goc2V0dGluZylcblx0XHRcdH1cblx0XHR9XG5cblx0XHRwID0gc2VjdGlvbkVuZFxuXHR9XG5cblx0cmV0dXJuIG91dFxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBHRU5FUklDIFNFVFRJTkdTIFJFU1BPTlNFIFBBUlNFUiAoMHgwYSBnZXQtYWxsICsgMHgwYiB1bnNvbGljaXRlZCBwdXNoKVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG4vKipcbiAqIFBhcnNlcyBhbnkgZnVsbCBzZXR0aW5ncyBibG9jayByZWdhcmRsZXNzIG9mIHdoZXRoZXIgdGhlIGNtZElkIGlzIDB4MGFcbiAqIChyZXNwb25zZSB0byBHZXQgQWxsIFNldHRpbmdzKSBvciAweDBiICh1bnNvbGljaXRlZCBwdXNoIGFmdGVyIGEgc2V0KS5cbiAqIEJvdGggdXNlIHRoZSBzYW1lIHNlY3Rpb25lZCBvciBmbGF0IGJsb2NrIGxheW91dC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlU2V0dGluZ3NSZXNwb25zZShtb2RlbDogc3RyaW5nLCBidWY6IEJ1ZmZlcik6IFBhcnNlZFNldHRpbmdbXSB7XG5cdGNvbnN0IGlkeCA9IGV4dHJhY3RTdFBheWxvYWRJbmRleChidWYpXG5cdGNvbnN0IGNtZElkID0gYnVmW2lkeCArIDFdICYgMHg3ZlxuXHRpZiAoY21kSWQgIT09IENNRF9HRVRfQUxMX1NFVFRJTkdTICYmIGNtZElkICE9PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdHRocm93IG5ldyBFcnJvcihgTm90IGEgc2V0dGluZ3MgYmxvY2sgKGNtZElkPTB4JHtjbWRJZC50b1N0cmluZygxNil9KWApXG5cdH1cblx0cmV0dXJuIHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpXG59XG5cbi8qKlxuICogRm9ybWF0cyBhIHNpbmdsZSBwYXJzZWQgc2V0dGluZyBpbnRvIGEgaHVtYW4tcmVhZGFibGUgc3RyaW5nIHVzaW5nIGFjdGlvblxuICogZGVmaW5pdGlvbnMgZnJvbSB0aGUgZGV2aWNlIEpTT04uIEZhbGxzIGJhY2sgdG8gaGV4IElEcyB3aGVuIHVua25vd24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRQYXJzZWRTZXR0aW5nKHNldHRpbmc6IFBhcnNlZFNldHRpbmcsIGFjdGlvbnM6IFN0QWN0aW9uW10pOiBzdHJpbmcge1xuXHQvLyBUcnkgZXhhY3QgbWF0Y2ggZmlyc3Rcblx0bGV0IGFjdGlvbiA9IGFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IHNldHRpbmcuY21kX2lkICYmIGEuaWQgPT09IHNldHRpbmcuaWQpXG5cblx0Ly8gSWYgbm8gZXhhY3QgbWF0Y2ggYW5kIGlkID4gYmFzZSBpZCwgdHJ5IHRvIGZpbmQgYWN0aW9uIHdpdGggaWRBZGQgb3B0aW9uXG5cdC8vIFRoaXMgaGFuZGxlcyBjYXNlcyBsaWtlIENNRF9IRUFEUEhPTkUgKDB4MDUsIGUuZy4gUGhvbmVzIFJvdXRpbmcpIGFuZFxuXHQvLyBDTURfQlVUVE9OX01PREUgKDB4MDcsIGUuZy4gQnV0dG9ucykgd2hlcmUgaWQgMC0zIHJlcHJlc2VudHMgY2hhbm5lbHMgMS00XG5cdGlmICghYWN0aW9uKSB7XG5cdFx0Y29uc3QgYmFzZUFjdGlvbiA9IGFjdGlvbnMuZmluZCgoYSkgPT4ge1xuXHRcdFx0aWYgKGEuY21kX2lkICE9PSBzZXR0aW5nLmNtZF9pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiB0aGlzIGFjdGlvbiBoYXMgYW4gaWRBZGQgb3B0aW9uIChpbmRpY2F0aW5nIGNoYW5uZWwgc2VsZWN0aW9uKVxuXHRcdFx0Y29uc3QgaWRBZGRPcHRpb24gPSBhLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdGlvbj8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHQvLyBDaGVjayBpZiB0aGUgc2V0dGluZy5pZCBvZmZzZXQgbWF0Y2hlcyBvbmUgb2YgdGhlIGlkQWRkIGNob2ljZSBJRHNcblx0XHRcdGNvbnN0IGNoYW5uZWxPZmZzZXQgPSBzZXR0aW5nLmlkIC0gYS5pZFxuXHRcdFx0cmV0dXJuIGlkQWRkT3B0aW9uLmNob2ljZXMuc29tZSgoYykgPT4gYy5pZCA9PT0gY2hhbm5lbE9mZnNldClcblx0XHR9KVxuXHRcdGlmIChiYXNlQWN0aW9uKSB7XG5cdFx0XHRhY3Rpb24gPSBiYXNlQWN0aW9uXG5cdFx0fVxuXHR9XG5cblx0Y29uc3QgY21kSGV4ID0gdG9IZXgoc2V0dGluZy5jbWRfaWQpXG5cdGNvbnN0IGlkSGV4ID0gdG9IZXgoc2V0dGluZy5pZClcblx0Y29uc3QgdmFsSGV4ID0gYnl0ZXNUb0hleChzZXR0aW5nLnZhbHVlQnl0ZXMpXG5cdGNvbnN0IHZhbERlYyA9XG5cdFx0c2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gM1xuXHRcdFx0PyBmb3JtYXRSZ2JDb2xvcihzZXR0aW5nLnZhbHVlQnl0ZXNbMF0sIHNldHRpbmcudmFsdWVCeXRlc1sxXSwgc2V0dGluZy52YWx1ZUJ5dGVzWzJdKVxuXHRcdFx0OiBzZXR0aW5nLnZhbHVlQnl0ZXMubGVuZ3RoID09PSAxXG5cdFx0XHRcdD8gc2V0dGluZy52YWx1ZUJ5dGVzWzBdXG5cdFx0XHRcdDogc2V0dGluZy52YWx1ZUJ5dGVzLmpvaW4oJywnKVxuXG5cdC8vIEJ1aWxkIHRoZSBwcmVmaXg6IGNtZDoweDEyIGNoOjAgaWQ6MHgwMSB2YWw6MHgxNCAoY2ggb25seSBmb3IgY29tbWFuZHMgd2l0aCBidXNDaClcblx0Y29uc3QgYnVzQ2hTdHIgPSBzZXR0aW5nLmJ1c0NoICE9PSB1bmRlZmluZWQgPyBgIGNoOiR7c2V0dGluZy5idXNDaH1gIDogJydcblx0Y29uc3QgcHJlZml4ID0gYGNtZDoke2NtZEhleH0ke2J1c0NoU3RyfSBpZDoke2lkSGV4fSB2YWw6JHt2YWxIZXh9YFxuXG5cdC8vIElmIHdlIGhhdmUgYW4gYWN0aW9uIHdpdGggYSBuYW1lIGFuZCBjaG9pY2UgbGFiZWwsIHVzZSBpdFxuXHRpZiAoYWN0aW9uKSB7XG5cdFx0bGV0IG5hbWUgPSBhY3Rpb24ubmFtZVxuXG5cdFx0Ly8gSWYgc2V0dGluZyBoYXMgYnVzQ2gsIGFkZCBjaGFubmVsIGluZm8gdG8gbmFtZVxuXHRcdGlmIChzZXR0aW5nLmJ1c0NoICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdG5hbWUgPSBgJHtuYW1lfSBDaCR7c2V0dGluZy5idXNDaCArIDF9YFxuXHRcdH1cblx0XHQvLyBPdGhlcndpc2UsIGlmIHRoaXMgYWN0aW9uIGhhcyBpZEFkZCwgaW5jbHVkZSB0aGUgaWRBZGQgbGFiZWxcblx0XHRlbHNlIHtcblx0XHRcdGNvbnN0IGlkQWRkT3B0aW9uID0gYWN0aW9uLm9wdGlvbnM/LmZpbmQoKG9wdCkgPT4gb3B0LmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKGlkQWRkT3B0aW9uPy5jaG9pY2VzKSB7XG5cdFx0XHRcdGNvbnN0IGNoYW5uZWxPZmZzZXQgPSBzZXR0aW5nLmlkIC0gYWN0aW9uLmlkXG5cdFx0XHRcdGNvbnN0IGlkQWRkQ2hvaWNlID0gaWRBZGRPcHRpb24uY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSBjaGFubmVsT2Zmc2V0KVxuXHRcdFx0XHRpZiAoaWRBZGRDaG9pY2UpIHtcblx0XHRcdFx0XHRuYW1lID0gYCR7bmFtZX0gJHtpZEFkZENob2ljZS5sYWJlbH1gXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBMb29rIGZvciB0aGUgdmFsdWUgb3B0aW9uIChub3QgYnVzQ2ggb3IgaWRBZGQpXG5cdFx0Y29uc3QgdmFsdWVPcHRpb24gPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgob3B0KSA9PiBvcHQuaWQgPT09ICd2YWx1ZScpXG5cdFx0Ly8gRm9yIGZpeGVkLXZhbHVlIGFjdGlvbnMsIGZhbGwgYmFjayB0byB0aGUgdG9wLWxldmVsIHZhbHVlIHByb3BlcnR5XG5cdFx0Y29uc3QgZml4ZWRWYWx1ZSA9IChhY3Rpb24gYXMgYW55KS52YWx1ZVxuXHRcdGlmIChmaXhlZFZhbHVlICE9PSB1bmRlZmluZWQgJiYgdmFsdWVPcHRpb24gPT09IHVuZGVmaW5lZCkge1xuXHRcdFx0cmV0dXJuIGAke3ByZWZpeH0gfCAke25hbWV9OiAke2ZpeGVkVmFsdWV9YFxuXHRcdH1cblx0XHRpZiAodmFsdWVPcHRpb24/LmNob2ljZXMgJiYgc2V0dGluZy52YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0Y29uc3QgY2hvaWNlID0gdmFsdWVPcHRpb24uY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSBzZXR0aW5nLnZhbHVlQnl0ZXNbMF0pXG5cdFx0XHRpZiAoY2hvaWNlKSB7XG5cdFx0XHRcdHJldHVybiBgJHtwcmVmaXh9IHwgJHtuYW1lfTogJHtjaG9pY2UubGFiZWx9ICgke3ZhbERlY30pYFxuXHRcdFx0fVxuXHRcdH1cblx0XHRyZXR1cm4gYCR7cHJlZml4fSB8ICR7bmFtZX06ICR7dmFsRGVjfWBcblx0fVxuXG5cdC8vIE5vIGFjdGlvbiBmb3VuZCAtIGp1c3Qgc2hvdyB0aGUgcmF3IHZhbHVlc1xuXHRyZXR1cm4gYCR7cHJlZml4fSB8IFVua25vd24gU2V0dGluZ2Bcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgUEFSU0VSIERJU1BBVENIIFdJVEggQVVUTy1ERVRFQ1RJT05cbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBQYXJzZXMgZ2V0QWxsU2V0dGluZ3MgcmVzcG9uc2Ugd2l0aCBhdXRvbWF0aWMgZm9ybWF0IGRldGVjdGlvbi5cbiAqXG4gKiBAcmV0dXJucyB7c2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXSwgZGV0ZWN0ZWRTZWN0aW9uZWQ6IGJvb2xlYW4gfCBudWxsfVxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc1dpdGhEZXRlY3Rpb24oXG5cdG1vZGVsOiBzdHJpbmcsXG5cdGJ1ZjogQnVmZmVyLFxuKTogeyBzZXR0aW5nczogUGFyc2VkU2V0dGluZ1tdOyBkZXRlY3RlZFNlY3Rpb25lZDogbnVsbCB9IHtcblx0Y29uc3Qgc2V0dGluZ3MgPSBwYXJzZUdldEFsbFNldHRpbmdzX3NlY3Rpb25lZChidWYsIG1vZGVsKVxuXHRyZXR1cm4geyBzZXR0aW5ncywgZGV0ZWN0ZWRTZWN0aW9uZWQ6IG51bGwgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHZXRBbGxTZXR0aW5nc0Zvck1vZGVsKG1vZGVsOiBzdHJpbmcsIGJ1ZjogQnVmZmVyKTogUGFyc2VkU2V0dGluZ1tdIHtcblx0cmV0dXJuIHBhcnNlR2V0QWxsU2V0dGluZ3Nfc2VjdGlvbmVkKGJ1ZiwgbW9kZWwpXG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIFZBTFVFIFx1MjE5MiBPUFRJT05cbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZnVuY3Rpb24gdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXM6IG51bWJlcltdKTogU3RBY3Rpb25PcHRpb24ge1xuXHRpZiAodmFsdWVCeXRlcy5sZW5ndGggPT09IDEpIHtcblx0XHRyZXR1cm4geyBpZDogJ3ZhbHVlJywgbGFiZWw6ICdWYWx1ZScsIHR5cGU6ICdudW1iZXInLCBkZWZhdWx0OiB2YWx1ZUJ5dGVzWzBdIH1cblx0fVxuXG5cdGlmICh2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMykge1xuXHRcdGNvbnN0IFtyLCBnLCBiXSA9IHZhbHVlQnl0ZXNcblx0XHRyZXR1cm4ge1xuXHRcdFx0aWQ6ICd2YWx1ZScsXG5cdFx0XHRsYWJlbDogJ0NvbG9yJyxcblx0XHRcdHR5cGU6ICdjb2xvcnBpY2tlcicsXG5cdFx0XHRkZWZhdWx0OiBmb3JtYXRSZ2JDb2xvcihyLCBnLCBiKSxcblx0XHR9XG5cdH1cblxuXHRyZXR1cm4geyBpZDogJ3ZhbHVlJywgbGFiZWw6ICdWYWx1ZScsIHR5cGU6ICdyYXcnLCBkZWZhdWx0OiBbLi4udmFsdWVCeXRlc10gfVxufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqICBTTUFSVCBKU09OIFVQREFURVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlTW9kZWxKc29uRnJvbVNldHRpbmdzKFxuXHRtb2RlbEpzb246IFN0TW9kZWxKc29uLFxuXHRwYXJzZWQ6IFBhcnNlZFNldHRpbmdbXSxcblx0YWxsTW9kZWxzOiBSZWNvcmQ8c3RyaW5nLCBTdE1vZGVsSnNvbj4sXG4pOiBTdE1vZGVsSnNvbiB7XG5cdGNvbnN0IG91dCA9IHN0cnVjdHVyZWRDbG9uZShtb2RlbEpzb24pXG5cblx0Ly8gRW5zdXJlIGNtZFNjaGVtYSBhcnJheSBleGlzdHNcblx0aWYgKCFvdXQuY21kU2NoZW1hKSB7XG5cdFx0b3V0LmNtZFNjaGVtYSA9IFtdXG5cdH1cblxuXHQvLyBTb3J0IG90aGVyIG1vZGVscyBieSBudW1lcmljIGRpc3RhbmNlIHRvIGN1cnJlbnQgbW9kZWxcblx0Y29uc3QgY2FuZGlkYXRlcyA9IE9iamVjdC52YWx1ZXMoYWxsTW9kZWxzKVxuXHRcdC5maWx0ZXIoKG0pID0+IG0ubW9kZWwgIT09IG1vZGVsSnNvbi5tb2RlbCkgLy8gZXhjbHVkZSBzZWxmXG5cdFx0LnNvcnQoKGEsIGIpID0+IG1vZGVsRGlzdGFuY2UobW9kZWxKc29uLm1vZGVsLCBhLm1vZGVsKSAtIG1vZGVsRGlzdGFuY2UobW9kZWxKc29uLm1vZGVsLCBiLm1vZGVsKSlcblxuXHRsb2dnZXIuaW5mbyhgVXBkYXRpbmcgbW9kZWw6ICR7bW9kZWxKc29uLm1vZGVsfWApXG5cdGxvZ2dlci5kZWJ1ZyhgQ2FuZGlkYXRlcyBmb3IgaW5mZXJlbmNlOiAke2NhbmRpZGF0ZXMubWFwKChjKSA9PiBjLm1vZGVsKS5qb2luKCcsICcpfWApXG5cblx0Ly8gUHJlLXNjYW46IGZvciBlYWNoIGNhbmRpZGF0ZSBpZEFkZCBiYXNlIGVudHJ5LCBmaW5kIHRoZSBtYXhpbXVtIHNlcXVlbnRpYWxcblx0Ly8gb2Zmc2V0IHRoZSBwYWNrZXQgY29udGFpbnMgKGV2ZW4gYmV5b25kIHdoYXQgdGhlIHJlZmVyZW5jZSBtb2RlbCBrbm93cykuXG5cdC8vIEtleTogYCR7Y21kX2lkfV8ke2Jhc2VfaWR9YCwgdmFsdWU6IG1heCBzZXF1ZW50aWFsIG9mZnNldCBzZWVuIGluIHBhcnNlZCBkYXRhLlxuXHRjb25zdCBpZEFkZERlZmVyUmFuZ2VzID0gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4oKVxuXHRmb3IgKGNvbnN0IGMgb2YgY2FuZGlkYXRlcykge1xuXHRcdGZvciAoY29uc3QgYmFzZUVudHJ5IG9mIGMuY21kU2NoZW1hID8/IFtdKSB7XG5cdFx0XHRjb25zdCBpZEFkZE9wdCA9IGJhc2VFbnRyeS5vcHRpb25zPy5maW5kKChvOiBhbnkpID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRpZiAoIWlkQWRkT3B0Py5jaG9pY2VzKSBjb250aW51ZVxuXHRcdFx0Y29uc3QgYmFzZUlkID0gYmFzZUVudHJ5LmlkXG5cdFx0XHRjb25zdCBjbWRJZCA9IGJhc2VFbnRyeS5jbWRfaWRcblx0XHRcdGNvbnN0IGtleSA9IGAke2NtZElkfV8ke2Jhc2VJZH1gXG5cdFx0XHRpZiAoaWRBZGREZWZlclJhbmdlcy5oYXMoa2V5KSkgY29udGludWVcblx0XHRcdC8vIEZpbmQgdGhlIG1heCBzZXF1ZW50aWFsIG9mZnNldCBwcmVzZW50IGluIHRoZSBwYXJzZWQgcGFja2V0IGZvciB0aGlzIGJhc2Vcblx0XHRcdGNvbnN0IHBhcnNlZE9mZnNldHMgPSBwYXJzZWRcblx0XHRcdFx0LmZpbHRlcigocCkgPT4gcC5jbWRfaWQgPT09IGNtZElkICYmIHAuaWQgPiBiYXNlSWQpXG5cdFx0XHRcdC5tYXAoKHApID0+IHAuaWQgLSBiYXNlSWQpXG5cdFx0XHRcdC5zb3J0KChhLCBiKSA9PiBhIC0gYilcblx0XHRcdC8vIFdhbGsgZnJvbSAxIHVwd2FyZCBcdTIwMTQgc3RvcCBhdCBmaXJzdCBnYXBcblx0XHRcdGxldCBtYXhTZXEgPSAwXG5cdFx0XHRmb3IgKGNvbnN0IG9mZiBvZiBwYXJzZWRPZmZzZXRzKSB7XG5cdFx0XHRcdGlmIChvZmYgPT09IG1heFNlcSArIDEpIG1heFNlcSA9IG9mZlxuXHRcdFx0XHRlbHNlIGlmIChvZmYgPiBtYXhTZXEgKyAxKSBicmVha1xuXHRcdFx0fVxuXHRcdFx0aWYgKG1heFNlcSA+IDApIHtcblx0XHRcdFx0aWRBZGREZWZlclJhbmdlcy5zZXQoa2V5LCBtYXhTZXEpXG5cdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgaWRBZGQgZGVmZXIgcmFuZ2UgZm9yIGNtZF9pZD0ke3RvSGV4KGNtZElkKX0gYmFzZV9pZD0ke3RvSGV4KGJhc2VJZCl9OiBvZmZzZXRzIDFcdTIwMTMke21heFNlcX1gKVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdC8vIFByZS1jb21wdXRlIHRoZSBzZXQgb2YgYWxsIGJ1c0NoIHZhbHVlcyBzZWVuIHBlciAoY21kX2lkLCBpZCkgcGFpciBhY3Jvc3MgdGhlIGZ1bGxcblx0Ly8gcGFyc2VkIHJlc3BvbnNlIFx1MjAxNCB1c2VkIGxhdGVyIHRvIGRlY2lkZSBmaXhlZCB2cy4gc2VsZWN0YWJsZSBidXNDaC5cblx0Y29uc3QgYnVzQ2hTZWVuID0gbmV3IE1hcDxzdHJpbmcsIFNldDxudW1iZXI+PigpXG5cdGZvciAoY29uc3QgeyBjbWRfaWQsIGlkLCBidXNDaCB9IG9mIHBhcnNlZCkge1xuXHRcdGlmIChidXNDaCA9PT0gdW5kZWZpbmVkKSBjb250aW51ZVxuXHRcdGNvbnN0IGtleSA9IGAke2NtZF9pZH1fJHtpZH1gXG5cdFx0aWYgKCFidXNDaFNlZW4uaGFzKGtleSkpIGJ1c0NoU2Vlbi5zZXQoa2V5LCBuZXcgU2V0KCkpXG5cdFx0YnVzQ2hTZWVuLmdldChrZXkpIS5hZGQoYnVzQ2gpXG5cdH1cblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFBBU1MgMTogcmVzb2x2ZSBlYWNoIHBhcnNlZCBlbnRyeSBcdTIwMTQgZXhhY3QgbWF0Y2gsIGluZmVycmVkLFxuXHQvLyBpZEFkZC1mb2xkIChvZmZzZXQgaW50byBhbiBhbHJlYWR5LWFkZGVkIGJhc2UgZW50cnkpLCBvciB1bmtub3duXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Zm9yIChjb25zdCB7IGNtZF9pZCwgaWQsIGJ1c0NoLCB2YWx1ZUJ5dGVzIH0gb2YgcGFyc2VkKSB7XG5cdFx0Ly8gMWEuIEV4YWN0IG1hdGNoIGFscmVhZHkgaW4gb3V0cHV0IHNjaGVtYSBcdTIwMTQgcmVmcmVzaCB0aGUgZGVmYXVsdCBhbmQgc3luYyBidXNDaFxuXHRcdGNvbnN0IGV4aXN0aW5nRXhhY3QgPSBvdXQuY21kU2NoZW1hLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWQpXG5cdFx0aWYgKGV4aXN0aW5nRXhhY3QpIHtcblx0XHRcdGNvbnN0IG9wdCA9IGV4aXN0aW5nRXhhY3Qub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ3ZhbHVlJylcblx0XHRcdGlmIChvcHQpIG9wdC5kZWZhdWx0ID0gdmFsdWVCeXRlc1RvT3B0aW9uKHZhbHVlQnl0ZXMpLmRlZmF1bHRcblxuXHRcdFx0Ly8gU3luYyBidXNDaCBmcm9tIHBhY2tldCBkYXRhIGlmIHRoZSBleGlzdGluZyBlbnRyeSBpcyBtaXNzaW5nIGl0XG5cdFx0XHRjb25zdCBzZWVuQnVzQ2hWYWx1ZXMgPSBidXNDaFNlZW4uZ2V0KGAke2NtZF9pZH1fJHtpZH1gKVxuXHRcdFx0aWYgKHNlZW5CdXNDaFZhbHVlcyAmJiBzZWVuQnVzQ2hWYWx1ZXMuc2l6ZSA+IDApIHtcblx0XHRcdFx0Y29uc3QgbWF4QnVzQ2ggPSBNYXRoLm1heCguLi5zZWVuQnVzQ2hWYWx1ZXMpXG5cdFx0XHRcdGNvbnN0IGhhc0J1c0NoT3B0aW9uID0gZXhpc3RpbmdFeGFjdC5vcHRpb25zPy5zb21lKChvKSA9PiBvLmlkID09PSAnYnVzQ2gnKVxuXHRcdFx0XHRpZiAobWF4QnVzQ2ggPT09IDAgJiYgZXhpc3RpbmdFeGFjdC5idXNDaCA9PT0gdW5kZWZpbmVkICYmICFoYXNCdXNDaE9wdGlvbikge1xuXHRcdFx0XHRcdGV4aXN0aW5nRXhhY3QuYnVzQ2ggPSAwXG5cdFx0XHRcdFx0bG9nZ2VyLmluZm8oYFN5bmNlZCBidXNDaD0wIG9udG8gZXhpc3RpbmcgZW50cnkgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9YClcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0Y29udGludWVcblx0XHR9XG5cblx0XHQvLyAxYi4gQ2hlY2sgaWYgdGhpcyBpZCBmb2xkcyBpbnRvIGFuIGFscmVhZHktYWRkZWQgYmFzZSBlbnRyeSB2aWEgaWRBZGQuXG5cdFx0Ly8gICAgIEdhdGU6IHRoZSBvZmZzZXQgbXVzdCBhY3R1YWxseSBleGlzdCBpbiB0aGUgcmVmZXJlbmNlIG1vZGVsJ3MgaWRBZGQgY2hvaWNlc1xuXHRcdC8vICAgICB0byBhdm9pZCBzd2FsbG93aW5nIHVucmVsYXRlZCBzYW1lLWNtZF9pZCBlbnRyaWVzIChlLmcuIFNpZGV0b25lIGF0IGlkPTIxKS5cblx0XHRjb25zdCBpZEFkZEJhc2UgPSBvdXQuY21kU2NoZW1hLmZpbmQoKGEpID0+IHtcblx0XHRcdGlmIChhLmNtZF9pZCAhPT0gY21kX2lkKSByZXR1cm4gZmFsc2Vcblx0XHRcdGNvbnN0IGlkQWRkT3B0ID0gYS5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKCFpZEFkZE9wdD8uY2hvaWNlcykgcmV0dXJuIGZhbHNlXG5cdFx0XHRpZiAoaWQgPD0gYS5pZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRjb25zdCBvZmZzZXQgPSBpZCAtIGEuaWRcblx0XHRcdC8vIE9ubHkgZm9sZCBpZiBhIHJlZmVyZW5jZSBtb2RlbCBleHBsaWNpdGx5IGxpc3RzIHRoaXMgb2Zmc2V0IGluIGl0cyBpZEFkZCBjaG9pY2VzXG5cdFx0XHRyZXR1cm4gY2FuZGlkYXRlcy5zb21lKChjKSA9PiB7XG5cdFx0XHRcdGNvbnN0IHJlZkVudHJ5ID0gYy5jbWRTY2hlbWE/LmZpbmQoKHIpID0+IHIuY21kX2lkID09PSBjbWRfaWQgJiYgci5pZCA9PT0gYS5pZClcblx0XHRcdFx0Y29uc3QgcmVmSWRBZGQgPSByZWZFbnRyeT8ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0cmV0dXJuIHJlZklkQWRkPy5jaG9pY2VzPy5zb21lKChjaDogYW55KSA9PiBjaC5pZCA9PT0gb2Zmc2V0KVxuXHRcdFx0fSlcblx0XHR9KVxuXHRcdGlmIChpZEFkZEJhc2UpIHtcblx0XHRcdGNvbnN0IG9mZnNldCA9IGlkIC0gaWRBZGRCYXNlLmlkXG5cdFx0XHRjb25zdCBpZEFkZE9wdCA9IGlkQWRkQmFzZS5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0aWYgKGlkQWRkT3B0Py5jaG9pY2VzICYmICFpZEFkZE9wdC5jaG9pY2VzLnNvbWUoKGM6IGFueSkgPT4gYy5pZCA9PT0gb2Zmc2V0KSkge1xuXHRcdFx0XHRsZXQgbGFiZWwgPSBgQ2hhbm5lbCAke29mZnNldCArIDF9YFxuXHRcdFx0XHRmb3IgKGNvbnN0IGMgb2YgY2FuZGlkYXRlcykge1xuXHRcdFx0XHRcdGNvbnN0IHJlZkVudHJ5ID0gYy5jbWRTY2hlbWE/LmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWRBZGRCYXNlLmlkKVxuXHRcdFx0XHRcdGNvbnN0IHJlZklkQWRkID0gcmVmRW50cnk/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRcdFx0Y29uc3QgcmVmQ2hvaWNlID0gcmVmSWRBZGQ/LmNob2ljZXM/LmZpbmQoKGNoOiBhbnkpID0+IGNoLmlkID09PSBvZmZzZXQpXG5cdFx0XHRcdFx0aWYgKHJlZkNob2ljZSkge1xuXHRcdFx0XHRcdFx0bGFiZWwgPSByZWZDaG9pY2UubGFiZWxcblx0XHRcdFx0XHRcdGJyZWFrXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdGlkQWRkT3B0LmNob2ljZXMucHVzaCh7IGlkOiBvZmZzZXQsIGxhYmVsIH0pXG5cdFx0XHRcdGxvZ2dlci5pbmZvKFxuXHRcdFx0XHRcdGBGb2xkZWQgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9IGludG8gaWRBZGQgYmFzZSBpZD0ke3RvSGV4KGlkQWRkQmFzZS5pZCl9IGFzIG9mZnNldCAke29mZnNldH0gKFwiJHtsYWJlbH1cIilgLFxuXHRcdFx0XHQpXG5cdFx0XHR9XG5cdFx0XHRjb250aW51ZVxuXHRcdH1cblxuXHRcdC8vIDFjLiBObyBleGFjdCBtYXRjaCBcdTIwMTQgdHJ5IGluZmVyZW5jZSBmcm9tIGNhbmRpZGF0ZSBtb2RlbHNcblx0XHRsZXQgYWN0aW9uOiBTdEFjdGlvbiB8IHVuZGVmaW5lZFxuXG5cdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdGNvbnN0IG1hdGNoID0gYy5jbWRTY2hlbWE/LmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWQpXG5cdFx0XHRpZiAobWF0Y2gpIHtcblx0XHRcdFx0YWN0aW9uID0gc3RydWN0dXJlZENsb25lKG1hdGNoKVxuXHRcdFx0XHQvLyBTdHJpcCBhbnkgZXhpc3RpbmcgXCIoaW5mZXJyZWQgZnJvbSBNb2RlbCBYKVwiIHN1ZmZpeGVzIGJlZm9yZSBhZGRpbmcgb3VyIG93blxuXHRcdFx0XHRjb25zdCBiYXNlTmFtZSA9IG1hdGNoLm5hbWUucmVwbGFjZSgvXFxzKlxcKGluZmVycmVkIGZyb20gTW9kZWwgW14pXStcXCkvZywgJycpLnRyaW0oKVxuXHRcdFx0XHRhY3Rpb24ubmFtZSA9IGAke2Jhc2VOYW1lfSAoaW5mZXJyZWQgZnJvbSBNb2RlbCAke2MubW9kZWx9KWBcblx0XHRcdFx0bG9nZ2VyLmluZm8oYEluZmVycmVkIGNtZF9pZD0ke3RvSGV4KGNtZF9pZCl9IGlkPSR7dG9IZXgoaWQpfSBmcm9tIE1vZGVsICR7Yy5tb2RlbH0gKGV4YWN0KWApXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gQ2hlY2sgaWYgdGhpcyBpZCBzaG91bGQgYmUgZGVmZXJyZWQgdG8gcGFzcyAyIFx1MjAxNFxuXHRcdC8vIGl0J3MgYSBzZXF1ZW50aWFsIGlkQWRkIG9mZnNldCBvZiBhIGtub3duIGNhbmRpZGF0ZSBiYXNlIGVudHJ5LlxuXHRcdGlmICghYWN0aW9uKSB7XG5cdFx0XHRsZXQgc2hvdWxkRGVmZXIgPSBmYWxzZVxuXHRcdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdFx0Y29uc3QgYmFzZUVudHJ5ID0gYy5jbWRTY2hlbWE/LmZpbmQoKGE6IGFueSkgPT4ge1xuXHRcdFx0XHRcdGlmIChhLmNtZF9pZCAhPT0gY21kX2lkKSByZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRjb25zdCBpZEFkZE9wdCA9IGEub3B0aW9ucz8uZmluZCgobzogYW55KSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0XHRcdGlmICghaWRBZGRPcHQ/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdGlmIChpZCA8PSBhLmlkKSByZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRjb25zdCBvZmZzZXQgPSBpZCAtIGEuaWRcblx0XHRcdFx0XHRjb25zdCBtYXhTZXEgPSBpZEFkZERlZmVyUmFuZ2VzLmdldChgJHtjbWRfaWR9XyR7YS5pZH1gKSA/PyAwXG5cdFx0XHRcdFx0cmV0dXJuIG9mZnNldCA8PSBtYXhTZXFcblx0XHRcdFx0fSlcblx0XHRcdFx0aWYgKGJhc2VFbnRyeSkge1xuXHRcdFx0XHRcdHNob3VsZERlZmVyID0gdHJ1ZVxuXHRcdFx0XHRcdGxvZ2dlci5kZWJ1Zyhcblx0XHRcdFx0XHRcdGBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gaXMgYW4gaWRBZGQgb2Zmc2V0IG9mIGNhbmRpZGF0ZSBiYXNlIGlkPSR7dG9IZXgoYmFzZUVudHJ5LmlkKX0gXHUyMDE0IGRlZmVycmluZyB0byBwYXNzIDJgLFxuXHRcdFx0XHRcdClcblx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRpZiAoc2hvdWxkRGVmZXIpIGNvbnRpbnVlXG5cdFx0fVxuXG5cdFx0Ly8gRmFsbGJhY2s6IHVua25vd24gc2V0dGluZ1xuXHRcdGlmICghYWN0aW9uKSB7XG5cdFx0XHRhY3Rpb24gPSB7XG5cdFx0XHRcdGNtZF9pZCxcblx0XHRcdFx0aWQsXG5cdFx0XHRcdG5hbWU6IGBVbmtub3duIGNtZDoke3RvSGV4KGNtZF9pZCl9IGlkOiR7dG9IZXgoaWQpLnRvVXBwZXJDYXNlKCl9YCxcblx0XHRcdFx0b3B0aW9uczogW3ZhbHVlQnl0ZXNUb09wdGlvbih2YWx1ZUJ5dGVzKV0sXG5cdFx0XHR9XG5cdFx0XHRpZiAoYnVzQ2ggIT09IHVuZGVmaW5lZCkgYWN0aW9uLmJ1c0NoID0gYnVzQ2hcblx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3QgaW5mZXIgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9YClcblx0XHR9IGVsc2Uge1xuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIEZpeCAxOiBidXNDaCBoYW5kbGluZyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRcdC8vIFN0cmlwIGFueSBpbmhlcml0ZWQgYnVzQ2ggb3B0aW9uIGZyb20gdGhlIGNhbmRpZGF0ZSBcdTIwMTQgd2UnbGwgcmUtZGVyaXZlXG5cdFx0XHQvLyBpdCBmcm9tIHdoYXQgdGhlIHBhY2tldCBhY3R1YWxseSByZXBvcnRlZCBmb3IgdGhpcyBkZXZpY2UuXG5cdFx0XHRhY3Rpb24ub3B0aW9ucyA9IGFjdGlvbi5vcHRpb25zPy5maWx0ZXIoKG8pID0+IG8uaWQgIT09ICdidXNDaCcpID8/IFtdXG5cdFx0XHRkZWxldGUgYWN0aW9uLmJ1c0NoXG5cblx0XHRcdGNvbnN0IHNlZW5CdXNDaFZhbHVlcyA9IGJ1c0NoU2Vlbi5nZXQoYCR7Y21kX2lkfV8ke2lkfWApXG5cdFx0XHRpZiAoc2VlbkJ1c0NoVmFsdWVzICYmIHNlZW5CdXNDaFZhbHVlcy5zaXplID4gMCkge1xuXHRcdFx0XHRjb25zdCBtYXhCdXNDaCA9IE1hdGgubWF4KC4uLnNlZW5CdXNDaFZhbHVlcylcblx0XHRcdFx0aWYgKG1heEJ1c0NoID09PSAwKSB7XG5cdFx0XHRcdFx0Ly8gT25seSBldmVyIHNhdyBidXNDaD0wIFx1MjE5MiBmaXhlZCBwcm9wZXJ0eSwgbm90IGFuIG9wdGlvblxuXHRcdFx0XHRcdGFjdGlvbi5idXNDaCA9IDBcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHQvLyBNdWx0aXBsZSBjaGFubmVscyBvYnNlcnZlZCBcdTIxOTIgc2VsZWN0YWJsZSBvcHRpb25cblx0XHRcdFx0XHRjb25zdCBidXNDaENob2ljZXMgPSBBcnJheS5mcm9tKHsgbGVuZ3RoOiBtYXhCdXNDaCArIDEgfSwgKF8sIGkpID0+ICh7XG5cdFx0XHRcdFx0XHRpZDogaSxcblx0XHRcdFx0XHRcdGxhYmVsOiBgQ2hhbm5lbCAke2kgKyAxfWAsXG5cdFx0XHRcdFx0fSkpXG5cdFx0XHRcdFx0YWN0aW9uLm9wdGlvbnMudW5zaGlmdCh7XG5cdFx0XHRcdFx0XHRpZDogJ2J1c0NoJyxcblx0XHRcdFx0XHRcdGxhYmVsOiAnQ2hhbm5lbCcsXG5cdFx0XHRcdFx0XHR0eXBlOiAnZHJvcGRvd24nLFxuXHRcdFx0XHRcdFx0Y2hvaWNlczogYnVzQ2hDaG9pY2VzLFxuXHRcdFx0XHRcdFx0ZGVmYXVsdDogMCxcblx0XHRcdFx0XHR9KVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBGaXggMjogZGVmYXVsdCBtdXN0IGV4aXN0IGluIGNob2ljZXMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHQvLyBTZXQgdGhlIGRlZmF1bHQgdG8gdGhlIG9ic2VydmVkIHZhbHVlLiBJZiB0aGF0IHZhbHVlIGlzbid0IGluIHRoZVxuXHRcdFx0Ly8gaW5oZXJpdGVkIGNob2ljZXMgbGlzdCwgdGhlIGNob2ljZXMgYXJlIGZyb20gYSBzdHJ1Y3R1cmFsbHkgZGlmZmVyZW50XG5cdFx0XHQvLyBtb2RlbCBhbmQgY2FuJ3QgYmUgdHJ1c3RlZCBcdTIwMTQgZGlzY2FyZCB0aGVtIGFuZCBmYWxsIGJhY2sgdG8gYSBwbGFpbiBudW1iZXIuXG5cdFx0XHRjb25zdCBvYnNlcnZlZERlZmF1bHQgPSB2YWx1ZUJ5dGVzVG9PcHRpb24odmFsdWVCeXRlcykuZGVmYXVsdFxuXHRcdFx0Y29uc3QgdmFsdWVPcHQgPSBhY3Rpb24ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ3ZhbHVlJylcblx0XHRcdGlmICh2YWx1ZU9wdCkge1xuXHRcdFx0XHRpZiAodmFsdWVPcHQuY2hvaWNlcyAmJiBBcnJheS5pc0FycmF5KHZhbHVlT3B0LmNob2ljZXMpKSB7XG5cdFx0XHRcdFx0Y29uc3QgaW5DaG9pY2VzID0gdmFsdWVPcHQuY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9ic2VydmVkRGVmYXVsdClcblx0XHRcdFx0XHRpZiAoIWluQ2hvaWNlcykge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLndhcm4oXG5cdFx0XHRcdFx0XHRcdGBJbmZlcnJlZCBjaG9pY2VzIGZvciBjbWRfaWQ9JHt0b0hleChjbWRfaWQpfSBpZD0ke3RvSGV4KGlkKX0gZG9uJ3QgY29udGFpbiBvYnNlcnZlZCB2YWx1ZSAke29ic2VydmVkRGVmYXVsdH0gXHUyMDE0IGRpc2NhcmRpbmcgaW5oZXJpdGVkIGNob2ljZXNgLFxuXHRcdFx0XHRcdFx0KVxuXHRcdFx0XHRcdFx0Ly8gS2VlcCBsYWJlbC90b29sdGlwIGJ1dCBkcm9wIGNob2ljZXMsIHN3aXRjaCB0byBwbGFpbiBudW1iZXJcblx0XHRcdFx0XHRcdHZhbHVlT3B0LnR5cGUgPSAnbnVtYmVyJ1xuXHRcdFx0XHRcdFx0ZGVsZXRlICh2YWx1ZU9wdCBhcyBhbnkpLmNob2ljZXNcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0dmFsdWVPcHQuZGVmYXVsdCA9IG9ic2VydmVkRGVmYXVsdFxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdG91dC5jbWRTY2hlbWEucHVzaChhY3Rpb24pXG5cdH1cblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFBBU1MgMjogZm9sZCBhbnkgZGVmZXJyZWQgaWRBZGQgb2Zmc2V0cyB3aG9zZSBiYXNlIGVudHJ5XG5cdC8vIGlzIG5vdyBwcmVzZW50IGluIHRoZSBvdXRwdXQgc2NoZW1hLlxuXHQvLyBHYXRlOiB0aGUgb2Zmc2V0IG11c3QgZWl0aGVyIGV4aXN0IGluIGEgcmVmZXJlbmNlIG1vZGVsJ3MgY2hvaWNlcyxcblx0Ly8gT1IgdGhlIGJhc2UgZW50cnkgaXRzZWxmIHdhcyBpbmZlcnJlZCAoaGFzIGlkQWRkKSBhbmQgdGhlIG9mZnNldFxuXHQvLyBjb250aW51ZXMgc2VxdWVudGlhbGx5IGJleW9uZCB0aGUgcmVmZXJlbmNlIG1vZGVsJ3Mga25vd24gcmFuZ2UuXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Zm9yIChjb25zdCB7IGNtZF9pZCwgaWQgfSBvZiBwYXJzZWQpIHtcblx0XHRjb25zdCBhbHJlYWR5VG9wTGV2ZWwgPSBvdXQuY21kU2NoZW1hLnNvbWUoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWQpXG5cdFx0aWYgKGFscmVhZHlUb3BMZXZlbCkgY29udGludWVcblxuXHRcdC8vIEZpbmQgYSBiYXNlIGVudHJ5IGluIHRoZSBvdXRwdXQgdGhhdCBoYXMgaWRBZGQgYW5kIHdob3NlIGlkIDwgdGhpcyBpZFxuXHRcdGNvbnN0IGlkQWRkQmFzZSA9IG91dC5jbWRTY2hlbWEuZmluZCgoYSkgPT4ge1xuXHRcdFx0aWYgKGEuY21kX2lkICE9PSBjbWRfaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0Y29uc3QgaWRBZGRPcHQgPSBhLm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICdpZEFkZCcpXG5cdFx0XHRyZXR1cm4gISFpZEFkZE9wdD8uY2hvaWNlcyAmJiBpZCA+IGEuaWRcblx0XHR9KVxuXHRcdGlmICghaWRBZGRCYXNlKSBjb250aW51ZVxuXG5cdFx0Y29uc3Qgb2Zmc2V0ID0gaWQgLSBpZEFkZEJhc2UuaWRcblx0XHRjb25zdCBpZEFkZE9wdCA9IGlkQWRkQmFzZS5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdGlmICghaWRBZGRPcHQ/LmNob2ljZXMgfHwgaWRBZGRPcHQuY2hvaWNlcy5zb21lKChjOiBhbnkpID0+IGMuaWQgPT09IG9mZnNldCkpIGNvbnRpbnVlXG5cblx0XHQvLyBBY2NlcHQgdGhlIGZvbGQgaWY6IGEgcmVmZXJlbmNlIG1vZGVsIGV4cGxpY2l0bHkgaGFzIHRoaXMgb2Zmc2V0LFxuXHRcdC8vIE9SIHRoZSBvZmZzZXRzIGFyZSBzdHJpY3RseSBzZXF1ZW50aWFsIGZyb20gMCAoZGV2aWNlIGhhcyBtb3JlIGNoYW5uZWxzIHRoYW4gcmVmZXJlbmNlKVxuXHRcdGNvbnN0IHJlZkhhc09mZnNldCA9IGNhbmRpZGF0ZXMuc29tZSgoYykgPT4ge1xuXHRcdFx0Y29uc3QgcmVmRW50cnkgPSBjLmNtZFNjaGVtYT8uZmluZCgocikgPT4gci5jbWRfaWQgPT09IGNtZF9pZCAmJiByLmlkID09PSBpZEFkZEJhc2UuaWQpXG5cdFx0XHRjb25zdCByZWZJZEFkZCA9IHJlZkVudHJ5Py5vcHRpb25zPy5maW5kKChvKSA9PiBvLmlkID09PSAnaWRBZGQnKVxuXHRcdFx0cmV0dXJuIHJlZklkQWRkPy5jaG9pY2VzPy5zb21lKChjaDogYW55KSA9PiBjaC5pZCA9PT0gb2Zmc2V0KVxuXHRcdH0pXG5cdFx0Y29uc3QgZXhpc3RpbmdPZmZzZXRzID0gaWRBZGRPcHQuY2hvaWNlcy5tYXAoKGM6IGFueSkgPT4gYy5pZCBhcyBudW1iZXIpLnNvcnQoKGEsIGIpID0+IGEgLSBiKVxuXHRcdGNvbnN0IGlzU2VxdWVudGlhbCA9IGV4aXN0aW5nT2Zmc2V0cy5sZW5ndGggPiAwICYmIG9mZnNldCA9PT0gZXhpc3RpbmdPZmZzZXRzW2V4aXN0aW5nT2Zmc2V0cy5sZW5ndGggLSAxXSArIDFcblxuXHRcdGlmICghcmVmSGFzT2Zmc2V0ICYmICFpc1NlcXVlbnRpYWwpIGNvbnRpbnVlXG5cblx0XHQvLyBJbmhlcml0IGxhYmVsIGZyb20gcmVmZXJlbmNlIG1vZGVsIGlmIGF2YWlsYWJsZSwgb3RoZXJ3aXNlIGdlbmVyYXRlIG9uZVxuXHRcdGxldCBsYWJlbCA9IGBDaGFubmVsICR7b2Zmc2V0ICsgMX1gXG5cdFx0Zm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRcdGNvbnN0IHJlZkVudHJ5ID0gYy5jbWRTY2hlbWE/LmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRfaWQgJiYgYS5pZCA9PT0gaWRBZGRCYXNlLmlkKVxuXHRcdFx0Y29uc3QgcmVmSWRBZGQgPSByZWZFbnRyeT8ub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdGNvbnN0IHJlZkNob2ljZSA9IHJlZklkQWRkPy5jaG9pY2VzPy5maW5kKChjaDogYW55KSA9PiBjaC5pZCA9PT0gb2Zmc2V0KVxuXHRcdFx0aWYgKHJlZkNob2ljZSkge1xuXHRcdFx0XHRsYWJlbCA9IHJlZkNob2ljZS5sYWJlbFxuXHRcdFx0XHRicmVha1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGlkQWRkT3B0LmNob2ljZXMucHVzaCh7IGlkOiBvZmZzZXQsIGxhYmVsIH0pXG5cdFx0bG9nZ2VyLmluZm8oXG5cdFx0XHRgUGFzcyAyOiBGb2xkZWQgY21kX2lkPSR7dG9IZXgoY21kX2lkKX0gaWQ9JHt0b0hleChpZCl9IGludG8gaWRBZGQgYmFzZSBpZD0ke3RvSGV4KGlkQWRkQmFzZS5pZCl9IGFzIG9mZnNldCAke29mZnNldH0gKFwiJHtsYWJlbH1cIilgLFxuXHRcdClcblx0fVxuXG5cdHJldHVybiBvdXRcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiAgU0FWRVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5leHBvcnQgZnVuY3Rpb24gc2F2ZU1vZGVsSnNvblByZXR0eShmaWxlUGF0aDogc3RyaW5nLCBqc29uT2JqOiBTdE1vZGVsSnNvbik6IHZvaWQge1xuXHR0cnkge1xuXHRcdC8vIEVuc3VyZSBwcm9wZXIga2V5IG9yZGVyaW5nOiBtb2RlbCwgdXNlQ29uTW9uIChpZiBwcmVzZW50KSwgY21kU2NoZW1hXG5cdFx0Y29uc3Qgb3JkZXJlZE9iajogYW55ID0geyBtb2RlbDoganNvbk9iai5tb2RlbCB9XG5cblx0XHQvLyBBZGQgdXNlQ29uTW9uIGtleSBpZiBwcmVzZW50IChyaWdodCBhZnRlciBtb2RlbClcblx0XHRpZiAoJ3VzZUNvbk1vbicgaW4ganNvbk9iaikge1xuXHRcdFx0b3JkZXJlZE9iai51c2VDb25Nb24gPSBqc29uT2JqLnVzZUNvbk1vblxuXHRcdH1cblxuXHRcdC8vIEFkZCBvdGhlciBrZXlzIGluIG9yZGVyXG5cdFx0aWYgKCdjbWRTY2hlbWEnIGluIGpzb25PYmopIHtcblx0XHRcdG9yZGVyZWRPYmouY21kU2NoZW1hID0ganNvbk9iai5jbWRTY2hlbWEubWFwKChlbnRyeTogYW55KSA9PiB7XG5cdFx0XHRcdC8vIEVuZm9yY2Uga2V5IG9yZGVyIHdpdGhpbiBlYWNoIHNjaGVtYSBlbnRyeTogY21kX2lkLCBpZCwgYnVzQ2gsIG5hbWUsIHZhbHVlLCBvcHRpb25zXG5cdFx0XHRcdGNvbnN0IG9yZGVyZWRFbnRyeTogYW55ID0ge31cblx0XHRcdFx0aWYgKCdjbWRfaWQnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkuY21kX2lkID0gZW50cnkuY21kX2lkXG5cdFx0XHRcdGlmICgnaWQnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkuaWQgPSBlbnRyeS5pZFxuXHRcdFx0XHRpZiAoJ2J1c0NoJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5LmJ1c0NoID0gZW50cnkuYnVzQ2hcblx0XHRcdFx0aWYgKCduYW1lJyBpbiBlbnRyeSkgb3JkZXJlZEVudHJ5Lm5hbWUgPSBlbnRyeS5uYW1lXG5cdFx0XHRcdGlmICgndmFsdWUnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkudmFsdWUgPSBlbnRyeS52YWx1ZVxuXHRcdFx0XHRpZiAoJ29wdGlvbnMnIGluIGVudHJ5KSBvcmRlcmVkRW50cnkub3B0aW9ucyA9IGVudHJ5Lm9wdGlvbnNcblx0XHRcdFx0Ly8gQ29weSBhbnkgcmVtYWluaW5nIGtleXNcblx0XHRcdFx0Zm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMoZW50cnkpKSB7XG5cdFx0XHRcdFx0aWYgKCEoa2V5IGluIG9yZGVyZWRFbnRyeSkpIG9yZGVyZWRFbnRyeVtrZXldID0gZW50cnlba2V5XVxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBvcmRlcmVkRW50cnlcblx0XHRcdH0pXG5cdFx0fVxuXHRcdC8vIENvcHkgYW55IG90aGVyIGtleXMgdGhhdCBtaWdodCBleGlzdFxuXHRcdGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGpzb25PYmopKSB7XG5cdFx0XHRpZiAoIShrZXkgaW4gb3JkZXJlZE9iaikpIHtcblx0XHRcdFx0b3JkZXJlZE9ialtrZXldID0gKGpzb25PYmogYXMgYW55KVtrZXldXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gQ3VzdG9tIGZvcm1hdHRlcjoga2VlcCBjaG9pY2Ugb2JqZWN0cyBjb21wYWN0IG9uIG9uZSBsaW5lXG5cdFx0bGV0IGpzb24gPSBKU09OLnN0cmluZ2lmeShvcmRlcmVkT2JqLCBudWxsLCAyKVxuXG5cdFx0Ly8gUmVwbGFjZSBleHBhbmRlZCBjaG9pY2Ugb2JqZWN0cyB3aXRoIGNvbXBhY3Qgc2luZ2xlLWxpbmUgZm9ybWF0XG5cdFx0Ly8gTWF0Y2hlczoge1xcbiAgICAgICAgICAgIFwiaWRcIjogWCxcXG4gICAgICAgICAgICBcImxhYmVsXCI6IFwiWVwiXFxuICAgICAgICAgIH1cblx0XHQvLyBSZXBsYWNlcyB3aXRoOiB7IFwiaWRcIjogWCwgXCJsYWJlbFwiOiBcIllcIiB9XG5cdFx0anNvbiA9IGpzb24ucmVwbGFjZSgvXFx7XFxuXFxzK1wiaWRcIjpcXHMqKFxcZCspLFxcblxccytcImxhYmVsXCI6XFxzKlwiKFteXCJdKilcIlxcblxccytcXH0vZywgJ3sgXCJpZFwiOiAkMSwgXCJsYWJlbFwiOiBcIiQyXCIgfScpXG5cblx0XHRmcy53cml0ZUZpbGVTeW5jKGZpbGVQYXRoLCBqc29uICsgJ1xcbicsICd1dGY4Jylcblx0fSBjYXRjaCAoZSkge1xuXHRcdGxvZ2dlci5lcnJvcihgRmlsZSBXcml0ZSBFcnJvcjogJHtlfWApXG5cdH1cbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgYnVpbGRGZWVkYmFja3MgfSBmcm9tICcuL2J1aWxkLWNvbW1hbmRzLmpzJ1xuaW1wb3J0IHsgZ2V0RGV2aWNlU2NoZW1hcyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgcGFyc2VTZXR0aW5nSWQsIGdldE5vcm1hbGl6ZWRTY2hlbWFzLCBmaW5kQWN0aW9uRm9yU2V0dGluZyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbi8qKlxuICogSGVscGVyIGZ1bmN0aW9uIHRvIGdldCBsYWJlbCBmcm9tIGNob2ljZXMgYmFzZWQgb24gdmFsdWVcbiAqL1xuZnVuY3Rpb24gZ2V0TGFiZWxGb3JWYWx1ZShcblx0c2NoZW1hczogUmVjb3JkPHN0cmluZywgeyBtb2RlbDogc3RyaW5nOyBjbWRTY2hlbWE6IGFueVtdIH0+LFxuXHRtb2RlbDogc3RyaW5nLFxuXHRjbWRJZDogbnVtYmVyLFxuXHRzZXR0aW5nSWQ6IG51bWJlcixcblx0dmFsdWU6IG51bWJlcixcbik6IHN0cmluZyB8IG51bWJlciB7XG5cdGNvbnN0IHNldHRpbmcgPSBmaW5kQWN0aW9uRm9yU2V0dGluZyhzY2hlbWFzLCBtb2RlbCwgY21kSWQsIHNldHRpbmdJZClcblx0aWYgKCFzZXR0aW5nIHx8ICFBcnJheS5pc0FycmF5KHNldHRpbmcub3B0aW9ucykpIHJldHVybiB2YWx1ZVxuXG5cdC8vIEZpbmQgdGhlICd2YWx1ZScgb3B0aW9uIHdoaWNoIGNvbnRhaW5zIHRoZSBjaG9pY2VzXG5cdGNvbnN0IHZhbHVlT3B0aW9uID0gc2V0dGluZy5vcHRpb25zLmZpbmQoKG9wdDogYW55KSA9PiBvcHQuaWQgPT09ICd2YWx1ZScpXG5cdGlmICghdmFsdWVPcHRpb24gfHwgIUFycmF5LmlzQXJyYXkodmFsdWVPcHRpb24uY2hvaWNlcykpIHJldHVybiB2YWx1ZVxuXG5cdC8vIEZpbmQgdGhlIGNob2ljZSB3aXRoIG1hdGNoaW5nIGlkXG5cdGNvbnN0IGNob2ljZSA9IHZhbHVlT3B0aW9uLmNob2ljZXMuZmluZCgoYzogYW55KSA9PiBjLmlkID09PSB2YWx1ZSlcblx0cmV0dXJuIGNob2ljZT8ubGFiZWwgPz8gdmFsdWVcbn1cblxuLyoqXG4gKiBCdWlsZCBhbmQgd2lyZSBDb21wYW5pb24gZmVlZGJhY2sgZGVmaW5pdGlvbnNcbiAqIFBhdHRlcm4gbWF0Y2hlcyBhY3Rpb25zLnRzIC0gZmlsdGVycyBieSBhY3RpdmUgbW9kZWwgYW5kIHdpcmVzIGNhbGxiYWNrc1xuICovXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlRmVlZGJhY2tzKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IHNjaGVtYXNSYXcgPSBnZXREZXZpY2VTY2hlbWFzKClcblx0Y29uc3QgcmF3RmVlZGJhY2tzID0gYnVpbGRGZWVkYmFja3MoKVxuXHRjb25zdCBzY2hlbWFzID0gZ2V0Tm9ybWFsaXplZFNjaGVtYXMoc2NoZW1hc1Jhdylcblx0Y29uc3Qgd2lyZWRGZWVkYmFja3M6IGFueSA9IHt9XG5cblx0Ly8gR2V0IHRoZSBhY3RpdmUgbW9kZWwgZnJvbSB0aGUgY2FjaGVkIHZhbHVlIHNldCBieSBzeW5jTW9kZWwoKVxuXHRjb25zdCBhY3RpdmVNb2RlbCA9IHNlbGYuYWN0aXZlTW9kZWxcblxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gXHUyNzA1IEJVSUxEIFBFUi1TRVRUSU5HIEZFRURCQUNLUyAoRklMVEVSRUQgQlkgQUNUSVZFIE1PREVMKVxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHRmb3IgKGNvbnN0IFtmZWVkYmFja0lkLCBmZWVkYmFja10gb2YgT2JqZWN0LmVudHJpZXMocmF3RmVlZGJhY2tzKSkge1xuXHRcdC8vIFN0cmlwIF9ib29sIHN1ZmZpeCBiZWZvcmUgcGFyc2luZyBzbyB0aGUgbW9kZWwvY21kSWQvYmFzZUlkIGFyZSBleHRyYWN0ZWQgY29ycmVjdGx5XG5cdFx0Y29uc3QgcGFyc2VJZCA9IGZlZWRiYWNrSWQuZW5kc1dpdGgoJ19ib29sJykgPyBmZWVkYmFja0lkLnNsaWNlKDAsIC01KSA6IGZlZWRiYWNrSWRcblx0XHRjb25zdCB7IG1vZGVsLCBjbWRJZCwgYmFzZUlkIH0gPSBwYXJzZVNldHRpbmdJZChwYXJzZUlkKVxuXG5cdFx0Ly8gT25seSBpbmNsdWRlIGZlZWRiYWNrcyBmb3IgdGhlIGN1cnJlbnRseSBhY3RpdmUgbW9kZWxcblx0XHRpZiAobW9kZWwgIT09IGFjdGl2ZU1vZGVsKSBjb250aW51ZVxuXG5cdFx0Ly8gVkFMVUUgRkVFREJBQ0s6IFJldHVybnMgY3VycmVudCB2YWx1ZSBmb3IgbG9jYWwgdmFyaWFibGVcblx0XHR3aXJlZEZlZWRiYWNrc1tmZWVkYmFja0lkXSA9IHtcblx0XHRcdC4uLmZlZWRiYWNrLFxuXHRcdFx0Y2FsbGJhY2s6IChmZWVkYmFja0V2ZW50OiBhbnkpID0+IHtcblx0XHRcdFx0Y29uc3QgaXAgPSBzZWxmLmhvc3Rcblx0XHRcdFx0Y29uc3QgaWRBZGQgPSBmZWVkYmFja0V2ZW50Lm9wdGlvbnNbJ2lkQWRkJ10gPz8gMFxuXHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBiYXNlSWQgKyBpZEFkZFxuXG5cdFx0XHRcdC8vIGJ1c0NoIGZyb20gb3B0aW9ucyB0YWtlcyBwcmlvcml0eTsgZmFsbCBiYWNrIHRvIGZpeGVkIGJ1c0NoIGluIHNjaGVtYVxuXHRcdFx0XHRsZXQgYnVzQ2ggPSBmZWVkYmFja0V2ZW50Lm9wdGlvbnNbJ2J1c0NoJ11cblx0XHRcdFx0aWYgKGJ1c0NoID09PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRjb25zdCBzY2hlbWFBY3Rpb24gPSBmaW5kQWN0aW9uRm9yU2V0dGluZyhzY2hlbWFzLCBtb2RlbCwgY21kSWQsIHNldHRpbmdJZClcblx0XHRcdFx0XHRpZiAoc2NoZW1hQWN0aW9uPy5idXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0XHRidXNDaCA9IHNjaGVtYUFjdGlvbi5idXNDaFxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHQvLyBMYXN0IHJlc29ydDogbG9vayB1cCBmaXhlZCBidXNDaCBkaXJlY3RseSBmcm9tIHRoZSByYXcgZGV2aWNlIHNjaGVtYSxcblx0XHRcdFx0Ly8gaW4gY2FzZSBnZXROb3JtYWxpemVkU2NoZW1hcygpIHN0cmlwcGVkIHRoZSBwcm9wZXJ0eSAoZS5nLiBNaWMgRWxlY3RyZXQgUG93ZXIpLlxuXHRcdFx0XHRpZiAoYnVzQ2ggPT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdGNvbnN0IHJhd0FjdGlvbiA9IHNjaGVtYXNSYXdbbW9kZWxdPy5jbWRTY2hlbWE/LmZpbmQoKGE6IGFueSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IHNldHRpbmdJZClcblx0XHRcdFx0XHRpZiAocmF3QWN0aW9uPy5idXNDaCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0XHRidXNDaCA9IHJhd0FjdGlvbi5idXNDaFxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXG5cdFx0XHRcdGNvbnN0IGN1cnJlbnQgPSBzZWxmLnN0Q29udHJvbGxlci5nZXRTZXR0aW5nVmFsdWUoaXAsIGNtZElkLCBzZXR0aW5nSWQsIGJ1c0NoKVxuXG5cdFx0XHRcdC8vIEJvb2xlYW4gZmVlZGJhY2tzOiBhbnkgbm9uLXplcm8gdmFsdWUgPSBhY3RpdmUgKHRydWUpLCB6ZXJvID0gaW5hY3RpdmUgKGZhbHNlKS5cblx0XHRcdFx0Ly8gVGhpcyB3b3JrcyBmb3IgYWxsIE9uL09mZiBzZXR0aW5ncyByZWdhcmRsZXNzIG9mIHdoYXQgdGhlIFwiT25cIiBJRCB2YWx1ZSBpc1xuXHRcdFx0XHQvLyBpbiB0aGUgc2NoZW1hIChlLmcuIE1pYyBFbGVjdHJldCBQb3dlciB1c2VzIDUgZm9yIE9uLCBub3QgMSkuXG5cdFx0XHRcdC8vIFJldHVybnMgYSByZWFsIGJvb2xlYW4gXHUyMDE0IHVzZWQgZm9yIGJ1dHRvbiBjb2xvcmluZyBvbmx5LCBub3QgdmFyaWFibGVzLlxuXHRcdFx0XHRpZiAoZmVlZGJhY2tJZC5lbmRzV2l0aCgnX2Jvb2wnKSkge1xuXHRcdFx0XHRcdHJldHVybiBjdXJyZW50ICE9PSB1bmRlZmluZWQgJiYgY3VycmVudCAhPT0gMFxuXHRcdFx0XHR9XG5cblx0XHRcdFx0Ly8gQ2hlY2sgaWYgdXNlciB3YW50cyBsYWJlbCBpbnN0ZWFkIG9mIG51bWVyaWMgdmFsdWVcblx0XHRcdFx0Y29uc3Qgc2hvd0xhYmVsID0gZmVlZGJhY2tFdmVudC5vcHRpb25zWydzaG93TGFiZWwnXSA/PyBmYWxzZVxuXG5cdFx0XHRcdGlmIChzaG93TGFiZWwgJiYgY3VycmVudCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0Y29uc3QgbGFiZWwgPSBnZXRMYWJlbEZvclZhbHVlKHNjaGVtYXMsIG1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkLCBjdXJyZW50KVxuXHRcdFx0XHRcdC8vIElmIG5vIGNob2ljZSBsYWJlbCB3YXMgZm91bmQgKHJldHVybmVkIGEgbnVtYmVyKSwgdGhlIHNldHRpbmcgaGFzIG5vXG5cdFx0XHRcdFx0Ly8gZGlzY3JldGUgY2hvaWNlcyBcdTIwMTQgdHJlYXQgaXQgYXMgYm9vbGVhbiBhbmQgc2hvdyB0cnVlL2ZhbHNlLlxuXHRcdFx0XHRcdGlmICh0eXBlb2YgbGFiZWwgPT09ICdudW1iZXInKSB7XG5cdFx0XHRcdFx0XHRyZXR1cm4gbGFiZWwgIT09IDAgPyAndHJ1ZScgOiAnZmFsc2UnXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdHJldHVybiBsYWJlbFxuXHRcdFx0XHR9XG5cblx0XHRcdFx0Ly8gUmV0dXJuIG51bWVyaWMgdmFsdWUgZGlyZWN0bHkgZm9yIGxvY2FsIHZhcmlhYmxlICh0eXBlOiAndmFsdWUnKVxuXHRcdFx0XHRyZXR1cm4gY3VycmVudCA/PyAwXG5cdFx0XHR9LFxuXHRcdH1cblx0fVxuXG5cdHNlbGYuc2V0RmVlZGJhY2tEZWZpbml0aW9ucyh3aXJlZEZlZWRiYWNrcylcbn1cbiIsICJpbXBvcnQgZGdyYW0gZnJvbSAnZGdyYW0nXG5pbXBvcnQgb3MgZnJvbSAnb3MnXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHtcblx0Q01EX0JVU19HRVQsXG5cdENNRF9CVVNfU0VULFxuXHRDTURfREVWX1NQRUMsXG5cdENNRF9HRVRfQUxMX1NFVFRJTkdTLFxuXHRDTURfR0VUX0ZJUk1XQVJFLFxuXHRDTURfR0xPQkFMX01JQ19LSUxMLFxuXHRDTURfTUlDX1BSRSxcblx0Q01EX01JQ19QUkVfQlVTLFxuXHRDTURfUkVTRVRfREVWSUNFLFxuXHRDTURfU0VUVElOR1NfUFVTSCxcblx0Z2V0Q29tbWFuZE5hbWUsXG5cdG1ha2VTZXR0aW5nSWQsXG5cdHRvSGV4LFxuXHRieXRlc1RvSGV4LFxuXHR0eXBlIERldmljZUluZm8sXG59IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQge1xuXHRwYXJzZUdldEFsbFNldHRpbmdzRm9yTW9kZWwsXG5cdHBhcnNlU2V0dGluZ3NSZXNwb25zZSxcblx0Zm9ybWF0UGFyc2VkU2V0dGluZyxcblx0dHlwZSBTdEFjdGlvbixcblx0dHlwZSBQYXJzZWRTZXR0aW5nLFxufSBmcm9tICcuL3NldHRpbmdzUGFyc2VyLmpzJ1xuaW1wb3J0IHsgZ2V0RGV2aWNlU2NoZW1hIH0gZnJvbSAnLi9jb25maWcuanMnXG5cbmltcG9ydCB7XG5cdERBTlRFX01TR19JTkZPX1JFU1BPTlNFLFxuXHRwYXJzZURhbnRlSW5mb1Jlc3BvbnNlLFxuXHRkaXNjb3ZlckRldmljZXMsXG5cdHByb2JlRGV2aWNlIGFzIGRhbnRlUHJvYmVEZXZpY2UsXG5cdGdldE1hY0ZvckRlc3RpbmF0aW9uLFxuXHRnZXRMb2NhbEFkZHJlc3NGb3JEZXN0aW5hdGlvbixcbn0gZnJvbSAnLi9kYW50ZS5qcydcbmltcG9ydCB7IG9wZW5Db25Nb25TZXNzaW9uIH0gZnJvbSAnLi9jb25tb24uanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignU3RDb250cm9sbGVyJylcblxuZXhwb3J0IGNsYXNzIFN0Q29udHJvbGxlciB7XG5cdHByaXZhdGUgcmVhZG9ubHkgZGVmYXVsdFBvcnQ6IG51bWJlciA9IDg3MDBcblx0cHJpdmF0ZSByZWFkb25seSBtdWx0aWNhc3RHcm91cCA9ICcyMjQuMC4wLjIzMSdcblx0cHJpdmF0ZSByZWFkb25seSByeFBvcnQgPSA4NzAyXG5cblx0cHJpdmF0ZSB0eFNvY2tldDogZGdyYW0uU29ja2V0XG5cdHByaXZhdGUgcnhTb2NrZXQ6IGRncmFtLlNvY2tldCAvLyBmb3IgcmVjZWl2aW5nIHJlc3BvbnNlcyAoODcwMilcblx0cHJpdmF0ZSByeE1jYXN0U29ja2V0OiBkZ3JhbS5Tb2NrZXQgfCBudWxsID0gbnVsbCAvLyBkaWFnbm9zdGljOiB0cmFja3Mgd2hpY2ggcmVzcG9uc2VzIGFycml2ZSB2aWEgbXVsdGljYXN0XG5cdHByaXZhdGUgbWNhc3REZWxpdmVyaWVzOiBTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKSAvLyBrZXlzIHNlZW4gb24gbXVsdGljYXN0IHNvY2tldCB0aGlzIGN5Y2xlXG5cdHByaXZhdGUgcGVuZGluZ0Fja3M6IE1hcDxcblx0XHRzdHJpbmcsXG5cdFx0eyByZXNvbHZlOiAoYnVmOiBCdWZmZXIpID0+IHZvaWQ7IHJlamVjdDogKGU6IEVycm9yKSA9PiB2b2lkOyB0aW1lcjogTm9kZUpTLlRpbWVvdXQgfVxuXHQ+ID0gbmV3IE1hcCgpXG5cdHByaXZhdGUgam9pbmVkSW50ZXJmYWNlczogU2V0PHN0cmluZz4gPSBuZXcgU2V0KCkgLy8gbG9jYWwgSVBzIHdlJ3ZlIGpvaW5lZCBtdWx0aWNhc3Qgb25cblxuXHQvKiogU2VyaWFsaXplcyBvdXRnb2luZyBjb21tYW5kcyBzbyBlYWNoIHdhaXRzIGZvciBBQ0sgYmVmb3JlIHRoZSBuZXh0IGlzIHNlbnQgKi9cblx0cHJpdmF0ZSBzZW5kUXVldWU6IFByb21pc2U8dm9pZD4gPSBQcm9taXNlLnJlc29sdmUoKVxuXG5cdC8qKiBUcmFja3MgaG93IG1hbnkgY29tbWFuZHMgYXJlIHF1ZXVlZC9pbi1mbGlnaHQsIHRvIGRlZmVyIHJlcXVlc3RBbGxTZXR0aW5ncyAqL1xuXHRwcml2YXRlIHBlbmRpbmdDb21tYW5kQ291bnQgPSAwXG5cblx0LyoqIFJlc29sdmVzIG9uY2UgdHhTb2NrZXQgaXMgYm91bmQgYW5kIHJlYWR5IHRvIHNlbmQgKi9cblx0cHJpdmF0ZSB0eFJlYWR5OiBQcm9taXNlPHZvaWQ+XG5cblx0LyoqIEFjdGl2ZSBkZXZpY2UgbW9kZWwgYW5kIGFjdGlvbiBkZWZpbml0aW9ucyBmb3Igc2V0dGluZ3MgZGVjb2RpbmcgKi9cblx0cHJpdmF0ZSBtb2RlbDogc3RyaW5nID0gJydcblx0cHJpdmF0ZSBhY3Rpb25zOiBTdEFjdGlvbltdID0gW11cblxuXHQvKipcblx0ICogS25vd24gc3RhdGUgb2YgZXZlcnkgc2V0dGluZyBwZXIgZGV2aWNlIElQLlxuXHQgKiBLZXllZCBieSBJUCBcdTIxOTIgTWFwIG9mIFwiJHtjbWRJZH0vJHtzZXR0aW5nSWR9XCIgXHUyMTkyIGN1cnJlbnQgdmFsdWUgYnl0ZS5cblx0ICogUG9wdWxhdGVkIG9uIGNvbm5lY3QgdmlhIHJlcXVlc3RBbGxTZXR0aW5ncygpLCB1cGRhdGVkIG9uIGV2ZXJ5IENNRF9TRVRUSU5HU19QVVNIICgweDBiKS5cblx0ICogVXNlZCB0byBkaWZmIGluY29taW5nIHB1c2hlcyAoY2hhbmdlZCA9IGluZm8sIHVuY2hhbmdlZCA9IGRlYnVnKSBhbmQgZm9yIGZlZWRiYWNrcy5cblx0ICovXG5cdHByaXZhdGUgZGV2aWNlU3RhdGU6IE1hcDxzdHJpbmcsIE1hcDxzdHJpbmcsIG51bWJlcj4+ID0gbmV3IE1hcCgpXG5cblx0LyoqXG5cdCAqIElQcyB0aGF0IGhhdmUgYmVlbiB2ZXJpZmllZCBhZ2FpbnN0IHRoZSBjb25maWd1cmVkIG1vZGVsIGFuZCBhcmUgYWxsb3dlZFxuXHQgKiB0byByZWNlaXZlIFN0dWRpby1UIGNvbW1hbmRzLiBQb3B1bGF0ZWQgYnkgYXV0aG9yaXplRGV2aWNlKCkgYWZ0ZXIgYVxuXHQgKiBzdWNjZXNzZnVsIHByb2JlRGV2aWNlKCkgbW9kZWwgbWF0Y2gsIG9yIGFmdGVyIG11bHRpY2FzdCBkaXNjb3ZlcnkuXG5cdCAqIF9zZW5kQXdhaXRBY2soKSByZWplY3RzIGFueSBkZXN0SXAgbm90IGluIHRoaXMgc2V0LlxuXHQgKi9cblx0cHJpdmF0ZSBhdXRob3JpemVkSXBzOiBTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKVxuXG5cdC8qKiBDYWxsYmFja3MgcmVnaXN0ZXJlZCBmb3IgRGFudGUgMHgwMTcwIGRldmljZSBpbmZvIHJlc3BvbnNlcyBcdTIwMTQga2V5ZWQgYnkgdXNhZ2UgKi9cblx0cHJpdmF0ZSBkaXNjb3ZlcnlMaXN0ZW5lcnM6IE1hcDxzdHJpbmcsIChkZXZpY2U6IERldmljZUluZm8pID0+IHZvaWQ+ID0gbmV3IE1hcCgpXG5cblx0LyoqIENhbGxiYWNrIHRvIHRyaWdnZXIgZmVlZGJhY2sgdXBkYXRlcyB3aGVuIHN0YXRlIGNoYW5nZXMgKi9cblx0cHJpdmF0ZSBmZWVkYmFja0NhbGxiYWNrPzogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZFxuXG5cdC8qKiBDYWNoZSBvZiBsb2NhbCBpbnRlcmZhY2UgTUFDIGJ5dGVzIHBlciBkZXN0aW5hdGlvbiBJUCwgdG8gYXZvaWQgcmVwZWF0ZWQgT1MgbG9va3VwcyAqL1xuXHRwcml2YXRlIG1hY0NhY2hlOiBNYXA8c3RyaW5nLCBudW1iZXJbXT4gPSBuZXcgTWFwKClcblxuXHQvKiogVHJhY2tzIHNlc3Npb24gcmVhZGluZXNzIHBlciBJUCBcdTIwMTQgc2V0IGZvciBkZXZpY2VzIHRoYXQgZXN0YWJsaXNoZWQgQ29uTW9uLCBhbmQgYWxzb1xuXHQgKiAgZm9yIGRldmljZXMgdGhhdCBkb24ndCByZXF1aXJlIENvbk1vbiAodXNlQ29uTW9uIG5vdCBzZXQpLCBzbyB0aGUgY2hlY2sgaXMgb25seSBkb25lIG9uY2UuICovXG5cdHByaXZhdGUgc2Vzc2lvbkVzdGFibGlzaGVkOiBTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKVxuXG5cdC8qKiBDbGVhbnVwIGZ1bmN0aW9ucyByZXR1cm5lZCBieSBvcGVuQ29uTW9uU2Vzc2lvbigpIFx1MjAxNCBjYWxsIHRvIHN0b3Aga2VlcGFsaXZlcyBhbmQgY2xvc2UgdGhlIHNvY2tldCAqL1xuXHRwcml2YXRlIF9jb25tb25DbGVhbnVwczogTWFwPHN0cmluZywgKCkgPT4gdm9pZD4gPSBuZXcgTWFwKClcblxuXHRjb25zdHJ1Y3RvcigpIHtcblx0XHRsb2dnZXIuaW5mbygnU3RDb250cm9sbGVyIGluaXRpYWxpemVkJylcblxuXHRcdC8vIFNlbmQgc29ja2V0IFx1MjAxNCBiaW5kIHRvIGVwaGVtZXJhbCBwb3J0LiBSZXNwb25zZXMgYWx3YXlzIGdvIHRvIHJ4U29ja2V0IG9uXG5cdFx0Ly8gcG9ydCA4NzAyIChEYW50ZSBoYXJkY29kZXMgdGhlIHJlc3BvbnNlIGRlc3RpbmF0aW9uIHBvcnQgdG8gODcwMikuXG5cdFx0dGhpcy50eFNvY2tldCA9IGRncmFtLmNyZWF0ZVNvY2tldCh7IHR5cGU6ICd1ZHA0JywgcmV1c2VBZGRyOiB0cnVlIH0pXG5cdFx0dGhpcy50eFJlYWR5ID0gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUpID0+IHtcblx0XHRcdHRoaXMudHhTb2NrZXQuYmluZCgwLCAoKSA9PiB7XG5cdFx0XHRcdGxvZ2dlci5kZWJ1ZyhgVFggc29ja2V0IGJvdW5kIHRvIHBvcnQgJHsodGhpcy50eFNvY2tldC5hZGRyZXNzKCkgYXMgeyBwb3J0OiBudW1iZXIgfSkucG9ydH1gKVxuXHRcdFx0XHRyZXNvbHZlKClcblx0XHRcdH0pXG5cdFx0fSlcblx0XHR0aGlzLnR4U29ja2V0Lm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGxvZ2dlci5lcnJvcihgVFggc29ja2V0IGVycm9yOiAke2Vycn1gKVxuXHRcdH0pXG5cblx0XHQvLyBSZWNlaXZlIHNvY2tldCAtIGJpbmQgdG8gYWxsIGFkZHJlc3NlcyBzbyBrZXJuZWwgY2FuIGRlbGl2ZXIgbXVsdGljYXN0IHBhY2tldHNcblx0XHR0aGlzLnJ4U29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblxuXHRcdHRoaXMucnhTb2NrZXQub24oJ2xpc3RlbmluZycsICgpID0+IHtcblx0XHRcdGNvbnN0IGFkZHIgPSB0aGlzLnJ4U29ja2V0LmFkZHJlc3MoKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCBzb2NrZXQgbGlzdGVuaW5nIG9uICR7SlNPTi5zdHJpbmdpZnkoYWRkcil9YClcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHRoaXMucnhTb2NrZXQuc2V0TXVsdGljYXN0TG9vcGJhY2sodHJ1ZSlcblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdH0pXG5cblx0XHR0aGlzLnJ4U29ja2V0Lm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGxvZ2dlci5lcnJvcihgUlggc29ja2V0IGVycm9yOiAke2Vycn1gKVxuXHRcdH0pXG5cblx0XHR0aGlzLnJ4U29ja2V0Lm9uKCdtZXNzYWdlJywgKG1zZywgcmluZm8pID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHRoaXMuaGFuZGxlSW5jb21pbmcobXNnLCByaW5mby5hZGRyZXNzKVxuXHRcdFx0fSBjYXRjaCAoX2UpIHtcblx0XHRcdFx0bG9nZ2VyLmVycm9yKGBFcnJvciBoYW5kbGluZyBpbmNvbWluZyBtZXNzYWdlOiAke19lfWApXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdC8vIEJpbmQgdG8gd2lsZGNhcmQgc28ga2VybmVsIGNhbiBkZWxpdmVyIG11bHRpY2FzdCBwYWNrZXRzIGZvciBqb2luZWQgaW50ZXJmYWNlcy5cblx0XHQvLyBBZnRlciBiaW5kaW5nLCBlYWdlcmx5IGpvaW4gMjI0LjAuMC4yMzEgb24gZXZlcnkgbm9uLWxvb3BiYWNrIElQdjQgaW50ZXJmYWNlIHNvXG5cdFx0Ly8gdGhhdCB1bnNvbGljaXRlZCBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikgcGFja2V0cyBhcmUgbm90IG1pc3NlZCBiZWZvcmUgdGhlXG5cdFx0Ly8gZmlyc3Qgb3V0Z29pbmcgY29tbWFuZCB0cmlnZ2VycyB0aGUgbGF6eSBlbnN1cmVNZW1iZXJzaGlwRm9yKCkgam9pbi5cblx0XHR0aGlzLnJ4U29ja2V0LmJpbmQoeyBhZGRyZXNzOiAnMC4wLjAuMCcsIHBvcnQ6IHRoaXMucnhQb3J0IH0sICgpID0+IHtcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgUlggc29ja2V0IGJvdW5kIHRvIDAuMC4wLjA6JHt0aGlzLnJ4UG9ydH1gKVxuXHRcdFx0Y29uc3QgaWZhY2VzID0gb3MubmV0d29ya0ludGVyZmFjZXMoKSBhcyBSZWNvcmQ8c3RyaW5nLCBpbXBvcnQoJ29zJykuTmV0d29ya0ludGVyZmFjZUluZm9bXT5cblx0XHRcdGZvciAoY29uc3QgYWRkcnMgb2YgT2JqZWN0LnZhbHVlcyhpZmFjZXMpKSB7XG5cdFx0XHRcdGZvciAoY29uc3QgYWRkciBvZiBhZGRycyA/PyBbXSkge1xuXHRcdFx0XHRcdGlmIChhZGRyLmZhbWlseSA9PT0gJ0lQdjQnICYmICFhZGRyLmludGVybmFsICYmICF0aGlzLmpvaW5lZEludGVyZmFjZXMuaGFzKGFkZHIuYWRkcmVzcykpIHtcblx0XHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRcdHRoaXMucnhTb2NrZXQuYWRkTWVtYmVyc2hpcCh0aGlzLm11bHRpY2FzdEdyb3VwLCBhZGRyLmFkZHJlc3MpXG5cdFx0XHRcdFx0XHRcdHRoaXMuam9pbmVkSW50ZXJmYWNlcy5hZGQoYWRkci5hZGRyZXNzKVxuXHRcdFx0XHRcdFx0XHRsb2dnZXIuZGVidWcoYFByZS1qb2luZWQgbXVsdGljYXN0ICR7dGhpcy5tdWx0aWNhc3RHcm91cH0gb24gJHthZGRyLmFkZHJlc3N9YClcblx0XHRcdFx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3QgcHJlLWpvaW4gbXVsdGljYXN0IG9uICR7YWRkci5hZGRyZXNzfTogJHtTdHJpbmcoX2UpfWApXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdC8vIERpYWdub3N0aWMgbXVsdGljYXN0IHNvY2tldCBcdTIwMTQgYm91bmQgdG8gdGhlIG11bHRpY2FzdCBncm91cCBhZGRyZXNzIHNvIG9ubHlcblx0XHQvLyBtdWx0aWNhc3QtZGVsaXZlcmVkIHBhY2tldHMgYXJyaXZlIGhlcmUuIEFueSBTdHVkaW8tVCByZXNwb25zZSBzZWVuIG9uIHRoaXNcblx0XHQvLyBzb2NrZXQgd2FzIHNlbnQgdG8gMjI0LjAuMC4yMzE7IHJlc3BvbnNlcyBzZWVuIG9ubHkgb24gcnhTb2NrZXQgYXJlIHVuaWNhc3QuXG5cdFx0dGhpcy5yeE1jYXN0U29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblx0XHR0aGlzLnJ4TWNhc3RTb2NrZXQub24oJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCBtY2FzdCBzb2NrZXQgZXJyb3I6ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHR9KVxuXHRcdHRoaXMucnhNY2FzdFNvY2tldC5vbignbWVzc2FnZScsIChtc2c6IEJ1ZmZlciwgcmluZm86IGRncmFtLlJlbW90ZUluZm8pID0+IHtcblx0XHRcdGlmIChtc2cubGVuZ3RoIDwgMjUpIHJldHVyblxuXHRcdFx0aWYgKG1zZ1swXSAhPT0gMHhmZiB8fCBtc2dbMV0gIT09IDB4ZmYpIHJldHVyblxuXHRcdFx0Y29uc3Qgc2lnID0gbXNnLnN1YmFycmF5KDE2LCAyNClcblx0XHRcdGlmIChzaWcudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdTdHVkaW8tVCcpIHJldHVyblxuXHRcdFx0Y29uc3Qgc3RQYXlsb2FkID0gbXNnLnN1YmFycmF5KDI0KVxuXHRcdFx0aWYgKHN0UGF5bG9hZC5sZW5ndGggPCAyIHx8IHN0UGF5bG9hZFswXSAhPT0gMHg1YSkgcmV0dXJuXG5cdFx0XHRjb25zdCByZXNwQ21kSWQgPSBzdFBheWxvYWRbMV1cblx0XHRcdGNvbnN0IGlzUmVzcG9uc2UgPSAocmVzcENtZElkICYgMHg4MCkgIT09IDBcblx0XHRcdGNvbnN0IG9yaWdpbmFsQ21kSWQgPSByZXNwQ21kSWQgJiAweDdmXG5cdFx0XHRpZiAoaXNSZXNwb25zZSkge1xuXHRcdFx0XHRjb25zdCBrZXkgPSBgJHtyaW5mby5hZGRyZXNzfToke29yaWdpbmFsQ21kSWR9YFxuXHRcdFx0XHRjb25zdCB3YXNVbmljYXN0QWxyZWFkeSA9ICF0aGlzLm1jYXN0RGVsaXZlcmllcy5oYXMoa2V5KVxuXHRcdFx0XHR0aGlzLm1jYXN0RGVsaXZlcmllcy5hZGQoa2V5KVxuXHRcdFx0XHRsb2dnZXIuZGVidWcoXG5cdFx0XHRcdFx0YE11bHRpY2FzdCBkZWxpdmVyeTogJHtyaW5mby5hZGRyZXNzfSBjbWQ6JHt0b0hleChvcmlnaW5hbENtZElkKX1gICtcblx0XHRcdFx0XHRcdCh3YXNVbmljYXN0QWxyZWFkeSA/ICcgKHVuaWNhc3QgYWxzbyBwZW5kaW5nKScgOiAnIChtdWx0aWNhc3Qgb25seSBzbyBmYXIpJyksXG5cdFx0XHRcdClcblx0XHRcdFx0Ly8gQ2xlYW4gdXAgdGhlIGtleSBhZnRlciBhIHNob3J0IGRlbGF5IHNvIHdlIGRvbid0IGFjY3VtdWxhdGUgc3RhbGUgZW50cmllc1xuXHRcdFx0XHRzZXRUaW1lb3V0KCgpID0+IHRoaXMubWNhc3REZWxpdmVyaWVzLmRlbGV0ZShrZXkpLCA1MDApXG5cdFx0XHR9XG5cdFx0fSlcblx0XHR0aGlzLnJ4TWNhc3RTb2NrZXQuYmluZCh7IGFkZHJlc3M6IHRoaXMubXVsdGljYXN0R3JvdXAsIHBvcnQ6IHRoaXMucnhQb3J0IH0sICgpID0+IHtcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgUlggbWNhc3Qgc29ja2V0IGJvdW5kIHRvICR7dGhpcy5tdWx0aWNhc3RHcm91cH06JHt0aGlzLnJ4UG9ydH1gKVxuXHRcdH0pXG5cdH1cblxuXHRwdWJsaWMgY2xvc2UoKTogdm9pZCB7XG5cdFx0Ly8gU3RvcCBhbGwgQ29uTW9uIGtlZXBhbGl2ZXMgYW5kIGNsb3NlIHRoZWlyIHNvY2tldHMgYmVmb3JlIGNsb3NpbmcgdGhlIG1haW4gc29ja2V0c1xuXHRcdGZvciAoY29uc3QgY2xlYW51cCBvZiB0aGlzLl9jb25tb25DbGVhbnVwcy52YWx1ZXMoKSkge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y2xlYW51cCgpXG5cdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0LyogaWdub3JlICovXG5cdFx0XHR9XG5cdFx0fVxuXHRcdHRoaXMuX2Nvbm1vbkNsZWFudXBzLmNsZWFyKClcblx0XHR0cnkge1xuXHRcdFx0Zm9yIChjb25zdCBsb2NhbEFkZHIgb2YgQXJyYXkuZnJvbSh0aGlzLmpvaW5lZEludGVyZmFjZXMpKSB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0dGhpcy5yeFNvY2tldC5kcm9wTWVtYmVyc2hpcCh0aGlzLm11bHRpY2FzdEdyb3VwLCBsb2NhbEFkZHIpXG5cdFx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdFx0dHJ5IHtcblx0XHRcdHRoaXMucnhNY2FzdFNvY2tldD8uY2xvc2UoKVxuXHRcdFx0dGhpcy5yeE1jYXN0U29ja2V0ID0gbnVsbFxuXHRcdH0gY2F0Y2gge1xuXHRcdFx0LyogaWdub3JlICovXG5cdFx0fVxuXHRcdHRyeSB7XG5cdFx0XHR0aGlzLnJ4U29ja2V0LmNsb3NlKClcblx0XHR9IGNhdGNoIHtcblx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdH1cblx0XHR0cnkge1xuXHRcdFx0dGhpcy50eFNvY2tldC5jbG9zZSgpXG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvKiBpZ25vcmUgKi9cblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogUHJvdmlkZSB0aGUgYWN0aXZlIGRldmljZSBtb2RlbCBhbmQgYWN0aW9uIGRlZmluaXRpb25zIHNvIGluY29taW5nIG1lc3NhZ2VzXG5cdCAqIGNhbiBiZSBkZWNvZGVkIGludG8gaHVtYW4tcmVhZGFibGUgbmFtZXMuIENhbGwgZnJvbSBtYWluLnRzIGFmdGVyIGNvbmZpZyBsb2FkLlxuXHQgKi9cblx0cHVibGljIHNldE1vZGVsKG1vZGVsOiBzdHJpbmcsIGFjdGlvbnM6IFN0QWN0aW9uW10pOiB2b2lkIHtcblx0XHR0aGlzLm1vZGVsID0gbW9kZWxcblx0XHR0aGlzLmFjdGlvbnMgPSBhY3Rpb25zXG5cdH1cblxuXHQvKipcblx0ICogU2V0IGNhbGxiYWNrIHRvIHRyaWdnZXIgd2hlbiBkZXZpY2Ugc3RhdGUgY2hhbmdlcyAoZm9yIGZlZWRiYWNrcykuXG5cdCAqIENhbGwgZnJvbSBtYWluLnRzIHRvIHdpcmUgdXAgY2hlY2tGZWVkYmFja3MuXG5cdCAqL1xuXHRwdWJsaWMgc2V0RmVlZGJhY2tDYWxsYmFjayhjYWxsYmFjazogKGZlZWRiYWNrSWQ6IHN0cmluZykgPT4gdm9pZCk6IHZvaWQge1xuXHRcdHRoaXMuZmVlZGJhY2tDYWxsYmFjayA9IGNhbGxiYWNrXG5cdH1cblxuXHQvKiogUmV0dXJucyB0cnVlIGlmIHRoZSBkZXZpY2UgYXQgdGhlIGdpdmVuIElQIGhhcyBiZWVuIGF1dGhvcml6ZWQgdG8gcmVjZWl2ZSBjb21tYW5kcy4gKi9cblx0cHVibGljIGlzRGV2aWNlQXV0aG9yaXplZChpcDogc3RyaW5nKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuYXV0aG9yaXplZElwcy5oYXMoaXApXG5cdH1cblxuXHQvKiogTWFyayBhbiBJUCBhcyB2ZXJpZmllZCBhbmQgYWxsb3dlZCB0byByZWNlaXZlIFN0dWRpby1UIGNvbW1hbmRzLiAqL1xuXHRwdWJsaWMgYXV0aG9yaXplRGV2aWNlKGlwOiBzdHJpbmcpOiB2b2lkIHtcblx0XHR0aGlzLmF1dGhvcml6ZWRJcHMuYWRkKGlwKVxuXHRcdGxvZ2dlci5kZWJ1ZyhgQXV0aG9yaXplZCBkZXZpY2UgYXQgJHtpcH1gKVxuXHR9XG5cblx0LyoqIFJlbW92ZSBhdXRob3JpemF0aW9uIGZvciBhbiBJUCAoZS5nLiBvbiBjb25maWcgY2hhbmdlIG9yIG1vZGVsIG1pc21hdGNoKS4gKi9cblx0cHVibGljIHJldm9rZURldmljZShpcDogc3RyaW5nKTogdm9pZCB7XG5cdFx0dGhpcy5hdXRob3JpemVkSXBzLmRlbGV0ZShpcClcblx0XHR0aGlzLmRldmljZVN0YXRlLmRlbGV0ZShpcClcblx0XHR0aGlzLm1hY0NhY2hlLmRlbGV0ZShpcClcblx0XHR0aGlzLnNlc3Npb25Fc3RhYmxpc2hlZC5kZWxldGUoaXApXG5cdFx0dGhpcy5fY29ubW9uQ2xlYW51cHMuZ2V0KGlwKT8uKClcblx0XHR0aGlzLl9jb25tb25DbGVhbnVwcy5kZWxldGUoaXApXG5cdFx0bG9nZ2VyLmRlYnVnKGBSZXZva2VkIGRldmljZSBhdCAke2lwfWApXG5cdH1cblxuXHQvKipcblx0ICogT3BlbnMgYSBEYW50ZSBDb25Nb24gc2Vzc2lvbiBmb3IgdGhlIGRldmljZSBpZiBcInVzZUNvbk1vblwiOiB0cnVlIGlzIHNldCBpbiBpdHNcblx0ICogZGV2aWNlIEpTT04uIENhY2hlcyB0aGUgcmVzdWx0IHNvIHRoZSBoYW5kc2hha2Ugb25seSBydW5zIG9uY2UgcGVyIElQLlxuXHQgKiBEZWxlZ2F0ZXMgdG8gY29ubW9uLnRzLiBEZXZpY2VzIHdpdGhvdXQgdXNlQ29uTW9uIGFyZSBtYXJrZWQgYXMgcmVhZHkgaW1tZWRpYXRlbHkuXG5cdCAqL1xuXHRwdWJsaWMgYXN5bmMgb3BlblNlc3Npb24oZGV2aWNlSXA6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xuXHRcdGlmICh0aGlzLnNlc3Npb25Fc3RhYmxpc2hlZC5oYXMoZGV2aWNlSXApKSByZXR1cm4gdHJ1ZVxuXHRcdGNvbnN0IHNjaGVtYSA9IGdldERldmljZVNjaGVtYSh0aGlzLm1vZGVsKVxuXHRcdGlmICghc2NoZW1hPy51c2VDb25Nb24pIHtcblx0XHRcdC8vIERldmljZSBkb2VzIG5vdCByZXF1aXJlIENvbk1vbiBcdTIwMTQgc2tpcCBzaWxlbnRseVxuXHRcdFx0dGhpcy5zZXNzaW9uRXN0YWJsaXNoZWQuYWRkKGRldmljZUlwKVxuXHRcdFx0cmV0dXJuIHRydWVcblx0XHR9XG5cdFx0Y29uc3QgY2xlYW51cCA9IGF3YWl0IG9wZW5Db25Nb25TZXNzaW9uKGRldmljZUlwKVxuXHRcdGNvbnN0IHN1Y2Nlc3MgPSBjbGVhbnVwICE9PSBudWxsXG5cdFx0Ly8gTWFyayBhcyBhdHRlbXB0ZWQgcmVnYXJkbGVzcyBvZiBvdXRjb21lIFx1MjAxNCByZXRyeWluZyBpbW1lZGlhdGVseSB3b3VsZCBoaXQgdGhlXG5cdFx0Ly8gc2FtZSBiaW5kIGVycm9yIChFQUREUklOVVNFKS4gRGV2aWNlcyB0aGF0IGRvbid0IG5lZWQgQ29uTW9uIHdvcmsgZmluZSB3aXRob3V0IGl0LlxuXHRcdHRoaXMuc2Vzc2lvbkVzdGFibGlzaGVkLmFkZChkZXZpY2VJcClcblx0XHRpZiAoc3VjY2Vzcykge1xuXHRcdFx0dGhpcy5fY29ubW9uQ2xlYW51cHMuc2V0KGRldmljZUlwLCBjbGVhbnVwKVxuXHRcdH1cblx0XHRyZXR1cm4gc3VjY2Vzc1xuXHR9XG5cblx0LyoqXG5cdCAqIFNlbmRzIGEgdW5pY2FzdCBEYW50ZSBpbmZvIHJlcXVlc3QgdG8gYSBzcGVjaWZpYyBJUCBhbmQgd2FpdHMgZm9yIHRoZVxuXHQgKiBkZXZpY2UgaW5mbyByZXNwb25zZS4gUmV0dXJucyB0aGUgRGV2aWNlSW5mbyBpZiB0aGUgZGV2aWNlIHJlc3BvbmRzIHdpdGhpblxuXHQgKiB0aW1lb3V0TXMsIG9yIG51bGwgaWYgbm8gcmVzcG9uc2UuIFVzZWQgdG8gdmVyaWZ5IGEgbWFudWFsbHkgY29uZmlndXJlZCBJUC5cblx0ICogRG9lcyBOT1QgcmVxdWlyZSBhdXRob3JpemF0aW9uIFx1MjAxNCB0aGlzIGlzIGhvdyBhdXRob3JpemF0aW9uIGlzIGVzdGFibGlzaGVkLlxuXHQgKi9cblx0cHVibGljIGFzeW5jIHByb2JlRGV2aWNlKGlwOiBzdHJpbmcsIHRpbWVvdXRNcyA9IDMwMDApOiBQcm9taXNlPERldmljZUluZm8gfCBudWxsPiB7XG5cdFx0YXdhaXQgdGhpcy50eFJlYWR5XG5cdFx0cmV0dXJuIGRhbnRlUHJvYmVEZXZpY2UoXG5cdFx0XHR0aGlzLnR4U29ja2V0LFxuXHRcdFx0KGtleSwgY2IpID0+IHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNldChrZXksIGNiKSxcblx0XHRcdChrZXkpID0+IHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLmRlbGV0ZShrZXkpLFxuXHRcdFx0YXN5bmMgKGRlc3RJcCkgPT4gdGhpcy5lbnN1cmVNZW1iZXJzaGlwRm9yKGRlc3RJcCksXG5cdFx0XHRpcCxcblx0XHRcdHRpbWVvdXRNcyxcblx0XHQpXG5cdH1cblxuXHQvKipcblx0ICogU2VuZCBhIENNRF9HRVRfQUxMX1NFVFRJTkdTICgweDBhKSByZXF1ZXN0IHRvIHRoZSBkZXZpY2UgYW5kIHN0b3JlIHRoZSByZXNwb25zZVxuXHQgKiBpbiBkZXZpY2VTdGF0ZS4gUmV0dXJucyB0aGUgcmF3IHJlc3BvbnNlIGJ1ZmZlciBmb3IgcGFyc2luZy5cblx0ICovXG5cdHB1YmxpYyBhc3luYyByZXF1ZXN0QWxsU2V0dGluZ3MoZGV2aWNlSXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0bG9nZ2VyLmluZm8oYFJlcXVlc3RpbmcgYWxsIHNldHRpbmdzIGZyb20gJHtkZXZpY2VJcH1gKVxuXHRcdGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5zZW5kQXdhaXRBY2soQ01EX0dFVF9BTExfU0VUVElOR1MsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIGRldmljZUlwLCBmYWxzZSlcblx0XHQvLyBkZXZpY2VTdGF0ZSBpcyBwb3B1bGF0ZWQgYnkgbG9nU3RQYXlsb2FkIHdoZW4gdGhlIENNRF9HRVRfQUxMX1NFVFRJTkdTIHJlc3BvbnNlIGFycml2ZXNcblx0XHRyZXR1cm4gcmVzcG9uc2Vcblx0fVxuXG5cdC8qKlxuXHQgKiBEaXNjb3ZlcnMgU3R1ZGlvIFRlY2hub2xvZ2llcyBEYW50ZSBkZXZpY2VzIG9uIHRoZSBsb2NhbCBuZXR3b3JrLlxuXHQgKlxuXHQgKiBMaXN0ZW5zIGZvciBEYW50ZSBhbm5vdW5jZXMgb24gMjI0LjAuMC4yMzM6ODcwOCwgc2VuZHMgdW5pY2FzdCBpbmZvIHJlcXVlc3RzXG5cdCAqIHRvIGVhY2ggZGlzY292ZXJlZCBJUCwgYW5kIGNvbGxlY3RzIDB4MDE3MCByZXNwb25zZXMgdmlhIHRoZSByeFNvY2tldC5cblx0ICovXG5cdHB1YmxpYyBhc3luYyBkaXNjb3ZlckRldmljZXModGltZW91dE1zID0gNTAwMCk6IFByb21pc2U8RGV2aWNlSW5mb1tdPiB7XG5cdFx0Y29uc3QgRElTQ09WRVJZX0tFWSA9ICdfX2Rpc2NvdmVyeV9fJ1xuXHRcdGNvbnN0IGZvdW5kRGV2aWNlczogRGV2aWNlSW5mb1tdID0gW11cblxuXHRcdHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNldChESVNDT1ZFUllfS0VZLCAoZGV2aWNlOiBEZXZpY2VJbmZvKSA9PiB7XG5cdFx0XHRpZiAoIWZvdW5kRGV2aWNlcy5zb21lKChkKSA9PiBkLmlwID09PSBkZXZpY2UuaXApKSB7XG5cdFx0XHRcdGZvdW5kRGV2aWNlcy5wdXNoKGRldmljZSlcblx0XHRcdH1cblx0XHR9KVxuXG5cdFx0dHJ5IHtcblx0XHRcdGF3YWl0IHRoaXMudHhSZWFkeVxuXHRcdFx0YXdhaXQgZGlzY292ZXJEZXZpY2VzKHRoaXMudHhTb2NrZXQsIGFzeW5jIChkZXN0SXApID0+IHRoaXMuZW5zdXJlTWVtYmVyc2hpcEZvcihkZXN0SXApLCB0aW1lb3V0TXMpXG5cdFx0XHRyZXR1cm4gZm91bmREZXZpY2VzXG5cdFx0fSBmaW5hbGx5IHtcblx0XHRcdHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLmRlbGV0ZShESVNDT1ZFUllfS0VZKVxuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBSZXF1ZXN0cyBkZXZpY2UgZmlybXdhcmUgdmVyc2lvbiB2aWEgU3R1ZGlvLVQgcHJvdG9jb2wgKENNRF9HRVRfRklSTVdBUkUpLlxuXHQgKiBSZXR1cm5zIHRoZSBmaXJtd2FyZSB2ZXJzaW9uIHN0cmluZyAoZS5nLiwgXCIzLjAxXCIsIFwiMi4yXCIsIFwiMS4wNVwiKS5cblx0ICovXG5cdHB1YmxpYyBhc3luYyByZXF1ZXN0RmlybXdhcmVWZXJzaW9uKGRldmljZUlwOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuXHRcdGxvZ2dlci5pbmZvKGBSZXF1ZXN0aW5nIGZpcm13YXJlIHZlcnNpb24gZnJvbSAke2RldmljZUlwfWApXG5cdFx0Y29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLnNlbmRBd2FpdEFjayhDTURfR0VUX0ZJUk1XQVJFLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBkZXZpY2VJcCwgZmFsc2UpXG5cblx0XHQvLyBSZXNwb25zZSBzdHJ1Y3R1cmU6IFtoZWFkZXJdIDB4NWEgMHg4MCBbZmlybXdhcmVfZGF0YV0gQ1JDXG5cdFx0Ly8gRmlybXdhcmUgZGF0YSBzdGFydHMgYXQgYnl0ZSAyNiAoMjQtYnl0ZSBoZWFkZXIgKyAweDVhICsgMHg4MClcblx0XHRjb25zdCBkYXRhU3RhcnQgPSAyNlxuXG5cdFx0aWYgKHJlc3BvbnNlLmxlbmd0aCA8IGRhdGFTdGFydCArIDMpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBGaXJtd2FyZSByZXNwb25zZSB0b28gc2hvcnQ6ICR7cmVzcG9uc2UubGVuZ3RofSBieXRlc2ApXG5cdFx0XHRyZXR1cm4gJ1Vua25vd24nXG5cdFx0fVxuXG5cdFx0Ly8gRmlybXdhcmUgZm9ybWF0OiBbdW5rbm93bl9ieXRlLCBtYWpvciwgbWlub3JdXG5cdFx0Y29uc3QgbWFqb3IgPSByZXNwb25zZVtkYXRhU3RhcnQgKyAxXVxuXHRcdGNvbnN0IG1pbm9yID0gcmVzcG9uc2VbZGF0YVN0YXJ0ICsgMl1cblxuXHRcdGNvbnN0IG1pbm9yU3RyID1cblx0XHRcdG1pbm9yIDwgMTBcblx0XHRcdFx0PyBtaW5vci50b1N0cmluZygpLnBhZFN0YXJ0KDIsICcwJykgLy8gZS5nLiAxIFx1MjE5MiBcIjAxXCIsIDUgXHUyMTkyIFwiMDVcIlxuXHRcdFx0XHQ6IG1pbm9yLnRvU3RyaW5nKCkgLy8gZS5nLiAxMCBcdTIxOTIgXCIxMFwiXG5cblx0XHRjb25zdCBmaXJtd2FyZSA9IGAke21ham9yfS4ke21pbm9yU3RyfWBcblxuXHRcdGxvZ2dlci5kZWJ1ZyhgRmlybXdhcmUgdmVyc2lvbjogJHtmaXJtd2FyZX1gKVxuXHRcdHJldHVybiBmaXJtd2FyZVxuXHR9XG5cblx0LyoqXG5cdCAqIEpvaW5zIHRoZSBtdWx0aWNhc3QgcmVzcG9uc2UgZ3JvdXAgb24gdGhlIGludGVyZmFjZSB0aGF0IHJvdXRlcyB0byBkZXN0SXAuXG5cdCAqIE9ubHkgam9pbnMgdGhlIHNwZWNpZmljIGludGVyZmFjZSB1c2VkIHRvIHJlYWNoIHRoZSBkZXZpY2UsIGFuZCBvbmx5IG9uY2UgcGVyIGludGVyZmFjZS5cblx0ICovXG5cdHByaXZhdGUgYXN5bmMgZW5zdXJlTWVtYmVyc2hpcEZvcihkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBsb2NhbEFkZHIgPSBhd2FpdCBnZXRMb2NhbEFkZHJlc3NGb3JEZXN0aW5hdGlvbihkZXN0SXApXG5cdFx0XHRpZiAoIWxvY2FsQWRkcikge1xuXHRcdFx0XHRsb2dnZXIud2FybihgQ291bGQgbm90IGRldGVybWluZSBsb2NhbCBhZGRyZXNzIGZvciBkZXN0aW5hdGlvbiAke2Rlc3RJcH1gKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0aWYgKHRoaXMuam9pbmVkSW50ZXJmYWNlcy5oYXMobG9jYWxBZGRyKSkge1xuXHRcdFx0XHQvLyBhbHJlYWR5IGpvaW5lZFxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0dGhpcy5yeFNvY2tldC5hZGRNZW1iZXJzaGlwKHRoaXMubXVsdGljYXN0R3JvdXAsIGxvY2FsQWRkcilcblx0XHRcdFx0dGhpcy5qb2luZWRJbnRlcmZhY2VzLmFkZChsb2NhbEFkZHIpXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBKb2luZWQgbXVsdGljYXN0ICR7dGhpcy5tdWx0aWNhc3RHcm91cH0gb24gJHtsb2NhbEFkZHJ9YClcblx0XHRcdH0gY2F0Y2ggKF9lKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gam9pbiBtdWx0aWNhc3Qgb24gJHtsb2NhbEFkZHJ9OiAke1N0cmluZyhfZSl9YClcblx0XHRcdH1cblx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0bG9nZ2VyLndhcm4oYGVuc3VyZU1lbWJlcnNoaXBGb3IgZmFpbGVkOiAke19lfWApXG5cdFx0fVxuXHR9XG5cblx0cHVibGljIGFzeW5jIHNlbmRBd2FpdEFjayhcblx0XHRjbWRJZDogbnVtYmVyLFxuXHRcdGJ1c0NoOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0c2V0dGluZ0lkOiBudW1iZXIgfCB1bmRlZmluZWQsXG5cdFx0dmFsdWU6IHVua25vd24sXG5cdFx0ZGVzdElwOiBzdHJpbmcsXG5cdFx0YWRkTGVuID0gdHJ1ZSxcblx0KTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHR0aGlzLnBlbmRpbmdDb21tYW5kQ291bnQrK1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZTxCdWZmZXI+KChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdHRoaXMuc2VuZFF1ZXVlID0gdGhpcy5zZW5kUXVldWUudGhlbihhc3luYyAoKSA9PlxuXHRcdFx0XHR0aGlzLl9zZW5kQXdhaXRBY2soY21kSWQsIGJ1c0NoLCBzZXR0aW5nSWQsIHZhbHVlLCBkZXN0SXAsIGFkZExlbilcblx0XHRcdFx0XHQudGhlbigoYnVmKSA9PiB7XG5cdFx0XHRcdFx0XHR0aGlzLnBlbmRpbmdDb21tYW5kQ291bnQtLVxuXHRcdFx0XHRcdFx0Ly8gT25seSB0cmlnZ2VyIHJlcXVlc3RBbGxTZXR0aW5ncyBhZnRlciBhIHdyaXRlIChTRVQpIGNvbW1hbmQsIG5vdCBhIHJlYWQvcG9sbC5cblx0XHRcdFx0XHRcdC8vIEEgd3JpdGUgYWx3YXlzIGhhcyBhIHZhbHVlOyByZWFkcyAoR0VULCBCVVNfR0VUKSBuZXZlciBkby5cblx0XHRcdFx0XHRcdGlmICh0aGlzLnBlbmRpbmdDb21tYW5kQ291bnQgPT09IDAgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdFx0XHR0aGlzLnJlcXVlc3RBbGxTZXR0aW5ncyhkZXN0SXApLmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRsb2dnZXIud2FybihgRmFpbGVkIHRvIHJlZnJlc2ggc2V0dGluZ3MgYWZ0ZXIgY29tbWFuZDogJHtlcnJ9YClcblx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdHJlc29sdmUoYnVmKVxuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0LmNhdGNoKChlcnIpID0+IHtcblx0XHRcdFx0XHRcdHRoaXMucGVuZGluZ0NvbW1hbmRDb3VudC0tXG5cdFx0XHRcdFx0XHRyZWplY3QoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIgOiBuZXcgRXJyb3IoU3RyaW5nKGVycikpKVxuXHRcdFx0XHRcdH0pLFxuXHRcdFx0KVxuXHRcdH0pXG5cdH1cblxuXHRwcml2YXRlIGFzeW5jIF9zZW5kQXdhaXRBY2soXG5cdFx0Y21kSWQ6IG51bWJlcixcblx0XHRidXNDaDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHNldHRpbmdJZDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuXHRcdHZhbHVlOiB1bmtub3duLFxuXHRcdGRlc3RJcDogc3RyaW5nLFxuXHRcdGFkZExlbiA9IHRydWUsXG5cdCk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0Y29uc3QgdGltZW91dE1zID0gMjAwMFxuXG5cdFx0Y29uc3QgZGF0YUJsb2NrOiBudW1iZXJbXSA9IFtdXG5cdFx0aWYgKHNldHRpbmdJZCAhPT0gdW5kZWZpbmVkKSBkYXRhQmxvY2sucHVzaChzZXR0aW5nSWQgJiAweGZmKVxuXHRcdGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkKSBkYXRhQmxvY2sucHVzaCguLi5TdENvbnRyb2xsZXIuYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlKSlcblxuXHRcdGNvbnN0IHBheWxvYWRCb2R5OiBudW1iZXJbXSA9IFsweDVhLCBjbWRJZCAmIDB4ZmZdXG5cblx0XHRpZiAoY21kSWQgPT09IENNRF9NSUNfUFJFICYmIGJ1c0NoICE9PSB1bmRlZmluZWQgJiYgc2V0dGluZ0lkICE9PSB1bmRlZmluZWQgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0Ly8gUG9zaXRpb25hbCBmb3JtYXQ6IFsweDVhXSBbMHgwMl0gW2J1c0NoXSBbdmFsMF0gW3ZhbDFdIFt2YWwyXSAuLi5cblx0XHRcdC8vIFJlYWQgYWxsIHBvc2l0aW9ucyBmcm9tIGRldmljZVN0YXRlLCBvdmVycmlkZSB0aGUgdGFyZ2V0IHBvc2l0aW9uIHdpdGggbmV3IHZhbHVlLlxuXHRcdFx0Ly8gQWxzbyB1cGRhdGUgZGV2aWNlU3RhdGUgb3B0aW1pc3RpY2FsbHkgc28gY29uc2VjdXRpdmUgQ01EX01JQ19QUkUgY29tbWFuZHMgY2hhaW4gY29ycmVjdGx5LlxuXHRcdFx0aWYgKCF0aGlzLmRldmljZVN0YXRlLmhhcyhkZXN0SXApKSB0aGlzLmRldmljZVN0YXRlLnNldChkZXN0SXAsIG5ldyBNYXAoKSlcblx0XHRcdGNvbnN0IGlwU3RhdGUgPSB0aGlzLmRldmljZVN0YXRlLmdldChkZXN0SXApIVxuXHRcdFx0Y29uc3QgbnVtUG9zaXRpb25zID0gMyAvLyBnYWluLCBlbGVjdHJldC9waGFudG9tLCB1bmtub3duXG5cdFx0XHRjb25zdCBwb3NpdGlvbnM6IG51bWJlcltdID0gW11cblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgbnVtUG9zaXRpb25zOyBpKyspIHtcblx0XHRcdFx0Y29uc3Qgc3RhdGVLZXkgPSBtYWtlU2V0dGluZ0lkKHRoaXMubW9kZWwsIENNRF9NSUNfUFJFLCBpLCBidXNDaClcblx0XHRcdFx0Y29uc3QgdmFsID0gaSA9PT0gc2V0dGluZ0lkID8gTnVtYmVyKHZhbHVlKSA6IChpcFN0YXRlLmdldChzdGF0ZUtleSkgPz8gMClcblx0XHRcdFx0cG9zaXRpb25zLnB1c2godmFsKVxuXHRcdFx0XHRpcFN0YXRlLnNldChzdGF0ZUtleSwgdmFsKSAvLyBvcHRpbWlzdGljIHVwZGF0ZVxuXHRcdFx0fVxuXHRcdFx0cGF5bG9hZEJvZHkucHVzaChidXNDaCAmIDB4ZmYsIC4uLnBvc2l0aW9ucylcblx0XHR9IGVsc2Uge1xuXHRcdFx0aWYgKGJ1c0NoICE9PSB1bmRlZmluZWQpIHBheWxvYWRCb2R5LnB1c2goYnVzQ2ggJiAweGZmKVxuXHRcdFx0aWYgKGFkZExlbikgcGF5bG9hZEJvZHkucHVzaChkYXRhQmxvY2subGVuZ3RoKVxuXHRcdFx0aWYgKGRhdGFCbG9jay5sZW5ndGggPiAwKSBwYXlsb2FkQm9keS5wdXNoKC4uLmRhdGFCbG9jaylcblx0XHR9XG5cblx0XHRjb25zdCBjcmMgPSBTdENvbnRyb2xsZXIuY3JjOER2YlMyKHBheWxvYWRCb2R5KVxuXHRcdGNvbnN0IHBheWxvYWRXaXRoQ3JjID0gQnVmZmVyLmZyb20oWy4uLnBheWxvYWRCb2R5LCBjcmNdKVxuXG5cdFx0Ly8gSHVtYW4tcmVhZGFibGUgaW5mbyBsb2cgZm9yIHRoZSBvdXRnb2luZyBjb21tYW5kXG5cdFx0aWYgKHNldHRpbmdJZCAhPT0gdW5kZWZpbmVkICYmIHZhbHVlICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdGNvbnN0IHZhbHVlQnl0ZXMgPSBTdENvbnRyb2xsZXIuYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlKVxuXHRcdFx0Y29uc3Qgc2V0dGluZzogUGFyc2VkU2V0dGluZyA9IHtcblx0XHRcdFx0Y21kX2lkOiBjbWRJZCxcblx0XHRcdFx0aWQ6IHNldHRpbmdJZCxcblx0XHRcdFx0YnVzQ2gsXG5cdFx0XHRcdHZhbHVlQnl0ZXMsXG5cdFx0XHR9XG5cdFx0XHRsb2dnZXIuaW5mbyhgVFggJHtkZXN0SXB9IHwgJHtmb3JtYXRQYXJzZWRTZXR0aW5nKHNldHRpbmcsIHRoaXMuYWN0aW9ucyl9YClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYFRYICR7ZGVzdElwfSB8ICR7Z2V0Q29tbWFuZE5hbWUoY21kSWQpfWApXG5cdFx0fVxuXG5cdFx0Ly8gUmVqZWN0IGNvbW1hbmRzIHRvIHVudmVyaWZpZWQgZGV2aWNlcyBcdTIwMTQgbG9nIHRoZSB3b3VsZC1iZSBwYWNrZXQgZmlyc3QgYXQgZGVidWdcblx0XHQvLyBzbyB0aGUgYnl0ZXMgYXJlIHZpc2libGUgZXZlbiB3aGVuIHRoZSBkZXZpY2UgaXMgb2ZmbGluZS5cblx0XHRpZiAoIXRoaXMuYXV0aG9yaXplZElwcy5oYXMoZGVzdElwKSkge1xuXHRcdFx0bG9nZ2VyLmRlYnVnKGBQYWNrZXQgKG5vdCBzZW50IFx1MjAxNCBkZXZpY2Ugbm90IGF1dGhvcml6ZWQpIHRvICR7ZGVzdElwfTogJHtwYXlsb2FkV2l0aENyYy50b1N0cmluZygnaGV4Jyl9YClcblx0XHRcdHRocm93IG5ldyBFcnJvcihgRGV2aWNlIGF0ICR7ZGVzdElwfSBpcyBub3QgYXV0aG9yaXplZCBcdTIwMTQgdmVyaWZ5IHRoZSBJUCBhbmQgbW9kZWwgbWF0Y2ggYmVmb3JlIHNlbmRpbmcgY29tbWFuZHNgKVxuXHRcdH1cblxuXHRcdC8vIElmIFwidXNlQ29uTW9uXCIgaXMgc2V0IGluIHRoZSBkZXZpY2UgSlNPTiwgZW5zdXJlIHRoZSBEYW50ZSBDb25Nb24gc2Vzc2lvblxuXHRcdC8vIChwb3J0IDg4MDApIGlzIG9wZW4gYmVmb3JlIHNlbmRpbmcuIG9wZW5TZXNzaW9uKCkgY2FjaGVzIHRoZSByZXN1bHQgXHUyMDE0IHRoZVxuXHRcdC8vIGhhbmRzaGFrZSBvbmx5IHJ1bnMgb25jZSBwZXIgSVAuIE5vbi11c2VDb25Nb24gZGV2aWNlcyBhcmUgbWFya2VkIHJlYWR5IGltbWVkaWF0ZWx5LlxuXHRcdGlmICghdGhpcy5zZXNzaW9uRXN0YWJsaXNoZWQuaGFzKGRlc3RJcCkpIHtcblx0XHRcdGF3YWl0IHRoaXMub3BlblNlc3Npb24oZGVzdElwKVxuXHRcdFx0Ly8gU2Vzc2lvbiBmYWlsdXJlIGlzIG5vbi1mYXRhbCBcdTIwMTQgbWFueSBkZXZpY2VzIHJlc3BvbmQgdG8gU3R1ZGlvLVQgcmVnYXJkbGVzcy5cblx0XHR9XG5cblx0XHQvLyBFbnN1cmUgd2UgYXJlIGxpc3RlbmluZyBmb3IgcmVwbGllcyBvbiB0aGUgaW50ZXJmYWNlIHRoYXQgd2lsbCByZWNlaXZlIHRoZW1cblx0XHRhd2FpdCB0aGlzLmVuc3VyZU1lbWJlcnNoaXBGb3IoZGVzdElwKVxuXG5cdFx0Y29uc3QgdG90YWxMZW4gPSAyNCArIHBheWxvYWRXaXRoQ3JjLmxlbmd0aFxuXHRcdGNvbnN0IGhlYWRlciA9IGF3YWl0IHRoaXMuYnVpbGRIZWFkZXIodG90YWxMZW4sIGRlc3RJcClcblx0XHRjb25zdCBwYWNrZXQgPSBCdWZmZXIuY29uY2F0KFtoZWFkZXIsIHBheWxvYWRXaXRoQ3JjXSlcblxuXHRcdGxvZ2dlci5kZWJ1ZyhgU2VuZGluZyBwYWNrZXQgdG8gJHtkZXN0SXB9OiAke3BhY2tldC50b1N0cmluZygnaGV4Jyl9YClcblxuXHRcdGNvbnN0IGtleSA9IGAke2Rlc3RJcH06JHtjbWRJZH1gXG5cblx0XHRyZXR1cm4gbmV3IFByb21pc2U8QnVmZmVyPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoYFRpbWVvdXQgd2FpdGluZyBmb3IgQUNLIGZyb20gTW9kZWwgJHt0aGlzLm1vZGVsfSBhdCAke2Rlc3RJcH06ODcwMGApKVxuXHRcdFx0fSwgdGltZW91dE1zKVxuXG5cdFx0XHR0aGlzLnBlbmRpbmdBY2tzLnNldChrZXksIHtcblx0XHRcdFx0cmVzb2x2ZTogKGJ1ZikgPT4ge1xuXHRcdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdFx0XHRyZXNvbHZlKGJ1Zilcblx0XHRcdFx0fSxcblx0XHRcdFx0cmVqZWN0OiAoZXJyKSA9PiB7XG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdHJlamVjdChlcnIpXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHRpbWVyLFxuXHRcdFx0fSlcblxuXHRcdFx0dGhpcy50eFNvY2tldC5zZW5kKHBhY2tldCwgdGhpcy5kZWZhdWx0UG9ydCwgZGVzdElwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdGlmIChlcnIpIHtcblx0XHRcdFx0XHR0aGlzLnBlbmRpbmdBY2tzLmRlbGV0ZShrZXkpXG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdHJlamVjdChuZXcgRXJyb3IoZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVycikpKVxuXHRcdFx0XHR9XG5cdFx0XHR9KVxuXHRcdH0pXG5cdH1cblxuXHRwcml2YXRlIGhhbmRsZUluY29taW5nKG1zZzogQnVmZmVyLCBzcmNJcDogc3RyaW5nKSB7XG5cdFx0aWYgKG1zZy5sZW5ndGggPCA0KSByZXR1cm5cblx0XHRpZiAobXNnWzBdICE9PSAweGZmIHx8IG1zZ1sxXSAhPT0gMHhmZikgcmV0dXJuXG5cblx0XHRjb25zdCBtc2dUeXBlID0gbXNnLnJlYWRVSW50MTZCRSgyKVxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlICgweDAxNzApIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdC8vIFRoZXNlIGhhdmUgXCJBdWRpbmF0ZVwiIGF0IG9mZnNldCAxNiwgbm90IFwiU3R1ZGlvLVRcIiBcdTIwMTQgaGFuZGxlIGJlZm9yZVxuXHRcdC8vIHRoZSBTdHVkaW8tVCBzaWduYXR1cmUgY2hlY2sgYmVsb3cuXG5cdFx0aWYgKG1zZ1R5cGUgPT09IERBTlRFX01TR19JTkZPX1JFU1BPTlNFICYmIHRoaXMuZGlzY292ZXJ5TGlzdGVuZXJzLnNpemUgPiAwKSB7XG5cdFx0XHRjb25zdCBkZXZpY2UgPSBwYXJzZURhbnRlSW5mb1Jlc3BvbnNlKG1zZywgc3JjSXApXG5cdFx0XHRpZiAoZGV2aWNlKSB7XG5cdFx0XHRcdGxvZ2dlci5kZWJ1Zyhcblx0XHRcdFx0XHRgRGFudGUgaW5mbyByZXNwb25zZSBmcm9tICR7c3JjSXB9OiBgICtcblx0XHRcdFx0XHRcdGBEZXZpY2VJRD1cIiR7ZGV2aWNlLm5hbWV9XCIsIGAgK1xuXHRcdFx0XHRcdFx0YE1vZGVsPVwiJHtkZXZpY2UubW9kZWx9XCIsIGAgK1xuXHRcdFx0XHRcdFx0YE1vZGVsTmFtZT1cIiR7ZGV2aWNlLm1vZGVsTmFtZX1cIiwgYCArXG5cdFx0XHRcdFx0XHRgTWFudWZhY3R1cmVyPVwiJHtkZXZpY2UubWFudWZhY3R1cmVyfVwiYCxcblx0XHRcdFx0KVxuXG5cdFx0XHRcdC8vIE9ubHkgYWNjZXB0IFN0dWRpbyBUZWNobm9sb2dpZXMgZGV2aWNlcyAoaWRlbnRpZmllZCBieSBEZXZpY2VJRCBcIlN0dWRpby1UXCIpXG5cdFx0XHRcdGlmIChkZXZpY2UubmFtZSA9PT0gJ1N0dWRpby1UJykge1xuXHRcdFx0XHRcdGZvciAoY29uc3QgY2Igb2YgdGhpcy5kaXNjb3ZlcnlMaXN0ZW5lcnMudmFsdWVzKCkpIHtcblx0XHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRcdGNiKGRldmljZSlcblx0XHRcdFx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBJZ25vcmluZyBub24tU3R1ZGlvIFRlY2hub2xvZ2llcyBkZXZpY2U6IERldmljZUlEPVwiJHtkZXZpY2UubmFtZX1cIiBAICR7c3JjSXB9YClcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0aWYgKG1zZy5sZW5ndGggPCAyNSkgcmV0dXJuXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgU3R1ZGlvLVQgY29udHJvbCBwcm90b2NvbCBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRjb25zdCBzaWcgPSBtc2cuc3ViYXJyYXkoMTYsIDI0KVxuXHRcdGlmIChzaWcudG9TdHJpbmcoJ2FzY2lpJykgIT09ICdTdHVkaW8tVCcpIHJldHVyblxuXG5cdFx0Ly8gSWdub3JlIFN0dWRpby1UIHBhY2tldHMgZnJvbSBkZXZpY2VzIHdlIGhhdmVuJ3QgYXV0aG9yaXplZC5cblx0XHQvLyBUaGlzIHByZXZlbnRzIGNyb3NzLWNvbnRhbWluYXRpb24gd2hlbiBtdWx0aXBsZSBkZXZpY2VzIChvciBtdWx0aXBsZVxuXHRcdC8vIENvbXBhbmlvbiBpbnN0YW5jZXMpIGFyZSBvbiB0aGUgc2FtZSBuZXR3b3JrIFx1MjAxNCBhbGwgc2hhcmUgdGhlIG11bHRpY2FzdFxuXHRcdC8vIGdyb3VwIDIyNC4wLjAuMjMxOjg3MDIgYW5kIHdpbGwgcmVjZWl2ZSBlYWNoIG90aGVyJ3MgQUNLcyBhbmQgcHVzaGVzLlxuXHRcdGlmICghdGhpcy5hdXRob3JpemVkSXBzLmhhcyhzcmNJcCkpIHtcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgSWdub3JpbmcgU3R1ZGlvLVQgcGFja2V0IGZyb20gdW5hdXRob3JpemVkIGRldmljZSAke3NyY0lwfWApXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBQYXlsb2FkIHN0YXJ0cyBhdCBvZmZzZXQgMjRcblx0XHQvLyBMYXlvdXQ6IFsweDVhXSBbY21kSWR8MHg4MF0gW2RhdGEuLi5dIFtjcmNdXG5cdFx0Y29uc3Qgc3RQYXlsb2FkID0gbXNnLnN1YmFycmF5KDI0KVxuXHRcdGlmIChzdFBheWxvYWQubGVuZ3RoIDwgMikgcmV0dXJuXG5cdFx0aWYgKHN0UGF5bG9hZFswXSAhPT0gMHg1YSkgcmV0dXJuXG5cblx0XHQvLyBEZXZpY2UgcmVwbGllcyB3aXRoIGNtZCB8IDB4ODBcblx0XHRjb25zdCByZXNwQ21kSWQgPSBzdFBheWxvYWRbMV1cblx0XHRjb25zdCBpc1Jlc3BvbnNlID0gKHJlc3BDbWRJZCAmIDB4ODApICE9PSAwXG5cdFx0Y29uc3Qgb3JpZ2luYWxDbWRJZCA9IHJlc3BDbWRJZCAmIDB4N2YgLy8gc3RyaXAgdGhlIHJlc3BvbnNlIGZsYWdcblxuXHRcdC8vIFJlc3BvbnNlcyBhcmUgZGVsaXZlcmVkIHRvIGJvdGggdW5pY2FzdCBhbmQgbXVsdGljYXN0IDIyNC4wLjAuMjMxOjg3MDIuXG5cdFx0Ly8gV2l0aCB0d28gam9pbmVkIGludGVyZmFjZXMgdGhlIHJ4U29ja2V0IHJlY2VpdmVzIGVhY2ggcmVzcG9uc2UgdHdpY2UuXG5cdFx0Ly8gR2F0ZSBsb2dnaW5nIGFuZCBBQ0sgcmVzb2x1dGlvbiBvbiB0aGUgZmlyc3QgZGVsaXZlcnkgKHBlbmRpbmcgQUNLIHByZXNlbnQpLlxuXHRcdC8vIENNRF9TRVRUSU5HU19QVVNIICgweDBiKSBpcyB1bnNvbGljaXRlZCBcdTIwMTQgYWx3YXlzIGxvZyBpdC5cblx0XHRpZiAoaXNSZXNwb25zZSkge1xuXHRcdFx0Y29uc3Qga2V5ID0gYCR7c3JjSXB9OiR7b3JpZ2luYWxDbWRJZH1gXG5cdFx0XHRjb25zdCBwZW5kaW5nID0gdGhpcy5wZW5kaW5nQWNrcy5nZXQoa2V5KVxuXHRcdFx0aWYgKHBlbmRpbmcpIHtcblx0XHRcdFx0dGhpcy5wZW5kaW5nQWNrcy5kZWxldGUoa2V5KVxuXHRcdFx0XHRjb25zdCB2aWFNdWx0aWNhc3QgPSB0aGlzLm1jYXN0RGVsaXZlcmllcy5oYXMoa2V5KVxuXHRcdFx0XHRsb2dnZXIuZGVidWcoXG5cdFx0XHRcdFx0YFJYIGRlbGl2ZXJ5IG1ldGhvZDogJHtzcmNJcH0gY21kOiR7dG9IZXgob3JpZ2luYWxDbWRJZCl9IHZpYSAke3ZpYU11bHRpY2FzdCA/ICdtdWx0aWNhc3QnIDogJ3VuaWNhc3QnfWAsXG5cdFx0XHRcdClcblx0XHRcdFx0aWYgKG9yaWdpbmFsQ21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTKSB7XG5cdFx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBSZWNlaXZlZCBwYWNrZXQgZnJvbSAke3NyY0lwfTogJHttc2cudG9TdHJpbmcoJ2hleCcpfWApXG5cdFx0XHRcdH1cblx0XHRcdFx0dGhpcy5sb2dTdFBheWxvYWQoc3JjSXAsIG9yaWdpbmFsQ21kSWQsIG1zZywgc3RQYXlsb2FkKVxuXHRcdFx0XHRwZW5kaW5nLnJlc29sdmUobXNnKVxuXHRcdFx0fSBlbHNlIGlmIChvcmlnaW5hbENtZElkID09PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdFx0XHQvLyBVbnNvbGljaXRlZCBwdXNoIFx1MjAxNCBhbHdheXMgbG9nXG5cdFx0XHRcdHRoaXMubG9nU3RQYXlsb2FkKHNyY0lwLCBvcmlnaW5hbENtZElkLCBtc2csIHN0UGF5bG9hZClcblx0XHRcdH1cblx0XHRcdC8vIGVsc2U6IGR1cGxpY2F0ZSBtdWx0aWNhc3QgZGVsaXZlcnkgXHUyMDE0IHN1cHByZXNzXG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIE91dGdvaW5nIGNvbW1hbmQgZWNobyBvciB1bnNvbGljaXRlZCBkaXJlY3QtcHVzaCBmcm9tIGRldmljZS5cblx0XHRcdC8vIElmIHRoaXMgY21kSWQgaGFzIGtub3duIHNjaGVtYSBlbnRyaWVzLCBwYXJzZSBkYXRhIGFzIFtkYXRhTGVuXVtpZDp2YWwgcGFpcnNdXG5cdFx0XHQvLyBhbmQgdXBkYXRlIHN0YXRlL2ZlZWRiYWNrcyBcdTIwMTQgdGhlIGRldmljZSBzZW5kcyB0aGVzZSB3aXRob3V0IGEgMHgwYiB3cmFwcGVyLlxuXHRcdFx0Y29uc3QgZGF0YSA9IHN0UGF5bG9hZC5zdWJhcnJheSgyLCBzdFBheWxvYWQubGVuZ3RoIC0gMSlcblx0XHRcdGNvbnN0IGhhc1NjaGVtYUVudHJpZXMgPSB0aGlzLmFjdGlvbnMuc29tZSgoYSkgPT4gYS5jbWRfaWQgPT09IG9yaWdpbmFsQ21kSWQpXG5cdFx0XHRpZiAoaGFzU2NoZW1hRW50cmllcyAmJiBkYXRhLmxlbmd0aCA+PSAyKSB7XG5cdFx0XHRcdGNvbnN0IGRhdGFMZW4gPSBkYXRhWzBdXG5cdFx0XHRcdGNvbnN0IHBheWxvYWQgPSBkYXRhLnN1YmFycmF5KDEpXG5cdFx0XHRcdGlmIChwYXlsb2FkLmxlbmd0aCA+PSBkYXRhTGVuICYmIGRhdGFMZW4gPiAwKSB7XG5cdFx0XHRcdFx0Y29uc3QgcGFyc2VkOiBQYXJzZWRTZXR0aW5nW10gPSBbXVxuXHRcdFx0XHRcdGxldCBxID0gMFxuXHRcdFx0XHRcdHdoaWxlIChxICsgMSA8IGRhdGFMZW4pIHtcblx0XHRcdFx0XHRcdGNvbnN0IGlkID0gcGF5bG9hZFtxXVxuXHRcdFx0XHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IFtwYXlsb2FkW3EgKyAxXV1cblx0XHRcdFx0XHRcdHBhcnNlZC5wdXNoKHsgY21kX2lkOiBvcmlnaW5hbENtZElkLCBpZCwgdmFsdWVCeXRlcyB9KVxuXHRcdFx0XHRcdFx0cSArPSAyXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGlmIChwYXJzZWQubGVuZ3RoID4gMCkge1xuXHRcdFx0XHRcdFx0dGhpcy5hcHBseVBhcnNlZFNldHRpbmdzKHNyY0lwLCBwYXJzZWQpXG5cdFx0XHRcdFx0XHRyZXR1cm5cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHRoaXMubG9nU3RQYXlsb2FkKHNyY0lwLCBvcmlnaW5hbENtZElkLCBtc2csIHN0UGF5bG9hZClcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogQXBwbGllcyBhIGxpc3Qgb2YgcGFyc2VkIHNldHRpbmdzIHRvIGRldmljZVN0YXRlLCBsb2dzIGNoYW5nZXMsIGFuZCB0cmlnZ2VycyBmZWVkYmFja3MuXG5cdCAqIFNoYXJlZCBieSB0aGUgQ01EX0dFVF9BTExfU0VUVElOR1MvQ01EX1NFVFRJTkdTX1BVU0ggcGF0aCBhbmQgdGhlIGRpcmVjdC1wdXNoIHBhdGguXG5cdCAqL1xuXHRwcml2YXRlIGFwcGx5UGFyc2VkU2V0dGluZ3Moc3JjSXA6IHN0cmluZywgc2V0dGluZ3M6IFBhcnNlZFNldHRpbmdbXSk6IHZvaWQge1xuXHRcdGNvbnN0IHN0YXRlID0gdGhpcy5kZXZpY2VTdGF0ZS5nZXQoc3JjSXApID8/IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KClcblx0XHRpZiAoIXRoaXMuZGV2aWNlU3RhdGUuaGFzKHNyY0lwKSkgdGhpcy5kZXZpY2VTdGF0ZS5zZXQoc3JjSXAsIHN0YXRlKVxuXG5cdFx0Zm9yIChjb25zdCBzIG9mIHNldHRpbmdzKSB7XG5cdFx0XHRjb25zdCBzdGF0ZUtleSA9IG1ha2VTZXR0aW5nSWQodGhpcy5tb2RlbCwgcy5jbWRfaWQsIHMuaWQsIHMuYnVzQ2gpXG5cdFx0XHRjb25zdCBuZXdWYWx1ZSA9XG5cdFx0XHRcdHMudmFsdWVCeXRlcy5sZW5ndGggPT09IDNcblx0XHRcdFx0XHQ/IChzLnZhbHVlQnl0ZXNbMF0gPDwgMTYpIHwgKHMudmFsdWVCeXRlc1sxXSA8PCA4KSB8IHMudmFsdWVCeXRlc1syXVxuXHRcdFx0XHRcdDogKHMudmFsdWVCeXRlc1swXSA/PyAwKVxuXHRcdFx0Y29uc3QgcHJldlZhbHVlID0gc3RhdGUuZ2V0KHN0YXRlS2V5KVxuXHRcdFx0Y29uc3QgY2hhbmdlZCA9IHByZXZWYWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHByZXZWYWx1ZSAhPT0gbmV3VmFsdWVcblxuXHRcdFx0c3RhdGUuc2V0KHN0YXRlS2V5LCBuZXdWYWx1ZSlcblxuXHRcdFx0Y29uc3QgZm9ybWF0dGVkID0gZm9ybWF0UGFyc2VkU2V0dGluZyhzLCB0aGlzLmFjdGlvbnMpXG5cdFx0XHRpZiAoY2hhbmdlZCkge1xuXHRcdFx0XHRsb2dnZXIuaW5mbyhgUlggJHtzcmNJcH0gfCAke2Zvcm1hdHRlZH1gKVxuXHRcdFx0XHRpZiAodGhpcy5mZWVkYmFja0NhbGxiYWNrKSB7XG5cdFx0XHRcdFx0bGV0IGJhc2VJZCA9IHMuaWRcblx0XHRcdFx0XHRjb25zdCBiYXNlQWN0aW9uID0gdGhpcy5hY3Rpb25zLmZpbmQoKGEpID0+IHtcblx0XHRcdFx0XHRcdGlmIChhLmNtZF9pZCAhPT0gcy5jbWRfaWQpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdFx0aWYgKGEuaWQgPT09IHMuaWQpIHJldHVybiB0cnVlXG5cdFx0XHRcdFx0XHRjb25zdCBpZEFkZE9wdGlvbiA9IGEub3B0aW9ucz8uZmluZCgobykgPT4gby5pZCA9PT0gJ2lkQWRkJylcblx0XHRcdFx0XHRcdGlmICghaWRBZGRPcHRpb24/LmNob2ljZXMpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRcdFx0Y29uc3Qgb2Zmc2V0ID0gcy5pZCAtIGEuaWRcblx0XHRcdFx0XHRcdHJldHVybiBvZmZzZXQgPiAwICYmIGlkQWRkT3B0aW9uLmNob2ljZXMuc29tZSgoYykgPT4gYy5pZCA9PT0gb2Zmc2V0KVxuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0aWYgKGJhc2VBY3Rpb24pIGJhc2VJZCA9IGJhc2VBY3Rpb24uaWRcblx0XHRcdFx0XHRjb25zdCBiYXNlRmVlZGJhY2tLZXkgPSBtYWtlU2V0dGluZ0lkKHRoaXMubW9kZWwsIHMuY21kX2lkLCBiYXNlSWQpXG5cdFx0XHRcdFx0dGhpcy5mZWVkYmFja0NhbGxiYWNrKGJhc2VGZWVkYmFja0tleSlcblx0XHRcdFx0XHR0aGlzLmZlZWRiYWNrQ2FsbGJhY2soYmFzZUZlZWRiYWNrS2V5ICsgJ19ib29sJylcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRsb2dnZXIud2FybihgZmVlZGJhY2tDYWxsYmFjayBub3Qgc2V0IFx1MjAxNCBza2lwcGluZyBmZWVkYmFjayB1cGRhdGUgZm9yICR7c3RhdGVLZXl9YClcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBSWCAke3NyY0lwfSB8ICR7Zm9ybWF0dGVkfWApXG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIERlY29kZXMgYW5kIGxvZ3MgYSBTdHVkaW8tVCByZXNwb25zZSBwYXlsb2FkLlxuXHQgKiBSZWNlaXZlcyBib3RoIHRoZSBmdWxsIG1zZyAoZm9yIHBhcnNlcnMgdGhhdCBuZWVkIHRoZSBTdHVkaW8tVCBoZWFkZXIpXG5cdCAqIGFuZCBzdFBheWxvYWQgKG1zZy5zdWJhcnJheSgyNCksIGZvciBkaXJlY3QgYnl0ZSBhY2Nlc3MpLlxuXHQgKlxuXHQgKiBzdFBheWxvYWQgbGF5b3V0OlxuXHQgKiAgIFswXSAgICAgIDB4NWEgIG1hZ2ljXG5cdCAqICAgWzFdICAgICAgY21kSWQgfCAweDgwXG5cdCAqICAgWzIuLi0yXSAgZGF0YSBieXRlc1xuXHQgKiAgIFstMV0gICAgIENSQy04L0RWQi1TMlxuXHQgKi9cblx0cHJpdmF0ZSBsb2dTdFBheWxvYWQoc3JjSXA6IHN0cmluZywgY21kSWQ6IG51bWJlciwgbXNnOiBCdWZmZXIsIHN0UGF5bG9hZDogQnVmZmVyKTogdm9pZCB7XG5cdFx0Y29uc3QgY21kTmFtZSA9IGdldENvbW1hbmROYW1lKGNtZElkKVxuXHRcdGNvbnN0IGRhdGEgPSBzdFBheWxvYWQuc3ViYXJyYXkoMiwgc3RQYXlsb2FkLmxlbmd0aCAtIDEpIC8vIHN0cmlwIG1hZ2ljK2NtZElkIGhlYWRlciBhbmQgQ1JDXG5cblx0XHQvLyBQYXlsb2FkIHN0cnVjdHVyZTogW2NtZDoweDhkXSBbZGF0YSBieXRlcy4uLl0gW2NyY11cblx0XHRjb25zdCByZXNwQ21kSWQgPSBzdFBheWxvYWRbMV1cblx0XHRjb25zdCBjcmMgPSBzdFBheWxvYWRbc3RQYXlsb2FkLmxlbmd0aCAtIDFdXG5cdFx0Y29uc3QgZnVsbFN0cnVjdHVyZSA9IGBbY21kOiR7dG9IZXgocmVzcENtZElkKX0gZGF0YToke2RhdGEudG9TdHJpbmcoJ2hleCcpfSBjcmM6JHt0b0hleChjcmMpfV1gXG5cblx0XHQvLyBcdTI1MDBcdTI1MDAgQ01EX0dFVF9BTExfU0VUVElOR1MgKDB4MGEpIGFuZCBDTURfU0VUVElOR1NfUFVTSCAoMHgwYikgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0Ly8gUGFyc2UgYWxsIHNldHRpbmdzLCBkaWZmIGFnYWluc3QgZGV2aWNlU3RhdGUsIGxvZyBjaGFuZ2VkIGF0IGluZm8gLyB1bmNoYW5nZWQgYXQgZGVidWcsXG5cdFx0Ly8gdGhlbiB1cGRhdGUgZGV2aWNlU3RhdGUuIENNRF9HRVRfQUxMX1NFVFRJTkdTIGFsc28gc2VydmVzIGFzIHRoZSBpbml0aWFsIHN0YXRlIHBvcHVsYXRpb24gb24gY29ubmVjdC5cblx0XHRpZiAoY21kSWQgPT09IENNRF9HRVRfQUxMX1NFVFRJTkdTIHx8IGNtZElkID09PSBDTURfU0VUVElOR1NfUFVTSCkge1xuXHRcdFx0aWYgKCF0aGlzLm1vZGVsKSB7XG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHRcdFx0cmV0dXJuXG5cdFx0XHR9XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBzZXR0aW5ncyA9XG5cdFx0XHRcdFx0Y21kSWQgPT09IENNRF9TRVRUSU5HU19QVVNIXG5cdFx0XHRcdFx0XHQ/IHBhcnNlU2V0dGluZ3NSZXNwb25zZSh0aGlzLm1vZGVsLCBtc2cpXG5cdFx0XHRcdFx0XHQ6IHBhcnNlR2V0QWxsU2V0dGluZ3NGb3JNb2RlbCh0aGlzLm1vZGVsLCBtc2cpXG5cblx0XHRcdFx0dGhpcy5hcHBseVBhcnNlZFNldHRpbmdzKHNyY0lwLCBzZXR0aW5ncylcblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYFJYICR7c3JjSXB9IHwgJHtjbWROYW1lfSB8IHBhcnNlIGZhaWxlZDogJHtlfSB8ICR7ZnVsbFN0cnVjdHVyZX1gKVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Ly8gXHUyNTAwXHUyNTAwIEFsbCBvdGhlciBjb21tYW5kcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRjb25zdCBkZWNvZGVkID0gdGhpcy5kZWNvZGVTdERhdGEoY21kSWQsIGRhdGEpXG5cdFx0Ly8gQ01EX0JVU19HRVQgKGtlZXBhbGl2ZSkgaXMgaGlnaC1mcmVxdWVuY3kgbm9pc2UgXHUyMDE0IGxvZyBhdCBkZWJ1ZyBvbmx5XG5cdFx0Y29uc3QgbG9nRm4gPSBjbWRJZCA9PT0gQ01EX0JVU19HRVQgPyBsb2dnZXIuZGVidWcuYmluZChsb2dnZXIpIDogbG9nZ2VyLmluZm8uYmluZChsb2dnZXIpXG5cdFx0aWYgKGRlY29kZWQpIHtcblx0XHRcdGxvZ0ZuKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9IHwgJHtkZWNvZGVkfWApXG5cdFx0fSBlbHNlIHtcblx0XHRcdGxvZ0ZuKGBSWCAke3NyY0lwfSB8ICR7Y21kTmFtZX0gfCAke2Z1bGxTdHJ1Y3R1cmV9YClcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogQXR0ZW1wdHMgdG8gZGVjb2RlIHRoZSBkYXRhIGJ5dGVzIG9mIGEgU3R1ZGlvLVQgcmVzcG9uc2UgaW50byBhXG5cdCAqIGh1bWFuLXJlYWRhYmxlIHN0cmluZy4gUmV0dXJucyBudWxsIHRvIGZhbGwgYmFjayB0byByYXcgaGV4LlxuXHQgKi9cblx0cHJpdmF0ZSBkZWNvZGVTdERhdGEoY21kSWQ6IG51bWJlciwgZGF0YTogQnVmZmVyKTogc3RyaW5nIHwgbnVsbCB7XG5cdFx0aWYgKGRhdGEubGVuZ3RoID09PSAwKSByZXR1cm4gJ0FDSydcblxuXHRcdC8vIFx1MjUwMFx1MjUwMCBDaGVjayBmb3Igc2luZ2xlLWJ5dGUgcmVzcG9uc2VzIChBQ0sgb3IgZXJyb3IpIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXHRcdGlmIChkYXRhLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0aWYgKGRhdGFbMF0gPT09IDB4MDApIHtcblx0XHRcdFx0cmV0dXJuICdBQ0sgb2snXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRyZXR1cm4gYEVSUk9SICR7dG9IZXgoZGF0YVswXSl9YFxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdHN3aXRjaCAoY21kSWQpIHtcblx0XHRcdC8vIFx1MjUwMFx1MjUwMCBDTURfTUlDX1BSRSAoMHgwMik6IHJhdyBwcmVhbXAgZWNobyBcdTIwMTQgcG9zaXRpb25hbCBieXRlcywgbm8gc2V0dGluZyBJRHMgXHUyNTAwXHUyNTAwXG5cdFx0XHQvLyBEZXZpY2UgZWNob2VzIFtidXNDaF1bdmFsMF1bdmFsMV0uLi4gY29uZmlybWluZyB0aGUgYXBwbGllZCB2YWx1ZXMuXG5cdFx0XHRjYXNlIENNRF9NSUNfUFJFOiB7XG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRjb25zdCB2YWxzID0gQXJyYXkuZnJvbShkYXRhLnN1YmFycmF5KDEpKVxuXHRcdFx0XHRcdC5tYXAoKGIsIGkpID0+IGBbJHtpfV09MHgke2IudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJyl9KCR7Yn0pYClcblx0XHRcdFx0XHQuam9pbignICcpXG5cdFx0XHRcdHJldHVybiBgY2g9JHtidXNDaH0gJHt2YWxzfWBcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9ERVZfU1BFQyAoMHgwZCk6IHNpbmdsZS1ieXRlIEFDSyBvciBlY2hvIG9mIGFwcGxpZWQgc2V0dGluZyBcdTI1MDBcdTI1MDBcblx0XHRcdC8vIERldmljZSBzZW5kcyB0d28gQ01EX0RFVl9TUEVDIHBhY2tldHMgaW4gcmVzcG9uc2UgdG8gYSBzZXQ6XG5cdFx0XHQvLyAgIDEuIEFDSzogIFtzdGF0dXNdICAgICAgICAgICAgICAgKDEgYnl0ZSwgMHgwMCA9IG9rKVxuXHRcdFx0Ly8gICAyLiBFY2hvOiBbYnVzQ2hdIFtzZXR0aW5nSWRdIFt2YWx1ZS4uLl0gIChjb25maXJtaW5nIHdoYXQgd2FzIGFwcGxpZWQpXG5cdFx0XHRjYXNlIENNRF9ERVZfU1BFQzoge1xuXHRcdFx0XHRpZiAoZGF0YS5sZW5ndGggPT09IDEpIHtcblx0XHRcdFx0XHRyZXR1cm4gZGF0YVswXSA9PT0gMHgwMCA/ICdBQ0sgb2snIDogYEFDSyBlcnI9JHt0b0hleChkYXRhWzBdKX1gXG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKGRhdGEubGVuZ3RoID49IDMpIHtcblx0XHRcdFx0XHRjb25zdCBidXNDaCA9IGRhdGFbMF1cblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBkYXRhWzFdXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVCeXRlcyA9IGRhdGEuc3ViYXJyYXkoMilcblx0XHRcdFx0XHRjb25zdCBhY3Rpb24gPSB0aGlzLmFjdGlvbnMuZmluZCgoYSkgPT4gYS5jbWRfaWQgPT09IGNtZElkICYmIGEuaWQgPT09IHNldHRpbmdJZClcblx0XHRcdFx0XHRjb25zdCBzZXR0aW5nTmFtZSA9IGFjdGlvbj8ubmFtZSA/PyBgc2V0dGluZz0ke3RvSGV4KHNldHRpbmdJZCl9YFxuXHRcdFx0XHRcdGNvbnN0IGNob2ljZXMgPSBhY3Rpb24/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICd2YWx1ZScpPy5jaG9pY2VzXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVOdW0gPSB2YWx1ZUJ5dGVzLmxlbmd0aCA9PT0gMSA/IHZhbHVlQnl0ZXNbMF0gOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCBjaG9pY2VMYWJlbCA9XG5cdFx0XHRcdFx0XHRjaG9pY2VzICYmIHZhbHVlTnVtICE9PSB1bmRlZmluZWQgPyBjaG9pY2VzLmZpbmQoKGMpID0+IGMuaWQgPT09IHZhbHVlTnVtKT8ubGFiZWwgOiB1bmRlZmluZWRcblx0XHRcdFx0XHRjb25zdCB2YWx1ZVN0ciA9IGNob2ljZUxhYmVsID8gYCR7Y2hvaWNlTGFiZWx9ICgke3RvSGV4KHZhbHVlTnVtISl9KWAgOiBieXRlc1RvSGV4KEFycmF5LmZyb20odmFsdWVCeXRlcykpXG5cdFx0XHRcdFx0Y29uc3QgcmF3VGFnID0gYFske3RvSGV4KGNtZElkKX0vJHt0b0hleChzZXR0aW5nSWQpfV09JHtieXRlc1RvSGV4KEFycmF5LmZyb20odmFsdWVCeXRlcykpfWBcblx0XHRcdFx0XHRyZXR1cm4gYGVjaG8gY2g9JHtidXNDaH0gfCAke3NldHRpbmdOYW1lfTogJHt2YWx1ZVN0cn0gJHtyYXdUYWd9YFxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBgcmF3OiAke2RhdGEudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIENNRF9NSUNfUFJFX0JVUyAoMHgxMik6IE11bHRpLWJ5dGUgZWNobyByZXNwb25zZXMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cdFx0XHRjYXNlIENNRF9NSUNfUFJFX0JVUzoge1xuXHRcdFx0XHQvLyBBbHJlYWR5IGhhbmRsZWQgc2luZ2xlLWJ5dGUgYWJvdmUsIHNvIG11bHRpLWJ5dGUgbXVzdCBiZSBlY2hvXG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA+PSAzKSB7XG5cdFx0XHRcdFx0Y29uc3QgYnVzQ2ggPSBkYXRhWzBdXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ0lkID0gZGF0YVsxXVxuXHRcdFx0XHRcdGNvbnN0IHZhbHVlQnl0ZXMgPSBkYXRhLnN1YmFycmF5KDIpXG5cdFx0XHRcdFx0Y29uc3QgYWN0aW9uID0gdGhpcy5hY3Rpb25zLmZpbmQoKGEpID0+IGEuY21kX2lkID09PSBjbWRJZCAmJiBhLmlkID09PSBzZXR0aW5nSWQpXG5cdFx0XHRcdFx0Y29uc3Qgc2V0dGluZ05hbWUgPSBhY3Rpb24/Lm5hbWUgPz8gYHNldHRpbmc9JHt0b0hleChzZXR0aW5nSWQpfWBcblx0XHRcdFx0XHRjb25zdCB2YWx1ZU51bSA9IHZhbHVlQnl0ZXMubGVuZ3RoID09PSAxID8gdmFsdWVCeXRlc1swXSA6IHVuZGVmaW5lZFxuXHRcdFx0XHRcdGNvbnN0IGNob2ljZXMgPSBhY3Rpb24/Lm9wdGlvbnM/LmZpbmQoKG8pID0+IG8uaWQgPT09ICd2YWx1ZScpPy5jaG9pY2VzXG5cdFx0XHRcdFx0Y29uc3QgY2hvaWNlTGFiZWwgPVxuXHRcdFx0XHRcdFx0Y2hvaWNlcyAmJiB2YWx1ZU51bSAhPT0gdW5kZWZpbmVkID8gY2hvaWNlcy5maW5kKChjKSA9PiBjLmlkID09PSB2YWx1ZU51bSk/LmxhYmVsIDogdW5kZWZpbmVkXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWVTdHIgPSBjaG9pY2VMYWJlbCA/PyBgMHgke3ZhbHVlQnl0ZXMudG9TdHJpbmcoJ2hleCcpfWBcblx0XHRcdFx0XHRyZXR1cm4gYGVjaG8gY2g9JHtidXNDaH0gfCAke3NldHRpbmdOYW1lfTogJHt2YWx1ZVN0cn1gXG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIG51bGxcblx0XHRcdH1cblxuXHRcdFx0Ly8gXHUyNTAwXHUyNTAwIEJ1cy1zY29wZWQgZ2V0L3NldCBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblx0XHRcdGNhc2UgQ01EX0JVU19HRVQ6XG5cdFx0XHRjYXNlIENNRF9CVVNfU0VUOiB7XG5cdFx0XHRcdGlmIChkYXRhLmxlbmd0aCA8IDIpIHJldHVybiBudWxsXG5cdFx0XHRcdGNvbnN0IGJ1c0NoID0gZGF0YVswXVxuXHRcdFx0XHRjb25zdCBzZXR0aW5nSWQgPSBkYXRhWzFdXG5cdFx0XHRcdGNvbnN0IHZhbHVlID0gZGF0YS5zdWJhcnJheSgyKVxuXHRcdFx0XHRyZXR1cm4gYGNoPSR7YnVzQ2h9IHNldHRpbmc9JHt0b0hleChzZXR0aW5nSWQpfSB2YWx1ZT0ke3ZhbHVlLnRvU3RyaW5nKCdoZXgnKX1gXG5cdFx0XHR9XG5cblx0XHRcdGRlZmF1bHQ6XG5cdFx0XHRcdHJldHVybiBudWxsIC8vIGZhbGwgdGhyb3VnaCB0byByYXcgaGV4XG5cdFx0fVxuXHR9XG5cblx0cHJpdmF0ZSBzdGF0aWMgYnVpbGRWYWx1ZUJ5dGVzKHZhbHVlOiB1bmtub3duKTogbnVtYmVyW10ge1xuXHRcdGlmICh0eXBlb2YgdmFsdWUgPT09ICdib29sZWFuJykgcmV0dXJuIFt2YWx1ZSA/IDEgOiAwXVxuXHRcdGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkgcmV0dXJuIHZhbHVlLm1hcCgodikgPT4gTnVtYmVyKHYpICYgMHhmZilcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykge1xuXHRcdFx0aWYgKHZhbHVlID4gMHhmZikgcmV0dXJuIFsodmFsdWUgPj4gMTYpICYgMHhmZiwgKHZhbHVlID4+IDgpICYgMHhmZiwgdmFsdWUgJiAweGZmXVxuXHRcdFx0cmV0dXJuIFt2YWx1ZSAmIDB4ZmZdXG5cdFx0fVxuXHRcdHRocm93IG5ldyBFcnJvcihgVW5zdXBwb3J0ZWQgdmFsdWUgdHlwZSBmb3IgU1Rjb250cm9sbGVyOiAke3ZhbHVlfWApXG5cdH1cblxuXHRwcml2YXRlIGFzeW5jIGJ1aWxkSGVhZGVyKHRvdGFsTGVuOiBudW1iZXIsIGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRsZXQgbWFjID0gdGhpcy5tYWNDYWNoZS5nZXQoZGVzdElwKVxuXHRcdGlmICghbWFjKSB7XG5cdFx0XHRtYWMgPSBhd2FpdCBnZXRNYWNGb3JEZXN0aW5hdGlvbihkZXN0SXApXG5cdFx0XHR0aGlzLm1hY0NhY2hlLnNldChkZXN0SXAsIG1hYylcblx0XHR9XG5cblx0XHRyZXR1cm4gQnVmZmVyLmNvbmNhdChbXG5cdFx0XHRCdWZmZXIuZnJvbShbMHhmZiwgMHhmZiwgMHgwMCwgdG90YWxMZW4gJiAweGZmLCAweDA3LCAweGUxLCAweDAwLCAweDAwLCAuLi5tYWMsIDB4MDAsIDB4MDBdKSxcblx0XHRcdEJ1ZmZlci5mcm9tKCdTdHVkaW8tVCcsICd1dGY4JyksXG5cdFx0XSlcblx0fVxuXG5cdHByaXZhdGUgc3RhdGljIGNyYzhEdmJTMihkYXRhOiBudW1iZXJbXSk6IG51bWJlciB7XG5cdFx0bGV0IGNyYyA9IDBcblx0XHRmb3IgKGNvbnN0IGIgb2YgZGF0YSkge1xuXHRcdFx0Y3JjIF49IGJcblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgODsgaSsrKSB7XG5cdFx0XHRcdGNyYyA9IChjcmMgJiAweDgwKSAhPT0gMCA/ICgoY3JjIDw8IDEpIF4gMHhkNSkgJiAweGZmIDogKGNyYyA8PCAxKSAmIDB4ZmZcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIGNyY1xuXHR9XG5cblx0LyoqXG5cdCAqIFJldHVybnMgdGhlIGN1cnJlbnQga25vd24gdmFsdWUgZm9yIGEgc2V0dGluZyBvbiBhIGRldmljZSwgb3IgdW5kZWZpbmVkIGlmIHVua25vd24uXG5cdCAqIFVzZSBmb3IgZmVlZGJhY2tzIFx1MjAxNCB2YWx1ZSBpcyB1cGRhdGVkIG9uIGV2ZXJ5IENNRF9TRVRUSU5HU19QVVNIICgweDBiKSBmcm9tIHRoZSBkZXZpY2UuXG5cdCAqXG5cdCAqIEBwYXJhbSBpcCAgICAgICAgRGV2aWNlIElQIGFkZHJlc3Ncblx0ICogQHBhcmFtIGNtZElkICAgICBDb21tYW5kIElEIChlLmcuIENNRF9ERVZfU1BFQylcblx0ICogQHBhcmFtIHNldHRpbmdJZCBTZXR0aW5nIElEIChlLmcuIDB4MDIgZm9yIENvbnRyb2wgU291cmNlKVxuXHQgKiBAcGFyYW0gYnVzQ2ggICAgIE9wdGlvbmFsIGJ1cy9jaGFubmVsIElEIGZvciBtdWx0aS1jaGFubmVsIGNvbW1hbmRzXG5cdCAqL1xuXHRwdWJsaWMgZ2V0U2V0dGluZ1ZhbHVlKGlwOiBzdHJpbmcsIGNtZElkOiBudW1iZXIsIHNldHRpbmdJZDogbnVtYmVyLCBidXNDaD86IG51bWJlcik6IG51bWJlciB8IHVuZGVmaW5lZCB7XG5cdFx0Y29uc3Qga2V5ID0gbWFrZVNldHRpbmdJZCh0aGlzLm1vZGVsLCBjbWRJZCwgc2V0dGluZ0lkLCBidXNDaClcblx0XHRyZXR1cm4gdGhpcy5kZXZpY2VTdGF0ZS5nZXQoaXApPy5nZXQoa2V5KVxuXHR9XG5cblx0cHVibGljIGFzeW5jIHJlc2V0RGV2aWNlKGRlc3RJcDogc3RyaW5nKTogUHJvbWlzZTxCdWZmZXI+IHtcblx0XHRyZXR1cm4gdGhpcy5zZW5kQXdhaXRBY2soQ01EX1JFU0VUX0RFVklDRSwgdW5kZWZpbmVkLCAweDAwLCB1bmRlZmluZWQsIGRlc3RJcCwgZmFsc2UpXG5cdH1cblxuXHRwdWJsaWMgYXN5bmMgZ2xvYmFsTWljS2lsbChkZXN0SXA6IHN0cmluZyk6IFByb21pc2U8QnVmZmVyPiB7XG5cdFx0cmV0dXJuIHRoaXMuc2VuZEF3YWl0QWNrKENNRF9HTE9CQUxfTUlDX0tJTEwsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIGRlc3RJcCwgZmFsc2UpXG5cdH1cbn1cbiIsICJpbXBvcnQgZGdyYW0gZnJvbSAnZGdyYW0nXG5pbXBvcnQgb3MgZnJvbSAnb3MnXG5pbXBvcnQgeyBjcmVhdGVNb2R1bGVMb2dnZXIgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHR5cGUgeyBEZXZpY2VJbmZvIH0gZnJvbSAnLi90eXBlcy5qcydcblxuY29uc3QgbG9nZ2VyID0gY3JlYXRlTW9kdWxlTG9nZ2VyKCdEYW50ZScpXG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBEYW50ZSBkaXNjb3ZlcnkgY29uc3RhbnRzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG4vKiogRGFudGUgZGV2aWNlIGluZm8gcmVxdWVzdCBtZXNzYWdlIHR5cGUgKHNlbnQgdG8gcG9ydCA4NzAwKSAqL1xuY29uc3QgREFOVEVfTVNHX0lORk9fUkVRVUVTVCA9IDB4MDAyMFxuLyoqIERhbnRlIGRldmljZSBpbmZvIHJlc3BvbnNlIG1lc3NhZ2UgdHlwZSAocmVjZWl2ZWQgb24gcG9ydCA4NzAyKSAqL1xuZXhwb3J0IGNvbnN0IERBTlRFX01TR19JTkZPX1JFU1BPTlNFID0gMHgwMTcwXG5jb25zdCBEQU5URV9JTkZPX01JTl9MRU4gPSAweGNjICsgNjQgLy8gMjY4IGJ5dGVzIFx1MjAxNCBuZWVkIGZ1bGwgbW9kZWwgZmllbGRcblxuZnVuY3Rpb24gYnVpbGREYW50ZUluZm9SZXF1ZXN0KCk6IEJ1ZmZlciB7XG5cdGNvbnN0IGJ1ZiA9IEJ1ZmZlci5hbGxvYygzMiwgMClcblx0Y29uc3Qgc2VxID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMHhmZmZmKVxuXG5cdGJ1Zi53cml0ZVVJbnQxNkJFKDB4ZmZmZiwgMClcblx0YnVmLndyaXRlVUludDE2QkUoREFOVEVfTVNHX0lORk9fUkVRVUVTVCwgMilcblx0YnVmLndyaXRlVUludDE2QkUoc2VxLCA0KVxuXG5cdGNvbnN0IG1hYyA9IGdldEZpcnN0TG9jYWxNYWMoKVxuXHRtYWMuY29weShidWYsIDgpXG5cblx0QnVmZmVyLmZyb20oJ0F1ZGluYXRlJywgJ2FzY2lpJykuY29weShidWYsIDE2KVxuXHRidWYud3JpdGVVSW50MTZCRSgweDA3MzksIDI0KVxuXHRidWYud3JpdGVVSW50MTZCRSgweDAwYzEsIDI2KVxuXHRidWYud3JpdGVVSW50MzJCRSgweDAwMGY0MjQwLCAyOClcblxuXHRyZXR1cm4gYnVmXG59XG5cbi8qKiBSZXR1cm5zIHRoZSBmaXJzdCBub24tbG9vcGJhY2sgTUFDIGFzIGEgNi1ieXRlIEJ1ZmZlciwgb3IgemVyb3MuICovXG5mdW5jdGlvbiBnZXRGaXJzdExvY2FsTWFjKCk6IEJ1ZmZlciB7XG5cdHRyeSB7XG5cdFx0Y29uc3QgaWZhY2VzID0gb3MubmV0d29ya0ludGVyZmFjZXMoKVxuXHRcdGZvciAoY29uc3QgbmFtZSBvZiBPYmplY3Qua2V5cyhpZmFjZXMpKSB7XG5cdFx0XHRmb3IgKGNvbnN0IGFkZHIgb2YgaWZhY2VzW25hbWVdID8/IFtdKSB7XG5cdFx0XHRcdGlmICghYWRkci5pbnRlcm5hbCAmJiBhZGRyLmZhbWlseSA9PT0gJ0lQdjQnICYmIGFkZHIubWFjICYmIGFkZHIubWFjICE9PSAnMDA6MDA6MDA6MDA6MDA6MDAnKSB7XG5cdFx0XHRcdFx0cmV0dXJuIEJ1ZmZlci5mcm9tKGFkZHIubWFjLnNwbGl0KCc6JykubWFwKChoOiBzdHJpbmcpID0+IHBhcnNlSW50KGgsIDE2KSkpXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH0gY2F0Y2gge1xuXHRcdC8qIGlnbm9yZSAqL1xuXHR9XG5cdHJldHVybiBCdWZmZXIuYWxsb2MoNiwgMClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlRGFudGVJbmZvUmVzcG9uc2UobXNnOiBCdWZmZXIsIHNyY0lwOiBzdHJpbmcpOiBEZXZpY2VJbmZvIHwgbnVsbCB7XG5cdGlmIChtc2cubGVuZ3RoIDwgREFOVEVfSU5GT19NSU5fTEVOKSByZXR1cm4gbnVsbFxuXHRpZiAobXNnLnJlYWRVSW50MTZCRSgwKSAhPT0gMHhmZmZmKSByZXR1cm4gbnVsbFxuXHRpZiAobXNnLnJlYWRVSW50MTZCRSgyKSAhPT0gREFOVEVfTVNHX0lORk9fUkVTUE9OU0UpIHJldHVybiBudWxsXG5cdGlmIChtc2cuc3ViYXJyYXkoMTYsIDI0KS50b1N0cmluZygnYXNjaWknKSAhPT0gJ0F1ZGluYXRlJykgcmV0dXJuIG51bGxcblxuXHRjb25zdCByZWFkU3RyID0gKG9mZnNldDogbnVtYmVyLCBsZW46IG51bWJlcik6IHN0cmluZyA9PlxuXHRcdG1zZ1xuXHRcdFx0LnN1YmFycmF5KG9mZnNldCwgb2Zmc2V0ICsgbGVuKVxuXHRcdFx0LnRvU3RyaW5nKCdhc2NpaScpXG5cdFx0XHQuc3BsaXQoJ1xcMCcpWzBdXG5cdFx0XHQudHJpbSgpXG5cblx0Y29uc3QgZXVpNjQgPSBtc2cuc3ViYXJyYXkoOCwgMTYpXG5cdGNvbnN0IG1hY0J5dGVzID0gW2V1aTY0WzBdLCBldWk2NFsxXSwgZXVpNjRbMl0sIGV1aTY0WzVdLCBldWk2NFs2XSwgZXVpNjRbN11dXG5cdGNvbnN0IG1hYyA9IG1hY0J5dGVzLm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSkuam9pbignOicpXG5cblx0Y29uc3QgbmFtZSA9IHJlYWRTdHIoMHgyMCwgMzEpIC8vIERhbnRlIGRldmljZSBsYWJlbCAoY2FuIGJlIHVwIHRvIDMxIGNoYXJzIHBlciBEYW50ZSBzcGVjKVxuXHRjb25zdCBtYW51ZmFjdHVyZXIgPSByZWFkU3RyKDB4NGMsIDY0KSAvLyBlLmcuIFwiU3R1ZGlvIFRlY2hub2xvZ2llcywgSW5jLlwiXG5cdGNvbnN0IG1vZGVsUmF3ID0gcmVhZFN0cigweGNjLCA2NClcblx0Y29uc3QgZGFudGVGaXJtd2FyZSA9IGAke21zZ1sweDE4XX0uJHttc2dbMHgxOV19YFxuXG5cdGlmICghbW9kZWxSYXcpIHJldHVybiBudWxsXG5cblx0Ly8gRXh0cmFjdCBqdXN0IHRoZSBtb2RlbCBudW1iZXIvY29kZSAoZS5nLiBcIk1vZGVsIDM5MSBBbGVydGluZyBVbml0XCIgXHUyMTkyIFwiMzkxXCIpXG5cdC8vIFN0cmlwIFwiTW9kZWwgXCIgcHJlZml4LCB0aGVuIHRha2Ugb25seSB0aGUgZmlyc3Qgd29yZCAodGhlIG1vZGVsIG51bWJlcilcblx0Y29uc3QgbW9kZWwgPSBtb2RlbFJhd1xuXHRcdC5yZXBsYWNlKC9eTW9kZWxcXHMrL2ksICcnKVxuXHRcdC50cmltKClcblx0XHQuc3BsaXQoL1xccysvKVswXVxuXG5cdHJldHVybiB7XG5cdFx0aXA6IHNyY0lwLFxuXHRcdG5hbWUsXG5cdFx0bWFudWZhY3R1cmVyLFxuXHRcdG1vZGVsLFxuXHRcdG1vZGVsTmFtZTogbW9kZWxSYXcsIC8vIEZ1bGwgbW9kZWwgZGVzY3JpcHRpb25cblx0XHRtYWMsXG5cdFx0ZGFudGVGaXJtd2FyZSxcblx0fVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIE1BQyBhZGRyZXNzIGJ5dGVzIG9mIHRoZSBsb2NhbCBpbnRlcmZhY2UgdXNlZCB0byByb3V0ZSB0byBkZXN0SXAuXG4gKiBVc2VzIGEgdGVtcG9yYXJ5IFVEUCBjb25uZWN0IHRvIGxldCB0aGUgT1Mgc2VsZWN0IHRoZSBvdXRnb2luZyBpbnRlcmZhY2UsXG4gKiB0aGVuIGZpbmRzIHRoZSBtYXRjaGluZyBNQUMgZnJvbSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFjRm9yRGVzdGluYXRpb24oZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPG51bWJlcltdPiB7XG5cdHJldHVybiBuZXcgUHJvbWlzZTxudW1iZXJbXT4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGNvbnN0IHRtcCA9IGRncmFtLmNyZWF0ZVNvY2tldCgndWRwNCcpXG5cblx0XHR0bXAub25jZSgnZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0fSlcblxuXHRcdHRtcC5jb25uZWN0KDksIGRlc3RJcCwgKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3QgYWRkciA9IHRtcC5hZGRyZXNzKCkgYXMgeyBhZGRyZXNzOiBzdHJpbmcgfVxuXHRcdFx0XHRjb25zdCBsb2NhbEFkZHIgPSBhZGRyLmFkZHJlc3Ncblx0XHRcdFx0dG1wLmNsb3NlKClcblxuXHRcdFx0XHRjb25zdCBpZmFjZXMgPSBvcy5uZXR3b3JrSW50ZXJmYWNlcygpXG5cdFx0XHRcdGZvciAoY29uc3QgbmFtZSBvZiBPYmplY3Qua2V5cyhpZmFjZXMpKSB7XG5cdFx0XHRcdFx0Zm9yIChjb25zdCBpZmFjZSBvZiBpZmFjZXNbbmFtZV0gPz8gW10pIHtcblx0XHRcdFx0XHRcdGlmIChcblx0XHRcdFx0XHRcdFx0aWZhY2UuZmFtaWx5ID09PSAnSVB2NCcgJiZcblx0XHRcdFx0XHRcdFx0aWZhY2UuYWRkcmVzcyA9PT0gbG9jYWxBZGRyICYmXG5cdFx0XHRcdFx0XHRcdGlmYWNlLm1hYyAmJlxuXHRcdFx0XHRcdFx0XHRpZmFjZS5tYWMgIT09ICcwMDowMDowMDowMDowMDowMCdcblx0XHRcdFx0XHRcdCkge1xuXHRcdFx0XHRcdFx0XHRyZXR1cm4gcmVzb2x2ZShpZmFjZS5tYWMuc3BsaXQoJzonKS5tYXAoKGIpID0+IHBhcnNlSW50KGIsIDE2KSAmIDB4ZmYpKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKGBObyBpbnRlcmZhY2UgZm91bmQgZm9yIGxvY2FsIGFkZHJlc3MgJHtsb2NhbEFkZHJ9YCkpXG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRyZWplY3QobmV3IEVycm9yKFN0cmluZyhfZSkpKVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0pXG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgbG9jYWwgSVAgYWRkcmVzcyB1c2VkIGJ5IHRoZSBPUyB0byByb3V0ZSB0byBkZXN0SXAuXG4gKiBVc2VzIGEgdGVtcG9yYXJ5IFVEUCBzb2NrZXQgY29ubmVjdCB0byBsZXQgdGhlIE9TIHNlbGVjdCB0aGUgb3V0Z29pbmcgaW50ZXJmYWNlLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TG9jYWxBZGRyZXNzRm9yRGVzdGluYXRpb24oZGVzdElwOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuXHRyZXR1cm4gbmV3IFByb21pc2U8c3RyaW5nPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0Y29uc3QgdG1wID0gZGdyYW0uY3JlYXRlU29ja2V0KCd1ZHA0JylcblxuXHRcdGxldCByZXNvbHZlZCA9IGZhbHNlXG5cdFx0dG1wLm9uY2UoJ2Vycm9yJywgKGVycikgPT4ge1xuXHRcdFx0aWYgKCFyZXNvbHZlZCkge1xuXHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0cmVqZWN0KG5ldyBFcnJvcihlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSkpXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdC8vIFVzZSBhbiBhcmJpdHJhcnkgcG9ydCBmb3IgY29ubmVjdDsgd2Ugb25seSBuZWVkIHRoZSBrZXJuZWwgdG8gYXNzaWduIGEgbG9jYWwgYWRkcmVzcy5cblx0XHR0bXAuY29ubmVjdCg5LCBkZXN0SXAsICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IGFkZHIgPSB0bXAuYWRkcmVzcygpIGFzIHsgYWRkcmVzczogc3RyaW5nIH1cblx0XHRcdFx0Y29uc3QgbG9jYWxBZGRyID0gYWRkci5hZGRyZXNzXG5cdFx0XHRcdGlmICghcmVzb2x2ZWQpIHtcblx0XHRcdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdFx0XHR0bXAuY2xvc2UoKVxuXHRcdFx0XHRcdHJlc29sdmUobG9jYWxBZGRyKVxuXHRcdFx0XHR9XG5cdFx0XHR9IGNhdGNoIChfZSkge1xuXHRcdFx0XHRpZiAoIXJlc29sdmVkKSB7XG5cdFx0XHRcdFx0cmVzb2x2ZWQgPSB0cnVlXG5cdFx0XHRcdFx0dG1wLmNsb3NlKClcblx0XHRcdFx0XHRyZWplY3QobmV3IEVycm9yKFN0cmluZyhfZSkpKVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSlcblx0fSlcbn1cblxuLyoqXG4gKiBMaXN0ZW5zIGZvciBEYW50ZSBkZXZpY2UgYW5ub3VuY2VzIG9uIHRoZSBsb2NhbCBuZXR3b3JrIGFuZCBzZW5kcyB1bmljYXN0XG4gKiBpbmZvIHJlcXVlc3RzIHRvIGVhY2ggZGlzY292ZXJlZCBJUC4gUmVzcG9uc2VzIGFycml2ZSBvbiB0aGUgY2FsbGVyJ3MgcnhTb2NrZXRcbiAqIHZpYSBoYW5kbGVJbmNvbWluZygpIFx1MjE5MiBkaXNjb3ZlcnlMaXN0ZW5lcnMuXG4gKlxuICogQHBhcmFtIHR4U29ja2V0IC0gVGhlIHNvY2tldCB0byB1c2UgZm9yIHNlbmRpbmcgZGlzY292ZXJ5IHJlcXVlc3RzXG4gKiBAcGFyYW0gZW5zdXJlTWVtYmVyc2hpcCAtIENhbGxiYWNrIHRvIGVuc3VyZSBtdWx0aWNhc3QgbWVtYmVyc2hpcCBiZWZvcmUgcXVlcnlpbmdcbiAqIEBwYXJhbSB0aW1lb3V0TXMgLSBIb3cgbG9uZyB0byBsaXN0ZW4gZm9yIGFubm91bmNlcyBiZWZvcmUgcmVzb2x2aW5nXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkaXNjb3ZlckRldmljZXMoXG5cdHR4U29ja2V0OiBkZ3JhbS5Tb2NrZXQsXG5cdGVuc3VyZU1lbWJlcnNoaXA6IChkZXN0SXA6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPixcblx0dGltZW91dE1zID0gNTAwMCxcbik6IFByb21pc2U8dm9pZD4ge1xuXHRjb25zdCBEQU5URV9BTk5PVU5DRV9HUk9VUCA9ICcyMjQuMC4wLjIzMydcblx0Y29uc3QgREFOVEVfQU5OT1VOQ0VfUE9SVCA9IDg3MDhcblx0Y29uc3QgREVGQVVMVF9QT1JUID0gODcwMFxuXG5cdGNvbnN0IHF1ZXJpZWRJcHMgPSBuZXcgU2V0PHN0cmluZz4oKVxuXG5cdHJldHVybiBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuXHRcdGNvbnN0IGFubm91bmNlU29ja2V0ID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblx0XHRjb25zdCBqb2luZWRJbnRlcmZhY2VzOiBzdHJpbmdbXSA9IFtdXG5cblx0XHRjb25zdCBjbGVhbnVwID0gKCkgPT4ge1xuXHRcdFx0Zm9yIChjb25zdCBpZmFjZSBvZiBqb2luZWRJbnRlcmZhY2VzKSB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuZHJvcE1lbWJlcnNoaXAoREFOVEVfQU5OT1VOQ0VfR1JPVVAsIGlmYWNlKVxuXHRcdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0XHQvKiBpZ25vcmUgKi9cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YW5ub3VuY2VTb2NrZXQuY2xvc2UoKVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdFx0cmVzb2x2ZSgpXG5cdFx0fVxuXG5cdFx0Y29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KGNsZWFudXAsIHRpbWVvdXRNcylcblx0XHR0aW1lci51bnJlZj8uKClcblxuXHRcdGFubm91bmNlU29ja2V0Lm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRcdGxvZ2dlci53YXJuKGBBbm5vdW5jZSBzb2NrZXQgZXJyb3I6ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHR9KVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQub24oJ21lc3NhZ2UnLCAobXNnLCByaW5mbykgPT4ge1xuXHRcdFx0Y29uc3Qgc3JjSXAgPSByaW5mby5hZGRyZXNzXG5cdFx0XHQvLyBWYWxpZGF0ZSBpdCdzIGEgRGFudGUgYW5ub3VuY2UgKG1hZ2ljIDB4ZmZmZSArIFwiQXVkaW5hdGVcIiBhdCBvZmZzZXQgMTYpXG5cdFx0XHRpZiAobXNnLmxlbmd0aCA8IDI0KSByZXR1cm5cblx0XHRcdGlmIChtc2cucmVhZFVJbnQxNkJFKDApICE9PSAweGZmZmUpIHJldHVyblxuXHRcdFx0aWYgKG1zZy5zdWJhcnJheSgxNiwgMjQpLnRvU3RyaW5nKCdhc2NpaScpICE9PSAnQXVkaW5hdGUnKSByZXR1cm5cblxuXHRcdFx0aWYgKHF1ZXJpZWRJcHMuaGFzKHNyY0lwKSkgcmV0dXJuXG5cdFx0XHRxdWVyaWVkSXBzLmFkZChzcmNJcClcblx0XHRcdGxvZ2dlci5kZWJ1ZyhgQW5ub3VuY2UgZnJvbSAke3NyY0lwfSBcdTIwMTQgc2VuZGluZyB1bmljYXN0IHF1ZXJ5YClcblxuXHRcdFx0Ly8gSm9pbiAyMjQuMC4wLjIzMSBvbiB0aGUgaW50ZXJmYWNlIHRoYXQgcm91dGVzIHRvIHRoaXMgZGV2aWNlIEJFRk9SRSBzZW5kaW5nXG5cdFx0XHQvLyB0aGUgcXVlcnkuIFRoZSBkZXZpY2UgbXVsdGljYXN0cyBpdHMgMHgwMTcwIHJlc3BvbnNlIHRvIDIyNC4wLjAuMjMxOjg3MDJcblx0XHRcdC8vIGluIGFkZGl0aW9uIHRvIHVuaWNhc3RpbmcgaXQgXHUyMDE0IHJ4U29ja2V0IG11c3QgYmUgYSBtZW1iZXIgdG8gcmVjZWl2ZSBpdC5cblx0XHRcdGNvbnN0IHNlbmRRdWVyeSA9IGFzeW5jICgpID0+IHtcblx0XHRcdFx0YXdhaXQgZW5zdXJlTWVtYmVyc2hpcChzcmNJcClcblx0XHRcdFx0Y29uc3QgcXVlcnkgPSBidWlsZERhbnRlSW5mb1JlcXVlc3QoKVxuXHRcdFx0XHR0eFNvY2tldC5zZW5kKHF1ZXJ5LCBERUZBVUxUX1BPUlQsIHNyY0lwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdFx0aWYgKGVycikgbG9nZ2VyLndhcm4oYFVuaWNhc3QgcXVlcnkgdG8gJHtzcmNJcH0gZmFpbGVkOiAke2Vyci5tZXNzYWdlfWApXG5cdFx0XHRcdH0pXG5cdFx0XHR9XG5cdFx0XHRzZW5kUXVlcnkoKS5jYXRjaCgoZXJyKSA9PiBsb2dnZXIud2FybihgUXVlcnkgc2V0dXAgZmFpbGVkOiAke2Vycn1gKSlcblx0XHR9KVxuXG5cdFx0YW5ub3VuY2VTb2NrZXQuYmluZChEQU5URV9BTk5PVU5DRV9QT1JULCAoKSA9PiB7XG5cdFx0XHQvLyBKb2luIDIyNC4wLjAuMjMzIG9uIGV2ZXJ5IG5vbi1sb29wYmFjayBJUHY0IGludGVyZmFjZSBzbyB0aGF0IGFubm91bmNlc1xuXHRcdFx0Ly8gYXJlIHJlY2VpdmVkIHJlZ2FyZGxlc3Mgb2Ygd2hpY2ggaW50ZXJmYWNlIHRoZSBkZXZpY2UgaXMgb24uXG5cdFx0XHQvLyBPbiBXaW5kb3dzIHdpdGggbXVsdGlwbGUgaW50ZXJmYWNlcyAoZS5nLiBIeXBlci1WICsgTEFOKSwgdGhlIE9TIGRlZmF1bHRcblx0XHRcdC8vIG11bHRpY2FzdCBpbnRlcmZhY2UgbWF5IG5vdCBiZSB0aGUgb25lIGNvbm5lY3RlZCB0byB0aGUgRGFudGUgbmV0d29yay5cblx0XHRcdGNvbnN0IGlmYWNlcyA9IG9zLm5ldHdvcmtJbnRlcmZhY2VzKClcblx0XHRcdGZvciAoY29uc3QgYWRkcnMgb2YgT2JqZWN0LnZhbHVlcyhpZmFjZXMpKSB7XG5cdFx0XHRcdGZvciAoY29uc3QgYWRkciBvZiBhZGRycyA/PyBbXSkge1xuXHRcdFx0XHRcdGlmIChhZGRyLmZhbWlseSA9PT0gJ0lQdjQnICYmICFhZGRyLmludGVybmFsKSB7XG5cdFx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0XHRhbm5vdW5jZVNvY2tldC5hZGRNZW1iZXJzaGlwKERBTlRFX0FOTk9VTkNFX0dST1VQLCBhZGRyLmFkZHJlc3MpXG5cdFx0XHRcdFx0XHRcdGpvaW5lZEludGVyZmFjZXMucHVzaChhZGRyLmFkZHJlc3MpXG5cdFx0XHRcdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0XHRcdFx0LyogaWdub3JlIFx1MjAxNCBpbnRlcmZhY2UgbWF5IG5vdCBzdXBwb3J0IG11bHRpY2FzdCAqL1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKGpvaW5lZEludGVyZmFjZXMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBDb3VsZCBub3Qgam9pbiBhbm5vdW5jZSBtdWx0aWNhc3QgZ3JvdXAgb24gYW55IGludGVyZmFjZWApXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRsb2dnZXIuZGVidWcoYExpc3RlbmluZyBmb3IgRGFudGUgYW5ub3VuY2VzIG9uICR7REFOVEVfQU5OT1VOQ0VfR1JPVVB9OiR7REFOVEVfQU5OT1VOQ0VfUE9SVH1gKVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0pXG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBEZXZpY2UgcHJvYmUgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbi8qKlxuICogU2VuZHMgYSB1bmljYXN0IERhbnRlIGluZm8gcmVxdWVzdCB0byBhIHNwZWNpZmljIElQIGFuZCB3YWl0cyBmb3IgdGhlIGRldmljZSBpbmZvXG4gKiByZXNwb25zZS4gVXNlZCB0byB2ZXJpZnkgYSBtYW51YWxseSBjb25maWd1cmVkIElQLlxuICpcbiAqIEBwYXJhbSB0eFNvY2tldCAgICAgICAgIEJvdW5kIHNvY2tldCB0byBzZW5kIHRoZSBxdWVyeSBmcm9tXG4gKiBAcGFyYW0gcmVnaXN0ZXJMaXN0ZW5lciBSZWdpc3RlciBhIGNhbGxiYWNrIChrZXllZCkgdG8gcmVjZWl2ZSBwYXJzZWQgRGV2aWNlSW5mbyByZXNwb25zZXNcbiAqIEBwYXJhbSByZW1vdmVMaXN0ZW5lciAgIFJlbW92ZSBhIHByZXZpb3VzbHkgcmVnaXN0ZXJlZCBsaXN0ZW5lciBieSBrZXlcbiAqIEBwYXJhbSBlbnN1cmVNZW1iZXJzaGlwIEVuc3VyZSBtdWx0aWNhc3QgbWVtYmVyc2hpcCBvbiB0aGUgb3V0Z29pbmcgaW50ZXJmYWNlXG4gKiBAcGFyYW0gaXAgICAgICAgICAgICAgICBUYXJnZXQgZGV2aWNlIElQXG4gKiBAcGFyYW0gdGltZW91dE1zICAgICAgICBUaW1lb3V0IGluIG1pbGxpc2Vjb25kc1xuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJvYmVEZXZpY2UoXG5cdHR4U29ja2V0OiBkZ3JhbS5Tb2NrZXQsXG5cdHJlZ2lzdGVyTGlzdGVuZXI6IChrZXk6IHN0cmluZywgY2I6IChkZXZpY2U6IERldmljZUluZm8pID0+IHZvaWQpID0+IHZvaWQsXG5cdHJlbW92ZUxpc3RlbmVyOiAoa2V5OiBzdHJpbmcpID0+IHZvaWQsXG5cdGVuc3VyZU1lbWJlcnNoaXA6IChpcDogc3RyaW5nKSA9PiBQcm9taXNlPHZvaWQ+LFxuXHRpcDogc3RyaW5nLFxuXHR0aW1lb3V0TXMgPSAzMDAwLFxuKTogUHJvbWlzZTxEZXZpY2VJbmZvIHwgbnVsbD4ge1xuXHRyZXR1cm4gbmV3IFByb21pc2U8RGV2aWNlSW5mbyB8IG51bGw+KChyZXNvbHZlKSA9PiB7XG5cdFx0Y29uc3Qga2V5ID0gYF9fcHJvYmVfJHtpcH1fX2Bcblx0XHRsZXQgcmVzb2x2ZWQgPSBmYWxzZVxuXG5cdFx0Y29uc3QgZmluaXNoID0gKHJlc3VsdDogRGV2aWNlSW5mbyB8IG51bGwpID0+IHtcblx0XHRcdGlmIChyZXNvbHZlZCkgcmV0dXJuXG5cdFx0XHRyZXNvbHZlZCA9IHRydWVcblx0XHRcdHJlbW92ZUxpc3RlbmVyKGtleSlcblx0XHRcdHJlc29sdmUocmVzdWx0KVxuXHRcdH1cblxuXHRcdHJlZ2lzdGVyTGlzdGVuZXIoa2V5LCAoZGV2aWNlOiBEZXZpY2VJbmZvKSA9PiB7XG5cdFx0XHRpZiAoZGV2aWNlLmlwID09PSBpcCkgZmluaXNoKGRldmljZSlcblx0XHR9KVxuXG5cdFx0Y29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IGZpbmlzaChudWxsKSwgdGltZW91dE1zKVxuXHRcdHRpbWVyLnVucmVmPy4oKVxuXG5cdFx0Y29uc3QgcnVuID0gYXN5bmMgKCkgPT4ge1xuXHRcdFx0YXdhaXQgZW5zdXJlTWVtYmVyc2hpcChpcClcblx0XHRcdGNvbnN0IHF1ZXJ5ID0gYnVpbGREYW50ZUluZm9SZXF1ZXN0KClcblx0XHRcdHR4U29ja2V0LnNlbmQocXVlcnksIDg3MDAsIGlwLCAoZXJyKSA9PiB7XG5cdFx0XHRcdGlmIChlcnIpIHtcblx0XHRcdFx0XHRsb2dnZXIud2FybihgUHJvYmUgdG8gJHtpcH0gZmFpbGVkOiAke2Vyci5tZXNzYWdlfWApXG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKVxuXHRcdFx0XHRcdGZpbmlzaChudWxsKVxuXHRcdFx0XHR9XG5cdFx0XHR9KVxuXHRcdH1cblxuXHRcdHJ1bigpLmNhdGNoKChlKSA9PiB7XG5cdFx0XHRsb2dnZXIud2FybihgcHJvYmVEZXZpY2Ugc2V0dXAgZmFpbGVkIGZvciAke2lwfTogJHtlfWApXG5cdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRmaW5pc2gobnVsbClcblx0XHR9KVxuXHR9KVxufVxuIiwgImltcG9ydCBkZ3JhbSBmcm9tICdkZ3JhbSdcbmltcG9ydCB7IGNyZWF0ZU1vZHVsZUxvZ2dlciB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBnZXRNYWNGb3JEZXN0aW5hdGlvbiwgZ2V0TG9jYWxBZGRyZXNzRm9yRGVzdGluYXRpb24gfSBmcm9tICcuL2RhbnRlLmpzJ1xuXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVNb2R1bGVMb2dnZXIoJ0Nvbk1vbicpXG5cbi8qKiBDb2FsZXNjZXMgY29uY3VycmVudCBvcGVuQ29uTW9uU2Vzc2lvbiBjYWxscyBwZXIgSVAgKi9cbmNvbnN0IF9jb25tb25QZW5kaW5nID0gbmV3IE1hcDxzdHJpbmcsIFByb21pc2U8KCgpID0+IHZvaWQpIHwgbnVsbD4+KClcblxuLyoqXG4gKiBPcGVucyBhIERhbnRlIENvbk1vbiBzZXNzaW9uIHdpdGggdGhlIGRldmljZSBvbiBwb3J0IDg4MDAuXG4gKiBPbmx5IG5lZWRlZCBmb3IgZGV2aWNlcyB3aXRoIFwidXNlQ29uTW9uXCI6IHRydWUgaW4gdGhlaXIgZGV2aWNlIEpTT04uXG4gKiBSZXR1cm5zIGEgY2xlYW51cCBmdW5jdGlvbiB0byBzdG9wIGtlZXBhbGl2ZXMgYW5kIGNsb3NlIHRoZSBzb2NrZXQsIG9yIG51bGwgb24gZmFpbHVyZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG9wZW5Db25Nb25TZXNzaW9uKGRldmljZUlwOiBzdHJpbmcsIHRpbWVvdXRNcyA9IDMwMDApOiBQcm9taXNlPCgoKSA9PiB2b2lkKSB8IG51bGw+IHtcblx0Y29uc3QgcGVuZGluZyA9IF9jb25tb25QZW5kaW5nLmdldChkZXZpY2VJcClcblx0aWYgKHBlbmRpbmcpIHJldHVybiBwZW5kaW5nXG5cblx0Y29uc3QgcHJvbWlzZSA9IF9kb0Nvbk1vblNlc3Npb24oZGV2aWNlSXAsIHRpbWVvdXRNcykuZmluYWxseSgoKSA9PiB7XG5cdFx0X2Nvbm1vblBlbmRpbmcuZGVsZXRlKGRldmljZUlwKVxuXHR9KVxuXHRfY29ubW9uUGVuZGluZy5zZXQoZGV2aWNlSXAsIHByb21pc2UpXG5cdHJldHVybiBwcm9taXNlXG59XG5cbmFzeW5jIGZ1bmN0aW9uIF9kb0Nvbk1vblNlc3Npb24oZGV2aWNlSXA6IHN0cmluZywgdGltZW91dE1zOiBudW1iZXIpOiBQcm9taXNlPCgoKSA9PiB2b2lkKSB8IG51bGw+IHtcblx0cmV0dXJuIG5ldyBQcm9taXNlPCgoKSA9PiB2b2lkKSB8IG51bGw+KChyZXNvbHZlKSA9PiB7XG5cdFx0bGV0IHNldHRsZWQgPSBmYWxzZVxuXHRcdGxldCBrZWVwYWxpdmVUaW1lcjogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGxcblxuXHRcdGNvbnN0IGNsb3NlU2Vzc2lvbiA9IChzb2NrOiBkZ3JhbS5Tb2NrZXQpID0+IHtcblx0XHRcdGlmIChrZWVwYWxpdmVUaW1lcikge1xuXHRcdFx0XHRjbGVhckludGVydmFsKGtlZXBhbGl2ZVRpbWVyKVxuXHRcdFx0XHRrZWVwYWxpdmVUaW1lciA9IG51bGxcblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdHNvY2suY2xvc2UoKVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdC8qIGlnbm9yZSAqL1xuXHRcdFx0fVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBDb25Nb24gc2Vzc2lvbiBjbG9zZWQgZm9yICR7ZGV2aWNlSXB9YClcblx0XHR9XG5cblx0XHRjb25zdCBmYWlsID0gKHNvY2s6IGRncmFtLlNvY2tldCkgPT4ge1xuXHRcdFx0aWYgKHNldHRsZWQpIHJldHVyblxuXHRcdFx0c2V0dGxlZCA9IHRydWVcblx0XHRcdGNsZWFyVGltZW91dCh0aW1lcilcblx0XHRcdGNsb3NlU2Vzc2lvbihzb2NrKVxuXHRcdFx0bG9nZ2VyLmRlYnVnKGBDb25Nb24gc2Vzc2lvbiBub3QgZXN0YWJsaXNoZWQgZm9yICR7ZGV2aWNlSXB9YClcblx0XHRcdHJlc29sdmUobnVsbClcblx0XHR9XG5cblx0XHRjb25zdCBzb2NrID0gZGdyYW0uY3JlYXRlU29ja2V0KHsgdHlwZTogJ3VkcDQnLCByZXVzZUFkZHI6IHRydWUgfSlcblx0XHRjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4gZmFpbChzb2NrKSwgdGltZW91dE1zKVxuXG5cdFx0c29jay5vbignZXJyb3InLCAoZXJyKSA9PiB7XG5cdFx0XHRsb2dnZXIud2FybihgQ29uTW9uIHNvY2tldCBlcnJvciBmb3IgJHtkZXZpY2VJcH06ICR7ZXJyLm1lc3NhZ2V9YClcblx0XHRcdGZhaWwoc29jaylcblx0XHR9KVxuXG5cdFx0c29jay5vbignbWVzc2FnZScsIChtc2c6IEJ1ZmZlcikgPT4ge1xuXHRcdFx0Ly8gRGV2aWNlIEFDSzogdHlwZSBieXRlIDB4MjAgYXQgb2Zmc2V0IDNcblx0XHRcdGlmICghc2V0dGxlZCAmJiBtc2cubGVuZ3RoID49IDQgJiYgbXNnWzBdID09PSAweDEyICYmIG1zZ1szXSA9PT0gMHgyMCkge1xuXHRcdFx0XHRzZXR0bGVkID0gdHJ1ZVxuXHRcdFx0XHRjbGVhclRpbWVvdXQodGltZXIpXG5cdFx0XHRcdGxvZ2dlci5pbmZvKGBDb25Nb24gc2Vzc2lvbiBlc3RhYmxpc2hlZCB3aXRoICR7ZGV2aWNlSXB9YClcblxuXHRcdFx0XHRsZXQga2VlcGFsaXZlU2VxID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMHhmZmZlKSArIDFcblx0XHRcdFx0Y29uc3Qgc2VuZEtlZXBhbGl2ZSA9ICgpID0+IHtcblx0XHRcdFx0XHRjb25zdCBwa3QgPSBCdWZmZXIuYWxsb2MoMjAsIDApXG5cdFx0XHRcdFx0cGt0WzBdID0gMHgxMlxuXHRcdFx0XHRcdHBrdFszXSA9IDB4NGVcblx0XHRcdFx0XHRwa3Qud3JpdGVVSW50MTZCRShrZWVwYWxpdmVTZXErKyAmIDB4ZmZmZiwgNClcblx0XHRcdFx0XHRwa3RbNl0gPSAweDMwXG5cdFx0XHRcdFx0cGt0WzddID0gMHgxMFxuXHRcdFx0XHRcdHNvY2suc2VuZChwa3QsIDg4MDAsIGRldmljZUlwLCAoKSA9PiB7XG5cdFx0XHRcdFx0XHQvKiBmaXJlIGFuZCBmb3JnZXQgKi9cblx0XHRcdFx0XHR9KVxuXHRcdFx0XHR9XG5cdFx0XHRcdGtlZXBhbGl2ZVRpbWVyID0gc2V0SW50ZXJ2YWwoc2VuZEtlZXBhbGl2ZSwgMTAwMClcblx0XHRcdFx0cmVzb2x2ZSgoKSA9PiBjbG9zZVNlc3Npb24oc29jaykpXG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdGNvbnN0IGRvSW5pdCA9IGFzeW5jICgpID0+IHtcblx0XHRcdGxldCBsb2NhbElwOiBzdHJpbmdcblx0XHRcdGxldCBsb2NhbE1hYzogbnVtYmVyW11cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGxvY2FsSXAgPSBhd2FpdCBnZXRMb2NhbEFkZHJlc3NGb3JEZXN0aW5hdGlvbihkZXZpY2VJcClcblx0XHRcdFx0bG9jYWxNYWMgPSBhd2FpdCBnZXRNYWNGb3JEZXN0aW5hdGlvbihkZXZpY2VJcClcblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYENvbk1vbjogY291bGQgbm90IGdldCBsb2NhbCBuZXR3b3JrIGluZm8gZm9yICR7ZGV2aWNlSXB9OiAke2V9YClcblx0XHRcdFx0ZmFpbChzb2NrKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblxuXHRcdFx0c29jay5iaW5kKHsgcG9ydDogODgwMCwgYWRkcmVzczogbG9jYWxJcCB9LCAoKSA9PiB7XG5cdFx0XHRcdGNvbnN0IHNlcSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDB4ZmZmZSkgKyAxXG5cdFx0XHRcdGNvbnN0IHBrdCA9IEJ1ZmZlci5hbGxvYygyMCwgMClcblx0XHRcdFx0cGt0WzBdID0gMHgxMlxuXHRcdFx0XHRwa3RbM10gPSAweDE0XG5cdFx0XHRcdHBrdC53cml0ZVVJbnQxNkJFKHNlcSwgNClcblx0XHRcdFx0cGt0WzZdID0gMHgxMFxuXHRcdFx0XHRwa3RbN10gPSAweDAxXG5cdFx0XHRcdGxvY2FsTWFjLmZvckVhY2goKGIsIGkpID0+IHtcblx0XHRcdFx0XHRwa3RbMTIgKyBpXSA9IGJcblx0XHRcdFx0fSlcblx0XHRcdFx0bG9nZ2VyLmRlYnVnKGBDb25Nb24gVFggdG8gJHtkZXZpY2VJcH06ICR7cGt0LnRvU3RyaW5nKCdoZXgnKX1gKVxuXHRcdFx0XHRzb2NrLnNlbmQocGt0LCA4ODAwLCBkZXZpY2VJcCwgKGVycikgPT4ge1xuXHRcdFx0XHRcdGlmIChlcnIpIHtcblx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKGBDb25Nb24gc2VuZCBmYWlsZWQgZm9yICR7ZGV2aWNlSXB9OiAke2Vyci5tZXNzYWdlfWApXG5cdFx0XHRcdFx0XHRmYWlsKHNvY2spXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9KVxuXHRcdFx0fSlcblx0XHR9XG5cblx0XHRkb0luaXQoKS5jYXRjaCgoZSkgPT4ge1xuXHRcdFx0bG9nZ2VyLndhcm4oYENvbk1vbiBpbml0IGZhaWxlZCBmb3IgJHtkZXZpY2VJcH06ICR7ZX1gKVxuXHRcdFx0ZmFpbChzb2NrKVxuXHRcdH0pXG5cdH0pXG59XG4iLCAiaW1wb3J0IHtcblx0SW5zdGFuY2VUeXBlcyxcblx0SW5zdGFuY2VCYXNlLFxuXHRJbnN0YW5jZVN0YXR1cyxcblx0U29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkLFxuXHRjcmVhdGVNb2R1bGVMb2dnZXIsXG59IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBHZXRDb25maWdGaWVsZHMsIHJlc29sdmVIb3N0LCByZXNvbHZlTW9kZWwsIGdldERldmljZVNjaGVtYSwgdHlwZSBNb2R1bGVDb25maWcgfSBmcm9tICcuL2NvbmZpZy5qcydcbmltcG9ydCB7IFVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMsIFVwZGF0ZVZhcmlhYmxlVmFsdWVzIH0gZnJvbSAnLi92YXJpYWJsZXMuanMnXG5pbXBvcnQgeyBVcGdyYWRlU2NyaXB0cyB9IGZyb20gJy4vdXBncmFkZXMuanMnXG5pbXBvcnQgeyBVcGRhdGVBY3Rpb25zIH0gZnJvbSAnLi9hY3Rpb25zLmpzJ1xuaW1wb3J0IHsgVXBkYXRlRmVlZGJhY2tzIH0gZnJvbSAnLi9mZWVkYmFja3MuanMnXG5pbXBvcnQgeyBTdENvbnRyb2xsZXIgfSBmcm9tICcuL3N0Y29udHJvbGxlci5qcydcbmltcG9ydCB0eXBlIHsgRGV2aWNlSW5mbyB9IGZyb20gJy4vdHlwZXMuanMnXG5cbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZU1vZHVsZUxvZ2dlcignTW9kdWxlSW5zdGFuY2UnKVxuXG5leHBvcnQgdHlwZSBNb2R1bGVUeXBlcyA9IEluc3RhbmNlVHlwZXMgJiB7XG5cdGNvbmZpZzogTW9kdWxlQ29uZmlnXG59XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1vZHVsZUluc3RhbmNlIGV4dGVuZHMgSW5zdGFuY2VCYXNlPE1vZHVsZVR5cGVzPiB7XG5cdGNvbmZpZyE6IE1vZHVsZUNvbmZpZyAvLyBTZXR1cCBpbiBpbml0KClcblx0c3RDb250cm9sbGVyITogU3RDb250cm9sbGVyXG5cblx0LyoqIENhY2hlZCBkaXNjb3ZlcnkgcmVzdWx0cyBcdTIwMTQgcGFzc2VkIGludG8gZ2V0Q29uZmlnRmllbGRzKCkgc28gdGhlIFVJXG5cdCAqICBjYW4gc2hvdyB0aGUgZGlzY292ZXJlZCBkZXZpY2UgZHJvcGRvd24gb24gc3Vic2VxdWVudCBjb25maWcgb3BlbnMuICovXG5cdHByaXZhdGUgZGlzY292ZXJlZERldmljZXM6IERldmljZUluZm9bXSA9IFtdXG5cblx0LyoqIEN1cnJlbnRseSBhY3RpdmUgbW9kZWwgXHUyMDE0IHJlc29sdmVkIG9uY2UgaW4gc3luY01vZGVsKCkgYW5kIGNhY2hlZCBoZXJlXG5cdCAqICBzbyBVcGRhdGVBY3Rpb25zLCBVcGRhdGVGZWVkYmFja3MgZXRjLiBkb24ndCBlYWNoIGNhbGwgcmVzb2x2ZU1vZGVsIGluZGVwZW5kZW50bHkuICovXG5cdGFjdGl2ZU1vZGVsOiBzdHJpbmcgPSAnJ1xuXG5cdGNvbnN0cnVjdG9yKGludGVybmFsOiB1bmtub3duKSB7XG5cdFx0c3VwZXIoaW50ZXJuYWwpXG5cdH1cblxuXHRhc3luYyBpbml0KGNvbmZpZzogTW9kdWxlQ29uZmlnKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dGhpcy5jb25maWcgPSBjb25maWdcblx0XHRpZiAoIXRoaXMuc3RDb250cm9sbGVyKSB7XG5cdFx0XHR0aGlzLnN0Q29udHJvbGxlciA9IG5ldyBTdENvbnRyb2xsZXIoKVxuXHRcdH1cblx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5Db25uZWN0aW5nLCAnRGlzY292ZXJpbmcgZGV2aWNlcy4uLicpXG5cblx0XHQvLyBXaXJlIGZlZWRiYWNrIGNhbGxiYWNrIHNvIHN0Q29udHJvbGxlciBjYW4gdHJpZ2dlciBmZWVkYmFjayB1cGRhdGVzXG5cdFx0dGhpcy5zdENvbnRyb2xsZXIuc2V0RmVlZGJhY2tDYWxsYmFjaygoZmVlZGJhY2tJZDogc3RyaW5nKSA9PiB7XG5cdFx0XHR0aGlzLmNoZWNrRmVlZGJhY2tzKGZlZWRiYWNrSWQpXG5cdFx0fSlcblxuXHRcdC8vIFN0YXJ0IGRpc2NvdmVyeSBpbiB0aGUgYmFja2dyb3VuZCBcdTIwMTQgYWxsIG1vZGVsIHJlc29sdXRpb24sIHNjaGVtYSBzeW5jLFxuXHRcdC8vIGFuZCBVSSB1cGRhdGVzIGhhcHBlbiBpbnNpZGUgcnVuRGlzY292ZXJ5KCkgb25jZSB0aGUgZGV2aWNlIGxpc3QgaXMga25vd24uXG5cdFx0dGhpcy5ydW5EaXNjb3ZlcnkoKS5jYXRjaCgoZSkgPT4ge1xuXHRcdFx0bG9nZ2VyLmVycm9yKGBEaXNjb3ZlcnkgZmFpbGVkOiAke2V9YClcblx0XHR9KVxuXHR9XG5cblx0LyoqXG5cdCAqIFJ1biBkZXZpY2UgZGlzY292ZXJ5LCB0aGVuIHJlc29sdmUgdGhlIG1vZGVsIGFuZCB1cGRhdGUgYWxsIFVJLlxuXHQgKiAtIElmIGRpc2NvdmVyeSBmaW5kcyBkZXZpY2VzLCByZXNvbHZlTW9kZWwgcGlja3MgZnJvbSB0aG9zZS5cblx0ICogLSBPbmx5IGlmIHRoZSBsaXN0IGlzIGVtcHR5IGRvIHdlIGZhbGwgYmFjayB0byB0aGUgbWFudWFsIGNvbmZpZyBzZWxlY3Rpb24uXG5cdCAqIEFsbCBhY3Rpb25zL2ZlZWRiYWNrcy92YXJpYWJsZXMgYXJlIGJ1aWx0IGFmdGVyIHRoZSBtb2RlbCBpcyBrbm93bi5cblx0ICovXG5cdHByaXZhdGUgYXN5bmMgcnVuRGlzY292ZXJ5KCk6IFByb21pc2U8dm9pZD4ge1xuXHRcdGxvZ2dlci5pbmZvKCdTdGFydGluZyBkZXZpY2UgZGlzY292ZXJ5Li4uJylcblxuXHRcdHRoaXMuZGlzY292ZXJlZERldmljZXMgPSBhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5kaXNjb3ZlckRldmljZXMoKVxuXG5cdFx0Ly8gRGV0ZXJtaW5lIGVmZmVjdGl2ZSBtb2RlbCBcdTIwMTQgZnJvbSBkaXNjb3ZlcmVkIGRldmljZXMgZmlyc3QsIG1hbnVhbCBjb25maWcgb25seSBhcyBmYWxsYmFja1xuXHRcdGxldCBlZmZlY3RpdmVNb2RlbDogc3RyaW5nXG5cdFx0aWYgKHRoaXMuZGlzY292ZXJlZERldmljZXMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRpZiAodGhpcy5jb25maWcuZGV2aWNlTWFjKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBTYXZlZCBkZXZpY2UgTUFDIFwiJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XCIgbm90IGZvdW5kIGR1cmluZyBkaXNjb3ZlcnkgXHUyMDE0IHN0b3BwaW5nYClcblx0XHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuQ29ubmVjdGlvbkZhaWx1cmUsIGBbJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XSBub3QgZm91bmRgKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHRcdGNvbnN0IG1hbnVhbE1vZGVsID0gdGhpcy5jb25maWcuYWN0aXZlTW9kZWxcblx0XHRcdGlmICghdGhpcy5jb25maWcuaG9zdCB8fCAhbWFudWFsTW9kZWwpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oJ05vIGRldmljZXMgZGlzY292ZXJlZCBhbmQgbm8gbWFudWFsIElQL21vZGVsIGNvbmZpZ3VyZWQnKVxuXHRcdFx0XHRyZXR1cm5cblx0XHRcdH1cblx0XHRcdGxvZ2dlci5pbmZvKCdObyBkZXZpY2VzIGRpc2NvdmVyZWQgXHUyMDE0IHdpbGwgcHJvYmUgbWFudWFsIElQIGR1cmluZyBhdXRob3JpemF0aW9uJylcblx0XHRcdGVmZmVjdGl2ZU1vZGVsID0gbWFudWFsTW9kZWxcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYERpc2NvdmVyZWQgJHt0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmxlbmd0aH0gZGV2aWNlKHMpOmApXG5cdFx0XHRmb3IgKGNvbnN0IGQgb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHRsb2dnZXIuaW5mbyhgICAtIE1vZGVsICR7ZC5tb2RlbH0gJHtkLm1hbnVmYWN0dXJlciA/PyAnJ30gQCAke2QuaXB9YClcblx0XHRcdH1cblxuXHRcdFx0Ly8gQXV0aG9yaXplIGFsbCBkaXNjb3ZlcmVkIGRldmljZXMgc28gZmlybXdhcmUgcmVxdWVzdHMgY2FuIHByb2NlZWQuXG5cdFx0XHQvLyB2ZXJpZnlBdXRob3JpemF0aW9uIChjYWxsZWQgYmVsb3cpIHdpbGwgcmV2b2tlIGFueSB0aGF0IGRvbid0IG1hdGNoXG5cdFx0XHQvLyB0aGUgY3VycmVudCBjb25maWcgc2VsZWN0aW9uLlxuXHRcdFx0Zm9yIChjb25zdCBkZXZpY2Ugb2YgdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcykge1xuXHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5hdXRob3JpemVEZXZpY2UoZGV2aWNlLmlwKVxuXHRcdFx0fVxuXG5cdFx0XHQvLyBSZXF1ZXN0IGZpcm13YXJlIHZlcnNpb24gZnJvbSBlYWNoIGRpc2NvdmVyZWQgZGV2aWNlXG5cdFx0XHRmb3IgKGNvbnN0IGRldmljZSBvZiB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKSB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0Y29uc3QgZmlybXdhcmUgPSBhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5yZXF1ZXN0RmlybXdhcmVWZXJzaW9uKGRldmljZS5pcClcblx0XHRcdFx0XHRkZXZpY2UuZmlybXdhcmVNYWluID0gZmlybXdhcmVcblx0XHRcdFx0XHRsb2dnZXIuaW5mbyhgICAtICR7ZGV2aWNlLmlwfTogRmlybXdhcmUgJHtmaXJtd2FyZX0sIERhbnRlICR7ZGV2aWNlLmRhbnRlRmlybXdhcmV9YClcblx0XHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRcdGxvZ2dlci53YXJuKGAgIC0gJHtkZXZpY2UuaXB9OiBGYWlsZWQgdG8gZ2V0IGZpcm13YXJlOiAke2V9YClcblx0XHRcdFx0XHRkZXZpY2UuZmlybXdhcmVNYWluID0gJ1Vua25vd24nXG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0ZWZmZWN0aXZlTW9kZWwgPSByZXNvbHZlTW9kZWwodGhpcy5jb25maWcsIHRoaXMuZGlzY292ZXJlZERldmljZXMpXG5cblx0XHRcdGlmICghZWZmZWN0aXZlTW9kZWwgJiYgdGhpcy5jb25maWcuZGV2aWNlTWFjKSB7XG5cdFx0XHRcdGxvZ2dlci53YXJuKGBTYXZlZCBkZXZpY2UgTUFDIFwiJHt0aGlzLmNvbmZpZy5kZXZpY2VNYWN9XCIgbm90IGZvdW5kIGFtb25nIGRpc2NvdmVyZWQgZGV2aWNlcyBcdTIwMTQgc3RvcHBpbmdgKVxuXHRcdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5Db25uZWN0aW9uRmFpbHVyZSwgYFske3RoaXMuY29uZmlnLmRldmljZU1hY31dIG5vdCBmb3VuZGApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIFN5bmMgbW9kZWwgc2NoZW1hIHRvIGNvbnRyb2xsZXJcblx0XHR0aGlzLnN5bmNNb2RlbChlZmZlY3RpdmVNb2RlbClcblxuXHRcdC8vIFZlcmlmeSB0aGF0IHRoZSBjdXJyZW50bHkgY29uZmlndXJlZCBob3N0K21vZGVsIGlzIHZhbGlkIG5vdyB0aGF0XG5cdFx0Ly8gZGlzY292ZXJ5IHJlc3VsdHMgYXJlIGtub3duLiBUaGlzIGlzIHRoZSBzYW1lIGNoZWNrIGNvbmZpZ1VwZGF0ZWQgdXNlcy5cblx0XHRjb25zdCB0YXJnZXRIb3N0ID0gdGhpcy5ob3N0XG5cdFx0YXdhaXQgdGhpcy52ZXJpZnlBdXRob3JpemF0aW9uKCcnLCB0YXJnZXRIb3N0KVxuXG5cdFx0Ly8gQnVpbGQgYWxsIFVJIG5vdyB0aGF0IG1vZGVsIGFuZCBhdXRob3JpemF0aW9uIHN0YXRlIGFyZSBrbm93blxuXHRcdHRoaXMudXBkYXRlQWN0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVGZWVkYmFja3MoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZVZhbHVlcygpXG5cblx0XHRsb2dnZXIuaW5mbygnRGV2aWNlIGRpc2NvdmVyeSBjb21wbGV0ZScpXG5cdH1cblxuXHQvLyBXaGVuIG1vZHVsZSBnZXRzIGRlbGV0ZWRcblx0YXN5bmMgZGVzdHJveSgpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0aGlzLnN0Q29udHJvbGxlcj8uY2xvc2UoKVxuXHRcdGxvZ2dlci5kZWJ1ZygnZGVzdHJveScpXG5cdH1cblxuXHRhc3luYyBjb25maWdVcGRhdGVkKGNvbmZpZzogTW9kdWxlQ29uZmlnKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0Y29uc3QgcHJldmlvdXNIb3N0ID0gdGhpcy5ob3N0XG5cdFx0dGhpcy5jb25maWcgPSBjb25maWdcblx0XHRjb25zdCBlZmZlY3RpdmVNb2RlbCA9IHJlc29sdmVNb2RlbChjb25maWcsIHRoaXMuZGlzY292ZXJlZERldmljZXMpXG5cdFx0dGhpcy5zeW5jTW9kZWwoZWZmZWN0aXZlTW9kZWwpXG5cblx0XHQvLyBDbGVhciB2YXJpYWJsZXMgaW1tZWRpYXRlbHkgXHUyMDE0IHRoZSBuZXcgc2VsZWN0aW9uIGlzbid0IGF1dGhvcml6ZWQgeWV0LlxuXHRcdC8vIFRoZXknbGwgYmUgcmVwb3B1bGF0ZWQgYmVsb3cgb25jZSB2ZXJpZnlBdXRob3JpemF0aW9uIGNvbXBsZXRlcy5cblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlVmFsdWVzKClcblxuXHRcdGNvbnN0IG5ld0hvc3QgPSB0aGlzLmhvc3RcblxuXHRcdC8vIFJlLXZlcmlmeSBhdXRob3JpemF0aW9uIG9uIGV2ZXJ5IGNvbmZpZyBjaGFuZ2UgKG1vZGVsIG9yIElQKS5cblx0XHQvLyBUaGlzIGhhbmRsZXMgc3dpdGNoaW5nIGZyb20gYSB2YWxpZCBkZXZpY2UgdG8gYW4gaW52YWxpZCBvbmUgYW5kIGJhY2suXG5cdFx0YXdhaXQgdGhpcy52ZXJpZnlBdXRob3JpemF0aW9uKHByZXZpb3VzSG9zdCwgbmV3SG9zdClcblxuXHRcdC8vIFJlYnVpbGQgVUkgYWZ0ZXIgYXV0aG9yaXphdGlvbiBzdGF0ZSBpcyBzZXR0bGVkXG5cdFx0dGhpcy51cGRhdGVBY3Rpb25zKClcblx0XHR0aGlzLnVwZGF0ZUZlZWRiYWNrcygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKClcblx0XHR0aGlzLnVwZGF0ZVZhcmlhYmxlVmFsdWVzKClcblx0fVxuXG5cdC8qKlxuXHQgKiBSZS1ldmFsdWF0ZXMgd2hldGhlciB0aGUgY3VycmVudCBjb25maWcgaXMgYXV0aG9yaXplZCB0byBzZW5kIGNvbW1hbmRzLlxuXHQgKlxuXHQgKiBBdXRvIG1vZGUgKGRldmljZU1hYyBzZXQpOlxuXHQgKiAgIC0gRmluZCB0aGUgZGlzY292ZXJlZCBkZXZpY2Ugd2l0aCBtYXRjaGluZyBNQUMgXHUyMTkyIGdldCBpdHMgY3VycmVudCBJUFxuXHQgKiAgIC0gUmV2b2tlIHRoZSBwcmV2aW91cyBJUCwgYXV0aG9yaXplIHRoZSBuZXcgSVBcblx0ICogICAtIElmIE1BQyBub3QgZm91bmQgaW4gZGlzY292ZXJ5LCByZXZva2UgYW5kIGJsb2NrXG5cdCAqXG5cdCAqIE1hbnVhbCBtb2RlIChkZXZpY2VNYWMgZW1wdHkpOlxuXHQgKiAgIC0gQ2hlY2sgZGlzY292ZXJlZCBsaXN0IGJ5IElQK21vZGVsIG1hdGNoLCBvciBwcm9iZSBkaXJlY3RseVxuXHQgKi9cblx0cHJpdmF0ZSBhc3luYyB2ZXJpZnlBdXRob3JpemF0aW9uKHByZXZpb3VzSG9zdDogc3RyaW5nLCBuZXdIb3N0OiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHRpZiAoIW5ld0hvc3QpIHtcblx0XHRcdGlmIChwcmV2aW91c0hvc3QpIHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRpZiAodGhpcy5jb25maWcuZGV2aWNlTWFjKSB7XG5cdFx0XHQvLyBBdXRvIG1vZGUgXHUyMDE0IG1hdGNoIGJ5IE1BQywgdXNlIHdoYXRldmVyIElQIGRpc2NvdmVyeSBmb3VuZCBpdCBhdFxuXHRcdFx0Y29uc3QgZGV2aWNlID0gdGhpcy5kaXNjb3ZlcmVkRGV2aWNlcy5maW5kKChkKSA9PiBkLm1hYyA9PT0gdGhpcy5jb25maWcuZGV2aWNlTWFjKVxuXHRcdFx0aWYgKCFkZXZpY2UpIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oYERldmljZSBNQUMgXCIke3RoaXMuY29uZmlnLmRldmljZU1hY31cIiBub3QgZm91bmQgaW4gY3VycmVudCBkaXNjb3ZlcnkgXHUyMDE0IG5vdCBhdXRob3JpemluZ2ApXG5cdFx0XHRcdGlmIChwcmV2aW91c0hvc3QpIHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXG5cdFx0XHRpZiAocHJldmlvdXNIb3N0ICYmIHByZXZpb3VzSG9zdCAhPT0gbmV3SG9zdCkge1xuXHRcdFx0XHR0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UocHJldmlvdXNIb3N0KVxuXHRcdFx0fVxuXHRcdFx0Y29uc3Qgd2FzQXV0aG9yaXplZCA9IHRoaXMuc3RDb250cm9sbGVyLmlzRGV2aWNlQXV0aG9yaXplZChuZXdIb3N0KVxuXHRcdFx0aWYgKCF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShuZXdIb3N0KVxuXHRcdFx0fVxuXHRcdFx0aWYgKG5ld0hvc3QgIT09IHByZXZpb3VzSG9zdCB8fCAhd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHRhd2FpdCB0aGlzLmZldGNoU2V0dGluZ3NBbmRFbnN1cmVTY2hlbWEoZGV2aWNlLm1vZGVsLCBuZXdIb3N0KVxuXHRcdFx0fVxuXHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuT2ssIGBNb2RlbCAke2RldmljZS5tb2RlbH0gQCAke25ld0hvc3R9YClcblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdC8vIE1hbnVhbCBtb2RlIFx1MjAxNCBjb25maWcuaG9zdCArIGNvbmZpZy5hY3RpdmVNb2RlbCBtdXN0IG1hdGNoXG5cdFx0Y29uc3QgbWFudWFsTW9kZWwgPSBTdHJpbmcodGhpcy5jb25maWcuYWN0aXZlTW9kZWwgPz8gJycpXG5cdFx0Y29uc3QgZGlzY292ZXJlZEF0SXAgPSB0aGlzLmRpc2NvdmVyZWREZXZpY2VzLmZpbmQoKGQpID0+IGQuaXAgPT09IG5ld0hvc3QpXG5cblx0XHRpZiAoZGlzY292ZXJlZEF0SXApIHtcblx0XHRcdGlmIChkaXNjb3ZlcmVkQXRJcC5tb2RlbCA9PT0gbWFudWFsTW9kZWwpIHtcblx0XHRcdFx0aWYgKHByZXZpb3VzSG9zdCAmJiBwcmV2aW91c0hvc3QgIT09IG5ld0hvc3QpIHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShwcmV2aW91c0hvc3QpXG5cdFx0XHRcdGNvbnN0IHdhc0F1dGhvcml6ZWQgPSB0aGlzLnN0Q29udHJvbGxlci5pc0RldmljZUF1dGhvcml6ZWQobmV3SG9zdClcblx0XHRcdFx0aWYgKCF3YXNBdXRob3JpemVkKSB7XG5cdFx0XHRcdFx0dGhpcy5zdENvbnRyb2xsZXIuYXV0aG9yaXplRGV2aWNlKG5ld0hvc3QpXG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKG5ld0hvc3QgIT09IHByZXZpb3VzSG9zdCB8fCAhd2FzQXV0aG9yaXplZCkge1xuXHRcdFx0XHRcdGF3YWl0IHRoaXMuZmV0Y2hTZXR0aW5nc0FuZEVuc3VyZVNjaGVtYShtYW51YWxNb2RlbCwgbmV3SG9zdClcblx0XHRcdFx0fVxuXHRcdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5PaywgYE1vZGVsICR7bWFudWFsTW9kZWx9IEAgJHtuZXdIb3N0fWApXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRsb2dnZXIuZXJyb3IoXG5cdFx0XHRcdFx0YERldmljZSBzZWxlY3RlZCAoTW9kZWwgJHttYW51YWxNb2RlbH0pIGRvZXMgbm90IG1hdGNoIGRldGVjdGVkIGRldmljZSAoTW9kZWwgJHtkaXNjb3ZlcmVkQXRJcC5tb2RlbH0pIGF0ICR7bmV3SG9zdH0gXHUyMDE0IGNvbW1hbmRzIGJsb2NrZWRgLFxuXHRcdFx0XHQpXG5cdFx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnJldm9rZURldmljZShuZXdIb3N0KVxuXHRcdFx0XHR0aGlzLnVwZGF0ZVN0YXR1cyhcblx0XHRcdFx0XHRJbnN0YW5jZVN0YXR1cy5Db25uZWN0aW9uRmFpbHVyZSxcblx0XHRcdFx0XHRgTW9kZWwgbWlzbWF0Y2g6IGV4cGVjdGVkICR7bWFudWFsTW9kZWx9LCBnb3QgJHtkaXNjb3ZlcmVkQXRJcC5tb2RlbH1gLFxuXHRcdFx0XHQpXG5cdFx0XHR9XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBJUCBub3QgaW4gZGlzY292ZXJlZCBsaXN0IFx1MjAxNCBwcm9iZSBpdCBkaXJlY3RseSB2aWEgRGFudGVcblx0XHRsb2dnZXIuaW5mbyhgJHtuZXdIb3N0fSBub3QgaW4gZGlzY292ZXJlZCBsaXN0IFx1MjAxNCBwcm9iaW5nYClcblx0XHRpZiAocHJldmlvdXNIb3N0ICYmIHByZXZpb3VzSG9zdCAhPT0gbmV3SG9zdCkgdGhpcy5zdENvbnRyb2xsZXIucmV2b2tlRGV2aWNlKHByZXZpb3VzSG9zdClcblx0XHR0aGlzLnN0Q29udHJvbGxlci5yZXZva2VEZXZpY2UobmV3SG9zdClcblxuXHRcdGNvbnN0IHByb2JlZCA9IGF3YWl0IHRoaXMuc3RDb250cm9sbGVyLnByb2JlRGV2aWNlKG5ld0hvc3QpXG5cdFx0aWYgKCFwcm9iZWQpIHtcblx0XHRcdGxvZ2dlci5lcnJvcihgTm8gZGV2aWNlIHJlc3BvbmRlZCBhdCAke25ld0hvc3R9IFx1MjAxNCBjb21tYW5kcyBibG9ja2VkYClcblx0XHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLlVua25vd25XYXJuaW5nLCBgRGV2aWNlIG9mZmxpbmU6ICR7bmV3SG9zdH1gKVxuXHRcdH0gZWxzZSBpZiAocHJvYmVkLm1vZGVsICE9PSBtYW51YWxNb2RlbCkge1xuXHRcdFx0bG9nZ2VyLmVycm9yKFxuXHRcdFx0XHRgRGV2aWNlIHNlbGVjdGVkIChNb2RlbCAke21hbnVhbE1vZGVsfSkgZG9lcyBub3QgbWF0Y2ggZGV0ZWN0ZWQgZGV2aWNlIChNb2RlbCAke3Byb2JlZC5tb2RlbH0pIGF0ICR7bmV3SG9zdH0gXHUyMDE0IGNvbW1hbmRzIGJsb2NrZWRgLFxuXHRcdFx0KVxuXHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoXG5cdFx0XHRcdEluc3RhbmNlU3RhdHVzLkNvbm5lY3Rpb25GYWlsdXJlLFxuXHRcdFx0XHRgTW9kZWwgbWlzbWF0Y2g6IGV4cGVjdGVkICR7bWFudWFsTW9kZWx9LCBnb3QgJHtwcm9iZWQubW9kZWx9YCxcblx0XHRcdClcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmluZm8oYFZlcmlmaWVkIE1vZGVsICR7cHJvYmVkLm1vZGVsfSBhdCAke25ld0hvc3R9YClcblx0XHRcdHRoaXMuc3RDb250cm9sbGVyLmF1dGhvcml6ZURldmljZShuZXdIb3N0KVxuXHRcdFx0YXdhaXQgdGhpcy5mZXRjaFNldHRpbmdzQW5kRW5zdXJlU2NoZW1hKG1hbnVhbE1vZGVsLCBuZXdIb3N0KVxuXHRcdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuT2ssIGBNb2RlbCAke3Byb2JlZC5tb2RlbH0gQCAke25ld0hvc3R9YClcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogRmV0Y2hlcyBhbGwgc2V0dGluZ3MgZnJvbSB0aGUgZGV2aWNlLiBJZiBubyBzY2hlbWEgZXhpc3RzIGZvciB0aGUgbW9kZWwsXG5cdCAqIGNyZWF0ZXMgb25lIGZyb20gdGhlIHJlc3BvbnNlIGFuZCByZWxvYWRzIHRoZSBzY2hlbWEgY2FjaGUuXG5cdCAqL1xuXHRwcml2YXRlIGFzeW5jIGZldGNoU2V0dGluZ3NBbmRFbnN1cmVTY2hlbWEobW9kZWw6IHN0cmluZywgaXA6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRyeSB7XG5cdFx0XHRhd2FpdCB0aGlzLnN0Q29udHJvbGxlci5yZXF1ZXN0QWxsU2V0dGluZ3MoaXApXG5cblx0XHRcdGlmICghZ2V0RGV2aWNlU2NoZW1hKG1vZGVsKSkge1xuXHRcdFx0XHQvLyBObyBzY2hlbWEgZXhpc3RzIFx1MjAxNCBkbyBOT1QgYXV0by1jcmVhdGUgb25lIGhlcmUuXG5cdFx0XHRcdC8vIFRoZSB1c2VyIG11c3QgcnVuIFwiR0xPQkFMOiBHZXQgQWxsIFNldHRpbmdzXCIgdG8gY3JlYXRlIGl0LlxuXHRcdFx0XHRsb2dnZXIud2FybihgTm8gc2NoZW1hIGZvdW5kIGZvciBNb2RlbCAke21vZGVsfSBcdTIwMTQgcnVuIFwiR0xPQkFMOiBHZXQgQWxsIFNldHRpbmdzXCIgdG8gY3JlYXRlIG9uZWApXG5cdFx0XHRcdHJldHVyblxuXHRcdFx0fVxuXHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBGYWlsZWQgdG8gZmV0Y2ggc2V0dGluZ3MgZnJvbSAke2lwfTogJHtlfWApXG5cdFx0fVxuXHR9XG5cblx0LyoqIExvYWRzIHRoZSBkZXZpY2UgSlNPTiBmb3IgdGhlIGdpdmVuIG1vZGVsLCBjYWNoZXMgaXQgYXMgYWN0aXZlTW9kZWwsIGFuZCBwdXNoZXMgaXQgdG8gdGhlIGNvbnRyb2xsZXIuICovXG5cdHByaXZhdGUgc3luY01vZGVsKG1vZGVsOiBzdHJpbmcpOiB2b2lkIHtcblx0XHR0aGlzLmFjdGl2ZU1vZGVsID0gbW9kZWxcblx0XHRjb25zdCBzY2hlbWEgPSBnZXREZXZpY2VTY2hlbWEobW9kZWwpXG5cdFx0aWYgKCFzY2hlbWEpIHtcblx0XHRcdGxvZ2dlci53YXJuKGBNb2RlbCBcIiR7bW9kZWx9XCIgbm90IGZvdW5kIGluIGRldmljZSBzY2hlbWFzYClcblx0XHRcdHRoaXMuc3RDb250cm9sbGVyLnNldE1vZGVsKG1vZGVsLCBbXSlcblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdGNvbnN0IGFjdGlvbnMgPSBBcnJheS5pc0FycmF5KHNjaGVtYS5jbWRTY2hlbWEpID8gc2NoZW1hLmNtZFNjaGVtYSA6IFtdXG5cblx0XHR0aGlzLnN0Q29udHJvbGxlci5zZXRNb2RlbChtb2RlbCwgYWN0aW9ucylcblx0XHRpZiAoYWN0aW9ucy5sZW5ndGggPT09IDApIHtcblx0XHRcdGxvZ2dlci53YXJuKGBObyBhY3Rpb25zIGZvdW5kIGZvciBtb2RlbCBcIiR7bW9kZWx9XCIgXHUyMDE0IHNldHRpbmdzIGRlY29kaW5nIHdpbGwgdXNlIHJhdyBJRHNgKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRsb2dnZXIuZGVidWcoYExvYWRlZCAke2FjdGlvbnMubGVuZ3RofSBhY3Rpb25zIGZvciBtb2RlbCBcIiR7bW9kZWx9XCJgKVxuXHRcdH1cblx0fVxuXG5cdGdldENvbmZpZ0ZpZWxkcygpOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdFx0cmV0dXJuIEdldENvbmZpZ0ZpZWxkcyh0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHR9XG5cblx0LyoqIFJldHVybnMgdGhlIGVmZmVjdGl2ZSBob3N0IElQLCByZXNvbHZlZCBmcm9tIE1BQ1x1MjE5MklQIHZpYSBkaXNjb3ZlcmVkRGV2aWNlcyAoYXV0bykgb3IgY29uZmlnLmhvc3QgKG1hbnVhbCkuICovXG5cdGdldCBob3N0KCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIHJlc29sdmVIb3N0KHRoaXMuY29uZmlnLCB0aGlzLmRpc2NvdmVyZWREZXZpY2VzKVxuXHR9XG5cblx0LyoqIFJldHVybnMgZGlzY292ZXJlZCBkZXZpY2VzIGZvciB1c2UgaW4gYWN0aW9ucy9jb25maWcgKi9cblx0Z2V0IGRldmljZXMoKTogRGV2aWNlSW5mb1tdIHtcblx0XHRyZXR1cm4gdGhpcy5kaXNjb3ZlcmVkRGV2aWNlc1xuXHR9XG5cblx0dXBkYXRlQWN0aW9ucygpOiB2b2lkIHtcblx0XHRVcGRhdGVBY3Rpb25zKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVGZWVkYmFja3MoKTogdm9pZCB7XG5cdFx0VXBkYXRlRmVlZGJhY2tzKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKCk6IHZvaWQge1xuXHRcdFVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnModGhpcylcblx0fVxuXG5cdHVwZGF0ZVZhcmlhYmxlVmFsdWVzKCk6IHZvaWQge1xuXHRcdFVwZGF0ZVZhcmlhYmxlVmFsdWVzKHRoaXMpXG5cdH1cbn1cblxuZXhwb3J0IHsgVXBncmFkZVNjcmlwdHMgfVxuIl0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7QUFrQkEsSUFBTSxxQkFBa0MsQ0FBQyxRQUFRLE9BQU8sWUFBVztBQUVsRSxVQUFRLElBQUksSUFBSSxNQUFNLFlBQVcsQ0FBRSxJQUFJLFNBQVMsS0FBSyxNQUFNLE1BQU0sRUFBRSxJQUFJLE9BQU8sRUFBRTtBQUNqRjtBQUVBLFNBQVMsVUFBVSxRQUE0QixPQUFpQixTQUFlO0FBQzlFLFFBQU0sT0FBTyxPQUFPLE9BQU8scUJBQXFCLGFBQWEsT0FBTyxtQkFBbUI7QUFDdkYsT0FBSyxRQUFRLE9BQU8sT0FBTztBQUM1QjtBQU9NLFNBQVUsbUJBQW1CLFFBQWU7QUFDakQsU0FBTztJQUNOLE9BQU8sQ0FBQyxZQUFvQixVQUFVLFFBQVEsU0FBUyxPQUFPO0lBQzlELE1BQU0sQ0FBQyxZQUFvQixVQUFVLFFBQVEsUUFBUSxPQUFPO0lBQzVELE1BQU0sQ0FBQyxZQUFvQixVQUFVLFFBQVEsUUFBUSxPQUFPO0lBQzVELE9BQU8sQ0FBQyxZQUFvQixVQUFVLFFBQVEsU0FBUyxPQUFPOztBQUVoRTs7O0FDVE0sU0FBVSxZQUFZLE1BQVc7QUFFdkM7QUF5Qk0sU0FBVSxXQUFXLEdBQVcsR0FBVyxHQUFXLEdBQVU7QUFDckUsTUFBSSxlQUF3QixJQUFJLFFBQVMsTUFBUSxJQUFJLFFBQVMsSUFBTSxJQUFJO0FBQ3hFLE1BQUksS0FBSyxLQUFLLEtBQUssSUFBSSxHQUFHO0FBQ3pCLG1CQUFlLFdBQVksS0FBSyxNQUFNLE9BQU8sSUFBSSxFQUFFO0VBQ3BEO0FBQ0EsU0FBTztBQUNSOzs7QUMvREEsU0FBUyxvQkFBb0I7QUEyRXZCLElBQU8sc0JBQVAsY0FBbUMsYUFBbUM7RUFDbEU7RUFDQTtFQUVULElBQVcsV0FBUTtBQUNsQixXQUFPLEtBQUssWUFBWTtFQUN6QjtFQUNBLElBQVcsYUFBVTtBQUNwQixXQUFPLEtBQUssWUFBWTtFQUN6QjtFQUVBLElBQVksYUFBVTtBQUNyQixRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVyxVQUFVO0FBQ25ELGFBQU8sS0FBSztJQUNiLE9BQU87QUFDTixhQUFPO0lBQ1I7RUFDRDtFQUVBLFNBQXVFO0VBRXZFLFlBQVksU0FBeUMsU0FBK0I7QUFDbkYsVUFBSztBQUVMLFNBQUssV0FBVztBQUNoQixTQUFLLFdBQVcsRUFBRSxHQUFHLFFBQU87RUFDN0I7RUFFQSxLQUFLLE1BQWMsVUFBbUIsVUFBcUI7QUFDMUQsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVc7QUFBVSxZQUFNLElBQUksTUFBTSx5QkFBeUI7QUFDN0YsWUFBUSxLQUFLLFFBQVE7TUFDcEIsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLG9DQUFvQztNQUNyRCxLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0seUJBQXlCO01BQzFDLEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSxtQkFBbUI7TUFDcEMsS0FBSztBQUNKO01BQ0Q7QUFDQyxvQkFBWSxLQUFLLE1BQU07QUFDdkIsY0FBTSxJQUFJLE1BQU0sc0JBQXNCO0lBQ3hDO0FBRUEsU0FBSyxTQUFTO0FBRWQsUUFBSTtBQUFVLFdBQUssR0FBRyxhQUFhLFFBQVE7QUFFM0MsU0FBSyxTQUNILG9CQUFvQjtNQUNwQixRQUFRLEtBQUssU0FBUztNQUN0QixZQUFZOztLQUVaLEVBQ0EsS0FDQSxDQUFDLGFBQVk7QUFDWixXQUFLLFNBQVMsRUFBRSxZQUFZLE1BQU0sU0FBUTtBQUMxQyxXQUFLLFNBQVMsd0JBQXdCLElBQUksVUFBVSxJQUFJO0FBQ3hELFdBQUssS0FBSyxXQUFXO0lBQ3RCLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxTQUFTO0FBQ2QsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFFQSxNQUFNLFVBQXFCO0FBQzFCLFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXLFVBQVU7SUFFcEQsT0FBTztBQUNOLGNBQVEsS0FBSyxRQUFRO1FBQ3BCLEtBQUs7QUFDSixnQkFBTSxJQUFJLE1BQU0sb0NBQW9DO1FBQ3JELEtBQUs7UUFDTCxLQUFLO1FBQ0wsS0FBSztBQUNKLGdCQUFNLElBQUksTUFBTSxvQkFBb0I7UUFDckM7QUFDQyxzQkFBWSxLQUFLLE1BQU07QUFDdkIsZ0JBQU0sSUFBSSxNQUFNLHNCQUFzQjtNQUN4QztJQUNEO0FBRUEsVUFBTSxXQUFXLEtBQUssT0FBTztBQUM3QixTQUFLLFNBQVM7QUFFZCxRQUFJO0FBQVUsV0FBSyxHQUFHLFNBQVMsUUFBUTtBQUV2QyxTQUFLLFNBQ0gscUJBQXFCO01BQ3JCO0tBQ0EsRUFDQSxLQUNBLE1BQUs7QUFDSixXQUFLLFNBQVMsd0JBQXdCLE9BQU8sUUFBUTtBQUNyRCxXQUFLLEtBQUssT0FBTztJQUNsQixHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxRQUFRO0FBQ3JELFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBV0EsS0FDQyxjQUNBLGNBQ0EsaUJBQ0EsZ0JBQ0EsU0FDQSxVQUFxQjtBQUVyQixRQUFJLE9BQU8saUJBQWlCO0FBQVUsWUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ3pFLFFBQUksT0FBTyxvQkFBb0IsVUFBVTtBQUN4QyxVQUFJLE9BQU8sbUJBQW1CLFlBQVksT0FBTyxZQUFZO0FBQVUsY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQzFHLFVBQUksYUFBYSxVQUFhLE9BQU8sYUFBYTtBQUFZLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUVqRyxZQUFNLFNBQVMsS0FBSyxlQUFlLGNBQWMsY0FBYyxlQUFlO0FBQzlFLFdBQUssV0FBVyxRQUFRLGdCQUFnQixTQUFTLFFBQVE7SUFDMUQsV0FBVyxPQUFPLG9CQUFvQixVQUFVO0FBQy9DLFVBQUksbUJBQW1CLFVBQWEsT0FBTyxtQkFBbUI7QUFBWSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFFN0csWUFBTSxTQUFTLEtBQUssZUFBZSxjQUFjLEdBQUcsTUFBUztBQUM3RCxXQUFLLFdBQVcsUUFBUSxjQUFjLGlCQUFpQixjQUFjO0lBQ3RFLE9BQU87QUFDTixZQUFNLElBQUksTUFBTSxtQkFBbUI7SUFDcEM7RUFDRDtFQUVBLGVBQ0MsY0FDQSxRQUNBLFFBQTBCO0FBRTFCLFFBQUk7QUFDSixRQUFJLE9BQU8saUJBQWlCLFVBQVU7QUFDckMsZUFBUyxPQUFPLEtBQUssY0FBYyxPQUFPO0lBQzNDLFdBQVcsT0FBTyxTQUFTLFlBQVksR0FBRztBQUN6QyxlQUFTO0lBQ1YsV0FBVyxNQUFNLFFBQVEsWUFBWSxHQUFHO0FBRXZDLGFBQU8sT0FBTyxLQUFLLFlBQVk7SUFDaEMsT0FBTztBQUNOLGVBQVMsT0FBTyxLQUFLLGFBQWEsUUFBUSxhQUFhLFlBQVksYUFBYSxVQUFVO0lBQzNGO0FBRUEsV0FBTyxPQUFPLFNBQVMsUUFBUSxXQUFXLFNBQVksU0FBUyxTQUFTLE1BQVM7RUFDbEY7RUFFQSxXQUFXLFFBQWdCLE1BQWMsU0FBaUIsVUFBcUI7QUFDOUUsUUFBSSxDQUFDLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVztBQUFVLFlBQU0sSUFBSSxNQUFNLG9CQUFvQjtBQUV6RixTQUFLLFNBQ0gsb0JBQW9CO01BQ3BCLFVBQVUsS0FBSyxPQUFPO01BQ3RCLFNBQVM7TUFFVDtNQUNBO0tBQ0EsRUFDQSxLQUNBLE1BQUs7QUFDSixpQkFBVTtJQUNYLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFFQSxxQkFBcUIsU0FBK0I7QUFDbkQsUUFBSTtBQUNILFdBQUssS0FBSyxXQUFXLFFBQVEsU0FBUyxRQUFRLE1BQU07SUFDckQsU0FBUyxJQUFJO0lBRWI7RUFDRDtFQUNBLG1CQUFtQixPQUFZO0FBQzlCLFNBQUssU0FBUztBQUVkLFVBQU0sYUFBYSxLQUFLO0FBQ3hCLFFBQUk7QUFBWSxXQUFLLFNBQVMsd0JBQXdCLE9BQU8sV0FBVyxRQUFRO0FBRWhGLFFBQUk7QUFDSCxXQUFLLEtBQUssU0FBUyxLQUFLO0lBQ3pCLFNBQVMsSUFBSTtJQUViO0VBQ0Q7Ozs7QUM5UEssU0FBVSxrQkFBbUQsS0FBWTtBQUM5RSxRQUFNLE9BQU87QUFDYixTQUFPLENBQUMsQ0FBQyxRQUFRLE9BQU8sU0FBUyxZQUFZLE9BQU8sS0FBSyxPQUFPLFlBQVksS0FBSyx1QkFBdUI7QUFDekc7OztBQzZCTSxJQUFnQixlQUFoQixNQUE0QjtFQUN4QjtFQUNBO0VBRUE7RUFFVCxJQUFXLEtBQUU7QUFDWixXQUFPLEtBQUssU0FBUztFQUN0QjtFQUVBLElBQVcsa0JBQWU7QUFDekIsV0FBTyxLQUFLO0VBQ2I7Ozs7O0VBTUEsSUFBVyxRQUFLO0FBQ2YsV0FBTyxLQUFLLFNBQVM7RUFDdEI7Ozs7RUFLQSxZQUFZLFVBQWlCO0FBQzVCLFFBQUksQ0FBQyxrQkFBNkIsUUFBUSxLQUFLLENBQUMsU0FBUztBQUN4RCxZQUFNLElBQUksTUFDVCxtR0FBbUc7QUFHckcsU0FBSyxXQUFXO0FBRWhCLFNBQUssVUFBVSxtQkFBa0I7QUFFakMsU0FBSyx3QkFBd0IsS0FBSyxzQkFBc0IsS0FBSyxJQUFJO0FBRWpFLFNBQUssV0FBVztNQUNmLDJCQUEyQjtNQUMzQix3QkFBd0I7O0FBR3pCLFNBQUssSUFBSSxTQUFTLGNBQWM7RUFDakM7RUErQkEsV0FBVyxXQUE0QyxZQUFpQztBQUN2RixTQUFLLFNBQVMsV0FBVyxXQUFXLFVBQVU7RUFDL0M7Ozs7O0VBdUJBLHFCQUFxQixTQUF5RDtBQUM3RSxTQUFLLFNBQVMscUJBQXFCLE9BQU87RUFDM0M7Ozs7O0VBTUEsdUJBQXVCLFdBQStEO0FBQ3JGLFNBQUssU0FBUyx1QkFBdUIsU0FBUztFQUMvQzs7Ozs7O0VBT0EscUJBQ0MsV0FDQSxTQUE4QztBQUU5QyxTQUFLLFNBQVMscUJBQXFCLFdBQVcsT0FBTztFQUN0RDs7Ozs7RUFNQSx1QkFBdUIsV0FBK0Q7QUFDckYsUUFBSSxNQUFNLFFBQVEsU0FBUztBQUFHLFlBQU0sSUFBSSxNQUFNLHdEQUF3RDtBQUV0RyxTQUFLLFNBQVMsdUJBQXVCLFNBQVM7RUFDL0M7Ozs7O0VBTUEsa0JBQWtCLFFBQXVDO0FBQ3hELFNBQUssU0FBUyxrQkFBa0IsTUFBTTtFQUN2Qzs7Ozs7O0VBT0EsaUJBQW1DLFlBQWE7QUFDL0MsV0FBTyxLQUFLLFNBQVMsaUJBQWlCLFVBQVU7RUFDakQ7Ozs7RUFLQSxvQkFBaUI7QUFDaEIsU0FBSyxTQUFTLGtCQUFpQjtFQUNoQzs7Ozs7OztFQVFBLGVBQ0MsaUJBQ0csZUFBbUQ7QUFFdEQsU0FBSyxTQUFTLGVBQWUsQ0FBQyxjQUFjLEdBQUcsYUFBYSxDQUFDO0VBQzlEOzs7OztFQU1BLHNCQUFzQixhQUFxQjtBQUMxQyxTQUFLLFNBQVMsbUJBQW1CLFdBQVc7RUFDN0M7Ozs7OztFQU9BLG9CQUFvQixXQUFtQjtBQUN0QyxTQUFLLFNBQVMsaUJBQWlCLFNBQVM7RUFDekM7Ozs7OztFQU1BLHNCQUFzQixXQUFtQjtBQUN4QyxTQUFLLFNBQVMsbUJBQW1CLFNBQVM7RUFDM0M7Ozs7OztFQU9BLHdCQUF3QixhQUFxQjtBQUM1QyxTQUFLLFNBQVMscUJBQXFCLFdBQVc7RUFDL0M7Ozs7OztFQU9BLGFBQWEsUUFBaUMsY0FBcUI7QUFDbEUsU0FBSyxTQUFTLGFBQWEsUUFBUSxZQUFZO0VBQ2hEOzs7Ozs7OztFQVNBLFFBQVEsTUFBYyxNQUFjQSxPQUFjLE1BQXNCO0FBQ3ZFLFNBQUssU0FBUyxRQUFRLE1BQU0sTUFBTUEsT0FBTSxJQUFJO0VBQzdDOzs7Ozs7Ozs7OztFQVlBLGFBQWEsUUFBd0IsU0FBdUI7QUFDM0QsU0FBSyxTQUFTLGFBQWEsUUFBUSxXQUFXLElBQUk7RUFDbkQ7Ozs7OztFQU9BLElBQUksT0FBaUIsU0FBZTtBQUNuQyxZQUFRLE9BQU87TUFDZCxLQUFLO0FBQ0osYUFBSyxRQUFRLE1BQU0sT0FBTztBQUMxQjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLE1BQU0sT0FBTztBQUMxQjtNQUNEO0FBQ0Msb0JBQVksS0FBSztBQUNqQixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO0lBQ0Y7RUFDRDtFQVlBLHNCQUNDLGVBQ0EsVUFBeUM7QUFFekMsVUFBTSxVQUFrQyxPQUFPLGtCQUFrQixXQUFXLEVBQUUsTUFBTSxjQUFhLElBQUs7QUFFdEcsVUFBTSxTQUFTLElBQUksb0JBQW9CLEtBQUssVUFBVSxPQUFPO0FBQzdELFFBQUk7QUFBVSxhQUFPLEdBQUcsV0FBVyxRQUFRO0FBRTNDLFdBQU87RUFDUjs7OztBQy9VRCxJQUFZO0NBQVosU0FBWUMsaUJBQWM7QUFDekIsRUFBQUEsZ0JBQUEsSUFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsWUFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsY0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsbUJBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLFdBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGNBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGdCQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSx1QkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEseUJBQUEsSUFBQTtBQUNELEdBVlksbUJBQUEsaUJBQWMsQ0FBQSxFQUFBO0FBYXBCLElBQVc7Q0FBakIsU0FBaUJDLFFBQUs7QUFFUixFQUFBQSxPQUFBLEtBQUs7QUFDTCxFQUFBQSxPQUFBLFdBQ1o7QUFDWSxFQUFBQSxPQUFBLFVBQVU7QUFDVixFQUFBQSxPQUFBLE9BQ1o7QUFDWSxFQUFBQSxPQUFBLGNBQWM7QUFDZCxFQUFBQSxPQUFBLFVBQVU7QUFDVixFQUFBQSxPQUFBLFFBQVE7QUFDUixFQUFBQSxPQUFBLGVBQWU7QUFDZixFQUFBQSxPQUFBLGVBQWU7QUFDZixFQUFBQSxPQUFBLFNBQVM7QUFDVCxFQUFBQSxPQUFBLGdCQUFnQjtBQUNoQixFQUFBQSxPQUFBLFlBQVk7QUFDWixFQUFBQSxPQUFBLFdBQ1o7QUFDRixHQWxCaUIsVUFBQSxRQUFLLENBQUEsRUFBQTs7O0FDakJ0QixPQUFPLFFBQVE7QUFDZixPQUFPLFVBQVU7QUFJakIsSUFBTSxTQUFTLG1CQUFtQixRQUFRO0FBeUIxQyxTQUFTLHVCQUFvQjtBQUM1QixRQUFNLGNBQWMsS0FBSyxLQUFLLFlBQVksU0FBUyxZQUFZO0FBQy9ELFFBQU0sZUFBZSxLQUFLLEtBQUssWUFBWSxTQUFTLFdBQVc7QUFHL0QsTUFBSSxHQUFHLFdBQVcsV0FBVyxHQUFHO0FBQy9CLFdBQU8sTUFBTSx5QkFBeUIsV0FBVyxFQUFFO0FBQ25ELFdBQU87RUFDUjtBQUdBLE1BQUksR0FBRyxXQUFXLFlBQVksR0FBRztBQUNoQyxXQUFPLEtBQUsscURBQXFELFlBQVksRUFBRTtBQUMvRSxXQUFPO0VBQ1I7QUFHQSxRQUFNLFdBQVc7O01BQTBDLFdBQVc7TUFBUyxZQUFZOztBQUMzRixTQUFPLE1BQU0sUUFBUTtBQUNyQixRQUFNLElBQUksTUFBTSxRQUFRO0FBQ3pCO0FBR0EsSUFBTSxnQkFBZ0IscUJBQW9CO0FBRzFDLElBQUkscUJBQWlEO0FBTS9DLFNBQVUsbUJBQWdCO0FBQy9CLFNBQU87QUFDUjtBQU1BLFNBQVMsb0JBQWlCO0FBQ3pCLFFBQU0sVUFBK0IsQ0FBQTtBQUNyQyxNQUFJO0FBQ0gsVUFBTSxRQUFRLEdBQUcsWUFBWSxhQUFhLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxTQUFTLE9BQU8sQ0FBQztBQUU3RSxlQUFXLEtBQUssT0FBTztBQUN0QixZQUFNLFdBQVcsS0FBSyxLQUFLLGVBQWUsQ0FBQztBQUMzQyxZQUFNLE9BQU8sS0FBSyxNQUFNLEdBQUcsYUFBYSxVQUFVLE1BQU0sQ0FBQztBQUN6RCxVQUFJLE1BQU0sT0FBTztBQUNoQixnQkFBUSxPQUFPLEtBQUssS0FBSyxDQUFDLElBQUk7TUFDL0I7SUFDRDtBQUVBLFdBQU8sTUFBTSxVQUFVLE9BQU8sS0FBSyxPQUFPLEVBQUUsTUFBTSw0QkFBNEI7RUFDL0UsU0FBUyxHQUFHO0FBQ1gsV0FBTyxNQUFNLGtDQUFrQyxDQUFDLEVBQUU7RUFDbkQ7QUFDQSxTQUFPO0FBQ1I7QUFNTSxTQUFVLG1CQUFnQjtBQUMvQixNQUFJLENBQUMsb0JBQW9CO0FBQ3hCLHlCQUFxQixrQkFBaUI7RUFDdkM7QUFDQSxTQUFPO0FBQ1I7QUFNTSxTQUFVLGdCQUFnQixPQUFhO0FBQzVDLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsU0FBTyxRQUFRLEtBQUs7QUFDckI7QUFNTSxTQUFVLHNCQUFtQjtBQUNsQyxTQUFPLEtBQUssdUNBQXVDO0FBQ25ELHVCQUFxQixrQkFBaUI7QUFDdkM7QUFLQSxTQUFTLHNCQUFtQjtBQUMzQixRQUFNLFVBQVUsaUJBQWdCO0FBQ2hDLFNBQU8sT0FBTyxLQUFLLE9BQU8sRUFBRSxLQUFJO0FBQ2pDO0FBRU0sU0FBVSxnQkFBZ0Isb0JBQWtDLENBQUEsR0FBRTtBQUNuRSxRQUFNLFNBQVMsb0JBQW1CO0FBSWxDLFFBQU0sZ0JBQWdCO0lBQ3JCLEVBQUUsSUFBSSxJQUFJLE9BQU8sa0NBQWlDO0lBQ2xELEdBQUcsa0JBQWtCLElBQUksQ0FBQyxPQUFPO01BQ2hDLElBQUksRUFBRSxPQUFPO01BQ2IsT0FBTyxTQUFTLEVBQUUsS0FBSyxLQUFLLEVBQUUsR0FBRyxPQUFPLEVBQUUsRUFBRTtNQUMzQzs7QUFHSCxTQUFPOzs7SUFHTjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTO01BQ1QsU0FBUztNQUNULFNBQVM7OztJQUlWO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVM7TUFDVCxPQUFPLE1BQU07TUFDYixxQkFBcUI7TUFDckIsU0FBUzs7O0lBSVY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUyxPQUFPLENBQUMsS0FBSztNQUN0QixTQUFTLE9BQU8sSUFBSSxDQUFDLFdBQVc7UUFDL0IsSUFBSTtRQUNKLE9BQU8sU0FBUyxLQUFLO1FBQ3BCO01BQ0YscUJBQXFCO01BQ3JCLFNBQVM7OztJQUlWO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVM7TUFDVCxTQUFTOzs7QUFHWjtBQU9NLFNBQVUsWUFBWSxRQUFzQixtQkFBK0I7QUFDaEYsTUFBSSxPQUFPLFdBQVc7QUFDckIsVUFBTSxTQUFTLGtCQUFrQixLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsT0FBTyxTQUFTO0FBQ3ZFLFdBQU8sUUFBUSxNQUFNO0VBQ3RCO0FBQ0EsU0FBTyxPQUFPLE9BQU8sUUFBUSxFQUFFO0FBQ2hDO0FBT00sU0FBVSxhQUFhLFFBQXNCLG1CQUErQjtBQUNqRixNQUFJLE9BQU8sV0FBVztBQUNyQixVQUFNLFNBQVMsa0JBQWtCLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxPQUFPLFNBQVM7QUFDdkUsV0FBTyxNQUFNLDRCQUE0QixPQUFPLFNBQVMsb0JBQW9CLFFBQVEsU0FBUyxNQUFNLEVBQUU7QUFDdEcsV0FBTyxRQUFRLFNBQVM7RUFDekI7QUFDQSxTQUFPLE1BQU0sMkNBQTJDLE9BQU8sV0FBVyxHQUFHO0FBQzdFLFNBQU8sT0FBTyxPQUFPLGVBQWUsRUFBRTtBQUN2Qzs7O0FDcE5NLFNBQVUsMEJBQTBCLE1BQW9CO0FBQzdELE9BQUssdUJBQXVCO0lBQzNCLE9BQU8sRUFBRSxNQUFNLHNCQUFxQjtJQUNwQyxXQUFXLEVBQUUsTUFBTSx1Q0FBc0M7SUFDekQsY0FBYyxFQUFFLE1BQU0sc0JBQXFCO0lBQzNDLFVBQVUsRUFBRSxNQUFNLDBCQUF5QjtJQUMzQyxTQUFTLEVBQUUsTUFBTSxnQ0FBK0I7SUFDaEQsS0FBSyxFQUFFLE1BQU0scUJBQW9CO0lBQ2pDLElBQUksRUFBRSxNQUFNLG9CQUFtQjtHQUMvQjtBQUNGO0FBRUEsSUFBTSxvQkFBb0I7RUFDekIsT0FBTztFQUNQLFdBQVc7RUFDWCxjQUFjO0VBQ2QsVUFBVTtFQUNWLFNBQVM7RUFDVCxLQUFLO0VBQ0wsSUFBSTs7QUFRQyxTQUFVLHFCQUFxQixNQUFvQjtBQUN4RCxRQUFNLGNBQWMsS0FBSztBQUd6QixNQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssYUFBYSxtQkFBbUIsV0FBVyxHQUFHO0FBQ3ZFLFNBQUssa0JBQWtCLGlCQUFpQjtBQUN4QztFQUNEO0FBRUEsUUFBTSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sV0FBVztBQUM1RCxNQUFJLFFBQVE7QUFDWCxTQUFLLGtCQUFrQjtNQUN0QixPQUFPLE9BQU8sU0FBUztNQUN2QixXQUFXLE9BQU8sYUFBYTtNQUMvQixjQUFjLE9BQU8sZ0JBQWdCO01BQ3JDLFVBQVUsT0FBTyxnQkFBZ0I7TUFDakMsU0FBUyxPQUFPLGlCQUFpQjtNQUNqQyxLQUFLLE9BQU8sT0FBTztNQUNuQixJQUFJLE9BQU87S0FDWDtFQUNGLE9BQU87QUFHTixTQUFLLGtCQUFrQjtNQUN0QixHQUFHO01BQ0gsSUFBSTtLQUNKO0VBQ0Y7QUFDRDs7O0FDMURPLElBQU0saUJBQStEOzs7Ozs7Ozs7Ozs7Ozs7QUNTckUsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxjQUFjO0FBQ3BCLElBQU0sY0FBYztBQUNwQixJQUFNLGNBQWM7QUFDcEIsSUFBTSxnQkFBZ0I7QUFDdEIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxhQUFhO0FBQ25CLElBQU0sdUJBQXVCO0FBQzdCLElBQU0sb0JBQW9CO0FBQzFCLElBQU0sZUFBZTtBQUNyQixJQUFNLG1CQUFtQjtBQUN6QixJQUFNLHNCQUFzQjtBQUM1QixJQUFNLGtCQUFrQjtBQUN4QixJQUFNLGNBQWM7QUFHckIsU0FBVSxlQUFlLE9BQWE7QUFDM0MsVUFBUSxPQUFPO0lBQ2QsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSLEtBQUs7QUFDSixhQUFPO0lBQ1IsS0FBSztBQUNKLGFBQU87SUFDUixLQUFLO0FBQ0osYUFBTztJQUNSO0FBQ0MsYUFBTyxTQUFTLE1BQU0sU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztFQUNyRDtBQUNEO0FBUU0sU0FBVSxjQUNmLE9BQ0EsT0FDQSxXQUNBLE9BQXVCO0FBRXZCLFFBQU0sTUFBTSxPQUFPLFVBQVUsV0FBVyxNQUFNLFNBQVMsRUFBRSxJQUFJO0FBQzdELFFBQU0sS0FBSyxPQUFPLGNBQWMsV0FBVyxVQUFVLFNBQVMsRUFBRSxJQUFJO0FBRXBFLE1BQUksVUFBVSxRQUFXO0FBQ3hCLFVBQU0sS0FBSyxPQUFPLFVBQVUsV0FBVyxNQUFNLFNBQVMsRUFBRSxJQUFJO0FBQzVELFdBQU8sR0FBRyxLQUFLLElBQUksR0FBRyxJQUFJLEVBQUUsSUFBSSxFQUFFO0VBQ25DO0FBRUEsU0FBTyxHQUFHLEtBQUssSUFBSSxHQUFHLElBQUksRUFBRTtBQUM3QjtBQVNNLFNBQVUsTUFBTSxPQUFlLFlBQVksR0FBQztBQUNqRCxTQUFPLEtBQUssTUFBTSxTQUFTLEVBQUUsRUFBRSxTQUFTLFdBQVcsR0FBRyxDQUFDO0FBQ3hEO0FBT00sU0FBVSxXQUFXLE9BQXdCO0FBQ2xELFNBQU8sS0FBSyxNQUFNLEtBQUssS0FBSyxFQUMxQixJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFLENBQUM7QUFDWDtBQVNNLFNBQVUsZUFBZSxHQUFXLEdBQVcsR0FBUztBQUM3RCxTQUFPLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxFQUNqQixJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFLEVBQ1AsWUFBVyxDQUFFO0FBQ2hCO0FBUU0sU0FBVSxlQUFlLElBQVU7QUFDeEMsUUFBTSxDQUFDLE9BQU8sVUFBVSxLQUFLLElBQUksR0FBRyxNQUFNLEdBQUc7QUFDN0MsU0FBTztJQUNOO0lBQ0EsT0FBTyxTQUFTLFVBQVUsRUFBRTtJQUM1QixRQUFRLFNBQVMsT0FBTyxFQUFFOztBQUU1QjtBQVVNLFNBQVUsY0FBYyxRQUFnQixRQUFjO0FBQzNELFFBQU0sS0FBSyxTQUFTLE9BQU8sUUFBUSxPQUFPLEVBQUUsR0FBRyxFQUFFO0FBQ2pELFFBQU0sS0FBSyxTQUFTLE9BQU8sUUFBUSxPQUFPLEVBQUUsR0FBRyxFQUFFO0FBQ2pELE1BQUksT0FBTyxNQUFNLEVBQUUsS0FBSyxPQUFPLE1BQU0sRUFBRTtBQUFHLFdBQU87QUFDakQsU0FBTyxLQUFLLElBQUksS0FBSyxFQUFFO0FBQ3hCO0FBU00sU0FBVSxxQkFDZixZQUErQjtBQUUvQixRQUFNLGFBQWtFLENBQUE7QUFDeEUsYUFBVyxDQUFDLE9BQU8sSUFBSSxLQUFLLE9BQU8sUUFBUSxVQUFVLEdBQUc7QUFDdkQsZUFBVyxLQUFLLElBQUk7TUFDbkIsT0FBTyxLQUFLO01BQ1osV0FBVyxNQUFNLFFBQVEsS0FBSyxTQUFTLElBQUksS0FBSyxZQUFZLENBQUE7O0VBRTlEO0FBQ0EsU0FBTztBQUNSO0FBWU0sU0FBVSxxQkFDZixTQUNBLE9BQ0EsT0FDQSxXQUFpQjtBQUVqQixRQUFNLFNBQVMsUUFBUSxLQUFLO0FBQzVCLE1BQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxRQUFRLE9BQU8sU0FBUztBQUFHLFdBQU87QUFHeEQsTUFBSSxTQUFTLE9BQU8sVUFBVSxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUd2RixNQUFJLENBQUMsUUFBUTtBQUNaLGFBQVMsT0FBTyxVQUFVLEtBQUssQ0FBQyxNQUFVO0FBQ3pDLFVBQUksRUFBRSxXQUFXO0FBQU8sZUFBTztBQUMvQixZQUFNLGNBQWMsRUFBRSxTQUFTLEtBQUssQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBQ3BFLFVBQUksQ0FBQyxhQUFhO0FBQVMsZUFBTztBQUVsQyxZQUFNLFNBQVMsWUFBWSxFQUFFO0FBQzdCLGFBQU8sWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxNQUFNO0lBQzVELENBQUM7RUFDRjtBQUVBLFNBQU87QUFDUjs7O0FDNUxBLFNBQVMsWUFBWSxHQUFNO0FBQzFCLFFBQU0sT0FBTztJQUNaLE1BQU0sRUFBRTtJQUNSLElBQUksRUFBRTtJQUNOLE9BQU8sRUFBRTtJQUNULFNBQVMsRUFBRTtJQUNYLFNBQVMsRUFBRTs7QUFHWixVQUFRLEVBQUUsTUFBTTtJQUNmLEtBQUs7QUFDSixhQUFPLEVBQUUsR0FBRyxNQUFNLFNBQVMsRUFBRSxXQUFXLENBQUEsRUFBRTtJQUUzQyxLQUFLO0FBQ0osYUFBTztRQUNOLEdBQUc7UUFDSCxLQUFLLEVBQUU7UUFDUCxLQUFLLEVBQUU7UUFDUCxNQUFNLEVBQUUsUUFBUTtRQUNoQixPQUFPOztJQUdULEtBQUs7QUFDSixhQUFPLEVBQUUsR0FBRyxNQUFNLFNBQVMsRUFBRSxXQUFXLE1BQUs7SUFFOUMsS0FBSztBQUNKLGFBQU8sRUFBRSxHQUFHLE1BQU0sT0FBTyxFQUFFLFNBQVMsR0FBRTtJQUV2QyxLQUFLO0lBQ0wsS0FBSztJQUNMO0FBQ0MsYUFBTztFQUNUO0FBQ0Q7QUFNTSxTQUFVLGVBQVk7QUFDM0IsUUFBTSxVQUFVLGlCQUFnQjtBQUNoQyxRQUFNLFVBQXNDLENBQUE7QUFFNUMsYUFBVyxDQUFDLE9BQU8sTUFBTSxLQUFLLE9BQU8sUUFBUSxPQUFPLEdBQUc7QUFDdEQsVUFBTSxZQUFZLE9BQU87QUFDekIsUUFBSSxDQUFDLE1BQU0sUUFBUSxTQUFTO0FBQUc7QUFFL0IsZUFBVyxLQUFLLFdBQVc7QUFFMUIsVUFBSSxFQUFFLGFBQWE7QUFBTTtBQUV6QixZQUFNLFdBQVcsY0FBYyxPQUFPLEVBQUUsUUFBUSxFQUFFLEVBQUU7QUFHcEQsWUFBTSxtQkFBbUIsRUFBRSxXQUFXLENBQUEsR0FBSSxJQUFJLFdBQVc7QUFDekQsWUFBTSxVQUFVLEVBQUUsVUFBVSxTQUFZLGdCQUFnQixPQUFPLENBQUMsTUFBVyxFQUFFLE9BQU8sT0FBTyxJQUFJO0FBRS9GLFlBQU0sU0FBb0M7UUFDekMsTUFBTSxTQUFTLEtBQUssS0FBSyxFQUFFLElBQUk7UUFDL0I7UUFDQSxVQUFVLFlBQVc7UUFFckI7O0FBR0QsY0FBUSxRQUFRLElBQUk7SUFDckI7RUFDRDtBQUVBLFNBQU87QUFDUjtBQVdBLFNBQVMsa0JBQWtCLFNBQVk7QUFDdEMsUUFBTSxXQUFXLFFBQVEsU0FBUyxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sT0FBTztBQUNuRSxNQUFJLENBQUM7QUFBVSxXQUFPO0FBQ3RCLE1BQUksU0FBUyxTQUFTO0FBQVksV0FBTztBQUN6QyxNQUFJLFNBQVMsU0FBUyxjQUFjLENBQUMsTUFBTSxRQUFRLFNBQVMsT0FBTztBQUFHLFdBQU87QUFDN0UsTUFBSSxTQUFTLFFBQVEsV0FBVztBQUFHLFdBQU87QUFDMUMsUUFBTSxTQUFTLFNBQVMsUUFBUSxJQUFJLENBQUMsTUFBVyxPQUFPLEVBQUUsS0FBSyxFQUFFLFlBQVcsQ0FBRTtBQUM3RSxTQUFPLE9BQU8sU0FBUyxLQUFLLEtBQUssT0FBTyxTQUFTLElBQUk7QUFDdEQ7QUFFTSxTQUFVLGlCQUFjO0FBQzdCLFFBQU0sVUFBVSxpQkFBZ0I7QUFDaEMsUUFBTSxZQUEwQyxDQUFBO0FBRWhELGFBQVcsQ0FBQyxPQUFPLE1BQU0sS0FBSyxPQUFPLFFBQVEsT0FBTyxHQUFHO0FBQ3RELFVBQU0sWUFBWSxPQUFPO0FBQ3pCLFFBQUksQ0FBQyxNQUFNLFFBQVEsU0FBUztBQUFHO0FBRS9CLGVBQVcsV0FBVyxXQUFXO0FBRWhDLFVBQUksUUFBUSxjQUFjO0FBQU07QUFFaEMsWUFBTSxpQkFBaUIsY0FBYyxPQUFPLFFBQVEsUUFBUSxRQUFRLEVBQUU7QUFHdEUsVUFBSSxRQUFRLFVBQVUsUUFBVztBQUNoQyxjQUFNLGdCQUFnQixRQUFRLFdBQVcsQ0FBQSxHQUN2QyxJQUFJLFdBQVcsRUFDZixPQUFPLENBQUMsUUFBYSxJQUFJLE9BQU8sV0FBVyxJQUFJLE9BQU8sT0FBTztBQUUvRCxrQkFBVSxjQUFjLElBQUk7VUFDM0IsTUFBTTtVQUNOLE1BQU0sU0FBUyxLQUFLLEtBQUssUUFBUSxJQUFJO1VBQ3JDLGNBQWM7WUFDYixTQUFTLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFDN0IsT0FBTyxXQUFXLEdBQUcsR0FBRyxDQUFDOztVQUUxQixTQUFTO1VBQ1QsVUFBVSxNQUFLO0FBRWQsbUJBQU87VUFDUjs7QUFFRDtNQUNEO0FBR0EsWUFBTSxjQUFjLFFBQVEsV0FBVyxDQUFBLEdBQUksSUFBSSxXQUFXO0FBRzFELFlBQU0sZUFBZSxXQUFXLE9BQU8sQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBSXZFLFlBQU0saUJBQWlCLFFBQVEsU0FBUyxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sV0FBVyxFQUFFLFNBQVMsYUFBYTtBQUNyRyxVQUFJLENBQUMsZ0JBQWdCO0FBQ3BCLHFCQUFhLEtBQUs7VUFDakIsTUFBTTtVQUNOLElBQUk7VUFDSixPQUFPO1VBQ1AsU0FBUztVQUNULFNBQVM7U0FDVDtNQUNGO0FBR0EsWUFBTSxnQkFBcUI7UUFDMUIsTUFBTTtRQUNOLE1BQU0sU0FBUyxLQUFLLEtBQUssUUFBUSxJQUFJO1FBQ3JDLFNBQVM7UUFDVCxVQUFVLE1BQUs7QUFFZCxpQkFBTztRQUNSOztBQUdELGdCQUFVLGNBQWMsSUFBSTtBQUc1QixVQUFJLGtCQUFrQixPQUFPLEdBQUc7QUFDL0IsY0FBTSxpQkFBaUIsR0FBRyxjQUFjO0FBR3hDLGNBQU0sY0FBYyxXQUFXLE9BQU8sQ0FBQyxRQUFhLElBQUksT0FBTyxPQUFPO0FBRXRFLGNBQU0sZUFBb0I7VUFDekIsTUFBTTtVQUNOLE1BQU0sU0FBUyxLQUFLLEtBQUssUUFBUSxJQUFJO1VBQ3JDLGNBQWM7WUFDYixTQUFTLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFDN0IsT0FBTyxXQUFXLEdBQUcsR0FBRyxDQUFDOztVQUUxQixTQUFTO1VBQ1QsVUFBVSxNQUFLO0FBRWQsbUJBQU87VUFDUjs7QUFHRCxrQkFBVSxjQUFjLElBQUk7TUFDN0I7SUFDRDtFQUNEO0FBRUEsU0FBTztBQUNSOzs7QUN4TUEsT0FBT0MsV0FBVTs7O0FDTGpCLE9BQU9DLFNBQVE7QUFnQmYsSUFBTUMsVUFBUyxtQkFBbUIsZ0JBQWdCO0FBMkNsRCxTQUFTLFVBQVUsT0FBYTtBQUMvQixRQUFNLFNBQVMsb0JBQUksSUFBRztBQUN0QixNQUFJO0FBQ0gsVUFBTSxPQUFPLGdCQUFnQixLQUFLO0FBQ2xDLFFBQUksQ0FBQztBQUFNLGFBQU87QUFDbEIsZUFBVyxVQUFVLEtBQUssYUFBYSxDQUFBLEdBQUk7QUFDMUMsWUFBTSxpQkFBaUIsT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUF3QixJQUFJLFNBQVMsYUFBYTtBQUMvRixVQUFJLGdCQUFnQjtBQUNuQixlQUFPLElBQUksT0FBTyxFQUFFO0FBQ3BCLGNBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQXdCLElBQUksT0FBTyxPQUFPO0FBQ3BGLFlBQUksYUFBYSxTQUFTO0FBQ3pCLHFCQUFXLFVBQVUsWUFBWSxTQUFTO0FBQ3pDLGdCQUFJLE9BQU8sT0FBTyxPQUFPLFVBQVU7QUFDbEMscUJBQU8sSUFBSSxPQUFPLEtBQUssT0FBTyxFQUFFO1lBQ2pDO1VBQ0Q7UUFDRDtNQUNEO0lBQ0Q7RUFDRCxTQUFTLE1BQU07RUFFZjtBQUNBLFNBQU87QUFDUjtBQU1BLFNBQVMsc0JBQXNCLEtBQVc7QUFDekMsUUFBTSxXQUFXLElBQUksUUFBUSxPQUFPLEtBQUssVUFBVSxDQUFDO0FBQ3BELE1BQUksV0FBVztBQUFHLFVBQU0sSUFBSSxNQUFNLGlDQUFpQztBQUVuRSxRQUFNLGVBQWUsV0FBVztBQUNoQyxNQUFJLElBQUksWUFBWSxNQUFNLElBQU07QUFDL0IsVUFBTSxJQUFJLE1BQU0sdUNBQXVDLElBQUksWUFBWSxFQUFFLFNBQVMsRUFBRSxDQUFDLEVBQUU7RUFDeEY7QUFFQSxTQUFPO0FBQ1I7QUFNQSxTQUFTLDhCQUE4QixLQUFhLE9BQWE7QUFDaEUsUUFBTSxNQUFNLHNCQUFzQixHQUFHO0FBQ3JDLFFBQU0sUUFBUSxJQUFJLE1BQU0sQ0FBQyxJQUFJO0FBQzdCLE1BQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBTSxJQUFJLE1BQU0sNEJBQTRCO0VBQzdDO0FBR0EsTUFBSSxJQUFJLFVBQVUsdUJBQXVCLE1BQU0sSUFBSSxNQUFNO0FBQ3pELFFBQU0sTUFBTSxJQUFJLFNBQVM7QUFDekIsUUFBTSxNQUF1QixDQUFBO0FBRTdCLFFBQU0sU0FBUyxVQUFVLEtBQUs7QUFJOUIsUUFBTSxvQkFBb0IsQ0FBQyxhQUFhLGlCQUFpQixXQUFXO0FBS3BFLFFBQU0sbUJBQW1CLENBQUMsV0FBVztBQUVyQyxTQUFPLElBQUksSUFBSSxLQUFLO0FBQ25CLFVBQU0sU0FBUyxJQUFJLENBQUM7QUFDcEIsVUFBTSxlQUFlLElBQUksSUFBSSxDQUFDO0FBRTlCLFVBQU0sYUFBYSxJQUFJLElBQUk7QUFDM0IsUUFBSSxhQUFhO0FBQUs7QUFFdEIsVUFBTSxXQUFXLGtCQUFrQixTQUFTLFlBQVk7QUFDeEQsVUFBTSxhQUFhLGlCQUFpQixTQUFTLFlBQVk7QUFFekQsUUFBSTtBQUNKLFFBQUk7QUFDSixRQUFJO0FBRUosUUFBSSxZQUFZO0FBUWYsY0FBUSxJQUFJLElBQUksQ0FBQztBQUNqQixZQUFNLFdBQVcsSUFBSSxTQUFTLElBQUksR0FBRyxVQUFVO0FBRS9DLFlBQU0sU0FBUyxnQkFBZ0IsS0FBSztBQUNwQyxZQUFNLGlCQUFpQixRQUFRLGFBQWEsQ0FBQSxHQUMxQyxPQUFPLENBQUMsT0FBaUIsRUFBRSxXQUFXLGVBQWUsRUFBRSxXQUFXLG9CQUFvQixFQUFFLFVBQVUsTUFBUyxFQUMzRyxLQUFLLENBQUMsR0FBYSxNQUFnQixFQUFFLEtBQUssRUFBRSxFQUFFO0FBRWhELGVBQVMsSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7QUFDekMsY0FBTSxRQUFRLGNBQWMsQ0FBQztBQUM3QixZQUFJLE9BQU87QUFDVixjQUFJLEtBQUssRUFBRSxRQUFRLE1BQU0sUUFBUSxJQUFJLE1BQU0sSUFBSSxPQUFPLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFDLENBQUU7UUFDbEY7TUFFRDtBQUNBLFVBQUk7QUFDSjtJQUNELFdBQVcsVUFBVTtBQUVwQixjQUFRLElBQUksSUFBSSxDQUFDO0FBQ2pCLGdCQUFVLElBQUksSUFBSSxDQUFDO0FBQ25CLFVBQUksSUFBSTtJQUNULE9BQU87QUFFTixnQkFBVSxJQUFJLElBQUksQ0FBQztBQUNuQixVQUFJLElBQUk7SUFDVDtBQUVBLFVBQU0sT0FBTyxJQUFJO0FBQ2pCLFVBQU0sU0FBUztBQUVmLFdBQU8sSUFBSSxJQUFJLE1BQU07QUFDcEIsWUFBTSxLQUFLLElBQUksQ0FBQztBQUNoQixVQUFJO0FBR0osVUFBSSxPQUFPLElBQUksRUFBRSxLQUFLLElBQUksSUFBSSxNQUFNO0FBQ25DLHFCQUFhLENBQUMsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLENBQUM7QUFDaEQsYUFBSztNQUNOLE9BQU87QUFDTixxQkFBYSxDQUFDLElBQUksSUFBSSxDQUFDLENBQUM7QUFDeEIsYUFBSztNQUNOO0FBRUEsWUFBTSxVQUF5QjtRQUM5QixRQUFRO1FBQ1I7UUFDQTs7QUFFRCxVQUFJLFVBQVUsUUFBVztBQUN4QixnQkFBUSxRQUFRO01BQ2pCO0FBQ0EsVUFBSSxLQUFLLE9BQU87SUFDakI7QUFRQSxRQUFJLE1BQU0sVUFBVSxhQUFhLElBQUksR0FBRztBQUN2QyxVQUFJLE1BQU0sV0FBVyxJQUFJLElBQUksSUFBSTtBQUNqQyxVQUFJLFFBQVE7QUFDWixhQUFPLE1BQU0sWUFBWTtBQUN4QixjQUFNLFVBQXlCLEVBQUUsUUFBUSxjQUFjLElBQUksU0FBUyxZQUFZLENBQUMsSUFBSSxLQUFLLENBQUMsRUFBQztBQUM1RixZQUFJLFVBQVU7QUFBVyxrQkFBUSxRQUFRO0FBQ3pDLFlBQUksS0FBSyxPQUFPO01BQ2pCO0lBQ0Q7QUFFQSxRQUFJO0VBQ0w7QUFFQSxTQUFPO0FBQ1I7QUFXTSxTQUFVLHNCQUFzQixPQUFlLEtBQVc7QUFDL0QsUUFBTSxNQUFNLHNCQUFzQixHQUFHO0FBQ3JDLFFBQU0sUUFBUSxJQUFJLE1BQU0sQ0FBQyxJQUFJO0FBQzdCLE1BQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBTSxJQUFJLE1BQU0saUNBQWlDLE1BQU0sU0FBUyxFQUFFLENBQUMsR0FBRztFQUN2RTtBQUNBLFNBQU8sOEJBQThCLEtBQUssS0FBSztBQUNoRDtBQU1NLFNBQVUsb0JBQW9CLFNBQXdCLFNBQW1CO0FBRTlFLE1BQUksU0FBUyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxRQUFRLFVBQVUsRUFBRSxPQUFPLFFBQVEsRUFBRTtBQUtuRixNQUFJLENBQUMsUUFBUTtBQUNaLFVBQU0sYUFBYSxRQUFRLEtBQUssQ0FBQyxNQUFLO0FBQ3JDLFVBQUksRUFBRSxXQUFXLFFBQVE7QUFBUSxlQUFPO0FBRXhDLFlBQU0sY0FBYyxFQUFFLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDL0QsVUFBSSxDQUFDLGFBQWE7QUFBUyxlQUFPO0FBRWxDLFlBQU0sZ0JBQWdCLFFBQVEsS0FBSyxFQUFFO0FBQ3JDLGFBQU8sWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxhQUFhO0lBQzlELENBQUM7QUFDRCxRQUFJLFlBQVk7QUFDZixlQUFTO0lBQ1Y7RUFDRDtBQUVBLFFBQU0sU0FBUyxNQUFNLFFBQVEsTUFBTTtBQUNuQyxRQUFNLFFBQVEsTUFBTSxRQUFRLEVBQUU7QUFDOUIsUUFBTSxTQUFTLFdBQVcsUUFBUSxVQUFVO0FBQzVDLFFBQU0sU0FDTCxRQUFRLFdBQVcsV0FBVyxJQUMzQixlQUFlLFFBQVEsV0FBVyxDQUFDLEdBQUcsUUFBUSxXQUFXLENBQUMsR0FBRyxRQUFRLFdBQVcsQ0FBQyxDQUFDLElBQ2xGLFFBQVEsV0FBVyxXQUFXLElBQzdCLFFBQVEsV0FBVyxDQUFDLElBQ3BCLFFBQVEsV0FBVyxLQUFLLEdBQUc7QUFHaEMsUUFBTSxXQUFXLFFBQVEsVUFBVSxTQUFZLE9BQU8sUUFBUSxLQUFLLEtBQUs7QUFDeEUsUUFBTSxTQUFTLE9BQU8sTUFBTSxHQUFHLFFBQVEsT0FBTyxLQUFLLFFBQVEsTUFBTTtBQUdqRSxNQUFJLFFBQVE7QUFDWCxRQUFJLE9BQU8sT0FBTztBQUdsQixRQUFJLFFBQVEsVUFBVSxRQUFXO0FBQ2hDLGFBQU8sR0FBRyxJQUFJLE1BQU0sUUFBUSxRQUFRLENBQUM7SUFDdEMsT0FFSztBQUNKLFlBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFDcEUsVUFBSSxhQUFhLFNBQVM7QUFDekIsY0FBTSxnQkFBZ0IsUUFBUSxLQUFLLE9BQU87QUFDMUMsY0FBTSxjQUFjLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sYUFBYTtBQUMxRSxZQUFJLGFBQWE7QUFDaEIsaUJBQU8sR0FBRyxJQUFJLElBQUksWUFBWSxLQUFLO1FBQ3BDO01BQ0Q7SUFDRDtBQUdBLFVBQU0sY0FBYyxPQUFPLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLE9BQU87QUFFcEUsVUFBTSxhQUFjLE9BQWU7QUFDbkMsUUFBSSxlQUFlLFVBQWEsZ0JBQWdCLFFBQVc7QUFDMUQsYUFBTyxHQUFHLE1BQU0sTUFBTSxJQUFJLEtBQUssVUFBVTtJQUMxQztBQUNBLFFBQUksYUFBYSxXQUFXLFFBQVEsV0FBVyxXQUFXLEdBQUc7QUFDNUQsWUFBTSxTQUFTLFlBQVksUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxXQUFXLENBQUMsQ0FBQztBQUM3RSxVQUFJLFFBQVE7QUFDWCxlQUFPLEdBQUcsTUFBTSxNQUFNLElBQUksS0FBSyxPQUFPLEtBQUssS0FBSyxNQUFNO01BQ3ZEO0lBQ0Q7QUFDQSxXQUFPLEdBQUcsTUFBTSxNQUFNLElBQUksS0FBSyxNQUFNO0VBQ3RDO0FBR0EsU0FBTyxHQUFHLE1BQU07QUFDakI7QUFXTSxTQUFVLGlDQUNmLE9BQ0EsS0FBVztBQUVYLFFBQU0sV0FBVyw4QkFBOEIsS0FBSyxLQUFLO0FBQ3pELFNBQU8sRUFBRSxVQUFVLG1CQUFtQixLQUFJO0FBQzNDO0FBRU0sU0FBVSw0QkFBNEIsT0FBZSxLQUFXO0FBQ3JFLFNBQU8sOEJBQThCLEtBQUssS0FBSztBQUNoRDtBQU1BLFNBQVMsbUJBQW1CLFlBQW9CO0FBQy9DLE1BQUksV0FBVyxXQUFXLEdBQUc7QUFDNUIsV0FBTyxFQUFFLElBQUksU0FBUyxPQUFPLFNBQVMsTUFBTSxVQUFVLFNBQVMsV0FBVyxDQUFDLEVBQUM7RUFDN0U7QUFFQSxNQUFJLFdBQVcsV0FBVyxHQUFHO0FBQzVCLFVBQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQyxJQUFJO0FBQ2xCLFdBQU87TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE1BQU07TUFDTixTQUFTLGVBQWUsR0FBRyxHQUFHLENBQUM7O0VBRWpDO0FBRUEsU0FBTyxFQUFFLElBQUksU0FBUyxPQUFPLFNBQVMsTUFBTSxPQUFPLFNBQVMsQ0FBQyxHQUFHLFVBQVUsRUFBQztBQUM1RTtBQU1NLFNBQVUsNEJBQ2YsV0FDQSxRQUNBLFdBQXNDO0FBRXRDLFFBQU0sTUFBTSxnQkFBZ0IsU0FBUztBQUdyQyxNQUFJLENBQUMsSUFBSSxXQUFXO0FBQ25CLFFBQUksWUFBWSxDQUFBO0VBQ2pCO0FBR0EsUUFBTSxhQUFhLE9BQU8sT0FBTyxTQUFTLEVBQ3hDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsVUFBVSxVQUFVLEtBQUssRUFDekMsS0FBSyxDQUFDLEdBQUcsTUFBTSxjQUFjLFVBQVUsT0FBTyxFQUFFLEtBQUssSUFBSSxjQUFjLFVBQVUsT0FBTyxFQUFFLEtBQUssQ0FBQztBQUVsRyxFQUFBQSxRQUFPLEtBQUssbUJBQW1CLFVBQVUsS0FBSyxFQUFFO0FBQ2hELEVBQUFBLFFBQU8sTUFBTSw2QkFBNkIsV0FBVyxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLElBQUksQ0FBQyxFQUFFO0FBS3JGLFFBQU0sbUJBQW1CLG9CQUFJLElBQUc7QUFDaEMsYUFBVyxLQUFLLFlBQVk7QUFDM0IsZUFBVyxhQUFhLEVBQUUsYUFBYSxDQUFBLEdBQUk7QUFDMUMsWUFBTSxXQUFXLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBVyxFQUFFLE9BQU8sT0FBTztBQUNyRSxVQUFJLENBQUMsVUFBVTtBQUFTO0FBQ3hCLFlBQU0sU0FBUyxVQUFVO0FBQ3pCLFlBQU0sUUFBUSxVQUFVO0FBQ3hCLFlBQU0sTUFBTSxHQUFHLEtBQUssSUFBSSxNQUFNO0FBQzlCLFVBQUksaUJBQWlCLElBQUksR0FBRztBQUFHO0FBRS9CLFlBQU0sZ0JBQWdCLE9BQ3BCLE9BQU8sQ0FBQyxNQUFNLEVBQUUsV0FBVyxTQUFTLEVBQUUsS0FBSyxNQUFNLEVBQ2pELElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxNQUFNLEVBQ3hCLEtBQUssQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDO0FBRXRCLFVBQUksU0FBUztBQUNiLGlCQUFXLE9BQU8sZUFBZTtBQUNoQyxZQUFJLFFBQVEsU0FBUztBQUFHLG1CQUFTO2lCQUN4QixNQUFNLFNBQVM7QUFBRztNQUM1QjtBQUNBLFVBQUksU0FBUyxHQUFHO0FBQ2YseUJBQWlCLElBQUksS0FBSyxNQUFNO0FBQ2hDLFFBQUFBLFFBQU8sTUFBTSxnQ0FBZ0MsTUFBTSxLQUFLLENBQUMsWUFBWSxNQUFNLE1BQU0sQ0FBQyxvQkFBZSxNQUFNLEVBQUU7TUFDMUc7SUFDRDtFQUNEO0FBSUEsUUFBTSxZQUFZLG9CQUFJLElBQUc7QUFDekIsYUFBVyxFQUFFLFFBQVEsSUFBSSxNQUFLLEtBQU0sUUFBUTtBQUMzQyxRQUFJLFVBQVU7QUFBVztBQUN6QixVQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksRUFBRTtBQUMzQixRQUFJLENBQUMsVUFBVSxJQUFJLEdBQUc7QUFBRyxnQkFBVSxJQUFJLEtBQUssb0JBQUksSUFBRyxDQUFFO0FBQ3JELGNBQVUsSUFBSSxHQUFHLEVBQUcsSUFBSSxLQUFLO0VBQzlCO0FBTUEsYUFBVyxFQUFFLFFBQVEsSUFBSSxPQUFPLFdBQVUsS0FBTSxRQUFRO0FBRXZELFVBQU0sZ0JBQWdCLElBQUksVUFBVSxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sRUFBRTtBQUNsRixRQUFJLGVBQWU7QUFDbEIsWUFBTSxNQUFNLGNBQWMsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUMvRCxVQUFJO0FBQUssWUFBSSxVQUFVLG1CQUFtQixVQUFVLEVBQUU7QUFHdEQsWUFBTSxrQkFBa0IsVUFBVSxJQUFJLEdBQUcsTUFBTSxJQUFJLEVBQUUsRUFBRTtBQUN2RCxVQUFJLG1CQUFtQixnQkFBZ0IsT0FBTyxHQUFHO0FBQ2hELGNBQU0sV0FBVyxLQUFLLElBQUksR0FBRyxlQUFlO0FBQzVDLGNBQU0saUJBQWlCLGNBQWMsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUMxRSxZQUFJLGFBQWEsS0FBSyxjQUFjLFVBQVUsVUFBYSxDQUFDLGdCQUFnQjtBQUMzRSx3QkFBYyxRQUFRO0FBQ3RCLFVBQUFBLFFBQU8sS0FBSyw2Q0FBNkMsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxFQUFFO1FBQ3pGO01BQ0Q7QUFDQTtJQUNEO0FBS0EsVUFBTSxZQUFZLElBQUksVUFBVSxLQUFLLENBQUMsTUFBSztBQUMxQyxVQUFJLEVBQUUsV0FBVztBQUFRLGVBQU87QUFDaEMsWUFBTSxXQUFXLEVBQUUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUN4RCxVQUFJLENBQUMsVUFBVTtBQUFTLGVBQU87QUFDL0IsVUFBSSxNQUFNLEVBQUU7QUFBSSxlQUFPO0FBQ3ZCLFlBQU0sU0FBUyxLQUFLLEVBQUU7QUFFdEIsYUFBTyxXQUFXLEtBQUssQ0FBQyxNQUFLO0FBQzVCLGNBQU0sV0FBVyxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUUsRUFBRTtBQUM5RSxjQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLGVBQU8sVUFBVSxTQUFTLEtBQUssQ0FBQyxPQUFZLEdBQUcsT0FBTyxNQUFNO01BQzdELENBQUM7SUFDRixDQUFDO0FBQ0QsUUFBSSxXQUFXO0FBQ2QsWUFBTSxTQUFTLEtBQUssVUFBVTtBQUM5QixZQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLFVBQUksVUFBVSxXQUFXLENBQUMsU0FBUyxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxNQUFNLEdBQUc7QUFDN0UsWUFBSSxRQUFRLFdBQVcsU0FBUyxDQUFDO0FBQ2pDLG1CQUFXLEtBQUssWUFBWTtBQUMzQixnQkFBTSxXQUFXLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sVUFBVSxFQUFFO0FBQ3RGLGdCQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLGdCQUFNLFlBQVksVUFBVSxTQUFTLEtBQUssQ0FBQyxPQUFZLEdBQUcsT0FBTyxNQUFNO0FBQ3ZFLGNBQUksV0FBVztBQUNkLG9CQUFRLFVBQVU7QUFDbEI7VUFDRDtRQUNEO0FBQ0EsaUJBQVMsUUFBUSxLQUFLLEVBQUUsSUFBSSxRQUFRLE1BQUssQ0FBRTtBQUMzQyxRQUFBQSxRQUFPLEtBQ04saUJBQWlCLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsdUJBQXVCLE1BQU0sVUFBVSxFQUFFLENBQUMsY0FBYyxNQUFNLE1BQU0sS0FBSyxJQUFJO01BRTdIO0FBQ0E7SUFDRDtBQUdBLFFBQUk7QUFFSixlQUFXLEtBQUssWUFBWTtBQUMzQixZQUFNLFFBQVEsRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUUsT0FBTyxFQUFFO0FBQ3pFLFVBQUksT0FBTztBQUNWLGlCQUFTLGdCQUFnQixLQUFLO0FBRTlCLGNBQU0sV0FBVyxNQUFNLEtBQUssUUFBUSxxQ0FBcUMsRUFBRSxFQUFFLEtBQUk7QUFDakYsZUFBTyxPQUFPLEdBQUcsUUFBUSx5QkFBeUIsRUFBRSxLQUFLO0FBQ3pELFFBQUFBLFFBQU8sS0FBSyxtQkFBbUIsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxlQUFlLEVBQUUsS0FBSyxVQUFVO0FBQzVGO01BQ0Q7SUFDRDtBQUlBLFFBQUksQ0FBQyxRQUFRO0FBQ1osVUFBSSxjQUFjO0FBQ2xCLGlCQUFXLEtBQUssWUFBWTtBQUMzQixjQUFNLFlBQVksRUFBRSxXQUFXLEtBQUssQ0FBQyxNQUFVO0FBQzlDLGNBQUksRUFBRSxXQUFXO0FBQVEsbUJBQU87QUFDaEMsZ0JBQU0sV0FBVyxFQUFFLFNBQVMsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLE9BQU87QUFDN0QsY0FBSSxDQUFDLFVBQVU7QUFBUyxtQkFBTztBQUMvQixjQUFJLE1BQU0sRUFBRTtBQUFJLG1CQUFPO0FBQ3ZCLGdCQUFNLFNBQVMsS0FBSyxFQUFFO0FBQ3RCLGdCQUFNLFNBQVMsaUJBQWlCLElBQUksR0FBRyxNQUFNLElBQUksRUFBRSxFQUFFLEVBQUUsS0FBSztBQUM1RCxpQkFBTyxVQUFVO1FBQ2xCLENBQUM7QUFDRCxZQUFJLFdBQVc7QUFDZCx3QkFBYztBQUNkLFVBQUFBLFFBQU8sTUFDTixVQUFVLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsNENBQTRDLE1BQU0sVUFBVSxFQUFFLENBQUMsNkJBQXdCO0FBRS9IO1FBQ0Q7TUFDRDtBQUNBLFVBQUk7QUFBYTtJQUNsQjtBQUdBLFFBQUksQ0FBQyxRQUFRO0FBQ1osZUFBUztRQUNSO1FBQ0E7UUFDQSxNQUFNLGVBQWUsTUFBTSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsRUFBRSxZQUFXLENBQUU7UUFDaEUsU0FBUyxDQUFDLG1CQUFtQixVQUFVLENBQUM7O0FBRXpDLFVBQUksVUFBVTtBQUFXLGVBQU8sUUFBUTtBQUN4QyxNQUFBQSxRQUFPLEtBQUssMEJBQTBCLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsRUFBRTtJQUN0RSxPQUFPO0FBSU4sYUFBTyxVQUFVLE9BQU8sU0FBUyxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTyxLQUFLLENBQUE7QUFDcEUsYUFBTyxPQUFPO0FBRWQsWUFBTSxrQkFBa0IsVUFBVSxJQUFJLEdBQUcsTUFBTSxJQUFJLEVBQUUsRUFBRTtBQUN2RCxVQUFJLG1CQUFtQixnQkFBZ0IsT0FBTyxHQUFHO0FBQ2hELGNBQU0sV0FBVyxLQUFLLElBQUksR0FBRyxlQUFlO0FBQzVDLFlBQUksYUFBYSxHQUFHO0FBRW5CLGlCQUFPLFFBQVE7UUFDaEIsT0FBTztBQUVOLGdCQUFNLGVBQWUsTUFBTSxLQUFLLEVBQUUsUUFBUSxXQUFXLEVBQUMsR0FBSSxDQUFDLEdBQUcsT0FBTztZQUNwRSxJQUFJO1lBQ0osT0FBTyxXQUFXLElBQUksQ0FBQztZQUN0QjtBQUNGLGlCQUFPLFFBQVEsUUFBUTtZQUN0QixJQUFJO1lBQ0osT0FBTztZQUNQLE1BQU07WUFDTixTQUFTO1lBQ1QsU0FBUztXQUNUO1FBQ0Y7TUFDRDtBQU1BLFlBQU0sa0JBQWtCLG1CQUFtQixVQUFVLEVBQUU7QUFDdkQsWUFBTSxXQUFXLE9BQU8sU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUM3RCxVQUFJLFVBQVU7QUFDYixZQUFJLFNBQVMsV0FBVyxNQUFNLFFBQVEsU0FBUyxPQUFPLEdBQUc7QUFDeEQsZ0JBQU0sWUFBWSxTQUFTLFFBQVEsS0FBSyxDQUFDLE1BQVcsRUFBRSxPQUFPLGVBQWU7QUFDNUUsY0FBSSxDQUFDLFdBQVc7QUFDZixZQUFBQSxRQUFPLEtBQ04sK0JBQStCLE1BQU0sTUFBTSxDQUFDLE9BQU8sTUFBTSxFQUFFLENBQUMsaUNBQWlDLGVBQWUsc0NBQWlDO0FBRzlJLHFCQUFTLE9BQU87QUFDaEIsbUJBQVEsU0FBaUI7VUFDMUI7UUFDRDtBQUNBLGlCQUFTLFVBQVU7TUFDcEI7SUFDRDtBQUVBLFFBQUksVUFBVSxLQUFLLE1BQU07RUFDMUI7QUFTQSxhQUFXLEVBQUUsUUFBUSxHQUFFLEtBQU0sUUFBUTtBQUNwQyxVQUFNLGtCQUFrQixJQUFJLFVBQVUsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLEVBQUU7QUFDcEYsUUFBSTtBQUFpQjtBQUdyQixVQUFNLFlBQVksSUFBSSxVQUFVLEtBQUssQ0FBQyxNQUFLO0FBQzFDLFVBQUksRUFBRSxXQUFXO0FBQVEsZUFBTztBQUNoQyxZQUFNQyxZQUFXLEVBQUUsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTztBQUN4RCxhQUFPLENBQUMsQ0FBQ0EsV0FBVSxXQUFXLEtBQUssRUFBRTtJQUN0QyxDQUFDO0FBQ0QsUUFBSSxDQUFDO0FBQVc7QUFFaEIsVUFBTSxTQUFTLEtBQUssVUFBVTtBQUM5QixVQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLFFBQUksQ0FBQyxVQUFVLFdBQVcsU0FBUyxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxNQUFNO0FBQUc7QUFJOUUsVUFBTSxlQUFlLFdBQVcsS0FBSyxDQUFDLE1BQUs7QUFDMUMsWUFBTSxXQUFXLEVBQUUsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU8sVUFBVSxFQUFFO0FBQ3RGLFlBQU0sV0FBVyxVQUFVLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDaEUsYUFBTyxVQUFVLFNBQVMsS0FBSyxDQUFDLE9BQVksR0FBRyxPQUFPLE1BQU07SUFDN0QsQ0FBQztBQUNELFVBQU0sa0JBQWtCLFNBQVMsUUFBUSxJQUFJLENBQUMsTUFBVyxFQUFFLEVBQVksRUFBRSxLQUFLLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQztBQUM3RixVQUFNLGVBQWUsZ0JBQWdCLFNBQVMsS0FBSyxXQUFXLGdCQUFnQixnQkFBZ0IsU0FBUyxDQUFDLElBQUk7QUFFNUcsUUFBSSxDQUFDLGdCQUFnQixDQUFDO0FBQWM7QUFHcEMsUUFBSSxRQUFRLFdBQVcsU0FBUyxDQUFDO0FBQ2pDLGVBQVcsS0FBSyxZQUFZO0FBQzNCLFlBQU0sV0FBVyxFQUFFLFdBQVcsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFVBQVUsRUFBRSxPQUFPLFVBQVUsRUFBRTtBQUN0RixZQUFNLFdBQVcsVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ2hFLFlBQU0sWUFBWSxVQUFVLFNBQVMsS0FBSyxDQUFDLE9BQVksR0FBRyxPQUFPLE1BQU07QUFDdkUsVUFBSSxXQUFXO0FBQ2QsZ0JBQVEsVUFBVTtBQUNsQjtNQUNEO0lBQ0Q7QUFFQSxhQUFTLFFBQVEsS0FBSyxFQUFFLElBQUksUUFBUSxNQUFLLENBQUU7QUFDM0MsSUFBQUQsUUFBTyxLQUNOLHlCQUF5QixNQUFNLE1BQU0sQ0FBQyxPQUFPLE1BQU0sRUFBRSxDQUFDLHVCQUF1QixNQUFNLFVBQVUsRUFBRSxDQUFDLGNBQWMsTUFBTSxNQUFNLEtBQUssSUFBSTtFQUVySTtBQUVBLFNBQU87QUFDUjtBQU1NLFNBQVUsb0JBQW9CLFVBQWtCLFNBQW9CO0FBQ3pFLE1BQUk7QUFFSCxVQUFNLGFBQWtCLEVBQUUsT0FBTyxRQUFRLE1BQUs7QUFHOUMsUUFBSSxlQUFlLFNBQVM7QUFDM0IsaUJBQVcsWUFBWSxRQUFRO0lBQ2hDO0FBR0EsUUFBSSxlQUFlLFNBQVM7QUFDM0IsaUJBQVcsWUFBWSxRQUFRLFVBQVUsSUFBSSxDQUFDLFVBQWM7QUFFM0QsY0FBTSxlQUFvQixDQUFBO0FBQzFCLFlBQUksWUFBWTtBQUFPLHVCQUFhLFNBQVMsTUFBTTtBQUNuRCxZQUFJLFFBQVE7QUFBTyx1QkFBYSxLQUFLLE1BQU07QUFDM0MsWUFBSSxXQUFXO0FBQU8sdUJBQWEsUUFBUSxNQUFNO0FBQ2pELFlBQUksVUFBVTtBQUFPLHVCQUFhLE9BQU8sTUFBTTtBQUMvQyxZQUFJLFdBQVc7QUFBTyx1QkFBYSxRQUFRLE1BQU07QUFDakQsWUFBSSxhQUFhO0FBQU8sdUJBQWEsVUFBVSxNQUFNO0FBRXJELG1CQUFXLE9BQU8sT0FBTyxLQUFLLEtBQUssR0FBRztBQUNyQyxjQUFJLEVBQUUsT0FBTztBQUFlLHlCQUFhLEdBQUcsSUFBSSxNQUFNLEdBQUc7UUFDMUQ7QUFDQSxlQUFPO01BQ1IsQ0FBQztJQUNGO0FBRUEsZUFBVyxPQUFPLE9BQU8sS0FBSyxPQUFPLEdBQUc7QUFDdkMsVUFBSSxFQUFFLE9BQU8sYUFBYTtBQUN6QixtQkFBVyxHQUFHLElBQUssUUFBZ0IsR0FBRztNQUN2QztJQUNEO0FBR0EsUUFBSSxPQUFPLEtBQUssVUFBVSxZQUFZLE1BQU0sQ0FBQztBQUs3QyxXQUFPLEtBQUssUUFBUSwwREFBMEQsNkJBQTZCO0FBRTNHLElBQUFFLElBQUcsY0FBYyxVQUFVLE9BQU8sTUFBTSxNQUFNO0VBQy9DLFNBQVMsR0FBRztBQUNYLElBQUFGLFFBQU8sTUFBTSxxQkFBcUIsQ0FBQyxFQUFFO0VBQ3RDO0FBQ0Q7OztBRHZyQkEsSUFBTUcsVUFBUyxtQkFBbUIsU0FBUztBQUVyQyxTQUFVLGNBQWMsTUFBb0I7QUFDakQsUUFBTSxhQUFhLGlCQUFnQjtBQUNuQyxRQUFNLGFBQWEsYUFBWTtBQUMvQixRQUFNLFVBQVUscUJBQXFCLFVBQVU7QUFDL0MsUUFBTSxlQUFvQixDQUFBO0FBRTFCLFFBQU0sY0FBYyxLQUFLO0FBTXpCLE1BQUksS0FBSyxPQUFPLFNBQVM7QUFDeEIsaUJBQWEsdUJBQXVCLElBQUk7TUFDdkMsTUFBTTtNQUNOLGFBQWE7TUFDYixTQUFTLENBQUE7TUFDVCxVQUFVLFlBQVc7QUFDcEIsY0FBTSxRQUFRO0FBQ2QsY0FBTSxLQUFLLEtBQUs7QUFFaEIsY0FBTSxNQUFNLE1BQU0sS0FBSyxhQUFhLG1CQUFtQixFQUFFO0FBRXpELFlBQUksWUFBWSxnQkFBZ0IsS0FBSztBQUVyQyxjQUFNLEVBQUUsVUFBVSxPQUFNLElBQUssaUNBQWlDLE9BQU8sR0FBRztBQUN4RSxRQUFBQSxRQUFPLE1BQU0saUJBQWlCLEtBQUssVUFBVSxNQUFNLENBQUMsRUFBRTtBQUV0RCxZQUFJLENBQUMsV0FBVztBQUNmLFVBQUFBLFFBQU8sS0FBSyxTQUFTLEtBQUssdURBQWtEO0FBQzVFLHNCQUFZO1lBQ1g7WUFDQSxXQUFXLENBQUE7O1FBRWI7QUFFQSxjQUFNLFVBQVUsNEJBQTRCLFdBQVcsUUFBUSxPQUFPO0FBQ3RFLFFBQUFBLFFBQU8sTUFBTSxxQkFBcUIsS0FBSyxVQUFVLFNBQVMsTUFBTSxDQUFDLENBQUMsRUFBRTtBQUVwRSxjQUFNQyxpQkFBZ0IsaUJBQWdCO0FBQ3RDLGNBQU0sYUFBYUMsTUFBSyxLQUFLRCxnQkFBZSxRQUFRLEtBQUssT0FBTztBQUNoRSw0QkFBb0IsWUFBWSxPQUFPO0FBRXZDLDRCQUFtQjtBQUVuQixRQUFBRCxRQUFPLEtBQUssU0FBUyxLQUFLLHdDQUF3QztNQUNuRTs7RUFFRjtBQU1BLGFBQVcsQ0FBQyxVQUFVLE1BQU0sS0FBSyxPQUFPLFFBQVEsVUFBVSxHQUFHO0FBQzVELFVBQU0sRUFBRSxPQUFPLE9BQU8sT0FBTSxJQUFLLGVBQWUsUUFBUTtBQUd4RCxRQUFJLFVBQVU7QUFBYTtBQUszQixVQUFNLFlBQVksV0FBVyxLQUFLO0FBQ2xDLFVBQU0sWUFBWSxXQUFXLFdBQVcsS0FBSyxDQUFDLE1BQVcsRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLE1BQU07QUFFOUYsaUJBQWEsUUFBUSxJQUFJO01BQ3hCLEdBQUc7TUFDSCxVQUFVLE9BQU8sVUFBYztBQUM5QixjQUFNLEtBQUssS0FBSztBQUNoQixjQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFZLE1BQU0sUUFBUSxPQUFPLElBQUksV0FBVztBQUN6RixjQUFNLFFBQVEsV0FBVyxVQUFVLFNBQVksVUFBVSxRQUFRLE1BQU0sUUFBUSxPQUFPO0FBQ3RGLGNBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTyxLQUFLO0FBQ3hDLGNBQU0sWUFBWSxTQUFTO0FBRTNCLGNBQU0sS0FBSyxhQUFhLGFBQWEsT0FBTyxPQUFPLFdBQVcsT0FBTyxFQUFFO01BQ3hFO01BQ0EsR0FBSSxXQUFXLFVBQVUsVUFBYTtRQUNyQyxPQUFPLENBQUMsVUFBYztBQUNyQixnQkFBTSxLQUFLLEtBQUs7QUFDaEIsZ0JBQU0sUUFBUSxNQUFNLFFBQVEsT0FBTyxLQUFLO0FBQ3hDLGdCQUFNLFlBQVksU0FBUztBQUMzQixnQkFBTSxRQUFRLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBWSxNQUFNLFFBQVEsT0FBTyxJQUFJLFdBQVc7QUFFekYsZ0JBQU0sVUFBVSxLQUFLLGFBQWEsZ0JBQWdCLElBQUksT0FBTyxXQUFXLEtBQUs7QUFDN0UsY0FBSSxZQUFZO0FBQVcsbUJBQU87QUFFbEMsaUJBQU8sRUFBRSxHQUFHLE1BQU0sU0FBUyxPQUFPLFFBQU87UUFDMUM7OztFQUdIO0FBS0EsUUFBTSxlQUFlLFFBQVEsV0FBVztBQUN4QyxNQUFJLGNBQWM7QUFDakIsVUFBTSxtQkFBbUIsYUFBYSxhQUFhLENBQUEsR0FBSSxLQUFLLENBQUMsTUFBVyxFQUFFLEtBQUssU0FBUyxNQUFNLENBQUM7QUFFL0YsUUFBSSxpQkFBaUI7QUFDcEIsWUFBTSxXQUFXLEdBQUcsV0FBVztBQUUvQixtQkFBYSxRQUFRLElBQUk7UUFDeEIsTUFBTSxTQUFTLFdBQVc7UUFDMUIsU0FBUyxDQUFBO1FBQ1QsVUFBVSxZQUFXO0FBQ3BCLGdCQUFNLEtBQUssS0FBSztBQUNoQixVQUFBQSxRQUFPLEtBQUsseUJBQW9CLFdBQVcsTUFBTSxFQUFFLEVBQUU7QUFDckQsZ0JBQU0sS0FBSyxhQUFhLGNBQWMsRUFBRTtBQUN4QyxnQkFBTSxLQUFLLGFBQWEsbUJBQW1CLEVBQUUsRUFBRSxNQUFNLENBQUMsUUFBTztBQUM1RCxZQUFBQSxRQUFPLEtBQUssNkNBQTZDLEdBQUcsRUFBRTtVQUMvRCxDQUFDO1FBQ0Y7O0lBRUY7RUFDRDtBQUVBLE9BQUsscUJBQXFCLFlBQVk7QUFDdkM7OztBRTFIQSxTQUFTLGlCQUNSLFNBQ0EsT0FDQSxPQUNBLFdBQ0EsT0FBYTtBQUViLFFBQU0sVUFBVSxxQkFBcUIsU0FBUyxPQUFPLE9BQU8sU0FBUztBQUNyRSxNQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sUUFBUSxRQUFRLE9BQU87QUFBRyxXQUFPO0FBR3hELFFBQU0sY0FBYyxRQUFRLFFBQVEsS0FBSyxDQUFDLFFBQWEsSUFBSSxPQUFPLE9BQU87QUFDekUsTUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLFFBQVEsWUFBWSxPQUFPO0FBQUcsV0FBTztBQUdoRSxRQUFNLFNBQVMsWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFXLEVBQUUsT0FBTyxLQUFLO0FBQ2xFLFNBQU8sUUFBUSxTQUFTO0FBQ3pCO0FBTU0sU0FBVSxnQkFBZ0IsTUFBb0I7QUFDbkQsUUFBTSxhQUFhLGlCQUFnQjtBQUNuQyxRQUFNLGVBQWUsZUFBYztBQUNuQyxRQUFNLFVBQVUscUJBQXFCLFVBQVU7QUFDL0MsUUFBTSxpQkFBc0IsQ0FBQTtBQUc1QixRQUFNLGNBQWMsS0FBSztBQU16QixhQUFXLENBQUMsWUFBWSxRQUFRLEtBQUssT0FBTyxRQUFRLFlBQVksR0FBRztBQUVsRSxVQUFNLFVBQVUsV0FBVyxTQUFTLE9BQU8sSUFBSSxXQUFXLE1BQU0sR0FBRyxFQUFFLElBQUk7QUFDekUsVUFBTSxFQUFFLE9BQU8sT0FBTyxPQUFNLElBQUssZUFBZSxPQUFPO0FBR3ZELFFBQUksVUFBVTtBQUFhO0FBRzNCLG1CQUFlLFVBQVUsSUFBSTtNQUM1QixHQUFHO01BQ0gsVUFBVSxDQUFDLGtCQUFzQjtBQUNoQyxjQUFNLEtBQUssS0FBSztBQUNoQixjQUFNLFFBQVEsY0FBYyxRQUFRLE9BQU8sS0FBSztBQUNoRCxjQUFNLFlBQVksU0FBUztBQUczQixZQUFJLFFBQVEsY0FBYyxRQUFRLE9BQU87QUFDekMsWUFBSSxVQUFVLFFBQVc7QUFDeEIsZ0JBQU0sZUFBZSxxQkFBcUIsU0FBUyxPQUFPLE9BQU8sU0FBUztBQUMxRSxjQUFJLGNBQWMsVUFBVSxRQUFXO0FBQ3RDLG9CQUFRLGFBQWE7VUFDdEI7UUFDRDtBQUdBLFlBQUksVUFBVSxRQUFXO0FBQ3hCLGdCQUFNLFlBQVksV0FBVyxLQUFLLEdBQUcsV0FBVyxLQUFLLENBQUMsTUFBVyxFQUFFLFdBQVcsU0FBUyxFQUFFLE9BQU8sU0FBUztBQUN6RyxjQUFJLFdBQVcsVUFBVSxRQUFXO0FBQ25DLG9CQUFRLFVBQVU7VUFDbkI7UUFDRDtBQUVBLGNBQU0sVUFBVSxLQUFLLGFBQWEsZ0JBQWdCLElBQUksT0FBTyxXQUFXLEtBQUs7QUFNN0UsWUFBSSxXQUFXLFNBQVMsT0FBTyxHQUFHO0FBQ2pDLGlCQUFPLFlBQVksVUFBYSxZQUFZO1FBQzdDO0FBR0EsY0FBTSxZQUFZLGNBQWMsUUFBUSxXQUFXLEtBQUs7QUFFeEQsWUFBSSxhQUFhLFlBQVksUUFBVztBQUN2QyxnQkFBTSxRQUFRLGlCQUFpQixTQUFTLE9BQU8sT0FBTyxXQUFXLE9BQU87QUFHeEUsY0FBSSxPQUFPLFVBQVUsVUFBVTtBQUM5QixtQkFBTyxVQUFVLElBQUksU0FBUztVQUMvQjtBQUNBLGlCQUFPO1FBQ1I7QUFHQSxlQUFPLFdBQVc7TUFDbkI7O0VBRUY7QUFFQSxPQUFLLHVCQUF1QixjQUFjO0FBQzNDOzs7QUMzR0EsT0FBT0csWUFBVztBQUNsQixPQUFPQyxTQUFROzs7QUNEZixPQUFPLFdBQVc7QUFDbEIsT0FBTyxRQUFRO0FBSWYsSUFBTUMsVUFBUyxtQkFBbUIsT0FBTztBQUt6QyxJQUFNLHlCQUF5QjtBQUV4QixJQUFNLDBCQUEwQjtBQUN2QyxJQUFNLHFCQUFxQixNQUFPO0FBRWxDLFNBQVMsd0JBQXFCO0FBQzdCLFFBQU0sTUFBTSxPQUFPLE1BQU0sSUFBSSxDQUFDO0FBQzlCLFFBQU0sTUFBTSxLQUFLLE1BQU0sS0FBSyxPQUFNLElBQUssS0FBTTtBQUU3QyxNQUFJLGNBQWMsT0FBUSxDQUFDO0FBQzNCLE1BQUksY0FBYyx3QkFBd0IsQ0FBQztBQUMzQyxNQUFJLGNBQWMsS0FBSyxDQUFDO0FBRXhCLFFBQU0sTUFBTSxpQkFBZ0I7QUFDNUIsTUFBSSxLQUFLLEtBQUssQ0FBQztBQUVmLFNBQU8sS0FBSyxZQUFZLE9BQU8sRUFBRSxLQUFLLEtBQUssRUFBRTtBQUM3QyxNQUFJLGNBQWMsTUFBUSxFQUFFO0FBQzVCLE1BQUksY0FBYyxLQUFRLEVBQUU7QUFDNUIsTUFBSSxjQUFjLEtBQVksRUFBRTtBQUVoQyxTQUFPO0FBQ1I7QUFHQSxTQUFTLG1CQUFnQjtBQUN4QixNQUFJO0FBQ0gsVUFBTSxTQUFTLEdBQUcsa0JBQWlCO0FBQ25DLGVBQVcsUUFBUSxPQUFPLEtBQUssTUFBTSxHQUFHO0FBQ3ZDLGlCQUFXLFFBQVEsT0FBTyxJQUFJLEtBQUssQ0FBQSxHQUFJO0FBQ3RDLFlBQUksQ0FBQyxLQUFLLFlBQVksS0FBSyxXQUFXLFVBQVUsS0FBSyxPQUFPLEtBQUssUUFBUSxxQkFBcUI7QUFDN0YsaUJBQU8sT0FBTyxLQUFLLEtBQUssSUFBSSxNQUFNLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBYyxTQUFTLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFDM0U7TUFDRDtJQUNEO0VBQ0QsUUFBUTtFQUVSO0FBQ0EsU0FBTyxPQUFPLE1BQU0sR0FBRyxDQUFDO0FBQ3pCO0FBRU0sU0FBVSx1QkFBdUIsS0FBYSxPQUFhO0FBQ2hFLE1BQUksSUFBSSxTQUFTO0FBQW9CLFdBQU87QUFDNUMsTUFBSSxJQUFJLGFBQWEsQ0FBQyxNQUFNO0FBQVEsV0FBTztBQUMzQyxNQUFJLElBQUksYUFBYSxDQUFDLE1BQU07QUFBeUIsV0FBTztBQUM1RCxNQUFJLElBQUksU0FBUyxJQUFJLEVBQUUsRUFBRSxTQUFTLE9BQU8sTUFBTTtBQUFZLFdBQU87QUFFbEUsUUFBTSxVQUFVLENBQUMsUUFBZ0IsUUFDaEMsSUFDRSxTQUFTLFFBQVEsU0FBUyxHQUFHLEVBQzdCLFNBQVMsT0FBTyxFQUNoQixNQUFNLElBQUksRUFBRSxDQUFDLEVBQ2IsS0FBSTtBQUVQLFFBQU0sUUFBUSxJQUFJLFNBQVMsR0FBRyxFQUFFO0FBQ2hDLFFBQU0sV0FBVyxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDO0FBQzVFLFFBQU0sTUFBTSxTQUFTLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUFFLEtBQUssR0FBRztBQUV6RSxRQUFNLE9BQU8sUUFBUSxJQUFNLEVBQUU7QUFDN0IsUUFBTSxlQUFlLFFBQVEsSUFBTSxFQUFFO0FBQ3JDLFFBQU0sV0FBVyxRQUFRLEtBQU0sRUFBRTtBQUNqQyxRQUFNLGdCQUFnQixHQUFHLElBQUksRUFBSSxDQUFDLElBQUksSUFBSSxFQUFJLENBQUM7QUFFL0MsTUFBSSxDQUFDO0FBQVUsV0FBTztBQUl0QixRQUFNLFFBQVEsU0FDWixRQUFRLGNBQWMsRUFBRSxFQUN4QixLQUFJLEVBQ0osTUFBTSxLQUFLLEVBQUUsQ0FBQztBQUVoQixTQUFPO0lBQ04sSUFBSTtJQUNKO0lBQ0E7SUFDQTtJQUNBLFdBQVc7O0lBQ1g7SUFDQTs7QUFFRjtBQU9BLGVBQXNCLHFCQUFxQixRQUFjO0FBQ3hELFNBQU8sSUFBSSxRQUFrQixDQUFDLFNBQVMsV0FBVTtBQUNoRCxVQUFNLE1BQU0sTUFBTSxhQUFhLE1BQU07QUFFckMsUUFBSSxLQUFLLFNBQVMsQ0FBQyxRQUFPO0FBQ3pCLFVBQUksTUFBSztBQUNULGFBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO0lBQzdDLENBQUM7QUFFRCxRQUFJLFFBQVEsR0FBRyxRQUFRLE1BQUs7QUFDM0IsVUFBSTtBQUNILGNBQU0sT0FBTyxJQUFJLFFBQU87QUFDeEIsY0FBTSxZQUFZLEtBQUs7QUFDdkIsWUFBSSxNQUFLO0FBRVQsY0FBTSxTQUFTLEdBQUcsa0JBQWlCO0FBQ25DLG1CQUFXLFFBQVEsT0FBTyxLQUFLLE1BQU0sR0FBRztBQUN2QyxxQkFBVyxTQUFTLE9BQU8sSUFBSSxLQUFLLENBQUEsR0FBSTtBQUN2QyxnQkFDQyxNQUFNLFdBQVcsVUFDakIsTUFBTSxZQUFZLGFBQ2xCLE1BQU0sT0FDTixNQUFNLFFBQVEscUJBQ2I7QUFDRCxxQkFBTyxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBTSxTQUFTLEdBQUcsRUFBRSxJQUFJLEdBQUksQ0FBQztZQUN2RTtVQUNEO1FBQ0Q7QUFDQSxlQUFPLElBQUksTUFBTSx3Q0FBd0MsU0FBUyxFQUFFLENBQUM7TUFDdEUsU0FBUyxJQUFJO0FBQ1osZUFBTyxJQUFJLE1BQU0sT0FBTyxFQUFFLENBQUMsQ0FBQztNQUM3QjtJQUNELENBQUM7RUFDRixDQUFDO0FBQ0Y7QUFNQSxlQUFzQiw4QkFBOEIsUUFBYztBQUNqRSxTQUFPLElBQUksUUFBZ0IsQ0FBQyxTQUFTLFdBQVU7QUFDOUMsVUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBRXJDLFFBQUksV0FBVztBQUNmLFFBQUksS0FBSyxTQUFTLENBQUMsUUFBTztBQUN6QixVQUFJLENBQUMsVUFBVTtBQUNkLG1CQUFXO0FBQ1gsWUFBSSxNQUFLO0FBQ1QsZUFBTyxJQUFJLE1BQU0sSUFBSSxXQUFXLE9BQU8sR0FBRyxDQUFDLENBQUM7TUFDN0M7SUFDRCxDQUFDO0FBR0QsUUFBSSxRQUFRLEdBQUcsUUFBUSxNQUFLO0FBQzNCLFVBQUk7QUFDSCxjQUFNLE9BQU8sSUFBSSxRQUFPO0FBQ3hCLGNBQU0sWUFBWSxLQUFLO0FBQ3ZCLFlBQUksQ0FBQyxVQUFVO0FBQ2QscUJBQVc7QUFDWCxjQUFJLE1BQUs7QUFDVCxrQkFBUSxTQUFTO1FBQ2xCO01BQ0QsU0FBUyxJQUFJO0FBQ1osWUFBSSxDQUFDLFVBQVU7QUFDZCxxQkFBVztBQUNYLGNBQUksTUFBSztBQUNULGlCQUFPLElBQUksTUFBTSxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQzdCO01BQ0Q7SUFDRCxDQUFDO0VBQ0YsQ0FBQztBQUNGO0FBV0EsZUFBc0IsZ0JBQ3JCLFVBQ0Esa0JBQ0EsWUFBWSxLQUFJO0FBRWhCLFFBQU0sdUJBQXVCO0FBQzdCLFFBQU0sc0JBQXNCO0FBQzVCLFFBQU0sZUFBZTtBQUVyQixRQUFNLGFBQWEsb0JBQUksSUFBRztBQUUxQixTQUFPLElBQUksUUFBYyxDQUFDLFlBQVc7QUFDcEMsVUFBTSxpQkFBaUIsTUFBTSxhQUFhLEVBQUUsTUFBTSxRQUFRLFdBQVcsS0FBSSxDQUFFO0FBQzNFLFVBQU0sbUJBQTZCLENBQUE7QUFFbkMsVUFBTSxVQUFVLE1BQUs7QUFDcEIsaUJBQVcsU0FBUyxrQkFBa0I7QUFDckMsWUFBSTtBQUNILHlCQUFlLGVBQWUsc0JBQXNCLEtBQUs7UUFDMUQsUUFBUTtRQUVSO01BQ0Q7QUFDQSxVQUFJO0FBQ0gsdUJBQWUsTUFBSztNQUNyQixRQUFRO01BRVI7QUFDQSxjQUFPO0lBQ1I7QUFFQSxVQUFNLFFBQVEsV0FBVyxTQUFTLFNBQVM7QUFDM0MsVUFBTSxRQUFPO0FBRWIsbUJBQWUsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNsQyxNQUFBQSxRQUFPLEtBQUssMEJBQTBCLElBQUksT0FBTyxFQUFFO0lBQ3BELENBQUM7QUFFRCxtQkFBZSxHQUFHLFdBQVcsQ0FBQyxLQUFLLFVBQVM7QUFDM0MsWUFBTSxRQUFRLE1BQU07QUFFcEIsVUFBSSxJQUFJLFNBQVM7QUFBSTtBQUNyQixVQUFJLElBQUksYUFBYSxDQUFDLE1BQU07QUFBUTtBQUNwQyxVQUFJLElBQUksU0FBUyxJQUFJLEVBQUUsRUFBRSxTQUFTLE9BQU8sTUFBTTtBQUFZO0FBRTNELFVBQUksV0FBVyxJQUFJLEtBQUs7QUFBRztBQUMzQixpQkFBVyxJQUFJLEtBQUs7QUFDcEIsTUFBQUEsUUFBTyxNQUFNLGlCQUFpQixLQUFLLCtCQUEwQjtBQUs3RCxZQUFNLFlBQVksWUFBVztBQUM1QixjQUFNLGlCQUFpQixLQUFLO0FBQzVCLGNBQU0sUUFBUSxzQkFBcUI7QUFDbkMsaUJBQVMsS0FBSyxPQUFPLGNBQWMsT0FBTyxDQUFDLFFBQU87QUFDakQsY0FBSTtBQUFLLFlBQUFBLFFBQU8sS0FBSyxvQkFBb0IsS0FBSyxZQUFZLElBQUksT0FBTyxFQUFFO1FBQ3hFLENBQUM7TUFDRjtBQUNBLGdCQUFTLEVBQUcsTUFBTSxDQUFDLFFBQVFBLFFBQU8sS0FBSyx1QkFBdUIsR0FBRyxFQUFFLENBQUM7SUFDckUsQ0FBQztBQUVELG1CQUFlLEtBQUsscUJBQXFCLE1BQUs7QUFLN0MsWUFBTSxTQUFTLEdBQUcsa0JBQWlCO0FBQ25DLGlCQUFXLFNBQVMsT0FBTyxPQUFPLE1BQU0sR0FBRztBQUMxQyxtQkFBVyxRQUFRLFNBQVMsQ0FBQSxHQUFJO0FBQy9CLGNBQUksS0FBSyxXQUFXLFVBQVUsQ0FBQyxLQUFLLFVBQVU7QUFDN0MsZ0JBQUk7QUFDSCw2QkFBZSxjQUFjLHNCQUFzQixLQUFLLE9BQU87QUFDL0QsK0JBQWlCLEtBQUssS0FBSyxPQUFPO1lBQ25DLFFBQVE7WUFFUjtVQUNEO1FBQ0Q7TUFDRDtBQUNBLFVBQUksaUJBQWlCLFdBQVcsR0FBRztBQUNsQyxRQUFBQSxRQUFPLEtBQUssMERBQTBEO01BQ3ZFLE9BQU87QUFDTixRQUFBQSxRQUFPLE1BQU0sb0NBQW9DLG9CQUFvQixJQUFJLG1CQUFtQixFQUFFO01BQy9GO0lBQ0QsQ0FBQztFQUNGLENBQUM7QUFDRjtBQWVBLGVBQXNCLFlBQ3JCLFVBQ0Esa0JBQ0EsZ0JBQ0Esa0JBQ0EsSUFDQSxZQUFZLEtBQUk7QUFFaEIsU0FBTyxJQUFJLFFBQTJCLENBQUMsWUFBVztBQUNqRCxVQUFNLE1BQU0sV0FBVyxFQUFFO0FBQ3pCLFFBQUksV0FBVztBQUVmLFVBQU0sU0FBUyxDQUFDLFdBQTZCO0FBQzVDLFVBQUk7QUFBVTtBQUNkLGlCQUFXO0FBQ1gscUJBQWUsR0FBRztBQUNsQixjQUFRLE1BQU07SUFDZjtBQUVBLHFCQUFpQixLQUFLLENBQUMsV0FBc0I7QUFDNUMsVUFBSSxPQUFPLE9BQU87QUFBSSxlQUFPLE1BQU07SUFDcEMsQ0FBQztBQUVELFVBQU0sUUFBUSxXQUFXLE1BQU0sT0FBTyxJQUFJLEdBQUcsU0FBUztBQUN0RCxVQUFNLFFBQU87QUFFYixVQUFNLE1BQU0sWUFBVztBQUN0QixZQUFNLGlCQUFpQixFQUFFO0FBQ3pCLFlBQU0sUUFBUSxzQkFBcUI7QUFDbkMsZUFBUyxLQUFLLE9BQU8sTUFBTSxJQUFJLENBQUMsUUFBTztBQUN0QyxZQUFJLEtBQUs7QUFDUixVQUFBQSxRQUFPLEtBQUssWUFBWSxFQUFFLFlBQVksSUFBSSxPQUFPLEVBQUU7QUFDbkQsdUJBQWEsS0FBSztBQUNsQixpQkFBTyxJQUFJO1FBQ1o7TUFDRCxDQUFDO0lBQ0Y7QUFFQSxRQUFHLEVBQUcsTUFBTSxDQUFDLE1BQUs7QUFDakIsTUFBQUEsUUFBTyxLQUFLLGdDQUFnQyxFQUFFLEtBQUssQ0FBQyxFQUFFO0FBQ3RELG1CQUFhLEtBQUs7QUFDbEIsYUFBTyxJQUFJO0lBQ1osQ0FBQztFQUNGLENBQUM7QUFDRjs7O0FDdlVBLE9BQU9DLFlBQVc7QUFJbEIsSUFBTUMsVUFBUyxtQkFBbUIsUUFBUTtBQUcxQyxJQUFNLGlCQUFpQixvQkFBSSxJQUFHO0FBTzlCLGVBQXNCLGtCQUFrQixVQUFrQixZQUFZLEtBQUk7QUFDekUsUUFBTSxVQUFVLGVBQWUsSUFBSSxRQUFRO0FBQzNDLE1BQUk7QUFBUyxXQUFPO0FBRXBCLFFBQU0sVUFBVSxpQkFBaUIsVUFBVSxTQUFTLEVBQUUsUUFBUSxNQUFLO0FBQ2xFLG1CQUFlLE9BQU8sUUFBUTtFQUMvQixDQUFDO0FBQ0QsaUJBQWUsSUFBSSxVQUFVLE9BQU87QUFDcEMsU0FBTztBQUNSO0FBRUEsZUFBZSxpQkFBaUIsVUFBa0IsV0FBaUI7QUFDbEUsU0FBTyxJQUFJLFFBQTZCLENBQUMsWUFBVztBQUNuRCxRQUFJLFVBQVU7QUFDZCxRQUFJLGlCQUF3RDtBQUU1RCxVQUFNLGVBQWUsQ0FBQ0MsVUFBc0I7QUFDM0MsVUFBSSxnQkFBZ0I7QUFDbkIsc0JBQWMsY0FBYztBQUM1Qix5QkFBaUI7TUFDbEI7QUFDQSxVQUFJO0FBQ0gsUUFBQUEsTUFBSyxNQUFLO01BQ1gsUUFBUTtNQUVSO0FBQ0EsTUFBQUQsUUFBTyxNQUFNLDZCQUE2QixRQUFRLEVBQUU7SUFDckQ7QUFFQSxVQUFNLE9BQU8sQ0FBQ0MsVUFBc0I7QUFDbkMsVUFBSTtBQUFTO0FBQ2IsZ0JBQVU7QUFDVixtQkFBYSxLQUFLO0FBQ2xCLG1CQUFhQSxLQUFJO0FBQ2pCLE1BQUFELFFBQU8sTUFBTSxzQ0FBc0MsUUFBUSxFQUFFO0FBQzdELGNBQVEsSUFBSTtJQUNiO0FBRUEsVUFBTSxPQUFPRSxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFDakUsVUFBTSxRQUFRLFdBQVcsTUFBTSxLQUFLLElBQUksR0FBRyxTQUFTO0FBRXBELFNBQUssR0FBRyxTQUFTLENBQUMsUUFBTztBQUN4QixNQUFBRixRQUFPLEtBQUssMkJBQTJCLFFBQVEsS0FBSyxJQUFJLE9BQU8sRUFBRTtBQUNqRSxXQUFLLElBQUk7SUFDVixDQUFDO0FBRUQsU0FBSyxHQUFHLFdBQVcsQ0FBQyxRQUFlO0FBRWxDLFVBQUksQ0FBQyxXQUFXLElBQUksVUFBVSxLQUFLLElBQUksQ0FBQyxNQUFNLE1BQVEsSUFBSSxDQUFDLE1BQU0sSUFBTTtBQUN0RSxrQkFBVTtBQUNWLHFCQUFhLEtBQUs7QUFDbEIsUUFBQUEsUUFBTyxLQUFLLG1DQUFtQyxRQUFRLEVBQUU7QUFFekQsWUFBSSxlQUFlLEtBQUssTUFBTSxLQUFLLE9BQU0sSUFBSyxLQUFNLElBQUk7QUFDeEQsY0FBTSxnQkFBZ0IsTUFBSztBQUMxQixnQkFBTSxNQUFNLE9BQU8sTUFBTSxJQUFJLENBQUM7QUFDOUIsY0FBSSxDQUFDLElBQUk7QUFDVCxjQUFJLENBQUMsSUFBSTtBQUNULGNBQUksY0FBYyxpQkFBaUIsT0FBUSxDQUFDO0FBQzVDLGNBQUksQ0FBQyxJQUFJO0FBQ1QsY0FBSSxDQUFDLElBQUk7QUFDVCxlQUFLLEtBQUssS0FBSyxNQUFNLFVBQVUsTUFBSztVQUVwQyxDQUFDO1FBQ0Y7QUFDQSx5QkFBaUIsWUFBWSxlQUFlLEdBQUk7QUFDaEQsZ0JBQVEsTUFBTSxhQUFhLElBQUksQ0FBQztNQUNqQztJQUNELENBQUM7QUFFRCxVQUFNLFNBQVMsWUFBVztBQUN6QixVQUFJO0FBQ0osVUFBSTtBQUNKLFVBQUk7QUFDSCxrQkFBVSxNQUFNLDhCQUE4QixRQUFRO0FBQ3RELG1CQUFXLE1BQU0scUJBQXFCLFFBQVE7TUFDL0MsU0FBUyxHQUFHO0FBQ1gsUUFBQUEsUUFBTyxLQUFLLGdEQUFnRCxRQUFRLEtBQUssQ0FBQyxFQUFFO0FBQzVFLGFBQUssSUFBSTtBQUNUO01BQ0Q7QUFFQSxXQUFLLEtBQUssRUFBRSxNQUFNLE1BQU0sU0FBUyxRQUFPLEdBQUksTUFBSztBQUNoRCxjQUFNLE1BQU0sS0FBSyxNQUFNLEtBQUssT0FBTSxJQUFLLEtBQU0sSUFBSTtBQUNqRCxjQUFNLE1BQU0sT0FBTyxNQUFNLElBQUksQ0FBQztBQUM5QixZQUFJLENBQUMsSUFBSTtBQUNULFlBQUksQ0FBQyxJQUFJO0FBQ1QsWUFBSSxjQUFjLEtBQUssQ0FBQztBQUN4QixZQUFJLENBQUMsSUFBSTtBQUNULFlBQUksQ0FBQyxJQUFJO0FBQ1QsaUJBQVMsUUFBUSxDQUFDLEdBQUcsTUFBSztBQUN6QixjQUFJLEtBQUssQ0FBQyxJQUFJO1FBQ2YsQ0FBQztBQUNELFFBQUFBLFFBQU8sTUFBTSxnQkFBZ0IsUUFBUSxLQUFLLElBQUksU0FBUyxLQUFLLENBQUMsRUFBRTtBQUMvRCxhQUFLLEtBQUssS0FBSyxNQUFNLFVBQVUsQ0FBQyxRQUFPO0FBQ3RDLGNBQUksS0FBSztBQUNSLFlBQUFBLFFBQU8sS0FBSywwQkFBMEIsUUFBUSxLQUFLLElBQUksT0FBTyxFQUFFO0FBQ2hFLGlCQUFLLElBQUk7VUFDVjtRQUNELENBQUM7TUFDRixDQUFDO0lBQ0Y7QUFFQSxXQUFNLEVBQUcsTUFBTSxDQUFDLE1BQUs7QUFDcEIsTUFBQUEsUUFBTyxLQUFLLDBCQUEwQixRQUFRLEtBQUssQ0FBQyxFQUFFO0FBQ3RELFdBQUssSUFBSTtJQUNWLENBQUM7RUFDRixDQUFDO0FBQ0Y7OztBRm5GQSxJQUFNRyxVQUFTLG1CQUFtQixjQUFjO0FBRTFDLElBQU8sZUFBUCxNQUFPLGNBQVk7RUFDUCxjQUFzQjtFQUN0QixpQkFBaUI7RUFDakIsU0FBUztFQUVsQjtFQUNBOztFQUNBLGdCQUFxQzs7RUFDckMsa0JBQStCLG9CQUFJLElBQUc7O0VBQ3RDLGNBR0osb0JBQUksSUFBRztFQUNILG1CQUFnQyxvQkFBSSxJQUFHOzs7RUFHdkMsWUFBMkIsUUFBUSxRQUFPOztFQUcxQyxzQkFBc0I7O0VBR3RCOztFQUdBLFFBQWdCO0VBQ2hCLFVBQXNCLENBQUE7Ozs7Ozs7RUFRdEIsY0FBZ0Qsb0JBQUksSUFBRzs7Ozs7OztFQVF2RCxnQkFBNkIsb0JBQUksSUFBRzs7RUFHcEMscUJBQWdFLG9CQUFJLElBQUc7O0VBR3ZFOztFQUdBLFdBQWtDLG9CQUFJLElBQUc7OztFQUl6QyxxQkFBa0Msb0JBQUksSUFBRzs7RUFHekMsa0JBQTJDLG9CQUFJLElBQUc7RUFFMUQsY0FBQTtBQUNDLElBQUFBLFFBQU8sS0FBSywwQkFBMEI7QUFJdEMsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFDcEUsU0FBSyxVQUFVLElBQUksUUFBYyxDQUFDLFlBQVc7QUFDNUMsV0FBSyxTQUFTLEtBQUssR0FBRyxNQUFLO0FBQzFCLFFBQUFELFFBQU8sTUFBTSwyQkFBNEIsS0FBSyxTQUFTLFFBQU8sRUFBd0IsSUFBSSxFQUFFO0FBQzVGLGdCQUFPO01BQ1IsQ0FBQztJQUNGLENBQUM7QUFDRCxTQUFLLFNBQVMsR0FBRyxTQUFTLENBQUMsUUFBTztBQUNqQyxNQUFBQSxRQUFPLE1BQU0sb0JBQW9CLEdBQUcsRUFBRTtJQUN2QyxDQUFDO0FBR0QsU0FBSyxXQUFXQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFFcEUsU0FBSyxTQUFTLEdBQUcsYUFBYSxNQUFLO0FBQ2xDLFlBQU0sT0FBTyxLQUFLLFNBQVMsUUFBTztBQUNsQyxNQUFBRCxRQUFPLE1BQU0sMEJBQTBCLEtBQUssVUFBVSxJQUFJLENBQUMsRUFBRTtBQUM3RCxVQUFJO0FBQ0gsYUFBSyxTQUFTLHFCQUFxQixJQUFJO01BQ3hDLFNBQVMsSUFBSTtNQUViO0lBQ0QsQ0FBQztBQUVELFNBQUssU0FBUyxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ2pDLE1BQUFBLFFBQU8sTUFBTSxvQkFBb0IsR0FBRyxFQUFFO0lBQ3ZDLENBQUM7QUFFRCxTQUFLLFNBQVMsR0FBRyxXQUFXLENBQUMsS0FBSyxVQUFTO0FBQzFDLFVBQUk7QUFDSCxhQUFLLGVBQWUsS0FBSyxNQUFNLE9BQU87TUFDdkMsU0FBUyxJQUFJO0FBQ1osUUFBQUEsUUFBTyxNQUFNLG9DQUFvQyxFQUFFLEVBQUU7TUFDdEQ7SUFDRCxDQUFDO0FBTUQsU0FBSyxTQUFTLEtBQUssRUFBRSxTQUFTLFdBQVcsTUFBTSxLQUFLLE9BQU0sR0FBSSxNQUFLO0FBQ2xFLE1BQUFBLFFBQU8sTUFBTSw4QkFBOEIsS0FBSyxNQUFNLEVBQUU7QUFDeEQsWUFBTSxTQUFTRSxJQUFHLGtCQUFpQjtBQUNuQyxpQkFBVyxTQUFTLE9BQU8sT0FBTyxNQUFNLEdBQUc7QUFDMUMsbUJBQVcsUUFBUSxTQUFTLENBQUEsR0FBSTtBQUMvQixjQUFJLEtBQUssV0FBVyxVQUFVLENBQUMsS0FBSyxZQUFZLENBQUMsS0FBSyxpQkFBaUIsSUFBSSxLQUFLLE9BQU8sR0FBRztBQUN6RixnQkFBSTtBQUNILG1CQUFLLFNBQVMsY0FBYyxLQUFLLGdCQUFnQixLQUFLLE9BQU87QUFDN0QsbUJBQUssaUJBQWlCLElBQUksS0FBSyxPQUFPO0FBQ3RDLGNBQUFGLFFBQU8sTUFBTSx3QkFBd0IsS0FBSyxjQUFjLE9BQU8sS0FBSyxPQUFPLEVBQUU7WUFDOUUsU0FBUyxJQUFJO0FBQ1osY0FBQUEsUUFBTyxLQUFLLG1DQUFtQyxLQUFLLE9BQU8sS0FBSyxPQUFPLEVBQUUsQ0FBQyxFQUFFO1lBQzdFO1VBQ0Q7UUFDRDtNQUNEO0lBQ0QsQ0FBQztBQUtELFNBQUssZ0JBQWdCQyxPQUFNLGFBQWEsRUFBRSxNQUFNLFFBQVEsV0FBVyxLQUFJLENBQUU7QUFDekUsU0FBSyxjQUFjLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDdEMsTUFBQUQsUUFBTyxNQUFNLDBCQUEwQixJQUFJLE9BQU8sRUFBRTtJQUNyRCxDQUFDO0FBQ0QsU0FBSyxjQUFjLEdBQUcsV0FBVyxDQUFDLEtBQWEsVUFBMkI7QUFDekUsVUFBSSxJQUFJLFNBQVM7QUFBSTtBQUNyQixVQUFJLElBQUksQ0FBQyxNQUFNLE9BQVEsSUFBSSxDQUFDLE1BQU07QUFBTTtBQUN4QyxZQUFNLE1BQU0sSUFBSSxTQUFTLElBQUksRUFBRTtBQUMvQixVQUFJLElBQUksU0FBUyxPQUFPLE1BQU07QUFBWTtBQUMxQyxZQUFNLFlBQVksSUFBSSxTQUFTLEVBQUU7QUFDakMsVUFBSSxVQUFVLFNBQVMsS0FBSyxVQUFVLENBQUMsTUFBTTtBQUFNO0FBQ25ELFlBQU0sWUFBWSxVQUFVLENBQUM7QUFDN0IsWUFBTSxjQUFjLFlBQVksU0FBVTtBQUMxQyxZQUFNLGdCQUFnQixZQUFZO0FBQ2xDLFVBQUksWUFBWTtBQUNmLGNBQU0sTUFBTSxHQUFHLE1BQU0sT0FBTyxJQUFJLGFBQWE7QUFDN0MsY0FBTSxvQkFBb0IsQ0FBQyxLQUFLLGdCQUFnQixJQUFJLEdBQUc7QUFDdkQsYUFBSyxnQkFBZ0IsSUFBSSxHQUFHO0FBQzVCLFFBQUFBLFFBQU8sTUFDTix1QkFBdUIsTUFBTSxPQUFPLFFBQVEsTUFBTSxhQUFhLENBQUMsTUFDOUQsb0JBQW9CLDRCQUE0QiwyQkFBMkI7QUFHOUUsbUJBQVcsTUFBTSxLQUFLLGdCQUFnQixPQUFPLEdBQUcsR0FBRyxHQUFHO01BQ3ZEO0lBQ0QsQ0FBQztBQUNELFNBQUssY0FBYyxLQUFLLEVBQUUsU0FBUyxLQUFLLGdCQUFnQixNQUFNLEtBQUssT0FBTSxHQUFJLE1BQUs7QUFDakYsTUFBQUEsUUFBTyxNQUFNLDRCQUE0QixLQUFLLGNBQWMsSUFBSSxLQUFLLE1BQU0sRUFBRTtJQUM5RSxDQUFDO0VBQ0Y7RUFFTyxRQUFLO0FBRVgsZUFBVyxXQUFXLEtBQUssZ0JBQWdCLE9BQU0sR0FBSTtBQUNwRCxVQUFJO0FBQ0gsZ0JBQU87TUFDUixRQUFRO01BRVI7SUFDRDtBQUNBLFNBQUssZ0JBQWdCLE1BQUs7QUFDMUIsUUFBSTtBQUNILGlCQUFXLGFBQWEsTUFBTSxLQUFLLEtBQUssZ0JBQWdCLEdBQUc7QUFDMUQsWUFBSTtBQUNILGVBQUssU0FBUyxlQUFlLEtBQUssZ0JBQWdCLFNBQVM7UUFDNUQsUUFBUTtRQUVSO01BQ0Q7SUFDRCxRQUFRO0lBRVI7QUFDQSxRQUFJO0FBQ0gsV0FBSyxlQUFlLE1BQUs7QUFDekIsV0FBSyxnQkFBZ0I7SUFDdEIsUUFBUTtJQUVSO0FBQ0EsUUFBSTtBQUNILFdBQUssU0FBUyxNQUFLO0lBQ3BCLFFBQVE7SUFFUjtBQUNBLFFBQUk7QUFDSCxXQUFLLFNBQVMsTUFBSztJQUNwQixRQUFRO0lBRVI7RUFDRDs7Ozs7RUFNTyxTQUFTLE9BQWUsU0FBbUI7QUFDakQsU0FBSyxRQUFRO0FBQ2IsU0FBSyxVQUFVO0VBQ2hCOzs7OztFQU1PLG9CQUFvQixVQUFzQztBQUNoRSxTQUFLLG1CQUFtQjtFQUN6Qjs7RUFHTyxtQkFBbUIsSUFBVTtBQUNuQyxXQUFPLEtBQUssY0FBYyxJQUFJLEVBQUU7RUFDakM7O0VBR08sZ0JBQWdCLElBQVU7QUFDaEMsU0FBSyxjQUFjLElBQUksRUFBRTtBQUN6QixJQUFBQSxRQUFPLE1BQU0sd0JBQXdCLEVBQUUsRUFBRTtFQUMxQzs7RUFHTyxhQUFhLElBQVU7QUFDN0IsU0FBSyxjQUFjLE9BQU8sRUFBRTtBQUM1QixTQUFLLFlBQVksT0FBTyxFQUFFO0FBQzFCLFNBQUssU0FBUyxPQUFPLEVBQUU7QUFDdkIsU0FBSyxtQkFBbUIsT0FBTyxFQUFFO0FBQ2pDLFNBQUssZ0JBQWdCLElBQUksRUFBRSxJQUFHO0FBQzlCLFNBQUssZ0JBQWdCLE9BQU8sRUFBRTtBQUM5QixJQUFBQSxRQUFPLE1BQU0scUJBQXFCLEVBQUUsRUFBRTtFQUN2Qzs7Ozs7O0VBT08sTUFBTSxZQUFZLFVBQWdCO0FBQ3hDLFFBQUksS0FBSyxtQkFBbUIsSUFBSSxRQUFRO0FBQUcsYUFBTztBQUNsRCxVQUFNLFNBQVMsZ0JBQWdCLEtBQUssS0FBSztBQUN6QyxRQUFJLENBQUMsUUFBUSxXQUFXO0FBRXZCLFdBQUssbUJBQW1CLElBQUksUUFBUTtBQUNwQyxhQUFPO0lBQ1I7QUFDQSxVQUFNLFVBQVUsTUFBTSxrQkFBa0IsUUFBUTtBQUNoRCxVQUFNLFVBQVUsWUFBWTtBQUc1QixTQUFLLG1CQUFtQixJQUFJLFFBQVE7QUFDcEMsUUFBSSxTQUFTO0FBQ1osV0FBSyxnQkFBZ0IsSUFBSSxVQUFVLE9BQU87SUFDM0M7QUFDQSxXQUFPO0VBQ1I7Ozs7Ozs7RUFRTyxNQUFNLFlBQVksSUFBWSxZQUFZLEtBQUk7QUFDcEQsVUFBTSxLQUFLO0FBQ1gsV0FBTyxZQUNOLEtBQUssVUFDTCxDQUFDLEtBQUssT0FBTyxLQUFLLG1CQUFtQixJQUFJLEtBQUssRUFBRSxHQUNoRCxDQUFDLFFBQVEsS0FBSyxtQkFBbUIsT0FBTyxHQUFHLEdBQzNDLE9BQU8sV0FBVyxLQUFLLG9CQUFvQixNQUFNLEdBQ2pELElBQ0EsU0FBUztFQUVYOzs7OztFQU1PLE1BQU0sbUJBQW1CLFVBQWdCO0FBQy9DLElBQUFBLFFBQU8sS0FBSyxnQ0FBZ0MsUUFBUSxFQUFFO0FBQ3RELFVBQU0sV0FBVyxNQUFNLEtBQUssYUFBYSxzQkFBc0IsUUFBVyxRQUFXLFFBQVcsVUFBVSxLQUFLO0FBRS9HLFdBQU87RUFDUjs7Ozs7OztFQVFPLE1BQU0sZ0JBQWdCLFlBQVksS0FBSTtBQUM1QyxVQUFNLGdCQUFnQjtBQUN0QixVQUFNLGVBQTZCLENBQUE7QUFFbkMsU0FBSyxtQkFBbUIsSUFBSSxlQUFlLENBQUMsV0FBc0I7QUFDakUsVUFBSSxDQUFDLGFBQWEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU8sRUFBRSxHQUFHO0FBQ2xELHFCQUFhLEtBQUssTUFBTTtNQUN6QjtJQUNELENBQUM7QUFFRCxRQUFJO0FBQ0gsWUFBTSxLQUFLO0FBQ1gsWUFBTSxnQkFBZ0IsS0FBSyxVQUFVLE9BQU8sV0FBVyxLQUFLLG9CQUFvQixNQUFNLEdBQUcsU0FBUztBQUNsRyxhQUFPO0lBQ1I7QUFDQyxXQUFLLG1CQUFtQixPQUFPLGFBQWE7SUFDN0M7RUFDRDs7Ozs7RUFNTyxNQUFNLHVCQUF1QixVQUFnQjtBQUNuRCxJQUFBQSxRQUFPLEtBQUssb0NBQW9DLFFBQVEsRUFBRTtBQUMxRCxVQUFNLFdBQVcsTUFBTSxLQUFLLGFBQWEsa0JBQWtCLFFBQVcsUUFBVyxRQUFXLFVBQVUsS0FBSztBQUkzRyxVQUFNLFlBQVk7QUFFbEIsUUFBSSxTQUFTLFNBQVMsWUFBWSxHQUFHO0FBQ3BDLE1BQUFBLFFBQU8sS0FBSyxnQ0FBZ0MsU0FBUyxNQUFNLFFBQVE7QUFDbkUsYUFBTztJQUNSO0FBR0EsVUFBTSxRQUFRLFNBQVMsWUFBWSxDQUFDO0FBQ3BDLFVBQU0sUUFBUSxTQUFTLFlBQVksQ0FBQztBQUVwQyxVQUFNLFdBQ0wsUUFBUSxLQUNMLE1BQU0sU0FBUSxFQUFHLFNBQVMsR0FBRyxHQUFHLElBQ2hDLE1BQU0sU0FBUTtBQUVsQixVQUFNLFdBQVcsR0FBRyxLQUFLLElBQUksUUFBUTtBQUVyQyxJQUFBQSxRQUFPLE1BQU0scUJBQXFCLFFBQVEsRUFBRTtBQUM1QyxXQUFPO0VBQ1I7Ozs7O0VBTVEsTUFBTSxvQkFBb0IsUUFBYztBQUMvQyxRQUFJO0FBQ0gsWUFBTSxZQUFZLE1BQU0sOEJBQThCLE1BQU07QUFDNUQsVUFBSSxDQUFDLFdBQVc7QUFDZixRQUFBQSxRQUFPLEtBQUsscURBQXFELE1BQU0sRUFBRTtBQUN6RTtNQUNEO0FBRUEsVUFBSSxLQUFLLGlCQUFpQixJQUFJLFNBQVMsR0FBRztBQUV6QztNQUNEO0FBRUEsVUFBSTtBQUNILGFBQUssU0FBUyxjQUFjLEtBQUssZ0JBQWdCLFNBQVM7QUFDMUQsYUFBSyxpQkFBaUIsSUFBSSxTQUFTO0FBQ25DLFFBQUFBLFFBQU8sS0FBSyxvQkFBb0IsS0FBSyxjQUFjLE9BQU8sU0FBUyxFQUFFO01BQ3RFLFNBQVMsSUFBSTtBQUNaLFFBQUFBLFFBQU8sS0FBSywrQkFBK0IsU0FBUyxLQUFLLE9BQU8sRUFBRSxDQUFDLEVBQUU7TUFDdEU7SUFDRCxTQUFTLElBQUk7QUFDWixNQUFBQSxRQUFPLEtBQUssK0JBQStCLEVBQUUsRUFBRTtJQUNoRDtFQUNEO0VBRU8sTUFBTSxhQUNaLE9BQ0EsT0FDQSxXQUNBLE9BQ0EsUUFDQSxTQUFTLE1BQUk7QUFFYixTQUFLO0FBQ0wsV0FBTyxJQUFJLFFBQWdCLENBQUMsU0FBUyxXQUFVO0FBQzlDLFdBQUssWUFBWSxLQUFLLFVBQVUsS0FBSyxZQUNwQyxLQUFLLGNBQWMsT0FBTyxPQUFPLFdBQVcsT0FBTyxRQUFRLE1BQU0sRUFDL0QsS0FBSyxDQUFDLFFBQU87QUFDYixhQUFLO0FBR0wsWUFBSSxLQUFLLHdCQUF3QixLQUFLLFVBQVUsUUFBVztBQUMxRCxlQUFLLG1CQUFtQixNQUFNLEVBQUUsTUFBTSxDQUFDLFFBQU87QUFDN0MsWUFBQUEsUUFBTyxLQUFLLDZDQUE2QyxHQUFHLEVBQUU7VUFDL0QsQ0FBQztRQUNGO0FBQ0EsZ0JBQVEsR0FBRztNQUNaLENBQUMsRUFDQSxNQUFNLENBQUMsUUFBTztBQUNkLGFBQUs7QUFDTCxlQUFPLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDO01BQzNELENBQUMsQ0FBQztJQUVMLENBQUM7RUFDRjtFQUVRLE1BQU0sY0FDYixPQUNBLE9BQ0EsV0FDQSxPQUNBLFFBQ0EsU0FBUyxNQUFJO0FBRWIsVUFBTSxZQUFZO0FBRWxCLFVBQU0sWUFBc0IsQ0FBQTtBQUM1QixRQUFJLGNBQWM7QUFBVyxnQkFBVSxLQUFLLFlBQVksR0FBSTtBQUM1RCxRQUFJLFVBQVU7QUFBVyxnQkFBVSxLQUFLLEdBQUcsY0FBYSxnQkFBZ0IsS0FBSyxDQUFDO0FBRTlFLFVBQU0sY0FBd0IsQ0FBQyxJQUFNLFFBQVEsR0FBSTtBQUVqRCxRQUFJLFVBQVUsZUFBZSxVQUFVLFVBQWEsY0FBYyxVQUFhLFVBQVUsUUFBVztBQUluRyxVQUFJLENBQUMsS0FBSyxZQUFZLElBQUksTUFBTTtBQUFHLGFBQUssWUFBWSxJQUFJLFFBQVEsb0JBQUksSUFBRyxDQUFFO0FBQ3pFLFlBQU0sVUFBVSxLQUFLLFlBQVksSUFBSSxNQUFNO0FBQzNDLFlBQU0sZUFBZTtBQUNyQixZQUFNLFlBQXNCLENBQUE7QUFDNUIsZUFBUyxJQUFJLEdBQUcsSUFBSSxjQUFjLEtBQUs7QUFDdEMsY0FBTSxXQUFXLGNBQWMsS0FBSyxPQUFPLGFBQWEsR0FBRyxLQUFLO0FBQ2hFLGNBQU0sTUFBTSxNQUFNLFlBQVksT0FBTyxLQUFLLElBQUssUUFBUSxJQUFJLFFBQVEsS0FBSztBQUN4RSxrQkFBVSxLQUFLLEdBQUc7QUFDbEIsZ0JBQVEsSUFBSSxVQUFVLEdBQUc7TUFDMUI7QUFDQSxrQkFBWSxLQUFLLFFBQVEsS0FBTSxHQUFHLFNBQVM7SUFDNUMsT0FBTztBQUNOLFVBQUksVUFBVTtBQUFXLG9CQUFZLEtBQUssUUFBUSxHQUFJO0FBQ3RELFVBQUk7QUFBUSxvQkFBWSxLQUFLLFVBQVUsTUFBTTtBQUM3QyxVQUFJLFVBQVUsU0FBUztBQUFHLG9CQUFZLEtBQUssR0FBRyxTQUFTO0lBQ3hEO0FBRUEsVUFBTSxNQUFNLGNBQWEsVUFBVSxXQUFXO0FBQzlDLFVBQU0saUJBQWlCLE9BQU8sS0FBSyxDQUFDLEdBQUcsYUFBYSxHQUFHLENBQUM7QUFHeEQsUUFBSSxjQUFjLFVBQWEsVUFBVSxRQUFXO0FBQ25ELFlBQU0sYUFBYSxjQUFhLGdCQUFnQixLQUFLO0FBQ3JELFlBQU0sVUFBeUI7UUFDOUIsUUFBUTtRQUNSLElBQUk7UUFDSjtRQUNBOztBQUVELE1BQUFBLFFBQU8sS0FBSyxNQUFNLE1BQU0sTUFBTSxvQkFBb0IsU0FBUyxLQUFLLE9BQU8sQ0FBQyxFQUFFO0lBQzNFLE9BQU87QUFDTixNQUFBQSxRQUFPLEtBQUssTUFBTSxNQUFNLE1BQU0sZUFBZSxLQUFLLENBQUMsRUFBRTtJQUN0RDtBQUlBLFFBQUksQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEdBQUc7QUFDcEMsTUFBQUEsUUFBTyxNQUFNLHFEQUFnRCxNQUFNLEtBQUssZUFBZSxTQUFTLEtBQUssQ0FBQyxFQUFFO0FBQ3hHLFlBQU0sSUFBSSxNQUFNLGFBQWEsTUFBTSxpRkFBNEU7SUFDaEg7QUFLQSxRQUFJLENBQUMsS0FBSyxtQkFBbUIsSUFBSSxNQUFNLEdBQUc7QUFDekMsWUFBTSxLQUFLLFlBQVksTUFBTTtJQUU5QjtBQUdBLFVBQU0sS0FBSyxvQkFBb0IsTUFBTTtBQUVyQyxVQUFNLFdBQVcsS0FBSyxlQUFlO0FBQ3JDLFVBQU0sU0FBUyxNQUFNLEtBQUssWUFBWSxVQUFVLE1BQU07QUFDdEQsVUFBTSxTQUFTLE9BQU8sT0FBTyxDQUFDLFFBQVEsY0FBYyxDQUFDO0FBRXJELElBQUFBLFFBQU8sTUFBTSxxQkFBcUIsTUFBTSxLQUFLLE9BQU8sU0FBUyxLQUFLLENBQUMsRUFBRTtBQUVyRSxVQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksS0FBSztBQUU5QixXQUFPLElBQUksUUFBZ0IsQ0FBQyxTQUFTLFdBQVU7QUFDOUMsWUFBTSxRQUFRLFdBQVcsTUFBSztBQUM3QixhQUFLLFlBQVksT0FBTyxHQUFHO0FBQzNCLGVBQU8sSUFBSSxNQUFNLHNDQUFzQyxLQUFLLEtBQUssT0FBTyxNQUFNLE9BQU8sQ0FBQztNQUN2RixHQUFHLFNBQVM7QUFFWixXQUFLLFlBQVksSUFBSSxLQUFLO1FBQ3pCLFNBQVMsQ0FBQyxRQUFPO0FBQ2hCLHVCQUFhLEtBQUs7QUFDbEIsa0JBQVEsR0FBRztRQUNaO1FBQ0EsUUFBUSxDQUFDLFFBQU87QUFDZix1QkFBYSxLQUFLO0FBQ2xCLGlCQUFPLEdBQUc7UUFDWDtRQUNBO09BQ0E7QUFFRCxXQUFLLFNBQVMsS0FBSyxRQUFRLEtBQUssYUFBYSxRQUFRLENBQUMsUUFBTztBQUM1RCxZQUFJLEtBQUs7QUFDUixlQUFLLFlBQVksT0FBTyxHQUFHO0FBQzNCLHVCQUFhLEtBQUs7QUFDbEIsaUJBQU8sSUFBSSxNQUFNLElBQUksV0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBQzdDO01BQ0QsQ0FBQztJQUNGLENBQUM7RUFDRjtFQUVRLGVBQWUsS0FBYSxPQUFhO0FBQ2hELFFBQUksSUFBSSxTQUFTO0FBQUc7QUFDcEIsUUFBSSxJQUFJLENBQUMsTUFBTSxPQUFRLElBQUksQ0FBQyxNQUFNO0FBQU07QUFFeEMsVUFBTSxVQUFVLElBQUksYUFBYSxDQUFDO0FBS2xDLFFBQUksWUFBWSwyQkFBMkIsS0FBSyxtQkFBbUIsT0FBTyxHQUFHO0FBQzVFLFlBQU0sU0FBUyx1QkFBdUIsS0FBSyxLQUFLO0FBQ2hELFVBQUksUUFBUTtBQUNYLFFBQUFBLFFBQU8sTUFDTiw0QkFBNEIsS0FBSyxlQUNuQixPQUFPLElBQUksYUFDZCxPQUFPLEtBQUssaUJBQ1IsT0FBTyxTQUFTLG9CQUNiLE9BQU8sWUFBWSxHQUFHO0FBSXpDLFlBQUksT0FBTyxTQUFTLFlBQVk7QUFDL0IscUJBQVcsTUFBTSxLQUFLLG1CQUFtQixPQUFNLEdBQUk7QUFDbEQsZ0JBQUk7QUFDSCxpQkFBRyxNQUFNO1lBQ1YsUUFBUTtZQUVSO1VBQ0Q7UUFDRCxPQUFPO0FBQ04sVUFBQUEsUUFBTyxNQUFNLHNEQUFzRCxPQUFPLElBQUksT0FBTyxLQUFLLEVBQUU7UUFDN0Y7TUFDRDtBQUNBO0lBQ0Q7QUFFQSxRQUFJLElBQUksU0FBUztBQUFJO0FBR3JCLFVBQU0sTUFBTSxJQUFJLFNBQVMsSUFBSSxFQUFFO0FBQy9CLFFBQUksSUFBSSxTQUFTLE9BQU8sTUFBTTtBQUFZO0FBTTFDLFFBQUksQ0FBQyxLQUFLLGNBQWMsSUFBSSxLQUFLLEdBQUc7QUFDbkMsTUFBQUEsUUFBTyxNQUFNLHFEQUFxRCxLQUFLLEVBQUU7QUFDekU7SUFDRDtBQUlBLFVBQU0sWUFBWSxJQUFJLFNBQVMsRUFBRTtBQUNqQyxRQUFJLFVBQVUsU0FBUztBQUFHO0FBQzFCLFFBQUksVUFBVSxDQUFDLE1BQU07QUFBTTtBQUczQixVQUFNLFlBQVksVUFBVSxDQUFDO0FBQzdCLFVBQU0sY0FBYyxZQUFZLFNBQVU7QUFDMUMsVUFBTSxnQkFBZ0IsWUFBWTtBQU1sQyxRQUFJLFlBQVk7QUFDZixZQUFNLE1BQU0sR0FBRyxLQUFLLElBQUksYUFBYTtBQUNyQyxZQUFNLFVBQVUsS0FBSyxZQUFZLElBQUksR0FBRztBQUN4QyxVQUFJLFNBQVM7QUFDWixhQUFLLFlBQVksT0FBTyxHQUFHO0FBQzNCLGNBQU0sZUFBZSxLQUFLLGdCQUFnQixJQUFJLEdBQUc7QUFDakQsUUFBQUEsUUFBTyxNQUNOLHVCQUF1QixLQUFLLFFBQVEsTUFBTSxhQUFhLENBQUMsUUFBUSxlQUFlLGNBQWMsU0FBUyxFQUFFO0FBRXpHLFlBQUksa0JBQWtCLHNCQUFzQjtBQUMzQyxVQUFBQSxRQUFPLE1BQU0sd0JBQXdCLEtBQUssS0FBSyxJQUFJLFNBQVMsS0FBSyxDQUFDLEVBQUU7UUFDckU7QUFDQSxhQUFLLGFBQWEsT0FBTyxlQUFlLEtBQUssU0FBUztBQUN0RCxnQkFBUSxRQUFRLEdBQUc7TUFDcEIsV0FBVyxrQkFBa0IsbUJBQW1CO0FBRS9DLGFBQUssYUFBYSxPQUFPLGVBQWUsS0FBSyxTQUFTO01BQ3ZEO0lBRUQsT0FBTztBQUlOLFlBQU0sT0FBTyxVQUFVLFNBQVMsR0FBRyxVQUFVLFNBQVMsQ0FBQztBQUN2RCxZQUFNLG1CQUFtQixLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLGFBQWE7QUFDNUUsVUFBSSxvQkFBb0IsS0FBSyxVQUFVLEdBQUc7QUFDekMsY0FBTSxVQUFVLEtBQUssQ0FBQztBQUN0QixjQUFNLFVBQVUsS0FBSyxTQUFTLENBQUM7QUFDL0IsWUFBSSxRQUFRLFVBQVUsV0FBVyxVQUFVLEdBQUc7QUFDN0MsZ0JBQU0sU0FBMEIsQ0FBQTtBQUNoQyxjQUFJLElBQUk7QUFDUixpQkFBTyxJQUFJLElBQUksU0FBUztBQUN2QixrQkFBTSxLQUFLLFFBQVEsQ0FBQztBQUNwQixrQkFBTSxhQUFhLENBQUMsUUFBUSxJQUFJLENBQUMsQ0FBQztBQUNsQyxtQkFBTyxLQUFLLEVBQUUsUUFBUSxlQUFlLElBQUksV0FBVSxDQUFFO0FBQ3JELGlCQUFLO1VBQ047QUFDQSxjQUFJLE9BQU8sU0FBUyxHQUFHO0FBQ3RCLGlCQUFLLG9CQUFvQixPQUFPLE1BQU07QUFDdEM7VUFDRDtRQUNEO01BQ0Q7QUFDQSxXQUFLLGFBQWEsT0FBTyxlQUFlLEtBQUssU0FBUztJQUN2RDtFQUNEOzs7OztFQU1RLG9CQUFvQixPQUFlLFVBQXlCO0FBQ25FLFVBQU0sUUFBUSxLQUFLLFlBQVksSUFBSSxLQUFLLEtBQUssb0JBQUksSUFBRztBQUNwRCxRQUFJLENBQUMsS0FBSyxZQUFZLElBQUksS0FBSztBQUFHLFdBQUssWUFBWSxJQUFJLE9BQU8sS0FBSztBQUVuRSxlQUFXLEtBQUssVUFBVTtBQUN6QixZQUFNLFdBQVcsY0FBYyxLQUFLLE9BQU8sRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUs7QUFDbEUsWUFBTSxXQUNMLEVBQUUsV0FBVyxXQUFXLElBQ3BCLEVBQUUsV0FBVyxDQUFDLEtBQUssS0FBTyxFQUFFLFdBQVcsQ0FBQyxLQUFLLElBQUssRUFBRSxXQUFXLENBQUMsSUFDaEUsRUFBRSxXQUFXLENBQUMsS0FBSztBQUN4QixZQUFNLFlBQVksTUFBTSxJQUFJLFFBQVE7QUFDcEMsWUFBTSxVQUFVLGNBQWMsVUFBYSxjQUFjO0FBRXpELFlBQU0sSUFBSSxVQUFVLFFBQVE7QUFFNUIsWUFBTSxZQUFZLG9CQUFvQixHQUFHLEtBQUssT0FBTztBQUNyRCxVQUFJLFNBQVM7QUFDWixRQUFBQSxRQUFPLEtBQUssTUFBTSxLQUFLLE1BQU0sU0FBUyxFQUFFO0FBQ3hDLFlBQUksS0FBSyxrQkFBa0I7QUFDMUIsY0FBSSxTQUFTLEVBQUU7QUFDZixnQkFBTSxhQUFhLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBSztBQUMxQyxnQkFBSSxFQUFFLFdBQVcsRUFBRTtBQUFRLHFCQUFPO0FBQ2xDLGdCQUFJLEVBQUUsT0FBTyxFQUFFO0FBQUkscUJBQU87QUFDMUIsa0JBQU0sY0FBYyxFQUFFLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU87QUFDM0QsZ0JBQUksQ0FBQyxhQUFhO0FBQVMscUJBQU87QUFDbEMsa0JBQU0sU0FBUyxFQUFFLEtBQUssRUFBRTtBQUN4QixtQkFBTyxTQUFTLEtBQUssWUFBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxNQUFNO1VBQ3JFLENBQUM7QUFDRCxjQUFJO0FBQVkscUJBQVMsV0FBVztBQUNwQyxnQkFBTSxrQkFBa0IsY0FBYyxLQUFLLE9BQU8sRUFBRSxRQUFRLE1BQU07QUFDbEUsZUFBSyxpQkFBaUIsZUFBZTtBQUNyQyxlQUFLLGlCQUFpQixrQkFBa0IsT0FBTztRQUNoRCxPQUFPO0FBQ04sVUFBQUEsUUFBTyxLQUFLLGdFQUEyRCxRQUFRLEVBQUU7UUFDbEY7TUFDRCxPQUFPO0FBQ04sUUFBQUEsUUFBTyxNQUFNLE1BQU0sS0FBSyxNQUFNLFNBQVMsRUFBRTtNQUMxQztJQUNEO0VBQ0Q7Ozs7Ozs7Ozs7OztFQWFRLGFBQWEsT0FBZSxPQUFlLEtBQWEsV0FBaUI7QUFDaEYsVUFBTSxVQUFVLGVBQWUsS0FBSztBQUNwQyxVQUFNLE9BQU8sVUFBVSxTQUFTLEdBQUcsVUFBVSxTQUFTLENBQUM7QUFHdkQsVUFBTSxZQUFZLFVBQVUsQ0FBQztBQUM3QixVQUFNLE1BQU0sVUFBVSxVQUFVLFNBQVMsQ0FBQztBQUMxQyxVQUFNLGdCQUFnQixRQUFRLE1BQU0sU0FBUyxDQUFDLFNBQVMsS0FBSyxTQUFTLEtBQUssQ0FBQyxRQUFRLE1BQU0sR0FBRyxDQUFDO0FBSzdGLFFBQUksVUFBVSx3QkFBd0IsVUFBVSxtQkFBbUI7QUFDbEUsVUFBSSxDQUFDLEtBQUssT0FBTztBQUNoQixRQUFBQSxRQUFPLEtBQUssTUFBTSxLQUFLLE1BQU0sT0FBTyxNQUFNLGFBQWEsRUFBRTtBQUN6RDtNQUNEO0FBQ0EsVUFBSTtBQUNILGNBQU0sV0FDTCxVQUFVLG9CQUNQLHNCQUFzQixLQUFLLE9BQU8sR0FBRyxJQUNyQyw0QkFBNEIsS0FBSyxPQUFPLEdBQUc7QUFFL0MsYUFBSyxvQkFBb0IsT0FBTyxRQUFRO01BQ3pDLFNBQVMsR0FBRztBQUNYLFFBQUFBLFFBQU8sS0FBSyxNQUFNLEtBQUssTUFBTSxPQUFPLG9CQUFvQixDQUFDLE1BQU0sYUFBYSxFQUFFO01BQy9FO0FBQ0E7SUFDRDtBQUdBLFVBQU0sVUFBVSxLQUFLLGFBQWEsT0FBTyxJQUFJO0FBRTdDLFVBQU0sUUFBUSxVQUFVLGNBQWNBLFFBQU8sTUFBTSxLQUFLQSxPQUFNLElBQUlBLFFBQU8sS0FBSyxLQUFLQSxPQUFNO0FBQ3pGLFFBQUksU0FBUztBQUNaLFlBQU0sTUFBTSxLQUFLLE1BQU0sT0FBTyxNQUFNLGFBQWEsTUFBTSxPQUFPLEVBQUU7SUFDakUsT0FBTztBQUNOLFlBQU0sTUFBTSxLQUFLLE1BQU0sT0FBTyxNQUFNLGFBQWEsRUFBRTtJQUNwRDtFQUNEOzs7OztFQU1RLGFBQWEsT0FBZSxNQUFZO0FBQy9DLFFBQUksS0FBSyxXQUFXO0FBQUcsYUFBTztBQUc5QixRQUFJLEtBQUssV0FBVyxHQUFHO0FBQ3RCLFVBQUksS0FBSyxDQUFDLE1BQU0sR0FBTTtBQUNyQixlQUFPO01BQ1IsT0FBTztBQUNOLGVBQU8sU0FBUyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7TUFDL0I7SUFDRDtBQUVBLFlBQVEsT0FBTzs7O01BR2QsS0FBSyxhQUFhO0FBQ2pCLGNBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsY0FBTSxPQUFPLE1BQU0sS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDLEVBQ3RDLElBQUksQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQ2pFLEtBQUssR0FBRztBQUNWLGVBQU8sTUFBTSxLQUFLLElBQUksSUFBSTtNQUMzQjs7Ozs7TUFNQSxLQUFLLGNBQWM7QUFDbEIsWUFBSSxLQUFLLFdBQVcsR0FBRztBQUN0QixpQkFBTyxLQUFLLENBQUMsTUFBTSxJQUFPLFdBQVcsV0FBVyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDL0Q7QUFDQSxZQUFJLEtBQUssVUFBVSxHQUFHO0FBQ3JCLGdCQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGdCQUFNLFlBQVksS0FBSyxDQUFDO0FBQ3hCLGdCQUFNLGFBQWEsS0FBSyxTQUFTLENBQUM7QUFDbEMsZ0JBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFDaEYsZ0JBQU0sY0FBYyxRQUFRLFFBQVEsV0FBVyxNQUFNLFNBQVMsQ0FBQztBQUMvRCxnQkFBTSxVQUFVLFFBQVEsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTyxHQUFHO0FBQ2hFLGdCQUFNLFdBQVcsV0FBVyxXQUFXLElBQUksV0FBVyxDQUFDLElBQUk7QUFDM0QsZ0JBQU0sY0FDTCxXQUFXLGFBQWEsU0FBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtBQUNyRixnQkFBTSxXQUFXLGNBQWMsR0FBRyxXQUFXLEtBQUssTUFBTSxRQUFTLENBQUMsTUFBTSxXQUFXLE1BQU0sS0FBSyxVQUFVLENBQUM7QUFDekcsZ0JBQU0sU0FBUyxJQUFJLE1BQU0sS0FBSyxDQUFDLElBQUksTUFBTSxTQUFTLENBQUMsS0FBSyxXQUFXLE1BQU0sS0FBSyxVQUFVLENBQUMsQ0FBQztBQUMxRixpQkFBTyxXQUFXLEtBQUssTUFBTSxXQUFXLEtBQUssUUFBUSxJQUFJLE1BQU07UUFDaEU7QUFDQSxlQUFPLFFBQVEsS0FBSyxTQUFTLEtBQUssQ0FBQztNQUNwQzs7TUFHQSxLQUFLLGlCQUFpQjtBQUVyQixZQUFJLEtBQUssVUFBVSxHQUFHO0FBQ3JCLGdCQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGdCQUFNLFlBQVksS0FBSyxDQUFDO0FBQ3hCLGdCQUFNLGFBQWEsS0FBSyxTQUFTLENBQUM7QUFDbEMsZ0JBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLFNBQVMsRUFBRSxPQUFPLFNBQVM7QUFDaEYsZ0JBQU0sY0FBYyxRQUFRLFFBQVEsV0FBVyxNQUFNLFNBQVMsQ0FBQztBQUMvRCxnQkFBTSxXQUFXLFdBQVcsV0FBVyxJQUFJLFdBQVcsQ0FBQyxJQUFJO0FBQzNELGdCQUFNLFVBQVUsUUFBUSxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLEdBQUc7QUFDaEUsZ0JBQU0sY0FDTCxXQUFXLGFBQWEsU0FBWSxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtBQUNyRixnQkFBTSxXQUFXLGVBQWUsS0FBSyxXQUFXLFNBQVMsS0FBSyxDQUFDO0FBQy9ELGlCQUFPLFdBQVcsS0FBSyxNQUFNLFdBQVcsS0FBSyxRQUFRO1FBQ3REO0FBQ0EsZUFBTztNQUNSOztNQUdBLEtBQUs7TUFDTCxLQUFLLGFBQWE7QUFDakIsWUFBSSxLQUFLLFNBQVM7QUFBRyxpQkFBTztBQUM1QixjQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLGNBQU0sWUFBWSxLQUFLLENBQUM7QUFDeEIsY0FBTSxRQUFRLEtBQUssU0FBUyxDQUFDO0FBQzdCLGVBQU8sTUFBTSxLQUFLLFlBQVksTUFBTSxTQUFTLENBQUMsVUFBVSxNQUFNLFNBQVMsS0FBSyxDQUFDO01BQzlFO01BRUE7QUFDQyxlQUFPO0lBQ1Q7RUFDRDtFQUVRLE9BQU8sZ0JBQWdCLE9BQWM7QUFDNUMsUUFBSSxPQUFPLFVBQVU7QUFBVyxhQUFPLENBQUMsUUFBUSxJQUFJLENBQUM7QUFDckQsUUFBSSxNQUFNLFFBQVEsS0FBSztBQUFHLGFBQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxPQUFPLENBQUMsSUFBSSxHQUFJO0FBQ2xFLFFBQUksT0FBTyxVQUFVLFVBQVU7QUFDOUIsVUFBSSxRQUFRO0FBQU0sZUFBTyxDQUFFLFNBQVMsS0FBTSxLQUFPLFNBQVMsSUFBSyxLQUFNLFFBQVEsR0FBSTtBQUNqRixhQUFPLENBQUMsUUFBUSxHQUFJO0lBQ3JCO0FBQ0EsVUFBTSxJQUFJLE1BQU0sNENBQTRDLEtBQUssRUFBRTtFQUNwRTtFQUVRLE1BQU0sWUFBWSxVQUFrQixRQUFjO0FBQ3pELFFBQUksTUFBTSxLQUFLLFNBQVMsSUFBSSxNQUFNO0FBQ2xDLFFBQUksQ0FBQyxLQUFLO0FBQ1QsWUFBTSxNQUFNLHFCQUFxQixNQUFNO0FBQ3ZDLFdBQUssU0FBUyxJQUFJLFFBQVEsR0FBRztJQUM5QjtBQUVBLFdBQU8sT0FBTyxPQUFPO01BQ3BCLE9BQU8sS0FBSyxDQUFDLEtBQU0sS0FBTSxHQUFNLFdBQVcsS0FBTSxHQUFNLEtBQU0sR0FBTSxHQUFNLEdBQUcsS0FBSyxHQUFNLENBQUksQ0FBQztNQUMzRixPQUFPLEtBQUssWUFBWSxNQUFNO0tBQzlCO0VBQ0Y7RUFFUSxPQUFPLFVBQVUsTUFBYztBQUN0QyxRQUFJLE1BQU07QUFDVixlQUFXLEtBQUssTUFBTTtBQUNyQixhQUFPO0FBQ1AsZUFBUyxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7QUFDM0IsZUFBTyxNQUFNLFNBQVUsS0FBTSxPQUFPLElBQUssT0FBUSxNQUFRLE9BQU8sSUFBSztNQUN0RTtJQUNEO0FBQ0EsV0FBTztFQUNSOzs7Ozs7Ozs7O0VBV08sZ0JBQWdCLElBQVksT0FBZSxXQUFtQixPQUFjO0FBQ2xGLFVBQU0sTUFBTSxjQUFjLEtBQUssT0FBTyxPQUFPLFdBQVcsS0FBSztBQUM3RCxXQUFPLEtBQUssWUFBWSxJQUFJLEVBQUUsR0FBRyxJQUFJLEdBQUc7RUFDekM7RUFFTyxNQUFNLFlBQVksUUFBYztBQUN0QyxXQUFPLEtBQUssYUFBYSxrQkFBa0IsUUFBVyxHQUFNLFFBQVcsUUFBUSxLQUFLO0VBQ3JGO0VBRU8sTUFBTSxjQUFjLFFBQWM7QUFDeEMsV0FBTyxLQUFLLGFBQWEscUJBQXFCLFFBQVcsUUFBVyxRQUFXLFFBQVEsS0FBSztFQUM3Rjs7OztBR3ozQkQsSUFBTUcsVUFBUyxtQkFBbUIsZ0JBQWdCO0FBTWxELElBQXFCLGlCQUFyQixjQUE0QyxhQUF5QjtFQUNwRTs7RUFDQTs7O0VBSVEsb0JBQWtDLENBQUE7OztFQUkxQyxjQUFzQjtFQUV0QixZQUFZLFVBQWlCO0FBQzVCLFVBQU0sUUFBUTtFQUNmO0VBRUEsTUFBTSxLQUFLLFFBQW9CO0FBQzlCLFNBQUssU0FBUztBQUNkLFFBQUksQ0FBQyxLQUFLLGNBQWM7QUFDdkIsV0FBSyxlQUFlLElBQUksYUFBWTtJQUNyQztBQUNBLFNBQUssYUFBYSxlQUFlLFlBQVksd0JBQXdCO0FBR3JFLFNBQUssYUFBYSxvQkFBb0IsQ0FBQyxlQUFzQjtBQUM1RCxXQUFLLGVBQWUsVUFBVTtJQUMvQixDQUFDO0FBSUQsU0FBSyxhQUFZLEVBQUcsTUFBTSxDQUFDLE1BQUs7QUFDL0IsTUFBQUEsUUFBTyxNQUFNLHFCQUFxQixDQUFDLEVBQUU7SUFDdEMsQ0FBQztFQUNGOzs7Ozs7O0VBUVEsTUFBTSxlQUFZO0FBQ3pCLElBQUFBLFFBQU8sS0FBSyw4QkFBOEI7QUFFMUMsU0FBSyxvQkFBb0IsTUFBTSxLQUFLLGFBQWEsZ0JBQWU7QUFHaEUsUUFBSTtBQUNKLFFBQUksS0FBSyxrQkFBa0IsV0FBVyxHQUFHO0FBQ3hDLFVBQUksS0FBSyxPQUFPLFdBQVc7QUFDMUIsUUFBQUEsUUFBTyxLQUFLLHFCQUFxQixLQUFLLE9BQU8sU0FBUyw4Q0FBeUM7QUFDL0YsYUFBSyxhQUFhLGVBQWUsbUJBQW1CLElBQUksS0FBSyxPQUFPLFNBQVMsYUFBYTtBQUMxRjtNQUNEO0FBQ0EsWUFBTSxjQUFjLEtBQUssT0FBTztBQUNoQyxVQUFJLENBQUMsS0FBSyxPQUFPLFFBQVEsQ0FBQyxhQUFhO0FBQ3RDLFFBQUFBLFFBQU8sS0FBSyx5REFBeUQ7QUFDckU7TUFDRDtBQUNBLE1BQUFBLFFBQU8sS0FBSyx3RUFBbUU7QUFDL0UsdUJBQWlCO0lBQ2xCLE9BQU87QUFDTixNQUFBQSxRQUFPLEtBQUssY0FBYyxLQUFLLGtCQUFrQixNQUFNLGFBQWE7QUFDcEUsaUJBQVcsS0FBSyxLQUFLLG1CQUFtQjtBQUN2QyxRQUFBQSxRQUFPLEtBQUssYUFBYSxFQUFFLEtBQUssSUFBSSxFQUFFLGdCQUFnQixFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUU7TUFDckU7QUFLQSxpQkFBVyxVQUFVLEtBQUssbUJBQW1CO0FBQzVDLGFBQUssYUFBYSxnQkFBZ0IsT0FBTyxFQUFFO01BQzVDO0FBR0EsaUJBQVcsVUFBVSxLQUFLLG1CQUFtQjtBQUM1QyxZQUFJO0FBQ0gsZ0JBQU0sV0FBVyxNQUFNLEtBQUssYUFBYSx1QkFBdUIsT0FBTyxFQUFFO0FBQ3pFLGlCQUFPLGVBQWU7QUFDdEIsVUFBQUEsUUFBTyxLQUFLLE9BQU8sT0FBTyxFQUFFLGNBQWMsUUFBUSxXQUFXLE9BQU8sYUFBYSxFQUFFO1FBQ3BGLFNBQVMsR0FBRztBQUNYLFVBQUFBLFFBQU8sS0FBSyxPQUFPLE9BQU8sRUFBRSw2QkFBNkIsQ0FBQyxFQUFFO0FBQzVELGlCQUFPLGVBQWU7UUFDdkI7TUFDRDtBQUVBLHVCQUFpQixhQUFhLEtBQUssUUFBUSxLQUFLLGlCQUFpQjtBQUVqRSxVQUFJLENBQUMsa0JBQWtCLEtBQUssT0FBTyxXQUFXO0FBQzdDLFFBQUFBLFFBQU8sS0FBSyxxQkFBcUIsS0FBSyxPQUFPLFNBQVMsc0RBQWlEO0FBQ3ZHLGFBQUssYUFBYSxlQUFlLG1CQUFtQixJQUFJLEtBQUssT0FBTyxTQUFTLGFBQWE7QUFDMUY7TUFDRDtJQUNEO0FBR0EsU0FBSyxVQUFVLGNBQWM7QUFJN0IsVUFBTSxhQUFhLEtBQUs7QUFDeEIsVUFBTSxLQUFLLG9CQUFvQixJQUFJLFVBQVU7QUFHN0MsU0FBSyxjQUFhO0FBQ2xCLFNBQUssZ0JBQWU7QUFDcEIsU0FBSywwQkFBeUI7QUFDOUIsU0FBSyxxQkFBb0I7QUFFekIsSUFBQUEsUUFBTyxLQUFLLDJCQUEyQjtFQUN4Qzs7RUFHQSxNQUFNLFVBQU87QUFDWixTQUFLLGNBQWMsTUFBSztBQUN4QixJQUFBQSxRQUFPLE1BQU0sU0FBUztFQUN2QjtFQUVBLE1BQU0sY0FBYyxRQUFvQjtBQUN2QyxVQUFNLGVBQWUsS0FBSztBQUMxQixTQUFLLFNBQVM7QUFDZCxVQUFNLGlCQUFpQixhQUFhLFFBQVEsS0FBSyxpQkFBaUI7QUFDbEUsU0FBSyxVQUFVLGNBQWM7QUFJN0IsU0FBSyxxQkFBb0I7QUFFekIsVUFBTSxVQUFVLEtBQUs7QUFJckIsVUFBTSxLQUFLLG9CQUFvQixjQUFjLE9BQU87QUFHcEQsU0FBSyxjQUFhO0FBQ2xCLFNBQUssZ0JBQWU7QUFDcEIsU0FBSywwQkFBeUI7QUFDOUIsU0FBSyxxQkFBb0I7RUFDMUI7Ozs7Ozs7Ozs7OztFQWFRLE1BQU0sb0JBQW9CLGNBQXNCLFNBQWU7QUFDdEUsUUFBSSxDQUFDLFNBQVM7QUFDYixVQUFJO0FBQWMsYUFBSyxhQUFhLGFBQWEsWUFBWTtBQUM3RDtJQUNEO0FBRUEsUUFBSSxLQUFLLE9BQU8sV0FBVztBQUUxQixZQUFNLFNBQVMsS0FBSyxrQkFBa0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLEtBQUssT0FBTyxTQUFTO0FBQ2pGLFVBQUksQ0FBQyxRQUFRO0FBQ1osUUFBQUEsUUFBTyxLQUFLLGVBQWUsS0FBSyxPQUFPLFNBQVMseURBQW9EO0FBQ3BHLFlBQUk7QUFBYyxlQUFLLGFBQWEsYUFBYSxZQUFZO0FBQzdEO01BQ0Q7QUFFQSxVQUFJLGdCQUFnQixpQkFBaUIsU0FBUztBQUM3QyxhQUFLLGFBQWEsYUFBYSxZQUFZO01BQzVDO0FBQ0EsWUFBTSxnQkFBZ0IsS0FBSyxhQUFhLG1CQUFtQixPQUFPO0FBQ2xFLFVBQUksQ0FBQyxlQUFlO0FBQ25CLGFBQUssYUFBYSxnQkFBZ0IsT0FBTztNQUMxQztBQUNBLFVBQUksWUFBWSxnQkFBZ0IsQ0FBQyxlQUFlO0FBQy9DLGNBQU0sS0FBSyw2QkFBNkIsT0FBTyxPQUFPLE9BQU87TUFDOUQ7QUFDQSxXQUFLLGFBQWEsZUFBZSxJQUFJLFNBQVMsT0FBTyxLQUFLLE1BQU0sT0FBTyxFQUFFO0FBQ3pFO0lBQ0Q7QUFHQSxVQUFNLGNBQWMsT0FBTyxLQUFLLE9BQU8sZUFBZSxFQUFFO0FBQ3hELFVBQU0saUJBQWlCLEtBQUssa0JBQWtCLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBRTFFLFFBQUksZ0JBQWdCO0FBQ25CLFVBQUksZUFBZSxVQUFVLGFBQWE7QUFDekMsWUFBSSxnQkFBZ0IsaUJBQWlCO0FBQVMsZUFBSyxhQUFhLGFBQWEsWUFBWTtBQUN6RixjQUFNLGdCQUFnQixLQUFLLGFBQWEsbUJBQW1CLE9BQU87QUFDbEUsWUFBSSxDQUFDLGVBQWU7QUFDbkIsZUFBSyxhQUFhLGdCQUFnQixPQUFPO1FBQzFDO0FBQ0EsWUFBSSxZQUFZLGdCQUFnQixDQUFDLGVBQWU7QUFDL0MsZ0JBQU0sS0FBSyw2QkFBNkIsYUFBYSxPQUFPO1FBQzdEO0FBQ0EsYUFBSyxhQUFhLGVBQWUsSUFBSSxTQUFTLFdBQVcsTUFBTSxPQUFPLEVBQUU7TUFDekUsT0FBTztBQUNOLFFBQUFBLFFBQU8sTUFDTiwwQkFBMEIsV0FBVywyQ0FBMkMsZUFBZSxLQUFLLFFBQVEsT0FBTywwQkFBcUI7QUFFekksYUFBSyxhQUFhLGFBQWEsT0FBTztBQUN0QyxhQUFLLGFBQ0osZUFBZSxtQkFDZiw0QkFBNEIsV0FBVyxTQUFTLGVBQWUsS0FBSyxFQUFFO01BRXhFO0FBQ0E7SUFDRDtBQUdBLElBQUFBLFFBQU8sS0FBSyxHQUFHLE9BQU8sd0NBQW1DO0FBQ3pELFFBQUksZ0JBQWdCLGlCQUFpQjtBQUFTLFdBQUssYUFBYSxhQUFhLFlBQVk7QUFDekYsU0FBSyxhQUFhLGFBQWEsT0FBTztBQUV0QyxVQUFNLFNBQVMsTUFBTSxLQUFLLGFBQWEsWUFBWSxPQUFPO0FBQzFELFFBQUksQ0FBQyxRQUFRO0FBQ1osTUFBQUEsUUFBTyxNQUFNLDBCQUEwQixPQUFPLDBCQUFxQjtBQUNuRSxXQUFLLGFBQWEsZUFBZSxnQkFBZ0IsbUJBQW1CLE9BQU8sRUFBRTtJQUM5RSxXQUFXLE9BQU8sVUFBVSxhQUFhO0FBQ3hDLE1BQUFBLFFBQU8sTUFDTiwwQkFBMEIsV0FBVywyQ0FBMkMsT0FBTyxLQUFLLFFBQVEsT0FBTywwQkFBcUI7QUFFakksV0FBSyxhQUNKLGVBQWUsbUJBQ2YsNEJBQTRCLFdBQVcsU0FBUyxPQUFPLEtBQUssRUFBRTtJQUVoRSxPQUFPO0FBQ04sTUFBQUEsUUFBTyxLQUFLLGtCQUFrQixPQUFPLEtBQUssT0FBTyxPQUFPLEVBQUU7QUFDMUQsV0FBSyxhQUFhLGdCQUFnQixPQUFPO0FBQ3pDLFlBQU0sS0FBSyw2QkFBNkIsYUFBYSxPQUFPO0FBQzVELFdBQUssYUFBYSxlQUFlLElBQUksU0FBUyxPQUFPLEtBQUssTUFBTSxPQUFPLEVBQUU7SUFDMUU7RUFDRDs7Ozs7RUFNUSxNQUFNLDZCQUE2QixPQUFlLElBQVU7QUFDbkUsUUFBSTtBQUNILFlBQU0sS0FBSyxhQUFhLG1CQUFtQixFQUFFO0FBRTdDLFVBQUksQ0FBQyxnQkFBZ0IsS0FBSyxHQUFHO0FBRzVCLFFBQUFBLFFBQU8sS0FBSyw2QkFBNkIsS0FBSyxzREFBaUQ7QUFDL0Y7TUFDRDtJQUNELFNBQVMsR0FBRztBQUNYLE1BQUFBLFFBQU8sS0FBSyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsRUFBRTtJQUN4RDtFQUNEOztFQUdRLFVBQVUsT0FBYTtBQUM5QixTQUFLLGNBQWM7QUFDbkIsVUFBTSxTQUFTLGdCQUFnQixLQUFLO0FBQ3BDLFFBQUksQ0FBQyxRQUFRO0FBQ1osTUFBQUEsUUFBTyxLQUFLLFVBQVUsS0FBSywrQkFBK0I7QUFDMUQsV0FBSyxhQUFhLFNBQVMsT0FBTyxDQUFBLENBQUU7QUFDcEM7SUFDRDtBQUVBLFVBQU0sVUFBVSxNQUFNLFFBQVEsT0FBTyxTQUFTLElBQUksT0FBTyxZQUFZLENBQUE7QUFFckUsU0FBSyxhQUFhLFNBQVMsT0FBTyxPQUFPO0FBQ3pDLFFBQUksUUFBUSxXQUFXLEdBQUc7QUFDekIsTUFBQUEsUUFBTyxLQUFLLCtCQUErQixLQUFLLDZDQUF3QztJQUN6RixPQUFPO0FBQ04sTUFBQUEsUUFBTyxNQUFNLFVBQVUsUUFBUSxNQUFNLHVCQUF1QixLQUFLLEdBQUc7SUFDckU7RUFDRDtFQUVBLGtCQUFlO0FBQ2QsV0FBTyxnQkFBZ0IsS0FBSyxpQkFBaUI7RUFDOUM7O0VBR0EsSUFBSSxPQUFJO0FBQ1AsV0FBTyxZQUFZLEtBQUssUUFBUSxLQUFLLGlCQUFpQjtFQUN2RDs7RUFHQSxJQUFJLFVBQU87QUFDVixXQUFPLEtBQUs7RUFDYjtFQUVBLGdCQUFhO0FBQ1osa0JBQWMsSUFBSTtFQUNuQjtFQUVBLGtCQUFlO0FBQ2Qsb0JBQWdCLElBQUk7RUFDckI7RUFFQSw0QkFBeUI7QUFDeEIsOEJBQTBCLElBQUk7RUFDL0I7RUFFQSx1QkFBb0I7QUFDbkIseUJBQXFCLElBQUk7RUFDMUI7OyIsCiAgIm5hbWVzIjogWyJwYXRoIiwgIkluc3RhbmNlU3RhdHVzIiwgIlJlZ2V4IiwgInBhdGgiLCAiZnMiLCAibG9nZ2VyIiwgImlkQWRkT3B0IiwgImZzIiwgImxvZ2dlciIsICJkZXZpY2VzRm9sZGVyIiwgInBhdGgiLCAiZGdyYW0iLCAib3MiLCAibG9nZ2VyIiwgImRncmFtIiwgImxvZ2dlciIsICJzb2NrIiwgImRncmFtIiwgImxvZ2dlciIsICJkZ3JhbSIsICJvcyIsICJsb2dnZXIiXQp9Cg==
